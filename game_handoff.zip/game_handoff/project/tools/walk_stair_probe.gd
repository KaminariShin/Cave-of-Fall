extends SceneTree
var bus: Node
var driver: Node
var game: Node
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures+=1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func body() -> Vector2i: return ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
func room_data(id: StringName) -> Dictionary: return ask(&"RoomGetRequested",{"id":id})["data"]
func anchor(ex: Dictionary) -> Vector2i:
	var p:=Vector2i(int(ex["x"]),int(ex["y"]))
	match ex["dirOut"]:
		"west":p.x+=1
		"east":p.x-=4
		"north":p.y+=1
		"south":p.y-=4
	return p
func steps_to(goal: Vector2i,area: Dictionary) -> Array:
	var start:=body()
	var queue:Array=[start]
	var prev:Dictionary={start:null}
	var i:=0
	while i<queue.size():
		var p:Vector2i=queue[i];i+=1
		if p==goal:
			var route:Array=[]
			while p!=start:
				var old:Vector2i=prev[p]
				route.push_front(p-old);p=old
			return route
		for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var n:Vector2i=p+d
			if not prev.has(n) and ask(&"SpaceBodyFitsRequested",{"anchor":n,"size":4,"room":area,"ignore_entity":game.HERO}).get("fits",false):
				prev[n]=p;queue.append(n)
	return []
func follow(route: Array) -> bool:
	for d in route:
		var expected: Vector2i=body()+d
		if not game._move(d): print("movement refused ",body()," delta ",d," ",game.message);return false
		driver.advance_steps(300)
		if body()!=expected: print("movement diverged ",body()," expected ",expected," message ",game.message);return false
	return true
func enter_planned(room_id: StringName, child: StringName) -> bool:
	var info: Dictionary=room_data(room_id)
	var out: Dictionary={}
	for ex in info["exits"]:
		if ex.get("childId",null)==child: out=ex; break
	if out.is_empty(): print("missing connected exit ",room_id," -> ",child);return false
	var goal:=anchor(out)
	var area: Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
	var path:=steps_to(goal,area)
	if path.is_empty() and body()!=goal: print("no walking path ",room_id," ",body()," -> ",goal);return false
	if not follow(path): return false
	var delta: Vector2i={"north":Vector2i.UP,"east":Vector2i.RIGHT,"south":Vector2i.DOWN,"west":Vector2i.LEFT}[out["dirOut"]]
	for i in range(8):
		if game.current_room==child:return true
		if not follow([delta]):return false
	return game.current_room==child

func neutralize(room_id: StringName) -> void:
	var state:=ask(&"RoomSpawnStatusRequested",{"room":room_id})
	for id in state.get("data",{}).get("placed",[]):
		ask(&"AIUnregisterRequested",{"entity":id})
		ask(&"CombatDamageRequested",{"entity":id,"source":game.HERO,"amount":999999})

func run() -> void:
	bus=root.get_node("EventBus")
	driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save"
	var existed:=FileAccess.file_exists(path)
	var old:=PackedByteArray()
	if existed:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	game=load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"demo initialized")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"disable tutorial enemy for walking test")
	# Ускорение времени шага только в тесте: коллизия и MovementStepRequested настоящие.
	check(ask(&"MovementConfigureRequested",{"entity":game.HERO,"base_hundredths":1.0,"K_move":50.0}).get("accepted",false),"accelerate test movement")
	# Сначала строим настоящий граф, используя обычный ленивый генератор.
	# Это программное исследование, а не проверка решений игрока.
	var stack: Array=[game.ROOM]
	var attempts:=0
	var stair: Dictionary={}
	while not stack.is_empty() and attempts<100:
		var room: StringName=stack.pop_back()
		for ex in room_data(room)["exits"]:
			if ex["connected"] or ex["sealed"]:continue
			attempts+=1
			var gen:=ask(&"RoomChildGenerateRequested",{"room":room,"exit":ex["id"]})
			if gen.get("accepted",false):stack.append(gen["child"])
			var q:=ask(&"DungeonStairGetRequested",{})
			if q.get("found",false) and q["data"]["status"]=="placed":stair=q["data"];break
		if not stair.is_empty():break
	check(not stair.is_empty(),"placed staircase generated")
	if stair.is_empty():quit(1);return
	var rooms: Dictionary=ask(&"RoomAllGetRequested",{})["rooms"]
	var route: Array=[stair["room"]]
	while route[0]!=game.ROOM:
		var parent: StringName=rooms[route[0]]["parent"]
		if parent==&"":check(false,"valid generated path");quit(1);return
		route.push_front(parent)
	check(route.size()>6,"stair route meets distance rule")
	print("Всего переходов: ",route.size()-1)
	for i in range(route.size()-1):
		print("Переход ",i+1,"/",route.size()-1)
		check(enter_planned(route[i],route[i+1]),"real walking into room %d" % (i+1))
		if game.current_room!=route[i+1]:quit(1);return
		await process_frame
		await process_frame
		await process_frame
		# Существа порождены обычной системой, но отключаются и устраняются
		# искусственным уроном: этот тест не проверяет баланс и тактику боя.
		neutralize(route[i+1])
		if i==3:
			check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false) and ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"save/load during real walk")
			await process_frame
			await process_frame
			neutralize(route[i+1])
	var data: Dictionary=room_data(route.back())
	var bounds: Dictionary={"origin":data["origin_cell"]*4,"size":data["size_cells"]*4}
	var tile: Vector2i=ask(&"ObjectGetRequested",{"object":stair["object"]})["data"]["tile"]
	var walk: Array=[]
	var found := false
	for y in range(tile.y-4,tile.y+2):
		for x in range(tile.x-4,tile.x+2):
			var p:=Vector2i(x,y)
			var adj:=((tile.x==p.x-1 or tile.x==p.x+4) and tile.y>=p.y and tile.y<p.y+4) or ((tile.y==p.y-1 or tile.y==p.y+4) and tile.x>=p.x and tile.x<p.x+4)
			if adj:
				var candidate:=steps_to(p,bounds)
				if not candidate.is_empty() or body()==p:walk=candidate;found=true;break
		if found:break
	check(found and follow(walk),"walk to staircase interaction")
	ask(&"CombatDetectionChanged",{"entity":game.HERO,"active":false})
	check(game._interact_chest() and driver.advance_steps(10)==10,"interact and descend")
	check(ask(&"DungeonFloorTrackingGetRequested",{})["data"]["floor"]==2,"actual second floor reached")
	game.queue_free()
	await process_frame
	if existed:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo walk to stairs: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
