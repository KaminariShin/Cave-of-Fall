extends SceneTree
var bus: Node
var game: Node
var driver: Node
var failures := 0
func check(v: bool,label: String) -> void:
	if not v: failures+=1; printerr("FAIL: ",label)
func _initialize() -> void: call_deferred("run")
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus=root.get_node("EventBus")
	driver=root.get_node("TimeDriver")
	driver.set_process(false)
	game=load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	for floor_no in range(1,5):
		var stack: Array=[game.ROOM]
		var count:=0
		var got: Dictionary={}
		while not stack.is_empty() and count < 130:
			var room: StringName=stack.pop_back()
			var data: Dictionary=ask(&"RoomGetRequested",{"id":room})["data"]
			for ex in data["exits"]:
				if ex["connected"] or ex["sealed"]: continue
				count+=1
				var made:=ask(&"RoomChildGenerateRequested",{"room":room,"exit":ex["id"]})
				if made.get("accepted",false): stack.append(made["child"])
				if floor_no < 4:
					var st:=ask(&"DungeonStairGetRequested",{})
					if st.get("found",false) and st["data"]["status"]=="placed": got=st["data"]; break
				else:
					var track:=ask(&"DungeonFloorTrackingGetRequested",{})
					if track["data"].get("boss_candidate",null)!=null: got=track["data"];break
			if not got.is_empty():break
		check(not got.is_empty(),"natural generation reaches target on floor %d within search budget" % floor_no)
		if got.is_empty(): quit(1); return
		if floor_no==4:
			var boss_room: StringName=got["boss_candidate"]
			var info:Dictionary=ask(&"RoomGetRequested",{"id":boss_room})["data"]
			var bounds:Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
			var spot:=Vector2i(-1,-1)
			for y in range(bounds["origin"].y,bounds["origin"].y+bounds["size"].y-3):
				for x in range(bounds["origin"].x,bounds["origin"].x+bounds["size"].x-3):
					var p:=Vector2i(x,y)
					if ask(&"SpaceBodyFitsRequested",{"anchor":p,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false):spot=p;break
				if spot.x>=0:break
			if spot.x<0:check(false,"no boss room entry position");quit(1);return
			ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null})
			check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":spot}).get("accepted",false),"teleport into procedural boss room")
			check(ask(&"RoomEnterRequested",{"entity":game.HERO,"room":boss_room}).get("accepted",false),"enter boss room")
			await process_frame;await process_frame;await process_frame
			var boss:=ask(&"DungeonBossGetRequested",{})
			print("Boss status ",boss," message ",game.message)
			var chest_status:=ask(&"DungeonBossChestAutoStatusRequested",{})
			print("Boss chest search status ",chest_status)
			check(chest_status.get("status","") in ["waiting","searching","created"],"chest search not stopped on other room update")
			for step in range(400):
				if chest_status.get("status","") in ["created","failed"]:break
				await process_frame
				chest_status=ask(&"DungeonBossChestAutoStatusRequested",{})
				if step % 25 == 24:print("search step=",step+1," status=",chest_status)
			print("Final boss chest status ",chest_status)
			check(chest_status.get("status","")=="created","natural boss chest eventually created")
			if chest_status.get("status","")=="created":
				var chest:StringName=chest_status["object"]
				var chest_obj:Dictionary=ask(&"ObjectGetRequested",{"object":chest}).get("data",{})
				var chest_items:Array=ask(&"InventoryGetRequested",{"entity":chest}).get("data",{}).get("items",[])
				var safety:=ask(&"DungeonChestPositionPreflightRequested",{"room":boss_room,"tile":chest_obj.get("tile",null),"existing_object":chest})
				print("Chest items=",chest_items.size()," safety=",safety.get("accepted",false))
				check(chest_items.size()>=4 and chest_items.size()<=8 and safety.get("accepted",false),"created chest contents and access")
			if not boss.get("found",false):check(false,"boss spawned");quit(1);return
			var id:StringName=boss["data"]["entity"]
			var ai:=ask(&"AIGetRequested",{"entity":id})
			check(ai.get("found",false) and ai["data"].get("role","")=="melee","boss has common AI")
			var boss_body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":id})["data"]
			var nearby:=Vector2i(-1,-1)
			for d in [Vector2i(-5,1),Vector2i(7,1),Vector2i(1,-5),Vector2i(1,7),Vector2i(-6,1),Vector2i(8,1),Vector2i(1,-6),Vector2i(1,8)]:
				var p:Vector2i=boss_body["anchor"]+d
				if ask(&"SpaceBodyFitsRequested",{"anchor":p,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false):nearby=p;break
			if nearby.x<0:check(false,"no nearby combat position");quit(1);return
			check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":nearby}).get("accepted",false),"teleport adjacent to boss")
			var hero_start:float=ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"})["data"]["current"]
			var boss_start:float=ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"})["data"]["current"]
			var attacks:=0
			for i in range(80):
				if game.is_dead or not ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false):break
				var hb:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]
				var bb:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":id})["data"]
				var diff:Vector2i=(bb["anchor"]+Vector2i.ONE*3)-(hb["anchor"]+Vector2i.ONE*2)
				if absi(diff.x)>=absi(diff.y):game.facing=Vector2i(signi(diff.x),0)
				else:game.facing=Vector2i(0,signi(diff.y))
				if maxi(absi(diff.x),absi(diff.y))<=9:
					if game._start_attack():attacks+=1
				else:
					if not game._move(game.facing):game._wait()
				driver.advance_steps(100)
				if i%10==0:print("turn=",i," hero hp=",ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{}).get("current")," boss hp=",ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"}).get("data",{}).get("current")," attacks=",attacks)
			var hero_end:float=ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{}).get("current",0)
			var boss_end:float=ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"}).get("data",{}).get("current",0)
			print("Combat outcome hero=",hero_start,"->",hero_end," boss=",boss_start,"->",boss_end," attacks=",attacks," player_dead=",game.is_dead)
			check(attacks>0 and boss_end<boss_start,"player damages boss with actual attacks")
			check(hero_end<hero_start,"boss damages player with common AI")
			break
		var stair: Dictionary=ask(&"ObjectGetRequested",{"object":got["object"]})["data"]
		var info: Dictionary=ask(&"RoomGetRequested",{"id":got["room"]})["data"]
		var bounds: Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
		var tile: Vector2i=stair["tile"]
		var spot:=Vector2i(-1,-1)
		for y in range(tile.y-4,tile.y+2):
			for x in range(tile.x-4,tile.x+2):
				var p:=Vector2i(x,y)
				var adj:=((tile.x==p.x-1 or tile.x==p.x+4) and tile.y>=p.y and tile.y<p.y+4) or ((tile.y==p.y-1 or tile.y==p.y+4) and tile.x>=p.x and tile.x<p.x+4)
				if adj and ask(&"SpaceBodyFitsRequested",{"anchor":p,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false): spot=p;break
			if spot.x>=0:break
		if spot.x<0:check(false,"stair has reachable adjacent location");quit(1);return
		ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null})
		var move:=ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":spot})
		var enter:=ask(&"RoomEnterRequested",{"entity":game.HERO,"room":got["room"]})
		ask(&"CombatDetectionChanged",{"entity":game.HERO,"active":false})
		var ok: bool=game._interact_chest()
		check(move.get("accepted",false) and move.get("anchor",null)==spot and enter.get("accepted",false),"test teleport near stairs")
		check(ok and driver.advance_steps(10)==10,"actual demo descent")
		if not ok:quit(1);return
		var next:=ask(&"DungeonFloorTrackingGetRequested",{})
		if next.get("data",{}).get("floor",0)!=floor_no+1:check(false,"failed descent " + game.message);quit(1);return
		await process_frame
		await process_frame

	game.queue_free()
	await process_frame
	print("Procedural boss combat diagnostic: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
