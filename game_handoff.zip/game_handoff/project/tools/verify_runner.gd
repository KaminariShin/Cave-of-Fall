extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var runner = load("res://scripts/test_runner_service.gd").new()
	root.add_child(runner)
	var total: int = runner.discover_tests().size()
	var result: Dictionary = runner.start_all()
	if not result.get("accepted", false):
		printerr("FAIL: runner could not start: ", result)
		quit(1)
		return
	var summary: Dictionary = await runner.run_finished
	for item in summary["results"]:
		if item["status"] != "PASS": printerr("FAIL: ", item["name"], " ", item["reason"], "\n", item["log"])
	print("Runner full run: ", summary["passed"], "/", total, " report=", summary["run_dir"])
	quit(0 if summary["passed"] == total and summary["completed"] == total else 1)
