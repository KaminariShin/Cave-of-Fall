extends SceneTree
var bus: Node
var game: Node
var driver: Node
var failures := 0
func check(v: bool,label: String) -> void:
	if not v: failures+=1; printerr("FAIL: ",label)
func _initialize() -> void: call_deferred("run")
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus=root.get_node("EventBus")
	driver=root.get_node("TimeDriver")
	driver.set_process(false)
	game=load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	for floor_no in range(1,5):
		var stack: Array=[game.ROOM]
		var count:=0
		var got: Dictionary={}
		while not stack.is_empty() and count < 130:
			var room: StringName=stack.pop_back()
			var data: Dictionary=ask(&"RoomGetRequested",{"id":room})["data"]
			for ex in data["exits"]:
				if ex["connected"] or ex["sealed"]: continue
				count+=1
				var made:=ask(&"RoomChildGenerateRequested",{"room":room,"exit":ex["id"]})
				if made.get("accepted",false): stack.append(made["child"])
				if floor_no < 4:
					var st:=ask(&"DungeonStairGetRequested",{})
					if st.get("found",false) and st["data"]["status"]=="placed": got=st["data"]; break
				else:
					var track:=ask(&"DungeonFloorTrackingGetRequested",{})
					if track["data"].get("boss_candidate",null)!=null: got=track["data"];break
			if not got.is_empty():break
		check(not got.is_empty(),"natural generation reaches target on floor %d within search budget" % floor_no)
		if got.is_empty(): quit(1); return
		if floor_no==4:
			var boss_room: StringName=got["boss_candidate"]
			var info:Dictionary=ask(&"RoomGetRequested",{"id":boss_room})["data"]
			var bounds:Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
			var spot:=Vector2i(-1,-1)
			for y in range(bounds["origin"].y,bounds["origin"].y+bounds["size"].y-3):
				for x in range(bounds["origin"].x,bounds["origin"].x+bounds["size"].x-3):
					var p:=Vector2i(x,y)
					if ask(&"SpaceBodyFitsRequested",{"anchor":p,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false):spot=p;break
				if spot.x>=0:break
			if spot.x<0:check(false,"no boss room entry position");quit(1);return
			ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null})
			check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":spot}).get("accepted",false),"teleport into procedural boss room")
			check(ask(&"RoomEnterRequested",{"entity":game.HERO,"room":boss_room}).get("accepted",false),"enter boss room")
			await process_frame;await process_frame;await process_frame
			var boss:=ask(&"DungeonBossGetRequested",{})
			print("Boss status ",boss," message ",game.message)
			var chest_status:=ask(&"DungeonBossChestAutoStatusRequested",{})
			print("Boss chest search status ",chest_status)
			check(chest_status.get("status","") in ["waiting","searching","created"],"chest search not stopped on other room update")
			if not boss.get("found",false):check(false,"boss spawned");quit(1);return
			var id:StringName=boss["data"]["entity"]
			var ai:=ask(&"AIGetRequested",{"entity":id})
			check(ai.get("found",false) and ai["data"].get("role","")=="melee","boss has common AI")
			var roomdata:Dictionary=ask(&"RoomGetRequested",{"id":boss_room})["data"]
			print("ROOM=",roomdata," HERO=",ask(&"SpaceBodyGetRequested",{"entity":game.HERO})," BOSS=",ask(&"SpaceBodyGetRequested",{"entity":id}))
			var origin:Vector2i=roomdata["origin_cell"]*4
			var size:Vector2i=roomdata["size_cells"]*4
			var reasons:Dictionary={};var seen:=0
			for y in range(origin.y,origin.y+size.y):
				for x in range(origin.x,origin.x+size.x):
					var tile:=Vector2i(x,y);var t:=ask(&"SpaceTileGetRequested",{"tile":tile})
					if t.get("kind",0)!=1 or t.get("occupant",null)!=null or t.get("obstacle",null)!=null or t.get("passage",false):continue
					var wall:=false
					for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
						if ask(&"SpaceTileGetRequested",{"tile":tile+d}).get("kind",0)==0:wall=true
					if not wall:continue
					var p:=ask(&"DungeonChestPositionPreflightRequested",{"room":boss_room,"tile":tile})
					var reason:String="ACCEPT" if p.get("accepted",false) else str(p.get("error","unknown"))
					reasons[reason]=reasons.get(reason,0)+1;seen+=1
					if seen>=20:break
				if seen>=20:break
			print("DIAG FIRST ",seen," ",reasons)
			quit(0);return

		var stair: Dictionary=ask(&"ObjectGetRequested",{"object":got["object"]})["data"]
		var info: Dictionary=ask(&"RoomGetRequested",{"id":got["room"]})["data"]
		var bounds: Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
		var tile: Vector2i=stair["tile"]
		var spot:=Vector2i(-1,-1)
		for y in range(tile.y-4,tile.y+2):
			for x in range(tile.x-4,tile.x+2):
				var p:=Vector2i(x,y)
				var adj:=((tile.x==p.x-1 or tile.x==p.x+4) and tile.y>=p.y and tile.y<p.y+4) or ((tile.y==p.y-1 or tile.y==p.y+4) and tile.x>=p.x and tile.x<p.x+4)
				if adj and ask(&"SpaceBodyFitsRequested",{"anchor":p,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false): spot=p;break
			if spot.x>=0:break
		if spot.x<0:check(false,"stair has reachable adjacent location");quit(1);return
		ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null})
		var move:=ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":spot})
		var enter:=ask(&"RoomEnterRequested",{"entity":game.HERO,"room":got["room"]})
		ask(&"CombatDetectionChanged",{"entity":game.HERO,"active":false})
		var ok: bool=game._interact_chest()
		check(move.get("accepted",false) and move.get("anchor",null)==spot and enter.get("accepted",false),"test teleport near stairs")
		check(ok and driver.advance_steps(10)==10,"actual demo descent")
		if not ok:quit(1);return
		var next:=ask(&"DungeonFloorTrackingGetRequested",{})
		if next.get("data",{}).get("floor",0)!=floor_no+1:check(false,"failed descent " + game.message);quit(1);return
		await process_frame
		await process_frame

	game.queue_free()
	await process_frame
	print("Procedural boss combat diagnostic: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
