from PIL import Image, ImageDraw
from pathlib import Path
S=3; P=Path(__file__).resolve().parents[1]/'assets'/'item_icons'; P.mkdir(exist_ok=True)
def xy(p):return tuple(round(v*S) for v in p)
def poly(d,pts,fill,outline='#211a18',width=1.6):
 pts=[xy(p) for p in pts];d.polygon(pts,fill=fill);d.line(pts+[pts[0]],fill=outline,width=int(width*S),joint='curve')
def line(d,pts,color,width):d.line([xy(p) for p in pts],fill=color,width=int(width*S),joint='curve')
def ell(d,box,fill,outline='#211a18',width=1.6):d.ellipse(xy(box),fill=fill,outline=outline,width=int(width*S))
def rect(d,box,fill,outline='#211a18',width=1.6):d.rounded_rectangle(xy(box),radius=2*S,fill=fill,outline=outline,width=int(width*S))
def image():
 im=Image.new('RGBA',(96*S,96*S));return im,ImageDraw.Draw(im)
def save(im,name):im.resize((96,96),Image.Resampling.LANCZOS).save(P/(name+'.png'))
# Steel blade
im,d=image();poly(d,[(35,67),(32,59),(59,13),(68,7),(69,18),(43,64)],'#bac3c2');line(d,[(36,58),(64,13)],'#f2eeee',1);poly(d,[(27,58),(31,54),(46,63),(43,67)],'#b79851');line(d,[(33,65),(22,83)],'#6b4532',5);ell(d,(17,80,24,87),'#bd9d5b');save(im,'sword_simple')
# Hammer
im,d=image();line(d,[(32,84),(61,28)],'#805439',8);line(d,[(30,83),(40,65)],'#d6b682',2);poly(d,[(47,21),(55,9),(75,19),(79,26),(72,38),(59,32)],'#a1a5a0');poly(d,[(45,18),(52,8),(57,11),(50,23)],'#777e7b');save(im,'hammer_simple')
# Bow
im,d=image();line(d,[(31,12),(66,48),(31,84)],'#d8c49a',1.5);line(d,[(31,12),(21,20),(17,34),(17,61),(21,75),(31,84)],'#b58442',5);line(d,[(17,38),(17,59)],'#653f27',5);line(d,[(29,49),(73,49)],'#9f7147',2);poly(d,[(75,49),(64,44),(64,54)],'#d4d4cc');save(im,'bow_simple')
# Staff
im,d=image();line(d,[(30,82),(61,19)],'#8b633f',7);ell(d,(56,9,72,25),'#7e9c99');save(im,'staff_simple')
for name,color,w in [('shield_small','#a98a65',22),('shield_medium','#879890',28),('shield_large','#9ba2a3',34)]:
 im,d=image();poly(d,[(48-w,20),(48,12),(48+w,20),(48+w-3,53),(48,82),(48-w+3,53)],color);poly(d,[(48-w+6,25),(48,19),(48+w-6,25),(48+w-9,51),(48,72),(48-w+9,51)],'#4d625a');line(d,[(48,19),(48,72)],'#d1c49c',2);save(im,name)
for name,color in [('armor_cloth_body','#a49ab0'),('armor_leather_body','#a8754e'),('armor_iron_body','#abb7b5')]:
 im,d=image();poly(d,[(33,14),(41,18),(55,18),(63,14),(78,26),(70,41),(65,37),(65,76),(31,76),(31,37),(26,41),(18,26)],color);line(d,[(39,22),(48,27),(57,22)],'#dfd6ba',2);line(d,[(35,60),(61,60)],'#55453a',2);save(im,name)
for name,color in [('potion_hp','#c7433d'),('potion_stamina','#6dba67'),('potion_mana','#4f88d3'),('antidote','#c1bd64')]:
 im,d=image();rect(d,(39,12,57,24),'#aa855c');poly(d,[(40,23),(56,23),(59,36),(69,44),(71,71),(65,80),(31,80),(25,71),(27,44),(37,36)],'#c8c9bd');poly(d,[(30,48),(66,48),(67,70),(62,76),(34,76),(29,70)],color,outline='#50433b');line(d,[(34,42),(34,63)],'#eff5e1',2);save(im,name)
im,d=image();rect(d,(17,31,79,65),'#d2c9af');line(d,[(25,32),(52,64)],'#8b806e',4);line(d,[(43,32),(70,64)],'#8b806e',4);save(im,'bandage')
im,d=image();ell(d,(18,15,78,79),'#90775a');line(d,[(48,30),(48,53)],'#f0dbb6',7);ell(d,(44,60,52,68),'#f0dbb6');save(im,'unknown')
