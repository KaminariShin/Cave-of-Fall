extends SceneTree
var bus: Node
var driver: Node
var game: Node
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures+=1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func body() -> Vector2i: return ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
func room_data(id: StringName) -> Dictionary: return ask(&"RoomGetRequested",{"id":id})["data"]
func anchor(ex: Dictionary) -> Vector2i:
	var p:=Vector2i(int(ex["x"]),int(ex["y"]))
	match ex["dirOut"]:
		"west":p.x+=1
		"east":p.x-=4
		"north":p.y+=1
		"south":p.y-=4
	return p
func steps_to(goal: Vector2i,area: Dictionary) -> Array:
	var start:=body()
	var queue:Array=[start]
	var prev:Dictionary={start:null}
	var i:=0
	while i<queue.size():
		var p:Vector2i=queue[i];i+=1
		if p==goal:
			var route:Array=[]
			while p!=start:
				var old:Vector2i=prev[p]
				route.push_front(p-old);p=old
			return route
		for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var n:Vector2i=p+d
			if not prev.has(n) and ask(&"SpaceBodyFitsRequested",{"anchor":n,"size":4,"room":area,"ignore_entity":game.HERO}).get("fits",false):
				prev[n]=p;queue.append(n)
	return []
func follow(route: Array) -> bool:
	for d in route:
		var expected: Vector2i=body()+d
		if not game._move(d): print("movement refused ",body()," delta ",d," ",game.message);return false
		driver.advance_steps(300)
		if body()!=expected: print("movement diverged ",body()," expected ",expected," message ",game.message);return false
	return true
func enter_planned(room_id: StringName, child: StringName) -> bool:
	var info: Dictionary=room_data(room_id)
	var out: Dictionary={}
	for ex in info["exits"]:
		if ex.get("childId",null)==child: out=ex; break
	if out.is_empty(): print("missing connected exit ",room_id," -> ",child);return false
	var goal:=anchor(out)
	var area: Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
	var path:=steps_to(goal,area)
	if path.is_empty() and body()!=goal: print("no walking path ",room_id," ",body()," -> ",goal);return false
	if not follow(path): return false
	var delta: Vector2i={"north":Vector2i.UP,"east":Vector2i.RIGHT,"south":Vector2i.DOWN,"west":Vector2i.LEFT}[out["dirOut"]]
	for i in range(8):
		if game.current_room==child:return true
		if not follow([delta]):return false
	return game.current_room==child

func neutralize(room_id: StringName) -> void:
	var state:=ask(&"RoomSpawnStatusRequested",{"room":room_id})
	for id in state.get("data",{}).get("placed",[]):
		ask(&"AIUnregisterRequested",{"entity":id})
		ask(&"CombatDamageRequested",{"entity":id,"source":game.HERO,"amount":999999})

# Диагностика: путь пешком на всех этажах; не проверка естественного боя.
func run() -> void:
	bus=root.get_node("EventBus")
	driver=root.get_node("TimeDriver");driver.set_process(false)
	game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized,"demo initialized")
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	for floor_no in range(1,5):
		print("=== FLOOR ",floor_no," ===")
		if not ask(&"MovementConfigureRequested",{"entity":game.HERO,"base_hundredths":1.0,"K_move":50.0}).get("accepted",false):check(false,"accelerate test movement");quit(1);return
		var stack:Array=[game.ROOM];var attempts:=0;var target:Dictionary={};var goal_room:StringName=&""
		while not stack.is_empty() and attempts<130:
			var rid:StringName=stack.pop_back()
			for ex in room_data(rid)["exits"]:
				if ex["connected"] or ex["sealed"]:continue
				attempts+=1
				var gen:=ask(&"RoomChildGenerateRequested",{"room":rid,"exit":ex["id"]})
				if gen.get("accepted",false):stack.append(gen["child"])
				if floor_no<4:
					var st:=ask(&"DungeonStairGetRequested",{})
					if st.get("found",false) and st["data"]["status"]=="placed":target=st["data"];goal_room=target["room"];break
				else:
					var tr:=ask(&"DungeonFloorTrackingGetRequested",{})
					if tr.get("data",{}).get("boss_candidate",null) is StringName:
						goal_room=tr["data"]["boss_candidate"];target=tr["data"];break
			if not target.is_empty():break
		check(not target.is_empty(),"target generated floor %d attempts %d" % [floor_no,attempts])
		if target.is_empty():quit(1);return
		var rooms:Dictionary=ask(&"RoomAllGetRequested",{})["rooms"]
		var route:Array=[goal_room]
		while route[0]!=game.ROOM:
			var parent:StringName=rooms[route[0]]["parent"]
			if parent==&"":check(false,"valid route");quit(1);return
			route.push_front(parent)
		print("route transitions=",route.size()-1)
		for i in range(route.size()-1):
			print("floor ",floor_no," room ",i+1,"/",route.size()-1)
			if not enter_planned(route[i],route[i+1]):check(false,"walk across room %d" % (i+1));quit(1);return
			await process_frame;await process_frame;await process_frame
			# Обычные враги искусственно устраняются, чтобы проверить геометрию.
			if floor_no<4 or i+1<route.size()-1:neutralize(route[i+1])
		if floor_no==4:
			print("Boss room reached by movement; combat and victory NOT checked")
			break
		var data:Dictionary=room_data(goal_room)
		var bounds:Dictionary={"origin":data["origin_cell"]*4,"size":data["size_cells"]*4}
		var tile:Vector2i=ask(&"ObjectGetRequested",{"object":target["object"]})["data"]["tile"]
		var walk:Array=[];var found:=false
		for y in range(tile.y-4,tile.y+2):
			for x in range(tile.x-4,tile.x+2):
				var p:=Vector2i(x,y)
				var adj:=((tile.x==p.x-1 or tile.x==p.x+4) and tile.y>=p.y and tile.y<p.y+4) or ((tile.y==p.y-1 or tile.y==p.y+4) and tile.x>=p.x and tile.x<p.x+4)
				if adj:
					var candidate:=steps_to(p,bounds)
					if not candidate.is_empty() or body()==p:walk=candidate;found=true;break
			if found:break
		if not found or not follow(walk):check(false,"stair reachable floor %d" % floor_no);quit(1);return
		ask(&"CombatDetectionChanged",{"entity":game.HERO,"active":false})
		if not game._interact_chest() or driver.advance_steps(10)!=10:check(false,"descend floor %d: %s" % [floor_no,game.message]);quit(1);return
		if ask(&"DungeonFloorTrackingGetRequested",{})["data"]["floor"]!=floor_no+1:check(false,"descent result");quit(1);return
		await process_frame;await process_frame
	game.queue_free();await process_frame
	print("Four floor walk diagnostic: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
