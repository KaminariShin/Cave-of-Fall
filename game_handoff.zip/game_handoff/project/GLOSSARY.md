# Словарь разработки: понятия и текущий код

Словарь сопоставляет ТЗ с **текущей частичной реализацией**. Название понятия в ТЗ не обязательно является именем функции. Контракты запросов и ограничения приведены в README; события фрагмента 53 — в EVENTS.md.

## Ядро

| Термин | Текущий код |
|---|---|
| Time Driver, gameTime | `scripts/time_driver.gd`: единственная шкала игрового времени, шаг 0,01 с. Внутренние фазы процессов и ресурсов относятся к тому же шагу. |
| Process Registry | `scripts/process_registry.gd`, процессы; `ProcessStartRequested`, `ProcessGetRequested`, `ProcessInterruptRequested`. |
| Action Registry | `scripts/action_registry.gd`, действия сущностей; `ActionStartRequested`, `ActionInterruptRequested`, `ActionGetRequested`. |
| Event Bus | `scripts/event_bus.gd`: синхронные `publish`/`subscribe`; общий словарь запроса и ответа. |
| Entity Registry | `scripts/entity_registry.gd`: ID и компоненты. |
| Accumulator | `scripts/accumulator.gd`, дробное накопление; сервис ресурсов использует `accumulate_unbounded`. |
| World Tick Hook | `scripts/world_tick_hook.gd`, проверки событий среды в текущей комнате. Данные и эффекты пока не заполнены. |

## Координаты, тела и пространство

- **Клетка** — логическая единица генерации; **тайл** — физическая единица симуляции. При текущем `tiles_per_cell = 4` клетка состоит из 4×4 тайлов, физический тайл — 1/16 клетки. Коэффициент расположен в ruleset.
- **Якорь** — левый верхний тайл тела, `anchor` в SpaceService; **body_size / BSZ** — длина стороны квадратного тела в тайлах; **центр** — `anchor + Vector2.ONE * size / 2` (для движущегося тела — от интерполированной позиции).
- **bodyFits**: `SpaceBodyFitsRequested`, проверка пола, границ, тел и препятствий; `SpaceBodyGroupFitsRequested` — групповая проверка. Точные ограничения описаны в README фрагментов 20, 37 и 39.
- **covers**, **rectsOverlap**, **bodyGap** — геометрические понятия ТЗ; нет единого публичного API с этими именами. Покрытие и пересечения рассчитываются в соответствующих сервисах. Не считать произвольный запрос к ним реализованным.
- **posAt** — позиция во время движения. В проекте `MovementPositionGetRequested` возвращает интерполированную текущую позицию; произвольная историческая `posAt(t)` и история `pushSeg` пока не реализованы.
- **tileAt**: `SpaceTileGetRequested`, 1 — пол, 0 — скала. **LOS**: `SpaceLineOfSightRequested`; StrikeZoneService также проверяет видимость для тайлов зоны. Непроходимые сундуки и алтари пока не блокируют LOS или снаряды.
- **Проход** связывает комнаты, отдельного объекта двери нет; комнаты задаются логическими прямоугольниками, cave-режим добавляет геометрию пола. API — RoomService и SpaceService.

## Бой и оружие

- **HB** — половина размера тела; `range` — дальность, `gap` — отступ. `StrikeZoneGetRequested` строит набор тайлов зоны с полосой и LOS; `StrikeZoneBodyTestRequested` проверяет пересечение с телом. Формы `arc`, `line`, `cone` задаются данными.
- `base_attack_time`, `min_percent` — данные типа; `speed_effectiveness` — эффективность конкретного удара; `min_time_bonus` и `stamina_cost_percent` — свойства тегов. `WeaponHierarchyService`, `WeaponTimingService`, `WeaponStrikeService` хранят данные и выполняют предпросмотр. Неизвестный процент Stamina помечается `stamina_cost_complete: false`.
- `WeaponAttackTimingRequested` возвращает сырую длительность, пол и округлённую длительность. Выбранный удар пока не запускается этим сервисом; полноценная экипировка и два комплекта ещё не реализованы.

## Ресурсы и вес

- `CON`, `STR`, `DEX`, `INT`, `WIS`, `PER` — характеристики; `HP`, `Stamina`, `MP` — ресурсы. `ResourceGetRequested` выдаёт `current`, `max`, `remainder`, `timer`, `reserve`, `reserve_filled`.
- **period** — период регенерации, по умолчанию 0,5 с; порядок — MP, Stamina, HP. Множитель стоимости HP находится в `parameters.resources.regeneration.hp_stamina_multiplier`, сейчас 2,5.
- **free_stamina**: в текущем ResourceService это `Stamina.current`, уже без перенесённой в резерв суммы. `ResourceSpendRequested` списывает свободную Stamina; ожидающий резерв хранится в полях HP и заполняется до обычного регена.
- **capacity** — физическая грузоподъёмность `20 + STR × 5` кг; фактический вес и ступень — `WeightGetRequested`. **Бюджетный вес** рассчитывается отдельно по типу, виду, тегам и уровню; вклад предметов пока не определён.

## Спавн, обнаружение и ИИ

- **budget** — бюджет комнаты; **placed** — размещённые сущности; **queue / pending** — очередь размещения. `RoomSpawnRequested` и `RoomSpawnStatusRequested` — входные точки SpawnService. При выходе действия NPC отменяются согласно уточнению пользователя; состав очереди сохраняется.
- **max_level** — уровень по глубине; **growth_per_level** и веса задаются данными. Формула бюджетного веса и реальные пулы содержимого остаются неполными.
- **radius** — радиус обнаружения, PER × `radius_unit_in_tiles`; **noise** — шум, **LOS** — проверка видимости. `DetectionService`, `DetectionDetailsService`; пороги информации о цели заданы в ruleset.
- **mode** — `exploration` или `combat`; `GameModeGetRequested`, `GameModeChanged`. Хотбар — список взаимно обнаруженных враждебных сущностей в данных, не готовый игровой UI.
- **stepToward** — `MovementStepTowardRequested`; **aimAnchor** — `MovementAimAnchorRequested`; **pathTo** — ограниченный BFS через `MovementPathFindRequested` и `MovementPathStartRequested`.
- **summon_time**, расход маны и лимит — данные призывателя в ruleset и AIService; автоматическое назначение ИИ и экипировки всем мобам не реализовано.
- **findStagingDoor**, **dashStepOk** и полноценная история движения/отбрасывания в проекте отсутствуют. **enemyActionInfo** частично представлен `DetectionDetailsGetRequested`: детали доступны только в пределах реализованных действий и порогов PER.

**ADR** — architecture decision record; **ruleset** — версионированный набор правил. Самостоятельного документа с 27 ADR в проекте нет; не следует считать его созданным.
