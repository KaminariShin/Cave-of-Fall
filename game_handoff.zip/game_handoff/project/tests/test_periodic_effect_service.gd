extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, event: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, event)
	return event
func hp() -> float:
	return float(ask(&"ResourceGetRequested", {"entity":&"target", "resource":&"HP"})["data"]["current"])
func effect() -> Dictionary:
	return ask(&"PeriodicEffectGetRequested", {"entity":&"target", "effect":&"poison"})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"EntityCreateRequested", {"entity":&"target", "components":{&"stats":{"CON":4}}}).get("accepted", false), "create target")
	var before := hp()
	var e := {"entity":&"target", "effect":&"poison", "source":&"a", "damage_type":"physical", "damage_per_tick":0.6, "base_duration":5.0}
	check(ask(&"PeriodicEffectApplyRequested", e).get("accepted", false), "apply effect")
	check(driver.wait_for(10.0), "start time")
	driver.advance_steps(49)
	check(is_equal_approx(hp(), before), "no tick before half second")
	driver.advance_steps(1)
	check(is_equal_approx(hp(), before) and is_equal_approx(float(effect()["data"]["remainder"]), 0.6), "fraction accumulated")
	driver.advance_steps(20)
	var replacement := {"entity":&"target", "effect":&"poison", "source":&"b", "damage_type":"physical", "damage_per_tick":1.0, "base_duration":1.0}
	check(ask(&"PeriodicEffectApplyRequested", replacement).get("accepted", false), "refresh")
	var state: Dictionary = effect()["data"]
	check(state["next_tick_steps"] == 30 and is_equal_approx(float(state["remainder"]), 0.6) and state["source"] == &"b", "refresh keeps timer and remainder; higher source wins")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save active effect")
	driver.advance_steps(30)
	check(is_equal_approx(hp(), before - 1.0), "damage tick occurs at preserved timer")
	check(ask(&"SessionLoadRequested", {}).get("accepted", false), "load active effect")
	check(is_equal_approx(hp(), before) and effect()["data"]["next_tick_steps"] == 30, "save restored hp and timer")
	driver.advance_steps(30)
	check(is_equal_approx(hp(), before - 1.0), "restored effect ticks")
	var equal := {"entity":&"target", "effect":&"poison", "source":&"c", "damage_type":"physical", "damage_per_tick":1.0, "base_duration":0.5}
	check(ask(&"PeriodicEffectApplyRequested", equal).get("accepted", false) and effect()["data"]["source"] == &"b", "equal damage keeps source")
	var callback := func(q): q["percent"] = 50.0
	root.get_node("EventBus").subscribe(&"PeriodicProtectionGetRequested", callback)
	driver.advance_steps(50)
	check(is_equal_approx(hp(), before - 2.0) and not effect()["found"], "current protection applied and boundary tick precedes expiration")
	root.get_node("EventBus").unsubscribe(&"PeriodicProtectionGetRequested", callback)
	check(ask(&"PeriodicEffectApplyRequested", e.duplicate()).get("accepted", false), "reapply")
	check(ask(&"PeriodicEffectRemoveRequested", {"entity":&"target", "effect":&"poison"}).get("accepted", false) and not effect()["found"], "remove clears effect")
	check(ask(&"EntityCreateRequested", {"entity":&"victim", "components":{&"stats":{"CON":4}}}).get("accepted", false), "create victim")
	check(ask(&"ResourceSetRequested", {"entity":&"victim", "resource":&"HP", "value":1}).get("accepted", false), "victim hp")
	check(ask(&"PeriodicEffectApplyRequested", {"entity":&"victim", "effect":&"poison", "source":&"attacker", "damage_type":"physical", "damage_per_tick":2, "base_duration":0.5}).get("accepted", false), "lethal effect")
	var witness := {"died":false, "tick_saw_death":false}
	var on_death := func(event):
		if event.get("entity", &"") == &"victim": witness["died"] = true
	var on_tick := func(_event):
		if witness["died"]: witness["tick_saw_death"] = true
	root.get_node("EventBus").subscribe(&"EntityDied", on_death)
	root.get_node("EventBus").subscribe(&"Tick", on_tick)
	driver.advance_steps(50)
	check(witness["died"] and witness["tick_saw_death"], "lethal tick precedes action Tick phase")
	check(not ask(&"PeriodicEffectGetRequested", {"entity":&"victim", "effect":&"poison"})["found"], "death clears effect")
	root.get_node("EventBus").unsubscribe(&"EntityDied", on_death)
	root.get_node("EventBus").unsubscribe(&"Tick", on_tick)
	check(ask(&"StatBaseSetRequested", {"entity":&"target", "stat":&"CON", "value":55}).get("accepted", false), "raise CON")
	var magical := {"entity":&"target", "effect":&"magic_dot", "damage_type":"magical", "damage_per_tick":1, "base_duration":2.0}
	var magical_result := ask(&"PeriodicEffectApplyRequested", magical)
	check(magical_result.get("accepted", false) and is_equal_approx(float(magical_result.get("duration", 0.0)), 2.0), "CON does not shorten magical effect")
	var physical := {"entity":&"target", "effect":&"physical_dot", "damage_type":"physical", "damage_per_tick":1, "base_duration":2.0}
	var physical_result := ask(&"PeriodicEffectApplyRequested", physical)
	check(physical_result.get("accepted", false) and is_equal_approx(float(physical_result.get("duration", 0.0)), 1.0), "CON shortens physical effect")
	print("Periodic effects tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
