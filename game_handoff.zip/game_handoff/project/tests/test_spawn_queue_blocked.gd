extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run_tests")
func check(v: bool, m: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",m)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name,data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(bus,&"SpaceMapConfigureRequested",{"size":Vector2i(100,100)})["accepted"],"map")
	check(ask(bus,&"RoomCreateRequested",{"id":&"r","type":"start","origin_cell":Vector2i(2,2),"size_cells":Vector2i(11,11)})["accepted"],"room")
	ask(bus,&"EntityCreateRequested",{"entity":&"hero"})
	ask(bus,&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(28,28),"size":4})
	ask(bus,&"ControlledEntityRequested",{"entity":&"hero"})
	ask(bus,&"RoomEnterRequested",{"entity":&"hero","room":&"r"})
	var keep := {}
	for x in range(28,32):
		for y in range(28,32): keep[Vector2i(x,y)] = true
	for x in [23,24,26,27]:
		for y in [25,26]: keep[Vector2i(x,y)] = true
	var clear: Array = []
	for x in range(9,51):
		for y in range(9,51):
			if not keep.has(Vector2i(x,y)): clear.append(Vector2i(x,y))
	ask(bus,&"SpaceTilesSetRequested",{"tiles":clear,"kind":0})
	var m := {"id":"small","type_weight":0.1,"species":{"id":"small","species_weight":0.2},"tags":[{"id":"t","tag_weight":0.1}],"body_size":2,"min_depth":0,"max_depth":null,"base_stats":{"CON":5,"STR":5,"DEX":5,"INT":5,"WIS":5,"PER":5},"growth_per_level":{"CON":0,"STR":0,"DEX":0,"INT":0,"WIS":0,"PER":0}}
	ask(bus,&"RngSeedRequested",{"seed":42})
	var r := ask(bus,&"RoomSpawnRequested",{"room":&"r","player":&"hero","entry_tile":Vector2i(28,28),"depth":6,"pool":[m],"queue_delay":0.05})
	check(r["accepted"] and r.get("queue_count",0) == 1,"queue setup")
	if not r["accepted"] or r["units"].size() != 2:
		quit(1)
		return
	var dead: StringName = r["units"][0]["entity"]
	var anchor: Vector2i = r["units"][0]["anchor"]
	ask(bus,&"CombatDamageRequested",{"entity":dead,"amount":9999})
	ask(bus,&"EntityCreateRequested",{"entity":&"blocker"})
	check(ask(bus,&"SpaceBodyPlaceRequested",{"entity":&"blocker","anchor":anchor,"size":2})["accepted"],"occupy freed slot")
	ask(bus,&"ActionStartRequested",{"entity":&"hero","action":&"wait","duration":1.0})
	driver.advance_steps(5)
	var state: Dictionary = ask(bus,&"RoomSpawnStatusRequested",{"room":&"r"})["data"]
	check(state["queue"].size() == 1 and state["pending"] == &"", "blocked at completion, mob remains in queue")
	check(ask(bus,&"EntityRemoveRequested",{"entity":&"blocker"})["accepted"],"remove blocker")
	state = ask(bus,&"RoomSpawnStatusRequested",{"room":&"r"})["data"]
	check(state["pending"] != &"", "space release restarts delay")
	check(ask(bus,&"ObjectCreateRequested",{"entity":&"altar_blocker","type":"altar","room":&"r","tile":anchor})["accepted"], "place solid object in freed slot")
	driver.advance_steps(5)
	state = ask(bus,&"RoomSpawnStatusRequested",{"room":&"r"})["data"]
	check(state["queue"].size() == 1 and state["pending"] == &"", "solid object also blocks queued mob")
	check(ask(bus,&"ObjectRemoveRequested",{"object":&"altar_blocker"})["accepted"], "remove blocking altar")
	state = ask(bus,&"RoomSpawnStatusRequested",{"room":&"r"})["data"]
	check(state["pending"] != &"", "object removal schedules queue")
	driver.advance_steps(5)
	state = ask(bus,&"RoomSpawnStatusRequested",{"room":&"r"})["data"]
	check(state["queue"].is_empty() and state["placed"].size() == 2,"queued mob eventually arrives")
	print("Blocked queue tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
