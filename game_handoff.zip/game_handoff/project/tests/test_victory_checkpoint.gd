extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"start" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2,2) if i == 0 else Vector2i(1 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if index == 1: parent_exit = &"east"
	elif not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"LevelGenerationRequested", {"level_id":&"floor4", "seed":19, "size_cells":Vector2i(80,50), "start_origin":Vector2i(2,2), "deadend_budget":1}).get("accepted", false), "actual level")
	check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":4, "start_room":&"start"}).get("accepted", false), "fourth floor")
	for i in range(1,17): check(add_room(i, "passage"), "chain")
	var boss_room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_16"})["data"]
	var p := Vector2i(-1,-1)
	var boss_bounds := {"origin":boss_room["origin_cell"] * 4, "size":boss_room["size_cells"] * 4}
	for y in range(boss_bounds["origin"].y + 1, boss_bounds["origin"].y + boss_bounds["size"].y - 4):
		for x in range(boss_bounds["origin"].x + 1, boss_bounds["origin"].x + boss_bounds["size"].x - 4):
			var candidate := Vector2i(x,y)
			if ask(&"SpaceBodyFitsRequested", {"anchor":candidate, "size":4, "room":boss_bounds, "ignore_entity":&""}).get("fits", false): p = candidate; break
		if p.x >= 0: break
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":p, "size":4}).get("accepted", false), "hero placement")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "controlled")
	check(ask(&"RunStatisticsStartRequested", {"entity":&"hero", "start_room":&"start"}).get("accepted", false), "statistics start")
	for floor_no in range(2, 5): check(ask(&"RunStatisticsFloorBeginRequested", {"floor":floor_no, "start_room":&"start"}).get("accepted", false), "statistics floor")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted", false), "inventory")
	check(ask(&"ItemCreateRequested", {"id":&"victory_item", "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "item created")
	check(ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"victory_item"}).get("accepted", false), "item owned")
	check(ask(&"ItemCreateRequested", {"id":&"victory_sword", "base_id":&"sword_simple", "item_level":1}).get("accepted", false), "sword created")
	check(ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"victory_sword"}).get("accepted", false), "sword owned")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"victory_sword", "slot":"main"}).get("accepted", false), "equip sword")
	driver.advance_steps(10)
	var depth: Variant = ask(&"DungeonRoomDepthRequested", {"room":&"node_16"})["depth"]
	var spawn := ask(&"RoomSpawnRequested", {"room":&"node_16", "player":&"hero", "entry_tile":p, "depth":depth, "pool":[]})
	check(spawn.get("accepted", false) and spawn.get("units", []).size() == 1, "spawn boss")
	if not spawn.get("accepted", false) or spawn.get("units", []).is_empty(): quit(1); return
	var boss_id: StringName = spawn["units"][0]["entity"]
	check(ask(&"RoomExitAddRequested", {"room":&"node_16", "id":&"south", "dir":"south", "offset_cells":5}).get("accepted", false), "outgoing")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":1}).get("accepted", false), "budget")
	var result := ask(&"RoomChildGenerateRequested", {"room":&"node_16", "exit":&"south"})
	check(result.get("accepted", false), "portal room generated")
	if not result.get("accepted", false): quit(1); return
	var portal := ask(&"DungeonPortalGetRequested", {})
	check(portal.get("found", false) and portal["data"].get("status", "") == "placed", "portal placed")
	if not portal.get("found", false) or portal["data"].get("status", "") != "placed": quit(1); return
	var oid: StringName = portal["data"]["object"]
	var obj := ask(&"ObjectGetRequested", {"object":oid})
	var tile: Vector2i = obj["data"]["tile"]
	check(obj["data"]["type"] == "portal_exit" and reachable_stair(result["child"], tile), "real reachable portal")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":result["child"]})["data"]
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var anchor := Vector2i(-1,-1)
	for dy in range(-4,2):
		for dx in range(-4,2):
			var a := tile + Vector2i(dx,dy)
			var adjacent := ((tile.x == a.x - 1 or tile.x == a.x + 4) and tile.y >= a.y and tile.y < a.y + 4) or ((tile.y == a.y - 1 or tile.y == a.y + 4) and tile.x >= a.x and tile.x < a.x + 4)
			if adjacent and ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&"hero"}).get("fits", false): anchor = a; break
		if anchor.x >= 0: break
	check(anchor.x >= 0 and ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":anchor}).get("accepted", false), "hero adjacent")
	var q := ask(&"DungeonPortalAvailabilityRequested", {"entity":&"hero"})
	check(q.get("accepted", false) and not q.get("rule_allowed", true), "locked before boss death")
	check(not ask(&"VictoryCheckpointPrepareRequested", {"entity":&"hero", "object":oid}).get("accepted", true), "living boss blocks checkpoint")
	check(ask(&"DungeonBossEquipmentInstallRequested", {"entity":boss_id}).get("accepted", false), "equip before boss fight")
	check(ask(&"CombatDamageRequested", {"entity":boss_id, "source":&"hero", "amount":999999}).get("accepted", false), "defeat boss")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":false})
	q = ask(&"DungeonPortalAvailabilityRequested", {"entity":&"hero"})
	check(q.get("rule_allowed", false) and q.get("transition_available", false), "portal can now finish the run")
	check(not ask(&"VictoryCheckpointPrepareRequested", {"entity":&"other", "object":oid}).get("accepted", true), "non-controlled actor rejected")
	var rng_before := {"sections":{}, "errors":[]}
	ask(&"SnapshotCollectRequested", rng_before)
	var checkpoint_time: float = driver.game_time
	var blocked_wrong := ask(&"VictoryCheckpointPrepareRequested", {"entity":&"hero", "object":&"wrong"})
	check(not blocked_wrong.get("accepted", true), "wrong portal rejected")
	var nested := {"seen":false, "accepted":true}
	var bus = root.get_node("EventBus")
	var reenter := func(_e):
		if nested["seen"]: return
		nested["seen"] = true
		nested["accepted"] = ask(&"VictoryCheckpointPrepareRequested", {"entity":&"hero", "object":oid}).get("accepted", false)
	bus.subscribe(&"SnapshotCollectRequested", reenter)
	var checkpoint := ask(&"VictoryCheckpointPrepareRequested", {"entity":&"hero", "object":oid})
	bus.unsubscribe(&"SnapshotCollectRequested", reenter)
	check(checkpoint.get("accepted", false) and not checkpoint.get("executable", true) and nested["seen"] and not nested["accepted"], "read-only checkpoint and reentry guard " + str(checkpoint.get("error", "")))
	var rng_after := {"sections":{}, "errors":[]}
	ask(&"SnapshotCollectRequested", rng_after)
	check(rng_before["sections"]["rng"] == rng_after["sections"]["rng"] and driver.game_time == checkpoint_time, "capture does not advance time or rng")
	if checkpoint.get("accepted", false):
		var cp: Dictionary = checkpoint["checkpoint"]
		check(not cp["profile_ready"] and cp["manifest"]["player_items"].has(&"victory_item") and cp["manifest"]["player_items"].has(&"victory_sword") and cp["manifest"]["item_locations"][&"victory_sword"]["kind"] == "equipment" and cp["snapshot"]["sections"]["entities"][&"hero"][&"inventory"]["items"].has(&"victory_item"), "full raw snapshot and player item included")
		cp["snapshot"]["sections"]["entities"][&"hero"][&"inventory"]["items"].clear()
		check(ask(&"InventoryGetRequested", {"entity":&"hero"})["data"]["items"].has(&"victory_item"), "returned checkpoint detached")
	var deny_snapshot := func(e): e["errors"].append("blocked test")
	bus.subscribe(&"SnapshotCollectRequested", deny_snapshot)
	check(not ask(&"VictoryCheckpointPrepareRequested", {"entity":&"hero", "object":oid}).get("accepted", true), "snapshot lock rejects preparation")
	bus.unsubscribe(&"SnapshotCollectRequested", deny_snapshot)
	check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.1}).get("accepted", false), "start action")
	check(not ask(&"VictoryCheckpointPrepareRequested", {"entity":&"hero", "object":oid}).get("accepted", true), "busy actor cannot prepare")
	driver.advance_steps(10)
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":true})
	check(not ask(&"VictoryCheckpointPrepareRequested", {"entity":&"hero", "object":oid}).get("accepted", true), "combat blocked in snapshot")
	check(not ask(&"DungeonPortalAvailabilityRequested", {"entity":&"hero"}).get("rule_allowed", true), "combat condition undecided")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":false})
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "portal save load")
	var file := FileAccess.open("user://session.save", FileAccess.READ)
	var snapshot: Dictionary = bytes_to_var(file.get_buffer(file.get_length()))
	file.close()
	var invalid: Dictionary = snapshot["sections"].duplicate(true)
	invalid["dungeon_portal"]["object"] = &"missing_portal"
	check(not ask(&"DungeonPortalSnapshotValidateRequested", {"sections":invalid}).get("valid", false), "reject incorrect portal reference")
	check(ask(&"DungeonPortalGetRequested", {})["data"]["object"] == oid, "same portal restored")
	check(ask(&"ObjectRemoveRequested", {"object":oid}).get("accepted", false), "remove portal")
	check(ask(&"DungeonPortalGetRequested", {})["data"]["status"] == "failed", "removed portal marks failure")
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":p}).get("accepted", false), "clear entrance before retry")
	var block_entry := func(e): e["fits"] = false
	bus = root.get_node("EventBus")
	bus.subscribe(&"SpaceBodyFitsRequested", block_entry)
	check(not ask(&"DungeonPortalPlacementRetryRequested", {}).get("accepted", true), "blocked entrance prevents placement")
	bus.unsubscribe(&"SpaceBodyFitsRequested", block_entry)
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and ask(&"DungeonPortalGetRequested", {})["data"]["status"] == "failed", "failed placement persists")
	check(ask(&"DungeonPortalPlacementRetryRequested", {}).get("accepted", false), "retry placement")
	check(not ask(&"ObjectCreateRequested", {"entity":&"fake_portal", "type":"portal_exit", "room":result["child"], "tile":tile}).get("accepted", true), "arbitrary portal rejected")
	print("Victory checkpoint tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
