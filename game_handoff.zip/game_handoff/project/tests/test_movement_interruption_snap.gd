extends SceneTree
var failures := 0
var interruptions: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func anchor() -> Vector2i:
	return ask(&"SpaceBodyGetRequested", {"entity":&"hero"})["data"]["anchor"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	root.get_node("EventBus").subscribe(&"MovementInterrupted",func(e): interruptions.append(e.duplicate(true)))
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false),"entity")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(14,14)}).get("accepted",false),"map")
	var tiles: Array = []
	for x in range(14):
		for y in range(14): tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":tiles,"kind":1}).get("accepted",false),"floor")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(2,2),"size":2}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"MovementConfigureRequested", {"entity":&"hero","base_hundredths":20,"K_move":50}).get("accepted",false),"configure")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.RIGHT}).get("accepted",false) and driver.advance_steps(9) == 9 and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false),"before midpoint")
	check(anchor() == Vector2i(2,2) and is_equal_approx(interruptions[-1]["progress"],0.45),"nearest original")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.RIGHT}).get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false),"at midpoint")
	check(anchor() == Vector2i(3,2) and interruptions[-1]["anchor"] == Vector2i(3,2),"tie goes to target")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.RIGHT}).get("accepted",false) and driver.advance_steps(11) == 11,"after midpoint")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and anchor() == Vector2i(4,2),"nearest target")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and anchor() == Vector2i(4,2),"restore midstep then snap")
	check(ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted",false),"blocker")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.RIGHT}).get("accepted",false) and driver.advance_steps(11) == 11,"blocked target step")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker","anchor":Vector2i(6,2),"size":2}).get("accepted",false),"place blocker")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and anchor() == Vector2i(4,2),"blocked target returns reserved origin")
	check(ask(&"SpaceBodyRemoveRequested", {"entity":&"blocker"}).get("accepted",false),"remove blocker")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i(1,1)}).get("accepted",false) and driver.advance_steps(15) == 15,"diagonal step")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker","anchor":Vector2i(6,4),"size":2}).get("accepted",false),"block diagonal target")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and anchor() == Vector2i(5,2),"choose closer free diagonal corner")
	check(ask(&"SpaceBodyRemoveRequested", {"entity":&"blocker"}).get("accepted",false),"clear diagonal blocker")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i(-1,1)}).get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and anchor() == Vector2i(4,3),"diagonal tie selects target")
	print("Movement interruption snap tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
