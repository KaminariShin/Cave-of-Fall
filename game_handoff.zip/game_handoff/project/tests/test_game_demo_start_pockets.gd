extends SceneTree
var failures:=0
func _initialize() -> void: call_deferred("run")
func check(v:bool,s:String)->void:
	if not v: failures+=1;printerr("FAIL: ",s)
func run()->void:
	var bus=root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized,"demo starts")
	var e={"id":&"start"};bus.publish(&"RoomGetRequested",e)
	var room:Dictionary=e["data"]
	var origin:Vector2i=room["origin_cell"];var size:Vector2i=room["size_cells"]
	var base={"id":&"start","type":"start","origin":origin,"size":size,"seed":42,"entry_dir":""};bus.publish(&"CaveGeometryBuildRequested",base)
	var cells:Dictionary={};for p in base["cells"]: cells[p]=true
	var floor:Dictionary={};for p in room["floor_tiles"]: floor[p]=true
	var count:=0
	for x in range(1,size.x-1):
		for y in range(1,size.y-1):
			var c:=Vector2i(x,y)
			if cells.has(c):continue
			var n:=0
			for dx in range(4):
				for dy in range(4):
					if floor.has((origin+c)*4+Vector2i(dx,dy)):n+=1
			if n>0 and n<=10:count+=1
	check(count>0,"actual demo retains pockets in wall cells after tutorial setup")
	print("Actual demo start pockets: ",count)
	game.queue_free();await process_frame
	print("Demo start pockets: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
