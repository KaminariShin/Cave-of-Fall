extends SceneTree
var failures := 0
var decisions: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func hp(id: StringName) -> float:
	return ask(&"ResourceGetRequested", {"entity":id,"resource":&"HP"})["data"]["current"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	root.get_node("EventBus").subscribe(&"AIDecision",func(e): decisions.append(e.duplicate(true)))
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false) and ask(&"RoomCreateRequested", {"id":&"A","type":"start","origin_cell":Vector2i(1,1),"size_cells":Vector2i(11,11)}).get("accepted",false),"map room")
	check(root.get_node("EntityRegistry").create_entity(&"hero",{&"stats":{"CON":100,"PER":30}}),"hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(22,22),"size":2}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"RoomEnterRequested", {"entity":&"hero","room":&"A"}).get("accepted",false),"player enters")
	for row in [[&"small",Vector2i(17,22),2],[&"large",Vector2i(22,8),6]]:
		var actor: StringName = row[0]
		var sword := StringName(str(actor)+"_sword")
		check(root.get_node("EntityRegistry").create_entity(actor,{&"stats":{"PER":30}}),"actor")
		check(ask(&"SpaceBodyPlaceRequested", {"entity":actor,"anchor":row[1],"size":row[2]}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":actor,"volume":100}).get("accepted",false),"body inventory")
		check(ask(&"ItemCreateRequested", {"id":sword,"base_id":&"sword_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":actor,"item":sword}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":actor,"item":sword,"slot":"main"}).get("accepted",false),"equip request")
	check(driver.wait_for(0.1) and driver.advance_steps(10) == 10,"equip actions")
	for actor in [&"small",&"large"]:
		var sword := StringName(str(actor)+"_sword")
		var invalid := {"entity":actor,"room":&"A","role":"melee","target":&"hero","wait_duration":0.05,"weapon":{"item":sword,"strike":"missing"},"movement":{"actor_type":"goblin"}}
		check(not ask(&"AIRegisterRequested",invalid).get("accepted",true),"unknown strike rejected")
		var register := {"entity":actor,"room":&"A","role":"melee","target":&"hero","detected":false,"wait_duration":0.05,"weapon":{"item":sword,"strike":"sword_simple_thrust"},"movement":{"actor_type":"goblin"}}
		check(ask(&"AIRegisterRequested",register).get("accepted",false) and ask(&"DetectionHostilitySetRequested", {"a":actor,"b":&"hero","hostile":true}).get("accepted",false),"register and hostility")
	var original := hp(&"hero")
	check(driver.wait_for(2.0) and driver.advance_steps(5) == 5,"start simulation")
	for actor in [&"small",&"large"]: check(ask(&"AIGetRequested", {"entity":actor})["data"]["detected"],"detection " + str(actor))
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save active AI")
	check(driver.advance_steps(100) == 100 and hp(&"hero") < original,"AI lands automatic attack")
	var saw_attack := {}
	var saw_approach := false
	for d in decisions:
		if d["decision"] == "weapon_strike": saw_attack[d["entity"]] = true
		if d["entity"] == &"large" and d["decision"] == "approach": saw_approach = true
	check(saw_attack.has(&"small") and saw_attack.has(&"large") and saw_approach,"same behavior for two body sizes and approach")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore AI")
	check(driver.advance_steps(100) == 100 and hp(&"hero") < original,"loaded AI attacks")
	var ongoing := ask(&"ActionGetRequested", {"entity":&"small"})
	if ongoing.get("found",false): check(ask(&"ActionCancelRequested", {"entity":&"small"}).get("accepted",false),"cancel action")
	check(ask(&"ResourceSetRequested", {"entity":&"small","resource":&"Stamina","value":0}).get("accepted",false) and driver.advance_steps(1) == 1,"empty stamina")
	check(ask(&"ActionGetRequested", {"entity":&"small"})["data"]["id"] == &"wait", "in range but exhausted waits")
	check(ask(&"DetectionHostilitySetRequested", {"a":&"small","b":&"hero","hostile":false}).get("accepted",false) and driver.advance_steps(1) == 1 and not ask(&"AIGetRequested", {"entity":&"small"})["data"]["detected"],"hostility loss updates target")
	print("General melee AI tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
