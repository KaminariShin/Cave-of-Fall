extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false) and ask(&"RoomCreateRequested", {"id":&"room","type":"start","origin_cell":Vector2i(1,1),"size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest","type":"chest","room":&"room","tile":Vector2i(14,11),"inventory_capacity":20}).get("accepted",false), "chest")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":20}).get("accepted",false), "hero inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"RoomEnterRequested", {"entity":&"hero","room":&"room"}).get("accepted",false), "hero location")
	for name in [&"CON",&"STR",&"DEX",&"INT",&"WIS",&"PER"]: check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":name,"value":10}).get("accepted",false), "stats")
	var state := {"count":0}
	var rng := func(e):
		state["count"] += 1
		if state["count"] in [3,7,11,15]: e["value"] = 12
		elif state["count"] in [5,9,13,17]: e["value"] = 700
		else: e["value"] = e["min"]
	bus.subscribe(&"RngIntRequested",rng)
	var draft := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest","kind":"boss","depth":0})
	bus.unsubscribe(&"RngIntRequested",rng)
	check(draft.get("accepted",false), "magic armor plan")
	if not draft.get("accepted",false): quit(1); return
	var slots: Array = draft["draft"]["slots"]
	var ids: Array = []
	for m in slots[0]["mods"]: ids.append(m["id"])
	check(slots[0]["base_id"] == &"armor_cloth_body" and slots[0]["rarity"] == &"magic" and ids == [&"pre_vital",&"pre_agile",&"suf_perception",&"suf_wisdom",&"affix_hp",&"affix_stamina"], "fixed selected mods " + str(ids))
	var readiness := ask(&"ChestDraftReadinessRequested", {"object":&"chest"})
	check(readiness.get("accepted",false) and readiness.get("unsupported_mod_ids",[1]).is_empty() and not readiness.get("plain_supported",true), "all effects implemented, old materializer still rejects")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	check(ask(&"ChestDraftMaterializeRequested", {"object":&"chest","item_ids":[&"a",&"b",&"c",&"d"]}).get("accepted",false) and before["payload"]["sections"]["rng"] == saver.collect_world_transition_snapshot()["payload"]["sections"]["rng"], "materialize without reroll")
	check(ask(&"ObjectInteractRequested", {"entity":&"hero","object":&"chest"}).get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"ChestTakeRequested", {"entity":&"hero","object":&"chest","item":&"a"}).get("accepted",false) and driver.advance_steps(10) == 10, "open and take")
	check(ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"a"}).get("accepted",false) and driver.advance_steps(100) == 100, "identify")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"a","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10, "equip actual magic armor")
	for expected in [[&"CON",11.0],[&"DEX",11.0],[&"PER",11.0],[&"WIS",11.0]]:
		check(float(ask(&"StatGetRequested", {"entity":&"hero","stat":expected[0]}).get("value",NAN)) == expected[1], "live stat %s" % expected[0])
	for expected in [[&"HP",101.0],[&"Stamina",122.0],[&"MP",55.0]]:
		check(float(ask(&"ResourceGetRequested", {"entity":&"hero","resource":expected[0]})["data"]["max"]) == expected[1], "resource %s" % expected[0])
	check(ask(&"DetectionStateGetRequested", {"observer":&"hero"}).get("radius",NAN) == 11.0, "actual detection radius")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["max"] == 101.0, "save/load full equipment")
	print("Usable magic armor tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
