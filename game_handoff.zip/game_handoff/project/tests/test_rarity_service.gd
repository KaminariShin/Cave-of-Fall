extends SceneTree
var failures := 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func create(bus, id: StringName, rarity: StringName, set_id = null) -> Dictionary:
	return ask(bus, &"ItemCreateRequested", {"id": id, "base_id": &"base", "item_level": 17, "rarity": rarity, "set_id": set_id})
func info(bus, id: StringName) -> Dictionary:
	return ask(bus, &"ItemRarityGetRequested", {"item": id})
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"MaterialRegisterRequested", {"material": {"id": "mat", "name": "M", "weight_per_unit": 1, "volume_per_unit": 1, "level": 100}})["accepted"], "material")
	check(ask(bus, &"ItemBaseRegisterRequested", {"base": {"id": "base", "name": "B", "materials": [{"material_id": "mat", "count": 1}]}})["accepted"], "base")
	for category in ["prefix", "suffix", "affix"]:
		var def := {"id": category, "category": category, "stat": "STR", "tiers": [{"tier": 1, "value": 1, "level_req": 0, "weight": 1}]}
		check(ask(bus, &"ModDefinitionRegisterRequested", {"definition": def})["accepted"], "mod definition")
	for category in ["prefix", "affix"]:
		for n in [2, 3]:
			check(ask(bus, &"ModDefinitionRegisterRequested", {"definition":{"id":category + str(n), "category":category, "stat":"STR", "tiers":[{"tier":1, "value":1, "level_req":0, "weight":1}]}})["accepted"], "additional mod definition")
	check(create(bus, &"normal", &"normal")["accepted"], "normal")
	check(not create(bus, &"normal_set", &"normal", &"set_a")["accepted"], "normal forbids set")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"normal", "mod_id": &"prefix"})["accepted"], "normal forbids mods")
	check(ask(bus, &"RarityValidateRequested", {"item": &"normal"})["complete"], "normal complete")
	check(create(bus, &"magic", &"magic")["accepted"], "magic")
	check(ask(bus, &"RarityValidateRequested", {"item": &"magic"})["complete"], "missing affixes are allowed")
	for i in range(2):
		check(ask(bus, &"ModRollApplyRequested", {"item": &"magic", "mod_id": StringName("prefix" if i == 0 else "prefix2")})["accepted"], "magic prefix capacity")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"magic", "mod_id": &"prefix3"})["accepted"], "magic prefix limit")
	for i in range(2):
		check(ask(bus, &"ModRollApplyRequested", {"item": &"magic", "mod_id": StringName("affix" if i == 0 else "affix2")})["accepted"], "magic affix capacity")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"magic", "mod_id": &"affix3"})["accepted"], "max two affixes")
	check(ask(bus, &"RarityValidateRequested", {"item": &"magic"})["complete"], "valid magic")
	var int_req := ask(bus, &"IdentificationRequirementGetRequested", {"item": &"magic"})
	check(int_req["found"] and is_equal_approx(int_req["value"], 7.0), "INT requirement rounded up")
	check(create(bus, &"rare", &"rare")["accepted"] and info(bus, &"rare")["data"]["limits"]["prefix"] == 3, "rare optional set and three prefix max")
	check(create(bus, &"unique", &"unique")["accepted"], "unique optional set")
	var unique: Dictionary = info(bus, &"unique")["data"]
	var limits: Dictionary = unique["limits"]
	check((limits["prefix"] == 4 and limits["suffix"] == 3) or (limits["prefix"] == 3 and limits["suffix"] == 4), "one random extra slot")
	check(create(bus, &"artifact_bad", &"artifact")["accepted"], "artifact without set allowed")
	check(not info(bus, &"artifact_bad")["data"]["key_set_item"], "unbound artifact not a set key")
	check(create(bus, &"artifact", &"artifact", &"set_a")["accepted"], "artifact with set")
	var artifact: Dictionary = info(bus, &"artifact")["data"]
	check(artifact["limits"]["prefix"] == 5 and artifact["limits"]["suffix"] == 5 and artifact["key_set_item"], "artifact extra slots and key")
	var before = unique["extra_category"]
	var saved := ask(bus, &"SessionSaveRequested", {})
	check(saved.get("accepted", false), "save rarity: " + str(saved))
	var loaded := ask(bus, &"SessionLoadRequested", {})
	check(loaded.get("accepted", false) and info(bus, &"unique")["data"]["extra_category"] == before, "save restores unique slot")
	print("Rarity tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
