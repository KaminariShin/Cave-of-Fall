extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void: call_deferred("run")
func check(v:bool,label:String)->void:
	if not v: failures+=1; printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary: bus.publish(id,e); return e
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver"); driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate(); root.add_child(game); await process_frame
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(ask(&"ItemCreateRequested",{"id":&"enemy_bow_test","base_id":&"bow_simple","item_level":1}).get("accepted",false) and ask(&"ComponentSetRequested",{"entity":game.RAT,"component":&"equipment","data":{"main":&"enemy_bow_test"}}).get("accepted",false),"equip test bow")
	var shot:=ask(&"BowShotStartRequested",{"entity":game.RAT,"item":&"enemy_bow_test","direction":Vector2.LEFT})
	check(shot.get("accepted",false),"enemy aims")
	if not shot.get("accepted",false): quit(1); return
	var visible := {}
	for tile in ask(&"FogStateGetRequested",{}).get("visible_tiles",[]): visible[tile]=true
	check(not game._enemy_windup_tiles(game.RAT,visible).is_empty(),"visible enemy bow projects yellow line")
	check(game._enemy_windup_tiles(game.RAT,{})==[],"hidden enemy does not expose line")
	var mid:int=ceili(float(shot["data"]["duration_steps"])/2.0)
	check(driver.wait_for(2.0) and driver.advance_steps(mid)==mid,"release")
	check(game._strike_flashes.has(game.RAT),"visible enemy release shows red flash")
	game.queue_free(); await process_frame
	print("Enemy bow telegraph: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
