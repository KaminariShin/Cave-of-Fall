extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(v:bool,s:String)->void:
	if not v:failures+=1;printerr("FAIL: ",s)
func run()->void:
	var service=root.get_node("RoomService")
	var size:=Vector2i(9,9)
	var cell:=Vector2i(4,4)
	for direction in [Vector2i(-1,-1),Vector2i(1,-1),Vector2i(1,1),Vector2i(-1,1)]:
		var logical:Dictionary={cell+direction:true}
		var existing:Array=[]
		var adjacent_tile:=cell*4+Vector2i(-1 if direction.x<0 else 4,0 if direction.y<0 else 3)
		existing.append(adjacent_tile)
		var rounded:Array=service._round_diagonal_corners(logical,size,Vector2i.ZERO,existing)
		var chosen:Array=[]
		for p in rounded:
			if p.x>=cell.x*4 and p.x<cell.x*4+4 and p.y>=cell.y*4 and p.y<cell.y*4+4:chosen.append(p)
		check(chosen.size()==6,"six-cell corner "+str(direction))
		for p in chosen:
			var local:Vector2i=p-cell*4
			var dx:int=local.x if direction.x<0 else 3-local.x
			var dy:int=local.y if direction.y<0 else 3-local.y
			check(dx+dy<=2,"triangular shape, 1-cell steps and intact distant edges")
		check(service._round_diagonal_corners(logical,size,Vector2i.ZERO,[]).is_empty(),"no disconnected corner")
		var ambig:Dictionary={cell+direction:true,cell-direction:true}
		var result:Array=service._round_diagonal_corners(ambig,size,Vector2i.ZERO,existing)
		for p in result:check(not (p.x>=16 and p.x<20 and p.y>=16 and p.y<20),"no bridge between diagonal floors")
	print("Rounded cave corners: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
