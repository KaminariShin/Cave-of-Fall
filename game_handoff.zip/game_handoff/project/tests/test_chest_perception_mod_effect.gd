extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func per(actor: StringName) -> float:
	var q := ask(&"StatGetRequested", {"entity":actor, "stat":&"PER"})
	return float(q.get("value",NAN)) if q.get("found",false) else NAN
func radius(actor: StringName) -> float:
	return float(ask(&"DetectionStateGetRequested", {"observer":actor}).get("radius",NAN))
func state(id: StringName) -> Dictionary:
	return ask(&"ItemGetRequested", {"item":id})["item_data"]["learning_state"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc", "volume":10}).get("accepted",false), "control and inventory")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"PER", "value":10}).get("accepted",false) and ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"INT", "value":10}).get("accepted",false), "stats")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	var mod := {"id":&"suf_perception", "category":"suffix", "stat":"PER", "tier":3, "value":1.0, "level_req":1, "material_id":&"leather_thin", "unlock_after":5}
	check(ask(&"ItemCreateRequested", {"id":&"shield", "base_id":&"shield_small", "item_level":1, "rarity":&"magic", "learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"shield", "mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"shield"}).get("accepted",false), "shield with perception")
	var changes: Array = []
	var observer := func(e):
		if e.get("entity") == &"hero" and e.get("stat") == &"PER": changes.append([e["old"],e["new"]])
	bus.subscribe(&"StatChanged",observer)
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"shield", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and per(&"hero") == 10.0 and radius(&"hero") == 10.0 and state(&"shield")["progress"] == 0, "high INT does not reveal mod")
	for i in range(5):
		check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.01}).get("accepted",false) and driver.advance_steps(1) == 1, "wait %d" % i)
	check(state(&"shield")["progress"] == 5 and per(&"hero") == 11.0 and radius(&"hero") == 11.0 and changes.has([10.0,11.0]), "reveal updates actual stat and detection")
	check(ask(&"PipelineModifierRegisterRequested", {"entity":&"hero", "modifier":{"id":"double_per", "target":"stat.PER", "stage":"multiplicative", "op":"multiply", "value":2.0}}).get("accepted",false) and per(&"hero") == 22.0 and radius(&"hero") == 22.0, "bonus participates in additive stage")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and per(&"hero") == 22.0 and radius(&"hero") == 22.0, "save/load")
	var corrupt := func(e):
		if e.get("item",null) == &"shield" and e.get("found",false): e["item_data"]["mods"][0]["value"] = 999
	bus.subscribe(&"ItemGetRequested",corrupt)
	check(not ask(&"StatGetRequested", {"entity":&"hero", "stat":&"PER"}).get("found",true), "invalid mod rejects stat query")
	bus.unsubscribe(&"ItemGetRequested",corrupt)
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and per(&"hero") == 20.0 and radius(&"hero") == 20.0 and changes.has([22.0,20.0]), "unequip updates stat and detection")
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero", "item":&"shield"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc", "item":&"shield"}).get("accepted",false), "transfer")
	var p: int = state(&"shield")["progress"]
	var npc_base := per(&"npc")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc", "item":&"shield", "slot":"off"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.1}).get("accepted",false) and driver.advance_steps(10) == 10 and per(&"npc") == npc_base + 1 and radius(&"npc") == npc_base + 1 and state(&"shield")["progress"] == p and not state(&"shield")["identified"], "NPC effect without changing global knowledge")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"npc", "slot":"off"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.1}).get("accepted",false) and driver.advance_steps(10) == 10, "npc removes revealed shield")
	check(ask(&"ItemCreateRequested", {"id":&"fresh", "base_id":&"shield_small", "item_level":1, "rarity":&"magic", "learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"fresh", "mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc", "item":&"fresh"}).get("accepted",false), "create fresh NPC shield")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc", "item":&"fresh", "slot":"off"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.1}).get("accepted",false) and driver.advance_steps(10) == 10 and state(&"fresh")["progress"] == 0 and not state(&"fresh")["identified"] and per(&"npc") == npc_base + 1 and radius(&"npc") == npc_base + 1, "NPC receives unrevealed mod")
	check(ask(&"ControlledEntityRequested", {"entity":&"npc"}).get("accepted",false) and per(&"npc") == npc_base and radius(&"npc") == npc_base and not state(&"fresh")["identified"], "control switch removes unknown bonus and updates detection")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and per(&"npc") == npc_base + 1 and radius(&"npc") == npc_base + 1, "switch back restores NPC bonus")
	check(ask(&"ItemCreateRequested", {"id":&"blank", "base_id":&"shield_small", "item_level":1, "rarity":&"magic", "learning":schema}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"blank"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"blank", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "equip blank")
	check(not ask(&"ItemModAttachRequested", {"item":&"blank", "mod":mod}).get("accepted",true), "cannot attach perception to equipped item without refresh")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"ItemModAttachRequested", {"item":&"blank", "mod":mod}).get("accepted",false), "attach when unequipped")
	check(ask(&"ItemLearningIdentifyRequested", {"entity":&"hero", "item":&"blank"}).get("accepted",false) and driver.advance_steps(100) == 100 and state(&"blank")["progress"] < 5 and state(&"blank")["identified"], "identify before reveal")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"blank", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and per(&"hero") == 22.0 and radius(&"hero") == 22.0, "identified item activates perception immediately")
	var weapon_schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"sword_simple",bases)
	check(ask(&"ItemCreateRequested", {"id":&"weapon", "base_id":&"sword_simple", "item_level":1, "rarity":&"magic", "learning":weapon_schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"weapon", "mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"weapon"}).get("accepted",false), "weapon perception")
	check(ask(&"ItemLearningIdentifyRequested", {"entity":&"hero", "item":&"weapon"}).get("accepted",false) and driver.advance_steps(100) == 100 and ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"weapon", "slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10 and per(&"hero") == 24.0 and radius(&"hero") == 24.0, "identified weapon bonus stacks with shield")
	bus.unsubscribe(&"StatChanged",observer)
	print("Chest perception mod effect tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
