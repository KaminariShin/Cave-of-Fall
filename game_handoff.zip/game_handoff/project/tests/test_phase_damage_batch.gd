extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func hp(id: StringName) -> float: return float(ask(&"ResourceGetRequested", {"entity":id,"resource":&"HP"})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":id,"resource":&"HP","value":3}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"ActionDefinitionRegisterRequested", {"data":{"id":&"phase_strike_test","name":"test","type":&"physical","base_duration":0.03,"phase_completion":true}}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"hero","action":&"phase_strike_test"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"phase_strike_test"}).get("accepted",false),"actions")
	check(not ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{},"hits":[],"phase_commit":true}).get("accepted",true),"outside phase rejected")
	var got := {"success":false,"second":true,"before_phase":true,"snapshot_blocked":false,"deaths":0,"atomic":true,"due":0,"invalid_tried":false,"invalid_rejected":false,"retry_blocked":false}
	var death := func(e):
		if e.get("entity",null) in [&"hero",&"npc"]:
			got["deaths"] += 1
			got["atomic"] = got["atomic"] and hp(&"hero") == 0 and hp(&"npc") == 0 and root.get_node("CombatService").is_entity_dead(&"hero") and root.get_node("CombatService").is_entity_dead(&"npc")
	var tick := func(_e):
		got["before_phase"] = got["before_phase"] and not ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{},"hits":[],"phase_commit":true}).get("accepted",true)
	var phase := func(e):
		if not got["invalid_tried"] and e.get("actions",[]).is_empty():
			got["invalid_tried"] = true
			got["invalid_rejected"] = not ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{},"hits":[],"phase_commit":true,"apply_stagger":"invalid"}).get("accepted",true)
			got["retry_blocked"] = not ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{},"hits":[],"phase_commit":true}).get("accepted",true)
		if e.get("actions",[]).size() == 2:
			got["due"] = 2
			var batch := {"hp_by_target":{&"hero":3,&"npc":3},"hits":[{"source":&"hero","target":&"npc","damage":3},{"source":&"npc","target":&"hero","damage":3}],"phase_commit":true}
			var r := ask(&"SimultaneousDamageApplyRequested",batch)
			got["success"] = r.get("accepted",false)
			got["second"] = ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{},"hits":[],"phase_commit":true}).get("accepted",true)
			got["snapshot_blocked"] = not root.get_node("SaveService").collect_world_transition_snapshot().get("valid",true)
	bus.subscribe(&"Tick",tick); bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"EntityDied",death)
	check(driver.advance_steps(3) == 3 and got["due"] == 2 and got["success"] and not got["second"] and got["before_phase"] and got["snapshot_blocked"] and got["deaths"] == 2 and got["atomic"] and got["invalid_rejected"] and got["retry_blocked"],"one phase packet commits mutual death atomically")
	bus.unsubscribe(&"Tick",tick); bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"EntityDied",death)
	print("Phase damage batch tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
