extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(bus, id: StringName, data: Dictionary) -> Dictionary:
	bus.publish(id, data)
	return data
func run() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(root.get_node("EntityRegistry").create_entity(&"hero", {&"stats":{"DEX":15, "INT":25, "PER":5}}), "hero")
	check(ask(bus, &"WeaponTagRegisterRequested", {"definition":{"id":"fixture_heavy", "min_time_bonus":0.2}})["accepted"], "tag1")
	check(ask(bus, &"WeaponTagRegisterRequested", {"definition":{"id":"two", "min_time_bonus":0.1}})["accepted"], "tag2")
	check(ask(bus, &"WeaponVariantRegisterRequested", {"definition":{"id":"sword", "type":"sword", "tags":[]}})["accepted"], "variant")
	check(ask(bus, &"WeaponVariantRegisterRequested", {"definition":{"id":"great", "type":"sword", "tags":["fixture_heavy", "two"], "base_attack_time":1.4}})["accepted"], "great")
	var q := {"entity":&"hero", "variant":"sword", "kind":"physical", "speed_effectiveness":1.0}
	var r := ask(bus, &"WeaponAttackTimingRequested", q.duplicate())
	check(r["accepted"] and is_equal_approx(r["data"]["raw_duration"], 1.0/1.2) and is_equal_approx(r["data"]["duration"],0.84), "physical and rounding")
	check(ask(bus, &"PipelineModifierRegisterRequested", {"entity":&"hero", "modifier":{"id":"slow", "target":"action.duration", "stage":"additive", "op":"add", "value":0.1}})["accepted"], "pipeline register")
	r = ask(bus, &"WeaponAttackTimingRequested", q.duplicate())
	check(r["accepted"] and is_equal_approx(r["data"]["modified_duration"], 1.0/1.2 + 0.1) and is_equal_approx(r["data"]["duration"],0.94), "pipeline applied")
	check(ask(bus, &"PipelineModifierRemoveRequested", {"entity":&"hero", "id":"slow"})["accepted"], "pipeline remove")
	q["kind"] = "magical"
	r = ask(bus, &"WeaponAttackTimingRequested", q.duplicate())
	check(r["accepted"] and is_equal_approx(r["data"]["raw_duration"], 1.0/1.4), "magical")
	q["kind"] = "combined"
	r = ask(bus, &"WeaponAttackTimingRequested", q.duplicate())
	check(r["accepted"] and is_equal_approx(r["data"]["stat"],20) and is_equal_approx(r["data"]["raw_duration"], 1.0/1.3), "average")
	ask(bus, &"StatBaseSetRequested", {"entity":&"hero", "stat":&"PER", "value":100})
	check(is_equal_approx(ask(bus, &"WeaponAttackTimingRequested", q.duplicate())["data"]["raw_duration"], 1.0/1.3), "PER ignored")
	q["variant"] = "great"
	q["speed_effectiveness"] = 5.0
	r = ask(bus, &"WeaponAttackTimingRequested", q.duplicate())
	check(r["accepted"] and is_equal_approx(r["data"]["floor"], 0.98) and is_equal_approx(r["data"]["duration"], 0.98), "floor great sword")
	q["speed_effectiveness"] = 0
	check(not ask(bus, &"WeaponAttackTimingRequested", q.duplicate())["accepted"], "zero effectiveness")
	q["speed_effectiveness"] = 1.0
	ask(bus, &"StatBaseSetRequested", {"entity":&"hero", "stat":&"DEX", "value":-100})
	q["kind"] = "physical"
	check(not ask(bus, &"WeaponAttackTimingRequested", q.duplicate())["accepted"], "nonpositive denominator")
	print("Weapon timing tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
