extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok: failures+=1;printerr("FAIL: ",label)
func run()->void:
	root.get_node("TimeDriver").set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized,"game initialized")
	for spec in [["mine_floor_wallmatched_8px_preview.png","_floor_atlas"],["mine_wall_8px_grid_preview.png","_wall_atlas"]]:
		var raw:=FileAccess.get_file_as_bytes("res://assets/"+spec[0]);var image:=Image.new()
		check(image.load_png_from_buffer(raw)==OK,"load provided preview")
		var atlas:Image=game.get(spec[1]).get_image()
		var ok:=true
		for y in range(128):
			for x in range(128):
				var pixel:=image.get_pixel(x*4+2,y*4+2)
				if pixel.a>=0.999 and atlas.get_pixel(x,y)!=pixel: ok=false
		check(ok,"atlas follows preview pixel centers, "+spec[0])
	for floor_index in range(4):
		for is_floor in [true,false]:
			var chosen:={}
			for y in range(32):
				for x in range(32):
					var tile:=Vector2i(x+50,y+50)
					var src:Rect2=game._art_tile_source(tile,floor_index,is_floor)
					check(src==game._art_tile_source(tile,floor_index,is_floor),"stable per-tile result")
					check(src.size==Vector2(8,8) and int(src.position.x)%8==0 and int(src.position.y)%8==0 and src.position.x>=0 and src.position.y>=0 and src.end.x<=128 and src.end.y<=128,"one whole 8px fragment")
					chosen[src.position]=true
			check(chosen.size()>200,"varied fragments on floor %d" % floor_index)
	check(game._art_tile_source(Vector2i(20,30),0,true)!=game._art_tile_source(Vector2i(20,30),1,true),"floor variation")
	var bounds:Dictionary=game._ask(&"SpaceBodyGetRequested",{"entity":game.HERO})
	check(bounds["data"]["size"]==4,"physical dimensions unchanged")
	for height in [500,600,660,719,720,900]:
		game.size=Vector2(1280,height)
		var frame:Rect2=game._frame_rect()
		var map:Rect2=game._map_rect()
		var help_box:Rect2=game._ui_rect(Rect2(20,101,196,48))
		for pair in [[game._inventory_button_rect(),game._stats_button_rect()],[game._drop_cancel_rect(),game._drop_confirm_rect()]]:
			check(not pair[0].intersects(pair[1]),"buttons separate")
			for btn in pair:
				check(frame.encloses(btn) and not btn.intersects(help_box) and not btn.intersects(map),"buttons stay in frame and clear controls at %d" % height)
		check(frame.encloses(map),"map stays within frame")
		check(absf(frame.size.x/frame.size.y-1365.0/768.0)<0.001,"frame proportions preserved")
		check(game._map_contains(map.get_center()),"window center clickable")
		check(not game._map_contains(game._ui_point(Vector2(247,161))),"decorative corner is not clickable map")
	game._drop_pick={}
	game.queue_free();await process_frame
	print("Physical tile mixing and sidebar layout: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
