extends SceneTree

var bus: Node
var game: Node
var driver: Node
var run_seed := 42
var run_started_msec := 0
var failures := 0
var generation_failures: Array = []
var player_damage_events: Array = []
var player_death_events: Array = []
var player_block_events: Array = []
var player_phase_events: Array = []
var player_consumable_events: Array = []
var player_interrupt_events: Array = []
var outgoing_damage_events: Array = []
var combat_move_debug_count := 0
const MAX_STAGNANT_COMBAT_TURNS := 25
var combat_agent_active := false
var collecting_loot := false
# Full one-second action helper; combat uses a shorter polling interval below.
const ACTION_TICKS := 100
const COMBAT_POLL_TICKS := 20
const SAFE_REST_TICKS := 500
const MAX_SAFE_REST_CYCLES := 60
const MAX_ROOM_GENERATIONS := 130
const MAX_COMBAT_TURNS := 120

func _initialize() -> void:
	call_deferred("run")

func ask(id: StringName, event: Dictionary) -> Dictionary:
	bus.publish(id, event)
	return event

func check(value: bool, label: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL [seed %d]: %s" % [run_seed, label])

func body_anchor(entity: StringName = &"") -> Vector2i:
	var id: StringName = game.HERO if entity == &"" else entity
	return ask(&"SpaceBodyGetRequested", {"entity":id}).get("data", {}).get("anchor", Vector2i(-1,-1))

func room_data(room: StringName) -> Dictionary:
	return ask(&"RoomGetRequested", {"id":room}).get("data", {})

func room_bounds(room: StringName) -> Dictionary:
	var info := room_data(room)
	if info.is_empty(): return {}
	return {"origin":info["origin_cell"] * 4, "size":info["size_cells"] * 4}

func living_hostiles_in_room(room: StringName) -> Array:
	var status := ask(&"RoomSpawnStatusRequested",{"room":room})
	var result: Array = []
	for id in status.get("data",{}).get("placed",[]):
		if not id is StringName: continue
		if not ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false): continue
		if ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":id}).get("hostile",false): result.append(id)
	return result

func body_fits(anchor: Vector2i, bounds: Dictionary) -> bool:
	return ask(&"SpaceBodyFitsRequested", {"anchor":anchor,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false)

func path_snapshot(room: StringName) -> Dictionary:
	var bounds := room_bounds(room)
	if bounds.is_empty(): return {}
	var region := ask(&"SpaceRegionGetRequested",{"origin":bounds["origin"],"size":bounds["size"]})
	if not region.get("accepted",false): return {}
	var obstacles: Dictionary = ask(&"SpaceObstaclesGetRequested",{}).get("obstacles",{})
	var bodies: Dictionary = ask(&"SpaceBodiesGetRequested",{}).get("bodies",{})
	var occupied: Dictionary = {}
	for entity in bodies:
		if entity == game.HERO: continue
		var body: Dictionary = bodies[entity]
		var anchor = body.get("anchor",null)
		var size = body.get("size",null)
		if not anchor is Vector2i or not size is int or size <= 0: continue
		for x in range(anchor.x,anchor.x+size):
			for y in range(anchor.y,anchor.y+size):
				occupied[Vector2i(x,y)] = entity
	return {"bounds":bounds,"floor":region.get("floor",{}),"obstacles":obstacles,"occupied":occupied}

func path_body_fits(anchor: Vector2i, snapshot: Dictionary) -> bool:
	if snapshot.is_empty(): return false
	var bounds: Dictionary = snapshot["bounds"]
	var origin: Vector2i = bounds["origin"]
	var size: Vector2i = bounds["size"]
	if anchor.x < origin.x or anchor.y < origin.y or anchor.x+4 > origin.x+size.x or anchor.y+4 > origin.y+size.y: return false
	var floors: Dictionary = snapshot["floor"]
	var obstacles: Dictionary = snapshot["obstacles"]
	var occupied: Dictionary = snapshot["occupied"]
	for x in range(anchor.x,anchor.x+4):
		for y in range(anchor.y,anchor.y+4):
			var tile := Vector2i(x,y)
			if not floors.has(tile) or obstacles.has(tile) or occupied.has(tile): return false
	return true

func body_adjacent_to_tile(anchor: Vector2i, tile: Vector2i) -> bool:
	return ((tile.x == anchor.x-1 or tile.x == anchor.x+4) and tile.y >= anchor.y and tile.y < anchor.y+4) or ((tile.y == anchor.y-1 or tile.y == anchor.y+4) and tile.x >= anchor.x and tile.x < anchor.x+4)

func find_route(room: StringName, target: Vector2i, adjacent: bool) -> Dictionary:
	var snapshot := path_snapshot(room)
	if snapshot.is_empty(): return {"found":false,"route":[]}
	var start := body_anchor()
	var is_goal := func(anchor: Vector2i) -> bool:
		return body_adjacent_to_tile(anchor,target) if adjacent else anchor == target
	if is_goal.call(start): return {"found":true,"route":[]}
	var queue: Array = [start]
	var previous: Dictionary = {start:start}
	var index := 0
	var goal := Vector2i(-1,-1)
	while index < queue.size():
		var anchor: Vector2i = queue[index]
		index += 1
		for delta in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var next: Vector2i = anchor + delta
			if previous.has(next) or not path_body_fits(next,snapshot): continue
			previous[next] = anchor
			if is_goal.call(next):
				goal = next
				break
			queue.append(next)
		if goal.x >= 0: break
	if goal.x < 0: return {"found":false,"route":[]}
	var route: Array = []
	var cursor := goal
	while cursor != start:
		var before: Vector2i = previous[cursor]
		route.push_front(cursor-before)
		cursor = before
	return {"found":true,"route":route}

func finish_pending_player_action() -> bool:
	for _attempt in range(8):
		var active := ask(&"ActionGetRequested",{"entity":game.HERO})
		if not active.get("found",false): return true
		var active_id: Variant = active.get("data",{}).get("id",null)
		if combat_agent_active and active_id in [&"move",&"consumable_use"]:
			var attacker := imminent_melee_threat(float(COMBAT_POLL_TICKS)*0.01+0.05)
			if attacker != &"":
				var cancelled := ask(&"ActionCancelRequested",{"entity":game.HERO,"reason":&"combat_defense"})
				if cancelled.get("accepted",false):
					print("COMBAT_DEFEND_INTERRUPT room=%s action=%s attacker=%s" % [game.current_room,str(active.get("data",{}).get("id",null)),attacker])
					await defend_current_threat()
					if game.is_dead: return false
					continue
		var advanced: int = driver.advance_steps(COMBAT_POLL_TICKS)
		await process_frame
		if advanced == 0 and ask(&"ActionGetRequested",{"entity":game.HERO}).get("found",false): return false
	return not ask(&"ActionGetRequested",{"entity":game.HERO}).get("found",false)

func perform_move(delta: Vector2i) -> bool:
	if game.is_dead or game.is_won: return false
	if not await finish_pending_player_action(): return false
	if not combat_agent_active:
		var ranged_enemy := nearest_bow_threat(game.current_room)
		if ranged_enemy != &"":
			print("ENGAGE_BOW room=%s enemy=%s" % [game.current_room,ranged_enemy])
			if not await fight_enemy(ranged_enemy): return false
		else:
			var visible_enemy := nearest_visible_hostile(game.current_room)
			if visible_enemy != &"":
				print("ENGAGE_MELEE room=%s enemy=%s" % [game.current_room,visible_enemy])
				if not await fight_enemy(visible_enemy): return false
	if game.is_dead: return false
	await defend_current_threat()
	if game.is_dead: return false
	if not combat_agent_active:
		if await heal_if_needed(): await defend_current_threat()
		if await restore_stamina_if_needed(): await defend_current_threat()
	if game.is_dead: return false
	var before := body_anchor()
	if not game._move(delta): return false
	if not await finish_pending_player_action(): return false
	var moved: bool = body_anchor() == before + delta and not game.is_dead
	if moved:
		await defend_current_threat()
		if game.is_dead: return false
		if await heal_if_needed(): await defend_current_threat()
		if game.is_dead: return false
	return moved

func walk_to_anchor(room: StringName, goal: Vector2i) -> bool:
	if game.current_room != room: return false
	for _retry in range(4):
		if body_anchor() == goal: return true
		var route := find_route(room,goal,false)
		if not route.get("found",false):
			if await clear_current_hostiles(room): continue
			return false
		var blocked := false
		for delta in route["route"]:
			if game.current_room != room:
				return false
			var expected: Vector2i = body_anchor() + delta
			if not await perform_move(delta):
				blocked = true
				break
			# A newly sighted enemy may pull the hero off the old route.
			if body_anchor() != expected:
				blocked = true
				break
		if body_anchor() == goal: return true
		if _retry == 2 and blocked and not await clear_current_hostiles(room): return false
	return false

func exit_anchor(exit: Dictionary) -> Vector2i:
	var anchor := Vector2i(int(exit.get("x",-1)),int(exit.get("y",-1)))
	match str(exit.get("dirOut","")):
		"west": anchor.x += 1
		"east": anchor.x -= 4
		"north": anchor.y += 1
		"south": anchor.y -= 4
		_: return Vector2i(-1,-1)
	return anchor

func exit_direction(exit: Dictionary) -> Vector2i:
	return {"north":Vector2i.UP,"east":Vector2i.RIGHT,"south":Vector2i.DOWN,"west":Vector2i.LEFT}.get(str(exit.get("dirOut","")),Vector2i.ZERO)

func exit_record(room: StringName, exit_id: StringName) -> Dictionary:
	for exit in room_data(room).get("exits",[]):
		if exit.get("id",null) == exit_id: return exit
	return {}

func walk_through_exit(room: StringName, exit_id: StringName) -> StringName:
	if game.current_room != room: return &""
	var exit := exit_record(room,exit_id)
	if exit.is_empty(): return &""
	var approach := exit_anchor(exit)
	if approach.x < 0 or not await walk_to_anchor(room,approach): return &""
	await recover_in_safe_room(room)
	if game.is_dead or game.current_room != room: return &""
	var delta := exit_direction(exit)
	if delta == Vector2i.ZERO: return &""
	for retry in range(3):
		if game.current_room != room: return game.current_room
		if body_anchor() != approach and not await walk_to_anchor(room,approach): return &""
		var before := body_anchor()
		if not await perform_move(delta):
			break
		if body_anchor() != before + delta:
			if game.current_room != room: return game.current_room
			continue
		var refreshed := exit_record(room,exit_id)
		if refreshed.get("connected",false):
			for _step in range(8):
				if game.current_room != room: return game.current_room
				before = body_anchor()
				if not await perform_move(delta): break
				if body_anchor() != before + delta: break
			if game.current_room != room: return game.current_room
		else:
			# A failed generation leaves the four-tile doorway open. Step back
			# normally before retrying; no room or body is created by the test.
			if not await perform_move(-delta): break
	return &""

func nearest_hostile_in_room(room: StringName) -> StringName:
	var hostiles := living_hostiles_in_room(room)
	return hostiles[0] if not hostiles.is_empty() else &""

func verify_no_archers(room: StringName) -> void:
	if room == &"": return
	var status := ask(&"RoomSpawnStatusRequested",{"room":room})
	for id in status.get("data",{}).get("placed",[]):
		if not id is StringName: continue
		var ai: Dictionary = ask(&"AIGetRequested",{"entity":id}).get("data",{})
		if ai.get("weapon",{}).get("strike","")=="bow_simple_shot":
			check(false,"no-archer run does not spawn bow enemy %s" % id)

func nearest_bow_threat(room: StringName) -> StringName:
	var status := ask(&"RoomSpawnStatusRequested",{"room":room})
	var projectiles: Dictionary = ask(&"ProjectilesGetRequested",{}).get("projectiles",{})
	for id in status.get("data",{}).get("placed",[]):
		if not id is StringName or not ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false): continue
		if not ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":id}).get("hostile",false): continue
		var ai: Dictionary = ask(&"AIGetRequested",{"entity":id}).get("data",{})
		if ai.get("weapon",{}).get("strike","")!="bow_simple_shot": continue
		var action := ask(&"ActionGetRequested",{"entity":id})
		var active_shot: bool = action.get("found",false) and action.get("data",{}).get("id",null)==&"bow_shot"
		var has_projectile := false
		for projectile in projectiles.values():
			if projectile.get("owner",null)==id and projectile.get("weapon_type","")=="bow": has_projectile=true; break
		if not (enemy_visible(id) or active_shot or has_projectile) or not enemy_reachable(room,id): continue
		return id
	return &""

func nearest_visible_hostile(room: StringName) -> StringName:
	var hero_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO}).get("data",{})
	if hero_body.is_empty(): return &""
	var hero_center: Vector2 = hero_body.get("center",Vector2.ZERO)
	var status := ask(&"RoomSpawnStatusRequested",{"room":room})
	var closest: StringName = &""
	var best_distance := INF
	for id in status.get("data",{}).get("placed",[]):
		if not id is StringName or not ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false): continue
		if not ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":id}).get("hostile",false) or not enemy_visible(id): continue
		var body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":id}).get("data",{})
		if body.is_empty(): continue
		var distance := hero_center.distance_squared_to(body.get("center",Vector2.ZERO))
		if distance >= best_distance or not enemy_reachable(room,id): continue
		closest=id
		best_distance=distance
	return closest

func enemy_visible(enemy: StringName) -> bool:
	var body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":enemy}).get("data",{})
	if body.is_empty(): return false
	var visible: Array = ask(&"FogStateGetRequested",{}).get("visible_tiles",[])
	var anchor: Vector2i = body["anchor"]
	var size: int = int(body["size"])
	for x in range(anchor.x,anchor.x+size):
		for y in range(anchor.y,anchor.y+size):
			if Vector2i(x,y) in visible: return true
	return false

func body_adjacent_to_body(anchor: Vector2i, target: Dictionary) -> bool:
	var hero_rect := Rect2i(anchor,Vector2i.ONE*4)
	var enemy_rect := Rect2i(target["anchor"],Vector2i.ONE*int(target["size"]))
	var overlap_x := mini(hero_rect.end.x,enemy_rect.end.x)-maxi(hero_rect.position.x,enemy_rect.position.x)
	var overlap_y := mini(hero_rect.end.y,enemy_rect.end.y)-maxi(hero_rect.position.y,enemy_rect.position.y)
	return (overlap_y>0 and (hero_rect.end.x==enemy_rect.position.x or enemy_rect.end.x==hero_rect.position.x)) or (overlap_x>0 and (hero_rect.end.y==enemy_rect.position.y or enemy_rect.end.y==hero_rect.position.y))

func find_route_to_enemy(room: StringName, enemy: StringName) -> Dictionary:
	var target: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":enemy}).get("data",{})
	if target.is_empty(): return {"found":false,"route":[]}
	var snapshot := path_snapshot(room)
	if snapshot.is_empty(): return {"found":false,"route":[]}
	var start := body_anchor()
	if body_adjacent_to_body(start,target): return {"found":true,"route":[]}
	var queue: Array = [start]
	var previous: Dictionary = {start:start}
	var index := 0
	var goal := Vector2i(-1,-1)
	while index<queue.size():
		var anchor: Vector2i = queue[index]
		index+=1
		for delta in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var next: Vector2i = anchor+delta
			if previous.has(next) or not path_body_fits(next,snapshot): continue
			previous[next]=anchor
			if body_adjacent_to_body(next,target): goal=next; break
			queue.append(next)
		if goal.x>=0: break
	if goal.x<0: return {"found":false,"route":[]}
	var route: Array = []
	var cursor := goal
	while cursor!=start:
		var before: Vector2i = previous[cursor]
		route.push_front(cursor-before)
		cursor=before
	return {"found":true,"route":route}

func enemy_reachable(room: StringName, enemy: StringName) -> bool:
	return find_route_to_enemy(room,enemy).get("found",false)

func incoming_bow_action_direction(enemy: StringName, hero_body: Dictionary) -> Vector2:
	var action := ask(&"ActionGetRequested",{"entity":enemy})
	if not action.get("found",false) or action.get("data",{}).get("id",null)!=&"bow_shot": return Vector2.ZERO
	var shot := ask(&"BowShotStatusRequested",{"entity":enemy})
	if not shot.get("active",false): return Vector2.ZERO
	var data: Dictionary = shot.get("data",{})
	var direction: Vector2 = data.get("direction",Vector2.ZERO)
	if direction == Vector2.ZERO: return Vector2.ZERO
	var release_step := ceili(float(data.get("duration_steps",0))/2.0)
	var release_remaining := float(release_step)*0.01-float(action["data"].get("elapsed",0.0))
	if release_remaining > 0.45: return Vector2.ZERO
	var projectile_service: Node = root.get_node("ProjectileService")
	var muzzle := {"entity":enemy,"direction":direction}
	projectile_service._bow_muzzle_preview(muzzle)
	if not muzzle.get("accepted",false): return Vector2.ZERO
	var parameters: Dictionary = projectile_service.effective_projectile_parameters("bow")
	if parameters.is_empty(): return Vector2.ZERO
	var position: Vector2 = muzzle["position"]
	var hero_rect := Rect2(Vector2(hero_body["anchor"]),Vector2.ONE*float(hero_body["size"]))
	var travel: float = projectile_service._ray_rectangle(position,direction,float(parameters["range"]),hero_rect)
	if travel < 0.0: return Vector2.ZERO
	var wall: Dictionary = projectile_service._wall_ray(position,direction,travel)
	if wall.get("hit",false) and float(wall.get("distance",INF)) <= travel+0.000001: return Vector2.ZERO
	var impact_in: float = maxf(0.0,release_remaining)+travel/10.0
	return -direction.normalized() if impact_in <= 0.45 else Vector2.ZERO

func incoming_projectile_direction(enemy: StringName) -> Vector2:
	var hero_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO}).get("data",{})
	var enemy_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":enemy}).get("data",{})
	if hero_body.is_empty() or enemy_body.is_empty(): return Vector2.ZERO
	var incoming := incoming_bow_action_direction(enemy,hero_body)
	if incoming != Vector2.ZERO: return incoming
	var gear: Dictionary = ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"}).get("data",{})
	var slot := "off" if gear.get("off",null)==&"demo_shield" else "main"
	return root.get_node("AIService")._shield_threat_direction(game.HERO,enemy,slot,hero_body,enemy_body)

func defend_current_threat() -> void:
	var hero_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO}).get("data",{})
	if hero_body.is_empty(): return
	var hero_rect := Rect2i(hero_body["anchor"],Vector2i.ONE*int(hero_body["size"]))
	var status := ask(&"RoomSpawnStatusRequested",{"room":game.current_room})
	var placed: Array = status.get("data",{}).get("placed",[])
	var selected: StringName = &""
	var soonest := INF
	for id in placed:
		if not id is StringName or not ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false): continue
		if not ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":id}).get("hostile",false): continue
		var remaining := enemy_attack_remaining(id)
		if remaining <= 0.0 or remaining >= soonest: continue
		var strike: Dictionary = ask(&"WeaponStrikeActionStatusRequested",{"entity":id}).get("data",{})
		var preview := ask(&"WeaponStrikePreviewRequested",{"entity":id,"item":strike.get("item",null),"strike":strike.get("strike",null),"kind":"physical","direction":strike.get("direction",Vector2.RIGHT)})
		if not preview.get("accepted",false): continue
		var threatens_hero := false
		for tile in preview.get("zone",{}).get("tiles",[]):
			if hero_rect.has_point(tile): threatens_hero=true; break
		if threatens_hero:
			selected=id
			soonest=remaining
	if selected != &"":
		await block_current_enemy_strike(selected)
		return
	for id in placed:
		if not id is StringName or not ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false): continue
		if not ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":id}).get("hostile",false): continue
		var direction := incoming_projectile_direction(id)
		if direction == Vector2.ZERO: continue
		if game._start_shield_block(direction):
			driver.advance_steps(ACTION_TICKS)
			await process_frame
			return

func is_in_weapon_zone(target: StringName, aim: Vector2) -> bool:
	var equipment: Dictionary = ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"}).get("data",{})
	var item = equipment.get("main",null)
	if not item is StringName: return false
	var preview := ask(&"WeaponStrikePreviewRequested",{"entity":game.HERO,"item":item,"strike":game.STRIKE,"kind":"physical","direction":aim})
	if not preview.get("accepted",false): return false
	var target_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":target}).get("data",{})
	if target_body.is_empty(): return false
	var target_rect := Rect2i(target_body["anchor"],Vector2i.ONE*int(target_body["size"]))
	for tile in preview.get("zone",{}).get("tiles",[]):
		if target_rect.has_point(tile): return true
	return false

func enemy_attack_remaining(enemy: StringName) -> float:
	var strike := ask(&"WeaponStrikeActionStatusRequested",{"entity":enemy})
	var action := ask(&"ActionGetRequested",{"entity":enemy})
	if not strike.get("active",false) or not action.get("found",false): return -1.0
	var midpoint := ceilf(float(strike["data"]["duration_steps"])/2.0)*0.01
	return midpoint-float(action["data"]["elapsed"])

func imminent_melee_threat(lookahead: float) -> StringName:
	var hero_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO}).get("data",{})
	if hero_body.is_empty(): return &""
	var hero_rect := Rect2i(hero_body["anchor"],Vector2i.ONE*int(hero_body["size"]))
	var status := ask(&"RoomSpawnStatusRequested",{"room":game.current_room})
	var selected: StringName = &""
	var soonest := lookahead+0.000001
	for id in status.get("data",{}).get("placed",[]):
		if not id is StringName or not ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false): continue
		if not ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":id}).get("hostile",false): continue
		var remaining := enemy_attack_remaining(id)
		if remaining <= 0.0 or remaining > lookahead or remaining >= soonest: continue
		var strike: Dictionary = ask(&"WeaponStrikeActionStatusRequested",{"entity":id}).get("data",{})
		var preview := ask(&"WeaponStrikePreviewRequested",{"entity":id,"item":strike.get("item",null),"strike":strike.get("strike",null),"kind":"physical","direction":strike.get("direction",Vector2.RIGHT)})
		if not preview.get("accepted",false): continue
		for tile in preview.get("zone",{}).get("tiles",[]):
			if hero_rect.has_point(tile):
				selected = id
				soonest = remaining
				break
	return selected

func enemy_attack_is_threatening(enemy: StringName) -> bool:
	var remaining := enemy_attack_remaining(enemy)
	return remaining > 0.0 and remaining <= 0.5

func block_current_enemy_strike(enemy: StringName) -> bool:
	if enemy_attack_remaining(enemy) <= 0.0: return false
	var hero := body_anchor()
	var enemy_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":enemy}).get("data",{})
	if enemy_body.is_empty(): return false
	var diff := Vector2(enemy_body["anchor"])+Vector2.ONE*float(enemy_body["size"])/2.0-(Vector2(hero)+Vector2.ONE*2.0)
	var aim := diff.normalized() if diff.length_squared()>0.0 else Vector2.RIGHT
	var strike: Dictionary = ask(&"WeaponStrikeActionStatusRequested",{"entity":enemy}).get("data",{})
	var strike_zone := ask(&"WeaponStrikePreviewRequested",{"entity":enemy,"item":strike.get("item",null),"strike":strike.get("strike",null),"kind":"physical","direction":strike.get("direction",Vector2.RIGHT)})
	if strike_zone.get("accepted",false):
		var gear: Dictionary = ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"}).get("data",{})
		var slot := ""
		for hand in ["off","main"]:
			var item = gear.get(hand,null)
			if not item is StringName: continue
			var definition := ask(&"ItemGetRequested",{"item":item})
			if definition.get("found",false) and definition.get("base",{}).get("slot","")=="shield":
				slot = hand
				break
		if slot.is_empty(): return false
		var hero_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO}).get("data",{})
		var size := int(hero_body.get("size",4))
		var hero_rect := Rect2i(hero_body.get("anchor",hero),Vector2i.ONE*size)
		var selected_remaining := enemy_attack_remaining(enemy)
		var block_window := maxf(0.5,ceilf(selected_remaining/0.5)*0.5)
		var status := ask(&"RoomSpawnStatusRequested",{"room":game.current_room})
		var threats: Array = []
		for attacker in status.get("data",{}).get("placed",[]):
			if not attacker is StringName or not ask(&"CombatEntityCanActRequested",{"entity":attacker,"allowed":true}).get("allowed",false): continue
			if not ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":attacker}).get("hostile",false): continue
			var remaining := enemy_attack_remaining(attacker)
			if remaining <= 0.0 or remaining > block_window: continue
			var attacker_strike: Dictionary = ask(&"WeaponStrikeActionStatusRequested",{"entity":attacker}).get("data",{})
			var preview := ask(&"WeaponStrikePreviewRequested",{"entity":attacker,"item":attacker_strike.get("item",null),"strike":attacker_strike.get("strike",null),"kind":"physical","direction":attacker_strike.get("direction",Vector2.RIGHT)})
			if not preview.get("accepted",false): continue
			var attack_tiles: Array = preview.get("zone",{}).get("tiles",[])
			var threatens_hero := false
			for tile in attack_tiles:
				if hero_rect.has_point(tile): threatens_hero = true; break
			if threatens_hero: threats.append({"entity":attacker,"tiles":attack_tiles,"remaining":remaining})
		if threats.is_empty():
			threats.append({"entity":enemy,"tiles":strike_zone.get("zone",{}).get("tiles",[]),"remaining":selected_remaining})
		var candidates: Array[Vector2] = []
		for x in range(-1,size+1):
			for y in range(-1,size+1):
				if (x in [-1,size]) == (y in [-1,size]): continue
				var direction := (Vector2(hero+Vector2i(x,y))+Vector2.ONE*0.5-(Vector2(hero)+Vector2.ONE*float(size)*0.5)).normalized()
				if direction != Vector2.ZERO: candidates.append(direction)
		var best_score := 0
		var best_direction := aim
		for direction in candidates:
			var preview := ask(&"ShieldBlockPreviewRequested",{"entity":game.HERO,"slot":slot,"direction":direction})
			if not preview.get("accepted",false): continue
			var shield_tiles: Array = preview.get("data",{}).get("tiles",[])
			var score := 0
			for threat in threats:
				var overlap := 0
				for tile in shield_tiles:
					if tile in threat["tiles"]: overlap += 1
				if overlap > 0: score += 1000+overlap*10
			if score > best_score:
				best_score = score
				best_direction = direction
		if best_score > 0: aim = best_direction
	if not game._start_shield_block(aim): return false
	for _extend in range(12):
		var attack_remaining := enemy_attack_remaining(enemy)
		if attack_remaining <= 0.0: break
		var block := ask(&"ActionGetRequested",{"entity":game.HERO})
		if not block.get("found",false) or block.get("data",{}).get("id",null)!=&"shield_block": return false
		var block_remaining := float(block["data"]["duration"])-float(block["data"]["elapsed"])
		if attack_remaining >= block_remaining:
			var extension := ask(&"ShieldBlockExtendRequested",{"entity":game.HERO})
			if extension.get("accepted",false): continue
		var ticks := maxi(1,mini(25,floori(minf(attack_remaining,block_remaining)*100.0)))
		driver.advance_steps(ticks)
		await process_frame
	var attack_blocked: bool = enemy_attack_remaining(enemy) <= 0.0
	var block_finished: bool = await finish_pending_player_action()
	return attack_blocked and block_finished and not game.is_dead

func move_toward_enemy(enemy: StringName) -> bool:
	var route := find_route_to_enemy(game.current_room,enemy)
	if not route.get("found",false) or route.get("route",[]).is_empty():
		if combat_move_debug_count<12 or not route.get("found",false): print("COMBAT_ROUTE_FAIL room=%s enemy=%s pos=%s route=%s" % [game.current_room,enemy,str(body_anchor()),str(route)])
		combat_move_debug_count+=1
		return false
	var before := body_anchor()
	var first: Vector2i = route["route"][0]
	var moved: bool = await perform_move(first)
	if combat_move_debug_count<12 or not moved:
		print("COMBAT_MOVE room=%s enemy=%s before=%s delta=%s after=%s moved=%s route_len=%d hp=%s action=%s" % [game.current_room,enemy,str(before),str(first),str(body_anchor()),str(moved),route["route"].size(),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{}).get("current",null)),str(ask(&"ActionGetRequested",{"entity":game.HERO}))])
	combat_move_debug_count+=1
	return moved

func close_inventory_menu() -> bool:
	if game.is_dead: return false
	for attempt in range(4):
		if not game.inventory_open: return true
		if ask(&"ActionGetRequested",{"entity":game.HERO}).get("found",false):
			if not await finish_pending_player_action(): return false
			continue
		var closed: bool = game._toggle_inventory()
		if not closed:
			printerr("MENU_CLOSE_DIAG rejected attempt=%d mode=%s action=%s message=%s" % [attempt,str(ask(&"GameModeGetRequested",{})),str(ask(&"ActionGetRequested",{"entity":game.HERO})),game.message])
			await process_frame
			continue
		if not await finish_pending_player_action(): return false
		if game.inventory_open: printerr("MENU_CLOSE_DIAG attempt=%d accepted=%s action=%s message=%s" % [attempt,str(closed),str(ask(&"ActionGetRequested",{"entity":game.HERO})),game.message])
	return not game.inventory_open

func use_inventory_item(item_id: StringName) -> bool:
	if not game._inventory_items().has(item_id): return false
	if not game.inventory_open:
		if not game._toggle_inventory() or not await finish_pending_player_action() or not game.inventory_open: return false
	var items: Array = game._inventory_items()
	var index := items.find(item_id)
	if index < 0:
		await close_inventory_menu()
		return false
	var used: bool = game._use_inventory_item(index)
	if used and game.inventory_open:
		# Keep the inventory open only when choosing an item; after activation,
		# leave it before advancing gameplay so nearby foes cannot attack through it.
		if not await close_inventory_menu(): return false
	if used and not await finish_pending_player_action(): return false
	if game.inventory_open and not await close_inventory_menu():
		printerr("INVENTORY_DIAG failed to close the inventory after %s; action=%s" % [item_id,str(ask(&"ActionGetRequested",{"entity":game.HERO}))])
		return false
	return used

func find_inventory_consumable(kind: String) -> StringName:
	for item_id in game._inventory_items():
		if not item_id is StringName: continue
		var item: Dictionary = ask(&"ItemGetRequested",{"item":item_id})
		if item.get("found",false) and str(item.get("base",{}).get("consumable_kind","")) == kind:
			return item_id
	return &""

func use_inventory_consumable(kind: String) -> bool:
	var item_id := find_inventory_consumable(kind)
	if item_id == &"": return false
	var used: bool = await use_inventory_item(item_id)
	if used: print("CONSUMABLE kind=%s item=%s" % [kind,item_id])
	return used

func heal_if_needed() -> bool:
	var hp_data: Dictionary = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{})
	if hp_data.is_empty() or float(hp_data.get("current",0.0)) > float(hp_data.get("max",1.0))*0.75: return false
	return await use_inventory_consumable("heal_hp")

func restore_stamina_if_needed() -> bool:
	var stamina: Dictionary = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{})
	if stamina.is_empty() or float(stamina.get("current",0.0)) > float(stamina.get("max",1.0))*0.25: return false
	return await use_inventory_consumable("heal_stamina")

func recover_in_safe_room(room: StringName) -> void:
	if room == &"" or game.current_room != room or game.is_dead or game.is_won: return
	var status := ask(&"RoomSpawnStatusRequested",{"room":room})
	var spawn_data: Dictionary = status.get("data",{})
	if spawn_data.is_empty() or spawn_data.get("pending",&"") != &"" or not spawn_data.get("queue",[]).is_empty(): return
	if not living_hostiles_in_room(room).is_empty(): return
	var mode := ask(&"GameModeGetRequested",{})
	if not mode.get("rest_allowed",false): return
	var cycles := 0
	for _cycle in range(MAX_SAFE_REST_CYCLES):
		if game.current_room != room or game.is_dead or game.is_won or not living_hostiles_in_room(room).is_empty(): break
		var hp: Dictionary = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{})
		var stamina: Dictionary = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{})
		if hp.is_empty() or stamina.is_empty(): break
		if float(hp["current"]) >= float(hp["max"])*0.8 and float(stamina["current"]) >= float(stamina["max"])*0.85: break
		# One five-second ordinary wait replaces ten short waits in a safe room;
		# this is still an in-game action and lets passive recovery finish.
		var rest_action := ask(&"ActionStartRequested",{"entity":game.HERO,"action":&"wait","duration":float(SAFE_REST_TICKS)*0.01})
		if not rest_action.get("accepted",false): break
		driver.advance_steps(SAFE_REST_TICKS)
		await process_frame
		cycles += 1
	if cycles > 0:
		var hp: Dictionary = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{})
		var stamina: Dictionary = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{})
		print("SAFE_REST room=%s cycles=%d hp=%.1f/%.1f stamina=%.1f/%.1f" % [room,cycles,float(hp.get("current",0.0)),float(hp.get("max",0.0)),float(stamina.get("current",0.0)),float(stamina.get("max",0.0))])

func allocate_level_growth() -> bool:
	if game.hero_points <= 0: return true
	if not game.inventory_open or not game.stats_view:
		game._open_stats()
		driver.advance_steps(1)
		await process_frame
	if not game.inventory_open or not game.stats_view: return false
	var target_stat_base: int = 5 + int(game.hero_level) - 1
	while game.hero_points > 0:
		var con: Dictionary = ask(&"StatGetRequested",{"entity":game.HERO,"stat":&"CON"})
		var strength: Dictionary = ask(&"StatGetRequested",{"entity":game.HERO,"stat":&"STR"})
		var index := 0 if int(con.get("base",0)) < target_stat_base else (1 if int(strength.get("base",0)) < target_stat_base else -1)
		if index < 0: break
		if not game._allocate_stat(index): return false
		print("LEVEL_UP level=%d stat=%s base=%d points_left=%d" % [game.hero_level,"CON" if index==0 else "STR",target_stat_base,game.hero_points])
	if game.inventory_open and game._toggle_inventory():
		driver.advance_steps(1)
		await process_frame
	return game.hero_points == 0

func resolve_current_combat() -> bool:
	for _pass in range(4):
		if ask(&"GameModeGetRequested",{}).get("mode","")!="combat": return true
		var enemy := nearest_hostile_in_room(game.current_room)
		if enemy == &"": return true
		if not await fight_enemy(enemy): return false
	return not game.is_dead

func find_route_covering_tile(room: StringName, tile: Vector2i) -> Dictionary:
	var bounds := room_bounds(room)
	var hero_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO}).get("data",{})
	if bounds.is_empty() or hero_body.is_empty(): return {"found":false,"route":[]}
	var size := int(hero_body.get("size",4))
	var start := body_anchor()
	if Rect2i(start,Vector2i.ONE*size).has_point(tile): return {"found":true,"route":[]}
	var queue: Array = [start]
	var previous: Dictionary = {start:start}
	var index := 0
	var goal := Vector2i(-1,-1)
	while index<queue.size():
		var anchor: Vector2i = queue[index]
		index+=1
		for delta in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var next: Vector2i = anchor+delta
			if previous.has(next) or not body_fits(next,bounds): continue
			previous[next]=anchor
			if Rect2i(next,Vector2i.ONE*size).has_point(tile): goal=next; break
			queue.append(next)
		if goal.x>=0: break
	if goal.x<0: return {"found":false,"route":[]}
	var route: Array = []
	var cursor := goal
	while cursor!=start:
		var before: Vector2i = previous[cursor]
		route.push_front(cursor-before)
		cursor=before
	return {"found":true,"route":route}

func collect_room_consumables(room: StringName) -> void:
	if collecting_loot or room==&"" or room!=game.current_room or not living_hostiles_in_room(room).is_empty(): return
	collecting_loot=true
	var ground: Dictionary = ask(&"LootGetRequested",{}).get("items",{})
	var bounds := room_bounds(room)
	var room_rect := Rect2i(bounds.get("origin",Vector2i.ZERO),bounds.get("size",Vector2i.ZERO))
	var candidates: Array = []
	for id in ground:
		var tile = ground[id].get("tile",null)
		if not tile is Vector2i or not room_rect.has_point(tile): continue
		var item := ask(&"ItemGetRequested",{"item":id})
		if not item.get("found",false) or item.get("base",{}).get("slot","")!="consumable": continue
		var kind: String = str(item.get("base",{}).get("consumable_kind",""))
		if kind in ["heal_hp","heal_stamina"]: candidates.append({"id":id,"tile":tile,"kind":kind})
	for candidate in candidates:
		if game._inventory_items().has(candidate["id"]): continue
		var route := find_route_covering_tile(room,candidate["tile"])
		if not route.get("found",false): continue
		var reached := true
		for delta in route.get("route",[]):
			if not await perform_move(delta): reached=false; break
		if not reached or game.is_dead or game.current_room!=room: break
		if not game._pickup_candidates().has(candidate["id"]): continue
		if not game._pickup(): continue
		if not game._pickup_item(candidate["id"]):
			if game._pickup_open: game._pickup_close()
			continue
		driver.advance_steps(ACTION_TICKS)
		await process_frame
		if game._pickup_open: game._pickup_close()
		if game._inventory_items().has(candidate["id"]): print("LOOT_CONSUMABLE room=%s item=%s kind=%s" % [room,candidate["id"],candidate["kind"]])
	collecting_loot=false

func fight_enemy(enemy: StringName) -> bool:
	if combat_agent_active: return await _fight_enemy_impl(enemy)
	combat_agent_active = true
	var result: bool = await _fight_enemy_impl(enemy)
	combat_agent_active = false
	if result and not game.is_dead:
		if not await allocate_level_growth():
			check(false,"spend earned level-up points as +1 CON/+1 STR per level")
			return false
		await collect_room_consumables(game.current_room)
	return result and not game.is_dead

func _fight_enemy_impl(enemy: StringName) -> bool:
	var enemy_state: Array = []
	for foe in living_hostiles_in_room(game.current_room):
		var body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":foe}).get("data",{})
		enemy_state.append({"id":foe,"anchor":body.get("anchor",Vector2i(-1,-1)),"action":ask(&"ActionGetRequested",{"entity":foe}).get("data",{}),"equipment":ask(&"ComponentGetRequested",{"entity":foe,"component":&"equipment"}).get("data",{})})
	print("COMBAT_START room=%s target=%s hero=%s hp=%s stamina=%s hostiles=%s" % [str(game.current_room),str(enemy),str(body_anchor()),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{}).get("current",null)),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{}).get("current",null)),str(enemy_state)])
	# Prefer one foe, but switch only when another visible opponent is clearly
	# closer. Threat-timing based switches can alternate forever between a pair.
	var combat_target: StringName = enemy
	var target_lock_until_turn := 0
	var attacks := 0
	var stagnant_turns := 0
	var previous_anchor := body_anchor()
	var previous_target_anchor := body_anchor(combat_target)
	var previous_target_hp: float = float(ask(&"ResourceGetRequested",{"entity":combat_target,"resource":&"HP"}).get("data",{}).get("current",0.0))
	for turn in range(MAX_COMBAT_TURNS):
		if not ask(&"CombatEntityCanActRequested",{"entity":game.HERO,"allowed":true}).get("allowed",false): return false
		if not ask(&"CombatEntityCanActRequested",{"entity":combat_target,"allowed":true}).get("allowed",false):
			if attacks <= 0: return false
			var action_finished: bool = await finish_pending_player_action()
			return action_finished and not game.is_dead
		# A movement, block, potion, or stagger can still be resolving when an
		# enemy first becomes visible. Poll in short slices so combat can react
		# as soon as the ordinary action completes.
		if ask(&"ActionGetRequested",{"entity":game.HERO}).get("found",false):
			if not await finish_pending_player_action(): return false
			continue
		if turn >= target_lock_until_turn:
			var closest_visible := nearest_visible_hostile(game.current_room)
			if closest_visible != &"" and closest_visible != combat_target:
				var hero_target_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO}).get("data",{})
				var current_target_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":combat_target}).get("data",{})
				var closest_target_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":closest_visible}).get("data",{})
				if not hero_target_body.is_empty() and not current_target_body.is_empty() and not closest_target_body.is_empty():
					var hero_center: Vector2 = hero_target_body.get("center",Vector2.ZERO)
					var current_distance: float = hero_center.distance_to(current_target_body.get("center",Vector2.ZERO))
					var closest_distance: float = hero_center.distance_to(closest_target_body.get("center",Vector2.ZERO))
					if closest_distance + 4.0 < current_distance:
						print("COMBAT_RETARGET room=%s from=%s to=%s distances=%.1f/%.1f" % [game.current_room,combat_target,closest_visible,current_distance,closest_distance])
						combat_target = closest_visible
						target_lock_until_turn = turn + 8
		var hero := body_anchor()
		var hero_hp: float = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{}).get("current",0.0)
		if float(hero_hp) <= 0.0: return false
		await defend_current_threat()
		if game.is_dead: return false
		if ask(&"ActionGetRequested",{"entity":game.HERO}).get("found",false):
			driver.advance_steps(COMBAT_POLL_TICKS)
			await process_frame
			continue
		if enemy_attack_remaining(combat_target) > 0.0:
			var blocked: bool = await block_current_enemy_strike(combat_target)
			if not blocked and enemy_attack_remaining(combat_target) > 0.0: return false
			continue
		var arrow_direction := incoming_projectile_direction(combat_target)
		if arrow_direction != Vector2.ZERO and game._start_shield_block(arrow_direction):
			if not await finish_pending_player_action(): return false
			continue
		if await heal_if_needed(): continue
		if await restore_stamina_if_needed(): continue
		var hero_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO}).get("data",{})
		var enemy_body: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":combat_target}).get("data",{})
		if enemy_body.is_empty():
			if attacks <= 0: return false
			var pending_attack_finished: bool = await finish_pending_player_action()
			return pending_attack_finished and not game.is_dead
		var diff := Vector2(enemy_body["anchor"])+Vector2.ONE*float(enemy_body["size"])/2.0-(Vector2(hero)+Vector2.ONE*2.0)
		var aim := diff.normalized() if diff.length_squared() > 0.0 else Vector2.RIGHT
		var started := false
		if not started and is_in_weapon_zone(combat_target,aim):
			game.attack_direction = aim
			started = game._start_attack()
			if started: attacks += 1
		if not started:
			if not await move_toward_enemy(combat_target): game._wait()
		if turn % 20 == 0:
			var gear: Dictionary = ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"}).get("data",{})
			var player_item: StringName = gear.get("main",&"")
			var cost_preview := ask(&"WeaponStrikeStaminaPreviewRequested",{"entity":game.HERO,"item":player_item,"strike":"demo_player_sword_thrust"})
			print("COMBAT turn=%d hero=%s enemy=%s hp=%s zone=%s started=%s pending_attack=%s inventory=%s cost=%s message=%s action=%s driver=%s stamina=%s" % [turn,str(body_anchor()),str(body_anchor(combat_target)),str(ask(&"ResourceGetRequested",{"entity":combat_target,"resource":&"HP"}).get("data",{})),str(is_in_weapon_zone(combat_target,aim)),str(started),str(game.pending_attack),str(game.inventory_open),str(cost_preview),game.message,str(ask(&"ActionGetRequested",{"entity":game.HERO}).get("data",{})),str({"active":driver.is_action_active,"id":driver.current_action_id,"stepping":driver._stepping,"settling":driver._settling}),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{}))])
		driver.advance_steps(COMBAT_POLL_TICKS)
		await process_frame
		var observed_anchor := body_anchor()
		var observed_target_anchor := body_anchor(combat_target)
		var observed_target_hp: float = float(ask(&"ResourceGetRequested",{"entity":combat_target,"resource":&"HP"}).get("data",{}).get("current",0.0))
		if observed_anchor != previous_anchor or observed_target_anchor != previous_target_anchor or observed_target_hp < previous_target_hp:
			stagnant_turns = 0
			previous_anchor = observed_anchor
			previous_target_anchor = observed_target_anchor
			previous_target_hp = observed_target_hp
		else:
			stagnant_turns += 1
		if stagnant_turns >= MAX_STAGNANT_COMBAT_TURNS:
			printerr("COMBAT_STALLED room=%s target=%s turns=%d hero=%s hero_action=%s target_body=%s target_action=%s target_hp=%s route=%s hostiles=%s" % [game.current_room,combat_target,stagnant_turns,str(observed_anchor),str(ask(&"ActionGetRequested",{"entity":game.HERO})),str(ask(&"SpaceBodyGetRequested",{"entity":combat_target})),str(ask(&"ActionGetRequested",{"entity":combat_target})),str(ask(&"ResourceGetRequested",{"entity":combat_target,"resource":&"HP"})),str(find_route_to_enemy(game.current_room,combat_target)),str(living_hostiles_in_room(game.current_room))])
			return false
	if ask(&"CombatEntityCanActRequested",{"entity":combat_target,"allowed":true}).get("allowed",false): return false
	if attacks <= 0: return false
	var final_action_finished: bool = await finish_pending_player_action()
	return final_action_finished and not game.is_dead

func equip_shield() -> bool:
	var gear: Dictionary = ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"}).get("data",{})
	if gear.get("off",null) == &"demo_shield": return true
	return await use_inventory_item(&"demo_shield")

func clear_current_hostiles(room: StringName, wait_for_spawn: bool = false) -> bool:
	if game.current_room != room: return true
	if wait_for_spawn:
		for _pass in range(3): await process_frame
	var status := ask(&"RoomSpawnStatusRequested",{"room":room})
	var placed: Array = status.get("data",{}).get("placed",[])
	for enemy in placed:
		if not enemy is StringName or not ask(&"CombatEntityCanActRequested",{"entity":enemy,"allowed":true}).get("allowed",false): continue
		if not ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":enemy}).get("hostile",false): continue
		# A hostile body can physically block the only route to a connected door
		# before it enters the fog of war. If it is path-reachable, clear it with
		# normal combat rather than treating a visible-only route as a dead end.
		if not enemy_reachable(room,enemy): continue
		if not await fight_enemy(enemy):
			if game.is_dead: return false
			if ask(&"CombatEntityCanActRequested",{"entity":enemy,"allowed":true}).get("allowed",false): return false
		if game.is_dead: return false
	return true

func current_milestone(floor_no: int) -> Dictionary:
	var tracking := ask(&"DungeonFloorTrackingGetRequested",{})
	if not tracking.get("found",false): return {}
	var data: Dictionary = tracking.get("data",{})
	var key := "boss_candidate" if floor_no == 4 else "stair_candidate"
	var candidate = data.get(key,null)
	if not candidate is StringName or candidate == &"": return {}
	if floor_no < 4:
		var stair := ask(&"DungeonStairGetRequested",{})
		if stair.get("found",false) and stair.get("data",{}).get("status","")=="failed":
			game._press_key(KEY_R)
			await process_frame
			stair = ask(&"DungeonStairGetRequested",{})
		if not stair.get("found",false) or stair.get("data",{}).get("status","")!="placed": return {}
		return {"room":candidate,"object":stair["data"]["object"],"data":data}
	return {"room":candidate,"data":data}

func explore_until_milestone(floor_no: int) -> Dictionary:
	var attempted: Dictionary = {}
	var visited: Dictionary = {game.ROOM:true}
	var logged_rooms: Dictionary = {}
	var exit_attempts := 0
	while exit_attempts < MAX_ROOM_GENERATIONS:
		verify_no_archers(game.current_room)
		var target := await current_milestone(floor_no)
		if not target.is_empty():
			if game.current_room != target["room"]:
				check(false,"milestone room is reached by the player, not only generated")
				return {}
			return target
		if game.is_dead or game.is_won: return {}
		var here: StringName = game.current_room
		if here == &"": return {}
		visited[here] = true
		var info := room_data(here)
		if not logged_rooms.has(here):
			logged_rooms[here] = true
			var elapsed := float(Time.get_ticks_msec()-run_started_msec)/1000.0
			print("ROOM_ARRIVE floor=%d room=%s parent=%s visited=%d exits=%d elapsed=%.1fs" % [floor_no,here,str(info.get("parent",null)),visited.size(),info.get("exits",[]).size(),elapsed])
		var chosen: Dictionary = {}
		# Continue along already connected, unexplored branches before opening
		# another door. Every transition below uses ordinary player movement.
		for exit in info.get("exits",[]):
			var child = exit.get("childId",null)
			if exit.get("connected",false) and child is StringName and not visited.has(child):
				chosen = exit
				break
		if chosen.is_empty():
			for exit in info.get("exits",[]):
				var key := str(here)+"/"+str(exit.get("id",""))
				if not exit.get("connected",false) and not exit.get("sealed",false) and not attempted.has(key):
					chosen = exit
					attempted[key] = true
					exit_attempts += 1
					break
		if not chosen.is_empty():
			var next_room: StringName = await walk_through_exit(here,chosen["id"])
			if next_room != &"" and next_room != here:
				visited[next_room] = true
				await defend_current_threat()
				if game.is_dead:
					check(false,"survive a live threat after entering room %s" % next_room)
					return {}
				continue
			if chosen.get("connected",false):
				check(false,"walk through connected exit %s/%s" % [here,chosen.get("id","")])
				return {}
			continue
		if here == game.ROOM:
			var room_map: Dictionary = ask(&"RoomAllGetRequested",{}).get("rooms",{})
			var topology: Array = []
			for room_id in room_map:
				var room_info: Dictionary = room_map[room_id]
				var exits: Array = []
				for exit in room_info.get("exits",[]):
					exits.append({"id":exit.get("id",null),"dir":exit.get("dirOut",null),"connected":exit.get("connected",false),"child":exit.get("childId",null),"sealed":exit.get("sealed",false)})
				topology.append({"id":room_id,"type":room_info.get("type",""),"parent":room_info.get("parent",null),"exits":exits})
			printerr("No untried exits on floor %d after %d natural door attempts; rooms=%d generation_failures=%s topology=%s" % [floor_no,exit_attempts,room_map.size(),str(generation_failures),str(topology)])
			return {}
		var parent = info.get("parent",null)
		var entry := exit_record(here,&"entry")
		if not parent is StringName or parent == &"" or entry.is_empty(): return {}
		var back: StringName = await walk_through_exit(here,&"entry")
		if back != parent:
			var spawn_debug := ask(&"RoomSpawnStatusRequested",{"room":here})
			var blocker_details: Array = []
			var neighbor_fits: Dictionary = {}
			for delta in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]: neighbor_fits[str(delta)]=body_fits(body_anchor()+delta,room_bounds(here))
			for enemy in spawn_debug.get("data",{}).get("placed",[]):
				if not enemy is StringName: continue
				blocker_details.append({"id":enemy,"body":ask(&"SpaceBodyGetRequested",{"entity":enemy}).get("data",{}),"visible":enemy_visible(enemy),"reachable":enemy_reachable(here,enemy),"hostile":ask(&"DetectionPairGetRequested",{"observer":game.HERO,"target":enemy}).get("hostile",false)})
			printerr("RETURN_DIAG room=%s parent=%s back=%s pos=%s entry=%s entry_fit=%s neighbor_fits=%s route=%s exits=%s spawn=%s blockers=%s action=%s" % [here,parent,back,str(body_anchor()),str(entry),str(body_fits(exit_anchor(entry),room_bounds(here))),str(neighbor_fits),str(find_route(here,exit_anchor(entry),false)),str(info.get("exits",[])),str(spawn_debug),str(blocker_details),str(ask(&"ActionGetRequested",{"entity":game.HERO}))])
			check(false,"walk back through the connected room entrance")
			return {}
		visited[parent] = true
	return {}

func walk_to_object(room: StringName, object_id: StringName) -> bool:
	var object := ask(&"ObjectGetRequested",{"object":object_id})
	if not object.get("found",false): return false
	var tile: Vector2i = object["data"]["tile"]
	for attempt in range(3):
		if game.current_room != room: return false
		var route := find_route(room,tile,true)
		if not route.get("found",false):
			if attempt == 0 and await clear_current_hostiles(room): continue
			return false
		var blocked := false
		for delta in route["route"]:
			if not await perform_move(delta):
				blocked = true
				break
		if body_adjacent_to_tile(body_anchor(),tile): return true
		if not blocked: return false
		if attempt == 1 and not await clear_current_hostiles(room): return false
	return false

func use_adjacent_interactable(label: String) -> bool:
	game._press_key(KEY_F)
	var action := ask(&"ActionGetRequested",{"entity":game.HERO})
	if not action.get("found",false):
		printerr("%s interaction did not start: %s" % [label,game.message])
		return false
	driver.advance_steps(ACTION_TICKS)
	await process_frame
	await process_frame
	return true

func reach_and_use_stairs(floor_no: int, milestone: Dictionary) -> bool:
	var room: StringName = milestone["room"]
	var object_id: StringName = milestone["object"]
	if not await walk_to_object(room,object_id):
		check(false,"walk to floor %d stairs using normal movement" % floor_no)
		return false
	var availability := ask(&"DungeonStairAvailabilityRequested",{"entity":game.HERO})
	if not availability.get("rule_allowed",false):
		var blocking = availability.get("blocking_enemy",null)
		if blocking is StringName and blocking != &"":
			if not await fight_enemy(blocking): return false
			if not await walk_to_object(room,object_id): return false
			availability = ask(&"DungeonStairAvailabilityRequested",{"entity":game.HERO})
	if not availability.get("rule_allowed",false):
		check(false,"floor %d stairs are usable without disabling combat: %s" % [floor_no,str(availability)])
		return false
	if not await use_adjacent_interactable("floor %d stairs" % floor_no): return false
	var tracking := ask(&"DungeonFloorTrackingGetRequested",{})
	check(tracking.get("data",{}).get("floor",0)==floor_no+1,"real stair interaction descends to floor %d" % (floor_no+1))
	return tracking.get("data",{}).get("floor",0)==floor_no+1

func fight_boss_and_win() -> bool:
	var boss := ask(&"DungeonBossGetRequested",{})
	if not boss.get("found",false) or boss.get("data",{}).get("status","")!="alive":
		check(false,"procedural boss spawns alive in its reached room: %s" % str(boss))
		return false
	var boss_id: StringName = boss["data"]["entity"]
	check(await fight_enemy(boss_id),"defeat the live boss using movement, attacks, blocks and healing actions")
	var result := ask(&"DungeonBossGetRequested",{})
	if not result.get("found",false) or result.get("data",{}).get("status","")!="defeated":
		check(false,"boss status becomes defeated after live combat: %s" % str(result))
		return false
	var boss_room: StringName = game.current_room
	var out: Dictionary = {}
	for exit in room_data(boss_room).get("exits",[]):
		if exit.get("id",null)!=&"entry" and not exit.get("connected",false) and not exit.get("sealed",false):
			out = exit
			break
	if out.is_empty():
		check(false,"boss room has a natural portal branch exit")
		return false
	var portal_room := await walk_through_exit(boss_room,out["id"])
	if portal_room == &"" or portal_room == boss_room:
		check(false,"walk through the boss branch to generate the portal room")
		return false
	var portal := ask(&"DungeonPortalGetRequested",{})
	if not portal.get("found",false) or portal.get("data",{}).get("status","")!="placed":
		check(false,"portal is placed by the natural boss-branch generation: %s" % str(portal))
		return false
	var portal_id: StringName = portal["data"]["object"]
	check(await walk_to_object(portal_room,portal_id),"walk to the portal without teleporting")
	var availability := ask(&"DungeonPortalAvailabilityRequested",{"entity":game.HERO})
	check(availability.get("rule_allowed",false),"portal is available after the live boss fight: %s" % str(availability))
	if not availability.get("rule_allowed",false): return false
	game._press_key(KEY_F)
	await process_frame
	check(game.is_won,"win by the real portal interaction")
	var run := ask(&"RunStatisticsGetRequested",{})
	check(run.get("data",{}).get("finished",false),"portal victory finishes the run statistics")
	return game.is_won

func run() -> void:
	run_started_msec = Time.get_ticks_msec()
	var args := OS.get_cmdline_user_args()
	if args.size() > 1 or (not args.is_empty() and not args[0].is_valid_int()):
		printerr("FAIL: expected at most one integer seed argument")
		quit(2)
		return
	if not args.is_empty(): run_seed = args[0].to_int()
	bus = root.get_node("EventBus")
	var failed_observer := func(event):
		if generation_failures.size() < 6: generation_failures.append({"room":event.get("room",null),"exit":event.get("exit",null),"attempts":event.get("attempts",null)})
	bus.subscribe(&"RoomGenerationFailed",failed_observer)
	var damage_observer := func(event):
		if event.get("entity",null)!=game.HERO: return
		player_damage_events.append(event.duplicate(true))
		if player_damage_events.size()>12: player_damage_events.pop_front()
	var death_observer := func(event):
		if event.get("entity",null)==game.HERO: player_death_events.append(event.duplicate(true))
	var outgoing_observer := func(event):
		if event.get("source",null)!=game.HERO: return
		var target: Variant = event.get("entity",null)
		var hp: Dictionary = ask(&"ResourceGetRequested",{"entity":target,"resource":&"HP"}).get("data",{})
		var row := {"room":game.current_room,"target":target,"amount":event.get("amount",null),"hp":hp.get("current",null)}
		outgoing_damage_events.append(row)
		print("PLAYER_HIT room=%s target=%s amount=%s hp=%s" % [str(row["room"]),str(target),str(row["amount"]),str(row["hp"])])
	var consumable_observer := func(event):
		if event.get("entity",null)!=game.HERO: return
		player_consumable_events.append(event.duplicate(true))
		print("CONSUMABLE_COMPLETE item=%s kind=%s success=%s room=%s hp=%s stamina=%s" % [str(event.get("item",null)),str(event.get("kind","")),str(event.get("success",false)),str(game.current_room),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{}).get("current",null)),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{}).get("current",null))])
	var interrupt_observer := func(event):
		if event.get("entity",null)!=game.HERO: return
		player_interrupt_events.append(event.duplicate(true))
		print("PLAYER_ACTION_INTERRUPTED room=%s action=%s reason=%s hp=%s stamina=%s" % [str(game.current_room),str(event.get("action",null)),str(event.get("reason","")),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{}).get("current",null)),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{}).get("current",null))])
	var block_observer := func(event):
		var data: Dictionary = event.get("data",{})
		var blocks: Dictionary = data.get("blocks",{})
		if blocks.has(game.HERO):
			player_block_events.append(blocks[game.HERO].duplicate(true))
			if player_block_events.size()>20: player_block_events.pop_front()
		var hero_hits: Array = []
		for hit in data.get("resolved_hits",[]):
			if hit.get("target",null)==game.HERO: hero_hits.append(hit.duplicate(true))
		if not hero_hits.is_empty():
			var hp: Dictionary = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{})
			var stamina: Dictionary = ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{})
			player_phase_events.append({"room":game.current_room,"hp":hp.get("current",null),"stamina":stamina.get("current",null),"hits":hero_hits,"block":blocks.get(game.HERO,{})})
			if player_phase_events.size()>20: player_phase_events.pop_front()
	bus.subscribe(&"EntityDamaged",damage_observer)
	bus.subscribe(&"EntityDied",death_observer)
	bus.subscribe(&"EntityDamaged",outgoing_observer)
	bus.subscribe(&"ConsumableUseCompleted",consumable_observer)
	bus.subscribe(&"ActionInterrupted",interrupt_observer)
	bus.subscribe(&"CombatPhaseBatchResolved",block_observer)
	driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var melee_setup: Node = root.get_node("DemoMeleeSetupService")
	melee_setup.set("allow_bow_loadouts",false)
	check(not bool(melee_setup.get("allow_bow_loadouts")),"test-only no-archer mode is enabled")
	print("Run mode: bow loadouts disabled; starting at level 1")
	game = load("res://game_demo.tscn").instantiate()
	game.generation_seed = run_seed
	game.starting_shield_base = &"shield_large"
	game.starting_armor_base = &"armor_iron_body"
	root.add_child(game)
	await process_frame
	await process_frame
	check(game.initialized,"demo initializes")
	var level := ask(&"LevelMapGetRequested",{})
	check(level.get("found",false) and level.get("map_data",{}).get("seed",null)==run_seed,"demo uses requested seed")
	check(await use_inventory_item(&"demo_armor"),"equip body armor through the inventory controls")
	check(await equip_shield(),"equip shield through the inventory controls")
	var starting_armour := ask(&"EquipmentArmourGetRequested",{"entity":game.HERO})
	var starting_gear: Dictionary = ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"}).get("data",{})
	print("RUN_LOADOUT armour=%s body=%s shield=%s inventory=%s message=%s" % [str(starting_armour.get("armour",null)),str(starting_gear.get("body",null)),str(starting_gear.get("off",null)),str(game._inventory_items()),game.message])
	check(starting_armour.get("found",false) and float(starting_armour.get("armour",0.0)) >= 39.9,"large shield and iron body armor provide physical protection")
	check(await fight_enemy(game.RAT),"defeat the tutorial enemy through live combat actions")
	for floor_no in range(1,5):
		var floor_level := ask(&"LevelMapGetRequested",{})
		var floor_map: Dictionary = floor_level.get("map_data",{})
		print("=== Natural traversal: floor %d seed=%s level=%s size=%s ===" % [floor_no,str(floor_map.get("seed",null)),str(floor_map.get("level_id",null)),str(floor_map.get("size_cells",null))])
		print("FLOOR_TRACKING floor=%d data=%s" % [floor_no,str(ask(&"DungeonFloorTrackingGetRequested",{}).get("data",{}))])
		var milestone := await explore_until_milestone(floor_no)
		if milestone.is_empty():
			printerr("RUN_DIAG dead=%s mode=%s hp=%s stamina=%s last_damage=%s death=%s blocks=%s phase_hits=%s" % [game.is_dead,str(ask(&"GameModeGetRequested",{})),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"}).get("data",{})),str(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"}).get("data",{})),str(player_damage_events),str(player_death_events),str(player_block_events),str(player_phase_events)])
			if not player_death_events.is_empty():
				var killer: Variant = player_death_events.back().get("killer",null)
				if killer is StringName:
					printerr("KILLER_DIAG id=%s spawn=%s equipment=%s ai=%s body=%s action=%s" % [killer,str(ask(&"ComponentGetRequested",{"entity":killer,"component":&"spawn"})),str(ask(&"ComponentGetRequested",{"entity":killer,"component":&"equipment"})),str(ask(&"AIGetRequested",{"entity":killer})),str(ask(&"SpaceBodyGetRequested",{"entity":killer})),str(ask(&"ActionGetRequested",{"entity":killer}))])
			check(false,"natural movement reaches the floor %d milestone; room=%s position=%s failures=%s" % [floor_no,game.current_room,str(body_anchor()),str(generation_failures)])
			break
		check(game.current_room==milestone["room"],"player stands in the generated floor %d milestone room" % floor_no)
		if floor_no<4:
			if not await reach_and_use_stairs(floor_no,milestone): break
			await process_frame
			await process_frame
		else:
			await process_frame
			await process_frame
			await process_frame
			if not await fight_boss_and_win(): break
			break
	game.queue_free()
	await process_frame
	print("Natural dungeon run (seed %d): %s" % [run_seed,"PASS" if failures==0 else "%d failed" % failures])
	quit(0 if failures==0 else 1)
