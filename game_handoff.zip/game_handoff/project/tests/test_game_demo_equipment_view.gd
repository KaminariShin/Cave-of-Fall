extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func key(game: Node, code: Key) -> void:
	var e:=InputEventKey.new(); e.pressed=true; e.keycode=code
	game._unhandled_key_input(e)
func gear() -> Dictionary:
	return ask(&"ComponentGetRequested",{"entity":&"demo_hero","component":&"equipment"}).get("data",{})
func inventory() -> Array:
	return ask(&"InventoryGetRequested",{"entity":&"demo_hero"})["data"]["items"]
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path := "user://demo_session.save"
	var exists:=FileAccess.file_exists(path)
	var old:=PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game)
	await process_frame
	check(game.initialized,"initial setup")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet rat")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":50.0}).get("accepted",false),"large inventory")
	check(ask(&"ItemCreateRequested",{"id":&"test_body","base_id":&"armor_cloth_body","item_level":1}).get("accepted",false),"body item")
	check(ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"test_body"}).get("accepted",false),"body to inventory")
	check(ask(&"ItemBaseRegisterRequested",{"base":{"id":"test_ring_base","name":"Тестовое кольцо","slot":"ring","tags":[],"materials":[{"material_id":"iron_common","count":1}]}}).get("accepted",false),"ring base")
	check(ask(&"ItemCreateRequested",{"id":&"test_ring","base_id":&"test_ring_base","item_level":1}).get("accepted",false),"ring item")
	check(ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"test_ring"}).get("accepted",false),"ring to inventory")
	check(ask(&"ItemCreateRequested",{"id":&"test_ring_two","base_id":&"test_ring_base","item_level":1}).get("accepted",false),"second ring")
	check(ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"test_ring_two"}).get("accepted",false),"second ring to inventory")
	check(game._toggle_inventory() and driver.advance_steps(1)==1 and game.inventory_open,"open")
	var body_index:=inventory().find(&"test_body")
	check(body_index>=0 and game._use_inventory_item(body_index) and driver.advance_steps(10)==10 and gear().get("body",null)==&"test_body","equip body through inventory")
	var ring_index:=inventory().find(&"test_ring")
	check(ring_index>=0 and game._use_inventory_item(ring_index) and driver.advance_steps(10)==10 and gear().get("ring1",null)==&"test_ring","equip ring through inventory")
	var second_index:=inventory().find(&"test_ring_two")
	check(second_index>=0 and game._use_inventory_item(second_index) and driver.advance_steps(10)==10 and gear().get("ring2",null)==&"test_ring_two","equip second ring")
	var time: float=driver.game_time
	key(game,KEY_TAB);check(game.equipment_view and game.equipment_page==0 and driver.game_time==time,"tab opens equipment without time")
	key(game,KEY_LEFT);check(game.equipment_page==0,"first page bound")
	key(game,KEY_4)
	check(gear().get("body",null)==&"test_body" and not inventory().has(&"test_body"),"body stays until action completes")
	check(driver.advance_steps(5)==5,"half removal")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save pending removal")
	check(driver.advance_steps(5)==5 and inventory().has(&"test_body") and gear().get("body",null)==null,"body moved once")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"restore pending removal")
	check(game.inventory_open and not game.equipment_view and game.equipment_page==0,"restore resets view")
	check(driver.advance_steps(5)==5 and inventory().count(&"test_body")==1 and gear().get("body",null)==null,"restored body removal once")
	key(game,KEY_TAB); key(game,KEY_9)
	check(driver.advance_steps(10)==10 and inventory().has(&"test_ring") and gear().get("ring1",null)==null,"ring removed by slot")
	key(game,KEY_RIGHT);check(game.equipment_page==1,"second slot page")
	key(game,KEY_RIGHT);check(game.equipment_page==1,"last page bound")
	key(game,KEY_1)
	check(driver.advance_steps(10)==10 and inventory().has(&"test_ring_two") and gear().get("ring2",null)==null,"second page removes second ring")
	var before: float=driver.game_time
	key(game,KEY_9);check(game.message.contains("нет слота") and driver.game_time==before,"empty row rejected")
	key(game,KEY_2);check(game.message.contains("слот пуст") and driver.game_time==before,"empty slot rejected")
	key(game,KEY_LEFT)
	var info:=ask(&"InventoryGetRequested",{"entity":game.HERO})
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":info["used_volume"]}).get("accepted",false),"fill capacity")
	key(game,KEY_1)
	check(not game._drop_pick.is_empty() and gear().get("main",null)==&"demo_sword" and driver.game_time==before,"full inventory asks for drop tile")
	key(game,KEY_ESCAPE)
	check(game._drop_pick.is_empty() and gear().get("main",null)==&"demo_sword","cancel drop preserves sword")
	key(game,KEY_TAB);check(not game.equipment_view,"return inventory")
	game.queue_free();await process_frame
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo equipment view: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
