extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func preview()->Dictionary:
	return ask(&"WeaponStrikeStaminaPreviewRequested",{"entity":&"hero","item":&"bow","strike":"bow_simple_shot"})
func run()->void:
	root.get_node("TimeDriver").set_process(false)
	check(root.get_node("EntityRegistry").create_entity(&"hero",{&"stats":{"CON":10,"STR":5,"DEX":5,"INT":5,"WIS":5,"PER":5}}),"hero")
	check(ask(&"ItemCreateRequested",{"id":&"bow","base_id":&"bow_simple","item_level":1}).get("accepted",false),"bow")
	var w:=ask(&"WeaponItemResolveRequested",{"item":&"bow"})
	check(w.get("found",false) and w.get("data",{}).get("type","")=="bow","bow weapon variant")
	var rows:=ask(&"WeaponStrikesGetRequested",{"item":&"bow"})
	check(rows.get("found",false) and rows.get("strikes",[]).size()==1,"one shot")
	if rows.get("strikes",[]).size()==1:
		var shot:Dictionary=rows["strikes"][0]
		check(shot.get("damage",0)==7 and shot.get("range",0)==15 and shot.get("speed_effectiveness",0)==1.0,"draft shot parameters")
	check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"Stamina","value":10}).get("accepted",false),"stamina")
	var p:=preview()
	check(p.get("accepted",false),"preview")
	if p.get("accepted",false):
		check(p["data"]["full_cost"]==5 and is_equal_approx(p["data"]["duration"],1.2),"5 stamina, baseline time 1.2")
	check(ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"Stamina"})["data"]["current"]==10,"no cost in preview")
	check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"Stamina","value":2}).get("accepted",false),"low stamina")
	p=preview()
	check(p.get("accepted",false) and p["data"]["spend"]==2 and p["data"]["damage_multiplier"]==0.5 and is_equal_approx(p["data"]["duration"],1.8),"standard low stamina penalties")
	check(ask(&"ComponentSetRequested",{"entity":&"hero","component":&"equipment","data":{"main":&"bow"}}).get("accepted",false),"equip for safe melee rejection")
	var melee:=ask(&"WeaponStrikeDamagePreviewRequested",{"entity":&"hero","item":&"bow","strike":"bow_simple_shot"})
	check(not melee.get("accepted",true) and str(melee.get("error","")).contains("дальнобойное"),"bow cannot be treated as melee damage")
	check(not ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"bow","strike":"bow_simple_shot","direction":Vector2.RIGHT}).get("accepted",true),"generic melee action cannot launch bow")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save content")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load content")
	check(preview().get("accepted",false),"preview after load")
	print("Bow shot content preview: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
