extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	var materials = root.get_node("DungeonChestMaterialsService")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11)}).get("accepted",false), "chest")
	var rng_min := func(e): e["value"] = e["min"]
	bus.subscribe(&"RngIntRequested", rng_min)
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var families: Dictionary = materials._families.duplicate(true)
	materials._families["iron_common"][2] = "missing"
	var failed := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12.0})
	materials._families = families
	check(not failed.get("accepted",true) and failed.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "bad material rejects and rolls back RNG and draft")
	var result := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12.0})
	bus.unsubscribe(&"RngIntRequested", rng_min)
	check(result.get("accepted",false), "attach all equipment")
	if not result.get("accepted",false): quit(1); return
	var draft: Dictionary = result["draft"].duplicate(true)
	check(draft["slots"].size() == 4 and not draft["complete"], "four incomplete slots")
	for slot in draft["slots"]:
		check(slot["category"] == "equipment" and slot["item_level"] == 5 and slot["materials"] == [{"material_id":"steel_tempered","count":3},{"material_id":"leather_scale","count":1}], "level 5 material fixed")
	var after: Dictionary = saver.collect_world_transition_snapshot()
	check(after.get("valid",false) and before["payload"]["sections"]["items"]["instances"] == after["payload"]["sections"]["items"]["instances"], "no items created")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save")
	var f := FileAccess.open("user://session.save", FileAccess.READ)
	var saved: Dictionary = bytes_to_var(f.get_buffer(f.get_length())); f.close()
	var bad: Dictionary = saved.duplicate(true)
	bad["sections"]["objects"]["objects"][&"chest"]["content_draft"]["slots"][0]["materials"][0]["count"] = 999
	f = FileAccess.open("user://session.save", FileAccess.WRITE); f.store_buffer(var_to_bytes(bad)); f.close()
	check(not ask(&"SessionLoadRequested",{}).get("accepted",true), "tampered material rejected")
	f = FileAccess.open("user://session.save", FileAccess.WRITE); f.store_buffer(var_to_bytes(saved)); f.close()
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ObjectGetRequested", {"object":&"chest"})["data"]["content_draft"] == draft, "materials persist unchanged")
	check(not ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12}).get("accepted",true), "no reroll after loading")
	print("Fixed chest materials tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
