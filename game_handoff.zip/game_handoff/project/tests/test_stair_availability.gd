extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func availability() -> Dictionary:
	return ask(&"DungeonStairAvailabilityRequested", {"entity":&"hero"})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"start", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(12,12), "size":4}).get("accepted", false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"start"}).get("accepted", false), "enter")
	check(ask(&"ObjectCreateRequested", {"entity":&"stairs_test", "room":&"start", "type":"stairs_down", "tile":Vector2i(16,13)}).get("accepted", false), "stair object")
	# Изоляция теста проверки: выбор тупика и размещение отдельно покрыты
	# тестом test_dungeon_milestones.gd на полноценном графе.
	root.get_node("DungeonStairsService").set("_state", {"floor":1, "room":&"start", "status":"placed", "object":&"stairs_test"})
	check(ask(&"EntityCreateRequested", {"entity":&"enemy"}).get("accepted", false), "enemy")
	# Центр героя (14,14), ближайший край тела врага — ровно в 18 тайлах.
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"enemy", "anchor":Vector2i(32,14), "size":2}).get("accepted", false), "enemy at boundary")
	check(ask(&"DetectionHostilitySetRequested", {"a":&"hero", "b":&"enemy", "hostile":true}).get("accepted", false), "hostility")
	check(not ask(&"DetectionPairGetRequested", {"observer":&"hero", "target":&"enemy"}).get("detected", false), "enemy not detected")
	var q := availability()
	check(q.get("accepted", false) and q.get("rule_allowed", false) and not q.get("transition_available", true), "exploration ignores nearby enemy; no actual transition")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":true})
	check(ask(&"GameModeGetRequested", {}).get("mode", "") == "combat", "force combat for test")
	q = availability()
	check(not q.get("rule_allowed", true) and q.get("blocking_enemy", &"") == &"enemy" and is_equal_approx(q.get("distance", 0.0), 18.0), "undetected hostile at inclusive boundary blocks")
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"enemy", "anchor":Vector2i(33,14)}).get("accepted", false), "enemy moves outside")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":true})
	q = availability()
	check(q.get("rule_allowed", false) and not q.get("transition_available", true), "enemy outside radius permits rule but not transition")
	var interpolated := func(e):
		if e.get("entity", null) == &"enemy":
			e["position"] = Vector2(31.5, 14.0)
			e["found"] = true
	root.get_node("EventBus").subscribe(&"MovementPositionGetRequested", interpolated)
	q = availability()
	check(not q.get("rule_allowed", true) and is_equal_approx(q.get("distance", 0.0), 17.5), "current interpolated enemy position is used")
	root.get_node("EventBus").unsubscribe(&"MovementPositionGetRequested", interpolated)
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"enemy", "anchor":Vector2i(22,14)}).get("accepted", false), "enemy near")
	check(ask(&"DetectionHostilitySetRequested", {"a":&"hero", "b":&"enemy", "hostile":false}).get("accepted", false), "make neutral")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":true})
	check(availability().get("rule_allowed", false), "neutral nearby body does not block")
	check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.1}).get("accepted", false), "start other action")
	check(not availability().get("rule_allowed", true), "busy actor cannot start")
	driver.advance_steps(10)
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":Vector2i(8,12)}).get("accepted", false), "move away from stair")
	check(not availability().get("rule_allowed", true), "cannot use staircase from afar")
	check(not ask(&"ObjectInteractRequested", {"entity":&"hero", "object":&"stairs_test"}).get("accepted", false), "legacy object interaction cannot pretend to descend")
	print("Stair availability tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
