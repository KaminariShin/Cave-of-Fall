extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func hp(id: StringName,key: String) -> int: return int(ask(&"ResourceGetRequested", {"entity":id,"resource":&"HP"})["data"][key])
func action(id: StringName) -> Dictionary: return ask(&"ActionGetRequested", {"entity":id})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ActionDefinitionRegisterRequested", {"data":{"id":&"phase_test","name":"test","type":&"physical","base_duration":0.03,"phase_completion":true}}).get("accepted",false),"definition")
	var maximum := hp(&"hero","max")
	var threshold := ceili(maximum/4.0)
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"phase_test"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"phase_test"}).get("accepted",false) and ask(&"SessionSaveRequested",{}).get("accepted",false),"start and save")
	check(not ask(&"CombatPhaseHitSubmitRequested", {"source":&"hero","target":&"npc","damage":threshold,"hp_before":maximum}).get("accepted",true),"outside phase rejected")
	var state := {"a":false,"b":false,"batch":false,"two":false,"resolved":false,"actions_finished":0,"before_done":false}
	var p1 := func(e):
		if e.get("actions",[]).size() == 2: state["a"] = ask(&"CombatPhaseHitSubmitRequested", {"source":&"hero","target":&"npc","damage":threshold,"hp_before":maximum}).get("accepted",false)
	var p2 := func(e):
		if e.get("actions",[]).size() == 2: state["b"] = ask(&"CombatPhaseHitSubmitRequested", {"source":&"npc","target":&"hero","damage":threshold,"hp_before":maximum}).get("accepted",false)
	var batch := func(e):
		state["batch"] = e.get("accepted",false)
		state["two"] = e.get("hit_count",0) == 2 and hp(&"hero","current") == maximum-threshold and hp(&"npc","current") == maximum-threshold
		state["before_done"] = state["actions_finished"] == 0
	var complete := func(e):
		if e.get("action",null) == &"phase_test": state["actions_finished"] += 1
	var stagger := func(e): state["resolved"] = e.get("outcomes",[]).size() == 2 and state["actions_finished"] == 2
	bus.subscribe(&"TimeCombatPhase",p1); bus.subscribe(&"TimeCombatPhase",p2); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"ActionCompleted",complete); bus.subscribe(&"PhaseStaggerResolved",stagger)
	check(driver.advance_steps(3) == 3 and state["a"] and state["b"] and state["batch"] and state["two"] and state["before_done"] and state["resolved"] and action(&"hero")["data"]["id"] == &"stagger" and action(&"npc")["data"]["id"] == &"stagger","two producers commit one batch and defer staggers")
	bus.unsubscribe(&"TimeCombatPhase",p1); bus.unsubscribe(&"TimeCombatPhase",p2); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"ActionCompleted",complete); bus.unsubscribe(&"PhaseStaggerResolved",stagger)
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore")
	var fail := {"first":false,"second_rejected":false,"reported":false}
	var duplicate := func(e):
		if e.get("actions",[]).size() == 2:
			var hit := {"source":&"hero","target":&"npc","damage":threshold,"hp_before":maximum}
			fail["first"] = ask(&"CombatPhaseHitSubmitRequested",hit.duplicate(true)).get("accepted",false)
			fail["second_rejected"] = not ask(&"CombatPhaseHitSubmitRequested",hit.duplicate(true)).get("accepted",true)
	var failed := func(e): fail["reported"] = not e.get("accepted",true) and e.has("error")
	bus.subscribe(&"TimeCombatPhase",duplicate); bus.subscribe(&"CombatPhaseBatchResolved",failed)
	check(driver.advance_steps(3) == 3 and fail["first"] and fail["second_rejected"] and fail["reported"] and hp(&"hero","current") == maximum and hp(&"npc","current") == maximum,"duplicate rejects entire collection, no damage")
	bus.unsubscribe(&"TimeCombatPhase",duplicate); bus.unsubscribe(&"CombatPhaseBatchResolved",failed)
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore again")
	var stale := {"failed":false,"a":false,"b":false}
	var conflicting := func(e):
		if e.get("actions",[]).size() == 2:
			stale["a"] = ask(&"CombatPhaseHitSubmitRequested", {"source":&"hero","target":&"npc","damage":1,"hp_before":maximum}).get("accepted",false)
			stale["b"] = not ask(&"CombatPhaseHitSubmitRequested", {"source":&"npc","target":&"npc","damage":1,"hp_before":maximum-1}).get("accepted",true)
	var on_stale := func(e): stale["failed"] = not e.get("accepted",true)
	bus.subscribe(&"TimeCombatPhase",conflicting); bus.subscribe(&"CombatPhaseBatchResolved",on_stale)
	check(driver.advance_steps(3) == 3 and stale["a"] and stale["b"] and stale["failed"] and hp(&"npc","current") == maximum,"conflicting HP snapshot rejects whole batch")
	bus.unsubscribe(&"TimeCombatPhase",conflicting); bus.unsubscribe(&"CombatPhaseBatchResolved",on_stale)
	print("Combat phase collector tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
