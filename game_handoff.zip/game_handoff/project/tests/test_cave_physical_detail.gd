extends SceneTree
var bus: Node
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool, label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus=root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"LevelGenerationRequested",{"level_id":&"detail_test","seed":55,"size_cells":Vector2i(160,160)}).get("accepted",false),"level")
	var state: Dictionary = ask(&"RoomAllGetRequested",{})
	var initial: Dictionary=state["rooms"][&"start"]
	var counts: Dictionary={}
	for tile in initial["floor_tiles"]:
		var c:=Vector2i(floori(float(tile.x)/4),floori(float(tile.y)/4))
		counts[c]=int(counts.get(c,0))+1
	var mixed:=0
	for c in counts:
		if counts[c]>0 and counts[c]<16: mixed+=1
	check(mixed>0,"actual initial room contains mixed cells")
	var snapshot := {"sections":{},"errors":[]};bus.publish(&"SnapshotCollectRequested",snapshot)
	var seed: int = snapshot["sections"]["rooms"]["cave_seed"]
	for row in [["start",Vector2i(5,5),Vector2i(11,11)],["corridor",Vector2i(55,30),Vector2i(10,5)],["passage",Vector2i(30,5),Vector2i(12,12)]]:
		var type: String=row[0];var origin: Vector2i=row[1];var size: Vector2i=row[2]
		var id:=StringName("detail_"+type)
		check(ask(&"RoomCreateRequested",{"id":id,"type":type,"origin_cell":origin,"size_cells":size}).get("accepted",false),type+" create")
		var geom:=ask(&"CaveGeometryBuildRequested",{"id":id,"type":type,"origin":origin,"size":size,"seed":seed,"entry_dir":""})
		var logical: Dictionary={}
		for c in geom["cells"]: logical[c]=true
		var region:=ask(&"SpaceRegionGetRequested",{"origin":origin*4,"size":size*4})
		var floor: Dictionary=region["floor"]
		var pocket_count:=0
		var corner_count:=0
		for x in range(size.x):
			for y in range(size.y):
				var cell:=Vector2i(x,y);var points: Array=[]
				for dx in range(4):
					for dy in range(4):
						if floor.has(origin*4+cell*4+Vector2i(dx,dy)): points.append(Vector2i(dx,dy))
				var adjacent: Array=[]
				for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
					if logical.has(cell+d): adjacent.append(d)
				if logical.has(cell):
					check(points.size()==16,type+" logical floor intact "+str(cell))
				elif x>0 and y>0 and x<size.x-1 and y<size.y-1 and not adjacent.is_empty():
					check(not points.is_empty(),type+" no uncarved wall at floor boundary "+str(cell))
				if not logical.has(cell) and not points.is_empty():
					pocket_count+=1
					check(x>0 and y>0 and x<size.x-1 and y<size.y-1,type+" boundary intact")
					check(points.size()<=10,type+" pocket cap")
					var neighbors: Array=[]
					for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
						if logical.has(cell+d): neighbors.append(d)
					if neighbors.is_empty():
						corner_count+=1
						var diagonal: Array=[]
						for d in [Vector2i(-1,-1),Vector2i(1,-1),Vector2i(1,1),Vector2i(-1,1)]:
							if logical.has(cell+d): diagonal.append(d)
						check(diagonal.size()==1 and points.size()==6,type+" diagonal rounded corner")
						if diagonal.size()==1:
							var d: Vector2i=diagonal[0]
							for p in points:
								var distance: int=(p.x if d.x<0 else 3-p.x)+(p.y if d.y<0 else 3-p.y)
								check(distance<=2,type+" diagonal shape")
					if not neighbors.is_empty():
						var side: Vector2i=neighbors[0]
						var depths: Array = [0,0,0,0]
						for p in points:
							var column: int = p.y if side.x != 0 else p.x
							depths[column] += 1
							var depth: int = p.x if side==Vector2i.LEFT else (3-p.x if side==Vector2i.RIGHT else (p.y if side==Vector2i.UP else 3-p.y))
							check(depth<3,type+" far edge intact")
							for j in range(depth):
								check(points.has(p+side*(depth-j)),type+" column contiguous")
						for i in range(3): check(absi(depths[i]-depths[i+1])<=2,type+" smooth neighboring depths")
						# На стыке двух стеновых клеток, обращённых к одной стороне,
						# профиль также не скачет более чем на две физические клетки.
						var next_cell: Vector2i=cell+(Vector2i.DOWN if side.x!=0 else Vector2i.RIGHT)
						if next_cell.x<size.x-1 and next_cell.y<size.y-1 and not logical.has(next_cell):
							var next_neighbors: Array=[]
							for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
								if logical.has(next_cell+d): next_neighbors.append(d)
							if not next_neighbors.is_empty() and next_neighbors[0]==side:
								var next_depth:=0
								for step in range(4):
									var local: Vector2i=Vector2i(step,0) if side==Vector2i.LEFT else (Vector2i(3-step,0) if side==Vector2i.RIGHT else (Vector2i(0,step) if side==Vector2i.UP else Vector2i(0,3-step)))
									if floor.has((origin+next_cell)*4+local):next_depth+=1
								check(absi(depths[3]-next_depth)<=2,type+" smooth across logical cell boundary")
		check(pocket_count>0,type+" has pockets")
		if type != "corridor": check(corner_count>0,type+" has rounded diagonal corners")
		print(type, " pockets: ",pocket_count," diagonal corners: ",corner_count)
		if type == "corridor":
			for direction in ["west","east"]:
				check(ask(&"RoomExitAddRequested",{"room":id,"id":StringName(direction),"dir":direction,"offset_cells":2}).get("accepted",false),"corridor exit "+direction)
			region=ask(&"SpaceRegionGetRequested",{"origin":origin*4,"size":size*4})
			floor=region["floor"]
			var remaining:=0
			for x in range(1,size.x-1):
				for y in range(1,size.y-1):
					if logical.has(Vector2i(x,y)): continue
					var count:=0
					for dx in range(4):
						for dy in range(4):
							if floor.has((origin+Vector2i(x,y))*4+Vector2i(dx,dy)): count+=1
					if count>0 and count<16: remaining+=1
			print("corridor mixed after exits: ",remaining)
			check(remaining>0,"corridor pockets remain after exits")
	var before: Dictionary=ask(&"RoomAllGetRequested",{})["rooms"]
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load")
	check(ask(&"RoomAllGetRequested",{})["rooms"]==before,"preserve geometry")
	print("Cave pockets: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
