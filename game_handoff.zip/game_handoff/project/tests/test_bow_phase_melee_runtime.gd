extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(40):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for actor in [&"hero",&"enemy",&"archer"]: check(ask(&"EntityCreateRequested",{"entity":actor}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"archer",Vector2i(2,5)],[&"hero",Vector2i(10,5)],[&"enemy",Vector2i(15,5)]]:
		check(ask(&"SpaceBodyPlaceRequested",{"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested",{"id":&"sword","base_id":&"sword_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":&"hero","item":&"sword"}).get("accepted",false),"sword")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"equip")
	check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"HP","value":1}).get("accepted",false) and ask(&"ResourceSetRequested",{"entity":&"enemy","resource":&"HP","value":1}).get("accepted",false),"lethal hp")
	check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"Stamina","value":7}).get("accepted",false),"stamina")
	var melee := ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(melee.get("accepted",false),"start melee")
	if not melee.get("accepted",false): quit(1); return
	var midpoint := ceili(float(melee["data"]["duration_steps"])/2.0)
	check(midpoint>30 and driver.advance_steps(midpoint-30)==midpoint-30,"advance before midpoint")
	var arrow := ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":7.0})
	check(arrow.get("accepted",false),"launch synchronized arrow " + str(arrow))
	var seen := {"events":[],"hp_before":-1.0}
	var phase := func(_e):
		if not root.get_node("ProjectileService")._phase_contacts.is_empty(): seen["hp_before"] = ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"HP"})["data"]["current"]
	var batch := func(e): seen["events"].append(e.duplicate(true))
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch)
	check(driver.advance_steps(30)==30,"advance same phase")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch)
	check(seen["hp_before"]==1 and seen["events"].size()==1 and seen["events"][0].get("accepted",false) and seen["events"][0].get("hit_count",0)==2,"arrow and melee in same packet " + str(seen))
	check(root.get_node("CombatService").is_entity_dead(&"hero") and root.get_node("CombatService").is_entity_dead(&"enemy"),"lethal arrow does not cancel simultaneous melee")
	print("Bow and melee same phase: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
