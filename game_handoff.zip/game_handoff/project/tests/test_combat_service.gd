extends SceneTree
var failures := 0
var events: Array = []
var finished: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var processes = root.get_node("ProcessRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"EntityDamaged", func(e): events.append({"kind": "damage", "data": e.duplicate()}))
	bus.subscribe(&"EntityDied", func(e): events.append({"kind": "death", "data": e.duplicate()}))
	check(entities.create_entity(&"hero") and entities.create_entity(&"rat") and entities.create_entity(&"other"), "entities")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "control")
	check(ask(bus, &"ActionStartRequested", {"entity": &"rat", "action": &"attack"})["accepted"], "enemy action")
	check(ask(bus, &"CombatStartActionRequested", {"entity": &"hero", "target": &"rat", "action": &"attack"})["accepted"], "player attack watches target")
	check(processes.register_process(&"projectile", 0.08, &"rat", true, Callable(), func(id): finished.append(id)), "independent projectile")
	check(processes.register_process(&"bound", 1.0, &"rat", false), "dependent process")
	driver.advance_steps(4)
	var rat_action := ask(bus, &"ActionGetRequested", {"entity": &"rat"})
	check(is_equal_approx(rat_action["data"]["elapsed"], 0.04), "enemy progresses during player action")
	check(ask(bus, &"ResourceSetRequested", {"entity": &"rat", "resource": &"HP", "value": 5})["accepted"], "hp setup")
	check(ask(bus, &"PipelineModifierRegisterRequested", {"entity": &"hero", "modifier": {"id": "double", "target": "damage.outgoing", "stage": "multiplicative", "op": "multiply", "value": 2}})["accepted"], "damage modifier")
	var damage := ask(bus, &"CombatDamageRequested", {"entity": &"rat", "source": &"hero", "amount": 3.0})
	check(damage["accepted"] and damage["applied"] == 5.0, "damage pipeline and actual clamped damage")
	check(events.size() == 2 and events[0]["kind"] == "damage" and events[1]["kind"] == "death" and events[1]["data"]["killer"] == &"hero", "damage then death")
	check(not ask(bus, &"ActionGetRequested", {"entity": &"rat"})["found"], "death cancels carrier action")
	check(not driver.is_action_active and not ask(bus, &"ActionGetRequested", {"entity": &"hero"})["found"], "target death cancels watched attack")
	check(not ask(bus, &"CombatDamageRequested", {"entity": &"rat", "source": &"hero", "amount": 2})["accepted"] and events.size() == 2, "dead cannot die twice")
	check(not ask(bus, &"ActionStartRequested", {"entity": &"rat", "action": &"attack"})["accepted"], "dead cannot act")
	check(entities.remove_entity(&"rat"), "remove dead entity")
	check(processes.has_process(&"projectile") and not processes.has_process(&"bound"), "projectile survives carrier removal")
	check(ask(bus, &"ActionStartRequested", {"entity": &"hero", "action": &"wait", "duration": 0.04})["accepted"], "advance remaining projectile time")
	driver.advance_steps(4)
	check(finished.has(&"projectile"), "projectile completed")
	check(ask(bus, &"CombatStartActionRequested", {"entity": &"hero", "target": &"other", "action": &"attack"})["accepted"], "watch other")
	driver.advance_steps(10)
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save active combat")
	ask(bus, &"CombatActionInvalidated", {"entity": &"hero"})
	check(not driver.is_action_active, "invalid action ends early")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load active combat")
	check(driver.is_action_active, "action restored")
	check(ask(bus, &"CombatDamageRequested", {"entity": &"other", "source": &"hero", "amount": 999})["accepted"], "lethal other")
	check(not driver.is_action_active, "restored watch cancels on target death")
	print("Combat tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
