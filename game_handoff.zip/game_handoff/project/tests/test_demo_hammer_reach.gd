extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func preview(entity: StringName, item: StringName, direction: Vector2) -> Dictionary:
	return ask(&"WeaponStrikePreviewRequested",{"entity":entity,"item":item,"strike":"demo_player_hammer_slam","kind":"physical","direction":direction})
func run() -> void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,32)}).get("accepted",false),"map")
	var floors: Array=[]
	for x in range(40):
		for y in range(32): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"enemy"]: check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"hero 4x4")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"enemy","anchor":Vector2i(14,11),"size":2}).get("accepted",false),"adjacent enemy 2x2")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":100}).get("accepted",false),"inventory")
	check(ask(&"ItemCreateRequested",{"id":&"hammer","base_id":&"hammer_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":&"hero","item":&"hammer"}).get("accepted",false),"hammer")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"hammer","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"equip")
	var prior:=ask(&"StrikeZoneBodyTestRequested",{"entity":&"hero","target":&"enemy","weapon_type":"hammer","range":4,"shape":{"type":"arc","angle_degrees":90,"reach_bound":true},"direction":Vector2.RIGHT})
	check(prior.get("accepted",false) and not prior.get("hit",true),"reproduce old blind spot")
	for row in [[Vector2i(14,11),Vector2.RIGHT],[Vector2i(8,11),Vector2.LEFT],[Vector2i(11,8),Vector2.UP],[Vector2i(11,14),Vector2.DOWN]]:
		check(ask(&"SpaceBodyMoveRequested",{"entity":&"enemy","anchor":row[0]}).get("accepted",false),"move adjacent target")
		var oriented:=preview(&"hero",&"hammer",row[1])
		var body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":&"enemy"}).get("data",{})
		var overlap:Dictionary=root.get_node("StrikeZoneService")._body_tiles_in_zone(&"enemy",body,oriented.get("zone",{}).get("tile_set",{}))
		check(oriented.get("accepted",false) and not overlap.get("tiles",[]).is_empty(),"adjacent hit from direction "+str(row[1]))
	check(ask(&"SpaceBodyMoveRequested",{"entity":&"enemy","anchor":Vector2i(14,11)}).get("accepted",false),"restore target")
	var p:=preview(&"hero",&"hammer",Vector2.RIGHT)
	check(p.get("accepted",false) and p.get("zone",{}).get("tile_set",{}).has(Vector2i(15,11)),"preview covers adjacent target")
	check(is_equal_approx(float(p.get("zone",{}).get("min_distance",-1)),1.7) and is_equal_approx(float(p.get("zone",{}).get("max_distance",-1)),7.35),"blind zone reduced and outer reach reduced by one")
	var former:=ask(&"StrikeZoneGetRequested",{"entity":&"hero","weapon_type":"hammer","range":4,"shape":{"type":"arc","angle_degrees":90,"reach_bound":true},"direction":Vector2.RIGHT})
	check(former.get("tile_set",{}).has(Vector2i(19,11)) and not p.get("zone",{}).get("tile_set",{}).has(Vector2i(19,11)),"outer tile removed")
	for sample in [[Vector2i(18,11),true],[Vector2i(19,11),false]]:
		check(ask(&"SpaceBodyMoveRequested",{"entity":&"enemy","anchor":sample[0]}).get("accepted",false),"set outer target")
		var body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":&"enemy"})["data"]
		var overlap:Dictionary=root.get_node("StrikeZoneService")._body_tiles_in_zone(&"enemy",body,p["zone"]["tile_set"])
		check((not overlap.get("tiles",[]).is_empty())==sample[1],"outer boundary "+str(sample[0]))
	check(ask(&"SpaceBodyMoveRequested",{"entity":&"enemy","anchor":Vector2i(14,11)}).get("accepted",false),"return target")
	var hp:float=ask(&"ResourceGetRequested",{"entity":&"enemy","resource":&"HP"})["data"]["current"]
	var start:=ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"hammer","strike":"demo_player_hammer_slam","direction":Vector2.RIGHT})
	check(start.get("accepted",false),"start hammer")
	var snapshot:=ask(&"WeaponStrikeHitSnapshotRequested",{"entity":&"hero","candidates":[&"enemy"]})
	check(snapshot.get("accepted",false) and snapshot.get("data",{}).get("targets",[]).size()==1,"real hit snapshot covers target")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"save and reload active attack")
	var restored:=ask(&"WeaponStrikeHitSnapshotRequested",{"entity":&"hero","candidates":[&"enemy"]})
	check(restored.get("accepted",false) and restored.get("data",{}).get("targets",[]).size()==1,"loaded attack hits")
	if start.get("accepted",false):
		var mid:=ceili(float(start["data"]["duration_steps"])/2.0)
		check(driver.advance_steps(mid)==mid and float(ask(&"ResourceGetRequested",{"entity":&"enemy","resource":&"HP"})["data"]["current"])<hp,"actual damage at midpoint")
	# The enemy uses the same demo strike and shares exactly the same adjustment.
	var enemy:=preview(&"enemy",&"hammer",Vector2.LEFT)
	check(enemy.get("accepted",false) and is_equal_approx(float(enemy.get("zone",{}).get("min_distance",-1)),0.7),"same hammer adjustment for enemy")
	print("Demo hammer reach: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
