extends SceneTree
var failures := 0
var repositioned := false
func _initialize() -> void: call_deferred("run_tests")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",text)
func ask(bus, name: StringName, e: Dictionary) -> Dictionary:
	bus.publish(name,e)
	return e
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	bus.subscribe(&"RoomRepositioned", func(e): if e["room"] == &"start": repositioned = true)
	ask(bus,&"SpaceMapConfigureRequested",{"size":Vector2i(256,256)})
	ask(bus,&"RoomCreateRequested",{"id":&"start","type":"start","origin_cell":Vector2i(20,20),"size_cells":Vector2i(11,11)})
	ask(bus,&"RoomExitAddRequested",{"room":&"start","id":&"east","dir":"east","offset_cells":5})
	ask(bus,&"EntityCreateRequested",{"entity":&"hero"})
	ask(bus,&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(118,100),"size":4})
	ask(bus,&"ControlledEntityRequested",{"entity":&"hero"})
	ask(bus,&"RoomEnterRequested",{"entity":&"hero","room":&"start"})
	ask(bus,&"RngSeedRequested",{"seed":42})
	var spawn := ask(bus,&"RoomSpawnRequested",{"room":&"start","player":&"hero","entry_tile":Vector2i(118,100),"depth":6,"demo_pool":true,"queue_delay":0.05})
	check(spawn["accepted"] and not spawn["units"].is_empty(),"spawn in start")
	check(ask(bus,&"SpaceBodyMoveRequested",{"entity":&"hero","anchor":Vector2i(120,100)})["accepted"],"start crossing")
	var room: Dictionary = ask(bus,&"RoomGetRequested",{"id":&"start"})["data"]
	check(room["exits"][0]["connected"],"child connected")
	var child: StringName = room["exits"][0]["childId"]
	for x in range(121,125): check(ask(bus,&"SpaceBodyMoveRequested",{"entity":&"hero","anchor":Vector2i(x,100)})["accepted"],"enter child")
	check(root.get_node("SpawnService")._current_room == child,"real transition to child")
	for x in range(125,129): check(ask(bus,&"SpaceBodyMoveRequested",{"entity":&"hero","anchor":Vector2i(x,100)})["accepted"],"clear child entrance")
	for x in range(127,119,-1): check(ask(bus,&"SpaceBodyMoveRequested",{"entity":&"hero","anchor":Vector2i(x,100)})["accepted"],"return through passage")
	check(root.get_node("SpawnService")._current_room == &"start" and repositioned,"real return repositions placed")
	check(ask(bus,&"RoomSpawnStatusRequested",{"room":&"start"})["data"]["placed"].size() == spawn["units"].size(), "same population")
	print("Spawn room transition tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
