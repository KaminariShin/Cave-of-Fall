extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(value: bool, label: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ",label)
func ask(name: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(name,e)
	return e
func plan(per: float, hits: Array, extra: Dictionary = {}) -> Dictionary:
	var e := {"per":per,"kind":&"direct_mixed","hits":hits}
	e.merge(extra,true)
	return ask(&"CriticalHitPlanRequested",e)
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var rng = root.get_node("RngService")._rng
	var start: int = rng.state
	var q := ask(&"CriticalHitPreviewRequested", {"per":10,"chance_add_percent":3,"chance_factor":2,"multiplier_factor":1.5})
	check(q.get("accepted",false) and q["data"]["base_chance_percent"] == 10 and q["data"]["chance_percent"] == 26 and q["data"]["critical_multiplier"] == 3 and rng.state == start,"preview formula no RNG")
	q = ask(&"CriticalHitPreviewRequested", {"per":-100,"multiplier_factor":0})
	check(q.get("accepted",false) and q["data"]["chance_percent"] == 0 and q["data"]["critical_multiplier"] == 1,"lower caps")
	check(ask(&"CriticalHitPreviewRequested", {"per":1000}).get("data",{}).get("chance_percent",-1) == 100,"upper cap")
	var hits := [{"target":&"z","physical":10.0,"magical":3.5},{"target":&"a","physical":7.0,"magical":8.0}]
	for bad in [
		{"per":10,"kind":&"periodic","hits":hits},
		{"per":10,"kind":&"environment","hits":hits},
		{"per":10,"kind":&"direct_physical","hits":hits},
		{"per":10,"kind":&"direct_mixed","hits":[hits[0],hits[0]]},
		{"per":10,"kind":&"direct_mixed","hits":[hits[0],{"target":&"b","physical":-1,"magical":0}]},
		{"per":10,"kind":&"direct_mixed","hits":[{"target":&"b","physical":NAN,"magical":0}]},
		{"per":10,"kind":&"direct_mixed","hits":hits,"chance_factor":-1}]:
		check(not ask(&"CriticalHitPlanRequested",bad).get("accepted",true) and rng.state == start,"invalid batch rejected before RNG")
	q = plan(-100,hits)
	check(q.get("accepted",false) and not q["data"]["hits"][0]["critical"] and q["data"]["hits"][0]["physical"] == 7 and q["data"]["hits"][0]["magical"] == 8 and rng.state != start,"zero chance and fixed roll per target")
	q = plan(1000,hits,{"multiplier_factor":1.5})
	check(q.get("accepted",false) and q["data"]["hits"][1]["critical"] and q["data"]["hits"][1]["physical"] == 30 and q["data"]["hits"][1]["magical"] == 10.5,"100 percent mixed damage uses one common multiplier")
	check(ask(&"CriticalHitPlanRequested", {"per":10,"kind":&"direct_physical","hits":[{"target":&"a","physical":2,"magical":0}]}).get("accepted",false),"direct physical")
	check(ask(&"CriticalHitPlanRequested", {"per":10,"kind":&"direct_magical","hits":[{"target":&"a","physical":0,"magical":2}]}).get("accepted",false),"direct magical")
	ask(&"RngSeedRequested", {"seed":7654})
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save RNG")
	var mixed := plan(10,hits)
	var final_state: int = rng.state
	check(mixed.get("accepted",false) and mixed["data"]["hits"][0]["target"] == &"a" and mixed["data"]["hits"][0]["roll"] != mixed["data"]["hits"][1]["roll"],"separate deterministic rolls per target")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore RNG")
	hits.reverse()
	var replay := plan(10,hits)
	check(replay.get("accepted",false) and replay["data"] == mixed["data"] and rng.state == final_state,"same result after load with reversed input order")
	print("Critical hit plan tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
