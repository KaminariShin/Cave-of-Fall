extends SceneTree
var failures:=0
var bus:Node
var started:Array=[]
func _initialize()->void:call_deferred("run")
func check(v:bool,s:String)->void:
	if not v:failures+=1;printerr("FAIL: ",s)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	check(ask(&"ObjectCreateRequested",{"entity":&"all_chest","type":"chest","room":game.ROOM,"tile":Vector2i(70,70),"inventory_capacity":20.0}).get("accepted",false),"chest")
	for row in [[&"chest_small_1",&"potion_hp"],[&"chest_big",&"hammer_simple"],[&"chest_small_2",&"potion_hp"]]:
		check(ask(&"ItemCreateRequested",{"id":row[0],"base_id":row[1],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":&"all_chest","item":row[0]}).get("accepted",false),"chest item")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":Vector2i(66,69)}).get("accepted",false),"approach")
	check(game._interact_chest() and driver.advance_steps(10)==10,"open chest")
	var used:float=ask(&"InventoryGetRequested",{"entity":game.HERO})["used_volume"]
	var small:float=ask(&"ItemVolumeRequested",{"item":&"chest_small_1"})["volume"]
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":used+2*small}).get("accepted",false),"capacity")
	var cb:=func(e):started.append(e["item"])
	bus.subscribe(&"ChestTakeStarted",cb)
	check(game._interact_chest() and game._pickup_open,"open selection")
	var time:float=driver.game_time
	game._pickup_all()
	check(started==[&"chest_small_1"] and driver.advance_steps(5)==5,"first begins")
	var save:=ask(&"SessionSaveRequested",{"slot":"demo"})
	check(save.get("accepted",false),"save chest queue " + str(save))
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load chest queue")
	check(driver.advance_steps(5)==5,"finish first")
	await process_frame
	check(started==[&"chest_small_1",&"chest_small_2"],"skip big and continue in order " + str(started))
	check(driver.advance_steps(10)==10,"finish second")
	await process_frame
	check(absf(driver.game_time-time-0.2)<0.00001,"only two actions cost time")
	check(game._pickup_open and not game._pickup_queue_running and game._pickup_candidates()==[&"chest_big"],"big item remains in open chest")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":100.0}).get("accepted",false),"capacity back")
	game._pickup_all()
	check(driver.advance_steps(10)==10,"collect last")
	await process_frame
	check(not game._pickup_open and game._inventory_items().has(&"chest_big"),"closes on empty chest")
	bus.unsubscribe(&"ChestTakeStarted",cb)
	game.queue_free();await process_frame
	print("Chest take all sequence: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
