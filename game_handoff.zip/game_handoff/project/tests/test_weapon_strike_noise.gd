extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e);return e
func check(ok: bool,label: String) -> void:
	if not ok: failures+=1;printerr("FAIL: ",label)
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(30,20)}).get("accepted",false),"map")
	var tiles: Array=[]
	for x in range(30):
		for y in range(20):tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"listener"]:check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"controlled")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(5,5),"size":2}).get("accepted",false),"hero body")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"listener","anchor":Vector2i(8,5),"size":2}).get("accepted",false),"listener body")
	check(ask(&"StatBaseSetRequested",{"entity":&"listener","stat":&"PER","value":0}).get("accepted",false),"listener cannot see at distance")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":100}).get("accepted",false),"inventory")
	check(ask(&"ItemCreateRequested",{"id":&"sword","base_id":&"sword_simple","item_level":1}).get("accepted",false),"sword")
	check(ask(&"InventoryAddRequested",{"entity":&"hero","item":&"sword"}).get("accepted",false),"add")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false),"equip")
	driver.advance_steps(10)
	var heard: Array=[]
	var noise_cb:=func(e):
		if e.get("source",null)==&"hero" and e.get("kind","")=="strike":heard.append(e.duplicate(true))
	bus.subscribe(&"NoiseStarted",noise_cb)
	var fail_phase:=func(e):
		for action in e.get("actions",[]):
			if action.get("entity",null)==&"hero" and action.get("action",null)==&"weapon_strike":
				ask(&"CombatPhaseHitSubmitRequested",{"source":&"", "target":&"listener", "damage":1,"hp_before":1})
	bus.subscribe(&"TimeCombatPhase",fail_phase)
	var fail_strike:=ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.LEFT})
	check(fail_strike.get("accepted",false),"failed-batch strike starts")
	driver.advance_steps(200)
	bus.unsubscribe(&"TimeCombatPhase",fail_phase)
	check(heard.is_empty(),"rejected phase emits no strike noise")
	var before_hp: float=ask(&"ResourceGetRequested",{"entity":&"listener","resource":&"HP"})["data"]["current"]
	var strike:=ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.LEFT})
	check(strike.get("accepted",false),"successful whiff starts")
	var midpoint:=ceili(float(strike.get("data",{}).get("duration_steps",0))/2.0)
	check(midpoint>0 and driver.advance_steps(midpoint)==midpoint,"reach phase midpoint")
	check(heard.size()==1,"one noise for committed whiff")
	if heard.size()==1:
		check(heard[0].get("position",null)==Vector2(6,6),"noise captures attacker center")
	check(ask(&"DetectionPairGetRequested",{"observer":&"listener","target":&"hero"}).get("detected",false),"listener hears strike")
	check(float(ask(&"ResourceGetRequested",{"entity":&"listener","resource":&"HP"})["data"]["current"])==before_hp,"whiff does not damage listener")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"noise is serializable")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"reload active noise")
	check(ask(&"DetectionPairGetRequested",{"observer":&"listener","target":&"hero"}).get("detected",false),"hearing restored")
	driver.advance_steps(200)
	var hit:=ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(hit.get("accepted",false),"targeted strike starts")
	driver.advance_steps(200)
	check(heard.size()==2,"exactly one additional sound for hit")
	check(float(ask(&"ResourceGetRequested",{"entity":&"listener","resource":&"HP"})["data"]["current"])<before_hp,"targeted strike actually hit")
	bus.unsubscribe(&"NoiseStarted",noise_cb)
	print("Weapon strike noise: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
