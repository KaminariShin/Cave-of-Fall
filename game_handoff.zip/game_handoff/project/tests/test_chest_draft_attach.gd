extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11)}).get("accepted",false), "chest")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	check(not ask(&"DungeonChestDraftAttachRequested", {"object":&"unknown", "kind":"boss", "depth":4}).get("accepted",true), "missing chest rejected")
	check(before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "rejection changes no world")
	var bus = root.get_node("EventBus")
	var invalidate := func(e): e["value"] = e["max"] + 1
	bus.subscribe(&"RngIntRequested", invalidate)
	var failed := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":4})
	bus.unsubscribe(&"RngIntRequested", invalidate)
	check(not failed.get("accepted",true) and failed.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "failed roll restores RNG and does not attach")
	var attached := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":4})
	check(attached.get("accepted",false) and not attached["draft"]["complete"] and attached["draft"]["slots"].size() >= 4, "attached boss draft")
	var draft: Dictionary = attached.get("draft", {}).duplicate(true)
	attached["draft"]["slots"].clear()
	check(ask(&"ObjectGetRequested", {"object":&"chest"})["data"]["content_draft"] == draft, "response is independent copy")
	var committed: Dictionary = saver.collect_world_transition_snapshot()
	check(committed.get("valid",false) and committed["payload"]["sections"]["items"]["instances"] == before["payload"]["sections"]["items"]["instances"], "valid snapshot no items created")
	check(not ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":4}).get("accepted",true) and committed["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "repeat cannot reroll")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(10,10), "size":4}).get("accepted",false), "body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	check(not ask(&"ObjectInteractRequested", {"entity":&"hero", "object":&"chest"}).get("accepted",true), "incomplete chest cannot open")
	check(ask(&"ItemCreateRequested", {"id":&"extra", "base_id":&"potion_hp", "item_level":1}).get("accepted",false), "extra")
	check(not ask(&"InventoryAddRequested", {"entity":&"chest", "item":&"extra"}).get("accepted",true), "no technical stocking of planned chest")
	check(ask(&"SessionSaveRequested", {}).get("accepted",false), "save")
	var f := FileAccess.open("user://session.save", FileAccess.READ)
	var saved: Dictionary = bytes_to_var(f.get_buffer(f.get_length()))
	f.close()
	var bad := saved.duplicate(true)
	bad["sections"]["objects"]["objects"][&"chest"]["content_draft"]["slots"][0]["base_id"] = &"missing"
	f = FileAccess.open("user://session.save", FileAccess.WRITE); f.store_buffer(var_to_bytes(bad)); f.close()
	check(not ask(&"SessionLoadRequested", {}).get("accepted",true), "malformed saved draft rejected")
	f = FileAccess.open("user://session.save", FileAccess.WRITE); f.store_buffer(var_to_bytes(saved)); f.close()
	check(ask(&"SessionLoadRequested", {}).get("accepted",false) and ask(&"ObjectGetRequested", {"object":&"chest"})["data"]["content_draft"] == draft, "save and load preserve plan")
	check(not ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"normal", "depth":0}).get("accepted",true), "no reroll after load")
	var tx: Dictionary = saver.run_world_transition_transaction(func(): return root.get_node("ObjectGenerationService").discard_objects_for_transition().get("accepted",false))
	check(tx.get("committed",false) and not ask(&"ObjectGetRequested", {"object":&"chest"}).get("found",true), "floor cleanup removes chest and draft")
	print("Chest draft attach tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
