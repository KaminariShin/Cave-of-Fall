extends SceneTree

const Accumulator = preload("res://scripts/accumulator.gd")
var failures := 0

func _initialize() -> void:
	call_deferred("run_tests")

func check(value: bool, message: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", message)

func run_tests() -> void:
	var first := Accumulator.accumulate(4, 0.4, 10, 0.0)
	check(first["ok"] and first["current"] == 4 and is_equal_approx(first["remainder"], 0.4), "fraction accumulates")
	var second := Accumulator.accumulate(first["current"], 0.7, 10, first["remainder"])
	check(second["current"] == 5 and second["applied"] == 1 and is_equal_approx(second["remainder"], 0.1), "fraction crosses one")
	var multiple := Accumulator.accumulate(1, 3.25, 10, 0.2)
	check(multiple["current"] == 4 and multiple["applied"] == 3 and is_equal_approx(multiple["remainder"], 0.45), "multiple whole units")
	var capped := Accumulator.accumulate(9, 4.75, 10, 0.2)
	check(capped["current"] == 10 and capped["applied"] == 1 and capped["remainder"] == 0.0, "cap clears remainder")
	var full := Accumulator.accumulate(10, 0.0, 10, 0.8)
	check(full["current"] == 10 and full["remainder"] == 0.0, "already full clears remainder")
	var zero := Accumulator.accumulate(0, 0.0, 0, 0.5)
	check(zero["remainder"] == 0.0, "zero capacity is full")
	var uncapped := Accumulator.accumulate_unbounded(0.75, 2.5)
	check(uncapped["whole"] == 3 and is_equal_approx(uncapped["remainder"], 0.25), "unbounded")
	check(not Accumulator.accumulate(1, -0.1, 10)["ok"], "reject negative amount")
	check(not Accumulator.accumulate(11, 1.0, 10)["ok"], "reject invalid current")
	check(not Accumulator.accumulate(0, 1.0, 10, 1.0)["ok"], "reject invalid remainder")
	check(not Accumulator.accumulate_unbounded(0.0, INF)["ok"], "reject infinity")
	print("Accumulator tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
