extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func click(game:Control,p:Vector2,button:MouseButton)->void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*p;e.button_index=button;e.pressed=true;game._input(e)
func key(game:Node,k:Key)->void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame;game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	var center:Vector2=game._map_origin()+game._camera_center_world()*game.STEP_PX
	var t:float=driver.game_time
	key(game,KEY_SPACE)
	check(game._direction_action=="attack" and driver.game_time==t and not driver.is_action_active,"select attack without time")
	click(game,center+Vector2(0,-120),MOUSE_BUTTON_LEFT)
	check(game.facing==Vector2i.UP and game._direction_action=="","left click chooses direction and starts attack")
	var attack:Dictionary=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})
	check(attack.get("active",false) and Vector2(attack["data"]["direction"]).normalized()==Vector2.UP,"attack uses mouse direction")
	driver.advance_steps(200)
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open inventory")
	var items:Array=game._inventory_items()
	check(game._use_inventory_item(items.find(&"demo_shield")) and driver.advance_steps(10)==10,"equip shield")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close inventory")
	center=game._map_origin()+game._camera_center_world()*game.STEP_PX
	key(game,KEY_B);click(game,center+Vector2(-100,0),MOUSE_BUTTON_LEFT)
	var shield:Dictionary=ask(&"ShieldBlockStatusRequested",{"entity":game.HERO})
	check(shield.get("active",false) and Vector2(shield.get("direction",Vector2.ZERO))==Vector2.LEFT,"block uses mouse direction")
	driver.advance_steps(100)
	var start:Vector2i=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
	var initial_cam:Vector2=game._camera_center_world()
	center=game._map_origin()+game._camera_center_world()*game.STEP_PX
	click(game,center+Vector2(100,0),MOUSE_BUTTON_RIGHT)
	check(ask(&"MovementPositionGetRequested",{"entity":game.HERO}).get("moving",false),"right click starts path")
	check(driver.advance_steps(5)==5,"advance partial step")
	var mid_cam:Vector2=game._camera_center_world()
	var anchor:Vector2i=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
	check(anchor==start and mid_cam.x>initial_cam.x and mid_cam.x<initial_cam.x+1,"camera uses continuous movement before physical step completes")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save mid-path")
	driver.advance_steps(3)
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load mid-path")
	check(game._camera_center_world().is_equal_approx(mid_cam),"camera resumes restored intermediate position")
	var loops:=0
	while loops<12 and (driver.is_action_active or loops==0):
		driver.advance_steps(100);await process_frame;loops+=1
	var finish:Vector2i=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
	check(finish.x>start.x+1 and finish.y==start.y,"path moves several physical cells")
	check(game._camera_center_world()==Vector2(finish)+Vector2(2,2),"camera ends centered")
	center=game._map_origin()+game._camera_center_world()*game.STEP_PX
	click(game,center+Vector2(-100,0),MOUSE_BUTTON_RIGHT)
	check(driver.is_action_active,"second path starts")
	key(game,KEY_ESCAPE)
	driver.advance_steps(100);await process_frame
	var stopped:Vector2i=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
	await process_frame
	check(not driver.is_action_active and stopped.x>=finish.x-1,"escape cancels remaining path, finishes current step")
	center=game._map_origin()+game._camera_center_world()*game.STEP_PX
	var now:float=driver.game_time
	click(game,center+Vector2(10000,0),MOUSE_BUTTON_RIGHT)
	check(not driver.is_action_active and driver.game_time==now,"click outside map ignored")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open menu")
	var f:Vector2i=game.facing
	click(game,Vector2(40,100),MOUSE_BUTTON_LEFT)
	check(game.facing==f and not driver.is_action_active,"menu prevents map input")
	game.queue_free();await process_frame
	print("Game demo mouse movement and camera: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
