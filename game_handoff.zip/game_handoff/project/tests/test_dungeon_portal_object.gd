extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(begin(4), "fourth floor")
	for i in range(1,17): check(add_room(i, "passage"), "chain")
	var boss_room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_16"})["data"]
	var p: Vector2i = boss_room["origin_cell"] * 4 + Vector2i(10,10)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":p, "size":4}).get("accepted", false), "hero placement")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "controlled")
	check(ask(&"RunStatisticsStartRequested", {"entity":&"hero","start_room":&"root"}).get("accepted",false), "start statistics")
	for floor_no in [2,3,4]: check(ask(&"RunStatisticsFloorBeginRequested", {"floor":floor_no,"start_room":&"root"}).get("accepted",false), "statistics floor")
	var depth: Variant = ask(&"DungeonRoomDepthRequested", {"room":&"node_16"})["depth"]
	var spawn := ask(&"RoomSpawnRequested", {"room":&"node_16", "player":&"hero", "entry_tile":p, "depth":depth, "pool":[]})
	check(spawn.get("accepted", false) and spawn.get("units", []).size() == 1, "spawn boss")
	if not spawn.get("accepted", false) or spawn.get("units", []).is_empty(): quit(1); return
	var boss_id: StringName = spawn["units"][0]["entity"]
	check(ask(&"RoomExitAddRequested", {"room":&"node_16", "id":&"south", "dir":"south", "offset_cells":5}).get("accepted", false), "outgoing")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":1}).get("accepted", false), "budget")
	var result := ask(&"RoomChildGenerateRequested", {"room":&"node_16", "exit":&"south"})
	check(result.get("accepted", false), "portal room generated")
	if not result.get("accepted", false): quit(1); return
	var portal := ask(&"DungeonPortalGetRequested", {})
	check(portal.get("found", false) and portal["data"].get("status", "") == "placed", "portal placed")
	if not portal.get("found", false) or portal["data"].get("status", "") != "placed": quit(1); return
	var oid: StringName = portal["data"]["object"]
	var obj := ask(&"ObjectGetRequested", {"object":oid})
	var tile: Vector2i = obj["data"]["tile"]
	check(obj["data"]["type"] == "portal_exit" and reachable_stair(result["child"], tile), "real reachable portal")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":result["child"]})["data"]
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var anchor := Vector2i(-1,-1)
	for dy in range(-4,2):
		for dx in range(-4,2):
			var a := tile + Vector2i(dx,dy)
			var adjacent := ((tile.x == a.x - 1 or tile.x == a.x + 4) and tile.y >= a.y and tile.y < a.y + 4) or ((tile.y == a.y - 1 or tile.y == a.y + 4) and tile.x >= a.x and tile.x < a.x + 4)
			if adjacent and ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&"hero"}).get("fits", false): anchor = a; break
		if anchor.x >= 0: break
	check(anchor.x >= 0 and ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":anchor}).get("accepted", false), "hero adjacent")
	var q := ask(&"DungeonPortalAvailabilityRequested", {"entity":&"hero"})
	check(q.get("accepted", false) and not q.get("rule_allowed", true), "locked before boss death")
	check(ask(&"DungeonBossEquipmentInstallRequested", {"entity":boss_id}).get("accepted", false), "equip before boss fight")
	check(ask(&"CombatDamageRequested", {"entity":boss_id, "source":&"hero", "amount":999999}).get("accepted", false), "defeat boss")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":false})
	q = ask(&"DungeonPortalAvailabilityRequested", {"entity":&"hero"})
	check(q.get("rule_allowed", false) and q.get("transition_available", false), "portal available")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":true})
	check(not ask(&"ObjectInteractRequested", {"entity":&"hero", "object":oid}).get("accepted",true), "no victory in combat")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":false})
	var before: float = driver.game_time
	var interaction := ask(&"ObjectInteractRequested", {"entity":&"hero", "object":oid, "duration":0.0})
	check(interaction.get("accepted", false) and interaction.get("rule_allowed", false) and driver.game_time == before, "portal victory without advancing time")
	check(ask(&"RunStatisticsGetRequested", {})["data"].get("outcome","") == "victory", "victory statistics recorded")
	check(not ask(&"ObjectInteractRequested", {"entity":&"hero", "object":oid}).get("accepted",true), "victory is one-shot")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":true})
	check(not ask(&"DungeonPortalAvailabilityRequested", {"entity":&"hero"}).get("rule_allowed", true), "combat condition undecided")
	ask(&"CombatDetectionChanged", {"entity":&"hero", "active":false})
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "portal save load")
	var file := FileAccess.open("user://session.save", FileAccess.READ)
	var snapshot: Dictionary = bytes_to_var(file.get_buffer(file.get_length()))
	file.close()
	var invalid: Dictionary = snapshot["sections"].duplicate(true)
	invalid["dungeon_portal"]["object"] = &"missing_portal"
	check(not ask(&"DungeonPortalSnapshotValidateRequested", {"sections":invalid}).get("valid", false), "reject incorrect portal reference")
	check(ask(&"DungeonPortalGetRequested", {})["data"]["object"] == oid, "same portal restored")
	check(ask(&"RunStatisticsGetRequested", {})["data"].get("outcome","") == "victory", "victory survives save and load")
	var forged: Dictionary = snapshot["sections"].duplicate(true)
	forged["spawn"]["boss"]["status"] = "alive"
	check(not ask(&"RunStatisticsSnapshotValidateRequested", {"sections":forged}).get("valid",true), "victory cannot have undefeated boss")
	check(ask(&"ObjectRemoveRequested", {"object":oid}).get("accepted", false), "remove portal")
	check(ask(&"DungeonPortalGetRequested", {})["data"]["status"] == "failed", "removed portal marks failure")
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":p}).get("accepted", false), "clear entrance before retry")
	var block_entry := func(e): e["fits"] = false
	var bus = root.get_node("EventBus")
	bus.subscribe(&"SpaceBodyFitsRequested", block_entry)
	check(not ask(&"DungeonPortalPlacementRetryRequested", {}).get("accepted", true), "blocked entrance prevents placement")
	bus.unsubscribe(&"SpaceBodyFitsRequested", block_entry)
	check(not ask(&"SessionSaveRequested", {}).get("accepted", true) and ask(&"DungeonPortalGetRequested", {})["data"]["status"] == "failed", "invalid finished world is not saved")
	check(ask(&"DungeonPortalPlacementRetryRequested", {}).get("accepted", false), "retry placement")
	check(not ask(&"ObjectCreateRequested", {"entity":&"fake_portal", "type":"portal_exit", "room":result["child"], "tile":tile}).get("accepted", true), "arbitrary portal rejected")
	print("Portal object tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
