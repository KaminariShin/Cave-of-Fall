extends SceneTree
var failures := 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(ok: bool, message: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", message)
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	var entities = root.get_node("EntityRegistry")
	var processes = root.get_node("ProcessRegistry")
	driver.set_process(false)
	bus.publish(&"RngSeedRequested", {"seed": 42})
	var one := {"min": 0, "max": 999}
	bus.publish(&"RngIntRequested", one)
	bus.publish(&"RngSeedRequested", {"seed": 42})
	var again := {"min": 0, "max": 999}
	bus.publish(&"RngIntRequested", again)
	check(one["value"] == again["value"], "same seed repeats")
	var rules := {}
	bus.publish(&"RulesetGetRequested", rules)
	check(rules["found"] and rules["ruleset"]["version"] == "0.193.0", "load ruleset")
	entities.create_entity(&"hero", {&"stats": {"CON": 5}})
	var control := {"entity": &"hero"}
	bus.publish(&"ControlledEntityRequested", control)
	var action := {"entity": &"hero", "action": &"attack"}
	bus.publish(&"ActionStartRequested", action)
	driver.advance_steps(30)
	var save := {}
	bus.publish(&"SessionSaveRequested", save)
	check(save.get("accepted", false), "save mid-action: " + str(save))
	var expected := {"min": 0, "max": 999}
	bus.publish(&"RngIntRequested", expected)
	driver.advance_steps(20)
	bus.publish(&"StatBaseSetRequested", {"entity": &"hero", "stat": &"CON", "value": 20})
	var load := {}
	bus.publish(&"SessionLoadRequested", load)
	check(load.get("accepted", false), "load: " + str(load))
	check(is_equal_approx(driver.game_time, 0.3) and driver.is_action_active, "restores time and action")
	check(entities.get_component(&"hero", &"stats")["CON"] == 5, "restores entity")
	var actual := {"min": 0, "max": 999}
	bus.publish(&"RngIntRequested", actual)
	check(actual["value"] == expected["value"], "restores rng state")
	check(processes.register_process(&"callback_process", 1.0, &"", true, func(_id, _dt): pass), "callback process")
	var rejected := {}
	bus.publish(&"SessionSaveRequested", rejected)
	check(not rejected.get("accepted", false), "unsafe callback cannot be saved")
	processes.interrupt_process(&"callback_process")
	var meta := {"data": {"craft": 2}}
	bus.publish(&"MetaSaveRequested", meta)
	var meta_read := {}
	bus.publish(&"MetaLoadRequested", meta_read)
	check(meta.get("accepted", false) and meta_read.get("data", {}).get("craft", -1) == 2, "meta separate")
	bus.publish(&"EntityDied", {"entity": &"hero"})
	var after_death := {}
	bus.publish(&"SessionSaveRequested", after_death)
	check(not after_death.get("accepted", false) and not FileAccess.file_exists("user://session.save"), "death deletes and blocks session save")
	check(FileAccess.file_exists("user://meta.save"), "death preserves meta")
	print("Services tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
