extends SceneTree
var failures := 0
var finished: Array = []
var failed: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func run() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"DungeonDescended", func(e): finished.append(e.duplicate(true)))
	bus.subscribe(&"DungeonDescentFailed", func(e): failed.append(e.duplicate(true)))
	var level := ask(&"LevelGenerationRequested", {"level_id":&"floor1", "seed":11, "size_cells":Vector2i(100,60), "start_origin":Vector2i(2,2), "deadend_budget":1})
	check(level.get("accepted", false), "real level")
	check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":&"start"}).get("accepted", false), "tracking")
	var parent: StringName = &"start"
	for i in range(1,7):
		var id := StringName("chain_%d" % i)
		var x := 13 + (i-1)*12
		check(ask(&"RoomCreateRequested", {"id":id, "type":"deadend" if i == 6 else "passage", "origin_cell":Vector2i(x,2), "size_cells":Vector2i(12,12)}).get("accepted", false), "chain room " + str(i))
		if i > 1: check(ask(&"RoomExitAddRequested", {"room":parent, "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false), "parent exit")
		check(ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":"west", "offset_cells":5}).get("accepted", false), "entry")
		check(ask(&"RoomExitConnectRequested", {"room":parent, "exit":&"east", "other_room":id, "other_exit":&"entry"}).get("accepted", false), "connect " + str(i))
		if i == 6:
			var paint: Array = []
			for yy in range(9,55):
				for xx in range(x*4+1, x*4+47): paint.append(Vector2i(xx,yy))
			check(ask(&"SpaceTilesSetRequested", {"tiles":paint, "kind":1}).get("accepted", false), "test geometry for accessible stair")
		ask(&"RoomChildGenerated", {"room":parent, "child":id})
		parent = id
	var stair := ask(&"DungeonStairGetRequested", {})
	check(stair.get("found", false) and stair["data"].get("status", "") == "placed", "real selected stair " + str(stair))
	if failures > 0:
		quit(1)
		return
	var stair_id: StringName = stair["data"]["object"]
	var tile: Vector2i = ask(&"ObjectGetRequested", {"object":stair_id})["data"]["tile"]
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RunStatisticsStartRequested", {"entity":&"hero", "start_room":&"start"}).get("accepted", false), "stats")
	var placed := false
	for y in range(tile.y-4, tile.y+1):
		for x in range(tile.x-4, tile.x+1):
			var a := Vector2i(x,y)
			if not (((tile.x == a.x - 1 or tile.x == a.x + 4) and tile.y >= a.y and tile.y < a.y + 4) or ((tile.y == a.y - 1 or tile.y == a.y + 4) and tile.x >= a.x and tile.x < a.x + 4)): continue
			if ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":a, "size":4}).get("accepted", false):
				placed = true
				break
		if placed: break
	check(placed and ask(&"RoomEnterRequested", {"entity":&"hero", "room":parent}).get("accepted", false), "hero adjacent to stair")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted", false), "inventory")
	check(ask(&"ItemCreateRequested", {"id":&"potion", "base_id":&"potion_hp", "item_level":1}).get("accepted", false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"potion"}).get("accepted", false), "hero item")
	check(ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"HP", "value":23}).get("accepted", false), "hp")
	check(not ask(&"ActionStartRequested", {"entity":&"hero", "action":&"stairs_descend", "duration":0.01}).get("accepted", false), "cannot bypass protocol")
	var request := {"entity":&"hero", "level_id":&"floor2", "seed":22, "size_cells":Vector2i(48,48), "deadend_budget":1}
	var start := ask(&"DungeonDescendRequested", request.duplicate())
	check(start.get("accepted", false), "start descent: " + str(start.get("error", "")))
	if not start.get("accepted", false):
		quit(1)
		return
	check(not ask(&"ActionInterruptRequested", {"entity":&"hero", "action":&"stagger"}).get("accepted", false), "stagger does not interrupt descent")
	check(ask(&"EntityCreateRequested", {"entity":&"unexpected"}).get("accepted", false), "unexpected entity after start")
	check(driver.advance_steps(10) == 10 and failed.size() == 1 and finished.is_empty() and failed[0].get("rolled_back", false), "late cleanup blocker rolls back transition")
	check(ask(&"LevelMapGetRequested", {})["map_data"]["level_id"] == &"floor1" and ask(&"ObjectGetRequested", {"object":stair_id}).get("found", false), "failed descent keeps old level and stair")
	check(ask(&"EntityRemoveRequested", {"entity":&"unexpected"}).get("accepted", false), "remove blocker")
	failed.clear()
	start = ask(&"DungeonDescendRequested", request.duplicate())
	check(start.get("accepted", false), "restart descent after failure")
	check(driver.advance_steps(5) == 5 and finished.is_empty(), "half duration not completed")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save during descent")
	var snapshot: Dictionary = root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]
	var bad_snapshot := snapshot.duplicate(true)
	bad_snapshot["dungeon_descent"]["stair"] = &"not_the_stair"
	check(not ask(&"DungeonDescentSnapshotValidateRequested", {"sections":bad_snapshot}).get("valid", true), "corrupt stair rejected")
	bad_snapshot = snapshot.duplicate(true)
	bad_snapshot["dungeon_descent"]["phase"] = "ready"
	check(not ask(&"DungeonDescentSnapshotValidateRequested", {"sections":bad_snapshot}).get("valid", true), "cannot restore intermediate ready phase")
	check(driver.advance_steps(4) == 4 and finished.is_empty(), "no early completion")
	check(ask(&"SessionLoadRequested", {}).get("accepted", false), "load during descent")
	check(driver.advance_steps(5) == 5, "remaining duration")
	check(finished.size() == 1 and failed.is_empty(), "descent succeeds: " + str(failed))
	if finished.size() == 1:
		var level2 := ask(&"LevelMapGetRequested", {})
		check(level2.get("found", false) and level2["map_data"]["level_id"] == &"floor2" and ask(&"RunStatisticsGetRequested", {})["data"]["floor"] == 2, "level and floor advanced")
		check(not ask(&"ObjectGetRequested", {"object":stair_id}).get("found", false) and ask(&"ItemGetRequested", {"item":&"potion"}).get("found", false) and float(ask(&"ResourceGetRequested", {"entity":&"hero", "resource":&"HP"})["data"]["current"]) == 23, "old stairs removed, player state retained")
		check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save after descent")
	print("Dungeon descent tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
