extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(80,80)})["accepted"], "map")
	check(ask(bus, &"RoomCreateRequested", {"id": &"A", "type": "start", "origin_cell": Vector2i(1,1), "size_cells": Vector2i(11,11)})["accepted"], "room")
	check(entities.create_entity(&"hero"), "hero")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(10,10), "size": 4})["accepted"], "hero body")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "control")
	check(ask(bus, &"RoomEnterRequested", {"entity": &"hero", "room": &"A"})["accepted"], "enter")
	var small_seed := -1
	for seed in range(100):
		ask(bus, &"RngSeedRequested", {"seed": seed})
		if float(ask(bus, &"RngFloatRequested", {})["value"]) < 0.8:
			small_seed = seed
			break
	ask(bus, &"RngSeedRequested", {"seed": small_seed})
	check(ask(bus, &"RatSpawnRequested", {"entity": &"rat", "anchor": Vector2i(16,10)})["accepted"], "rat")
	ask(bus, &"StatBaseSetRequested", {"entity": &"hero", "stat": &"PER", "value": 6})
	ask(bus, &"StatBaseSetRequested", {"entity": &"rat", "stat": &"PER", "value": 6})
	check(ask(bus, &"AIRegisterRequested", {"entity": &"rat", "room": &"A", "role": "rat", "target": &"hero", "detected": false, "wait_duration": 0.05, "bite": {"damage": 3, "duration": 0.05, "stamina_cost": 0}, "movement": {"actor_type": "rat", "K_move": 10}})["accepted"], "AI registration")
	check(ask(bus, &"DetectionHostilitySetRequested", {"a": &"hero", "b": &"rat", "hostile": true})["accepted"], "hostility")
	check(ask(bus, &"ActionStartRequested", {"entity": &"hero", "action": &"wait", "duration": 3})["accepted"], "wait")
	driver.advance_steps(1)
	check(ask(bus, &"AIGetRequested", {"entity": &"rat"})["data"]["detected"], "automatically set AI target detection")
	driver.advance_steps(1)
	check(ask(bus, &"ActionGetRequested", {"entity": &"rat"})["data"]["id"] == &"move", "AI acts on detection")
	check(ask(bus, &"HotbarGetRequested", {})["hostiles"] == [&"rat"], "mutual combat detection")
	ask(bus, &"PlayerRoomChanged", {"entity": &"hero", "room": &"B", "room_type": &"start"})
	check(not ask(bus, &"DetectionPairGetRequested", {"observer": &"rat", "target": &"hero"})["detected"], "off-room observer loses target")
	check(not ask(bus, &"AIGetRequested", {"entity": &"rat"})["data"]["detected"] and not ask(bus, &"HotbarGetRequested", {})["combat_detected"], "loss propagated to AI and hotbar")
	check(ask(bus, &"SessionSaveRequested", {})["accepted"] and ask(bus, &"SessionLoadRequested", {})["accepted"], "save/load detection with inactive AI")
	ask(bus, &"PlayerRoomChanged", {"entity": &"hero", "room": &"A", "room_type": &"start"})
	check(ask(bus, &"AIGetRequested", {"entity": &"rat"})["data"]["detected"], "detection returns on room re-entry")
	check(ask(bus, &"DetectionHostilitySetRequested", {"a": &"hero", "b": &"rat", "hostile": false})["accepted"], "remove hostility")
	check(not ask(bus, &"AIGetRequested", {"entity": &"rat"})["data"]["detected"] and not ask(bus, &"HotbarGetRequested", {})["combat_detected"], "hostility removal updates AI and hotbar")
	print("Detection AI tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
