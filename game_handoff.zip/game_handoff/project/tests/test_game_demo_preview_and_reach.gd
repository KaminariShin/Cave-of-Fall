extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(v:bool,label:String)->void:
	if not v:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func key(game:Node,k:Key)->void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func click(game:Control,p:Vector2)->void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*p;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;game._input(e)
func strike(actor:StringName,item:StringName,id:String)->Dictionary:
	return ask(&"WeaponStrikePreviewRequested",{"entity":actor,"item":item,"strike":id,"kind":"physical","direction":Vector2.RIGHT})
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame;game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	var old:=strike(game.HERO,&"demo_sword","sword_simple_thrust")
	for pair in [["demo_player_sword_thrust",2],["demo_rat_thrust",4],["demo_creature_thrust",3]]:
		var fresh:=strike(game.HERO,&"demo_sword",pair[0])
		check(fresh.get("accepted",false) and absf(old["zone"]["max_distance"]-fresh["zone"]["max_distance"]-float(pair[1]))<0.0001,"range reduction "+pair[0])
	var rs:=strike(game.RAT,&"demo_rat_sword","demo_rat_thrust")
	check(rs.get("accepted",false) and rs["strike_data"]["range"]==2,"rat strike matches requested range")
	var rat_ai:Dictionary=ask(&"AIGetRequested",{"entity":game.RAT}) # AI was disabled above; setup verified through definitions below
	var defs:=ask(&"WeaponStrikesGetRequested",{"item":&"demo_sword"})
	var hammer_id=&"test_preview_hammer"
	check(ask(&"ItemCreateRequested",{"id":hammer_id,"base_id":&"hammer_simple","item_level":1}).get("accepted",false),"create hammer")
	var definitions:=ask(&"WeaponStrikesGetRequested",{"item":hammer_id})
	var h_old:Dictionary={};var h_new:Dictionary={}
	for entry in definitions.get("strikes",[]):
		if entry["id"]=="hammer_simple_slam":h_old=entry
		if entry["id"]=="demo_player_hammer_slam":h_new=entry
	check(not h_old.is_empty() and not h_new.is_empty() and h_old["range"]-h_new["range"]==2,"player hammer reduced, boss original unchanged")
	var center:Vector2=game._map_origin()+game._camera_center_world()*game.STEP_PX
	var time:float=driver.game_time
	var stamina:float=ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"})["data"]["current"]
	key(game,KEY_SPACE)
	var point:=center+Vector2(120,-35)
	var preview:Dictionary=game._direction_preview(point)
	check(preview.get("kind","")=="attack" and not preview.get("tiles",[]).is_empty() and driver.game_time==time,"attack preview without starting action")
	check(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"})["data"]["current"]==stamina,"preview free")
	click(game,point)
	check(game.pending_attack and game.attack_tiles==preview["tiles"],"chosen attack preview exactly equals started zone")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel attack")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open")
	var items:Array=game._inventory_items()
	check(game._use_inventory_item(items.find(&"demo_shield")) and driver.advance_steps(10)==10,"equip shield")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close")
	center=game._map_origin()+game._camera_center_world()*game.STEP_PX
	for direction in [Vector2.UP,Vector2.RIGHT,Vector2.DOWN,Vector2.LEFT,Vector2(1,1).normalized(),Vector2(-1,0.4).normalized(),Vector2(0.2,-1).normalized()]:
		key(game,KEY_B)
		point=center+Vector2(direction)*100
		preview=game._direction_preview(point)
		check(preview.get("kind","")=="block" and preview.get("tiles",[]).size()==1,"preview small shield "+str(direction))
		click(game,point)
		var real:=ask(&"ShieldBlockZoneRequested",{"entity":game.HERO})
		check(real.get("accepted",false) and real["data"]["tiles"]==preview.get("tiles",[]),"block preview equals actual "+str(direction))
		check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel block")
	game.queue_free();await process_frame
	print("Game demo action preview and reduced reach: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
