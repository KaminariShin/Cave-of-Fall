extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func preview(actor:StringName,item:StringName)->Dictionary:
	return ask(&"BowShotDamagePreviewRequested",{"entity":actor,"item":item,"strike":"bow_simple_shot"})
func run()->void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var bus=root.get_node("EventBus")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"EntityCreateRequested",{"entity":&"npc"}).get("accepted",false),"npc")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":100}).get("accepted",false),"inventory")
	check(ask(&"StatBaseSetRequested",{"entity":&"hero","stat":&"DEX","value":10}).get("accepted",false),"DEX 10")
	check(ask(&"StatBaseSetRequested",{"entity":&"hero","stat":&"INT","value":0}).get("accepted",false),"INT 0")
	var snap:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()
	var schema:Dictionary=root.get_node("DungeonChestLearningService").schema_for(&"bow_simple",snap["payload"]["sections"]["items"]["bases"])
	check(ask(&"ItemCreateRequested",{"id":&"bow","base_id":&"bow_simple","item_level":20,"rarity":&"magic","learning":schema}).get("accepted",false),"bow")
	var mod:Dictionary={"id":&"suf_physical_damage","category":"suffix","stat":"physical_damage","tier":3,"value":1.0,"level_req":1,"material_id":&"leather_thin","unlock_after":5}
	check(ask(&"ItemModAttachRequested",{"item":&"bow","mod":mod}).get("accepted",false),"physical mod")
	check(ask(&"InventoryAddRequested",{"entity":&"hero","item":&"bow"}).get("accepted",false),"ownership")
	var q:=preview(&"hero",&"bow")
	check(q.get("accepted",false) and q["data"]["stat"]==&"DEX" and q["data"]["learning_multiplier"]==0.5 and q["data"]["physical_mod_bonus"]==0.0 and is_equal_approx(q["data"]["raw_damage"],4.375),"DEX plus unknown item penalty")
	check(not preview(&"npc",&"bow").get("accepted",true),"ownership required")
	var reveal:=func(e):
		if e.get("item",null)==&"bow" and e.get("found",false):e["item_data"]["learning_state"]["progress"]=5
	bus.subscribe(&"ItemGetRequested",reveal)
	q=preview(&"hero",&"bow")
	check(q.get("accepted",false) and q["data"]["learning_multiplier"]==0.6 and q["data"]["physical_mod_bonus"]==1.0 and is_equal_approx(q["data"]["raw_damage"],6.5),"mod before characteristic multiplier")
	bus.unsubscribe(&"ItemGetRequested",reveal)
	check(not ask(&"WeaponStrikeDamagePreviewRequested",{"entity":&"hero","item":&"bow","strike":"bow_simple_shot"}).get("accepted",true),"melee API rejects bow")
	check(ask(&"StatBaseSetRequested",{"entity":&"hero","stat":&"INT","value":100}).get("accepted",false),"INT raised")
	q=preview(&"hero",&"bow")
	check(q.get("accepted",false) and is_equal_approx(q["data"]["raw_damage"],8.75),"DEX ten raises base 7 to 8.75")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and is_equal_approx(float(preview(&"hero",&"bow").get("data",{}).get("raw_damage",-1)),8.75),"save restore")
	print("Bow damage preview: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
