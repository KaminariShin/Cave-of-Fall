extends SceneTree
var failures := 0
var explosions: Array = []
var expirations: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func hp(id: StringName) -> float: return float(ask(&"ResourceGetRequested", {"entity":id, "resource":&"HP"})["data"]["current"])
func run() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	var service = root.get_node("ProjectileService")
	var save = root.get_node("SaveService")
	driver.set_process(false)
	bus.subscribe(&"ProjectileExplosion", func(e): explosions.append(e.duplicate(true)))
	bus.subscribe(&"ProjectileExpired", func(e): expirations.append(e.duplicate(true)))
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(60,40)}).get("accepted", false), "map")
	var tiles: Array = []
	for y in range(40):
		for x in range(60): tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":tiles, "kind":1}).get("accepted", false), "floor")
	for id in [&"hero", &"enemy"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted", false), "create "+str(id))
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(3,5), "size":2}).get("accepted", false), "hero body")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"enemy", "anchor":Vector2i(3,20), "size":2}).get("accepted", false), "enemy body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "hero control")
	var nested := {"tried":false, "accepted":true}
	var during_launch := func(_e):
		nested["tried"] = true
		nested["accepted"] = save.run_world_transition_transaction(func(): return true).get("committed", true)
	bus.subscribe(&"ProjectileLaunched", during_launch)
	var ball := ask(&"ProjectileLaunchRequested", {"entity":&"enemy", "weapon_type":"fireball", "direction":Vector2.RIGHT, "speed":2.0, "range":20.0})
	bus.unsubscribe(&"ProjectileLaunched", during_launch)
	var arrow := ask(&"ProjectileLaunchRequested", {"entity":&"hero", "weapon_type":"bow", "direction":Vector2.RIGHT, "speed":2.0, "range":20.0, "damage":4.0})
	check(ball.get("accepted", false) and arrow.get("accepted", false), "real fireball and arrow")
	check(nested["tried"] and not nested["accepted"], "transition unavailable during launch callback")
	if not ball.get("accepted", false) or not arrow.get("accepted", false):
		quit(1)
		return
	var first: StringName = ball["id"]
	var second: StringName = arrow["id"]
	check(ask(&"EntityRemoveRequested", {"entity":&"enemy"}).get("accepted", false), "owner removed")
	check(ask(&"ProjectileGetRequested", {"id":first})["found"], "independent projectile survives owner")
	check(ask(&"ProcessStartRequested", {"id":&"unrelated", "entity":&"hero", "duration":10.0, "independent":true}).get("accepted", false), "unrelated process")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save flight")
	check(not ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "projectiles block map reset")
	check(not service.discard_projectiles_for_transition().get("accepted", false), "outside transaction denied")
	var before_health := hp(&"hero")
	var before_first: Dictionary = ask(&"ProjectileGetRequested", {"id":first})["data"]
	var before_second: Dictionary = ask(&"ProjectileGetRequested", {"id":second})["data"]
	var out := {}
	var observed := {"nested":true, "launch":true, "restart":true, "other_stopped":false}
	var on_expired := func(e):
		if e.get("id", &"") != first or e.get("reason", &"") != &"floor_transition": return
		observed["nested"] = service.discard_projectiles_for_transition().get("accepted", true)
		observed["launch"] = ask(&"ProjectileLaunchRequested", {"entity":&"hero", "weapon_type":"fireball", "direction":Vector2.RIGHT, "speed":2.0}).get("accepted", true)
		observed["restart"] = ask(&"ProcessStartRequested", {"id":first, "entity":&"hero", "duration":1.0, "independent":true}).get("accepted", true)
		observed["other_stopped"] = ask(&"ProcessInterruptRequested", {"id":second, "reason":&"cancelled"}).get("accepted", false)
	bus.subscribe(&"ProjectileExpired", on_expired)
	var result: Dictionary = save.run_world_transition_transaction(func(): out["r"] = service.discard_projectiles_for_transition(); return true)
	bus.unsubscribe(&"ProjectileExpired", on_expired)
	check(not observed["nested"] and not observed["launch"] and not observed["restart"] and observed["other_stopped"], "reentrancy and conflicting interruption")
	check(not out["r"].get("accepted", true) and result.get("rolled_back", false), "partial failure forces rollback")
	check(ask(&"ProjectileGetRequested", {"id":first}).get("data", {}) == before_first and ask(&"ProjectileGetRequested", {"id":second}).get("data", {}) == before_second, "shots restored")
	check(ask(&"ProcessGetRequested", {"id":first})["found"] and ask(&"ProcessGetRequested", {"id":second})["found"], "flight processes restored")
	check(hp(&"hero") == before_health and explosions.is_empty(), "no damage or explosion during cancellation")
	expirations.clear()
	result = save.run_world_transition_transaction(func(): out["r"] = service.discard_projectiles_for_transition(); return out["r"].get("accepted", false))
	check(result.get("committed", false) and out["r"].get("projectiles", []) == [first,second], "both projectiles removed")
	check(not ask(&"ProjectileGetRequested", {"id":first})["found"] and not ask(&"ProjectileGetRequested", {"id":second})["found"] and not ask(&"ProcessGetRequested", {"id":first})["found"] and not ask(&"ProcessGetRequested", {"id":second})["found"], "no shots or flight processes")
	check(ask(&"ProcessGetRequested", {"id":&"unrelated"})["found"] and ask(&"EntityGetRequested", {"entity":&"hero"})["found"], "unrelated process and hero retained")
	check(expirations.size() == 2 and expirations[0]["reason"] == &"floor_transition" and expirations[1]["reason"] == &"floor_transition" and explosions.is_empty() and hp(&"hero") == before_health, "no impact, explosion, damage")
	check(not ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "shot noises still protect map after projectile removal")
	result = save.run_world_transition_transaction(func(): return root.get_node("DetectionService").discard_noises_for_transition().get("accepted", false))
	check(result.get("committed", false) and ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "map guard released after noise removal")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and not ask(&"ProjectileGetRequested", {"id":first})["found"], "cleanup survives save")
	print("Floor projectile cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
