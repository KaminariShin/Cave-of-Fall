extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func apply(target: StringName,damage: int,max_hp: int = 0) -> Dictionary:
	if max_hp == 0:
		var hp := ask(&"ResourceGetRequested", {"entity":target,"resource":&"HP"})
		max_hp = int(hp["data"]["max"]) if hp.get("found",false) else 20
	return ask(&"StaggerApplyRequested", {"target":target,"damage":damage,"expected_max_hp":max_hp})
func action(id: StringName) -> Dictionary: return ask(&"ActionGetRequested", {"entity":id})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"entities")
	var actual_max: int = int(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["max"])
	check(actual_max > 4,"fixture max")
	var threshold := ceili(actual_max / 4.0)
	check(not apply(&"missing",threshold).get("accepted",true) and not apply(&"hero",threshold,actual_max + 1).get("accepted",true) and not apply(&"hero",-1).get("accepted",true),"invalid and stale maximum")
	var q := apply(&"hero",threshold - 1)
	check(q.get("accepted",false) and not q["data"]["triggered"] and not action(&"hero").get("found",true),"below threshold leaves idle")
	q = apply(&"hero",threshold)
	check(q.get("accepted",false) and q["data"]["applied"] and action(&"hero")["data"]["id"] == &"stagger" and driver.current_action_id == &"stagger","threshold starts idle controlled actor")
	check(driver.advance_steps(10) == 10 and is_equal_approx(action(&"hero")["data"]["elapsed"],0.1),"progress")
	q = apply(&"hero",threshold)
	check(q.get("accepted",false) and q["data"]["refreshed"] and is_equal_approx(action(&"hero")["data"]["elapsed"],0),"refresh resets duration")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and driver.advance_steps(20) == 20 and not action(&"hero").get("found",true) and ask(&"SessionLoadRequested",{}).get("accepted",false) and action(&"hero")["data"]["id"] == &"stagger" and driver.advance_steps(20) == 20,"active stagger saved and restored")
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"attack","duration":0.7}).get("accepted",false),"start interruptible attack")
	var inside := {"attempted":false,"accepted":true}
	var on_tick := func(_e):
		if not inside["attempted"]:
			inside["attempted"] = true
			inside["accepted"] = apply(&"hero",threshold).get("accepted",true)
	bus.subscribe(&"Tick",on_tick)
	check(driver.advance_steps(1) == 1 and inside["attempted"] and not inside["accepted"] and action(&"hero")["data"]["id"] == &"attack","stepping rejects and attack remains")
	bus.unsubscribe(&"Tick",on_tick)
	var snapshot := {"checked":false,"valid":true}
	var on_interrupt := func(e):
		if e.get("entity",null) == &"hero" and e.get("action",null) == &"attack":
			snapshot["checked"] = true
			snapshot["valid"] = root.get_node("SaveService").collect_world_transition_snapshot().get("valid",true)
	bus.subscribe(&"ActionInterrupted",on_interrupt)
	q = apply(&"hero",threshold)
	check(q.get("accepted",false) and q["data"]["previous_action"] == &"attack" and action(&"hero")["data"]["id"] == &"stagger" and snapshot["checked"] and not snapshot["valid"],"interrupt attack and block snapshot in transaction")
	bus.unsubscribe(&"ActionInterrupted",on_interrupt)
	check(driver.advance_steps(20) == 20,"finish stagger")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_small","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false),"equip started")
	q = apply(&"hero",threshold)
	check(q.get("accepted",false) and q["data"]["triggered"] and not q["data"]["applied"] and q["data"]["reason"] == "uninterruptible" and action(&"hero")["data"]["id"] == &"equipment_equip" and driver.advance_steps(10) == 10,"uninterruptible equip stays")
	q = apply(&"npc",threshold)
	check(q.get("accepted",false) and q["data"]["applied"] and action(&"npc")["data"]["id"] == &"stagger","idle NPC")
	check(driver.wait_for(0.2) and driver.advance_steps(20) == 20 and not action(&"npc").get("found",true),"NPC stagger ticks with world")
	check(ask(&"CombatDamageRequested", {"entity":&"npc","amount":9999}).get("accepted",false) and not apply(&"npc",threshold).get("accepted",true),"dead target rejected")
	print("Stagger apply tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
