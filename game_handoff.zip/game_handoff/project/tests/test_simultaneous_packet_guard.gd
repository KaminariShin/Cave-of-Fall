extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func val(id: StringName, resource: StringName) -> float:
	return float(ask(&"ResourceGetRequested", {"entity":id,"resource":resource})["data"]["current"])
func set_val(id: StringName, resource: StringName, n: int) -> void:
	check(ask(&"ResourceSetRequested", {"entity":id,"resource":resource,"value":n}).get("accepted",false),"set resource")
func apply(blocks: Array,hits: Array) -> Dictionary:
	return ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":20,&"npc":20},"hits":hits,"blocks":blocks})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(50,40)}).get("accepted",false),"map")
	var floors: Array = []
	for x in range(50):
		for y in range(40): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc",&"a",&"b"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",&"hshield",Vector2i(10,10)],[&"npc",&"nshield",Vector2i(20,10)]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[2],"size":4}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"body inventory")
		check(ask(&"ItemCreateRequested", {"id":row[1],"base_id":&"shield_medium","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":row[1]}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":row[0],"item":row[1],"slot":"off"}).get("accepted",false),"equip")
		if row[0] == &"npc": check(driver.wait_for(0.1),"advance npc")
		check(driver.advance_steps(10) == 10,"equip finished")
	for id in [&"hero",&"npc"]: set_val(id,&"HP",20); set_val(id,&"Stamina",1)
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false) and ask(&"ShieldBlockStartRequested", {"entity":&"npc","slot":"off","direction":Vector2i.UP}).get("accepted",false),"two active blocks")
	var hits := []
	for row in [[&"hero",10],[&"npc",20]]:
		for source in [&"a",&"b"]: hits.append({"source":source,"target":row[0],"damage":3,"attack_tiles":[Vector2i(row[1],9)]})
	var blocks := [{"target":&"hero","direction":Vector2i.UP,"expected_stamina":1},{"target":&"npc","direction":Vector2i.UP,"expected_stamina":1}]
	var rng = root.get_node("RngService")._rng
	var state: int = rng.state
	var stale: Array = blocks.duplicate(true); stale[1]["expected_stamina"] = 2
	check(not apply(stale,hits).get("accepted",true) and val(&"hero",&"HP") == 20 and val(&"npc",&"HP") == 20 and val(&"hero",&"Stamina") == 1 and rng.state == state, "stale second target rejects entire package before rolls")
	check(not apply([blocks[0],blocks[0]],hits).get("accepted",true) and rng.state == state,"duplicate target rejected")
	check(not ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":20,&"npc":20},"hits":hits,"blocks":blocks,"block":blocks[0]}).get("accepted",true),"mixed API rejected")
	var move := {"done":false}
	var disrupt := func(e):
		if e.get("entity",null) == &"npc" and e.get("active",false) and not move["done"]:
			move["done"] = true
			ask(&"SpaceBodyMoveRequested", {"entity":&"hero","anchor":Vector2i(11,10)})
	bus.subscribe(&"ShieldBlockStatusRequested",disrupt)
	check(not apply(blocks,hits).get("accepted",true) and move["done"] and val(&"hero",&"HP") == 20 and rng.state == state,"later geometry callback cannot silently change earlier defender")
	bus.unsubscribe(&"ShieldBlockStatusRequested",disrupt)
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero","anchor":Vector2i(10,10)}).get("accepted",false),"restore body")
	# A later ItemGet listener can fabricate a wider shield in a query response.
	var spoof := func(e):
		if e.get("item",null) == &"hshield" and e.get("found",false): e["base"]["shield_block_width"] = 4
	bus.subscribe(&"ItemGetRequested",spoof)
	check(not apply(blocks,hits).get("accepted",true) and val(&"hero",&"HP") == 20 and val(&"npc",&"HP") == 20 and rng.state == state, "fabricated shield width rejected before RNG or commit")
	bus.unsubscribe(&"ItemGetRequested",spoof)
	# The input belongs to the caller and can be modified by synchronous observers.
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save before input mutation")
	var packet := {"hp_by_target":{&"hero":20,&"npc":20},"hits":hits.duplicate(true),"blocks":blocks.duplicate(true)}
	var mut := {"done":false}
	var mutate := func(e):
		if not mut["done"]:
			mut["done"] = true
			packet["hp_by_target"][&"hero"] = 999
			packet["hits"][0]["damage"] = 19
			packet["hits"][1]["attack_tiles"].clear()
			packet["blocks"][0]["expected_stamina"] = 999
	bus.subscribe(&"CombatDamageAllowedRequested",mutate)
	var frozen := ask(&"SimultaneousDamageApplyRequested",packet)
	bus.unsubscribe(&"CombatDamageAllowedRequested",mutate)
	check(mut["done"] and frozen.get("accepted",false) and val(&"hero",&"HP") == 16 and val(&"npc",&"HP") == 16 and val(&"hero",&"Stamina") == 0, "mutating caller arrays during check does not change packet")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore after mutation")
	ask(&"RngSeedRequested", {"seed":321})
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save before batch")
	var observed := {"n":0,"all_committed":true}
	var interrupted := func(e):
		if e.get("reason",null) == &"shield_exhausted":
			observed["n"] += 1
			observed["all_committed"] = observed["all_committed"] and val(&"hero",&"HP") == 16 and val(&"npc",&"HP") == 16 and val(&"hero",&"Stamina") == 0 and val(&"npc",&"Stamina") == 0
	bus.subscribe(&"ShieldBlockInterrupted",interrupted)
	var q := apply(blocks,hits)
	check(q.get("accepted",false) and q["data"]["blocks"].size() == 2 and observed["n"] == 2 and observed["all_committed"],"both blocks and all resources committed before events")
	var state_after: int = rng.state
	var data: Dictionary = q.get("data",{}).duplicate(true)
	bus.unsubscribe(&"ShieldBlockInterrupted",interrupted)
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load")
	blocks.reverse(); hits.reverse()
	var replay := apply(blocks,hits)
	check(replay.get("accepted",false) and replay.get("data",{}) == data and rng.state == state_after,"canonical ordering and deterministic RNG replay")
	print("Simultaneous packet guard tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
