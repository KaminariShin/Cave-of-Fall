extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func id(i: int) -> StringName: return StringName("chain_%d" % i)
func budget(room: StringName, value: int) -> Dictionary:
	return ask(&"DungeonDeadendBudgetAvailableRequested", {"room":room, "budget":value})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(500,250)}).get("accepted", false), "map")
	for i in range(6):
		var room_type := "start" if i == 0 else "fork"
		check(ask(&"RoomCreateRequested", {"id":id(i), "type":room_type, "origin_cell":Vector2i(10 if i == 0 else 22 + (i - 1) * 14,20), "size_cells":Vector2i(12,12) if i == 0 else Vector2i(14,14)}).get("accepted", false), "create chain room")
		if i == 0:
			check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":id(0)}).get("accepted", false), "tracking starts before children")
		else:
			check(ask(&"RoomExitAddRequested", {"room":id(i - 1), "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false), "add outgoing")
			check(ask(&"RoomExitAddRequested", {"room":id(i), "id":&"entry", "dir":"west", "offset_cells":5}).get("accepted", false), "add entry")
			check(ask(&"RoomExitConnectRequested", {"room":id(i - 1), "exit":&"east", "other_room":id(i), "other_exit":&"entry"}).get("accepted", false), "connect")
			ask(&"RoomChildGenerated", {"room":id(i - 1), "child":id(i), "type":room_type})
	check(budget(id(1),1).get("budget", -1) == 0, "reserve last deadend at early depth")
	check(budget(id(1),2).get("budget", -1) == 2, "additional early deadends remain allowed")
	check(budget(id(4),1).get("budget", -1) == 0, "child distance five still reserved")
	check(budget(id(5),1).get("budget", -1) == 1, "child distance six may use reservation")
	check(not budget(&"missing",1).get("accepted", false), "unknown parent fails closed")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":1}).get("accepted", false), "set budget")
	check(budget(id(1),0).get("budget", -1) == 0, "zero budget not fabricated")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save and restore before candidate")
	check(budget(id(1),1).get("budget", -1) == 0 and budget(id(5),1).get("budget", -1) == 1, "reservation survives restore")
	check(ask(&"RoomExitAddRequested", {"room":id(1), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "early branch")
	check(ask(&"RoomExitAddRequested", {"room":id(5), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "eligible branch")
	# Ограничиваем размеры и веса только в тестовом экземпляре, чтобы исчерпать
	# все варианты за разумное время, не меняя производственный ruleset.
	var service = root.get_node("RoomService")
	var old_dimensions: Dictionary = service._dimensions.duplicate(true)
	var old_weights: Dictionary = service._weights.duplicate(true)
	service._dimensions["deadend"] = {"min":6, "max":6}
	for key in service._weights: service._weights[key] = 1.0 if key == "deadend" else 0.0
	var fixed_float := func(e): e["value"] = 0.0
	var fixed_int := func(e): e["value"] = e["min"]
	var state := {"trials":0, "created":0, "nested_accepted":false, "last_bounds":[]}
	var reject := func(e):
		state["trials"] += 1
		var room: Dictionary = ask(&"RoomGetRequested", {"id":e["room"]})["data"]
		state["last_bounds"].append(Rect2i(room["origin_cell"] * 4, room["size_cells"] * 4))
		if state["trials"] == 1:
			state["nested_accepted"] = ask(&"RoomChildGenerateRequested", {"room":id(5), "exit":&"north"}).get("accepted", false)
		e["accepted"] = false
	var notice := func(e):
		if str(e.get("room", "")).begins_with("room_"): state["created"] += 1
	var bus = root.get_node("EventBus")
	bus.subscribe(&"RngFloatRequested", fixed_float)
	bus.subscribe(&"RngIntRequested", fixed_int)
	bus.subscribe(&"DungeonStairTrialRequested", reject)
	bus.subscribe(&"RoomCreated", notice)
	var result := ask(&"RoomChildGenerateRequested", {"room":id(5), "exit":&"north"})
	bus.unsubscribe(&"DungeonStairTrialRequested", reject)
	bus.unsubscribe(&"RoomCreated", notice)
	check(state["trials"] > 0 and not result.get("accepted", true), "all candidate probes rejected")
	check(not state["nested_accepted"] and state["created"] == 0, "no reentrant generation or publication")
	check(not ask(&"RoomGenerationStatusGetRequested", {}).get("incomplete", true), "complete rollback")
	check(not ask(&"RoomGetRequested", {"id":id(5)})["data"]["exits"].filter(func(ex): return ex["id"] == &"north")[0]["connected"], "exit unconnected")
	check(ask(&"DungeonFloorTrackingGetRequested", {})["data"]["stair_candidate"] == null, "no candidate")
	var clear := true
	for rect: Rect2i in state["last_bounds"]:
		for y in range(rect.position.y, rect.end.y):
			for x in range(rect.position.x, rect.end.x):
				if ask(&"SpaceTileGetRequested", {"tile":Vector2i(x,y)}).get("kind", -1) != 0: clear = false
	check(clear, "failed trial regions restored")
	# Успешная повторная генерация после отключения инъекции также доказывает,
	# что бюджет тупиков не был израсходован неудачными пробами.
	result = ask(&"RoomChildGenerateRequested", {"room":id(5), "exit":&"north"})
	check(result.get("accepted", false) and result.get("type", "") == "deadend", "budget survives failed trials")
	check(ask(&"DungeonStairGetRequested", {}).get("data", {}).get("status", "") == "placed", "stair after retry")
	service._dimensions = old_dimensions
	service._weights = old_weights
	bus.unsubscribe(&"RngFloatRequested", fixed_float)
	bus.unsubscribe(&"RngIntRequested", fixed_int)
	print("Stair all trials rejected tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
