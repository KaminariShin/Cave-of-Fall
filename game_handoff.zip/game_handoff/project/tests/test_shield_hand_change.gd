extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func gear() -> Dictionary: return ask(&"ComponentGetRequested", {"entity":&"hero","component":&"equipment"})["data"]
func change(slot: String) -> Dictionary: return ask(&"ShieldHandChangeRequested", {"entity":&"hero","slot":slot})
func equip(driver, id: StringName, slot: String) -> bool:
	return ask(&"EquipmentEquipRequested", {"entity":&"hero","item":id,"slot":slot}).get("accepted",false) and driver.advance_steps(10) == 10
func unequip(driver, slot: String) -> bool:
	return ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":slot}).get("accepted",false) and driver.advance_steps(10) == 10
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false), "hero")
	var saver = root.get_node("SaveService")
	var snap: Dictionary = saver.collect_world_transition_snapshot()
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",snap["payload"]["sections"]["items"]["bases"])
	check(ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_small","item_level":1,"learning":schema}).get("accepted",false), "learning shield")
	for row in [[&"sword",&"sword_simple"],[&"shield2",&"shield_small"]]: check(ask(&"ItemCreateRequested", {"id":row[0],"base_id":row[1],"item_level":1}).get("accepted",false), "item")
	for id in [&"shield",&"sword",&"shield2"]: check(ask(&"InventoryAddRequested", {"entity":&"hero","item":id}).get("accepted",false), "add")
	check(not change("off").get("accepted",true) and not ask(&"ActionStartRequested", {"entity":&"hero","action":&"shield_change_hand"}).get("accepted",true), "no shield and direct start reject")
	check(equip(driver,&"shield","off") and equip(driver,&"sword","main"), "equip")
	var test_two := func(e):
		if e.get("item",null) == &"sword" and e.get("found",false): e["base"]["tags"] = ["two_handed"]
	bus.subscribe(&"ItemGetRequested",test_two)
	check(not change("off").get("accepted",true), "two-handed opposite rejected")
	bus.unsubscribe(&"ItemGetRequested",test_two)
	var progress: int = ask(&"ItemGetRequested", {"item":&"shield"})["item_data"]["learning_state"]["progress"]
	check(change("off").get("accepted",false), "start swap")
	check(not ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"shield2"}).get("accepted",true) and not ask(&"EntityRemoveRequested", {"entity":&"hero"}).get("accepted",true), "ownership and removal protected")
	check(driver.advance_steps(50) == 50 and gear()["off"] == &"shield" and gear()["main"] == &"sword", "no early change")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save in progress")
	var file := FileAccess.open("user://session.save",FileAccess.READ)
	var saved: Dictionary = bytes_to_var(file.get_buffer(file.get_length())); file.close()
	for i in [0,1,2]:
		var bad: Dictionary = saved.duplicate(true)
		match i:
			0: bad["sections"]["shield_hand_actions"].erase(&"hero")
			1: bad["sections"]["shield_hand_actions"][&"hero"]["shield"] = &"missing"
			2: bad["sections"]["shield_hand_actions"][&"hero"]["other"] = null
		file = FileAccess.open("user://session.save",FileAccess.WRITE); file.store_buffer(var_to_bytes(bad)); file.close()
		check(not ask(&"SessionLoadRequested",{}).get("accepted",true), "invalid snapshot rejected")
	file = FileAccess.open("user://session.save",FileAccess.WRITE); file.store_buffer(var_to_bytes(saved)); file.close()
	var observed := {"atomic":false,"count":0}
	var changed := func(e):
		if e.get("entity",null) == &"hero" and e.get("component",null) == &"equipment":
			observed["atomic"] = gear().get("main",null) == &"shield" and gear().get("off",null) == &"sword"
			observed["count"] += 1
	bus.subscribe(&"ComponentChanged",changed)
	check(driver.advance_steps(50) == 50 and gear()["main"] == &"shield" and gear()["off"] == &"sword" and observed["atomic"] and observed["count"] == 1, "atomic swap at completion")
	check(ask(&"ItemGetRequested", {"item":&"shield"})["item_data"]["learning_state"]["progress"] == progress + 1, "completed action progresses shield learning")
	bus.unsubscribe(&"ComponentChanged",changed)
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and gear()["off"] == &"shield" and driver.advance_steps(50) == 50 and gear()["main"] == &"shield", "restore resumes and swaps once")
	check(change("main").get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and gear()["main"] == &"shield" and gear()["off"] == &"sword", "cancel leaves hands unchanged")
	check(unequip(driver,"off") and change("main").get("accepted",false) and driver.advance_steps(100) == 100 and gear()["off"] == &"shield" and gear()["main"] == null, "move to empty hand")
	check(equip(driver,&"shield2","main") and not change("off").get("accepted",true), "other shield unsupported")
	check(saver.collect_world_transition_snapshot().get("valid",false), "snapshot after")
	check(unequip(driver,"main") and change("off").get("accepted",false) and driver.advance_steps(10) == 10, "start before death")
	check(ask(&"CombatDamageRequested", {"entity":&"hero","source":null,"amount":99999}).get("accepted",false) and gear()["off"] == &"shield" and gear().get("main",null) == null and not ask(&"ActionGetRequested", {"entity":&"hero"}).get("found",true), "death interrupts without swapping")
	print("Shield hand change tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
