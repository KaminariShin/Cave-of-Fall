extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func armour(actor: StringName) -> float:
	var q := ask(&"EquipmentArmourGetRequested", {"entity":actor})
	return float(q["armour"]) if q.get("found",false) else -1.0
func state(item: StringName) -> Dictionary:
	return ask(&"ItemGetRequested", {"item":item})["item_data"]["learning_state"]
func wait_action(driver, steps: int = 1) -> bool:
	return ask(&"ActionStartRequested", {"entity":&"hero","action":&"wait","duration":steps*0.01}).get("accepted",false) and driver.advance_steps(steps) == steps
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":20}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":20}).get("accepted",false), "inventories")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0}).get("accepted",false), "low INT")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var learning = root.get_node("DungeonChestLearningService")
	for row in [[&"shield", &"shield_small"], [&"armor", &"armor_cloth_body"]]:
		check(ask(&"ItemCreateRequested", {"id":row[0],"base_id":row[1],"item_level":20,"learning":learning.schema_for(row[1],bases)}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":row[0]}).get("accepted",false), "create and own")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and is_equal_approx(armour(&"hero"),2.5), "unknown shield base 5 at 50 percent")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"armor","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and is_equal_approx(armour(&"hero"),4.5), "sum separately penalized armor and shield")
	for i in range(5): check(wait_action(driver), "wait")
	check(state(&"shield")["progress"] == 6 and state(&"armor")["progress"] == 5 and is_equal_approx(armour(&"hero"),5.4), "learned 5 increases material armor to 60 percent")
	var protection := ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"physical","percent":0.0})
	var expected := ask(&"ArmourProtectionCalculateRequested", {"armour":5.4,"percent_sources":[]})
	check(expected.get("accepted",false) and is_equal_approx(protection["percent"],expected["percent"]), "combat protection uses adjusted armor")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and is_equal_approx(armour(&"hero"),5.4), "penalty after save load")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":2}).get("accepted",false) and is_equal_approx(armour(&"hero"),9.0) and not state(&"shield")["identified"], "sufficient INT removes low-INT penalty without identifying")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0}).get("accepted",false) and is_equal_approx(armour(&"hero"),5.4), "penalty returns when INT insufficient")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10, "unequip body")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":2}).get("accepted",false) and ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"armor"}).get("accepted",false) and driver.advance_steps(100) == 100 and state(&"armor")["identified"], "identify body")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"armor","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and is_equal_approx(armour(&"hero"),7.0), "identified armor has no penalty at low INT")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "unequip shield")
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false), "transfer to NPC")
	var progress: int = state(&"shield")["progress"]
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and wait_action(driver,10), "NPC equips while time advances")
	check(is_equal_approx(armour(&"npc"),5.0) and not state(&"shield")["identified"] and state(&"shield")["progress"] == progress, "NPC uses full armor without identifying or learning")
	print("Unidentified armor penalty tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
