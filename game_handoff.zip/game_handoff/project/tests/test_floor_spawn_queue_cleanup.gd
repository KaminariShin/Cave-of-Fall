extends SceneTree
var failures := 0
var arrivals := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, text: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func mob_def() -> Dictionary:
	return {"id":"queue_test", "type_weight":0.1, "species":{"id":"test", "species_weight":0.2}, "tags":[{"id":"boss", "tag_weight":0.1}], "base_stats":{"CON":10,"STR":10,"DEX":10,"INT":10,"WIS":10,"PER":10}, "growth_per_level":{"CON":2,"STR":2,"DEX":2,"INT":2,"WIS":2,"PER":2}, "body_size":2,"min_depth":0,"max_depth":null}
func status() -> Dictionary: return ask(&"RoomSpawnStatusRequested", {"room":&"r"})["data"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	root.get_node("EventBus").subscribe(&"SpawnQueueMobSpawned", func(_e): arrivals += 1)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(100,100)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"r", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(28,28), "size":4}).get("accepted", false), "player body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"r"}).get("accepted", false), "enter")
	var keep := {}
	for x in range(28,32):
		for y in range(28,32): keep[Vector2i(x,y)] = true
	for x in [23,24,26,27]:
		for y in [25,26]: keep[Vector2i(x,y)] = true
	var to_clear: Array = []
	for x in range(9,51):
		for y in range(9,51):
			if not keep.has(Vector2i(x,y)): to_clear.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":to_clear, "kind":0}).get("accepted", false), "sparse room")
	ask(&"RngSeedRequested", {"seed":42})
	var spawn := ask(&"RoomSpawnRequested", {"room":&"r", "player":&"hero", "entry_tile":Vector2i(28,28), "depth":6, "pool":[mob_def()], "queue_delay":0.05})
	check(spawn.get("accepted", false) and spawn["units"].size() == 2 and spawn["queue_count"] == 1, "real queue")
	if not spawn.get("accepted", false) or spawn["units"].size() < 2:
		quit(1)
		return
	var first: StringName = spawn["units"][0]["entity"]
	var survivor: StringName = spawn["units"][1]["entity"]
	check(ask(&"CombatDamageRequested", {"entity":first, "source":&"hero", "amount":9999}).get("accepted", false), "free space and start delay")
	var before := status().duplicate(true)
	var pending: StringName = before["pending"]
	check(pending != &"" and before["queue"].size() == 1, "timer scheduled")
	check(ask(&"ProcessStartRequested", {"id":&"unrelated", "duration":4.0, "entity":&"hero", "independent":true}).get("accepted", false), "unrelated process")
	check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":2.0}).get("accepted", false), "advance time")
	driver.advance_steps(2)
	var elapsed: float = ask(&"ProcessGetRequested", {"id":pending})["data"]["elapsed"]
	var service = root.get_node("SpawnService")
	var save = root.get_node("SaveService")
	check(not service.cancel_queues_for_transition().get("accepted", false), "not usable outside transition")
	var early := {}
	var refused: Dictionary = save.run_world_transition_transaction(func(): early["status"] = root.get_node("FloorSpawnCleanup").discard_spawned_actors_for_transition(); return false)
	check(not early["status"].get("accepted", true) and refused.get("rolled_back", false) and status()["queue"].size() == 1, "creature cleanup refuses nonempty spawn queues")
	var trial := {}
	var result: Dictionary = save.run_world_transition_transaction(func(): trial["status"] = service.cancel_queues_for_transition(); return false)
	check(trial["status"].get("accepted", false) and result.get("rolled_back", false), "outer failure restores cancelled queue")
	check(status() == before and is_equal_approx(ask(&"ProcessGetRequested", {"id":pending})["data"]["elapsed"], elapsed), "queue and elapsed timer restored")
	var sabotage := {"attempted":false}
	var attack := func(e):
		if e.get("id", null) == pending and not sabotage["attempted"]:
			sabotage["attempted"] = true
			ask(&"ProcessInterruptRequested", {"id":pending, "reason":&"external"})
	root.get_node("EventBus").subscribe(&"ProcessGetRequested", attack)
	var failed := {}
	result = save.run_world_transition_transaction(func(): failed["status"] = service.cancel_queues_for_transition(); return true)
	root.get_node("EventBus").unsubscribe(&"ProcessGetRequested", attack)
	check(sabotage["attempted"] and not failed["status"].get("accepted", true) and result.get("rolled_back", false), "preflight interference forces rollback even when caller returns true")
	check(status() == before and ask(&"ProcessGetRequested", {"id":pending}).get("found", false), "interrupted timer restored after interference")
	var starting := {"attempted":false}
	var start_attack := func(e):
		if e.get("id", null) == &"guarded" and not starting["attempted"]:
			starting["attempted"] = true
			starting["nested"] = ask(&"ProcessStartRequested", {"id":&"guarded", "duration":1.0, "entity":&"hero", "independent":true}).get("accepted", false)
			starting["save"] = ask(&"SessionSaveRequested", {}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"ProcessStartAllowedRequested", start_attack)
	check(ask(&"ProcessStartRequested", {"id":&"guarded", "duration":1.0, "entity":&"hero", "independent":true}).get("accepted", false), "outer process starts")
	root.get_node("EventBus").unsubscribe(&"ProcessStartAllowedRequested", start_attack)
	check(starting["attempted"] and not starting["nested"] and not starting["save"], "reentrant same-id start and snapshot blocked")
	var nested := {"attempted":false}
	var callback := func(e):
		if e.get("process", null) != pending: return
		nested["attempted"] = true
		nested["restart"] = ask(&"ProcessStartRequested", {"id":pending, "duration":0.05, "entity":&"", "independent":true}).get("accepted", false)
		nested["cleanup"] = service.cancel_queues_for_transition().get("accepted", false)
		nested["save"] = ask(&"SessionSaveRequested", {}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"ProcessInterrupted", callback)
	var cleaned := {}
	result = save.run_world_transition_transaction(func(): cleaned["status"] = service.cancel_queues_for_transition(); return cleaned["status"].get("accepted", false))
	root.get_node("EventBus").unsubscribe(&"ProcessInterrupted", callback)
	check(result.get("committed", false) and cleaned["status"].get("queue_count", -1) == 1 and cleaned["status"].get("cancelled_processes", []) == [pending], "queue cleanup committed")
	check(nested["attempted"] and not nested["restart"] and not nested["cleanup"] and not nested["save"], "reentrant restart, cleanup and save blocked")
	check(status()["queue"].is_empty() and status()["pending"] == &"" and not ask(&"ProcessGetRequested", {"id":pending}).get("found", false), "queue and timer gone")
	check(ask(&"EntityGetRequested", {"entity":survivor}).get("found", false) and ask(&"ProcessGetRequested", {"id":&"unrelated"}).get("found", false), "existing mob and unrelated process survive")
	driver.advance_steps(20)
	check(arrivals == 0 and status()["queue"].is_empty(), "no delayed arrivals")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and status()["queue"].is_empty(), "cleaned queue persists")
	print("Floor spawn queue cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
