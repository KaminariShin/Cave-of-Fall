extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func hp(id: StringName) -> float:
	return float(ask(&"ResourceGetRequested", {"entity":id,"resource":&"HP"})["data"]["current"])
func set_hp(id: StringName, value: float) -> void:
	check(ask(&"ResourceSetRequested", {"entity":id,"resource":&"HP","value":value}).get("accepted",false), "set hp")
func apply(h: Dictionary, hits: Array) -> Dictionary:
	return ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":h,"hits":hits})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	for id in [&"a",&"b",&"c",&"victim",&"survivor"]:
		check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false), "create " + str(id))
	set_hp(&"a",10); set_hp(&"b",15); set_hp(&"victim",10); set_hp(&"survivor",20)
	var bus = root.get_node("EventBus")
	var saver = root.get_node("SaveService")
	ask(&"RngSeedRequested", {"seed":99})
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var invalid := apply({&"victim":9},[{"source":&"a","target":&"victim","damage":10}])
	var after: Dictionary = saver.collect_world_transition_snapshot()
	check(not invalid.get("accepted",true) and hp(&"victim") == 10 and before["payload"]["sections"]["rng"] == after["payload"]["sections"]["rng"], "stale hp rejects without changing RNG or HP")
	var deny := func(e):
		if e.get("entity",null) == &"victim": e["allowed"] = false
	bus.subscribe(&"CombatDamageAllowedRequested",deny)
	check(not apply({&"victim":10},[{"source":&"a","target":&"victim","damage":10}]).get("accepted",true) and hp(&"victim") == 10, "damage guard")
	bus.unsubscribe(&"CombatDamageAllowedRequested",deny)
	var mutate := func(e):
		if e.get("entity",null) == &"victim": ask(&"ResourceSetRequested", {"entity":&"a","resource":&"HP","value":9})
	bus.subscribe(&"CombatDamageAllowedRequested",mutate)
	check(not apply({&"victim":10},[{"source":&"a","target":&"victim","damage":10}]).get("accepted",true) and hp(&"victim") == 10, "guard mutation invalidates source snapshot")
	bus.unsubscribe(&"CombatDamageAllowedRequested",mutate)
	set_hp(&"a",10)
	var seen := {"events":[],"consistent":true,"nested":true,"save_valid":true}
	var damage_event := func(e):
		if not e.get("simultaneous",false): return
		seen["events"].append(["damage",e["entity"]])
		seen["consistent"] = seen["consistent"] and hp(&"a") == 0 and hp(&"b") == 0 and root.get_node("CombatService").is_entity_dead(&"a") and root.get_node("CombatService").is_entity_dead(&"b")
		seen["nested"] = apply({},[]).get("accepted",true)
		seen["save_valid"] = saver.collect_world_transition_snapshot().get("valid",true)
	var died := func(e):
		if e.get("simultaneous",false): seen["events"].append(["death",e["entity"],e["killer"]])
	bus.subscribe(&"EntityDamaged",damage_event)
	bus.subscribe(&"EntityDied",died)
	var q := apply({&"a":10,&"b":15},[{"source":&"a","target":&"b","damage":20},{"source":&"b","target":&"a","damage":11}])
	check(q.get("accepted",false) and seen["consistent"] and not seen["nested"] and not seen["save_valid"], "mutual death committed before events, guards")
	check(seen["events"] == [["damage",&"a"],["damage",&"b"],["death",&"a",&"b"],["death",&"b",&"a"]], "damage notifications precede all deaths and credit correct killer")
	bus.unsubscribe(&"EntityDamaged",damage_event)
	bus.unsubscribe(&"EntityDied",died)
	var tie_deaths: Array = []
	var observe := func(e):
		if e.get("simultaneous",false): tie_deaths.append(e.duplicate(true))
	bus.subscribe(&"EntityDied",observe)
	# Two live attackers tied for largest damage. Replay the RNG from a saved state.
	check(ask(&"EntityCreateRequested", {"entity":&"d"}).get("accepted",false), "create d")
	ask(&"RngSeedRequested", {"seed":123})
	var rng = root.get_node("RngService")._rng
	var state: int = rng.state
	var expected: StringName = [&"c",&"d"][rng.randi_range(0,1)]
	rng.state = state
	q = apply({&"victim":10,&"survivor":20},[{"source":&"c","target":&"victim","damage":12},{"source":&"d","target":&"victim","damage":12},{"source":&"c","target":&"survivor","damage":3}])
	check(q.get("accepted",false) and tie_deaths.size() == 1 and tie_deaths[0]["killer"] == expected and hp(&"survivor") == 17 and hp(&"victim") == 0, "RNG resolves tie and survivor is damaged")
	check(not apply({&"victim":10},[{"source":&"c","target":&"victim","damage":1}]).get("accepted",true), "dead victim cannot be killed again")
	bus.unsubscribe(&"EntityDied",observe)
	check(saver.collect_world_transition_snapshot().get("valid",false), "snapshot valid after batch")
	print("Simultaneous damage apply tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
