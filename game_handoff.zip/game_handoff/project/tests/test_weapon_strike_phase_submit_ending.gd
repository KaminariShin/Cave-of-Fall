extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(id: StringName,r: StringName) -> float:
	return float(ask(&"ResourceGetRequested", {"entity":id,"resource":r})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc",&"other"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5),&"sword",&"sword_simple","main"],[&"npc",Vector2i(10,5),&"shield",&"shield_medium","off"]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"body inventory")
		check(ask(&"ItemCreateRequested", {"id":row[2],"base_id":row[3],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":row[2]}).get("accepted",false),"item")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"HP","value":20}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":7}).get("accepted",false),"resources")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"npc","slot":"off","direction":Vector2i.LEFT}).get("accepted",false) and driver.wait_for(0.08) and driver.advance_steps(8) == 8,"shield starts eight steps early")
	var start := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(start.get("accepted",false),"strike")
	if not start.get("accepted",false): quit(1); return
	var middle := ceili(float(start["data"]["duration_steps"])/2.0)
	check(middle == 42,"planned simultaneous finishing block")
	var state := {"ending":false,"submitted":false,"resolved":false,"absorbed":0,"interrupted":false}
	var phase := func(_e):
		var status := ask(&"ShieldBlockStatusRequested", {"entity":&"npc"})
		if status.get("ending",false):
			state["ending"] = status.get("active",false) and status.get("direction",null) == Vector2i.LEFT
			ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":1})
			var q := ask(&"WeaponStrikePhaseAutoSubmitRequested",{})
			state["submitted"] = q.get("accepted",false) and q["data"]["block_count"] == 1
	var batch := func(e):
		state["resolved"] = e.get("accepted",false)
		if state["resolved"]: state["absorbed"] = e["data"]["blocks"][&"npc"]["absorbed"]
	var interrupted := func(e):
		if e.get("entity",null) == &"npc" and e.get("reason",null) == &"shield_exhausted": state["interrupted"] = true
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"ShieldBlockInterrupted",interrupted)
	check(driver.advance_steps(middle) == middle and state["ending"] and state["submitted"] and state["resolved"] and state["absorbed"] == 2 and state["interrupted"] and not ask(&"ShieldBlockStatusRequested", {"entity":&"npc"}).get("active",true),"ending shield included before settlement")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"ShieldBlockInterrupted",interrupted)
	print("Weapon strike phase submit ending shield tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
