extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus=root.get_node("EventBus")
	check(begin(1),"floor")
	check(ask(&"DungeonNormalChestAutoEnableRequested",{"enabled":true}).get("accepted",false),"enable integration")
	var count:={"chance":0,"reject":0}
	var force:=func(e):
		if e.get("min",0)==1 and e.get("max",0)==4:
			count["chance"]+=1
			if count["chance"]==1:e["value"]=1
	var deny:=func(e):
		if str(e.get("entity","")).begins_with("normal_chest:"):
			count["reject"]+=1
			if count["reject"]==2:e["accepted"]=false
	bus.subscribe(&"RngIntRequested",force)
	bus.subscribe(&"InventoryAddRequested",deny)
	check(add_room(1,"passage"),"create connected room")
	bus.unsubscribe(&"RngIntRequested",force)
	var status:=ask(&"DungeonNormalChestAutoStatusRequested",{})
	check(status.get("jobs",{}).get(&"node_1",{}).get("status","")=="pending" and count["chance"]==1,"single roll scheduled at room creation")
	ask(&"RoomChildGenerated",{"room":&"root","child":&"node_1","type":"passage"})
	check(count["chance"]==1,"repeat notification does not reroll")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"save load pending generation")
	await process_frame
	await process_frame
	await process_frame
	bus.unsubscribe(&"InventoryAddRequested",deny)
	status=ask(&"DungeonNormalChestAutoStatusRequested",{})
	print("status after failure ",status)
	check(count["reject"]==2 and status.get("jobs",{}).get(&"node_1",{}).get("status","")=="failed","failure is retained")
	check(ask(&"DungeonNormalChestRollGetRequested",{"room":&"node_1"}).get("roll",0)==1,"failed materialization does not reroll choice")
	check(ask(&"DungeonNormalChestAutoRetryRequested",{}).get("accepted",false),"retry scheduled")
	await process_frame
	await process_frame
	await process_frame
	status=ask(&"DungeonNormalChestAutoStatusRequested",{})
	var result:=ask(&"DungeonNormalChestGenerationGetRequested",{"room":&"node_1"})
	check(status["jobs"].is_empty() and result.get("found",false) and result["data"]["status"]=="created","retry creates chest")
	check(ask(&"DungeonNormalChestRollGetRequested",{"room":&"node_1"}).get("roll",0)==1,"same outcome after retry")
	var reject_chance:=func(e):
		if e.get("min",0)==1 and e.get("max",0)==4:e["value"]=4
	bus.subscribe(&"RngIntRequested",reject_chance)
	check(add_room(2,"passage"),"second room")
	bus.unsubscribe(&"RngIntRequested",reject_chance)
	check(not ask(&"DungeonNormalChestRollGetRequested",{"room":&"node_2"}).get("selected",true),"negative chance recorded")
	check(not ask(&"DungeonNormalChestAutoStatusRequested",{})["jobs"].has(&"node_2"),"negative chance schedules no chest")
	var reject_roll:=func(e):
		if e.get("min",0)==1 and e.get("max",0)==4:e["accepted"]=false
	bus.subscribe(&"RngIntRequested",reject_roll)
	check(add_room(3,"passage"),"third room")
	bus.unsubscribe(&"RngIntRequested",reject_roll)
	check(ask(&"DungeonNormalChestAutoStatusRequested",{})["jobs"].get(&"node_3",{}).get("status","")=="failed","failed initial roll recorded")
	check(ask(&"DungeonNormalChestAutoRetryRequested",{}).get("accepted",false),"retry failed initial roll")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"save retry without roll")
	await process_frame
	await process_frame
	await process_frame
	print("retry initial status ",ask(&"DungeonNormalChestAutoStatusRequested",{}))
	check(not ask(&"DungeonNormalChestAutoStatusRequested",{})["jobs"].has(&"node_3"),"initial-roll retry completes")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"save successful generation")
	await process_frame
	check(ask(&"DungeonNormalChestGenerationGetRequested",{"room":&"node_1"})["data"]["object"]==result["data"]["object"],"same object after load")
	print("Normal chest auto tests: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
