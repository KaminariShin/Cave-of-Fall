extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func run() -> void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(50,40)}).get("accepted",false),"map")
	var tiles: Array=[]
	for x in range(50):
		for y in range(40): tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":tiles,"kind":1}).get("accepted",false),"floors")
	check(ask(&"EntityCreateRequested",{"entity":&"fighter"}).get("accepted",false),"fighter")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"fighter","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"body")
	for row in [["sword_simple_variant","demo_player_sword_thrust",4],["sword_simple_variant","demo_creature_thrust",3],["sword_simple_variant","demo_rat_thrust",2],["hammer_simple_variant","demo_player_hammer_slam",4],["hammer_simple_variant","hammer_simple_slam",6]]:
		var data:=ask(&"WeaponStrikePreviewRequested",{"entity":&"fighter","variant":row[0],"strike":row[1],"kind":"physical","direction":Vector2.RIGHT})
		check(data.get("accepted",false),"preview "+row[1])
		if data.get("accepted",false):
			check(is_equal_approx(float(data["zone"]["min_distance"]),1.7),"gap zero "+row[1])
			check(is_equal_approx(float(data["zone"]["max_distance"]),float(row[2])+3.35),"one shorter from prior max "+row[1])
	var p:Dictionary=root.get_node("ProjectileService").effective_projectile_parameters("bow")
	check(p.get("gap",-1)==2.0 and p.get("range",-1)==16.0,"bow two closer and endpoint one shorter")
	var preview:=ask(&"BowMuzzlePreviewRequested",{"entity":&"fighter","direction":Vector2.RIGHT})
	check(preview.get("accepted",false) and preview.get("position",Vector2.ZERO)==Vector2(16,12),"bow preview closer by two")
	var arrow:=ask(&"ProjectileLaunchRequested",{"entity":&"fighter","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10,"damage":7})
	check(arrow.get("accepted",false) and arrow.get("position",Vector2.ZERO)==preview.get("position",null),"bow launch matches preview")
	if arrow.get("accepted",false):
		var shot:=ask(&"ProjectileGetRequested",{"id":arrow["id"]})
		check(is_equal_approx(float(shot.get("data",{}).get("range",0)),16.0),"actual flight reaches correct endpoint")
	var fireball:Dictionary=root.get_node("ProjectileService").effective_projectile_parameters("fireball")
	check(fireball.get("gap",-1)==0.0 and fireball.get("range",-1)==11.0,"fireball default geometry")
	print("All attack reach adjustment: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
