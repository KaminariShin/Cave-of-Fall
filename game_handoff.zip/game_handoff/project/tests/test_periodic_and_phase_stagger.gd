extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(id: StringName,r: StringName) -> float:
	return float(ask(&"ResourceGetRequested", {"entity":id,"resource":r})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc",&"other"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5),&"sword",&"sword_simple","main"],[&"npc",Vector2i(10,5),&"shield",&"shield_medium","off"]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"body inventory")
		check(ask(&"ItemCreateRequested", {"id":row[2],"base_id":row[3],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":row[2]}).get("accepted",false),"item")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"HP","value":20}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":7}).get("accepted",false),"resources")
	var maximum: int = int(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["max"])
	var threshold := ceili(float(maximum)/4.0)
	var effect := {"entity":&"hero","effect":&"dot","damage_type":"magical","damage_per_tick":float(threshold),"base_duration":5.0,"source":&"npc"}
	check(ask(&"PeriodicEffectApplyRequested",effect.duplicate(true)).get("accepted",false) and driver.wait_for(0.08) and driver.advance_steps(8) == 8,"align effect")
	var start := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(start.get("accepted",false),"start strike")
	if not start.get("accepted",false): quit(1); return
	var middle := ceili(float(start["data"]["duration_steps"])/2.0)
	check(middle == 42 and driver.advance_steps(middle-1) == middle-1 and ask(&"SessionSaveRequested",{}).get("accepted",false),"save one tick before midpoint")
	var seen := {"submit":false,"manual":false,"batch":false,"direct":false,"phase_refresh":false}
	var phase := func(_e):
		var q := ask(&"WeaponStrikePhaseAutoSubmitRequested",{})
		seen["submit"] = q.get("accepted",false) and q["data"]["hit_count"] == 1
		var h := int(value(&"hero",&"HP"))
		seen["manual"] = ask(&"CombatPhaseHitSubmitRequested", {"source":&"npc","target":&"hero","damage":threshold,"hp_before":h}).get("accepted",false)
	var batch := func(e): seen["batch"] = e.get("accepted",false) and e.get("hit_count",0) == 2
	var direct := func(e):
		if e.get("target",null) == &"hero": seen["direct"] = e.get("accepted",false) and e.get("data",{}).get("applied",false) and seen["batch"]
	var phase_stagger := func(e):
		for row in e.get("outcomes",[]):
			if row.get("target",null) == &"hero": seen["phase_refresh"] = row.get("applied",false) and row.get("refreshed",false) and seen["direct"]
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"DirectDamageStaggerResolved",direct); bus.subscribe(&"PhaseStaggerResolved",phase_stagger)
	check(driver.advance_steps(1) == 1 and seen["submit"] and seen["manual"] and seen["batch"] and seen["direct"] and seen["phase_refresh"] and ask(&"ActionGetRequested", {"entity":&"hero"}).get("data",{}).get("id",null) == &"stagger","periodic then simultaneous hit both trigger independent staggers")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"DirectDamageStaggerResolved",direct); bus.unsubscribe(&"PhaseStaggerResolved",phase_stagger)
	print("Periodic and phase stagger integration tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
