extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func anchor(ex: Dictionary) -> Vector2i:
	var p := Vector2i(int(ex["x"]),int(ex["y"]))
	match ex["dirOut"]:
		"west": p.x += 1
		"east": p.x -= 4
		"north": p.y += 1
		"south": p.y -= 4
	return p
func fits(p: Vector2i,bounds: Variant,hero: StringName) -> bool:
	return ask(&"SpaceBodyFitsRequested",{"anchor":p,"size":4,"room":bounds,"ignore_entity":hero}).get("fits",false)
func connected(a: Vector2i,targets: Array,bounds: Dictionary,hero: StringName) -> bool:
	if not fits(a,bounds,hero): return false
	var seen := {a:true}
	var queue: Array = [a]
	var i:=0
	while i < queue.size():
		var p: Vector2i = queue[i]; i += 1
		if targets.has(p): return true
		for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var next: Vector2i=p+d
			if not seen.has(next) and fits(next,bounds,hero): seen[next]=true; queue.append(next)
	return false
func run() -> void:
	bus=root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"demo initializes")
	var stack: Array=[game.ROOM]
	var attempts:=0
	var stairs: Dictionary = {}
	while not stack.is_empty() and attempts < 100:
		var room_id: StringName=stack.pop_back()
		var r: Dictionary=ask(&"RoomGetRequested",{"id":room_id})["data"]
		for ex in r["exits"]:
			if ex["connected"] or ex["sealed"]: continue
			attempts+=1
			var generated:=ask(&"RoomChildGenerateRequested",{"room":room_id,"exit":ex["id"]})
			if generated.get("accepted",false): stack.append(generated["child"])
			stairs=ask(&"DungeonStairGetRequested",{})
			if stairs.get("found",false): break
		if stairs.get("found",false): break
	check(stairs.get("found",false) and stairs.get("data",{}).get("status","")=="placed","default seed yields a placed staircase on this generation order")
	if not stairs.get("found",false) or stairs["data"]["status"]!="placed": quit(1); return
	var rooms: Dictionary=ask(&"RoomAllGetRequested",{})["rooms"]
	var path: Array=[stairs["data"]["room"]]
	while path[0]!=game.ROOM:
		var parent: StringName=rooms[path[0]]["parent"]
		if parent==&"": check(false,"route connected to start"); quit(1); return
		path.push_front(parent)
	for i in range(path.size()-1):
		var room: Dictionary=rooms[path[i]]
		var child: Dictionary=rooms[path[i+1]]
		var incoming:=Vector2i(54,60)
		if i>0:
			for ex in room["exits"]:
				if ex["id"]==&"entry": incoming=anchor(ex)
		var outgoing:=Vector2i(-1,-1)
		var child_in:=Vector2i(-1,-1)
		for ex in room["exits"]:
			if ex.get("childId",null)==path[i+1]: outgoing=anchor(ex)
		for ex in child["exits"]:
			if ex["id"]==&"entry": child_in=anchor(ex)
		var bounds := {"origin":room["origin_cell"]*4,"size":room["size_cells"]*4}
		check(connected(incoming,[outgoing],bounds,game.HERO),"4x4 passage inside " + str(path[i]))
		var delta:=child_in-outgoing
		var direction:=Vector2i(signi(delta.x),signi(delta.y))
		var length:=absi(delta.x)+absi(delta.y)
		check(length==6 and (delta.x==0 or delta.y==0),"aligned adjacent doors")
		for step in range(1,length): check(fits(outgoing+direction*step,null,game.HERO),"4x4 crossing between rooms")
	var last: Dictionary=rooms[path.back()]
	var entry:=Vector2i(-1,-1)
	for ex in last["exits"]:
		if ex["id"]==&"entry": entry=anchor(ex)
	var stair_tile: Vector2i=ask(&"ObjectGetRequested",{"object":stairs["data"]["object"]})["data"]["tile"]
	var targets: Array=[]
	for x in range(stair_tile.x-4,stair_tile.x+2):
		for y in range(stair_tile.y-4,stair_tile.y+2):
			var p:=Vector2i(x,y)
			if ((stair_tile.x==p.x-1 or stair_tile.x==p.x+4) and stair_tile.y>=p.y and stair_tile.y<p.y+4) or ((stair_tile.y==p.y-1 or stair_tile.y==p.y+4) and stair_tile.x>=p.x and stair_tile.x<p.x+4): targets.append(p)
	check(connected(entry,targets,{"origin":last["origin_cell"]*4,"size":last["size_cells"]*4},game.HERO),"4x4 reach staircase from entry")
	game.queue_free()
	await process_frame
	print("Game demo first-floor route: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
