extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func action(id: StringName) -> Dictionary: return ask(&"ActionGetRequested", {"entity":id})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"controlled")
	check(not ask(&"ActionDefinitionRegisterRequested", {"data":{"id":&"invalid","name":"invalid","type":&"physical","base_duration":0.03,"phase_completion":"yes"}}).get("accepted",true),"flag is strictly boolean")
	check(ask(&"ActionDefinitionRegisterRequested", {"data":{"id":&"phase_test","name":"test","type":&"physical","base_duration":0.03,"interruptible":true,"phase_completion":true}}).get("accepted",false),"register")
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"phase_test"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"phase_test"}).get("accepted",false),"start both")
	var log := []
	var state := {"both":false,"save_blocked":false,"time_blocked":false,"damage_blocked":false,"stagger_blocked":false,"times":0}
	var phase := func(e):
		state["times"] += 1
		var due: Array = e.get("actions",[])
		if due.size() == 2:
			log.append("phase")
			state["both"] = due[0]["entity"] == &"hero" and due[1]["entity"] == &"npc" and due[0]["elapsed_steps"] == 3 and due[1]["elapsed_steps"] == 3 and action(&"hero").get("found",false) and action(&"npc").get("found",false)
			state["save_blocked"] = not root.get_node("SaveService").collect_world_transition_snapshot().get("valid",true)
			state["time_blocked"] = driver.advance_steps(1) == 0
			state["damage_blocked"] = not ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{},"hits":[]}).get("accepted",true)
			state["stagger_blocked"] = not ask(&"StaggerApplyRequested", {"target":&"hero","damage":1,"expected_max_hp":1}).get("accepted",true)
	var finished := func(e):
		if e.get("action",null) == &"phase_test": log.append(str(e["entity"]))
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"ActionCompleted",finished)
	check(driver.advance_steps(2) == 2 and log.is_empty() and ask(&"SessionSaveRequested",{}).get("accepted",false),"partial and save")
	var saver = root.get_node("SaveService")
	var corrupt: Dictionary = saver.collect_world_transition_snapshot()["payload"].duplicate(true)
	corrupt["sections"]["actions"]["definitions"][&"phase_test"]["phase_completion"] = "yes"
	check(not saver._validate_snapshot(corrupt),"invalid saved phase flag rejected")
	check(driver.advance_steps(1) == 1 and state["both"] and state["save_blocked"] and state["time_blocked"] and state["damage_blocked"] and state["stagger_blocked"] and log == ["phase","npc","hero"],"phase includes both and precedes completion")
	check(not action(&"hero").get("found",true) and not action(&"npc").get("found",true),"finished")
	log.clear(); state["both"] = false
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and driver.advance_steps(1) == 1 and state["both"] and log == ["phase","npc","hero"],"save resumes phase actions")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"ActionCompleted",finished)
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"phase_test"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"phase_test"}).get("accepted",false),"restart")
	var cancelled := {"done":false,"completed":false}
	var cancel := func(e):
		if e.get("actions",[]).size() == 2:
			cancelled["done"] = ask(&"ActionCancelRequested", {"entity":&"npc"}).get("accepted",false)
	var on_finish := func(e):
		if e.get("entity",null) == &"npc" and e.get("action",null) == &"phase_test": cancelled["completed"] = true
	bus.subscribe(&"TimeCombatPhase",cancel); bus.subscribe(&"ActionCompleted",on_finish)
	check(driver.advance_steps(3) == 3 and cancelled["done"] and not cancelled["completed"],"cancelled deferred action is not completed")
	bus.unsubscribe(&"TimeCombatPhase",cancel); bus.unsubscribe(&"ActionCompleted",on_finish)
	print("Combat phase tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
