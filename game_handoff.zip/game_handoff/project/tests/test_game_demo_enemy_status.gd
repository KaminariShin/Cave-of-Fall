extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(v:bool,label:String)->void:
	if not v:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.RAT,"anchor":Vector2i(60,60)}).get("accepted",false),"place nearby target")
	var body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.RAT})["data"]
	var visible:Dictionary={body["anchor"]:true}
	check(game._enemy_display_details(game.HERO,visible).is_empty(),"never displays hero as enemy")
	check(game._enemy_display_details(game.RAT,{}).is_empty(),"fog prevents information")
	check(ask(&"StatBaseSetRequested",{"entity":game.HERO,"stat":&"PER","value":4}).get("accepted",false),"set low perception")
	check(game._enemy_display_details(game.RAT,visible).is_empty(),"no information without detection")
	check(ask(&"DetectionDirectedActionRequested",{"source":game.RAT,"target":game.HERO,"kind":"attack"}).get("accepted",false),"detect source")
	var details:Dictionary=game._enemy_display_details(game.RAT,visible)
	check(details.get("target",null)==game.RAT and not details.has("hp") and not details.has("action"),"PER below five hides hp and action")
	check(ask(&"ActionStartRequested",{"entity":game.RAT,"action":&"wait","duration":1.0}).get("accepted",false),"enemy active action")
	check(ask(&"StatBaseSetRequested",{"entity":game.HERO,"stat":&"PER","value":5}).get("accepted",false),"set PER 5")
	details=game._enemy_display_details(game.RAT,visible)
	check(details.has("hp") and not details.has("action"),"PER five shows only health")
	var original_hp:float=details["hp"]["current"]
	check(ask(&"ResourceSetRequested",{"entity":game.RAT,"resource":&"HP","value":original_hp-3}).get("accepted",false),"set enemy HP")
	check(float(game._enemy_display_details(game.RAT,visible)["hp"]["current"])==original_hp-3,"HP data updates")
	check(ask(&"StatBaseSetRequested",{"entity":game.HERO,"stat":&"PER","value":10}).get("accepted",false),"set PER 10")
	details=game._enemy_display_details(game.RAT,visible)
	check(details.get("action",{}).get("active",false) and details["action"].has("progress") and not details["action"].has("name"),"PER ten progress, no name")
	check(ask(&"ActionStartRequested",{"entity":game.HERO,"action":&"wait","duration":0.25}).get("accepted",false),"advance time")
	check(driver.advance_steps(15)==15,"advance 0.15")
	details=game._enemy_display_details(game.RAT,visible)
	check(float(details.get("action",{}).get("progress",0.0))>0.1,"progress follows actual action")
	check(game._enemy_display_details(game.RAT,{}).is_empty(),"hidden even if detected")
	check(ask(&"DetectionHostilitySetRequested",{"a":game.HERO,"b":game.RAT,"hostile":false}).get("accepted",false),"remove hostility")
	check(game._enemy_display_details(game.RAT,visible).is_empty(),"neutral no status")
	game.queue_free();await process_frame
	print("Game demo enemy status visibility: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
