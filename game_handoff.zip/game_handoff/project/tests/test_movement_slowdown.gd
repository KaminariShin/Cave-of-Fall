extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func stamina() -> Dictionary:
	return ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]
func setstamina(v: float) -> void:
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":v}).get("accepted",false),"set stamina")
func pos() -> float:
	return ask(&"MovementPositionGetRequested", {"entity":&"hero"})["position"].x
func step() -> bool:
	return ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.RIGHT}).get("accepted",false)
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false),"entity")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(12,12)}).get("accepted",false),"map")
	var tiles: Array = []
	for x in range(12):
		for y in range(12): tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":tiles,"kind":1}).get("accepted",false),"floor")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(2,2),"size":2}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"MovementConfigureRequested", {"entity":&"hero","actor_type":"player"}).get("accepted",false),"configure")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"baseline")
	setstamina(0)
	check(step() and driver.advance_steps(10) == 10 and is_equal_approx(pos(),2.0 + 10.0/22.5),"zero stamina slows")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save slowed move")
	check(driver.advance_steps(13) == 13 and not driver.is_action_active and is_equal_approx(pos(),3.0),"slow step 23 ticks")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and driver.advance_steps(13) == 13 and not driver.is_action_active and is_equal_approx(pos(),3.0),"restore slow step")
	setstamina(0)
	check(step() and driver.advance_steps(5) == 5,"begin second slow")
	var before := pos()
	setstamina(1)
	check(driver.advance_steps(1) == 1 and is_equal_approx(pos()-before,1.0/15.0),"external recovery speeds next tick")
	check(driver.advance_steps(11) == 11 and not driver.is_action_active,"retimed completion")
	setstamina(1)
	# Отдельный накопитель стоимости подводим к границе последней единицы.
	var state := stamina()
	var increment := fposmod(0.9625-float(state["movement_remainder"]),1.0)
	check(ask(&"MovementStaminaChargeRequested", {"entity":&"hero","amount":increment}).get("accepted",false),"prime fractional cost")
	check(step() and driver.advance_steps(3) == 3 and stamina()["current"] == 0 and is_equal_approx(pos(),4.0 + 0.15 + 0.75/22.5),"depletion mid tick slows remaining part")
	before = pos()
	check(driver.advance_steps(1) == 1 and is_equal_approx(pos()-before,1.0/22.5),"immediate slowdown")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false),"stop")
	# Натуральный тик регенерации погашает долг и ускоряет текущий шаг.
	check(ask(&"MovementConfigureRequested", {"entity":&"hero","base_hundredths":100,"K_move":50}).get("accepted",false),"long step")
	setstamina(0)
	check(ask(&"MovementStaminaChargeRequested", {"entity":&"hero","amount":1.0}).get("accepted",false) and stamina()["movement_debt"] >= 1,"create debt")
	check(step(),"long step starts")
	# Таймер Stamina уже мог пройти часть периода, поэтому проверяем именно
	# шаг, на котором долг оплачен и появляется свободная единица.
	var saw_recovery := false
	for tick in range(100):
		if not driver.is_action_active: break
		var oldpos := pos()
		var oldstate := stamina()
		driver.advance_steps(1)
		var nextstate := stamina()
		if oldstate["movement_debt"] > 0 and nextstate["movement_debt"] == 0 and nextstate["current"] >= 1:
			check(is_equal_approx(pos()-oldpos,0.01),"regen before movement speeds same tick")
			saw_recovery = true
			break
	check(saw_recovery,"natural regen clears debt while moving")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false),"stop long player step")
	check(ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"npc","anchor":Vector2i(2,7),"size":2}).get("accepted",false) and ask(&"MovementConfigureRequested", {"entity":&"npc","base_hundredths":20,"K_move":50}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":0}).get("accepted",false),"npc setup")
	check(ask(&"MovementStepRequested", {"entity":&"npc","delta":Vector2i.RIGHT}).get("accepted",false) and driver.wait_for(0.4) and driver.advance_steps(20) == 20,"npc slow action")
	var npcpos: Dictionary = ask(&"MovementPositionGetRequested", {"entity":&"npc"})
	check(npcpos["moving"] and is_equal_approx(npcpos["position"].x,2.0 + 20.0/30.0),"npc retimed")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and driver.advance_steps(10) == 10 and not ask(&"MovementPositionGetRequested", {"entity":&"npc"})["moving"],"npc completes and save midstep")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and driver.advance_steps(10) == 10 and not ask(&"MovementPositionGetRequested", {"entity":&"npc"})["moving"],"npc resumes slow step")
	print("Movement slowdown tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
