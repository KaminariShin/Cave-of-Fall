extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	root.get_node("EventBus").subscribe(&"DungeonMilestoneCandidateSelected", func(e): selected.append(e.duplicate(true)))
	check(begin(1), "start floor one tracking")
	check(not ask(&"DungeonFloorTrackingBeginRequested", {"floor":2, "start_room":&"root"}).get("accepted", false), "cannot replace active tracker")
	for i in range(1, 9):
		var type := "deadend" if i in [5,6,7] else "passage"
		check(add_room(i, type), "add room " + str(i))
		if i == 5: check(tracking().get("stair_candidate", null) == null, "distance five excluded")
		if i == 6: check(tracking().get("stair_candidate", null) == &"node_6", "first qualifying deadend selected")
	check(tracking().get("stair_candidate", null) == &"node_6" and selected.size() == 1, "later deadend does not replace")
	var stair: Dictionary = ask(&"DungeonStairGetRequested", {}).get("data", {})
	check(stair.get("status", "") == "placed" and stair.get("room", null) == &"node_6", "stairs placed in first eligible deadend")
	if stair.get("status", "") == "placed":
		var stair_object := ask(&"ObjectGetRequested", {"object":stair["object"]})
		check(stair_object.get("found", false) and stair_object["data"]["type"] == "stairs_down", "stairs are a real world object")
		check(reachable_stair(&"node_6", stair_object["data"]["tile"]), "stair remains reachable to 4x4 body after placement")
		var discarded := {}
		var rollback: Dictionary = root.get_node("SaveService").run_world_transition_transaction(func(): discarded["result"] = root.get_node("ObjectGenerationService").discard_objects_for_transition(); return false)
		check(discarded["result"].get("accepted", false) and rollback.get("rolled_back", false), "stair cleanup rolled back on failed transition")
		check(ask(&"DungeonStairGetRequested", {})["data"]["status"] == "placed" and ask(&"ObjectGetRequested", {"object":stair["object"]}).get("found", false), "rollback restores stair tracking and object")
		check(not ask(&"ObjectInteractRequested", {"entity":&"hero", "object":stair["object"]}).get("accepted", false), "descent unavailable until floor transition exists")
	var depth := ask(&"DungeonRoomDepthRequested", {"room":&"node_8"})
	check(depth.get("accepted", false) and depth.get("distance", -1) == 8 and is_equal_approx(float(depth.get("depth", 0)), 2.6), "real graph distance and depth")
	check(not ask(&"DungeonRoomDepthRequested", {"room":&"missing"}).get("accepted", false), "missing room rejected")
	var snapshot := {"sections":{}, "errors":[]}
	ask(&"SnapshotCollectRequested", snapshot)
	var invalid: Dictionary = snapshot["sections"].duplicate(true)
	invalid["dungeon_tracking"]["stair_candidate"] = &"node_5"
	check(not ask(&"DungeonTrackingSnapshotValidateRequested", {"sections":invalid}).get("valid", false), "reject snapshot with too-near candidate")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save selection")
	check(ask(&"SessionLoadRequested", {}).get("accepted", false) and tracking().get("stair_candidate", null) == &"node_6", "restore selected room")
	if stair.get("status", "") == "placed":
		check(ask(&"ObjectRemoveRequested", {"object":stair["object"]}).get("accepted", false), "remove staircase")
		check(ask(&"DungeonStairGetRequested", {})["data"]["status"] == "failed", "removed staircase becomes failed placement")
		check(ask(&"DungeonStairPlacementRetryRequested", {}).get("accepted", false), "retry missing staircase")
		var replacement: Dictionary = ask(&"DungeonStairGetRequested", {})["data"]
		check(replacement["status"] == "placed" and ask(&"ObjectRemoveRequested", {"object":replacement["object"]}).get("accepted", false), "remove replacement before map reset")
	selected.clear()
	check(begin(1), "new map for failed stair placement")
	for i in range(1, 6): check(add_room(i, "passage"), "path to blocked stairs")
	check(add_room(6, "deadend", true), "create deadend with blocked entrance")
	var failed_stair: Dictionary = ask(&"DungeonStairGetRequested", {}).get("data", {})
	check(failed_stair.get("status", "") == "failed" and failed_stair.get("room", null) == &"node_6", "placement fails explicitly without choosing a different room")
	check(ask(&"EntityRemoveRequested", {"entity":&"blocker"}).get("accepted", false), "remove entry blocker")
	check(ask(&"DungeonStairPlacementRetryRequested", {}).get("accepted", false), "retry after obstruction removed")
	var retry: Dictionary = ask(&"DungeonStairGetRequested", {})["data"]
	check(retry["status"] == "placed" and retry["room"] == &"node_6", "retry uses same first eligible room")
	check(ask(&"ObjectRemoveRequested", {"object":retry["object"]}).get("accepted", false), "remove retry stairs")
	selected.clear()
	check(begin(4), "new map begins fourth floor")
	for i in range(1, 19):
		var type := "deadend" if i == 16 else "passage"
		check(add_room(i, type), "fourth floor room " + str(i))
		if i == 15: check(tracking().get("boss_candidate", null) == null, "distance fifteen excluded")
		if i == 16: check(tracking().get("boss_candidate", null) == null, "deadend beyond fifteen excluded")
		if i == 17: check(tracking().get("boss_candidate", null) == &"node_17", "first eligible passage for boss")
	check(tracking().get("boss_candidate", null) == &"node_17" and tracking().get("stair_candidate", null) == null and selected.size() == 1, "fourth floor selection stable and no stair")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and tracking().get("boss_candidate", null) == &"node_17", "boss candidate survives save")
	print("Dungeon milestone tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
