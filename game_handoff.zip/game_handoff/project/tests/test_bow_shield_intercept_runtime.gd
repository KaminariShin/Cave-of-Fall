extends SceneTree
var failures := 0
var bus: Node
var impacts: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func resource(id: StringName, kind: StringName) -> float:
	return float(ask(&"ResourceGetRequested",{"entity":id,"resource":kind})["data"]["current"])
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,20)}).get("accepted",false),"map")
	var floors: Array = []
	for x in range(40):
		for y in range(20): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"archer",&"target"]: check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested",{"entity":&"target"}).get("accepted",false),"control")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"archer","anchor":Vector2i(2,6),"size":2}).get("accepted",false),"archer")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"target","anchor":Vector2i(12,5),"size":4}).get("accepted",false),"target")
	check(ask(&"ItemCreateRequested",{"id":&"shield","base_id":&"shield_small","item_level":1}).get("accepted",false),"item")
	check(ask(&"ComponentSetRequested",{"entity":&"target","component":&"equipment","data":{"off":&"shield"}}).get("accepted",false),"equip")
	check(ask(&"ShieldBlockStartRequested",{"entity":&"target","slot":"off","direction":Vector2.LEFT}).get("accepted",false),"block")
	check(driver.advance_steps(20) == 20,"advance")
	check(ask(&"ShieldBlockExtendRequested",{"entity":&"target"}).get("accepted",false),"extend")
	var save := ask(&"SessionSaveRequested",{})
	check(save.get("accepted",false),"save extended block: " + str(save))
	var load := ask(&"SessionLoadRequested",{})
	check(load.get("accepted",false),"load extended block: " + str(load))
	check(driver._action_steps == 100 and driver._action_elapsed_steps == 20,"duration restored")
	var hp := resource(&"target",&"HP")
	var stamina := resource(&"target",&"Stamina")
	bus.subscribe(&"ProjectileExpired",func(e): impacts.append(e.duplicate(true)))
	var arrow := ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":7.0})
	check(arrow.get("accepted",false),"launch: " + str(arrow))
	driver.advance_steps(70)
	check(impacts.size()==1 and impacts[0].get("reason",null)==&"shield" and impacts[0].get("direct",{}).get("accepted",false),"arrow hits shield and packet commits: " + str(impacts))
	check(resource(&"target",&"HP") == hp,"shield absorbed arrow")
	check(resource(&"target",&"Stamina") < stamina,"shield spent stamina")
	print("Bow shield intercept and block extension: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
