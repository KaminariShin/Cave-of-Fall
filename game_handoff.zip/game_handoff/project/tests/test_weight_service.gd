extends SceneTree
var failures := 0
var changes: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func info(bus) -> Dictionary:
	var request := {"entity": &"hero"}
	bus.publish(&"WeightGetRequested", request)
	return request.get("data", {})
func put_kg(registry, kg: float) -> void:
	root.get_node("EventBus").publish(&"InventoryCommitRequested", {"entity": &"hero", "data": {"items": [{"id": "load", "weight_kg": kg}], "volume": null}})
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	bus.subscribe(&"WeightThresholdChanged", func(event): changes.append(event.duplicate()))
	check(entities.create_entity(&"hero"), "entity")
	check(info(bus)["capacity_kg"] == 45.0 and info(bus)["physical_kg"] == 0.0, "capacity and empty load")
	put_kg(entities, 22.5)
	check(info(bus)["tier"] == &"0_50", "50 percent")
	put_kg(entities, 22.5001)
	check(info(bus)["tier"] == &"50_75" and info(bus)["stamina_add"] == 0.1, "above 50 percent")
	put_kg(entities, 33.75)
	check(info(bus)["tier"] == &"50_75", "75 percent")
	put_kg(entities, 45.0)
	check(info(bus)["tier"] == &"75_100", "100 percent")
	put_kg(entities, 56.25)
	check(info(bus)["tier"] == &"100_125", "125 percent")
	put_kg(entities, 67.5)
	check(info(bus)["tier"] == &"125_150", "150 percent")
	put_kg(entities, 68.0)
	check(info(bus)["tier"] == &"over_150" and info(bus)["stamina_add"] == 2.0 and info(bus)["duration_add"] == 0.5, "over 150 remains allowed")
	var mods := {"entity": &"hero"}
	bus.publish(&"WeightModifiersRequested", mods)
	check(mods["found"] and mods["modifiers"]["action_duration_add"] == 0.5, "additive contribution")
	check(entities.set_component(&"hero", &"equipment", {"main": {"id": "sword", "weight_kg": 2.0}, "off": null, "armor": {}, "accessories": []}), "equipment")
	check(info(bus)["physical_kg"] == 70.0, "equipment plus inventory")
	bus.publish(&"StatBaseSetRequested", {"entity": &"hero", "stat": &"STR", "value": 10})
	check(info(bus)["capacity_kg"] == 70.0 and info(bus)["tier"] == &"75_100", "STR recalc")
	check(not changes.is_empty() and changes.back()["new"] == &"75_100", "threshold event")
	var budget := {"type": 2, "species": 3, "tags": [1, 2], "level": 4}
	bus.publish(&"BudgetWeightRequested", budget)
	check(budget["accepted"] and budget["core"] == 32 and not budget["complete"], "budget core not claimed complete")
	bus.publish(&"InventoryCommitRequested", {"entity": &"hero", "data": {"items": ["unknown"], "volume": null}})
	check(not info(bus)["ok"], "unknown weight not silently zero")
	bus.subscribe(&"ItemWeightRequested", func(request):
		if request["item"] == "unknown":
			request["found"] = true
			request["weight_kg"] = 4.0)
	bus.publish(&"WeightRefreshRequested", {"entity": &"hero"})
	check(info(bus)["ok"] and info(bus)["physical_kg"] == 6.0, "item ID resolution")
	print("Weight tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
