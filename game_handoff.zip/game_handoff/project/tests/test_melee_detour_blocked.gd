extends SceneTree
var failures := 0
var decisions: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	root.get_node("EventBus").subscribe(&"AIDecision",func(e): if e.get("entity",null) == &"enemy": decisions.append(e["decision"]))
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(80,80)}).get("accepted",false),"map")
	check(ask(&"RoomCreateRequested",{"id":&"r","type":"start","origin_cell":Vector2i(1,1),"size_cells":Vector2i(11,11)}).get("accepted",false),"room")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(28,16),"size":2}).get("accepted",false),"hero body")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"RoomEnterRequested",{"entity":&"hero","room":&"r"}).get("accepted",false),"enter")
	check(ask(&"EntityCreateRequested",{"entity":&"enemy","components":{&"stats":{"PER":30}}}).get("accepted",false),"enemy")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"enemy","anchor":Vector2i(16,16),"size":2}).get("accepted",false),"enemy body")
	for y in [-2,0,2]:
		for x in [-2,0,2]:
			if x == 0 and y == 0: continue
			var id := StringName("b_%d_%d" % [x,y])
			check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"create blocker")
			check(ask(&"SpaceBodyPlaceRequested",{"entity":id,"anchor":Vector2i(16+x,16+y),"size":2}).get("accepted",false),"place blocker")
	check(ask(&"ItemCreateRequested",{"id":&"sword","base_id":&"sword_simple","item_level":1}).get("accepted",false),"sword")
	check(ask(&"ComponentSetRequested",{"entity":&"enemy","component":&"equipment","data":{"main":&"sword"}}).get("accepted",false),"equip")
	check(ask(&"AIRegisterRequested",{"entity":&"enemy","room":&"r","role":"melee","target":&"hero","wait_duration":0.1,"weapon":{"item":&"sword","strike":"sword_simple_thrust"},"movement":{"actor_type":"goblin"}}).get("accepted",false),"AI")
	check(ask(&"DetectionHostilitySetRequested",{"a":&"enemy","b":&"hero","hostile":true}).get("accepted",false),"hostile")
	check(driver.wait_for(2.0) and driver.advance_steps(30) == 30,"advance blocked")
	check(decisions.has("wait"),"wait when trapped " + str(decisions))
	check(ask(&"SpaceBodyGetRequested",{"entity":&"enemy"})["data"]["anchor"] == Vector2i(16,16),"stays in place")
	check(ask(&"EntityRemoveRequested",{"entity":&"b_2_0"}).get("accepted",false),"open passage")
	check(driver.advance_steps(100) == 100,"advance after opening")
	check(decisions.has("approach"),"resumes pursuit after opening " + str(decisions))
	check(ask(&"SpaceBodyGetRequested",{"entity":&"enemy"})["data"]["anchor"] != Vector2i(16,16),"leaves trap")
	print("Blocked melee detour: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
