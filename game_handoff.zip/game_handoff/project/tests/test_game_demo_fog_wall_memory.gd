extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func check(v: bool, label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func run() -> void:
	bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"game")
	var fog := ask(&"FogStateGetRequested",{})
	var center: Vector2 = fog["center"]
	var wall := Vector2i(-1,-1)
	var behind := Vector2i(-1,-1)
	for dir in [Vector2i.RIGHT,Vector2i.LEFT,Vector2i.UP,Vector2i.DOWN]:
		var a := Vector2i(floori(center.x+dir.x*3.0),floori(center.y+dir.y*3.0))
		var b: Vector2i = a+dir
		var ai := ask(&"SpaceTileGetRequested",{"tile":a})
		var bi := ask(&"SpaceTileGetRequested",{"tile":b})
		if ai.get("kind",0)==1 and bi.get("kind",0)==1 and ai.get("occupant",null)==null and bi.get("occupant",null)==null and ai.get("obstacle",null)==null and bi.get("obstacle",null)==null and not ai.get("passage",false) and not bi.get("passage",false) and fog["visible_tiles"].has(a) and fog["visible_tiles"].has(b):
			wall=a;behind=b;break
	check(wall.x >= 0,"find two visible empty floor tiles")
	if wall.x < 0: quit(1); return
	game._remember_visible()
	check((int(game._map_memory.get(behind,0)) & game.MEM_FLOOR)!=0,"initially remembered floor")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[wall],"kind":0}).get("accepted",false),"add wall")
	check(not ask(&"FogTileGetRequested",{"tile":behind}).get("terrain_visible",true),"wall hides explored tile")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[behind],"kind":0}).get("accepted",false),"change hidden floor")
	check((int(game._map_memory.get(behind,0)) & game.MEM_FLOOR)!=0,"hidden change remains remembered as floor")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save")
	game._map_memory.clear()
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load")
	check((int(game._map_memory.get(behind,0)) & game.MEM_FLOOR)!=0,"hidden memory survives loading")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[wall],"kind":1}).get("accepted",false),"open line of sight")
	check(ask(&"FogTileGetRequested",{"tile":behind}).get("terrain_visible",false),"wall behind seen after opening")
	check((int(game._map_memory.get(behind,-1)) & game.MEM_FLOOR)==0,"memory updated only on reobservation")
	check(not game._body_all_visible(Vector2i(1,1),2,{Vector2i(1,1):true}),"partially hidden sprite is clipped")
	game.queue_free(); await process_frame
	print("Fog wall and explored memory: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
