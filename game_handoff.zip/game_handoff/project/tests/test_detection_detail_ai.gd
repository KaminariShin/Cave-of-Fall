extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func details(bus) -> Dictionary:
	return ask(bus, &"DetectionDetailsGetRequested", {"observer": &"hero", "target": &"summoner"})
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(80,80)})["accepted"], "map")
	check(ask(bus, &"RoomCreateRequested", {"id": &"A", "type": "start", "origin_cell": Vector2i(1,1), "size_cells": Vector2i(11,11)})["accepted"], "room")
	check(entities.create_entity(&"hero") and entities.create_entity(&"summoner"), "entities")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(10,10), "size": 4})["accepted"], "hero")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"summoner", "anchor": Vector2i(20,10), "size": 4})["accepted"], "summoner")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"] and ask(bus, &"RoomEnterRequested", {"entity": &"hero", "room": &"A"})["accepted"], "control and room")
	ask(bus, &"StatBaseSetRequested", {"entity": &"hero", "stat": &"PER", "value": 30})
	ask(bus, &"StatBaseSetRequested", {"entity": &"summoner", "stat": &"PER", "value": 30})
	check(ask(bus, &"AIRegisterRequested", {"entity": &"summoner", "room": &"A", "role": "summoner", "target": &"hero", "detected": false, "wait_duration": 0.1})["accepted"], "AI")
	check(ask(bus, &"DetectionHostilitySetRequested", {"a": &"hero", "b": &"summoner", "hostile": true})["accepted"], "hostility")
	check(ask(bus, &"ActionStartRequested", {"entity": &"hero", "action": &"wait", "duration": 4.0})["accepted"], "wait")
	driver.advance_steps(2)
	var action: Dictionary = details(bus)["data"]["action"]
	check(action["name"] == "Призыв крысы" and absf(float(action["effect_in_seconds"]) - 2.0) < 0.00001, "real summon effect at end")
	driver.advance_steps(100)
	check(absf(float(details(bus)["data"]["action"]["effect_in_seconds"]) - 1.0) < 0.00001, "summon countdown")
	ask(bus, &"PlayerRoomChanged", {"entity": &"hero", "room": &"B", "room_type": &"start"})
	action = details(bus)["data"]["action"]
	check(not action["active"] and not action.has("effect_in_seconds"), "room exit cancels summon and effect countdown")
	driver.advance_steps(20)
	action = details(bus)["data"]["action"]
	check(not action["active"], "cancelled summon does not advance outside room")
	ask(bus, &"PlayerRoomChanged", {"entity": &"hero", "room": &"A", "room_type": &"start"})
	driver.advance_steps(1)
	check(absf(float(details(bus)["data"]["action"]["effect_in_seconds"]) - 2.0) < 0.00001, "AI starts a new summon on return")
	print("Detection detail AI tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
