extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(begin(4) and add_room(1, "passage") and add_room(2, "passage"), "connected rooms")
	var bus = root.get_node("EventBus")
	check(ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"future_north", "dir":"north", "offset_cells":5}).get("accepted", false), "reserve unconnected exit")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_1"})["data"]
	var origin: Vector2i = room["origin_cell"] * 4
	var candidates: Array = []
	for x in [1,2,3]:
		var result := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":origin + Vector2i(x,1)})
		check(result.get("accepted", false), "fixture candidate is valid")
		candidates.append(result)
	var state := {"rng":[], "limits":[], "nested":true}
	var mock_search := func(e):
		var cursor: int = e["cursor"]
		var index: int = {0:0, 50:1, 51:2}.get(cursor, -1)
		if index >= 0:
			e["accepted"] = true; e["found"] = true; e["complete"] = false
			e["next_cursor"] = 50 + index
			e["tile"] = candidates[index]["tile"]
			e["interaction_anchor"] = candidates[index]["interaction_anchor"]
			e["connected_exits_checked"] = candidates[index]["connected_exits_checked"]
			e["open_exits_checked"] = candidates[index]["open_exits_checked"]
		else:
			e["accepted"] = true; e["found"] = false; e["complete"] = true; e["next_cursor"] = 2304
	var mock_rng := func(e):
		state["limits"].append([e["min"], e["max"]])
		state["nested"] = ask(&"DungeonChestRandomPositionStepRequested", {}).get("accepted", true)
		if not state["rng"].is_empty(): e["value"] = state["rng"].pop_front()
	bus.subscribe(&"DungeonChestPositionSearchRequested", mock_search)
	bus.subscribe(&"RngIntRequested", mock_rng)
	state["rng"] = [2,1]
	check(ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", false), "begin")
	check(not ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", true), "only one active search")
	for i in range(3):
		var step := ask(&"DungeonChestRandomPositionStepRequested", {})
		check(step.get("accepted", false) and step.get("status", "") == "searching" and step.get("candidates_seen", -1) == i+1 and not step.has("tile"), "intermediate result not exposed")
	var done := ask(&"DungeonChestRandomPositionStepRequested", {})
	check(done.get("accepted", false) and done.get("status", "") == "complete" and done.get("found", false) and done.get("tile", null) == candidates[2]["tile"] and done.get("candidates_seen", 0) == 3 and done.get("connected_exits_checked", 0) == 2 and done.get("open_exits_checked", 0) == 3, "reservoir selects third candidate with future exit")
	check(state["limits"] == [[1,2],[1,3]] and not state["nested"], "reservoir weights and reentry guard")
	check(not ask(&"DungeonChestRandomPositionStepRequested", {}).get("accepted", true), "completed job cleared")
	state["rng"] = [999]
	check(ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", false), "begin failed RNG scenario")
	check(ask(&"DungeonChestRandomPositionStepRequested", {}).get("accepted", false), "first has no random draw")
	check(not ask(&"DungeonChestRandomPositionStepRequested", {}).get("accepted", true) and not ask(&"DungeonChestRandomPositionStepRequested", {}).get("accepted", true), "invalid random result aborts job")
	check(ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", false), "begin cancellation")
	check(ask(&"DungeonChestRandomPositionCancelRequested", {}).get("accepted", false) and not ask(&"DungeonChestRandomPositionCancelRequested", {}).get("accepted", true), "cancel once")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save world")
	check(ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and not ask(&"DungeonChestRandomPositionStepRequested", {}).get("accepted", true), "load cancels transient job")
	check(ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", false), "begin pending exit mutation scenario")
	check(ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"future_south", "dir":"south", "offset_cells":5}).get("accepted", false), "add future exit during search")
	check(not ask(&"DungeonChestRandomPositionStepRequested", {}).get("accepted", true), "new future exit invalidates selection")
	check(ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", false), "begin mutation scenario")
	check(ask(&"ObjectCreateRequested", {"entity":&"changed_chest", "room":&"node_1", "type":"chest", "tile":origin + Vector2i(10,10), "inventory_capacity":10}).get("accepted", false), "change geometry")
	check(not ask(&"DungeonChestRandomPositionStepRequested", {}).get("accepted", true), "world changes abort search")
	bus.unsubscribe(&"DungeonChestPositionSearchRequested", mock_search)
	bus.unsubscribe(&"RngIntRequested", mock_rng)
	check(ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", false), "begin real search")
	var real := ask(&"DungeonChestRandomPositionStepRequested", {})
	check(real.get("accepted", false) and real.get("status", "") == "searching" and real.get("candidates_seen", 0) == 1 and not real.has("tile"), "real search supplies first candidate")
	check(ask(&"DungeonChestRandomPositionCancelRequested", {}).get("accepted", false), "cancel real search")
	var blocked := func(e): e["fits"] = false
	bus.subscribe(&"SpaceBodyFitsRequested", blocked)
	check(ask(&"DungeonChestRandomPositionBeginRequested", {"room":&"node_1"}).get("accepted", false), "begin real no-position search")
	var completed := false
	var pages := 0
	while not completed and pages < 3000:
		var page := ask(&"DungeonChestRandomPositionStepRequested", {})
		check(page.get("accepted", false), "real search page accepted")
		if not page.get("accepted", false): break
		if page.get("status", "") == "complete":
			completed = true
			check(not page.get("found", true) and page.get("candidates_seen", -1) == 0, "real exhausted search has no candidate")
		pages += 1
	bus.unsubscribe(&"SpaceBodyFitsRequested", blocked)
	check(completed, "real scan reaches end")
	print("Chest random position tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
