extends SceneTree
var failures := 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func make_item(bus, id: StringName, base: StringName, rarity: StringName = &"magic") -> bool:
	return ask(bus, &"ItemCreateRequested", {"id": id, "base_id": base, "rarity": rarity, "item_level": 5})["accepted"]
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"MaterialRegisterRequested", {"material": {"id": "mat", "name": "Mat", "weight_per_unit": 1, "volume_per_unit": 1, "level": 10}})["accepted"], "material")
	for data in [{"id": "ring", "name": "Ring", "slot": "ring", "materials": [{"material_id": "mat", "count": 1}]}, {"id": "armor", "name": "Armor", "slot": "armor", "materials": [{"material_id": "mat", "count": 1}]}, {"id": "payload", "name": "Payload", "slot": "other", "materials": [{"material_id": "mat", "count": 12}]}]:
		check(ask(bus, &"ItemBaseRegisterRequested", {"base": data})["accepted"], "base")
	var definition := {"id": "bag_affix", "kind": "magic_inventory", "category": "affix", "allowed_slots": ["ring", "amulet", "cloak"], "slot_penalty": {"category": "suffix", "amount": 1}, "tier_list": [{"tier": 1, "level_req": 0, "weight": 1, "volume_bonus": 4.0}]}
	check(ask(bus, &"ModDefinitionRegisterRequested", {"definition": definition})["accepted"], "magic mod definition")
	check(ask(bus, &"ModDefinitionRegisterRequested", {"definition": {"id": "suffix", "category": "suffix", "stat": "STR", "tiers": [{"tier": 1, "value": 1, "level_req": 0, "weight": 1}]}})["accepted"], "suffix definition")
	check(ask(bus, &"ModDefinitionRegisterRequested", {"definition": {"id":"suffix2", "category":"suffix", "stat":"STR", "tiers":[{"tier":1,"value":1,"level_req":0,"weight":1}]}})["accepted"], "second suffix definition")
	check(make_item(bus, &"ring1", &"ring") and make_item(bus, &"ring2", &"ring") and make_item(bus, &"armor1", &"armor") and make_item(bus, &"stuff", &"payload", &"normal"), "items")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"armor1", "mod_id": &"bag_affix"})["accepted"], "armor slot rejected")
	check(ask(bus, &"ModRollApplyRequested", {"item": &"ring1", "mod_id": &"bag_affix"})["accepted"], "ring affix")
	var rarity: Dictionary = ask(bus, &"ItemRarityGetRequested", {"item": &"ring1"})["data"]
	check(rarity["limits"]["suffix"] == 1 and rarity["limits"]["prefix"] == 2 and rarity["counts"]["affix"] == 1, "suffix penalty and separate affix")
	check(ask(bus, &"ModRollApplyRequested", {"item": &"ring1", "mod_id": &"suffix"})["accepted"], "one suffix")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"ring1", "mod_id": &"suffix"})["accepted"], "lower suffix limit enforced")
	check(ask(bus, &"ModRollApplyRequested", {"item": &"ring2", "mod_id": &"suffix"})["accepted"] and ask(bus, &"ModRollApplyRequested", {"item": &"ring2", "mod_id": &"suffix2"})["accepted"], "prefilled suffixes")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"ring2", "mod_id": &"bag_affix"})["accepted"], "penalty cannot invalidate existing mods")
	for variant in [{"id": "suffix_two", "category": "suffix", "amount": 2}, {"id": "prefix_two", "category": "prefix", "amount": 2}]:
		var mod := {"id": variant["id"], "kind": "magic_inventory", "category": "affix", "slot_penalty": {"category": variant["category"], "amount": variant["amount"]}, "tier_list": [{"tier": 1, "level_req": 0, "weight": 1, "volume_bonus": 2}]}
		check(ask(bus, &"ModDefinitionRegisterRequested", {"definition": mod})["accepted"], "other penalty variant")
		var item_id := StringName("item_" + str(variant["id"]))
		check(make_item(bus, item_id, &"ring"), "variant item")
		check(ask(bus, &"ModRollApplyRequested", {"item": item_id, "mod_id": StringName(variant["id"])})["accepted"], "attach variant")
		var details: Dictionary = ask(bus, &"ItemRarityGetRequested", {"item": item_id})["data"]
		check(details["limits"][variant["category"]] == 0, "minus two to correct limit")
	check(entities.create_entity(&"hero"), "entity")
	check(ask(bus, &"InventoryConfigureRequested", {"entity": &"hero", "volume": 10.0})["accepted"], "base capacity")
	entities.set_component(&"hero", &"equipment", {"ring": &"ring1"})
	var inventory := ask(bus, &"InventoryGetRequested", {"entity": &"hero"})
	check(inventory["volume_known"] and inventory["capacity"] == 14.0, "equipped ring increases capacity")
	check(ask(bus, &"InventoryAddRequested", {"entity": &"hero", "item": &"stuff"})["accepted"], "larger item fits")
	var save := ask(bus, &"SessionSaveRequested", {})
	check(save.get("accepted", false), "save: " + str(save))
	entities.set_component(&"hero", &"equipment", {"ring": null})
	inventory = ask(bus, &"InventoryGetRequested", {"entity": &"hero"})
	check(inventory["capacity"] == 10.0 and inventory["over_capacity"] and inventory["data"]["items"].has(&"stuff"), "unequip keeps items but marks overfull")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load")
	check(ask(bus, &"InventoryGetRequested", {"entity": &"hero"})["capacity"] == 14.0, "no double application on load")
	entities.set_component(&"hero", &"equipment", {"ring": &"ring1", "duplicate": &"ring1"})
	check(ask(bus, &"InventoryGetRequested", {"entity": &"hero"})["capacity"] == 14.0, "same instance not counted twice")
	print("Magic inventory tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
