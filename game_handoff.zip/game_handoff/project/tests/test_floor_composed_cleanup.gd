extends SceneTree
var failures := 0
var deaths: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func exists(id: StringName) -> bool: return ask(&"EntityGetRequested", {"entity":id}).get("found", false)
func item(id: StringName) -> bool: return ask(&"ItemGetRequested", {"item":id}).get("found", false)
func mob_def() -> Dictionary:
	return {"id":"cleanup_test", "type_weight":0.1, "species":{"id":"test", "species_weight":0.2}, "tags":[{"id":"boss", "tag_weight":0.1}], "base_stats":{"CON":10,"STR":10,"DEX":10,"INT":10,"WIS":10,"PER":10}, "growth_per_level":{"CON":2,"STR":2,"DEX":2,"INT":2,"WIS":2,"PER":2}, "body_size":2,"min_depth":0,"max_depth":null}
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus = root.get_node("EventBus")
	var service = root.get_node("FloorTransitionCleanup")
	bus.subscribe(&"EntityDied", func(e): deaths.append(e.duplicate(true)))
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(100,100)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"r", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":20}).get("accepted", false), "hero inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(28,28), "size":4}).get("accepted", false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RunStatisticsStartRequested", {"entity":&"hero", "start_room":&"r"}).get("accepted", false), "stats")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"r"}).get("accepted", false), "room enter")
	ask(&"RngSeedRequested", {"seed":42})
	var spawned := ask(&"RoomSpawnRequested", {"room":&"r", "player":&"hero", "entry_tile":Vector2i(28,28), "depth":6, "pool":[mob_def()], "queue_delay":0.05})
	check(spawned.get("accepted", false) and spawned.get("units", []).size() >= 2, "real spawn")
	if not spawned.get("accepted", false) or spawned.get("units", []).size() < 2:
		quit(1)
		return
	var first: StringName = spawned["units"][0]["entity"]
	var other: StringName = spawned["units"][1]["entity"]
	check(ask(&"InventoryConfigureRequested", {"entity":first, "volume":10}).get("accepted", false), "victim inventory")
	for id in [&"ground_item", &"hero_item"]: check(ask(&"ItemCreateRequested", {"id":id, "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "item")
	check(ask(&"InventoryAddRequested", {"entity":first, "item":&"ground_item"}).get("accepted", false), "victim item")
	check(ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"hero_item"}).get("accepted", false), "hero item")
	check(ask(&"CombatDamageRequested", {"entity":first, "source":&"hero", "amount":9999}).get("accepted", false), "kill for ground loot")
	check(ask(&"LootGetRequested", {})["items"].has(&"ground_item"), "actual ground loot")
	var created_chest := false
	for x in range(9, 40):
		if ask(&"ObjectCreateRequested", {"entity":&"chest", "room":&"r", "type":"chest", "tile":Vector2i(x,9), "inventory_capacity":10}).get("accepted", false):
			created_chest = true
			break
	check(created_chest, "create chest")
	check(ask(&"ItemCreateRequested", {"id":&"chest_item", "base_id":&"bandage", "item_level":1}).get("accepted", false), "chest item")
	check(ask(&"InventoryAddRequested", {"entity":&"chest", "item":&"chest_item"}).get("accepted", false), "put chest item")
	var shot := {}
	for direction in [Vector2.UP, Vector2.DOWN, Vector2.RIGHT, Vector2.LEFT]:
		shot = ask(&"ProjectileLaunchRequested", {"entity":&"hero", "weapon_type":"fireball", "direction":direction, "speed":1.0, "range":5.0})
		if shot.get("accepted", false) and ask(&"ProjectileGetRequested", {"id":shot["id"]}).get("found", false): break
	check(shot.get("accepted", false) and ask(&"ProjectileGetRequested", {"id":shot.get("id", &"")}).get("found", false), "live projectile")
	check(ask(&"EntityCreateRequested", {"entity":&"unknown"}).get("accepted", false), "unclassified")
	var rejected: Dictionary = service.clean_known_floor(&"hero")
	check(not rejected.get("committed", true) and rejected.get("error", "").contains("Неизвестная сущность") and exists(&"chest") and exists(other), "unknown entity blocks preflight")
	check(ask(&"EntityRemoveRequested", {"entity":&"unknown"}).get("accepted", false), "remove unknown")
	check(ask(&"ItemCreateRequested", {"id":&"unassigned", "base_id":&"bandage", "item_level":1}).get("accepted", false), "unassigned item")
	rejected = service.clean_known_floor(&"hero")
	check(not rejected.get("committed", true) and rejected.get("error", "").contains("владельца"), "unassigned item blocks")
	check(ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"unassigned"}).get("accepted", false), "assign item")
	check(ask(&"ProcessStartRequested", {"id":&"unknown_process", "entity":other, "duration":5.0, "independent":true}).get("accepted", false), "unknown process")
	rejected = service.clean_known_floor(&"hero")
	check(not rejected.get("committed", true) and rejected.get("error", "").contains("Независимый процесс"), "unknown independent process blocks")
	ask(&"ProcessInterruptRequested", {"id":&"unknown_process"})
	var snapshot: Dictionary = root.get_node("SaveService").collect_world_transition_snapshot()
	var noises: Dictionary = snapshot["payload"]["sections"]["detection"]["noises"]
	check(not noises.is_empty(), "real projectile creates a noise")
	var deaths_before := deaths.size()
	var stats_before: Dictionary = ask(&"RunStatisticsGetRequested", {})["data"]
	var veto := func(e):
		if e.get("entity", &"") == other: e["allowed"] = false
	bus.subscribe(&"LootEntityRemovalCheckRequested", veto)
	var failed: Dictionary = service.clean_known_floor(&"hero")
	bus.unsubscribe(&"LootEntityRemovalCheckRequested", veto)
	check(not failed.get("committed", true) and failed.get("rolled_back", false), "late actor veto rolls back all steps")
	check(exists(&"chest") and exists(first) and exists(other) and item(&"ground_item") and item(&"chest_item") and ask(&"ProjectileGetRequested", {"id":shot["id"]}).get("found", false), "rollback restores object, dead, living, ground, projectile")
	check(root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]["detection"]["noises"] == noises, "late failure restores noises")
	var initial_hp: float = float(ask(&"ResourceGetRequested", {"entity":&"hero", "resource":&"HP"})["data"]["current"])
	var mutate := func(e):
		if e.get("entity", &"") == &"chest": ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"HP", "value":initial_hp - 1})
	bus.subscribe(&"EntityRemoved", mutate)
	var changed: Dictionary = service.clean_known_floor(&"hero")
	bus.unsubscribe(&"EntityRemoved", mutate)
	check(not changed.get("committed", true) and changed.get("rolled_back", false) and float(ask(&"ResourceGetRequested", {"entity":&"hero", "resource":&"HP"})["data"]["current"]) == initial_hp and exists(&"chest"), "player mutation forces rollback")
	var cleaned: Dictionary = service.clean_known_floor(&"hero")
	check(cleaned.get("committed", false), "composed cleanup commits: " + str(cleaned.get("error", "")))
	check(cleaned.get("steps", {}).get("noises", {}).get("noises", []).size() == noises.size(), "real noise cleaned as part of composition")
	for noise_id in noises: check(not ask(&"ProcessGetRequested", {"id":noise_id}).get("found", false), "noise process removed")
	check(not exists(&"chest") and not exists(first) and not exists(other) and not item(&"ground_item") and not item(&"chest_item") and not ask(&"ProjectileGetRequested", {"id":shot["id"]}).get("found", false), "all known objects removed")
	check(exists(&"hero") and item(&"hero_item") and item(&"unassigned") and deaths.size() == deaths_before and ask(&"RunStatisticsGetRequested", {})["data"] == stats_before, "hero items and stats retained without new deaths")
	check(ask(&"SpaceBodyGetRequested", {"entity":&"hero"}).get("found", false) and ask(&"RoomGetRequested", {"id":&"r"}).get("found", false), "old map and hero body remain: no floor transition")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and not exists(&"chest") and item(&"hero_item"), "result persists")
	print("Floor composed cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
