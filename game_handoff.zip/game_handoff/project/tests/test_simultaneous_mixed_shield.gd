extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(r: StringName) -> float: return float(ask(&"ResourceGetRequested", {"entity":&"hero","resource":r})["data"]["current"])
func set_value(r: StringName,n: int) -> void: check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":r,"value":n}).get("accepted",false),"resource")
func hit(source: StringName,p: int,m: int,x: int) -> Dictionary: return {"source":source,"target":&"hero","damage":p,"magical_damage":m,"attack_tiles":[Vector2i(x,9)]}
func apply(hp: int,stamina: int,hits: Array) -> Dictionary: return ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":hp},"hits":hits,"block":{"target":&"hero","direction":Vector2i.UP,"expected_stamina":stamina}})
func active() -> bool: return ask(&"ShieldBlockStatusRequested", {"entity":&"hero"}).get("active",false)
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(40,40)}).get("accepted",false),"map")
	var floors := []
	for x in range(40):
		for y in range(40): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"a",&"b"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_medium","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	set_value(&"HP",20); set_value(&"Stamina",2)
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false),"block")
	var rng = root.get_node("RngService")._rng
	var initial: int = rng.state
	var bads := [hit(&"a",1,-1,10),hit(&"a",1000000000,1,10),hit(&"a",1,1,10)]
	bads[2]["magical_damage"] = 1.5
	for bad in bads: check(not apply(20,2,[bad]).get("accepted",true) and value(&"HP") == 20 and value(&"Stamina") == 2 and rng.state == initial,"bad magical input rejected without commit or RNG")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save")
	var q := apply(20,2,[hit(&"a",4,3,10)])
	check(q.get("accepted",false) and q["data"]["block"]["absorbed"] == 4 and q["data"]["block"]["stamina_cost"] == 2 and q["data"]["targets"][0]["total_damage"] == 3 and value(&"HP") == 17 and value(&"Stamina") == 0 and active(),"exact full physical block passes magic")
	q = apply(17,0,[hit(&"a",2,3,20)])
	check(q.get("accepted",false) and q["data"]["targets"][0]["total_damage"] == 5 and value(&"HP") == 12 and active(),"nonintersecting physical and magical pass")
	q = apply(12,0,[hit(&"a",0,2,10)])
	check(q.get("accepted",false) and q["data"]["block"]["absorbed"] == 0 and value(&"HP") == 10 and active(),"pure magical hit never consumes or interrupts shield")
	q = apply(10,0,[hit(&"a",1,1,10)])
	check(q.get("accepted",false) and value(&"HP") == 8 and not active(),"uncovered physical and magical pass, shield interrupted")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore")
	var observed := {"hp":-1.0,"stamina":-1.0}
	var died := {"killer":null}
	var interrupt := func(e):
		if e.get("entity",null) == &"hero": observed["hp"] = value(&"HP"); observed["stamina"] = value(&"Stamina")
	var on_died := func(e):
		if e.get("entity",null) == &"hero": died["killer"] = e.get("killer",null)
	bus.subscribe(&"ShieldBlockInterrupted",interrupt); bus.subscribe(&"EntityDied",on_died)
	q = apply(20,2,[hit(&"a",5,1,10),hit(&"b",1,14,20)])
	check(q.get("accepted",false) and q["data"]["targets"][0]["total_damage"] == 17 and value(&"HP") == 3 and observed["hp"] == 3 and observed["stamina"] == 0,"partial block final HP committed before interruption")
	bus.unsubscribe(&"ShieldBlockInterrupted",interrupt)
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore again")
	q = ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":20},"hits":[hit(&"a",2,3,10)]})
	check(q.get("accepted",false) and value(&"HP") == 15 and value(&"Stamina") == 2,"mixed damage without block")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore third time")
	q = apply(20,2,[hit(&"a",5,1,10),hit(&"b",1,18,20)])
	check(q.get("accepted",false) and value(&"HP") == 0 and died["killer"] == &"b","killer uses final physical plus magical damage")
	print("Simultaneous mixed shield tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
