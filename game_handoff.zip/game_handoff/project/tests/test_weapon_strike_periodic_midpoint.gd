extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(id: StringName,r: StringName) -> float:
	return float(ask(&"ResourceGetRequested", {"entity":id,"resource":r})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc",&"other"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5),&"sword",&"sword_simple","main"],[&"npc",Vector2i(10,5),&"shield",&"shield_medium","off"]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"body inventory")
		check(ask(&"ItemCreateRequested", {"id":row[2],"base_id":row[3],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":row[2]}).get("accepted",false),"item")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"HP","value":20}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":7}).get("accepted",false),"resources")
	var effect := {"entity":&"hero","effect":&"dot","damage_type":"magical","damage_per_tick":2.0,"base_duration":5.0,"source":&"npc"}
	check(ask(&"PeriodicEffectApplyRequested",effect.duplicate(true)).get("accepted",false) and driver.wait_for(0.08) and driver.advance_steps(8) == 8,"align effect")
	var start := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(start.get("accepted",false),"start strike")
	if not start.get("accepted",false): quit(1); return
	var middle := ceili(float(start["data"]["duration_steps"])/2.0)
	check(middle == 42 and driver.advance_steps(middle-1) == middle-1 and ask(&"SessionSaveRequested",{}).get("accepted",false),"save one tick before midpoint")
	var seen := {"mode":0,"deferred":false,"hit":false,"batch":false,"dead_rejected":false,"no_hit":false,"resolved":false,"queued_before_death":false,"skipped_after_death":false}
	var damaged := func(e):
		if e.get("entity",null) == &"hero":
			var q := ask(&"ActionInterruptRequested", {"entity":&"hero","action":&"stagger","duration":0.2})
			if seen["mode"] == 0: seen["deferred"] = q.get("accepted",false) and q.get("deferred",false)
			else: seen["dead_rejected"] = not q.get("accepted",true)
	var phase := func(_e):
		var q := ask(&"WeaponStrikePhaseAutoSubmitRequested",{})
		if seen["mode"] == 0: seen["hit"] = q.get("accepted",false) and q["data"]["hit_count"] == 1
		else: seen["no_hit"] = q.get("accepted",false) and q["data"]["attack_count"] == 0 and q["data"]["hit_count"] == 0
	var batch := func(e):
		if seen["mode"] == 0: seen["batch"] = e.get("accepted",false)
	var resolved := func(e):
		if seen["mode"] == 0: seen["resolved"] = e.get("applied",false) and seen["batch"]
		else: seen["skipped_after_death"] = not e.get("applied",true) and e.get("reason","") == "action_changed"
	var pre_death := func(_e):
		if seen["mode"] == 1:
			var q := ask(&"ActionCancelRequested", {"entity":&"hero","reason":&"test"})
			seen["queued_before_death"] = q.get("accepted",false) and q.get("deferred",false)
	bus.subscribe(&"TimeStepStarted",pre_death); bus.subscribe(&"EntityDamaged",damaged); bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"WeaponStrikeDeferredInterruptionResolved",resolved)
	check(driver.advance_steps(1) == 1 and seen["deferred"] and seen["hit"] and seen["batch"] and seen["resolved"] and not root.get_node("CombatService").is_entity_dead(&"hero") and value(&"npc",&"HP") < 20 and ask(&"ActionGetRequested", {"entity":&"hero"}).get("data",{}).get("id",null) == &"stagger","surviving periodic tick defers interruption until strike")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore")
	seen["mode"] = 1
	effect["damage_per_tick"] = 1000.0
	check(ask(&"PeriodicEffectApplyRequested",effect.duplicate(true)).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"HP","value":1}).get("accepted",false),"lethal tick")
	check(driver.advance_steps(1) == 1 and seen["queued_before_death"] and seen["dead_rejected"] and seen["no_hit"] and seen["skipped_after_death"] and root.get_node("CombatService").is_entity_dead(&"hero") and value(&"npc",&"HP") == 20,"lethal periodic damage cancels attack before combat phase")
	bus.unsubscribe(&"TimeStepStarted",pre_death); bus.unsubscribe(&"EntityDamaged",damaged); bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"WeaponStrikeDeferredInterruptionResolved",resolved)
	print("Weapon strike periodic midpoint tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
