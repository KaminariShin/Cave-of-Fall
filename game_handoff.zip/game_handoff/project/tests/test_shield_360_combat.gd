extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(v:bool,label:String)->void:
	if not v:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func key(game:Node,k:Key)->void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func click(game:Control,p:Vector2)->void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*p;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;game._input(e)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame;game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open")
	var inv:Array=game._inventory_items()
	check(game._use_inventory_item(inv.find(&"demo_shield")) and driver.advance_steps(10)==10,"equip")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close")
	var geometry=root.get_node("ShieldBlockZoneService")
	for width in [1,2,4]:
		for hand in ["main","off"]:
			for angle in range(0,360,7):
				var dir:=Vector2.RIGHT.rotated(deg_to_rad(float(angle)))
				var tiles:Array=geometry._tiles(Vector2i(10,10),4,width,hand,dir)
				var unique:Dictionary={}
				for tile in tiles: unique[tile]=true
				check(tiles.size()==width and unique.size()==width,"perimeter width and uniqueness")
				for tile in tiles:
					check(not Rect2i(10,10,4,4).has_point(tile) and tile.x>=9 and tile.x<=14 and tile.y>=9 and tile.y<=14,"shield on outer perimeter")
	var center:Vector2=game._map_origin()+game._camera_center_world()*game.STEP_PX
	for deg in [0,15,31,45,59,75,90,125,165,205,245,275,315,345]:
		var d:=Vector2.RIGHT.rotated(deg_to_rad(float(deg)))
		var point:=center+d*100
		key(game,KEY_B)
		var preview:Dictionary=game._direction_preview(point)
		check(preview.get("kind","")=="block" and preview.get("tiles",[]).size()==1,"preview angle "+str(deg))
		click(game,point)
		var active:=ask(&"ShieldBlockStatusRequested",{"entity":game.HERO})
		var actual:=ask(&"ShieldBlockZoneRequested",{"entity":game.HERO})
		check(active.get("active",false) and Vector2(active.get("direction",Vector2.ZERO)).is_equal_approx(d),"direction "+str(deg))
		check(actual.get("accepted",false) and actual["data"]["tiles"]==preview.get("tiles",[]),"matching zone "+str(deg))
		if deg==45:
			check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save diagonal")
			check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel before load")
			check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load diagonal")
			active=ask(&"ShieldBlockStatusRequested",{"entity":game.HERO})
			check(active.get("active",false) and Vector2(active.get("direction",Vector2.ZERO)).is_equal_approx(d) and ask(&"ShieldBlockZoneRequested",{"entity":game.HERO}).get("data",{}).get("tiles",[])==preview.get("tiles",[]),"restore angle and zone")
		check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel")
	# Find an actual diagonal rat attack that overlaps both body and the shield.
	var body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]
	var rect:=Rect2i(body["anchor"],Vector2i.ONE*int(body["size"]))
	var chosen:=false;var hit_dir:=Vector2.ZERO;var block_dir:=Vector2.ZERO
	for dx in range(4,10):
		for dy in range(-8,0):
			var p:Vector2i=body["anchor"]+Vector2i(dx,dy)
			if not ask(&"SpaceBodyMoveRequested",{"entity":game.RAT,"anchor":p}).get("accepted",false):continue
			var from:=Vector2(p)+Vector2.ONE
			var to:=Vector2(body["anchor"])+Vector2.ONE*2.0
			var direction:Vector2=(to-from).normalized()
			var zone:=ask(&"WeaponStrikePreviewRequested",{"entity":game.RAT,"item":&"demo_rat_sword","strike":"demo_rat_thrust","kind":"physical","direction":direction})
			var shield:=ask(&"ShieldBlockPreviewRequested",{"entity":game.HERO,"slot":"off","direction":-direction})
			var tiles:Array=zone.get("zone",{}).get("tiles",[])
			var hits:=false
			for tile in tiles:
				if rect.has_point(tile):hits=true;break
			if hits and shield.get("accepted",false) and tiles.has(shield["data"]["tiles"][0]):
				chosen=true;hit_dir=direction;block_dir=-direction;break
		if chosen:break
	check(chosen,"find diagonal that intersects shield and body")
	if chosen:
		var result:Dictionary={"blocked":false,"absorbed":0,"failed":false}
		var on_phase:=func(e):
			if not e.get("accepted",false):result["failed"]=true
			elif e.get("data",{}).get("blocks",{}).has(game.HERO):
				result["blocked"]=true;result["absorbed"]=e["data"]["blocks"][game.HERO]["absorbed"]
		bus.subscribe(&"CombatPhaseBatchResolved",on_phase)
		var attack:=ask(&"WeaponStrikeStartRequested",{"entity":game.RAT,"item":&"demo_rat_sword","strike":"demo_rat_thrust","direction":hit_dir})
		check(attack.get("accepted",false),"start diagonal strike")
		var mid:int=ceili(float(attack["data"]["duration_steps"])/2.0)
		var early:int=maxi(0,mid-25)
		if early>0:check(driver.wait_for(float(early)*0.01) and driver.advance_steps(early)==early,"advance windup")
		key(game,KEY_B);click(game,center+block_dir*100)
		check(ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",false),"start mouse block")
		driver.advance_steps(mid-early)
		bus.unsubscribe(&"CombatPhaseBatchResolved",on_phase)
		check(result["blocked"] and result["absorbed"]>0 and not result["failed"],"diagonal actual strike blocked: "+str(result))
	game.queue_free();await process_frame
	print("Shield free-angle diagonal combat: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
