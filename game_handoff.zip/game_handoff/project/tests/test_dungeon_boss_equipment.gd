extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(begin(4), "floor four")
	for i in range(1,17): check(add_room(i, "passage"), "chain")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_16"})["data"]
	var p: Vector2i = room["origin_cell"] * 4 + Vector2i(10,10)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":p, "size":4}).get("accepted", false), "place hero")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "controlled")
	var d := ask(&"DungeonRoomDepthRequested", {"room":&"node_16"})
	var spawned := ask(&"RoomSpawnRequested", {"room":&"node_16", "player":&"hero", "entry_tile":p, "depth":d["depth"], "pool":[]})
	check(spawned.get("accepted", false) and spawned.get("units", []).size() == 1, "spawn boss")
	if not spawned.get("accepted", false) or spawned.get("units", []).is_empty(): quit(1); return
	var boss: StringName = spawned["units"][0]["entity"]
	var level: int = spawned["units"][0]["level"]
	var save_service = root.get_node("SaveService")
	var before: Dictionary = save_service.collect_world_transition_snapshot()
	check(before.get("valid", false), "snapshot before")
	var bus = root.get_node("EventBus")
	var observed := {"created":0, "nested":true, "damage":true, "save":true, "theft":true, "installed":0}
	var inject := func(e):
		if e.get("base_id", null) == &"armor_iron_body": e["accepted"] = false
	var probe := func(e):
		observed["created"] += 1
		observed["theft"] = ask(&"ComponentSetRequested", {"entity":&"hero", "component":&"equipment", "data":{"main":e["item"]}}).get("accepted", false)
		observed["nested"] = ask(&"DungeonBossEquipmentInstallRequested", {"entity":boss}).get("accepted", false)
		observed["damage"] = ask(&"CombatDamageRequested", {"entity":boss, "amount":1}).get("accepted", false)
		observed["save"] = ask(&"SessionSaveRequested", {}).get("accepted", false)
	var installed := func(_e): observed["installed"] += 1
	bus.subscribe(&"ItemCreateRequested", inject)
	bus.subscribe(&"ItemCreated", probe)
	bus.subscribe(&"DungeonBossEquipmentInstalled", installed)
	var failed := ask(&"DungeonBossEquipmentInstallRequested", {"entity":boss})
	bus.unsubscribe(&"ItemCreateRequested", inject)
	bus.unsubscribe(&"ItemCreated", probe)
	var after: Dictionary = save_service.collect_world_transition_snapshot()
	check(not failed.get("accepted", true) and failed.get("rolled_back", false) and observed["created"] == 2, "failed second item rolls back")
	check(not observed["nested"] and not observed["damage"] and not observed["save"] and not observed["theft"] and observed["installed"] == 0, "reentrancy damage and save blocked")
	check(after.get("valid", false) and after["payload"]["sections"] == before["payload"]["sections"], "world restored after failed attempt")
	check(not ask(&"DungeonBossEquipmentInstallRequested", {"entity":&"hero"}).get("accepted", true), "reject other entity")
	var before_time: float = driver.game_time
	var success := ask(&"DungeonBossEquipmentInstallRequested", {"entity":boss})
	check(success.get("accepted", false) and observed["installed"] == 1 and driver.game_time == before_time, "install successful without time")
	if success.get("accepted", false):
		var hammer: StringName = success["items"]["main"]
		var armor: StringName = success["items"]["body"]
		var h := ask(&"ItemGetRequested", {"item":hammer})
		var a := ask(&"ItemGetRequested", {"item":armor})
		check(h.get("found", false) and a.get("found", false) and h["item_data"]["base_id"] == &"hammer_simple" and a["item_data"]["base_id"] == &"armor_iron_body", "real equipment")
		check(h["item_data"]["item_level"] == level and a["item_data"]["item_level"] == level and h["item_data"]["rarity"] == &"normal", "item level and normal rarity")
		var gear := ask(&"ComponentGetRequested", {"entity":boss, "component":&"equipment"})
		check(gear["data"]["main"] == hammer and gear["data"]["body"] == armor, "actual equipped items")
		check(ask(&"EquipmentArmourGetRequested", {"entity":boss}).get("armour", 0) > 0, "armour provides protection")
		check(not ask(&"DungeonBossEquipmentInstallRequested", {"entity":boss}).get("accepted", true), "no duplicate equip")
		check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "equipment save restore")
		check(ask(&"ComponentGetRequested", {"entity":boss, "component":&"equipment"})["data"]["main"] == hammer and ask(&"DungeonBossGetRequested", {})["data"]["loadout"] == success["items"], "gear and one-time issuance persist")
		check(ask(&"ComponentSetRequested", {"entity":boss, "component":&"equipment", "data":{}}).get("accepted", false), "simulate gear loss")
		check(not ask(&"DungeonBossEquipmentInstallRequested", {"entity":boss}).get("accepted", true), "lost gear not regenerated")
		check(ask(&"ComponentSetRequested", {"entity":boss, "component":&"equipment", "data":success["items"]}).get("accepted", false), "restore test gear")
		check(ask(&"CombatDamageRequested", {"entity":boss, "source":&"hero", "amount":999999, "damage_type":"magical"}).get("accepted", false), "kill boss")
		var loot := ask(&"LootGetRequested", {})
		check(loot.get("items", {}).has(hammer) and loot.get("items", {}).has(armor), "actual gear drops on death")
	bus.unsubscribe(&"DungeonBossEquipmentInstalled", installed)
	print("Boss equipment tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
