extends SceneTree

var bus: Node
var failures := 0
var run_seed := 42
const MAP_CELLS := Vector2i(160,160)
const MAX_GENERATION_ATTEMPTS := 130

func _initialize() -> void:
	call_deferred("run")

func ask(id: StringName, event: Dictionary) -> Dictionary:
	bus.publish(id,event)
	return event

func check(value: bool, label: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL [seed %d]: %s" % [run_seed,label])

func floor_four_parameters() -> Dictionary:
	var level_id: StringName = &"demo_floor_1"
	var floor_seed := run_seed
	for floor_no in range(2,5):
		floor_seed = int(("next_floor:%s:%d:%d" % [str(level_id),floor_seed,floor_no]).hash())
		level_id = StringName("floor_%d_%08x" % [floor_no,floor_seed])
	return {"level_id":level_id,"seed":floor_seed}

func exit_anchor(exit: Dictionary) -> Vector2i:
	var anchor := Vector2i(int(exit.get("x",-1)),int(exit.get("y",-1)))
	match str(exit.get("dirOut","")):
		"west": anchor.x += 1
		"east": anchor.x -= 4
		"north": anchor.y += 1
		"south": anchor.y -= 4
		_: return Vector2i(-1,-1)
	return anchor

func body_path_reachable(bounds: Dictionary, start: Vector2i, goal: Vector2i) -> bool:
	var can_fit := func(anchor: Vector2i) -> bool:
		return ask(&"SpaceBodyFitsRequested",{"anchor":anchor,"size":4,"room":bounds,"ignore_entity":&""}).get("fits",false)
	if not can_fit.call(start) or not can_fit.call(goal): return false
	var queue: Array = [start]
	var visited: Dictionary = {start:true}
	var head := 0
	while head < queue.size():
		var anchor: Vector2i = queue[head]
		head += 1
		if anchor == goal: return true
		for delta in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var next: Vector2i = anchor+delta
			if not visited.has(next) and can_fit.call(next):
				visited[next] = true
				queue.append(next)
	return false

func generate_natural_spine(level_id: StringName, floor_seed: int) -> Dictionary:
	var level := ask(&"LevelGenerationRequested",{"level_id":level_id,"seed":floor_seed,"size_cells":MAP_CELLS,"start_origin":Vector2i(12,12),"deadend_budget":1})
	check(level.get("accepted",false),"generate floor-four map")
	var tracking := ask(&"DungeonFloorTrackingBeginRequested",{"floor":4,"start_room":&"start"})
	check(tracking.get("accepted",false),"begin floor-four milestone tracking")
	var stack: Array = [{"room":&"start","attempted":{}}]
	var attempts := 0
	while not stack.is_empty() and attempts < MAX_GENERATION_ATTEMPTS:
		var frame: Dictionary = stack.back()
		var room_id: StringName = frame["room"]
		var room := ask(&"RoomGetRequested",{"id":room_id})
		if not room.get("found",false):
			check(false,"queued room exists: %s" % room_id)
			stack.pop_back()
			continue
		var choice: Dictionary = {}
		for exit in room["data"].get("exits",[]):
			var key := str(exit.get("id",&""))
			if exit.get("connected",false) or exit.get("sealed",false) or frame["attempted"].has(key): continue
			choice = exit
			frame["attempted"][key] = true
			break
		if choice.is_empty():
			stack.pop_back()
			continue
		attempts += 1
		var generated := ask(&"RoomChildGenerateRequested",{"room":room_id,"exit":choice["id"]})
		if generated.get("accepted",false):
			stack.append({"room":generated["child"],"attempted":{}})
		var progress := ask(&"DungeonFloorTrackingGetRequested",{})
		if progress.get("data",{}).get("boss_candidate",null) is StringName: break
	var progress := ask(&"DungeonFloorTrackingGetRequested",{})
	var boss_room = progress.get("data",{}).get("boss_candidate",null)
	var all_rooms := ask(&"RoomAllGetRequested",{})
	var rooms: Dictionary = all_rooms.get("rooms",{})
	var depth := -1
	var boss_type := ""
	if boss_room is StringName and rooms.has(boss_room):
		var cursor: StringName = boss_room
		var seen: Dictionary = {}
		depth = 0
		while cursor != &"start" and rooms.has(cursor) and not seen.has(cursor):
			seen[cursor] = true
			var parent = rooms[cursor].get("parent",null)
			if not parent is StringName or parent == &"":
				depth = -1
				break
			cursor = parent
			depth += 1
		if cursor != &"start": depth = -1
		boss_type = str(rooms[boss_room].get("type",""))
	return {"candidate":boss_room,"depth":depth,"type":boss_type,"rooms":rooms,"attempts":attempts,"stack":stack.size()}

func run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() > 1 or (not args.is_empty() and not args[0].is_valid_int()):
		printerr("FAIL: expected at most one integer starting-seed argument")
		quit(2)
		return
	if not args.is_empty(): run_seed = args[0].to_int()
	bus = root.get_node("EventBus")
	var params := floor_four_parameters()
	var spine := generate_natural_spine(params["level_id"],params["seed"])
	check(spine["candidate"] is StringName,"natural door-by-door generation selects a boss candidate within %d attempts; rooms=%d" % [spine["attempts"],spine["rooms"].size()])
	check(spine["type"]=="passage" and spine["depth"]>15,"boss candidate is a passage deeper than 15 rooms (depth=%d, type=%s)" % [spine["depth"],spine["type"]])
	var unreachable_exits: Array = []
	for room_id in spine["rooms"]:
		var info: Dictionary = spine["rooms"][room_id]
		var origin: Vector2i = info["origin_cell"]*4
		var dimensions: Vector2i = info["size_cells"]*4
		var bounds := {"origin":origin,"size":dimensions}
		var start := origin+dimensions/2-Vector2i.ONE*2
		for exit in info.get("exits",[]):
			if exit.get("id",null)==&"entry": start=exit_anchor(exit); break
		for exit in info.get("exits",[]):
			if not body_path_reachable(bounds,start,exit_anchor(exit)):
				unreachable_exits.append("%s/%s" % [room_id,exit.get("id","")])
	check(unreachable_exits.is_empty(),"4x4 natural movement reaches every generated doorway: %s" % str(unreachable_exits))
	print("Boss spine (start seed %d, floor-four seed %d): room=%s depth=%d rooms=%d attempts=%d" % [run_seed,params["seed"],spine["candidate"],spine["depth"],spine["rooms"].size(),spine["attempts"]])
	print("Dungeon boss spine: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
