extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func state(item: StringName) -> Dictionary:
	return ask(&"ItemGetRequested", {"item":item})["item_data"]["learning_state"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc", "volume":10}).get("accepted",false), "inventories")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"sword_simple",bases)
	for id in [&"sword",&"sword2"]:
		check(ask(&"ItemCreateRequested", {"id":id,"base_id":&"sword_simple","item_level":10,"learning":schema}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":id}).get("accepted",false), "create item with state")
	check(state(&"sword") == {"progress":0,"identified":false}, "initial learning state")
	check(not ask(&"ItemLearningIdentifyRequested", {"entity":&"npc","item":&"sword"}).get("accepted",true), "NPC cannot identify")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0.0}).get("accepted",false), "low int")
	check(not ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"sword"}).get("accepted",true), "low int rejects")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":10.0}).get("accepted",false), "high int")
	var player_query := ask(&"IdentificationCheckRequested", {"entity":&"hero", "item":&"sword"})
	var npc_query := ask(&"IdentificationCheckRequested", {"entity":&"npc", "item":&"sword"})
	check(player_query.get("found",false) and not player_query["identified"] and not player_query["globally_identified"] and npc_query["identified"] and not npc_query["globally_identified"] and not state(&"sword")["identified"], "high INT does not auto identify; NPC bypass does not mutate")
	check(not ask(&"ActionStartRequested", {"entity":&"hero","action":&"item_learning_identify"}).get("accepted",true), "direct action blocked")
	check(ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"sword"}).get("accepted",false), "identify starts")
	check(not ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"sword"}).get("accepted",true) and not ask(&"ActionInterruptRequested", {"entity":&"hero","action":&"stagger","force":true}).get("accepted",true), "ownership locked and stagger rejected")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0.0}).get("accepted",false), "INT drops during action")
	check(driver.advance_steps(50) == 50 and not state(&"sword")["identified"], "not identified before 1 sec")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save pending action")
	var f := FileAccess.open("user://session.save",FileAccess.READ)
	var saved: Dictionary = bytes_to_var(f.get_buffer(f.get_length())); f.close()
	for corrupt in [0,1,2]:
		var bad: Dictionary = saved.duplicate(true)
		match corrupt:
			0: bad["sections"]["item_identification_actions"][&"hero"] = &"missing"
			1: bad["sections"]["item_identification_actions"].erase(&"hero")
			2: bad["sections"]["items"]["instances"][&"sword"]["learning_state"]["identified"] = true
		f = FileAccess.open("user://session.save",FileAccess.WRITE); f.store_buffer(var_to_bytes(bad)); f.close()
		check(not ask(&"SessionLoadRequested",{}).get("accepted",true), "invalid pending save rejected %d" % corrupt)
	f = FileAccess.open("user://session.save",FileAccess.WRITE); f.store_buffer(var_to_bytes(saved)); f.close()
	check(driver.advance_steps(50) == 50 and state(&"sword")["identified"], "completion ignores later INT decrease")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and not state(&"sword")["identified"] and driver.advance_steps(50) == 50 and state(&"sword")["identified"], "resume saved action")
	check(ask(&"IdentificationCheckRequested", {"entity":&"hero", "item":&"sword"}).get("identified",false), "identified query uses persistent state despite low INT")
	check(not ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"sword"}).get("accepted",true), "cannot repeat identified")
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"sword"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"sword"}).get("accepted",false) and state(&"sword")["identified"], "identified stays with item across owners")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":10.0}).get("accepted",false), "restore int")
	check(ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"sword2"}).get("accepted",false) and driver.advance_steps(20) == 20 and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and not state(&"sword2")["identified"], "cancel does not identify")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword2","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10, "equip second item")
	check(not ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"sword2"}).get("accepted",true), "worn item cannot be identified")
	print("Item learning identify tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
