extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"EntityCreateRequested", {"entity":&"probe"}).get("accepted",false), "probe")
	var initial: Dictionary = saver.collect_world_transition_snapshot()
	var normal := ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"sword_simple","item_level":1,"rarity":&"normal"})
	check(normal.get("accepted",false) and normal.get("mods",[]).is_empty() and initial["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "normal has no mods or RNG")
	check(not ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"sword_simple","item_level":1,"rarity":&"unique"}).get("accepted",true), "unique unavailable")
	var state := {"ranges":[], "nested":true, "save":true, "probe":true, "corrupt":false, "mutate":false}
	var rng := func(e):
		state["ranges"].append([e["min"],e["max"]])
		if state["probe"]:
			state["probe"] = false
			state["nested"] = ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"sword_simple","item_level":5,"rarity":&"magic"}).get("accepted",true)
			state["save"] = ask(&"SessionSaveRequested",{}).get("accepted",true)
		if state["mutate"]:
			state["mutate"] = false
			ask(&"StatBaseSetRequested", {"entity":&"probe", "stat":&"CON", "value":33.0})
		e["value"] = e["max"] + 1 if state["corrupt"] else e["min"]
	bus.subscribe(&"RngIntRequested",rng)
	var rare := ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"sword_simple","item_level":5,"rarity":&"rare"})
	check(rare.get("accepted",false) and not state["nested"] and not state["save"], "rare and guards")
	if rare.get("accepted",false):
		var mods: Array = rare["mods"]
		var ids: Array = []
		for mod in mods: ids.append(mod["id"])
		check(ids == [&"pre_strength",&"pre_agile",&"suf_physical_damage",&"suf_bleed",&"suf_poison"], "maximum available unique mods")
		check(mods[0]["material_id"] == &"steel_tempered" and mods[0]["tier"] == 3 and mods[0]["value"] == 1.0 and mods[1]["material_id"] == &"leather_scale", "material and tier choice")
		check(state["ranges"].size() == 15 and state["ranges"][0] == [0,1] and state["ranges"][2] == [0,13], "uniform materials and weighted tiers")
	var after: Dictionary = saver.collect_world_transition_snapshot()
	var a: Dictionary = initial["payload"]["sections"].duplicate(true); var b: Dictionary = after["payload"]["sections"].duplicate(true)
	a.erase("rng"); b.erase("rng")
	check(a == b, "only RNG changed")
	var before_failure: Dictionary = saver.collect_world_transition_snapshot()
	state["corrupt"] = true
	var failed := ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"sword_simple","item_level":5,"rarity":&"rare"})
	check(not failed.get("accepted",true) and failed.get("rolled_back",false) and before_failure["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "bad RNG rolls back")
	state["corrupt"] = false; state["mutate"] = true
	var mutation := ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"sword_simple","item_level":5,"rarity":&"magic"})
	check(not mutation.get("accepted",true) and mutation.get("rolled_back",false) and before_failure["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "foreign world mutation rolls back")
	bus.unsubscribe(&"RngIntRequested",rng)
	ask(&"RngSeedRequested", {"seed":42})
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save")
	var first := ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"staff_simple","item_level":3,"rarity":&"magic"})
	check(ask(&"SessionLoadRequested",{}).get("accepted",false), "load")
	var replay := ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"staff_simple","item_level":3,"rarity":&"magic"})
	check(first.get("accepted",false) and replay.get("accepted",false) and first["mods"] == replay["mods"], "RNG replay")
	print("Chest mod draft tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
