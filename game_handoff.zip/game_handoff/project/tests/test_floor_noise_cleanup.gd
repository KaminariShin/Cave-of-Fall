extends SceneTree
var failures := 0
var ended: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func snapshot() -> Dictionary:
	return root.get_node("SaveService").collect_world_transition_snapshot()
func run() -> void:
	var bus = root.get_node("EventBus")
	var service = root.get_node("DetectionService")
	var save = root.get_node("SaveService")
	root.get_node("TimeDriver").set_process(false)
	bus.subscribe(&"NoiseEnded", func(e): ended.append(e.duplicate(true)))
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(50,30)}).get("accepted", false), "map")
	var tiles: Array = []
	for y in range(30):
		for x in range(50): tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":tiles, "kind":1}).get("accepted", false), "floor")
	for id in [&"hero", &"source"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted", false), "entity")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(5,5), "size":2}).get("accepted", false), "hero body")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"source", "anchor":Vector2i(20,5), "size":2}).get("accepted", false), "source body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	var during := {"started":false, "save_accepted":true, "transaction_committed":true}
	var start_listener := func(_e):
		during["started"] = true
		during["save_accepted"] = ask(&"SessionSaveRequested", {}).get("accepted", true)
		during["transaction_committed"] = save.run_world_transition_transaction(func(): return true).get("committed", true)
	bus.subscribe(&"NoiseStarted", start_listener)
	var one := ask(&"NoiseEmitRequested", {"source":&"source", "kind":"strike"})
	bus.unsubscribe(&"NoiseStarted", start_listener)
	var two := ask(&"NoiseEmitRequested", {"source":&"hero", "kind":"shot"})
	check(one.get("accepted", false) and two.get("accepted", false) and during["started"] and not during["save_accepted"] and not during["transaction_committed"], "real noises, guarded start callback")
	if not one.get("accepted", false) or not two.get("accepted", false):
		quit(1)
		return
	var first: StringName = one["id"]
	var second: StringName = two["id"]
	check(ask(&"EntityRemoveRequested", {"entity":&"source"}).get("accepted", false), "remove noise source")
	check(ask(&"ProcessGetRequested", {"id":first}).get("found", false), "noise survives removal of source")
	check(ask(&"ProcessStartRequested", {"id":&"unrelated", "entity":&"hero", "duration":10.0, "independent":true}).get("accepted", false), "unrelated process")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save noise")
	var before: Dictionary = snapshot()["payload"]["sections"]["detection"]["noises"]
	check(before.has(first) and before.has(second) and not ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "noises persist and block map")
	check(not service.discard_noises_for_transition().get("accepted", false), "outside transaction rejected")
	var observed := {"nested":true, "emit":true, "restart":true, "cancel_second":false, "snapshot_valid":true}
	var listener := func(e):
		if e.get("id", &"") != first: return
		observed["nested"] = service.discard_noises_for_transition().get("accepted", true)
		observed["emit"] = ask(&"NoiseEmitRequested", {"source":&"hero", "kind":"shot"}).get("accepted", true)
		observed["restart"] = ask(&"ProcessStartRequested", {"id":first, "entity":&"hero", "duration":1.0, "independent":true}).get("accepted", true)
		observed["snapshot_valid"] = snapshot().get("valid", true)
		observed["cancel_second"] = ask(&"ProcessInterruptRequested", {"id":second, "reason":&"test_conflict"}).get("accepted", false)
	bus.subscribe(&"NoiseEnded", listener)
	var out := {}
	var result: Dictionary = save.run_world_transition_transaction(func(): out["r"] = service.discard_noises_for_transition(); return true)
	bus.unsubscribe(&"NoiseEnded", listener)
	check(not observed["nested"] and not observed["emit"] and not observed["restart"] and not observed["snapshot_valid"] and observed["cancel_second"], "nested cleanup, noise, process and snapshot blocked")
	check(not out["r"].get("accepted", true) and result.get("rolled_back", false), "conflicting interruption forces rollback")
	check(snapshot()["payload"]["sections"]["detection"]["noises"] == before and ask(&"ProcessGetRequested", {"id":first})["found"] and ask(&"ProcessGetRequested", {"id":second})["found"], "noise records and processes restored")
	ended.clear()
	result = save.run_world_transition_transaction(func(): out["r"] = service.discard_noises_for_transition(); return out["r"].get("accepted", false))
	check(result.get("committed", false) and out["r"].get("noises", []) == [first,second], "remove both noises")
	check(snapshot()["payload"]["sections"]["detection"]["noises"].is_empty() and not ask(&"ProcessGetRequested", {"id":first})["found"] and not ask(&"ProcessGetRequested", {"id":second})["found"] and ask(&"ProcessGetRequested", {"id":&"unrelated"})["found"], "only noise processes removed")
	check(ended.size() == 2 and ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "notifications and map guard released")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and snapshot()["payload"]["sections"]["detection"]["noises"].is_empty(), "cleanup persisted")
	result = save.run_world_transition_transaction(func(): out["r"] = service.discard_noises_for_transition(); return out["r"].get("accepted", false))
	check(result.get("committed", false) and out["r"].get("noises", [1]).is_empty(), "empty cleanup idempotent")
	print("Floor noise cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
