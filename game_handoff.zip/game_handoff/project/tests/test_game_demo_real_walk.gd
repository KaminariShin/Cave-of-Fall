extends SceneTree
var bus: Node
var driver: Node
var game: Node
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures+=1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func body() -> Vector2i: return ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
func room_data(id: StringName) -> Dictionary: return ask(&"RoomGetRequested",{"id":id})["data"]
func anchor(ex: Dictionary) -> Vector2i:
	var p:=Vector2i(int(ex["x"]),int(ex["y"]))
	match ex["dirOut"]:
		"west":p.x+=1
		"east":p.x-=4
		"north":p.y+=1
		"south":p.y-=4
	return p
func steps_to(goal: Vector2i,area: Dictionary) -> Array:
	var start:=body()
	var queue:Array=[start]
	var prev:Dictionary={start:null}
	var i:=0
	while i<queue.size():
		var p:Vector2i=queue[i];i+=1
		if p==goal:
			var route:Array=[]
			while p!=start:
				var old:Vector2i=prev[p]
				route.push_front(p-old);p=old
			return route
		for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var n:Vector2i=p+d
			if not prev.has(n) and ask(&"SpaceBodyFitsRequested",{"anchor":n,"size":4,"room":area,"ignore_entity":game.HERO}).get("fits",false):
				prev[n]=p;queue.append(n)
	return []
func follow(route: Array) -> bool:
	for d in route:
		var expected: Vector2i=body()+d
		if not game._move(d): print("movement refused ",body()," delta ",d," ",game.message);return false
		driver.advance_steps(300)
		if body()!=expected: print("movement diverged ",body()," expected ",expected," message ",game.message);return false
	return true
func enter_next(room_id: StringName) -> bool:
	var info:Dictionary=room_data(room_id)
	var out:Dictionary={}
	for ex in info["exits"]:
		if not ex["connected"] and not ex["sealed"]:out=ex;break
	if out.is_empty(): print("no unexplored exit");return false
	var goal:=anchor(out)
	var area:Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
	var path:=steps_to(goal,area)
	if path.is_empty() and body()!=goal: print("no walking path ",room_id," ",body()," to ",goal); return false
	if not follow(path): return false
	# Первый шаг на проход запускает ленивую генерацию.
	var delta: Vector2i={"north":Vector2i.UP,"east":Vector2i.RIGHT,"south":Vector2i.DOWN,"west":Vector2i.LEFT}[out["dirOut"]]
	if not follow([delta]): return false
	info=room_data(room_id)
	for ex in info["exits"]:
		if ex["id"]==out["id"]: out=ex;break
	if not out["connected"]: print("exit was not generated ",out);return false
	var child: StringName=out["childId"]
	for i in range(8):
		if game.current_room==child: return true
		if not follow([delta]): return false
	return game.current_room==child
func run() -> void:
	bus=root.get_node("EventBus")
	driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save"
	var existed:=FileAccess.file_exists(path)
	var old:=PackedByteArray()
	if existed:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	game=load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"demo initialized")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"disable tutorial enemy for route test")
	check(enter_next(game.ROOM),"walk from starting position to first generated room")
	var first:StringName=game.current_room
	await process_frame
	await process_frame
	await process_frame
	var spawned:=ask(&"RoomSpawnStatusRequested",{"room":first})
	check(spawned.get("spawned",false),"first room really spawned enemies")
	for id in spawned.get("data",{}).get("placed",[]):
		check(ask(&"AIGetRequested",{"entity":id}).get("data",{}).get("role","")=="melee","spawned enemy uses shared AI")
		ask(&"AIUnregisterRequested",{"entity":id}) # бой проверяется другими тестами
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save after walking")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load after walking")
	await process_frame
	await process_frame
	check(enter_next(first),"walk to second generated room")
	check(game.current_room!=first,"second actual room entered")
	await process_frame
	await process_frame
	check(ask(&"RoomSpawnStatusRequested",{"room":game.current_room}).get("spawned",false),"second room really spawned")
	game.queue_free()
	await process_frame
	if existed:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo real walk: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
