extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func preview(p: float,m: float,pp: float,mp: float,w: float) -> Dictionary:
	return ask(&"DirectHitMitigationPreviewRequested", {"physical":p,"magical":m,"physical_protection_percent":pp,"magical_protection_percent":mp,"weakening_multiplier":w})
func val(r: StringName) -> float: return float(ask(&"ResourceGetRequested", {"entity":&"hero","resource":r})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var rng = root.get_node("RngService")._rng
	var state: int = rng.state
	var q := preview(10,10,75,-20,0.5)
	check(q.get("accepted",false) and is_equal_approx(q["data"]["physical_after_protection"],2.5) and q["data"]["physical"] == 2 and q["data"]["magical"] == 6 and q["data"]["total"] == 8,"defense then weakening and separate ceil")
	check(preview(100,100,43,43,1).get("data",{}).get("total",-1) == 114,"decimal protection avoids spurious ceil")
	q = preview(0.1,0.1,0,0,1)
	check(q.get("accepted",false) and q["data"]["physical"] == 1 and q["data"]["magical"] == 1 and q["data"]["total"] == 2,"round each component, not total")
	check(preview(0,0,0,0,1).get("data",{}).get("total",-1) == 0,"zero remains zero")
	for w in [0.25,0.5,0.75,1.0]: check(preview(8,0,0,0,w).get("data",{}).get("physical",-1) == int(8*w),"all weakening tiers")
	for e in [
		{"physical":1,"magical":0,"physical_protection_percent":76,"magical_protection_percent":0,"weakening_multiplier":1},
		{"physical":1,"magical":0,"physical_protection_percent":0,"magical_protection_percent":0,"weakening_multiplier":0.3},
		{"physical":1,"magical":0,"physical_protection_percent":1.234,"magical_protection_percent":0,"weakening_multiplier":1},
		{"physical":-1,"magical":0,"physical_protection_percent":0,"magical_protection_percent":0,"weakening_multiplier":1},
		{"physical":1,"magical":NAN,"physical_protection_percent":0,"magical_protection_percent":0,"weakening_multiplier":1},
		{"physical":1000000000,"magical":1000000000,"physical_protection_percent":0,"magical_protection_percent":0,"weakening_multiplier":1},
		{"physical":1,"magical":0,"physical_protection_percent":0,"weakening_multiplier":1}]:
		check(not ask(&"DirectHitMitigationPreviewRequested",e).get("accepted",true),"reject invalid or oversized input")
	check(rng.state == state,"preview does not consume RNG")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,30)}).get("accepted",false),"map")
	var floors := []
	for x in range(30):
		for y in range(30): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"attacker"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_medium","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	for row in [[&"HP",20],[&"Stamina",1]]: check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":row[0],"value":row[1]}).get("accepted",false),"set")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false),"block")
	var crit := ask(&"CriticalHitPlanRequested", {"per":1000,"kind":&"direct_mixed","hits":[{"target":&"hero","physical":2.0,"magical":1.1}]})
	check(crit.get("accepted",false) and crit["data"]["hits"][0]["critical"],"prepare critical")
	var ch: Dictionary = crit["data"]["hits"][0]
	q = preview(ch["physical"],ch["magical"],25,-20,0.5)
	check(q.get("accepted",false) and q["data"]["physical"] == 2 and q["data"]["magical"] == 2,"mixed critical then mitigation")
	var applied := ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":20},"hits":[{"source":&"attacker","target":&"hero","damage":q["data"]["physical"],"magical_damage":q["data"]["magical"],"attack_tiles":[Vector2i(10,9)]}],"block":{"target":&"hero","direction":Vector2i.UP,"expected_stamina":1}})
	check(applied.get("accepted",false) and val(&"HP") == 18 and val(&"Stamina") == 0 and applied["data"]["block"]["absorbed"] == 2,"critical then protections then weakening then block physical only")
	print("Direct hit mitigation tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
