extends SceneTree
var failures := 0
var bus: Node
var descended: Array = []
var failed: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func reverse(d: String) -> String:
	return {"east":"west","west":"east","north":"south","south":"north"}[d]
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"DungeonDescended",func(e): descended.append(e.duplicate(true)))
	bus.subscribe(&"DungeonDescentFailed",func(e): failed.append(e.duplicate(true)))
	var save_path := "user://demo_session.save"
	var old_exists := FileAccess.file_exists(save_path)
	var old := PackedByteArray()
	if old_exists:
		var f := FileAccess.open(save_path,FileAccess.READ); old = f.get_buffer(f.get_length()); f.close()
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"demo initializes")
	check(ask(&"LevelMapGetRequested",{}).get("found",false),"demo has real level")
	# Deterministic chain is test scaffolding, not a claim that lazy generation
	# always finds the full route.
	var parents: Array = [Vector2i(23,12),Vector2i(35,12),Vector2i(47,12),Vector2i(47,24),Vector2i(35,24),Vector2i(24,24)]
	var dirs: Array = ["east","east","east","south","west","west"]
	var parent: StringName = game.ROOM
	for i in range(6):
		var id := StringName("demo_chain_%d" % i)
		var dir: String = dirs[i]
		check(ask(&"RoomCreateRequested",{"id":id,"type":"deadend" if i == 5 else "passage","origin_cell":parents[i],"size_cells":Vector2i(11,11) if i == 5 else Vector2i(12,12)}).get("accepted",false),"create chain %d" % i)
		var exit := &"east" if i == 0 else StringName("out_%d" % i)
		if i > 0: check(ask(&"RoomExitAddRequested",{"room":parent,"id":exit,"dir":dir,"offset_cells":5}).get("accepted",false),"parent exit %d" % i)
		check(ask(&"RoomExitAddRequested",{"room":id,"id":&"entry","dir":reverse(dir),"offset_cells":5}).get("accepted",false),"child exit %d" % i)
		check(ask(&"RoomExitConnectRequested",{"room":parent,"exit":exit,"other_room":id,"other_exit":&"entry"}).get("accepted",false),"connect %d" % i)
		if i == 5:
			var paint: Array = []
			for y in range(parents[i].y*4+1,parents[i].y*4+43):
				for x in range(parents[i].x*4+1,parents[i].x*4+43): paint.append(Vector2i(x,y))
			check(ask(&"SpaceTilesSetRequested",{"tiles":paint,"kind":1}).get("accepted",false),"stair room geometry")
		ask(&"RoomChildGenerated",{"room":parent,"child":id})
		parent = id
	var stair := ask(&"DungeonStairGetRequested",{})
	check(stair.get("found",false) and stair.get("data",{}).get("status","") == "placed","real stair " + str(stair))
	if not stair.get("found",false) or stair.get("data",{}).get("status","") != "placed": quit(1); return
	var stair_id: StringName = stair["data"]["object"]
	var tile: Vector2i = ask(&"ObjectGetRequested",{"object":stair_id})["data"]["tile"]
	var info: Dictionary = ask(&"RoomGetRequested",{"id":parent})["data"]
	var bounds := {"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
	var spot := Vector2i(-1,-1)
	for y in range(tile.y-4,tile.y+2):
		for x in range(tile.x-4,tile.x+2):
			var p := Vector2i(x,y)
			var adjacent := ((tile.x == p.x-1 or tile.x == p.x+4) and tile.y >= p.y and tile.y < p.y+4) or ((tile.y == p.y-1 or tile.y == p.y+4) and tile.x >= p.x and tile.x < p.x+4)
			if adjacent and ask(&"SpaceBodyFitsRequested",{"anchor":p,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false): spot=p; break
		if spot.x >= 0: break
	check(spot.x >= 0,"adjacent spot")
	check(ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null}).get("accepted",false),"test teleport unbounds")
	var move := ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":spot})
	check(move.get("accepted",false) and move.get("anchor",null) == spot,"test teleport to stair")
	check(ask(&"RoomEnterRequested",{"entity":game.HERO,"room":parent}).get("accepted",false),"enter stair room")
	ask(&"CombatDetectionChanged",{"entity":game.HERO,"active":false})
	var before_inventory: Array = ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].duplicate()
	# Принудительный отказ после фактического создания следующего уровня.
	# Проверяем именно транзакционный откат, а не только preflight.
	var fail_generation := func(e):
		if e.get("level_id",null) != &"demo_floor_1" and e.get("accepted",false): e["accepted"] = false
	bus.subscribe(&"LevelGenerationRequested",fail_generation)
	check(game._interact_chest(),"start descent for rollback " + game.message)
	check(driver.advance_steps(10) == 10 and failed.size() == 1 and failed[0].get("rolled_back",false),"late failure rolls back " + str(failed))
	bus.unsubscribe(&"LevelGenerationRequested",fail_generation)
	check(game.current_room == parent and ask(&"DungeonFloorTrackingGetRequested",{})["data"]["floor"] == 1 and ask(&"EntityGetRequested",{"entity":game.RAT}).get("found",false),"old world and scene restored")
	check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"] == before_inventory,"rollback preserves player items")
	failed.clear()
	check(game._interact_chest(),"retry descent " + game.message)
	if not game.message.begins_with("Спускаемся"):
		quit(1); return
	check(driver.advance_steps(5) == 5,"halfway")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save while descending")
	check(driver.advance_steps(5) == 5,"finish")
	check(descended.size() == 1 and failed.is_empty(),"descent succeeded " + str(failed))
	if descended.size() == 1:
		check(ask(&"DungeonFloorTrackingGetRequested",{})["data"]["floor"] == 2 and game.current_room == &"start","floor and scene updated")
		check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"] == before_inventory,"items retained")
		check(not ask(&"EntityGetRequested",{"entity":game.RAT}).get("found",true),"old tutorial rat cleaned")
		check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load mid-descent")
		check(driver.advance_steps(5) == 5 and descended.size() == 2 and failed.is_empty(),"replay saved descent " + str(failed))
		check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save new floor")
		var start_info: Dictionary = ask(&"RoomGetRequested",{"id":&"start"})["data"]
		var generated: Dictionary = {}
		for exit in start_info["exits"]:
			if not exit["connected"] and not exit["sealed"]:
				generated = ask(&"RoomChildGenerateRequested",{"room":&"start","exit":exit["id"]})
				if generated.get("accepted",false): break
		check(generated.get("accepted",false),"generate second-floor room " + str(generated))
		if generated.get("accepted",false):
			var child: StringName = generated["child"]
			var child_info: Dictionary = ask(&"RoomGetRequested",{"id":child})["data"]
			var origin: Vector2i = child_info["origin_cell"] * 4
			var size: Vector2i = child_info["size_cells"] * 4
			var area := {"origin":origin,"size":size}
			var landing := Vector2i(-1,-1)
			for y in range(origin.y,origin.y+size.y-3):
				for x in range(origin.x,origin.x+size.x-3):
					var p := Vector2i(x,y)
					if ask(&"SpaceBodyFitsRequested",{"anchor":p,"size":4,"room":area,"ignore_entity":game.HERO}).get("fits",false): landing=p; break
				if landing.x >= 0: break
			check(landing.x >= 0,"second-floor landing")
			ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null})
			check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":landing}).get("accepted",false),"move to second-floor room")
			check(ask(&"RoomEnterRequested",{"entity":game.HERO,"room":child}).get("accepted",false),"enter second-floor room")
			await process_frame
			await process_frame
			await process_frame
			var spawn := ask(&"RoomSpawnStatusRequested",{"room":child})
			check(spawn.get("spawned",false),"second-floor deferred spawn " + str(spawn) + " " + game.message)
			check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save spawned second-floor room")
			check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load spawned second-floor room")
			await process_frame
			check(ask(&"RoomSpawnStatusRequested",{"room":child}).get("data",{}).get("placed",[]) == spawn.get("data",{}).get("placed",[]),"spawn not duplicated")
	game.queue_free()
	await process_frame
	if old_exists:
		var f := FileAccess.open(save_path,FileAccess.WRITE); f.store_buffer(old); f.close()
	elif FileAccess.file_exists(save_path): DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
	print("Game demo descent: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
