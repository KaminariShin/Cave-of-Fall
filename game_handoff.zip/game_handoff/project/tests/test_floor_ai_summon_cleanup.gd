extends SceneTree
var failures := 0
var summons: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, what: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", what)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func exists(id: StringName) -> bool: return ask(&"EntityGetRequested", {"entity":id}).get("found", false)
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	root.get_node("EventBus").subscribe(&"AISummoned", func(e): summons.append(e["summon"]))
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(100,100)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"r", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(12,12), "size":4}).get("accepted", false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"r"}).get("accepted", false), "enter")
	check(ask(&"EntityCreateRequested", {"entity":&"summoner"}).get("accepted", false), "summoner")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"summoner", "anchor":Vector2i(24,24), "size":4}).get("accepted", false), "summoner body")
	check(ask(&"AIRegisterRequested", {"entity":&"summoner", "room":&"r", "role":"summoner", "target":&"hero", "detected":true, "wait_duration":0.05}).get("accepted", false), "summoner AI")
	check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":15.0}).get("accepted", false), "hero wait")
	ask(&"ResourceSetRequested", {"entity":&"summoner", "resource":&"MP", "value":25})
	driver.advance_steps(1)
	var pending_attempt := {}
	var pending_result: Dictionary = root.get_node("SaveService").run_world_transition_transaction(func(): pending_attempt["r"] = root.get_node("FloorSpawnCleanup").discard_ai_summons_for_transition(); return pending_attempt["r"].get("accepted", false))
	check(not pending_attempt["r"].get("accepted", true) and pending_result.get("rolled_back", false), "pending summon blocks cleanup")
	var during := {"tried":false, "accepted":true}
	var on_spawn := func(_e):
		during["tried"] = true
		during["accepted"] = ask(&"SessionSaveRequested", {}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"RatSpawned", on_spawn)
	driver.advance_steps(209)
	root.get_node("EventBus").unsubscribe(&"RatSpawned", on_spawn)
	check(during["tried"] and not during["accepted"], "snapshot blocked during summon completion")
	if summons.is_empty():
		check(false, "real summon")
		quit(1)
		return
	var first: StringName = summons[0]
	ask(&"ResourceSetRequested", {"entity":&"summoner", "resource":&"MP", "value":25})
	driver.advance_steps(210)
	if summons.size() < 2:
		check(false, "second real summon")
		quit(1)
		return
	var second: StringName = summons[1]
	check(ask(&"InventoryConfigureRequested", {"entity":first, "volume":10}).get("accepted", false), "first inventory")
	check(ask(&"ItemCreateRequested", {"id":&"rat_item", "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "create item")
	check(ask(&"InventoryAddRequested", {"entity":first, "item":&"rat_item"}).get("accepted", false), "summon item")
	check(ask(&"CombatDamageRequested", {"entity":second, "source":&"hero", "amount":9999}).get("accepted", false), "kill second")
	check(ask(&"EntityRemoveRequested", {"entity":&"summoner"}).get("accepted", false), "remove summoner")
	check(exists(first) and exists(second), "summons survive summoner removal")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save tracked summons")
	var snapshot := {"sections":{}, "errors":[]}
	ask(&"SnapshotCollectRequested", snapshot)
	check(snapshot["sections"]["ai"]["tracked"].has(first) and snapshot["sections"]["ai"]["tracked"].has(second), "live and dead summons tracked after owner removal")
	check(not ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "summons guard map")
	var cleanup = root.get_node("FloorSpawnCleanup")
	var save = root.get_node("SaveService")
	check(not cleanup.discard_ai_summons_for_transition().get("accepted", false), "requires transition")
	check(ask(&"ProcessStartRequested", {"id":&"independent_rat", "entity":first, "duration":2.0, "independent":true}).get("accepted", false), "independent process")
	var attempt := {}
	var result: Dictionary = save.run_world_transition_transaction(func(): attempt["r"] = cleanup.discard_ai_summons_for_transition(); return true)
	check(not attempt["r"].get("accepted", true) and result.get("rolled_back", false), "independent process blocks")
	ask(&"ProcessInterruptRequested", {"id":&"independent_rat"})
	var veto := func(e):
		if e.get("entity", &"") == second: e["allowed"] = false
	root.get_node("EventBus").subscribe(&"LootEntityRemovalCheckRequested", veto)
	result = save.run_world_transition_transaction(func(): attempt["r"] = cleanup.discard_ai_summons_for_transition(); return true)
	root.get_node("EventBus").unsubscribe(&"LootEntityRemovalCheckRequested", veto)
	check(not attempt["r"].get("accepted", true) and result.get("rolled_back", false), "partial removal rolls back")
	check(exists(first) and exists(second) and ask(&"ItemGetRequested", {"item":&"rat_item"}).get("found", false), "rollback restores entities and item")
	result = save.run_world_transition_transaction(func(): attempt["r"] = cleanup.discard_ai_summons_for_transition(); return attempt["r"].get("accepted", false))
	check(result.get("committed", false) and attempt["r"].get("entities", []).has(first) and attempt["r"].get("entities", []).has(second), "cleanup live and dead summons")
	check(not exists(first) and not exists(second) and exists(&"hero") and not ask(&"ItemGetRequested", {"item":&"rat_item"}).get("found", false), "summons and item removed, hero preserved")
	check(ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "map guard released")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save cleanup")
	print("Floor AI summon cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
