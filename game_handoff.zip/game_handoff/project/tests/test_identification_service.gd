extends SceneTree
var failures := 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"MaterialRegisterRequested", {"material": {"id": "mat", "name": "M", "weight_per_unit": 1, "volume_per_unit": 1, "level": 20}})["accepted"], "material")
	check(ask(bus, &"ItemBaseRegisterRequested", {"base": {"id": "base", "name": "B", "materials": [{"material_id": "mat", "count": 1}], "base_int_req": 999}})["accepted"], "base")
	check(not ask(bus, &"ItemCreateRequested", {"id": &"missing", "base_id": &"base"})["accepted"], "item level required at creation")
	check(ask(bus, &"ItemCreateRequested", {"id": &"magic", "base_id": &"base", "item_level": 17, "rarity": &"magic"})["accepted"], "item")
	var requirement := ask(bus, &"IdentificationRequirementGetRequested", {"item": &"magic"})
	check(requirement["found"] and requirement["value"] == 7.0, "ceil(5+17/10) at creation")
	var item := ask(bus, &"ItemGetRequested", {"item": &"magic"})
	check(item["item_data"]["int_req"] == 7.0, "requirement stored")
	check(entities.create_entity(&"weak") and entities.create_entity(&"smart", {&"stats": {"INT": 7}}), "observers")
	var weak := ask(bus, &"IdentificationCheckRequested", {"entity": &"weak", "item": &"magic"})
	var smart := ask(bus, &"IdentificationCheckRequested", {"entity": &"smart", "item": &"magic"})
	check(weak["found"] and not weak["identified"] and smart["identified"], "per-entity INT comparison")
	var use := ask(bus, &"IdentificationUseCheckRequested", {"entity": &"weak", "item": &"magic"})
	check(use["found"] and use["unidentified_use"] and not use["identification_blocks_equip"], "unidentified does not block equipment")
	ask(bus, &"StatBaseSetRequested", {"entity": &"weak", "stat": &"INT", "value": 7})
	check(ask(bus, &"IdentificationCheckRequested", {"entity": &"weak", "item": &"magic"})["identified"], "uses current effective INT")
	check(ask(bus, &"ModDefinitionRegisterRequested", {"definition": {"id": "mod", "category": "prefix", "stat": "INT", "tiers": [{"tier": 1, "value": 100, "level_req": 0, "weight": 1}]}})["accepted"], "mod definition")
	check(ask(bus, &"ModRollApplyRequested", {"item": &"magic", "mod_id": &"mod"})["accepted"], "attach mod")
	check(ask(bus, &"IdentificationRequirementGetRequested", {"item": &"magic"})["value"] == 7.0, "mod does not change requirement")
	var saved := ask(bus, &"SessionSaveRequested", {})
	check(saved.get("accepted", false), "save")
	var loaded := ask(bus, &"SessionLoadRequested", {})
	check(loaded.get("accepted", false) and ask(bus, &"IdentificationRequirementGetRequested", {"item": &"magic"})["value"] == 7.0, "requirement survives save")
	print("Identification tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
