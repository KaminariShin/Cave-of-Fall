extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func act(id: StringName) -> Dictionary: return ask(&"ActionGetRequested", {"entity":id})
func hp(id: StringName,k: String) -> int: return int(ask(&"ResourceGetRequested", {"entity":id,"resource":&"HP"})["data"][k])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	var def := {"id":&"mid_test","name":"mid","type":&"physical","base_duration":0.04,"phase_completion":true,"phase_trigger":"midpoint","interruptible":true}
	var bad := def.duplicate(true); bad["id"] = &"bad"; bad["phase_trigger"] = "other"
	check(not ask(&"ActionDefinitionRegisterRequested", {"data":bad}).get("accepted",true),"invalid trigger")
	bad["phase_trigger"] = "midpoint"; bad["phase_completion"] = false
	check(not ask(&"ActionDefinitionRegisterRequested", {"data":bad}).get("accepted",true),"midpoint requires phased completion")
	check(ask(&"ActionDefinitionRegisterRequested", {"data":def}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"hero","action":&"mid_test","duration":0.04}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"mid_test","duration":0.05}).get("accepted",false),"start actions")
	var seen := []
	var completed := []
	var phase := func(e):
		for row in e.get("actions",[]):
			if row["action"] == &"mid_test": seen.append([row["entity"],row["elapsed_steps"],row["duration_steps"]])
	var on_complete := func(e):
		if e.get("action",null) == &"mid_test": completed.append(e["entity"])
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"ActionCompleted",on_complete)
	check(driver.advance_steps(2) == 2 and seen == [[&"hero",2,4]] and completed.is_empty() and act(&"hero").get("found",false) and ask(&"SessionSaveRequested",{}).get("accepted",false),"even midpoint at step 2 before finish")
	var saver = root.get_node("SaveService")
	var corrupt: Dictionary = saver.collect_world_transition_snapshot()["payload"].duplicate(true)
	corrupt["sections"]["actions"]["definitions"][&"mid_test"]["phase_trigger"] = "bad"
	check(not saver._validate_snapshot(corrupt),"saved trigger validated")
	check(driver.advance_steps(1) == 1 and seen == [[&"hero",2,4],[&"npc",3,5]] and completed.is_empty(),"odd midpoint rounds up to step 3")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load before odd midpoint")
	seen.clear()
	check(driver.advance_steps(1) == 1 and seen == [[&"npc",3,5]],"restore emits odd midpoint once, not even again")
	check(driver.advance_steps(1) == 1 and completed == [&"hero"] and act(&"npc").get("found",false),"hero finishes at step 4, NPC not early")
	check(driver.wait_for(0.01) and driver.advance_steps(1) == 1 and completed == [&"hero",&"npc"] and seen == [[&"npc",3,5]],"NPC completes step 5 without second midpoint")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"ActionCompleted",on_complete)
	var maxhp := hp(&"hero","max")
	var threshold := ceili(maxhp/4.0)
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"mid_test"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"mid_test","duration":0.04}).get("accepted",false),"same midpoint")
	var combat := {"submits":0,"batch":false,"staggers":0,"interrupted":0}
	var mid := func(e):
		if e.get("actions",[]).size() == 2:
			for row in [[&"hero",&"npc"],[&"npc",&"hero"]]:
				if ask(&"CombatPhaseHitSubmitRequested", {"source":row[0],"target":row[1],"damage":threshold,"hp_before":hp(row[1],"current")}).get("accepted",false): combat["submits"] += 1
	var batch := func(e): combat["batch"] = e.get("accepted",false) and combat["submits"] == 2
	var stagger := func(e): combat["staggers"] = e.get("outcomes",[]).size()
	var interrupt := func(e):
		if e.get("action",null) == &"mid_test": combat["interrupted"] += 1
	bus.subscribe(&"TimeCombatPhase",mid); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"PhaseStaggerResolved",stagger); bus.subscribe(&"ActionInterrupted",interrupt)
	check(driver.advance_steps(2) == 2 and combat["batch"] and combat["staggers"] == 2 and combat["interrupted"] == 2 and act(&"hero")["data"]["id"] == &"stagger" and act(&"npc")["data"]["id"] == &"stagger", "both midpoint hits apply before both actions stagger-interrupted")
	bus.unsubscribe(&"TimeCombatPhase",mid); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"PhaseStaggerResolved",stagger); bus.unsubscribe(&"ActionInterrupted",interrupt)
	print("Combat midpoint tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
