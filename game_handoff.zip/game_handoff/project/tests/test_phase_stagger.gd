extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func resource(id: StringName,key: String) -> int: return int(ask(&"ResourceGetRequested", {"entity":id,"resource":&"HP"})["data"][key])
func action(id: StringName) -> Dictionary: return ask(&"ActionGetRequested", {"entity":id})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ActionDefinitionRegisterRequested", {"data":{"id":&"phase_test","name":"test","type":&"physical","base_duration":0.03,"interruptible":true,"phase_completion":true}}).get("accepted",false),"control and action")
	var maximum := resource(&"hero","max")
	var threshold := ceili(maximum / 4.0)
	check(maximum == resource(&"npc","max") and resource(&"hero","current") == maximum and resource(&"npc","current") == maximum,"fixture")
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"phase_test"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"phase_test"}).get("accepted",false),"start both")
	var log := []
	var seen := {"queued":false,"finished_before":true,"results":[],"blocked_save":false,"blocked_advance":false,"phase_events":0}
	var complete := func(e):
		if e.get("action",null) == &"phase_test": log.append("finish_" + str(e["entity"]))
	var started := func(e):
		if e.get("action",null) == &"stagger":
			seen["finished_before"] = seen["finished_before"] and log.has("finish_hero") and log.has("finish_npc")
			log.append("stagger_" + str(e["entity"]))
	var phase := func(e):
		if e.get("actions",[]).size() == 2:
			var q := ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":maximum,&"npc":maximum},"hits":[{"source":&"hero","target":&"npc","damage":threshold},{"source":&"npc","target":&"hero","damage":threshold}],"phase_commit":true,"apply_stagger":true})
			seen["queued"] = q.get("accepted",false) and q["data"]["stagger"].size() == 2 and q["data"]["stagger"][0]["reason"] == "queued" and action(&"hero")["data"]["id"] == &"phase_test" and action(&"npc")["data"]["id"] == &"phase_test"
	var done := func(e):
		seen["phase_events"] += 1
		seen["results"] = e.get("outcomes",[]).duplicate(true)
		seen["blocked_save"] = not root.get_node("SaveService").collect_world_transition_snapshot().get("valid",true)
		seen["blocked_advance"] = driver.advance_steps(1) == 0
	bus.subscribe(&"ActionCompleted",complete); bus.subscribe(&"ActionStarted",started); bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"PhaseStaggerResolved",done)
	check(driver.advance_steps(3) == 3 and seen["queued"] and seen["finished_before"] and log.size() == 4 and seen["phase_events"] == 1 and seen["results"].size() == 2 and seen["results"][0]["applied"] and seen["results"][1]["applied"] and seen["blocked_save"] and seen["blocked_advance"],"both strikes finish before stagger, postphase protected")
	check(action(&"hero")["data"]["id"] == &"stagger" and action(&"npc")["data"]["id"] == &"stagger" and driver.current_action_id == &"stagger", "both actors stagger; controlled new turn started")
	bus.unsubscribe(&"ActionCompleted",complete); bus.unsubscribe(&"ActionStarted",started); bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"PhaseStaggerResolved",done)
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and driver.advance_steps(20) == 20 and ask(&"SessionLoadRequested",{}).get("accepted",false) and action(&"hero")["data"]["id"] == &"stagger" and driver.advance_steps(20) == 20,"post-phase stagger persists and expires")
	check(ask(&"ActionDefinitionRegisterRequested", {"data":{"id":&"protected_test","name":"protected","type":&"utility","base_duration":1.0,"interruptible":false}}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"protected_test"}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"hero","action":&"phase_test"}).get("accepted",false),"immune scenario")
	var immune := {"outcome":{}}
	var p2 := func(e):
		if e.get("actions",[]).size() == 1:
			ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"npc":resource(&"npc","current")},"hits":[{"source":&"hero","target":&"npc","damage":threshold}],"phase_commit":true,"apply_stagger":true})
	var d2 := func(e): immune["outcome"] = e["outcomes"][0].duplicate(true)
	bus.subscribe(&"TimeCombatPhase",p2); bus.subscribe(&"PhaseStaggerResolved",d2)
	check(driver.advance_steps(3) == 3 and immune["outcome"].get("triggered",false) and immune["outcome"].get("reason","") == "uninterruptible" and action(&"npc")["data"]["id"] == &"protected_test","immune action not replaced")
	bus.unsubscribe(&"TimeCombatPhase",p2); bus.unsubscribe(&"PhaseStaggerResolved",d2)
	print("Phase stagger tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
