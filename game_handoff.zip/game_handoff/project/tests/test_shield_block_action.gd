extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func status(id: StringName) -> Dictionary: return ask(&"ShieldBlockStatusRequested", {"entity":id})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "actors")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	for actor in [&"hero",&"npc"]: check(ask(&"InventoryConfigureRequested", {"entity":actor,"volume":100}).get("accepted",false), "inventory")
	check(not ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",true), "no shield")
	check(not ask(&"ActionStartRequested", {"entity":&"hero","action":&"shield_block"}).get("accepted",true), "direct start forbidden")
	for entry in [[&"shield",&"hero"],[&"npc_shield",&"npc"]]:
		check(ask(&"ItemCreateRequested", {"id":entry[0],"base_id":&"shield_small","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":entry[1],"item":entry[0]}).get("accepted",false), "create shield")
		check(ask(&"EquipmentEquipRequested", {"entity":entry[1],"item":entry[0],"slot":"off"}).get("accepted",false), "equip begins")
		if entry[1] == &"npc": check(driver.wait_for(0.1), "advance NPC equip")
		check(driver.advance_steps(10) == 10, "equip completes")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":0}).get("accepted",false), "empty stamina")
	check(not ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"main","direction":Vector2i.UP}).get("accepted",true), "wrong hand")
	check(not ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off"}).get("accepted",true) and not ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i(1,1)}).get("accepted",true), "direction required and cardinal")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false) and status(&"hero").get("active",false) and status(&"hero").get("direction",null) == Vector2i.UP, "block at zero stamina, fixed direction")
	check(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]["current"] == 0, "start does not spend")
	check(not ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"off"}).get("accepted",true), "busy action prevents unequip")
	check(driver.advance_steps(20) == 20 and status(&"hero").get("active",false), "active mid action")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save active block")
	var f := FileAccess.open("user://session.save",FileAccess.READ)
	var saved: Dictionary = bytes_to_var(f.get_buffer(f.get_length())); f.close()
	for variant in [0,1,2,3,4]:
		var bad: Dictionary = saved.duplicate(true)
		match variant:
			0: bad["sections"]["shield_block_actions"].erase(&"hero")
			1: bad["sections"]["shield_block_actions"][&"hero"]["item"] = &"missing"
			2: bad["sections"]["shield_block_actions"][&"hero"]["slot"] = "main"
			3: bad["sections"]["shield_block_actions"][&"hero"]["direction"] = Vector2i(1,1)
			4: bad["sections"]["shield_block_actions"][&"hero"].erase("direction")
		f = FileAccess.open("user://session.save",FileAccess.WRITE); f.store_buffer(var_to_bytes(bad)); f.close()
		check(not ask(&"SessionLoadRequested",{}).get("accepted",true), "corrupt block snapshot rejected")
	f = FileAccess.open("user://session.save",FileAccess.WRITE); f.store_buffer(var_to_bytes(saved)); f.close()
	var observed := {"end_active":false,"completed":0}
	var on_action := func(e):
		if e.get("entity",null) == &"hero" and e.get("action",null) == &"shield_block": observed["end_active"] = status(&"hero").get("active",false)
	var on_done := func(e):
		if e.get("entity",null) == &"hero": observed["completed"] += 1
	bus.subscribe(&"ActionCompleted",on_action)
	bus.subscribe(&"ShieldBlockCompleted",on_done)
	check(driver.advance_steps(30) == 30 and observed["end_active"] and observed["completed"] == 1 and not status(&"hero").get("active",false), "active through completion, then cleared")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and status(&"hero").get("active",false) and status(&"hero").get("direction",null) == Vector2i.UP and driver.advance_steps(30) == 30 and observed["completed"] == 2, "restore block resumes")
	bus.unsubscribe(&"ActionCompleted",on_action); bus.unsubscribe(&"ShieldBlockCompleted",on_done)
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false) and driver.advance_steps(5) == 5 and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and not status(&"hero").get("active",false), "cancel block")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"npc","slot":"off","direction":Vector2i.UP}).get("accepted",false) and driver.wait_for(0.5), "NPC block")
	var npc_last := {"active":false,"ending":false}
	var on_tick := func(_e):
		var v := status(&"npc")
		if v.get("ending",false): npc_last["active"] = v["active"]; npc_last["ending"] = true
	bus.subscribe(&"Tick",on_tick)
	check(driver.advance_steps(50) == 50 and npc_last["active"] and npc_last["ending"] and not status(&"npc").get("active",false), "NPC block remains active after completion within final tick")
	bus.unsubscribe(&"Tick",on_tick)
	# Смерть на том же шаге, где NPC уже завершил действие: уборка владения
	# не должна блокироваться остаточным статусом до конца шага.
	check(ask(&"ShieldBlockStartRequested", {"entity":&"npc","slot":"off","direction":Vector2i.UP}).get("accepted",false) and driver.wait_for(0.5), "NPC second block")
	var dying := {"ownership_allowed":false,"hit":false}
	var on_damage := func(e):
		if e.get("entity",null) == &"npc": dying["ownership_allowed"] = ask(&"EntityOwnershipMutationCheckRequested", {"entity":&"npc","allowed":true})["allowed"]
	var kill_last := func(_e):
		if not dying["hit"] and status(&"npc").get("ending",false):
			dying["hit"] = true
			ask(&"CombatDamageRequested", {"entity":&"npc","amount":99999})
	bus.subscribe(&"EntityDamaged",on_damage)
	bus.subscribe(&"Tick",kill_last)
	check(driver.advance_steps(50) == 50 and dying["hit"] and dying["ownership_allowed"] and not status(&"npc").get("active",false), "death on ending tick releases ownership guard")
	bus.unsubscribe(&"Tick",kill_last); bus.unsubscribe(&"EntityDamaged",on_damage)
	print("Shield block action tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
