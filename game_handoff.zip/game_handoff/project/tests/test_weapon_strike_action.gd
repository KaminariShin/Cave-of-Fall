extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool, label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func plan(d = Vector2.RIGHT, strike = "sword_simple_thrust") -> Dictionary:
	return ask(&"WeaponStrikeStartPlanRequested", {"entity":&"hero","item":&"sword","strike":strike,"direction":d})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(5,5),"size":2}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false),"inventory")
	check(ask(&"ItemCreateRequested", {"id":&"sword","base_id":&"sword_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"sword"}).get("accepted",false),"item")
	check(not plan().get("accepted",true),"inventory weapon rejected")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false),"equip")
	check(root.get_node("TimeDriver").advance_steps(10) == 10,"complete equip")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":4}).get("accepted",false),"stamina")
	var before = ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]["current"]
	check(not ask(&"ActionStartRequested", {"entity":&"hero","action":&"weapon_strike"}).get("accepted",false),"bypass rejected")
	var started := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2(3,4)})
	check(started.get("accepted",false),"start")
	if not started.get("accepted",false): print("start error: ",started); quit(1); return
	var p: Dictionary = started["data"]
	check(p["spend"] == 4 and p["damage_multiplier"] == 0.5 and p["direction"].is_equal_approx(Vector2(0.6,0.8)),"parameters fixed")
	check(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]["current"] == before - 4,"paid once")
	check(not ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"main"}).get("accepted",true),"cannot change equipment while busy")
	var bus = root.get_node("EventBus")
	var events := []
	var mid := func(e): events.append(e.duplicate(true))
	bus.subscribe(&"WeaponStrikeMidpoint",mid)
	var driver = root.get_node("TimeDriver")
	var midpoint: int = ceili(float(p["duration_steps"])/2.0)
	check(driver.advance_steps(midpoint - 1) == midpoint - 1 and events.is_empty(),"before midpoint")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save before midpoint")
	var snap: Dictionary = root.get_node("SaveService").collect_world_transition_snapshot()
	check(snap.get("valid",false),"valid active snapshot")
	if snap.get("valid",false):
		var damaged: Dictionary = snap["payload"].duplicate(true)
		damaged["sections"]["weapon_strike_actions"][&"hero"]["direction"] = Vector2.ZERO
		check(not root.get_node("SaveService")._validate_snapshot(damaged),"invalid saved direction")
		damaged = snap["payload"].duplicate(true)
		damaged["sections"]["weapon_strike_actions"].erase(&"hero")
		check(not root.get_node("SaveService")._validate_snapshot(damaged),"orphan active action rejected")
	check(driver.advance_steps(1) == 1 and events.size() == 1 and events[0]["data"]["direction"].is_equal_approx(Vector2(0.6,0.8)),"midpoint once")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load active strike")
	events.clear()
	check(driver.advance_steps(1) == 1 and events.size() == 1,"midpoint after restore")
	check(driver.advance_steps(p["duration_steps"] - midpoint) == p["duration_steps"] - midpoint and events.size() == 1 and not ask(&"WeaponStrikeActionStatusRequested", {"entity":&"hero"}).get("active",true),"finish without duplicate")
	bus.unsubscribe(&"WeaponStrikeMidpoint",mid)
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":4}).get("accepted",false),"restore resource")
	var nested := {"count":-1,"save":true}
	var on_start := func(e):
		if e.get("action",null) == &"weapon_strike":
			nested["count"] = driver.advance_steps(1)
			nested["save"] = ask(&"SessionSaveRequested",{}).get("accepted",true)
	bus.subscribe(&"ActionStarted",on_start)
	check(ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT}).get("accepted",false),"second start")
	bus.unsubscribe(&"ActionStarted",on_start)
	check(nested["count"] == 0 and not nested["save"],"no reentrant tick or snapshot before payment")
	check(ask(&"ActionCancelRequested", {"entity":&"hero","reason":&"test"}).get("accepted",false),"interrupt")
	check(not ask(&"WeaponStrikeActionStatusRequested", {"entity":&"hero"}).get("active",true) and ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]["current"] == 0,"interrupt no refund")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":4}).get("accepted",false),"restore for stale preflight")
	var perturb := func(e):
		if e.get("action",null) == &"weapon_strike": ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":3})
	bus.subscribe(&"ActionStarted",perturb)
	var failed := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	bus.unsubscribe(&"ActionStarted",perturb)
	check(not failed.get("accepted",true) and not ask(&"ActionGetRequested", {"entity":&"hero"}).get("found",false) and ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]["current"] == 3,"stale resource cancels without charging")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":0.5}).get("accepted",false),"low stamina")
	check(not ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT}).get("accepted",true),"low stamina rejects start")
	print("Weapon strike action tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
