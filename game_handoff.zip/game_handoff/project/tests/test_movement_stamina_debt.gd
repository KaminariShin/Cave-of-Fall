extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func getres(id: StringName) -> Dictionary:
	return ask(&"ResourceGetRequested", {"entity":&"hero","resource":id})["data"]
func setres(id: StringName,v: float) -> void:
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":id,"value":v}).get("accepted",false),"set")
func charge(v: float) -> Dictionary:
	return ask(&"MovementStaminaChargeRequested", {"entity":&"hero","amount":v})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(root.get_node("EntityRegistry").create_entity(&"hero",{&"stats":{"CON":20}}),"create")
	var service = root.get_node("ResourceService")
	setres(&"HP",50)
	setres(&"Stamina",1)
	service._regen_cycle(&"hero",&"HP")
	check(getres(&"HP")["reserve"] == 2 and getres(&"HP")["reserve_filled"] == 1,"pending HP reserve")
	var first := charge(0.5)
	check(first.get("accepted",false) and first["charged"] == 0 and first["remainder"] == 0.5,"half cost accumulates")
	var second := charge(2.0)
	check(second.get("accepted",false) and second["debt"] == 2 and second["remainder"] == 0.5 and getres(&"Stamina")["current"] == 0,"debt tracked")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save debt and reserve")
	service._regen_cycle(&"hero",&"Stamina")
	check(getres(&"Stamina")["movement_debt"] == 0 and getres(&"HP")["reserve"] == 0 and getres(&"HP")["current"] == 51 and getres(&"Stamina")["current"] == 0 and getres(&"Stamina")["remainder"] == 0.5,"debt before reserve before free")
	service._regen_cycle(&"hero",&"Stamina")
	check(getres(&"Stamina")["current"] == 4 and getres(&"Stamina")["remainder"] == 0,"next regen goes free")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and getres(&"Stamina")["movement_debt"] == 2 and getres(&"Stamina")["movement_remainder"] == 0.5 and getres(&"HP")["reserve_filled"] == 1,"restore debt and remainder")
	for value in [-0.1,INF,NAN]: check(not charge(value).get("accepted",true),"reject invalid charge")
	var saver = root.get_node("SaveService")
	var payload: Dictionary = saver.collect_world_transition_snapshot()["payload"]
	for row in [["movement_debt",0.5],["movement_debt",-1],["movement_debt",INF],["movement_debt",null],["movement_remainder",-0.1],["movement_remainder",1.0],["movement_remainder",null]]:
		var broken: Dictionary = payload.duplicate(true)
		broken["sections"]["entities"][&"hero"][&"resources"][&"Stamina"][row[0]] = row[1]
		check(not saver._validate_snapshot(broken),"invalid snapshot " + str(row))
	check(charge(0.5)["debt"] == 3 and getres(&"Stamina")["movement_remainder"] == 0,"carry survives load")
	setres(&"HP", getres(&"HP")["max"])
	setres(&"Stamina", 0)
	var driver = root.get_node("TimeDriver")
	check(driver.wait_for(1.0) and driver.advance_steps(50) == 50, "advance real timer")
	check(getres(&"Stamina")["movement_debt"] == 0 and getres(&"Stamina")["current"] == 0 and getres(&"Stamina")["remainder"] == 0.5, "real timer pays debt before free")
	check(driver.advance_steps(50) == 50 and getres(&"Stamina")["current"] == 4, "real timer restores free after debt")
	setres(&"Stamina", 2)
	check(charge(0.5)["charged"] == 0 and charge(0.5)["paid"] == 1 and getres(&"Stamina")["current"] == 1,"paid whole cost from free")
	print("Movement stamina debt tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
