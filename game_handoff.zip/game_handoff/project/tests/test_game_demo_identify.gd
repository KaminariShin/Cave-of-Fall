extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func key(game:Node,code:Key)->void:
	var e:=InputEventKey.new();e.pressed=true;e.keycode=code;game._unhandled_key_input(e)
func state(id:StringName)->Dictionary:
	return ask(&"ItemGetRequested",{"item":id})["item_data"]["learning_state"]
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save";var exists:=FileAccess.file_exists(path);var old:=PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized,"initialization")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet rat")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":50}).get("accepted",false),"capacity")
	for i in range(4):
		var id:=StringName("identify_filler_%d"%i)
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"filler")
	var bases:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema:Dictionary=root.get_node("DungeonChestLearningService").schema_for(&"armor_cloth_body",bases)
	for id in [&"identify_armour",&"cancel_armour"]:
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"armor_cloth_body","item_level":10,"rarity":&"magic","learning":schema}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"learning armour")
	var mod:={"id":&"pre_vital","category":"prefix","stat":"CON","tier":3,"value":1.0,"level_req":1,"material_id":&"cloth_light","unlock_after":5}
	check(ask(&"ItemModAttachRequested",{"item":&"identify_armour","mod":mod}).get("accepted",false),"armour mod")
	check(game._toggle_inventory() and driver.advance_steps(1)==1 and game.inventory_open,"inventory opens")
	var items:Array=ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]
	var index:=items.find(&"identify_armour");check(index>=9 and index<18,"armour on second page")
	check(game._inventory_item_label(ask(&"ItemGetRequested",{"item":&"identify_armour"}),&"").contains("не опознано"),"unidentified label")
	check(ask(&"StatBaseSetRequested",{"entity":game.HERO,"stat":&"INT","value":0}).get("accepted",false),"low INT")
	var time:float=driver.game_time
	key(game,KEY_RIGHT);key(game,KEY_T)
	check(game.inventory_page==1 and game.identify_mode and driver.game_time==time,"navigate and enable identification for free")
	key(game,KEY_1+index-9)
	check(not state(&"identify_armour")["identified"] and game.message.contains("не хватает INT") and driver.game_time==time,"insufficient INT reported, no action")
	check(ask(&"StatBaseSetRequested",{"entity":game.HERO,"stat":&"INT","value":100}).get("accepted",false),"sufficient INT")
	key(game,KEY_1+index-9)
	check(game.message.contains("Опознаём") and ask(&"ActionGetRequested",{"entity":game.HERO})["data"]["id"]==&"item_learning_identify","number starts action")
	check(driver.advance_steps(50)==50 and not state(&"identify_armour")["identified"],"half second remains unknown")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save pending identify")
	check(driver.advance_steps(50)==50 and state(&"identify_armour")["identified"] and game.message.contains("Опознан"),"identify after one second")
	check(game._inventory_item_label(ask(&"ItemGetRequested",{"item":&"identify_armour"}),&"").contains("опознано") and not game._inventory_item_label(ask(&"ItemGetRequested",{"item":&"identify_armour"}),&"").contains("не опознано"),"identified label")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and game.inventory_open and not game.identify_mode and game.inventory_page==0 and not state(&"identify_armour")["identified"],"load pending action resets UI mode")
	check(driver.advance_steps(50)==50 and state(&"identify_armour")["identified"] and game.message.contains("Опознан"),"restored action completes")
	key(game,KEY_RIGHT);key(game,KEY_T);key(game,KEY_1+index-9)
	check(game.message.contains("уже опознан"),"repeat explained")
	key(game,KEY_T)
	var before:float=ask(&"StatGetRequested",{"entity":game.HERO,"stat":&"CON"})["value"]
	key(game,KEY_1+index-9)
	check(driver.advance_steps(10)==10 and ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"})["data"].get("body",null)==&"identify_armour","equip identified armour")
	check(ask(&"StatGetRequested",{"entity":game.HERO,"stat":&"CON"})["value"]==before+1,"identified mod takes effect")
	var updated:Array=ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]
	var cancel_index:=updated.find(&"cancel_armour")-9
	key(game,KEY_T);key(game,KEY_1+cancel_index)
	check(driver.advance_steps(20)==20 and ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false) and not state(&"cancel_armour")["identified"] and game.message.contains("не завершено"),"cancellation reported")
	key(game,KEY_TAB);check(game.equipment_view and not game.identify_mode,"tab exits identification")
	key(game,KEY_T);check(not game.equipment_view and game.identify_mode,"T from equipment enters identification")
	game.queue_free();await process_frame
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo identify: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
