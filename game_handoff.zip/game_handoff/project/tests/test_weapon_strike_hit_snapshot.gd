extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func snap(candidates: Array) -> Dictionary:
	return ask(&"WeaponStrikeHitSnapshotRequested", {"entity":&"hero","candidates":candidates})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"a",&"z",&"far"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5),2],[&"a",Vector2i(10,5),2],[&"z",Vector2i(12,5),2],[&"far",Vector2i(4,12),2]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":row[2]}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"sword","base_id":&"sword_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"sword"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	check(not snap([&"a"]).get("accepted",true),"inactive rejected")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":4}).get("accepted",false),"stamina")
	var start := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(start.get("accepted",false),"strike start")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"STR","value":10}).get("accepted",false) and ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"PER","value":9}).get("accepted",false),"late stats")
	var rng = root.get_node("RngService")._rng
	var rng_before: int = rng.state
	var result := snap([&"z",&"far",&"a"])
	check(result.get("accepted",false),"capture")
	if not result.get("accepted",false): print(result); quit(1); return
	var d: Dictionary = result["data"]
	check(d["targets"].size() == 2 and d["targets"][0]["target"] == &"a" and d["targets"][1]["target"] == &"z", "sorted hits and miss")
	var preview := ask(&"WeaponStrikeDamagePreviewRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust"})
	var prot := ask(&"PeriodicProtectionGetRequested", {"entity":&"a","damage_type":"physical"})
	check(d["physical"] == preview["data"]["nonnegative_damage"] and d["per"] == 9 and d["weakening_multiplier"] == 0.5 and d["direction"] == Vector2.RIGHT and d["targets"][0]["physical_protection_percent"] == prot["percent"],"current damage PER and protection, fixed weakening")
	check(rng.state == rng_before,"snapshot no RNG")
	check(not snap([&"a",&"a"]).get("accepted",true) and not snap([&"hero"]).get("accepted",true) and not snap([&"missing"]).get("accepted",true),"invalid candidate rejected")
	var bus = root.get_node("EventBus")
	var movement := func(e):
		if e.get("entity",null) == &"a": e["found"] = true; e["position"] = Vector2(4,12)
	bus.subscribe(&"MovementPositionGetRequested",movement)
	var shifted := snap([&"a",&"z"])
	bus.unsubscribe(&"MovementPositionGetRequested",movement)
	check(shifted.get("accepted",false) and shifted["data"]["targets"].size() == 1 and shifted["data"]["targets"][0]["target"] == &"z","uses current continuous position")
	var fail_protection := func(e):
		if e.get("entity",null) == &"a": e["percent"] = null
	bus.subscribe(&"PeriodicProtectionGetRequested",fail_protection)
	check(not snap([&"a"]).get("accepted",true),"protection failure closed")
	bus.unsubscribe(&"PeriodicProtectionGetRequested",fail_protection)
	var planned := ask(&"PreparedDirectHitPlanRequested",d.duplicate(true))
	check(planned.get("accepted",false) and planned["data"]["hits"].size() == 2,"snapshot connects to planner")
	var before = ask(&"ResourceGetRequested", {"entity":&"a","resource":&"HP"})["data"]["current"]
	check(before == d["targets"][0]["hp_before"],"no damage")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and snap([&"a"]).get("accepted",false),"restore active strike")
	var middle := ceili(float(start["data"]["duration_steps"])/2.0)
	var phase_result := {"ok":false,"submitted":false,"batch":false,"expected":0}
	var on_mid := func(_e):
		var shot := snap([&"a"])
		phase_result["ok"] = shot.get("accepted",false)
		if phase_result["ok"]:
			var q := ask(&"PreparedDirectHitPlanRequested",shot["data"].duplicate(true))
			if q.get("accepted",false):
				var h: Dictionary = q["data"]["hits"][0]
				phase_result["expected"] = maxi(0,h["hp_before"] - h["damage"] - h["magical_damage"])
				phase_result["submitted"] = true # проверяем чистый план, а не ручную подачу
	var on_batch := func(e):
		phase_result["batch"] = e.get("accepted",false)
		if e.get("accepted",false):
			for row in e["data"]["targets"]:
				if row["target"] == &"a": phase_result["expected"] = row["hp_after"]
	bus.subscribe(&"WeaponStrikeMidpoint",on_mid); bus.subscribe(&"CombatPhaseBatchResolved",on_batch)
	check(driver.advance_steps(middle) == middle and phase_result["ok"] and phase_result["submitted"] and phase_result["batch"] and ask(&"ResourceGetRequested", {"entity":&"a","resource":&"HP"})["data"]["current"] == phase_result["expected"],"midpoint snapshot and automatic damage")
	bus.unsubscribe(&"WeaponStrikeMidpoint",on_mid); bus.unsubscribe(&"CombatPhaseBatchResolved",on_batch)
	print("Weapon strike hit snapshot tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
