extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func key(game: Node, code: Key) -> void:
	var e := InputEventKey.new(); e.pressed=true; e.keycode=code
	game._unhandled_key_input(e)
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver"); driver.set_process(false)
	var path := "user://demo_session.save"
	var exists := FileAccess.file_exists(path)
	var old := PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ); old=f.get_buffer(f.get_length()); f.close()
	var game=load("res://game_demo.tscn").instantiate(); root.add_child(game)
	await process_frame
	check(game.initialized,"setup")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet tutorial")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":100.0}).get("accepted",false),"test capacity")
	for i in range(14):
		var id:=StringName("page_potion_%d" % i)
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false),"create potion")
		check(ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"add potion")
	check(game._toggle_inventory() and driver.advance_steps(1)==1 and game.inventory_open,"open inventory")
	var items: Array=ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]
	check(items.size()==20 and game._inventory_page_count(items)==3,"three pages")
	key(game, KEY_LEFT); check(game.inventory_page==0,"previous clamps at first")
	key(game, KEY_RIGHT); check(game.inventory_page==1,"next page")
	key(game, KEY_RIGHT); check(game.inventory_page==2,"third page")
	key(game, KEY_RIGHT); check(game.inventory_page==2,"next clamps at last")
	var last: StringName=items[19]
	key(game, KEY_2)
	check(not ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].has(last),"third page selects last item")
	check(driver.advance_steps(50)==50,"finish third-page use")
	key(game, KEY_LEFT); check(game.inventory_page==1,"return second page")
	var selected: StringName=items[9]
	check(ask(&"ResourceSetRequested",{"entity":game.HERO,"resource":&"HP","value":1}).get("accepted",false),"lower HP")
	key(game, KEY_1)
	check(not ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].has(selected),"page two key consumes displayed item")
	check(driver.advance_steps(50)==50 and ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"})["data"]["current"]>1,"selected potion applies")
	key(game, KEY_PAGEDOWN); check(game.inventory_page==1,"empty last page clamped")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save page two")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load")
	check(game.inventory_open and game.inventory_page==0,"load restores inventory and resets navigation")
	key(game, KEY_PAGEDOWN); check(game.inventory_page==1,"page after load")
	key(game, KEY_PAGEUP); check(game.inventory_page==0,"pageup")
	check(ask(&"ItemCreateRequested",{"id":&"late_shield","base_id":&"shield_small","item_level":1}).get("accepted",false),"create late equipment")
	check(ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"late_shield"}).get("accepted",false),"add late equipment")
	key(game, KEY_RIGHT); key(game, KEY_RIGHT)
	check(game.inventory_page==2,"equipment on third page")
	key(game, KEY_1)
	check(driver.advance_steps(10)==10,"finish late equipment action")
	check(ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"})["data"].get("off",null)==&"late_shield","third-page equipment worn")
	check(not game._use_inventory_item(9),"out of range key rejected")
	game.queue_free(); await process_frame
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE); f.store_buffer(old); f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo inventory pages: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
