extends SceneTree
var failures := 0
var discovered: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func room_info(bus, id: StringName) -> Dictionary:
	return ask(bus, &"RoomGetRequested", {"id": id})
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"RoomDiscovered", func(event): discovered.append(event["room"]))
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(256, 256)})["accepted"], "map")
	ask(bus, &"RngSeedRequested", {"seed": 42})
	check(ask(bus, &"RoomGenerationConfigureRequested", {"deadend_budget": 1})["accepted"], "budget")
	check(not ask(bus, &"RoomCreateRequested", {"id": &"bad", "type": "corridor", "origin_cell": Vector2i(0, 0), "size_cells": Vector2i(6, 8)})["accepted"], "corridor short side exactly five")
	check(ask(bus, &"RoomCreateRequested", {"id": &"start", "type": "start", "origin_cell": Vector2i(20, 20), "size_cells": Vector2i(11, 11)})["accepted"], "start room")
	check(not ask(bus, &"RoomCreateRequested", {"id": &"overlap", "type": "start", "origin_cell": Vector2i(20, 20), "size_cells": Vector2i(11, 11)})["accepted"], "overlap rejected")
	check(ask(bus, &"SpaceTileGetRequested", {"tile": Vector2i(80, 81)})["kind"] == 0, "room perimeter rock")
	check(ask(bus, &"SpaceTileGetRequested", {"tile": Vector2i(81, 81)})["kind"] == 1, "room interior floor")
	check(ask(bus, &"RoomExitAddRequested", {"room": &"start", "id": &"west", "dir": "west", "offset_cells": 5})["accepted"], "west exit")
	check(ask(bus, &"RoomExitAddRequested", {"room": &"start", "id": &"east", "dir": "east", "offset_cells": 5})["accepted"], "east exit")
	var barrier: Array = []
	for y in range(81, 123):
		barrier.append(Vector2i(100, y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": barrier, "kind": 0})["accepted"], "block room")
	var repair := ask(bus, &"RoomConnectivityRepairRequested", {"room": &"start"})
	check(repair["accepted"] and repair["floor_list"].has(Vector2i(100, 100)), "deterministic L corridor repairs BFS connectivity")
	check(ask(bus, &"SpaceTileGetRequested", {"tile": Vector2i(100, 100)})["kind"] == 1, "corridor carved")
	var high_roll := func(req): req["value"] = 0.999999
	bus.subscribe(&"RngFloatRequested", high_roll)
	check(ask(bus, &"RoomChildTypeRollRequested", {"parent_type": "fork", "deadend_budget": 1})["type"] == "deadend", "deadend allowed after fork with budget")
	check(ask(bus, &"RoomChildTypeRollRequested", {"parent_type": "corridor", "deadend_budget": 0})["type"] != "corridor", "no corridor after corridor")
	check(ask(bus, &"RoomChildTypeRollRequested", {"parent_type": "passage", "deadend_budget": 1})["type"] != "deadend", "deadend restricted by parent")
	bus.unsubscribe(&"RngFloatRequested", high_roll)
	check(entities.create_entity(&"hero"), "hero")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "controlled")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(118, 100), "size": 4})["accepted"], "body near passage")
	check(ask(bus, &"RoomEnterRequested", {"entity": &"hero", "room": &"start"})["accepted"], "enter room")
	check(discovered == [&"start"], "discover start only")
	check(ask(bus, &"RoomGetRequested", {"id": &"room_1"})["found"] == false, "child not generated before first passage")
	var saved := ask(bus, &"SessionSaveRequested", {})
	check(saved.get("accepted", false), "save before generation: " + str(saved))
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(120, 100)})["accepted"], "enter threshold")
	var start: Dictionary = room_info(bus, &"start")["data"]
	var east: Dictionary = start["exits"][1]
	check(east["connected"] and east["childId"] != null, "lazy generation connects child")
	var child: StringName = east["childId"]
	var child_before: Dictionary = room_info(bus, child)["data"]
	check(child_before["discovered"] and discovered.has(child), "passage reveals room")
	check(child_before["exits"][0]["connected"] and child_before["exits"][0]["childId"] == &"start" and child_before["exits"][0]["tiles"].size() == 4, "child exit connected symmetrically")
	check(not child_before["floor_list"].is_empty(), "reachable floor list populated")
	check(root.get_node("WorldTickHook")._room_id == &"start", "current room unchanged while crossing")
	for x in range(121, 125):
		check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(x, 100)})["accepted"], "cross passage step")
	check(root.get_node("WorldTickHook")._room_id == child, "current room changes when body inside")
	check(root.get_node("RoomService")._pending.is_empty(), "arrival does not reenter back")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "reload before child")
	check(not room_info(bus, child)["found"], "child absent after restore")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(120, 100)})["accepted"], "replay threshold")
	var after_start: Dictionary = room_info(bus, &"start")["data"]
	var child_after: Dictionary = room_info(bus, after_start["exits"][1]["childId"])["data"]
	check(child_after["type"] == child_before["type"] and child_after["size_cells"] == child_before["size_cells"] and child_after["origin_cell"] == child_before["origin_cell"], "restored seed and state reproduce generation")
	print("Room tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
