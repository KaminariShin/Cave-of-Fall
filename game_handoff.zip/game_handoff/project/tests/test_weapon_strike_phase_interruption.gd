extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5)],[&"npc",Vector2i(10,5)]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false),"body")
		check(ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"inventory")
		var item := StringName(str(row[0])+"_sword")
		check(ask(&"ItemCreateRequested", {"id":item,"base_id":&"sword_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":item}).get("accepted",false),"item")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"npc_sword","slot":"main"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"hero_sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	for actor in [&"hero",&"npc"]: check(ask(&"ResourceSetRequested", {"entity":actor,"resource":&"Stamina","value":7}).get("accepted",false),"stamina")
	var npc := ask(&"WeaponStrikeStartRequested", {"entity":&"npc","item":&"npc_sword","strike":"sword_simple_thrust","direction":Vector2.LEFT})
	var hero := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"hero_sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(npc.get("accepted",false) and hero.get("accepted",false) and npc["data"]["duration_steps"] == hero["data"]["duration_steps"],"two synchronous strikes")
	if not npc.get("accepted",false) or not hero.get("accepted",false): quit(1); return
	var midpoint := ceili(float(hero["data"]["duration_steps"])/2.0)
	var bus = root.get_node("EventBus")
	var state := {"hero_deferred":false,"npc_immediate":false,"batch":false,"resolved":false}
	var pause_npc := func(e):
		if e.get("entity",null) == &"npc" and driver._action_elapsed_steps == midpoint: e["allowed"] = false
	var phase := func(e):
		if e.get("actions",[]).size() == 1 and e["actions"][0]["entity"] == &"hero":
			var q := ask(&"ActionCancelRequested", {"entity":&"hero","reason":&"test"})
			state["hero_deferred"] = q.get("accepted",false) and q.get("deferred",false)
			var n := ask(&"ActionCancelRequested", {"entity":&"npc","reason":&"test"})
			state["npc_immediate"] = n.get("accepted",false) and not n.get("deferred",false)
			ask(&"WeaponStrikePhaseAutoSubmitRequested",{})
	var batch := func(e): state["batch"] = e.get("accepted",false) and e.get("hit_count",0) == 1
	var resolved := func(e): state["resolved"] = e.get("entity",null) == &"hero" and e.get("applied",false) and state["batch"]
	bus.subscribe(&"AIEntityTickAllowedRequested",pause_npc); bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"WeaponStrikeDeferredInterruptionResolved",resolved)
	check(driver.advance_steps(midpoint) == midpoint and state["hero_deferred"] and state["npc_immediate"] and state["batch"] and state["resolved"],"phase cancellation deferred but non-ticking NPC cancels immediately")
	bus.unsubscribe(&"AIEntityTickAllowedRequested",pause_npc); bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"WeaponStrikeDeferredInterruptionResolved",resolved)
	print("Weapon strike phase interruption tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
