extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(begin(4), "fourth floor")
	for i in range(1,17): check(add_room(i, "passage"), "chain")
	check(tracking().get("boss_candidate", null) == &"node_16", "boss candidate")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	var parent: Dictionary = ask(&"RoomGetRequested", {"id":&"node_15"})["data"]
	var ex: Dictionary = parent["exits"].filter(func(x): return x["childId"] == &"node_16")[0]
	var anchor := Vector2i(int(ex["x"]) - 4, int(ex["y"]))
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":anchor, "size":4}).get("accepted", false), "body at doorway")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"node_15"}).get("accepted", false), "enter before boss room")
	check(not ask(&"DungeonBossGetRequested", {}).get("found", true), "no boss before entry")
	var bus = root.get_node("EventBus")
	var state := {"moved":false, "boss":&"", "early_damage":true, "installed":0}
	var move_on_tick := func(_e):
		if state["moved"]: return
		state["moved"] = ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":Vector2i(anchor.x + 5,anchor.y)}).get("accepted", false)
		var boss := ask(&"DungeonBossGetRequested", {})
		if boss.get("found", false):
			state["boss"] = boss["data"]["entity"]
			state["early_damage"] = ask(&"CombatDamageRequested", {"entity":state["boss"], "amount":1}).get("accepted", false)
	var installed := func(_e): state["installed"] += 1
	for x in range(anchor.x + 1, anchor.x + 5): check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":Vector2i(x,anchor.y)}).get("accepted", false), "approach doorway")
	bus.subscribe(&"Tick", move_on_tick)
	bus.subscribe(&"DungeonBossEquipmentInstalled", installed)
	check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.02}).get("accepted", false), "start time")
	check(driver.advance_steps(1) == 1, "advance one step")
	bus.unsubscribe(&"Tick", move_on_tick)
	check(state["moved"] and state["boss"] != &"" and not state["early_damage"], "unready boss protected within entry step")
	check(state["installed"] == 1 and ask(&"DungeonBossEquipmentAutoStatusRequested", {})["status"] == "installed", "equipment installed at settled before next step")
	var boss: StringName = state["boss"]
	var gear := ask(&"ComponentGetRequested", {"entity":boss, "component":&"equipment"})
	check(gear.get("found", false) and gear["data"].has("main") and gear["data"].has("body"), "real loadout committed")
	check(ask(&"CombatDamageRequested", {"entity":boss, "amount":1, "damage_type":"magical"}).get("accepted", false), "damage works once equipped")
	bus.unsubscribe(&"DungeonBossEquipmentInstalled", installed)
	print("Boss equipment settled success tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
