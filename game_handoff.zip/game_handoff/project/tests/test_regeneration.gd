extends SceneTree
var failures := 0
var cycles: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(bus, id: StringName, d: Dictionary) -> Dictionary:
	bus.publish(id,d)
	return d
func res(bus, id: StringName) -> Dictionary:
	return ask(bus, &"ResourceGetRequested", {"entity":&"hero", "resource":id})["data"]
func setres(bus, id: StringName, value: float) -> void:
	ask(bus, &"ResourceSetRequested", {"entity":&"hero", "resource":id, "value":value})
func advance(driver, duration: float) -> void:
	check(driver.wait_for(duration), "wait starts")
	driver.advance_steps(int(round(duration*100)))
func run() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"RegenCycleDue", func(e): cycles.append(e["resource"]))
	check(root.get_node("EntityRegistry").create_entity(&"hero", {&"stats":{"CON":10}}), "hero")
	setres(bus, &"HP", 60)
	advance(driver, 0.49)
	setres(bus, &"Stamina", 0)
	advance(driver, 0.01)
	var hp := res(bus, &"HP")
	check(is_equal_approx(hp["reserve"],1.0) and is_equal_approx(hp["reserve_filled"],0.0) and is_equal_approx(res(bus, &"Stamina")["current"],0), "reserve transfers existing stamina")
	check(not ask(bus, &"ResourceSpendRequested", {"entity":&"hero", "resource":&"Stamina", "amount":0.1})["accepted"], "reserve not spendable")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted",false), "save pending reserve")
	advance(driver, 0.49)
	hp = res(bus, &"HP")
	check(hp["reserve"] == 0 and is_equal_approx(hp["remainder"],0.5) and is_equal_approx(res(bus, &"Stamina")["current"],1.0), "regen fills reserve and applies hp immediately")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted",false), "load pending reserve")
	check(is_equal_approx(res(bus, &"HP")["reserve_filled"],0.0), "reserve persists")
	setres(bus, &"HP", 70)
	check(res(bus, &"HP")["reserve"] == 0 and is_equal_approx(res(bus, &"Stamina")["current"],0.0), "heal to full refunds reserve")
	setres(bus, &"HP", 60)
	setres(bus, &"Stamina", 10)
	setres(bus, &"MP", 10)
	advance(driver, 1.0)
	check(res(bus, &"HP")["current"] >= 61.0, "HP accumulation")
	check(res(bus, &"MP")["current"] >= 12.0, "MP regeneration")
	var service = root.get_node("ResourceService")
	for entry in [[4.0,0.0], [5.0,0.04], [6.0,0.08], [7.0,0.12], [8.0,0.16], [9.0,0.20], [10.0,1.0], [11.0,1.1]]:
		ask(bus, &"StatBaseSetRequested", {"entity":&"hero", "stat":&"CON", "value":entry[0]})
		check(is_equal_approx(service._rate(&"hero", &"HP"), entry[1]), "HP threshold " + str(entry[0]))
	print("Regeneration tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
