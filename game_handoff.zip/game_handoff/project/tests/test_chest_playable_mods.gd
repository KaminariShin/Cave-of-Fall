extends SceneTree
var failures:=0
var bus:Node
func _initialize() -> void: call_deferred("run")
func check(ok:bool, label:String)->void:
	if not ok: failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var saver=root.get_node("SaveService")
	var mods=root.get_node("DungeonChestModDraftService")
	var catalog=root.get_node("DungeonChestModCatalogService")
	var learning=root.get_node("DungeonChestLearningService")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":10000}).get("accepted",false),"capacity")
	var bases:Dictionary=saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var cases:=[{"id":&"sword_simple","slot":"main"},{"id":&"hammer_simple","slot":"main"},{"id":&"bow_simple","slot":"main"},{"id":&"shield_small","slot":"off"},{"id":&"shield_medium","slot":"off"},{"id":&"shield_large","slot":"off"},{"id":&"armor_cloth_body","slot":"body"},{"id":&"armor_leather_body","slot":"body"},{"id":&"armor_iron_body","slot":"body"}]
	var choice:={"high":false}
	var override:=func(e):e["value"]=e["max"] if choice["high"] else e["min"]
	var count:=0
	for c in cases:
		for level in [1,5]:
			for rarity in [&"magic",&"rare"]:
				choice["high"]=(count%2==1)
				var work:={"mods":[],"materials":[],"error":""}
				bus.subscribe(&"RngIntRequested",override)
				var ok:bool=mods._execute(c["id"],level,rarity,work,true)
				bus.unsubscribe(&"RngIntRequested",override)
				check(ok,"draft %s %d %s %s" % [c["id"],level,rarity,work["error"]])
				if not ok:continue
				for i in range(work["mods"].size()):
					var mod:Dictionary=work["mods"][i]
					mod["unlock_after"]=learning.gate_for(i)
					check(str(mod["id"]) in catalog.LIVE_EFFECT_IDS,"only supported generated IDs")
				var item_sections:Dictionary=saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]
				var entry:={"base_id":c["id"],"item_level":level,"rarity":rarity,"mods":work["mods"],"materials":work["materials"]}
				check(mods.validate_fixed_mods(entry,item_sections),"snapshot validates filtered exhausted pools")
				var id:=StringName("case_%d" % count)
				var schema:Dictionary=learning.schema_for(c["id"],bases)
				check(ask(&"ItemCreateRequested",{"id":id,"base_id":c["id"],"item_level":level,"rarity":rarity,"materials":work["materials"],"learning":schema}).get("accepted",false),"create")
				for mod in work["mods"]:check(ask(&"ItemModAttachRequested",{"item":id,"mod":mod}).get("accepted",false),"attach supported mod")
				var data:Dictionary=ask(&"ItemGetRequested",{"item":id})["item_data"]
				check(catalog.unsupported_live_effects(data).is_empty(),"no blocked effect")
				check(ask(&"InventoryAddRequested",{"entity":&"hero","item":id}).get("accepted",false),"add to inventory")
				var equip:=ask(&"EquipmentEquipRequested",{"entity":&"hero","item":id,"slot":c["slot"]})
				check(equip.get("accepted",false),"start equip " + str(equip))
				if equip.get("accepted",false):
					check(driver.advance_steps(10)==10,"complete equip")
					var gear:=ask(&"ComponentGetRequested",{"entity":&"hero","component":&"equipment"})
					check(gear["data"].get(c["slot"],null)==id,"equipped")
					check(ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":c["slot"]}).get("accepted",false) and driver.advance_steps(10)==10,"unequip")
				count+=1
	check(count==36,"all equipment scenarios")
	print("Chest playable mod pool: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
