extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run_tests")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name,data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var level := ask(bus,&"LevelGenerationRequested",{"level_id":&"object_cave","seed":55,"size_cells":Vector2i(96,96)})
	var start_room: Dictionary = ask(bus,&"RoomGetRequested",{"id":&"start"})["data"]
	var chest_tile: Vector2i = (start_room["origin_cell"] + Vector2i(5,5)) * 4
	check(ask(bus,&"ObjectCreateRequested",{"entity":&"cave_chest", "type":&"chest", "room":&"start", "tile":chest_tile, "inventory_capacity":5.0}).get("accepted", false), "create chest after level setup")
	check(level["accepted"],"generate cave")
	check(ask(bus,&"RoomObjectsGetRequested",{"room":&"start"})["objects"].has(&"cave_chest"),"object generated from cave room point")
	var record: Dictionary = ask(bus,&"ObjectGetRequested",{"object":&"cave_chest"})["data"]
	check(ask(bus,&"SpaceTileGetRequested",{"tile":record["tile"]})["kind"] == 1,"cave object on reachable floor")
	var before := {"sections":{}, "errors":[]}
	bus.publish(&"SnapshotCollectRequested", before)
	check(not ask(bus,&"RoomExitAddRequested",{"room":&"start", "id":&"north_after_chest", "dir":"north", "offset_cells":5}).get("accepted", true), "cave room with chest conservatively rejects new exit")
	var after := {"sections":{}, "errors":[]}
	bus.publish(&"SnapshotCollectRequested", after)
	check(before["errors"].is_empty() and after["errors"].is_empty() and before["sections"] == after["sections"], "cave exit rejection changes no state")
	check(ask(bus,&"SessionSaveRequested",{}).get("accepted",false),"save cave with object")
	check(ask(bus,&"SessionLoadRequested",{}).get("accepted",false),"load cave with object")
	check(ask(bus,&"ObjectGetRequested",{"object":&"cave_chest"})["found"],"cave object survives load")
	print("Cave objects tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
