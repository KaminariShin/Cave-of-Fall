extends SceneTree
var failures := 0
var deaths: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, text: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func exists(id: StringName) -> bool: return ask(&"EntityGetRequested", {"entity":id}).get("found", false)
func item(id: StringName) -> bool: return ask(&"ItemGetRequested", {"item":id}).get("found", false)
func inv(id: StringName) -> Array: return ask(&"InventoryGetRequested", {"entity":id})["data"]["items"]
func mob_def() -> Dictionary:
	return {"id":"cleanup_test", "type_weight":0.1, "species":{"id":"test", "species_weight":0.2}, "tags":[{"id":"boss", "tag_weight":0.1}], "base_stats":{"CON":10,"STR":10,"DEX":10,"INT":10,"WIS":10,"PER":10}, "growth_per_level":{"CON":2,"STR":2,"DEX":2,"INT":2,"WIS":2,"PER":2}, "body_size":2,"min_depth":0,"max_depth":null}
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	root.get_node("EventBus").subscribe(&"EntityDied", func(e): deaths.append(e.duplicate(true)))
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(100,100)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"r", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	for id in [&"hero", &"unclassified"]:
		check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted", false), "entity")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":20}).get("accepted", false), "hero inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(28,28), "size":4}).get("accepted", false), "hero body")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"unclassified", "anchor":Vector2i(10,10), "size":2}).get("accepted", false), "unclassified body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"r"}).get("accepted", false), "enter")
	ask(&"RngSeedRequested", {"seed":42})
	var spawn := ask(&"RoomSpawnRequested", {"room":&"r", "player":&"hero", "entry_tile":Vector2i(28,28), "depth":6, "pool":[mob_def()], "queue_delay":0.05})
	check(spawn.get("accepted", false) and spawn.get("units", []).size() >= 2 and spawn.get("queue_count", -1) == 0, "real registered spawns without queue")
	if not spawn.get("accepted", false) or spawn.get("units", []).size() < 2 or spawn.get("queue_count", -1) != 0:
		quit(1)
		return
	var actors: Array = []
	for unit in spawn["units"]: actors.append(unit["entity"])
	actors.sort_custom(func(a,b): return str(a) < str(b))
	var first: StringName = actors[0]
	var second: StringName = actors[1]
	check(ask(&"InventoryConfigureRequested", {"entity":first, "volume":20}).get("accepted", false), "mob inventory")
	for spec in [[&"mob_potion", &"potion_hp"], [&"mob_sword", &"sword_simple"], [&"hero_potion", &"potion_hp"]]:
		check(ask(&"ItemCreateRequested", {"id":spec[0], "base_id":spec[1], "item_level":1}).get("accepted", false), "item")
	check(ask(&"InventoryAddRequested", {"entity":first, "item":&"mob_potion"}).get("accepted", false), "mob item")
	check(ask(&"ComponentSetRequested", {"entity":first, "component":&"equipment", "data":{"main":&"mob_sword"}}).get("accepted", false), "mob equipment")
	check(ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"hero_potion"}).get("accepted", false), "hero item")
	var cleanup = root.get_node("FloorSpawnCleanup")
	var save = root.get_node("SaveService")
	check(not cleanup.discard_spawned_actors_for_transition().get("accepted", false), "not usable outside transaction")
	check(ask(&"ProcessStartRequested", {"id":&"independent_mob", "duration":2.0, "entity":first, "independent":true}).get("accepted", false), "independent mob process")
	var blocked := {}
	var result: Dictionary = save.run_world_transition_transaction(func(): blocked["result"] = cleanup.discard_spawned_actors_for_transition(); return true)
	check(not blocked["result"].get("accepted", true) and result.get("rolled_back", false) and exists(first), "independent process forces rollback")
	check(ask(&"ProcessInterruptRequested", {"id":&"independent_mob"}).get("accepted", false), "interrupt independent process")
	check(ask(&"ProcessStartRequested", {"id":&"dependent_mob", "duration":2.0, "entity":first, "independent":false}).get("accepted", false), "dependent mob process")
	var reentry := {"attempted":false}
	var veto := func(e):
		if e.get("entity", null) == second: e["allowed"] = false
		if e.get("entity", null) == first and not reentry["attempted"]:
			reentry["attempted"] = true
			reentry["self"] = ask(&"EntityRemoveRequested", {"entity":first}).get("accepted", false)
			reentry["remove"] = ask(&"EntityRemoveRequested", {"entity":second}).get("accepted", false)
			reentry["process"] = ask(&"ProcessStartRequested", {"id":&"new_mob_process", "entity":second, "duration":1.0, "independent":true}).get("accepted", false)
			reentry["damage"] = ask(&"CombatDamageRequested", {"entity":second, "amount":9999}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"LootEntityRemovalCheckRequested", veto)
	var failed := {}
	result = save.run_world_transition_transaction(func(): failed["result"] = cleanup.discard_spawned_actors_for_transition(); return true)
	root.get_node("EventBus").unsubscribe(&"LootEntityRemovalCheckRequested", veto)
	check(not failed["result"].get("accepted", true) and result.get("rolled_back", false), "partial failure forces rollback")
	check(reentry["attempted"] and not reentry["self"] and not reentry["remove"] and not reentry["process"] and not reentry["damage"], "reentrant removal, process and damage blocked")
	check(exists(first) and exists(second) and item(&"mob_sword") and inv(first).has(&"mob_potion") and ask(&"ComponentGetRequested", {"entity":first, "component":&"equipment"})["data"]["main"] == &"mob_sword", "actors and belongings restored")
	check(ask(&"ProcessGetRequested", {"id":&"dependent_mob"}).get("found", false), "dependent process restored")
	var resurrect := {"attempted":false}
	var recreate := func(e):
		if e.get("entity", null) == second and not resurrect["attempted"]:
			resurrect["attempted"] = true
			resurrect["created"] = ask(&"EntityCreateRequested", {"entity":first}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"EntityRemoved", recreate)
	var altered := {}
	result = save.run_world_transition_transaction(func(): altered["result"] = cleanup.discard_spawned_actors_for_transition(); return true)
	root.get_node("EventBus").unsubscribe(&"EntityRemoved", recreate)
	check(resurrect["attempted"] and resurrect["created"] and not altered["result"].get("accepted", true) and result.get("rolled_back", false), "recreated target detected and whole operation rolled back")
	check(exists(first) and exists(second) and item(&"mob_sword") and inv(first).has(&"mob_potion"), "rollback restores original actor after recreation")
	var cleaned := {}
	result = save.run_world_transition_transaction(func(): cleaned["result"] = cleanup.discard_spawned_actors_for_transition(); return cleaned["result"].get("accepted", false))
	check(result.get("committed", false) and cleaned["result"].get("entities", []) == actors and cleaned["result"].get("items", []) == [&"mob_potion", &"mob_sword"], "registered actors removed")
	for actor in actors:
		check(not exists(actor) and not ask(&"SpaceBodyGetRequested", {"entity":actor}).get("found", false), "entity and body removed")
	check(not item(&"mob_sword") and not item(&"mob_potion") and not ask(&"ProcessGetRequested", {"id":&"dependent_mob"}).get("found", false), "mob items retired and dependent process cancelled")
	check(exists(&"hero") and exists(&"unclassified") and item(&"hero_potion") and inv(&"hero").has(&"hero_potion") and deaths.is_empty(), "player and unclassified creature preserved; no fake deaths")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and exists(&"unclassified") and item(&"hero_potion"), "cleanup persists")
	print("Floor spawn cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
