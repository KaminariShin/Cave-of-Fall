extends SceneTree
var failed := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failed+=1; printerr("FAIL: ",label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	bus.publish(id,data); return data
func key(g: Node, k: Key) -> void:
	var e:=InputEventKey.new(); e.keycode=k; e.pressed=true; g._unhandled_key_input(e)
func click(g: Control, p: Vector2) -> void:
	var e:=InputEventMouseButton.new(); e.position=g.get_global_transform_with_canvas()*p; e.button_index=MOUSE_BUTTON_LEFT; e.pressed=true; g._input(e)
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var g=load("res://game_demo.tscn").instantiate();root.add_child(g);await process_frame
	g.size=Vector2(1280,720)
	check(g.initialized,"initialized")
	check(ask(&"AIUnregisterRequested",{"entity":g.RAT}).get("accepted",false),"quiet")
	check(g._journal_book != null and g._journal_turn_left.size()==3 and g._journal_turn_right.size()==3,"book and animation frames")
	g.journal_entries.clear();g._journal_dirty=true
	for i in range(55): g.message="Событие %d: герой нашёл предмет и продолжил путь." % i
	check(g.journal_entries.size()==55 and g.journal_entries[0].contains("0:") and g.journal_entries[-1].contains("54:"),"history and order")
	check(g._journal_spreads()>1,"multiple spreads")
	var t:float=driver.game_time
	click(g,g._journal_button_rect().get_center())
	check(g.journal_open and g.journal_page==g._journal_spreads()-1 and driver.game_time==t,"mouse opens newest no time")
	var last:int=g.journal_page
	key(g,KEY_LEFT)
	check(g.journal_page==last-1 and g._journal_turn_time>0 and g._journal_turn_direction==-1,"previous page animated")
	click(g,g._journal_next_rect().get_center())
	check(g.journal_page==last and g._journal_turn_direction==1,"mouse next page")
	key(g,KEY_W)
	check(driver.game_time==t and g._held_keys.is_empty(),"modal does not move")
	key(g,KEY_ESCAPE)
	check(not g.journal_open and driver.game_time==t,"close no time")
	var q:=ask(&"SessionSaveRequested",{"slot":"demo"})
	check(q.get("accepted",false),"save journal")
	g.message="POST SAVE SHOULD VANISH"
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load")
	check(g.journal_entries.has("Событие 54: герой нашёл предмет и продолжил путь.") and not g.journal_entries.has("POST SAVE SHOULD VANISH"),"history restored")
	var payload:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()["payload"]
	var legacy:Dictionary=payload.duplicate(true); legacy["sections"]["game_demo"].erase("journal")
	check(root.get_node("SaveService")._validate_snapshot(legacy),"legacy snapshot without journal valid")
	var bad:Dictionary=payload.duplicate(true);bad["sections"]["game_demo"]["journal"]=[55]
	check(not root.get_node("SaveService")._validate_snapshot(bad),"invalid history rejected")
	g.journal_entries.clear();for i in range(310):g.message="Тест %d"%i
	check(g.journal_entries.size()==300 and g.journal_entries[0]=="Тест 10","history limit")
	check(g._journal_wrap("abcdefghijklmnopqrstuvwxyz",25,14).size()>1,"long words wrap")
	g.queue_free();await process_frame
	print("Game demo journal: ","PASS" if failed==0 else "%d failed"%failed)
	quit(0 if failed==0 else 1)
