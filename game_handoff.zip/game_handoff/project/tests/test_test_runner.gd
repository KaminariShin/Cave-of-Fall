extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var runner = load("res://scripts/test_runner_service.gd").new()
	root.add_child(runner)
	var found: Array = runner.discover_tests()
	check(found.has("test_accumulator.gd") and found.has("test_test_runner.gd"), "discover test files")
	check(not runner.start_one("../../project.godot")["accepted"], "path traversal rejected")
	check(not runner.start_tests(["test_accumulator.gd", "test_accumulator.gd"])["accepted"], "duplicates rejected")
	check(runner.classify_result(0, "PASS")["status"] == "PASS", "pass classification")
	for bad_log in ["PASS\nSCRIPT ERROR: bad", "PASS\nERROR: bad", "PASS\nParse Error", "PASS\nFAIL: bad", "no completion"]:
		check(runner.classify_result(0, bad_log)["status"] == "FAIL", "log error detected")
	check(runner.classify_result(1, "PASS")["status"] == "FAIL", "exit error")
	check(runner.classify_result(0, "PASS", true)["status"] == "TIMEOUT", "timeout")
	check(runner.classify_result(0, "PASS", false, true)["status"] == "CANCELLED", "cancel")
	var one: Dictionary = runner.start_one("test_accumulator.gd")
	check(one["accepted"], "single starts")
	check(not runner.start_one("test_event_bus.gd")["accepted"], "no concurrent run")
	var summary: Dictionary = await runner.run_finished
	check(summary["total"] == 1 and summary["passed"] == 1 and summary["results"][0]["name"] == "test_accumulator.gd", "single completes")
	check(FileAccess.file_exists(summary["run_dir"].path_join("report.json")), "report exists")
	var config := ConfigFile.new()
	check(config.load(summary["run_dir"].path_join("project/project.godot")) == OK and config.get_value("application", "config/use_custom_user_dir", false), "isolated user dir")
	check(str(config.get_value("application", "config/custom_user_dir_name", "")).begins_with("TimeDriver_test_runner/"), "dedicated user path")
	var two: Dictionary = runner.start_tests(["test_event_bus.gd", "test_accumulator.gd"])
	check(two["accepted"], "sequence starts")
	summary = await runner.run_finished
	check(summary["total"] == 2 and summary["passed"] == 2 and summary["results"][0]["name"] == "test_event_bus.gd" and summary["results"][1]["name"] == "test_accumulator.gd", "sequence order")
	var probe: Dictionary = runner.start_one("test_runner_probe.gd")
	check(probe["accepted"], "isolation probe starts")
	summary = await runner.run_finished
	var probe_log: String = summary["results"][0]["log"]
	check(summary["passed"] == 1 and probe_log.contains("TimeDriver_test_runner") and not probe_log.contains("TEST_USER_DIR=" + OS.get_user_data_dir()), "child uses separate user directory")
	var cancel_run: Dictionary = runner.start_one("test_accumulator.gd")
	check(cancel_run["accepted"], "cancel test starts")
	runner.cancel()
	check(not runner.is_running(), "cancel before launch")
	var active_cancel: Dictionary = runner.start_one("test_ai_service.gd")
	check(active_cancel["accepted"], "active cancel starts")
	await runner.test_started
	runner.call_deferred("cancel")
	summary = await runner.run_finished
	check(summary["cancelled"] and summary["completed"] == 1 and summary["results"][0]["status"] == "CANCELLED", "active process cancelled")
	runner.queue_free()
	print("Test runner tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
