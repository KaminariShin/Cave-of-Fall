extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func add(id: String,value: float,target: String = "protection.physical") -> bool:
	return ask(&"PipelineModifierRegisterRequested", {"entity":&"hero","modifier":{"id":id,"target":target,"stage":"additive","op":"add","value":value}}).get("accepted",false)
func remove(id: String) -> bool: return ask(&"PipelineModifierRemoveRequested", {"entity":&"hero","id":id}).get("accepted",false)
func protection() -> Dictionary: return ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"physical","percent":0.0})
func hp() -> float: return float(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["current"])
func reset_hp() -> void: check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"HP","value":20}).get("accepted",false),"HP")
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"hero")
	check(protection().get("percent",null) == 0.0,"base zero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_small","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	check(is_equal_approx(protection().get("percent",0),4.77),"armour base")
	check(add("plus",20.001) and add("minus",-1.234) and add("magic",13,"protection.magical"),"sources")
	var sources := ask(&"PhysicalProtectionSourcesGetRequested", {"entity":&"hero"})
	check(sources.get("found",false) and sources["sources"].size() == 2 and is_equal_approx(sources["percent"],18.77),"sources rounded separately, magic excluded")
	check(is_equal_approx(protection().get("percent",0),23.54),"armour and sources summed")
	check(is_equal_approx(ask(&"MagicalProtectionGetRequested", {"entity":&"hero"}).get("percent",0),13.0),"magic remains separate")
	check(not ask(&"PipelineModifierRegisterRequested", {"entity":&"hero","modifier":{"id":"bad","target":"protection.physical","stage":"final","op":"multiply","value":2}}).get("accepted",true),"unsupported source rejected")
	reset_hp()
	check(ask(&"CombatDamageRequested", {"entity":&"hero","amount":10,"damage_type":"physical"}).get("accepted",false) and hp() == 12,"physical direct uses percentage sources")
	reset_hp()
	check(ask(&"PeriodicEffectApplyRequested", {"entity":&"hero","effect":&"dot","damage_type":"physical","damage_per_tick":2,"base_duration":1.0}).get("accepted",false) and driver.wait_for(1.0) and driver.advance_steps(50) == 50 and hp() == 19 and driver.advance_steps(50) == 50 and hp() == 17,"physical periodic uses live percent before accumulator")
	check(add("cap",100) and protection()["percent"] == 75.0,"combined cap")
	check(remove("cap") and remove("plus") and remove("minus") and add("weakness",-30),"negative")
	check(is_equal_approx(protection()["percent"],-25.23),"negative final defense")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and remove("weakness") and ask(&"SessionLoadRequested",{}).get("accepted",false) and is_equal_approx(protection()["percent"],-25.23),"save restore")
	var broken := func(e):
		if e.get("entity",null) == &"hero": e["found"] = false
	bus.subscribe(&"PhysicalProtectionSourcesGetRequested",broken)
	var before := hp()
	var q := protection()
	check(q.get("percent",42) == null and q.has("protection_error") and not ask(&"CombatDamageRequested", {"entity":&"hero","amount":2,"damage_type":"physical"}).get("accepted",true) and hp() == before,"source failure closed")
	var errors := {"n":0}
	var failure := func(_e): errors["n"] += 1
	bus.subscribe(&"PeriodicEffectFailed",failure)
	check(ask(&"PeriodicEffectApplyRequested", {"entity":&"hero","effect":&"broken_dot","damage_type":"physical","damage_per_tick":3,"base_duration":0.5}).get("accepted",false) and driver.wait_for(0.5) and driver.advance_steps(50) == 50 and hp() == before and errors["n"] == 1,"failed physical tick skipped")
	bus.unsubscribe(&"PeriodicEffectFailed",failure); bus.unsubscribe(&"PhysicalProtectionSourcesGetRequested",broken)
	check(is_equal_approx(protection()["percent"],-25.23),"source restored")
	print("Physical protection sources tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
