extends SceneTree
var failures := 0
var done: Array = []
var stopped: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", label)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	var entities = root.get_node("EntityRegistry")
	driver.set_process(false)
	bus.subscribe(&"MenuTransitionCompleted", func(e): done.append(e.duplicate(true)))
	bus.subscribe(&"MenuTransitionInterrupted", func(e): stopped.append(e.duplicate(true)))
	check(entities.create_entity(&"hero"), "hero")
	check(ask(bus, &"ControlledEntityRequested", {"entity":&"hero"})["accepted"], "controlled")
	for menu in ["hotbar", "health_bars", "minimap", "tooltips", "pause", "settings", "save"]:
		for op in ["open", "close"]:
			var time: float = driver.game_time
			check(ask(bus, &"MenuTransitionRequested", {"menu":menu, "operation":op})["accepted"], "UI transition")
			check(driver.game_time == time and driver.advance_steps(1) == 0, "UI does not advance")
	for menu in ["inventory", "chest", "trade", "craft", "workbench", "dialogue", "equipment", "stats"]:
		for op in ["open", "close"]:
			var time: float = driver.game_time
			var count := done.size()
			check(ask(bus, &"MenuTransitionRequested", {"entity":&"hero", "menu":menu, "operation":op})["accepted"], "start " + menu)
			check(done.size() == count and driver.advance_steps(1) == 1, "one pending step")
			check(is_equal_approx(driver.game_time - time, 0.01) and done.size() == count + 1, "one step and completed")
	check(not ask(bus, &"MenuTransitionRequested", {"entity":&"hero", "menu":"wrong", "operation":"open"})["accepted"], "unknown menu")
	check(ask(bus, &"MenuTransitionRequested", {"entity":&"hero", "menu":"inventory", "operation":"open"})["accepted"], "start cancel")
	check(ask(bus, &"ActionCancelRequested", {"entity":&"hero"})["accepted"] and stopped.size() == 1, "cancelled")
	check(ask(bus, &"MenuTransitionRequested", {"entity":&"hero", "menu":"trade", "operation":"open"})["accepted"], "start save")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save pending")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load pending")
	var count := done.size()
	check(driver.advance_steps(1) == 1 and done.size() == count + 1 and done.back()["menu"] == "trade", "resume pending")
	ask(bus, &"CombatDetectionChanged", {"entity":&"hero", "active":true})
	check(ask(bus, &"GameModeGetRequested", {})["mode"] == "combat", "combat")
	var time: float = driver.game_time
	check(ask(bus, &"MenuTransitionRequested", {"entity":&"hero", "menu":"inventory", "operation":"close"})["accepted"], "combat transition")
	check(driver.advance_steps(1) == 1 and is_equal_approx(driver.game_time - time, 0.01), "combat step")
	print("Menu tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
