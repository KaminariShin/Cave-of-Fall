extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(v: bool, s: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",s)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	var id:=&"drop_test_potion"
	check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"item")
	var body: Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]
	var tile: Vector2i=body["anchor"]+Vector2i(2,2)
	check(not ask(&"LootInventoryDropRequested",{"entity":game.HERO,"item":id,"tile":Vector2i(-1,-1)}).get("accepted",false),"invalid position rejected")
	check(not ask(&"LootInventoryDropRequested",{"entity":game.RAT,"item":id,"tile":tile}).get("accepted",false),"other actor rejected")
	check(not ask(&"ActionStartRequested",{"entity":game.HERO,"action":&"loot_inventory_drop","duration":0.1}).get("accepted",false),"cannot start unreserved drop")
	check(ask(&"LootInventoryDropRequested",{"entity":game.HERO,"item":id,"tile":tile}).get("accepted",false),"start")
	check(not ask(&"InventoryRemoveRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"reserved inventory item protected")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"interrupt")
	check(game._inventory_items().has(id) and not ask(&"LootGetRequested",{})["items"].has(id),"interruption leaves item in inventory")
	check(ask(&"LootInventoryDropRequested",{"entity":game.HERO,"item":id,"tile":tile}).get("accepted",false),"restart")
	check(driver.advance_steps(10)==10 and not game._inventory_items().has(id) and ask(&"LootGetRequested",{})["items"].has(id),"atomic completed transfer")
	check(not ask(&"LootInventoryDropRequested",{"entity":game.HERO,"item":id,"tile":tile}).get("accepted",false),"cannot drop same item twice")
	check(not ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"cannot duplicate ground item")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false) and ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"ground survives save")
	check(ask(&"LootGetRequested",{})["items"].has(id) and not game._inventory_items().has(id),"ground preserved without duplicate")
	var saver = root.get_node("SaveService")
	var legacy: Dictionary = saver._read("user://demo_session.save")
	legacy["sections"]["loot"].erase("drop_pending")
	legacy["sections"]["actions"]["definitions"].erase(&"loot_inventory_drop")
	var written := {}
	saver._write(written,"user://demo_session.save",legacy)
	check(written.get("accepted",false) and ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load old save without drop action")
	check(ask(&"ActionDefinitionGetRequested",{"action":&"loot_inventory_drop"}).get("found",false),"drop action re-registered after old save")
	game.queue_free();await process_frame
	print("Inventory drop security and interruption: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
