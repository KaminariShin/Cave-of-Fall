extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc",&"neutral",&"unplaced",&"dead"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5)],[&"npc",Vector2i(10,5)]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false),"body")
		check(ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"inventory")
		var item := StringName(str(row[0])+"_sword")
		check(ask(&"ItemCreateRequested", {"id":item,"base_id":&"sword_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":item}).get("accepted",false),"item")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"neutral","anchor":Vector2i(12,5),"size":2}).get("accepted",false),"neutral body")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"npc_sword","slot":"main"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"hero_sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"dead","anchor":Vector2i(16,5),"size":2}).get("accepted",false),"dead body")
	check(ask(&"CombatDamageRequested", {"entity":&"dead","source":&"hero","amount":100000}).get("accepted",false) and root.get_node("CombatService").is_entity_dead(&"dead"),"kill before phase")
	var before_idle: int = root.get_node("RngService")._rng.state
	var idle := {"accepted":false}
	var idle_phase := func(_e):
		var r := ask(&"WeaponStrikePhaseAutoPlanRequested", {})
		idle["accepted"] = r.get("accepted",false) and r["data"]["attacks"].is_empty() and r["data"]["hits"].is_empty()
	var bus_idle = root.get_node("EventBus")
	bus_idle.subscribe(&"TimeCombatPhase",idle_phase)
	check(driver.wait_for(0.01) and driver.advance_steps(1) == 1 and idle["accepted"] and root.get_node("RngService")._rng.state == before_idle,"empty phase no RNG")
	bus_idle.unsubscribe(&"TimeCombatPhase",idle_phase)
	for actor in [&"hero",&"npc"]: check(ask(&"ResourceSetRequested", {"entity":actor,"resource":&"Stamina","value":7}).get("accepted",false),"stamina")
	var npc := ask(&"WeaponStrikeStartRequested", {"entity":&"npc","item":&"npc_sword","strike":"sword_simple_thrust","direction":Vector2.LEFT})
	var hero := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"hero_sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(npc.get("accepted",false) and hero.get("accepted",false) and npc["data"]["duration_steps"] == hero["data"]["duration_steps"],"two synchronous strikes")
	if not npc.get("accepted",false) or not hero.get("accepted",false): quit(1); return
	var rng = root.get_node("RngService")._rng
	var initial: int = rng.state
	check(not ask(&"WeaponStrikePhaseAutoPlanRequested", {}).get("accepted",true) and rng.state == initial,"outside phase rejected")
	var midpoint := ceili(float(hero["data"]["duration_steps"])/2.0)
	check(driver.advance_steps(midpoint-1) == midpoint-1 and ask(&"SessionSaveRequested",{}).get("accepted",false),"save before midpoint")
	var bus = root.get_node("EventBus")
	var state := {"mode":0,"first":{},"second":{},"invalid":false,"empty":false,"duplicate":false,"batch":false,"submitted":0,"snapshots":0,"all_captured_before_roll":true}
	var on_snapshot := func(_e): state["snapshots"] += 1
	var on_plan := func(_e):
		if state["snapshots"] < 2: state["all_captured_before_roll"] = false
	var on_batch := func(e): state["batch"] = e.get("accepted",false) and e.get("hit_count",0) == 3
	var phase := func(_e):
		for id in [&"hero",&"npc",&"neutral"]: ask(&"ResourceSetRequested", {"entity":id,"resource":&"HP","value":1})
		if state["mode"] == 0:
			var before: int = rng.state
			var inject := func(x): x["bodies"][&"ghost"] = {}
			bus.subscribe(&"SpaceBodiesGetRequested",inject)
			state["invalid"] = not ask(&"WeaponStrikePhaseAutoPlanRequested", {}).get("accepted",true) and rng.state == before
			bus.unsubscribe(&"SpaceBodiesGetRequested",inject)
		state["snapshots"] = 0
		var q := ask(&"WeaponStrikePhaseAutoPlanRequested", {})
		if q.get("accepted",false):
			if state["mode"] == 0:
				state["first"] = q["data"].duplicate(true)
				for id in [&"hero",&"npc",&"neutral"]: ask(&"ResourceSetRequested", {"entity":id,"resource":&"HP","value":45})
			else:
				state["second"] = q["data"].duplicate(true)
	bus.subscribe(&"WeaponStrikeHitSnapshotRequested",on_snapshot); bus.subscribe(&"PreparedDirectHitPlanRequested",on_plan); bus.subscribe(&"CombatPhaseBatchResolved",on_batch); bus.subscribe(&"TimeCombatPhase",phase)
	check(driver.advance_steps(1) == 1 and state["invalid"] and state["first"].get("hits",[]).size() == 3 and state["first"].get("candidate_count",0) == 4 and state["all_captured_before_roll"] and state["batch"] and not root.get_node("CombatService").is_entity_dead(&"hero"),"capture all before rolls and automatic batch")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore")
	state["mode"] = 1
	check(driver.advance_steps(1) == 1 and state["first"] == state["second"] and state["batch"] and root.get_node("CombatService").is_entity_dead(&"hero") and root.get_node("CombatService").is_entity_dead(&"npc") and root.get_node("CombatService").is_entity_dead(&"neutral"),"deterministic ordering, neutral and simultaneous deaths")
	bus.unsubscribe(&"WeaponStrikeHitSnapshotRequested",on_snapshot); bus.unsubscribe(&"PreparedDirectHitPlanRequested",on_plan); bus.unsubscribe(&"CombatPhaseBatchResolved",on_batch); bus.unsubscribe(&"TimeCombatPhase",phase)
	print("Weapon strike phase discovery tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
