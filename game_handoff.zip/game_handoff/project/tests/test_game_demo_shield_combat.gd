extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e);return e
func key(game: Node,k: Key) -> void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save";var had:=FileAccess.file_exists(path);var old:=PackedByteArray()
	if had:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized,"demo started")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"disable enemy in interface test")
	key(game,KEY_B);key(game,KEY_LEFT)
	check(game.message.contains("щит") and not ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",true),"no shield cannot start")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open inventory")
	var inv:Array=ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]
	check(game._use_inventory_item(inv.find(&"demo_shield")) and driver.advance_steps(10)==10,"equip shield")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close inventory")
	# Подготовленный бой: поставить учебную крысу так, чтобы её реальная
	# зона удара пересекала и тело, и фактическую клетку блока героя.
	game.facing=Vector2i.RIGHT
	check(game._start_shield_block(),"start to query actual shield geometry")
	var zone:=ask(&"ShieldBlockZoneRequested",{"entity":game.HERO})
	var block_tile:Vector2i=zone["data"]["tiles"][0]
	check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel geometry probe")
	var body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]
	var rect:=Rect2i(body["anchor"],Vector2i.ONE*int(body["size"]))
	var chosen:=Vector2i(-1,-1);var direction:=Vector2i.ZERO
	for x in range(body["anchor"].x+4,body["anchor"].x+12):
		for y in range(body["anchor"].y-5,body["anchor"].y+7):
			var p:=Vector2i(x,y)
			if not ask(&"SpaceBodyMoveRequested",{"entity":game.RAT,"anchor":p}).get("accepted",false):continue
			var preview:=ask(&"WeaponStrikePreviewRequested",{"entity":game.RAT,"item":&"demo_rat_sword","strike":"sword_simple_thrust","kind":"physical","direction":Vector2.LEFT})
			var tiles:Array=preview.get("zone",{}).get("tiles",[])
			var hits:=false
			for tile in tiles:
				if rect.has_point(tile):hits=true;break
			if hits and tiles.has(block_tile):chosen=p;direction=Vector2i.LEFT;break
		if chosen.x>=0:break
	check(chosen.x>=0,"real rat attack intersects hero and shield")
	if chosen.x<0:quit(1);return
	var hp:=ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"})
	var stamina:=ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"})
	check(ask(&"ResourceSetRequested",{"entity":game.HERO,"resource":&"Stamina","value":stamina["data"]["max"]}).get("accepted",false),"fill stamina")
	var attack:=ask(&"WeaponStrikeStartRequested",{"entity":game.RAT,"item":&"demo_rat_sword","strike":"sword_simple_thrust","direction":Vector2(direction)})
	check(attack.get("accepted",false),"start real enemy strike")
	if not attack.get("accepted",false):quit(1);return
	var midpoint:int=ceili(float(attack["data"]["duration_steps"])/2.0)
	var rat_body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.RAT})["data"]
	var preview:=ask(&"WeaponStrikePreviewRequested",{"entity":game.RAT,"item":&"demo_rat_sword","strike":"sword_simple_thrust","kind":"physical","direction":Vector2.LEFT})
	var visible:Dictionary={}
	for tile in preview["zone"]["tiles"]:visible[tile]=true
	visible[rat_body["anchor"]]=true
	var hint:Array=game._enemy_windup_tiles(game.RAT,visible)
	check(not hint.is_empty() and hint.has(block_tile),"visible enemy windup zone")
	check(game._enemy_windup_tiles(game.RAT,{}).is_empty() and game._enemy_windup_tiles(game.HERO,visible).is_empty(),"no hidden attacker or self leak")
	var only_body:Dictionary={rat_body["anchor"]:true}
	check(game._enemy_windup_tiles(game.RAT,only_body).size() <= 1,"zone restricted to visible tiles")
	var early:int=maxi(0,midpoint-25)
	if early>0:
		check(driver.wait_for(float(early)*0.01) and driver.advance_steps(early)==early,"advance enemy windup")
	var result:Dictionary={"blocked":false,"absorbed":0,"failed":false}
	var on_phase:=func(e):
		if not e.get("accepted",false):result["failed"]=true
		elif e.get("data",{}).get("blocks",{}).has(game.HERO):
			result["blocked"]=true;result["absorbed"]=e["data"]["blocks"][game.HERO]["absorbed"]
	bus.subscribe(&"CombatPhaseBatchResolved",on_phase)
	key(game,KEY_B);key(game,KEY_RIGHT)
	check(ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",false),"B starts live block")
	driver.advance_steps(midpoint-early)
	check(game._enemy_windup_tiles(game.RAT,visible).is_empty(),"hide enemy zone after hit midpoint")
	bus.unsubscribe(&"CombatPhaseBatchResolved",on_phase)
	print("Combat shield result ",result," hero hp=",hp["data"]["current"]," -> ",ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"})["data"]["current"])
	check(result["blocked"] and result["absorbed"]>0 and not result["failed"],"actual enemy strike absorbed by B shield")
	game.queue_free();await process_frame
	if had:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo real shield combat: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
