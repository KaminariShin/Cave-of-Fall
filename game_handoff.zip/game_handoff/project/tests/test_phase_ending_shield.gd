extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(id: StringName,r: StringName) -> int: return int(ask(&"ResourceGetRequested", {"entity":id,"resource":r})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,30)}).get("accepted",false),"map")
	var floors := []
	for x in range(30):
		for y in range(30): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"npc","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_medium","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false),"shield")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and driver.wait_for(0.1) and driver.advance_steps(10) == 10,"equip")
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":0}).get("accepted",false) and ask(&"ShieldBlockStartRequested", {"entity":&"npc","slot":"off","direction":Vector2i.UP}).get("accepted",false) and driver.wait_for(0.5),"start NPC shield")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save before ending")
	var seen := {"ending":false,"accepted":false,"interrupt":0,"complete":0,"before":0,"after":0,"stamina":-1,"damage":0}
	var interrupted := func(e):
		if e.get("entity",null) == &"npc" and e.get("reason",null) == &"shield_exhausted": seen["interrupt"] += 1
	var complete := func(e):
		if e.get("entity",null) == &"npc": seen["complete"] += 1
	var phase := func(_e):
		var status := ask(&"ShieldBlockStatusRequested", {"entity":&"npc"})
		if status.get("active",false) and status.get("ending",false):
			seen["ending"] = true
			seen["before"] = value(&"npc",&"HP")
			seen["stamina"] = value(&"npc",&"Stamina")
			seen["damage"] = seen["stamina"]*2 + 1
			var q := ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"npc":seen["before"]},"hits":[{"source":&"hero","target":&"npc","damage":seen["damage"],"attack_tiles":[Vector2i(10,9)]}],"block":{"target":&"npc","direction":Vector2i.UP,"expected_stamina":seen["stamina"]},"phase_commit":true})
			seen["accepted"] = q.get("accepted",false)
			seen["after"] = value(&"npc",&"HP")
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"ShieldBlockInterrupted",interrupted); bus.subscribe(&"ShieldBlockCompleted",complete)
	check(driver.advance_steps(50) == 50 and seen["ending"] and seen["accepted"] and seen["after"] == seen["before"] - 1 and seen["interrupt"] == 1 and seen["complete"] == 0,"ending NPC block absorbs then interrupts, not completed")
	check(not ask(&"ShieldBlockStatusRequested", {"entity":&"npc"}).get("active",true),"shield inactive after settlement")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"ShieldBlockInterrupted",interrupted); bus.unsubscribe(&"ShieldBlockCompleted",complete)
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":2}).get("accepted",false),"restore exact block")
	var exact := {"accepted":false,"unchanged_hp":false,"ending_during":false,"complete":0}
	var exact_complete := func(e):
		if e.get("entity",null) == &"npc": exact["complete"] += 1
	var exact_phase := func(_e):
		var status := ask(&"ShieldBlockStatusRequested", {"entity":&"npc"})
		if status.get("active",false) and status.get("ending",false):
			var prior := value(&"npc",&"HP")
			var stamina := value(&"npc",&"Stamina")
			var q := ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"npc":prior},"hits":[{"source":&"hero","target":&"npc","damage":stamina*2,"attack_tiles":[Vector2i(10,9)]}],"block":{"target":&"npc","direction":Vector2i.UP,"expected_stamina":stamina},"phase_commit":true})
			exact["accepted"] = q.get("accepted",false)
			exact["unchanged_hp"] = value(&"npc",&"HP") == prior
			exact["ending_during"] = ask(&"ShieldBlockStatusRequested", {"entity":&"npc"}).get("ending",false)
	bus.subscribe(&"TimeCombatPhase",exact_phase); bus.subscribe(&"ShieldBlockCompleted",exact_complete)
	check(driver.advance_steps(50) == 50 and exact["accepted"] and exact["unchanged_hp"] and exact["ending_during"] and exact["complete"] == 1,"exact coverage keeps ending block until settled")
	bus.unsubscribe(&"TimeCombatPhase",exact_phase); bus.unsubscribe(&"ShieldBlockCompleted",exact_complete)
	print("Phase ending shield tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
