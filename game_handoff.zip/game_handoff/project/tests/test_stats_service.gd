extends SceneTree
var failures := 0
var events: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func add_modifier(bus, modifier: Dictionary) -> bool:
	var req := {"entity": &"hero", "modifier": modifier}
	bus.publish(&"StatModifierAddRequested", req)
	return req.get("accepted", false)
func get_stat(bus, stat: StringName) -> Dictionary:
	var req := {"entity": &"hero", "stat": stat}
	bus.publish(&"StatGetRequested", req)
	return req
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var registry = root.get_node("EntityRegistry")
	check(registry.create_entity(&"hero"), "create hero")
	check(registry.create_entity(&"enemy", {&"stats": {"CON": 7}}), "create enemy")
	var base := get_stat(bus, &"CON")
	check(base["found"] and base["base"] == 5 and base["value"] == 5, "base 5")
	check(registry.get_component(&"enemy", &"stats")["CON"] == 7 and registry.get_component(&"enemy", &"stats")["STR"] == 5, "all six stats and override")
	check(not registry.set_component(&"hero", &"stats", {"CON": 50}), "direct write blocked")
	check(not registry.remove_component(&"hero", &"stats"), "cannot remove stats")
	bus.subscribe(&"StatChanged", func(event): events.append(event.duplicate()))
	check(add_modifier(bus, {"id": "flat", "stat": "CON", "stage": "additive", "op": "add", "value": 3}), "add additive")
	check(add_modifier(bus, {"id": "mult", "stat": "CON", "stage": "multiplicative", "op": "multiply", "value": 2}), "add multiplier")
	check(add_modifier(bus, {"id": "threshold", "stat": "CON", "stage": "threshold", "op": "add", "value": 4, "threshold": 15}), "threshold")
	check(add_modifier(bus, {"id": "final", "stat": "CON", "stage": "final", "op": "add", "value": 1}), "final")
	var value := get_stat(bus, &"CON")
	check(value["value"] == 21 and value["quantitative_thresholds"] == 4 and value["qualitative_thresholds"] == 2, "pipeline and absolute thresholds")
	check(events.size() == 4 and events[3]["old"] == 20 and events[3]["new"] == 21, "stat changed events")
	check(not add_modifier(bus, {"id": "flat", "stat": "CON", "stage": "additive", "op": "add", "value": 1}), "unique ID")
	var remove := {"entity": &"hero", "id": "mult"}
	bus.publish(&"StatModifierRemoveRequested", remove)
	check(remove["accepted"] and get_stat(bus, &"CON")["value"] == 9, "remove and threshold becomes inactive")
	var set := {"entity": &"hero", "stat": "CON", "value": 10}
	bus.publish(&"StatBaseSetRequested", set)
	check(set["accepted"] and get_stat(bus, &"CON")["value"] == 14, "change base")
	check(registry.get_component(&"enemy", &"stats")["CON"] == 7, "entities isolated")
	print("Stats tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
