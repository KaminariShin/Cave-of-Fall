extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool, label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", label)
func ask(bus, id: StringName, data: Dictionary) -> Dictionary:
	bus.publish(id,data)
	return data
func run() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var types := {"dagger":[0.6,0.35], "knife":[0.6,0.35], "sword":[1.0,0.4], "axe":[1.0,0.4], "mace":[1.1,0.45], "spear":[1.2,0.45], "hammer":[2.0,0.45], "bow":[1.2,0.4], "crossbow":[1.3,0.45]}
	for id in types:
		var r := ask(bus, &"WeaponTypeGetRequested", {"id":id})
		check(r["found"] and is_equal_approx(r["data"]["base_attack_time"],types[id][0]) and is_equal_approx(r["data"]["min_percent"],types[id][1]), "type " + id)
	var tags := {"heavy":0.2, "two_handed":0.1, "fencing":0.1, "polearm":0.1, "light":0.0, "one_handed":0.0, "throwing":0.0}
	for id in tags:
		var r := ask(bus, &"WeaponTagGetRequested", {"id":id})
		check(r["found"] and is_equal_approx(r["data"]["min_time_bonus"],tags[id]) and ((id == "one_handed" and r["data"].get("stamina_cost_percent", null) == 0.0) or (id == "two_handed" and r["data"].get("stamina_cost_percent", null) == 0.1) or (id not in ["one_handed","two_handed"] and not r["data"].has("stamina_cost_percent"))), "tag " + id)
	check(ask(bus, &"WeaponVariantRegisterRequested", {"definition":{"id":"sample", "type":"sword", "tags":["heavy", "two_handed"]}})["accepted"], "variant")
	var resolved := ask(bus, &"WeaponVariantResolveRequested", {"variant":"sample"})
	check(resolved["found"] and not resolved["data"]["stamina_cost_complete"] and is_equal_approx(resolved["data"]["min_time_bonus"],0.3), "unknown stamina explicitly marked")
	var rules := ask(bus, &"RulesetGetRequested", {})
	var weapons: Dictionary = rules["ruleset"]["parameters"]["combat"]["weapons"]
	for item in [["sword",6,2], ["dagger",3,1], ["spear",7,3], ["bow",15,4], ["fireball",10,2]]:
		check(weapons[item[0]]["range"] == item[1] and weapons[item[0]]["gap"] == item[2], "range gap " + item[0])
	print("Weapon ruleset tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
