extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(begin(4), "tracking floor four")
	for i in range(1, 17):
		check(add_room(i, "passage"), "chain room " + str(i))
	check(tracking().get("boss_candidate", null) == &"node_16", "first candidate")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_16"})["data"]
	var p: Vector2i = room["origin_cell"] * 4 + Vector2i(10,10)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "create hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":p, "size":4}).get("accepted", false), "place hero")
	var d := ask(&"DungeonRoomDepthRequested", {"room":&"node_16"})
	var request := {"room":&"node_16", "player":&"hero", "entry_tile":p, "depth":d["depth"], "pool":[]}
	var wrong := request.duplicate(true)
	wrong["depth"] = 1
	check(not ask(&"RoomSpawnRequested", wrong).get("accepted", true), "reject wrong depth")
	var bus = root.get_node("EventBus")
	var force_min := func(e): e["value"] = 0.0
	var block_boss := func(e):
		if e.get("size", 0) == 6: e["fits"] = false
	bus.subscribe(&"RngFloatRequested", force_min)
	bus.subscribe(&"SpaceBodyFitsRequested", block_boss)
	var blocked_request := request.duplicate(true)
	blocked_request["queue_delay"] = 1.0
	var blocked := ask(&"RoomSpawnRequested", blocked_request)
	bus.unsubscribe(&"SpaceBodyFitsRequested", block_boss)
	check(not blocked.get("accepted", true) and not ask(&"RoomSpawnStatusRequested", {"room":&"node_16"}).get("spawned", true), "unplaceable mandatory boss does not enter queue or commit")
	var spawn := ask(&"RoomSpawnRequested", request)
	bus.unsubscribe(&"RngFloatRequested", force_min)
	check(spawn.get("accepted", false), "boss room spawn " + str(spawn.get("error", "")))
	if spawn.get("accepted", false):
		var level: int = spawn["level"]
		check(spawn["units"].size() == 1 and spawn["queue_count"] == 0, "boss placed immediately")
		if spawn["units"].size() == 1:
			var boss: Dictionary = spawn["units"][0]
			check(boss["type_id"] == "final_ogre" and boss["body_size"] == 6 and boss["tags"] == ["boss"], "ogre type size and tags")
			check(is_equal_approx(boss["weight"], 12.0 * level) and is_equal_approx(spawn["budget"], boss["weight"]) and is_zero_approx(spawn["remaining_budget"]), "low budget raised to boss weight")
			check(boss["stats"]["CON"] == 12 + 2 * (level - 1) and boss["stats"]["DEX"] == 5, "growth and boss stat bonus")
			var boss_id: StringName = boss["entity"]
			check(ask(&"DungeonBossEquipmentInstallRequested", {"entity":boss_id}).get("accepted", false), "equip before combat")
			check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save and load boss")
			check(ask(&"EntityGetRequested", {"entity":boss_id}).get("found", false), "boss persists")
			check(not ask(&"RoomSpawnRequested", request.duplicate(true)).get("accepted", true), "no duplicate room spawn")
			check(ask(&"DungeonBossGetRequested", {}).get("data", {}).get("status", "") == "alive", "boss alive tracked")
			var file := FileAccess.open("user://session.save", FileAccess.READ)
			var alive_save: Dictionary = bytes_to_var(file.get_buffer(file.get_length()))
			file.close()
			var fake_save := alive_save.duplicate(true)
			fake_save["sections"]["spawn"]["boss"]["status"] = "defeated"
			file = FileAccess.open("user://session.save", FileAccess.WRITE)
			file.store_buffer(var_to_bytes(fake_save))
			file.close()
			check(not ask(&"SessionLoadRequested", {}).get("accepted", true), "reject false defeat of live boss")
			fake_save = alive_save.duplicate(true)
			fake_save["sections"]["spawn"]["boss"] = {}
			file = FileAccess.open("user://session.save", FileAccess.WRITE)
			file.store_buffer(var_to_bytes(fake_save))
			file.close()
			check(not ask(&"SessionLoadRequested", {}).get("accepted", true), "reject missing committed boss record")
			var deaths := {"count":0}
			var defeat := func(_e): deaths["count"] += 1
			bus.subscribe(&"DungeonBossDefeated", defeat)
			var rollback: Dictionary = root.get_node("SaveService").run_world_transition_transaction(func():
				ask(&"CombatDamageRequested", {"entity":boss_id, "source":&"hero", "amount":999999})
				return false)
			check(rollback.get("rolled_back", false) and ask(&"DungeonBossGetRequested", {})["data"]["status"] == "alive", "rollback restores boss alive")
			check(deaths["count"] == 1, "rollback does not retract event")
			check(ask(&"CombatDamageRequested", {"entity":boss_id, "source":&"hero", "amount":999999}).get("accepted", false), "kill boss")
			check(ask(&"DungeonBossGetRequested", {})["data"]["status"] == "defeated" and deaths["count"] == 2, "defeat reported once")
			check(not ask(&"CombatDamageRequested", {"entity":boss_id, "amount":1}).get("accepted", false) and deaths["count"] == 2, "no duplicate defeat")
			check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and ask(&"DungeonBossGetRequested", {})["data"]["status"] == "defeated", "defeat persists")
			check(ask(&"EntityRemoveRequested", {"entity":boss_id}).get("accepted", false), "remove corpse")
			check(ask(&"DungeonBossGetRequested", {})["data"]["status"] == "defeated" and ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "defeat persists after corpse removal")
			file = FileAccess.open("user://session.save", FileAccess.WRITE)
			file.store_buffer(var_to_bytes(alive_save))
			file.close()
			check(ask(&"SessionLoadRequested", {}).get("accepted", false), "restore alive snapshot")
			check(ask(&"EntityRemoveRequested", {"entity":boss_id}).get("accepted", false), "remove living boss")
			check(ask(&"DungeonBossGetRequested", {})["data"]["status"] == "lost" and deaths["count"] == 2, "removal is not victory")
			check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and ask(&"DungeonBossGetRequested", {})["data"]["status"] == "lost", "lost state persists")
			bus.unsubscribe(&"DungeonBossDefeated", defeat)
	print("Boss spawn tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
