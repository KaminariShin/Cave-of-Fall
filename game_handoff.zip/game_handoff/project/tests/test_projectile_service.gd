extends SceneTree
var failures := 0
var expired: Array = []
var explosions: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func hp(bus, id: StringName) -> float:
	return float(ask(bus, &"ResourceGetRequested", {"entity": id, "resource": &"HP"})["data"]["current"])
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"ProjectileExpired", func(e): expired.append(e.duplicate(true)))
	bus.subscribe(&"ProjectileExplosion", func(e): explosions.append(e.duplicate(true)))
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(40, 20)})["accepted"], "map")
	var floors: Array = []
	for x in range(40):
		for y in range(20): floors.append(Vector2i(x, y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})["accepted"], "floor")
	for id in [&"shooter", &"rat", &"bystander"]:
		check(entities.create_entity(id), "create " + str(id))
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"shooter", "anchor": Vector2i(2, 5), "size": 2})["accepted"], "shooter body")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"rat", "anchor": Vector2i(10, 5), "size": 2})["accepted"], "rat body")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"bystander", "anchor": Vector2i(10, 7), "size": 2})["accepted"], "bystander")
	check(not ask(bus, &"ProjectileLaunchRequested", {"entity": &"shooter", "weapon_type": "fireball", "gap": 2, "direction": Vector2.RIGHT})["accepted"], "no invented speed")
	var launch := ask(bus, &"ProjectileLaunchRequested", {"entity": &"shooter", "weapon_type": "fireball", "gap": 2, "direction": Vector2.RIGHT, "speed": 10})
	check(launch["accepted"] and launch["position"] == Vector2(7, 6), "fireball muzzle 2 + gap")
	var id: StringName = launch["id"]
	check(ask(bus, &"ProcessGetRequested", {"id": id})["data"]["independent"], "independent registered process")
	check(driver.wait_for(1.0), "time for flight")
	driver.advance_steps(10)
	var state := ask(bus, &"ProjectileGetRequested", {"id": id})
	check(state["found"] and is_equal_approx(state["data"]["position"].x, 8.0), "game time position")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save during flight")
	check(entities.remove_entity(&"shooter"), "remove owner during flight")
	check(ask(bus, &"ProjectileGetRequested", {"id": id})["found"], "flight survives removal")
	driver.advance_steps(20)
	check(not ask(bus, &"ProjectileGetRequested", {"id": id})["found"], "projectile hit")
	check(hp(bus, &"rat") == 36.0 and hp(bus, &"bystander") == 42.0, "direct 6 plus explosion 3, other 3")
	check(expired.size() == 1 and expired[0]["reason"] == &"entity" and expired[0]["target"] == &"rat" and expired[0]["explosion"]["center"] == Vector2i(10, 6), "impact and explosion cell")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load mid-flight")
	check(ask(bus, &"ProjectileGetRequested", {"id": id})["found"], "projectile restored")
	driver.advance_steps(20)
	check(hp(bus, &"rat") == 36.0 and hp(bus, &"bystander") == 42.0 and expired.size() == 2, "restored shot resolves once")
	# Для следующего теста обрываем ожидание и освобождаем новую полосу.
	driver.cancel_action()
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"rat", "anchor": Vector2i(10, 5)})["accepted"], "rat stays")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"bystander", "anchor": Vector2i(7, 7)})["accepted"], "bystander in front of wall")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(9, 5), Vector2i(9, 6), Vector2i(9, 7)], "kind": 0})["accepted"], "wall")
	var wall_shot := ask(bus, &"ProjectileLaunchRequested", {"entity": &"shooter", "weapon_type": "fireball", "gap": 2, "direction": Vector2.RIGHT, "speed": 10})
	check(wall_shot["accepted"], "fireball toward wall")
	check(driver.wait_for(0.3), "advance wall shot")
	driver.advance_steps(20)
	check(expired.size() == 3 and expired[2]["reason"] == &"wall" and expired[2]["explosion"]["center"] == Vector2i(9, 6), "wall impact explosion")
	check(hp(bus, &"rat") == 36.0, "wall blocks blast behind")
	check(hp(bus, &"bystander") == 39.0, "blast damages before wall")
	driver.cancel_action()
	# Стена перед точкой старта и ближе 0.4 тайла от неё.
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(9, 5), Vector2i(9, 6), Vector2i(9, 7)], "kind": 1})["accepted"], "remove wall")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(7, 6)], "kind": 0})["accepted"], "near wall")
	var denied := ask(bus, &"ProjectileLaunchRequested", {"entity": &"shooter", "weapon_type": "fireball", "gap": 2, "direction": Vector2(0.98, 0.2), "speed": 10})
	check(not denied["accepted"] and denied.get("error", "").contains("меньше 0.4"), "wall closer than 0.4 rejects launch")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(7, 6)], "kind": 1})["accepted"], "clear near wall")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(5, 6)], "kind": 0})["accepted"], "wall before muzzle")
	var blocked_muzzle := ask(bus, &"ProjectileLaunchRequested", {"entity": &"shooter", "weapon_type": "fireball", "gap": 2, "direction": Vector2.RIGHT, "speed": 10})
	check(not blocked_muzzle["accepted"] and blocked_muzzle.get("error", "").contains("точкой запуска"), "cannot spawn through wall")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(5, 6)], "kind": 1})["accepted"], "clear muzzle wall")
	# Летящий объект сохраняет урон источника даже после удаления источника.
	check(ask(bus, &"PipelineModifierRegisterRequested", {"entity": &"shooter", "modifier": {"id": "double", "target": "damage.outgoing", "stage": "multiplicative", "op": "multiply", "value": 2}})["accepted"], "source damage mod")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"bystander", "anchor": Vector2i(12, 8)})["accepted"], "move bystander away")
	var powered := ask(bus, &"ProjectileLaunchRequested", {"entity": &"shooter", "weapon_type": "fireball", "gap": 2, "direction": Vector2.RIGHT, "speed": 10})
	check(powered["accepted"], "powered launch")
	check(entities.remove_entity(&"shooter"), "remove powered source")
	check(driver.wait_for(0.4), "advance powered flight")
	driver.advance_steps(30)
	check(hp(bus, &"rat") == 18.0, "snapshot outgoing modifier: 12 plus 6 after removal")
	driver.cancel_action()
	# Снаряд исчезает и взрывается на пределе дальности, даже без попадания.
	# Явный gap проверяет низкоуровневый API независимо от игровых умолчаний.
	check(entities.create_entity(&"archer"), "new archer")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"archer", "anchor": Vector2i(2, 12), "size": 2})["accepted"], "archer body")
	var arrow := ask(bus, &"ProjectileLaunchRequested", {"entity": &"archer", "weapon_type": "bow", "gap": 4, "direction": Vector2.RIGHT, "speed": 2, "range": 2, "damage": 4})
	check(arrow["accepted"] and arrow["position"] == Vector2(9, 13), "bow blind offset six tiles")
	for i in range(5):
		check(driver.wait_for(0.2), "wait " + str(i))
		driver.advance_steps(20)
		if i < 4:
			check(ask(bus, &"ProjectileGetRequested", {"id": arrow["id"]})["found"], "arrow still airborne")
	check(not ask(bus, &"ProjectileGetRequested", {"id": arrow["id"]})["found"] and expired.back()["reason"] == &"range", "2 tiles at 2 tiles/s in five waits")
	var range_blast := ask(bus, &"ProjectileLaunchRequested", {"entity": &"archer", "weapon_type": "fireball", "gap": 2, "direction": Vector2.RIGHT, "speed": 2, "range": 2})
	check(range_blast["accepted"], "range blast launch")
	var idle: Vector2 = ask(bus, &"ProjectileGetRequested", {"id": range_blast["id"]})["data"]["position"]
	check(ask(bus, &"ProjectileGetRequested", {"id": range_blast["id"]})["data"]["position"] == idle, "no flight while time is stopped")
	check(driver.wait_for(1.0), "advance range blast")
	driver.advance_steps(100)
	check(expired.back()["reason"] == &"range" and expired.back()["explosion"]["center"] == Vector2i(9, 13), "range expiry explodes")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"archer", "anchor": Vector2i(2, 5)})["accepted"], "reposition archer")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"rat", "anchor": Vector2i(10, 4)})["accepted"], "position moving target")
	check(ask(bus, &"MovementConfigureRequested", {"entity": &"rat", "actor_type": "rat", "K_move": 10})["accepted"], "configure moving target")
	check(ask(bus, &"MovementStepRequested", {"entity": &"rat", "delta": Vector2i.DOWN})["accepted"], "target starts moving")
	var moving := ask(bus, &"ProjectileLaunchRequested", {"entity": &"archer", "weapon_type": "fireball", "gap": 2, "direction": Vector2.RIGHT, "speed": 30})
	check(moving["accepted"], "shot at moving target")
	check(driver.wait_for(0.2), "advance moving hit")
	driver.advance_steps(10)
	check(expired.back()["id"] == moving["id"] and expired.back()["target"] == &"rat" and hp(bus, &"rat") == 9.0, "projectile hits interpolated moving rectangle")
	driver.advance_steps(5)
	driver.cancel_action()
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"archer", "anchor": Vector2i(20, 5)})["accepted"], "position reverse shooter")
	var reverse := ask(bus, &"ProjectileLaunchRequested", {"entity": &"archer", "weapon_type": "fireball", "gap": 2, "direction": Vector2.LEFT, "speed": 50})
	check(reverse["accepted"] and driver.wait_for(0.2), "reverse fire")
	driver.advance_steps(10)
	check(expired.back()["id"] == reverse["id"] and expired.back()["explosion"]["center"] == Vector2i(11, 6) and hp(bus, &"rat") == 0, "leftward hit enters correct tile and kills")
	print("Projectile and explosion tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
