extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func ask(name: StringName, e: Dictionary) -> Dictionary:
	bus.publish(name,e)
	return e
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func run() -> void:
	bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"initialized")
	game._remember_visible()
	var fog := ask(&"FogStateGetRequested",{})
	var tile := Vector2i(-1,-1)
	for candidate in fog["visible_tiles"]:
		var info := ask(&"SpaceTileGetRequested",{"tile":candidate})
		if info.get("kind",0) == 1 and info.get("occupant",null) == null and info.get("obstacle",null) == null and not info.get("passage",false) and Vector2(candidate).distance_to(fog["center"]) > 3:
			tile = candidate
			break
	check(tile.x >= 0,"eligible observed tile")
	check((int(game._map_memory.get(tile,0)) & game.MEM_FLOOR) != 0,"observed floor remembered")
	check(ask(&"FogDetectionRadiusSetRequested",{"entity":game.HERO,"radius":0.0})["accepted"],"hide")
	check(not ask(&"FogStateGetRequested",{})["visible_tiles"].has(tile),"tile hidden")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[tile],"kind":0})["accepted"],"hidden terrain changed")
	check((int(game._map_memory.get(tile,0)) & game.MEM_FLOOR) != 0,"hidden change not leaked")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save")
	game._map_memory.clear()
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load")
	check((int(game._map_memory.get(tile,0)) & game.MEM_FLOOR) != 0,"hidden state survives save and load")
	check(ask(&"FogDetectionRadiusSetRequested",{"entity":game.HERO,"radius":20.0})["accepted"],"reveal")
	check((int(game._map_memory.get(tile,-1)) & game.MEM_FLOOR) == 0,"reobservation refreshes terrain")
	var a: Image = game._floor_memory_atlas.get_image()
	var c := a.get_pixel(5,5)
	check(absf(c.r-c.g)<0.01 and absf(c.g-c.b)<0.01,"memory atlas grayscale")
	game._spawn_map_reset({})
	check(game._map_memory.is_empty(),"new map clears memory")
	game.queue_free()
	await process_frame
	print("Fog map memory: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
