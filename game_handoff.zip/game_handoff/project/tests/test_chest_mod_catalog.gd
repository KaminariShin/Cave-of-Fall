extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func preview(base: StringName, level: int, material: StringName, category: String, used: Array = []) -> Dictionary:
	return ask(&"DungeonChestModCandidatesPreviewRequested", {"base_id":base,"item_level":level,"material_id":material,"category":category,"used_mod_ids":used})
func ids(result: Dictionary) -> Array:
	var out: Array = []
	for row in result.get("candidates",[]): out.append(row["id"])
	return out
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var level1 := preview(&"sword_simple",1,&"iron_common","prefix")
	check(level1.get("accepted",false) and ids(level1) == [&"pre_strength"] and level1["candidates"][0]["tiers"].size() == 1 and level1["candidates"][0]["tiers"][0]["tier"] == 3 and level1["candidates"][0]["tiers"][0]["weight"] == 10 and level1["candidates"][0]["tiers"][0]["value"] == 1.0, "level 1 sword metal prefixes")
	var level3 := preview(&"sword_simple",3,&"steel_common","prefix")
	check(ids(level3) == [&"pre_strength"] and level3["candidates"][0]["tiers"].size() == 2 and level3["candidates"][0]["tiers"][1]["weight"] == 3, "level 3 tiers")
	var level5 := preview(&"sword_simple",5,&"steel_tempered","suffix")
	check(ids(level5) == [&"suf_physical_damage", &"suf_bleed", &"suf_poison"] and level5["candidates"][1]["tiers"][2]["value"] == 30 and level5["candidates"][1]["tiers"][2]["weight"] == 1, "level 5 weapon suffixes")
	check(ids(preview(&"sword_simple",5,&"leather_scale","suffix",[&"suf_poison"])) == [&"suf_physical_damage", &"suf_perception"], "used mod ID excluded across materials")
	check(ids(preview(&"staff_simple",3,&"cloth_reinforced","prefix")) == [&"pre_agile", &"pre_mind"], "staff special prefix")
	check(ids(preview(&"staff_simple",3,&"cloth_reinforced","affix")) == [&"affix_mana"], "staff special affix")
	check(ids(preview(&"armor_cloth_body",1,&"cloth_light","prefix")) == [&"pre_vital", &"pre_agile", &"pre_mind"], "body cloth")
	check(ids(preview(&"shield_small",1,&"iron_common","prefix")) == [&"pre_vital", &"pre_strength", &"pre_armour"], "shield metal")
	check(preview(&"sword_simple",1,&"iron_common","affix").get("accepted",false) and ids(preview(&"sword_simple",1,&"iron_common","affix")).is_empty(), "empty eligible pool is valid")
	check(not preview(&"sword_simple",1,&"steel_common","prefix").get("accepted",true) and not preview(&"potion_hp",1,&"potion_pack","prefix").get("accepted",true), "wrong material or base rejected")
	check(not preview(&"sword_simple",1,&"iron_common","prefix",[&"x",&"x"]).get("accepted",true), "duplicate used IDs rejected")
	check(not ask(&"ModDefinitionGetRequested", {"id":&"pre_strength"}).get("found",true), "catalog does not register live mod")
	var after: Dictionary = saver.collect_world_transition_snapshot()
	check(before.get("valid",false) and after.get("valid",false) and before["payload"]["sections"] == after["payload"]["sections"], "no RNG or world mutations")
	var service = root.get_node("DungeonChestModCatalogService")
	var invalid: Array = service._catalog.duplicate(true)
	invalid[0]["tiers"][0]["weight"] = 0
	check(not service._catalog_valid(invalid), "invalid catalog rejected")
	invalid = service._catalog.duplicate(true); invalid.append(invalid[0].duplicate(true))
	check(not service._catalog_valid(invalid), "duplicate catalog ID rejected")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and ids(preview(&"staff_simple",3,&"cloth_reinforced","affix")) == [&"affix_mana"], "save load")
	print("Chest mod candidate catalog tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
