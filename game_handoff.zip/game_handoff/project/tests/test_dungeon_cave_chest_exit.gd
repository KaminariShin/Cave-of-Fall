extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false), "map")
	check(ask(&"RoomCaveConfigureRequested", {"enabled":true, "seed":55}).get("accepted", false), "caves")
	check(ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false), "root")
	check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":4, "start_room":&"root"}).get("accepted", false), "tracking")
	check(add_room(1, "passage") and add_room(2, "passage"), "cave chain")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_1"})["data"]
	var origin: Vector2i = room["origin_cell"] * 4
	var path: Array = []
	for x in range(24,28):
		for y in range(1,27): path.append(origin + Vector2i(x,y))
	for x in range(1,47):
		for y in range(20,24): path.append(origin + Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":path, "kind":1}).get("accepted", false), "prepare already-connected floor to north boundary")
	var north_tiles: Array = []
	for i in range(4): north_tiles.append(origin + Vector2i(24+i,0))
	var room_service = root.get_node("RoomService")
	room = ask(&"RoomGetRequested", {"id":&"node_1"})["data"]
	var wide: Array = room_service._wide_exit_floor(room,{"tiles":north_tiles,"dirOut":"north"})
	check(ask(&"SpaceTilesSetRequested", {"tiles":wide,"kind":1}).get("accepted",false), "prepare full 4x4 exit corridor")
	room = ask(&"RoomGetRequested", {"id":&"node_1"})["data"]
	check(room_service._cave_exit_needs_no_terrain_repair(room, north_tiles, "north"), "north passage already touches connected cave floor")
	var cursor := 0
	var chosen: Variant = null
	var pages := 0
	while chosen == null and pages < 600:
		var page := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "cursor":cursor})
		if not page.get("accepted", false): break
		if page.get("found", false):
			var probe := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":page["tile"], "additional_exit":{"x":origin.x+24, "y":origin.y, "dirOut":"north"}})
			if probe.get("accepted", false): chosen = page["tile"]
		cursor = page["next_cursor"]
		if page.get("complete", false): break
		pages += 1
	check(chosen is Vector2i, "found chest candidate compatible with planned exit")
	if not chosen is Vector2i: quit(1); return
	check(ask(&"ObjectCreateRequested", {"entity":&"cave_chest", "type":"chest", "room":&"node_1", "tile":chosen, "inventory_capacity":10}).get("accepted", false), "place cave chest")
	var save_service = root.get_node("SaveService")
	var before: Dictionary = save_service.collect_world_transition_snapshot()
	var rejected_offset := -1
	for offset in range(1,11):
		var proposed: Array = []
		for i in range(4): proposed.append(origin + Vector2i(offset * 4 + i,47))
		if not room_service._cave_exit_needs_no_terrain_repair(room, proposed, "south"): rejected_offset = offset; break
	check(rejected_offset >= 0, "find exit that would require repair")
	if rejected_offset >= 0:
		check(not ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"needs_repair", "dir":"south", "offset_cells":rejected_offset}).get("accepted", true), "reject cave exit requiring terrain repair")
		var after_rejection: Dictionary = save_service.collect_world_transition_snapshot()
		check(before.get("valid", false) and after_rejection.get("valid", false) and before["payload"]["sections"] == after_rejection["payload"]["sections"], "failed cave preflight leaves world unchanged")
	check(ask(&"EntityCreateRequested", {"entity":&"blocking_body"}).get("accepted", false), "create temporary blocking body")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"blocking_body", "anchor":origin + Vector2i(24,1), "size":4}).get("accepted", false), "block planned doorway approach")
	check(not ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"north_blocked", "dir":"north", "offset_cells":6}).get("accepted", true), "body blocks hypothetical 4x4 approach")
	check(ask(&"EntityRemoveRequested", {"entity":&"blocking_body"}).get("accepted", false), "remove temporary blocker")
	check(ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"north_safe", "dir":"north", "offset_cells":6}).get("accepted", false), "allow cave exit requiring no terrain repair")
	var after: Dictionary = save_service.collect_world_transition_snapshot()
	var oldfloor: Dictionary = before["payload"]["sections"]["space"]["floor"]
	var newfloor: Dictionary = after["payload"]["sections"]["space"]["floor"]
	var diff := []
	for tile in newfloor:
		if not oldfloor.has(tile): diff.append(tile)
	for tile in oldfloor:
		if not newfloor.has(tile): diff.append(tile)
	check(diff.size() == 4 and diff.all(func(t): return north_tiles.has(t)), "only new doorway tiles changed")
	var final := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":chosen, "existing_object":&"cave_chest"})
	check(final.get("accepted", false) and final.get("open_exits_checked", 0) == 3, "chest and exits remain reachable")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and ask(&"ObjectGetRequested", {"object":&"cave_chest"}).get("found", false), "safe cave result persists")
	print("Cave chest exit tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
