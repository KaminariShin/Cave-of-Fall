extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func gear()->Dictionary:return ask(&"ComponentGetRequested",{"entity":&"hero","component":&"equipment"})["data"]
func inventory()->Dictionary:return ask(&"InventoryGetRequested",{"entity":&"hero"})
func ground()->Dictionary:return ask(&"LootGetRequested",{})["items"]
func run()->void:
	bus=root.get_node("EventBus");var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://session.save";var exists:=FileAccess.file_exists(path);var old:=PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,40)}).get("accepted",false),"map")
	var floor_tiles:Array=[]
	for y in range(40):
		for x in range(40):floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false) and ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false) and ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":10}).get("accepted",false),"body and capacity")
	for id in [&"shield_one",&"shield_two"]:
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"shield_small","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":&"hero","item":id}).get("accepted",false),"shield")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"shield_one","slot":"off"}).get("accepted",false) and driver.advance_steps(10)==10,"equip")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":inventory()["used_volume"]}).get("accepted",false),"fill inventory")
	var no_tile:=ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":"off"})
	check(not no_tile.get("accepted",true) and no_tile.get("needs_drop_tile",false),"asks for tile")
	check(not ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":"off","drop_tile":Vector2i(20,12)}).get("accepted",true),"out of range rejected")
	var observed:={"atomic":true,"count":0}
	var on_drop:=func(e):
		if e.get("item",null)==&"shield_one":
			observed["count"]+=1
			if gear().get("off",null)!=null or not ground().has(&"shield_one") or inventory()["data"]["items"].has(&"shield_one"):observed["atomic"]=false
	bus.subscribe(&"LootItemDropped",on_drop)
	check(ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":"off","drop_tile":Vector2i(14,12)}).get("accepted",false),"start drop")
	check(driver.advance_steps(5)==5 and gear().get("off",null)==&"shield_one" and not ground().has(&"shield_one"),"item remains equipped halfway")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[Vector2i(14,12)],"kind":0}).get("accepted",false),"selected tile becomes wall")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save pending drop")
	check(driver.advance_steps(5)==5 and gear().get("off",null)==null and ground().get(&"shield_one",{}).get("tile",null)==Vector2i(14,11),"fallback drop completes")
	check(observed["atomic"] and observed["count"]==1,"notifications see atomic ownership")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and gear().get("off",null)==&"shield_one" and not ground().has(&"shield_one"),"restore pending drop")
	check(driver.advance_steps(5)==5 and ground().get(&"shield_one",{}).get("tile",null)==Vector2i(14,11) and observed["count"]==2,"restored drop once")
	bus.unsubscribe(&"LootItemDropped",on_drop)
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":10}).get("accepted",false),"expand")
	check(ask(&"SpaceBodyMoveRequested",{"entity":&"hero","anchor":Vector2i(11,8)}).get("accepted",false),"move body over item")
	check(ask(&"LootPickupRequested",{"entity":&"hero","item":&"shield_one","duration":0.1}).get("accepted",false) and driver.advance_steps(10)==10 and inventory()["data"]["items"].has(&"shield_one") and not ground().has(&"shield_one"),"ground item can be picked up")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"shield_two","slot":"off"}).get("accepted",false) and driver.advance_steps(10)==10,"equip second")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":inventory()["used_volume"]}).get("accepted",false),"fill again")
	check(ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":"off","drop_tile":Vector2i(14,11)}).get("accepted",false),"start second drop")
	var deny:=func(e):e["visible"]=false
	bus.subscribe(&"SpaceLineOfSightRequested",deny)
	check(driver.advance_steps(10)==10 and gear().get("off",null)==&"shield_two" and not ground().has(&"shield_two"),"no valid fallback keeps item equipped")
	bus.unsubscribe(&"SpaceLineOfSightRequested",deny)
	check(ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":"off","drop_tile":Vector2i(14,11)}).get("accepted",false) and driver.advance_steps(5)==5 and ask(&"ActionCancelRequested",{"entity":&"hero"}).get("accepted",false) and gear().get("off",null)==&"shield_two" and not ground().has(&"shield_two"),"interruption keeps item")
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Equipment ground drop: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
