extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(v:bool,label:String)->void:
	if not v:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized,"setup")
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	check(game._start_attack(),"hero starts attack")
	var hero:Dictionary=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})
	var midpoint:int=ceili(float(hero["data"]["duration_steps"])/2.0)
	check(game._strike_before_hit(game.HERO) and not game._strike_flashes.has(game.HERO),"white windup no green flash")
	check(driver.advance_steps(midpoint-1)==midpoint-1,"approach midpoint")
	check(game._strike_before_hit(game.HERO) and not game._strike_flashes.has(game.HERO),"windup stays white until hit")
	check(driver.advance_steps(1)==1,"hit step")
	check(not game._strike_before_hit(game.HERO) and game._strike_flashes.has(game.HERO),"green flash starts at midpoint")
	check(game._strike_flashes[game.HERO]["tiles"]==game.attack_tiles,"hero flash uses actual attack zone")
	ask(&"ActionCancelRequested",{"entity":game.HERO})
	check(ask(&"ControlledEntityRequested",{"entity":game.RAT}).get("accepted",false),"control rat for deterministic clock")
	var rat:=ask(&"WeaponStrikeStartRequested",{"entity":game.RAT,"item":&"demo_rat_sword","strike":"demo_rat_thrust","direction":Vector2.LEFT})
	check(rat.get("accepted",false),"rat starts")
	if rat.get("accepted",false):
		var st:Dictionary=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.RAT})
		var mid:int=ceili(float(st["data"]["duration_steps"])/2.0)
		check(driver.advance_steps(mid-1)==mid-1 and game._strike_before_hit(game.RAT) and not game._strike_flashes.has(game.RAT),"enemy remains yellow before midpoint")
		check(driver.advance_steps(1)==1 and not game._strike_before_hit(game.RAT),"enemy midpoint")
		check(game._strike_flashes.has(game.RAT),"visible enemy gets red impact flash")
	game.queue_free();await process_frame
	print("Two-color strike phases: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
