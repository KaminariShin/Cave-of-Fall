extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(id: StringName,r: StringName) -> float:
	return float(ask(&"ResourceGetRequested", {"entity":id,"resource":r})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc",&"other"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5),&"sword",&"sword_simple","main"],[&"npc",Vector2i(10,5),&"shield",&"shield_medium","off"]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"body inventory")
		check(ask(&"ItemCreateRequested", {"id":row[2],"base_id":row[3],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":row[2]}).get("accepted",false),"item")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	check(not ask(&"WeaponStrikePhaseAutoSubmitRequested",{}).get("accepted",true),"outside phase rejected")
	var idle := {"ok":false,"batch":false}
	var idle_phase := func(_e):
		var q := ask(&"WeaponStrikePhaseAutoSubmitRequested",{})
		idle["ok"] = q.get("accepted",false) and q["data"]["attack_count"] == 0 and q["data"]["hit_count"] == 0
	var idle_batch := func(_e): idle["batch"] = true
	bus.subscribe(&"TimeCombatPhase",idle_phase); bus.subscribe(&"CombatPhaseBatchResolved",idle_batch)
	check(driver.wait_for(0.01) and driver.advance_steps(1) == 1 and idle["ok"] and not idle["batch"],"empty phase")
	bus.unsubscribe(&"TimeCombatPhase",idle_phase); bus.unsubscribe(&"CombatPhaseBatchResolved",idle_batch)
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"HP","value":20}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":7}).get("accepted",false),"set resources")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"npc","slot":"off","direction":Vector2i.LEFT}).get("accepted",false),"block")
	var start := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(start.get("accepted",false),"strike")
	if not start.get("accepted",false): quit(1); return
	var middle := ceili(float(start["data"]["duration_steps"])/2.0)
	check(driver.advance_steps(middle-1) == middle-1 and ask(&"SessionSaveRequested",{}).get("accepted",false),"save before midpoint")
	var state := {"mode":0,"invalid":false,"duplicate":false,"batch_failed":false,"batch_ok":false,"submitted":false,"blocks":0,"interrupted":0,"other":false}
	var batch := func(e):
		if state["mode"] == 0: state["batch_failed"] = not e.get("accepted",true)
		else:
			state["batch_ok"] = e.get("accepted",false) and e.get("hit_count",0) == 1 and e.get("block_count",0) == 1
			if e.get("accepted",false): state["blocks"] = e["data"]["blocks"][&"npc"]["absorbed"]
	var interrupted := func(e):
		if e.get("entity",null) == &"npc" and e.get("reason",null) == &"shield_exhausted": state["interrupted"] += 1
	var phase := func(_e):
		if state["mode"] == 0:
			ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":1.5})
			state["other"] = ask(&"CombatPhaseHitSubmitRequested", {"source":&"other","target":&"npc","damage":1,"hp_before":20}).get("accepted",false)
			state["invalid"] = not ask(&"WeaponStrikePhaseAutoSubmitRequested",{}).get("accepted",true)
		else:
			ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":1})
			var q := ask(&"WeaponStrikePhaseAutoSubmitRequested",{})
			state["submitted"] = q.get("accepted",false) and q["data"]["attack_count"] == 1 and q["data"]["hit_count"] == 1 and q["data"]["block_count"] == 1
			state["duplicate"] = not ask(&"WeaponStrikePhaseAutoSubmitRequested",{}).get("accepted",true)
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"ShieldBlockInterrupted",interrupted)
	check(driver.advance_steps(1) == 1 and state["other"] and state["invalid"] and state["batch_failed"] and value(&"npc",&"HP") == 20 and value(&"npc",&"Stamina") == 1.5,"fractional block rejects entire collected package")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore")
	state["mode"] = 1
	check(driver.advance_steps(1) == 1 and state["submitted"] and state["duplicate"] and state["batch_ok"] and state["blocks"] == 2 and value(&"npc",&"HP") < 20 and value(&"npc",&"Stamina") == 0 and state["interrupted"] == 1,"auto-collected shield applies and interrupts")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"ShieldBlockInterrupted",interrupted)
	print("Weapon strike phase submit tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
