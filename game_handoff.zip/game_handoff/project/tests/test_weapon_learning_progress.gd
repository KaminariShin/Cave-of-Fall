extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void: call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func state(id:StringName)->Dictionary:
	return ask(&"ItemGetRequested",{"item":id})["item_data"]["learning_state"]
func strike()->Dictionary:
	return ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"learn_sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
func refill()->bool:
	var q:=ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"Stamina"})
	return ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"Stamina","value":q["data"]["max"]}).get("accepted",false)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://session.save";var exists:=FileAccess.file_exists(path);var old:=PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,30)}).get("accepted",false),"map")
	var floor_tiles:Array=[]
	for x in range(40):
		for y in range(30):floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for actor in [&"hero",&"npc"]:
		check(ask(&"EntityCreateRequested",{"entity":actor}).get("accepted",false),"entity")
		check(ask(&"InventoryConfigureRequested",{"entity":actor,"volume":40}).get("accepted",false),"capacity")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"controlled")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(5,5),"size":4}).get("accepted",false),"body")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"npc","anchor":Vector2i(25,20),"size":2}).get("accepted",false),"NPC body")
	var bases:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var learning=root.get_node("DungeonChestLearningService")
	for entry in [[&"learn_sword",&"sword_simple"],[&"learn_shield",&"shield_small"],[&"npc_sword",&"sword_simple"]]:
		check(ask(&"ItemCreateRequested",{"id":entry[0],"base_id":entry[1],"item_level":1,"rarity":&"magic","learning":learning.schema_for(entry[1],bases)}).get("accepted",false),"create learning equipment")
		check(ask(&"InventoryAddRequested",{"entity":&"npc" if entry[0]==&"npc_sword" else &"hero","item":entry[0]}).get("accepted",false),"own item")
	var mod:={"id":&"pre_strength","category":"prefix","stat":"STR","tier":3,"value":1.0,"level_req":1,"material_id":&"iron_common","unlock_after":5}
	check(ask(&"ItemModAttachRequested",{"item":&"learn_sword","mod":mod}).get("accepted",false),"attach strength")
	check(ask(&"EquipmentEquipRequested",{"entity":&"npc","item":&"npc_sword","slot":"main"}).get("accepted",false),"start NPC equip")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"learn_shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10)==10,"equip shield and NPC sword")
	check(ask(&"WeaponStrikeStartRequested",{"entity":&"npc","item":&"npc_sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT}).get("accepted",false),"NPC strike")
	check(ask(&"ActionStartRequested",{"entity":&"hero","action":&"wait","duration":4.0}).get("accepted",false),"advance NPC action")
	driver.advance_steps(400)
	check(state(&"npc_sword")["progress"]==0 and not state(&"npc_sword")["identified"],"NPC strike does not identify")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"learn_sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"equip sword")
	check(state(&"learn_sword")["progress"]==0,"equip does not learn weapon")
	var shield_start:int=state(&"learn_shield")["progress"]
	var callback_data:={"events":0,"atomic":true,"blocked_save":false}
	var observe:=func(e):
		if e.get("entity",null)==&"hero" and e.get("item",null) in [&"learn_sword",&"learn_shield"]:
			callback_data["events"]+=1
			if state(&"learn_shield")["progress"]!=mini(25,shield_start+state(&"learn_sword")["progress"]):callback_data["atomic"]=false
	var save_inside:=func(e):
		if e.get("entity",null)==&"hero":callback_data["blocked_save"]=not ask(&"SessionSaveRequested",{}).get("accepted",false)
	bus.subscribe(&"ItemLearningProgressChanged",observe)
	bus.subscribe(&"WeaponStrikeFinished",save_inside)
	ask(&"WeaponStrikeFinished",{"entity":&"hero","data":{"item":&"learn_sword"}})
	check(state(&"learn_sword")["progress"]==0,"spoofed finished event ignored")
	check(refill() and strike().get("accepted",false),"start interruption case")
	check(driver.advance_steps(10)==10 and ask(&"ActionCancelRequested",{"entity":&"hero"}).get("accepted",false),"interrupt strike")
	check(state(&"learn_sword")["progress"]==0 and state(&"learn_shield")["progress"]==shield_start,"interruption learns neither")
	check(refill() and strike().get("accepted",false) and driver.advance_steps(10)==10,"start save case")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save pending strike")
	driver.advance_steps(400)
	check(state(&"learn_sword")["progress"]==1 and state(&"learn_shield")["progress"]==shield_start+1,"completed miss learns both")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and state(&"learn_sword")["progress"]==0,"restore pending strike")
	driver.advance_steps(400)
	check(state(&"learn_sword")["progress"]==1 and state(&"learn_shield")["progress"]==shield_start+1,"restored completion counts once")
	for i in range(2,26):
		check(refill() and strike().get("accepted",false),"start strike %d" % i)
		driver.advance_steps(400)
		check(state(&"learn_sword")["progress"]==i,"progress %d" % i)
		if i==4:check(ask(&"StatGetRequested",{"entity":&"hero","stat":&"STR"})["value"]==5.0,"mod hidden before 5")
		if i==5:check(ask(&"StatGetRequested",{"entity":&"hero","stat":&"STR"})["value"]==6.0,"mod takes effect at 5")
	print("callbacks ",callback_data)
	check(callback_data["atomic"] and callback_data["blocked_save"],"atomic updates and completion snapshot guard")
	check(state(&"learn_sword")["identified"] and state(&"learn_sword")["progress"]==25,"auto identify at 25")
	check(refill() and strike().get("accepted",false),"attack after identification")
	driver.advance_steps(400)
	check(state(&"learn_sword")["progress"]==25,"identified no overrun")
	bus.unsubscribe(&"ItemLearningProgressChanged",observe);bus.unsubscribe(&"WeaponStrikeFinished",save_inside)
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and state(&"learn_sword")["identified"],"identified persists")
	check(ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"remove learned sword")
	check(ask(&"ItemCreateRequested",{"id":&"other_sword","base_id":&"sword_simple","item_level":1,"learning":learning.schema_for(&"sword_simple",bases)}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":&"hero","item":&"other_sword"}).get("accepted",false),"second learning weapon")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"other_sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"equip second weapon")
	check(refill() and ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"other_sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT}).get("accepted",false),"one strike with other weapon")
	driver.advance_steps(400)
	check(state(&"other_sword")["progress"]==1 and not state(&"other_sword")["identified"],"partial learning")
	check(ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"remove partially learned weapon")
	check(ask(&"InventoryRemoveRequested",{"entity":&"hero","item":&"other_sword"}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":&"npc","item":&"other_sword"}).get("accepted",false) and state(&"other_sword")["progress"]==1,"partial progress follows weapon")
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Weapon learning progress: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
