extends SceneTree
var failures := 0
var updates: Array = []
func _initialize() -> void: call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func detail(bus, observer: StringName = &"hero", target: StringName = &"rat") -> Dictionary:
	return ask(bus, &"DetectionDetailsGetRequested", {"observer": observer, "target": target})
func set_per(bus, value: float) -> void:
	check(ask(bus, &"StatBaseSetRequested", {"entity": &"hero", "stat": &"PER", "value": value})["accepted"], "set PER " + str(value))
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"HotbarDetailsChanged", func(e): updates.append(e.duplicate(true)))
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(20,20)})["accepted"], "map")
	var floors: Array = []
	for x in range(20):
		for y in range(20): floors.append(Vector2i(x,y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})["accepted"], "floors")
	check(entities.create_entity(&"hero"), "hero")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(2,2), "size": 2})["accepted"], "hero body")
	var small_seed := -1
	for seed in range(100):
		ask(bus, &"RngSeedRequested", {"seed": seed})
		if float(ask(bus, &"RngFloatRequested", {})["value"]) < 0.8:
			small_seed = seed
			break
	ask(bus, &"RngSeedRequested", {"seed": small_seed})
	check(ask(bus, &"RatSpawnRequested", {"entity": &"rat", "anchor": Vector2i(4,2)})["accepted"], "rat")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "control")
	check(ask(bus, &"DetectionHostilitySetRequested", {"a": &"hero", "b": &"rat", "hostile": true})["accepted"], "hostility")
	set_per(bus, 4.99)
	ask(bus, &"StatBaseSetRequested", {"entity": &"rat", "stat": &"PER", "value": 0})
	check(not detail(bus)["found"], "no details before detection")
	check(ask(bus, &"ActionStartRequested", {"entity": &"rat", "action": &"wait", "duration": 1.0})["accepted"], "rat waits")
	check(ask(bus, &"ActionStartRequested", {"entity": &"hero", "action": &"wait", "duration": 5.0})["accepted"], "hero waits")
	driver.advance_steps(1)
	check(detail(bus)["found"] and ask(bus, &"HotbarDetailsGetRequested", {})["entries"].is_empty(), "one-way detection: details query allowed but not hotbar")
	ask(bus, &"StatBaseSetRequested", {"entity": &"rat", "stat": &"PER", "value": 5})
	driver.advance_steps(1)
	var low := detail(bus)
	check(low["found"] and low["data"] == {"target": &"rat"}, "below 5: only fact, no HP or action")
	var reverse := detail(bus, &"rat", &"hero")
	check(reverse["found"] and reverse["data"].has("hp") and not reverse["data"].has("action"), "details use each observer PER")
	var bar := ask(bus, &"HotbarDetailsGetRequested", {})
	check(bar["entries"] == [{"target": &"rat"}] and bar["combat_detected"], "low PER still in mutual hotbar")
	set_per(bus, 4.0)
	check(ask(bus, &"StatModifierAddRequested", {"entity": &"hero", "modifier": {"id": "per_bonus", "stat": "PER", "stage": "additive", "op": "add", "value": 1.0}})["accepted"], "PER modifier")
	check(detail(bus)["data"].has("hp"), "effective PER grants HP")
	check(ask(bus, &"StatModifierRemoveRequested", {"entity": &"hero", "id": "per_bonus"})["accepted"] and not detail(bus)["data"].has("hp"), "removing modifier hides HP")
	set_per(bus, 5.0)
	var five: Dictionary = detail(bus)["data"]
	check(five.has("hp") and five["hp"].keys().size() == 2 and not five.has("action"), "5: only HP")
	var old_hp_max: float = float(five["hp"]["max"])
	check(ask(bus, &"StatBaseSetRequested", {"entity": &"rat", "stat": &"CON", "value": 10})["accepted"], "raise rat CON")
	check(float(updates.back()["entries"][0]["hp"]["max"]) > old_hp_max, "HP maximum change updates hotbar immediately")
	check(ask(bus, &"ResourceSetRequested", {"entity": &"rat", "resource": &"HP", "value": 4})["accepted"], "change HP")
	check(float(updates.back()["entries"][0]["hp"]["current"]) == 4.0, "HP change update")
	set_per(bus, 9.99)
	check(not detail(bus)["data"].has("action"), "below 10 no action")
	set_per(bus, 10.0)
	var ten: Dictionary = detail(bus)["data"]["action"]
	check(ten["active"] and ten.has("progress") and not ten.has("name") and not ten.has("remaining_action_seconds") and not ten.has("effect_in_seconds"), "10: timer progress without name or seconds")
	driver.advance_steps(23)
	check(absf(float(detail(bus)["data"]["action"]["progress"]) - 0.25) < 0.00001, "timer progress updates")
	set_per(bus, 19.99)
	check(not detail(bus)["data"]["action"].has("name"), "below 20 no name")
	set_per(bus, 20.0)
	var twenty: Dictionary = detail(bus)["data"]["action"]
	check(twenty["name"] == "Ожидание" and not twenty.has("remaining_action_seconds") and not twenty.has("effect_in_seconds"), "20: name but not exact timing")
	set_per(bus, 29.99)
	check(not detail(bus)["data"]["action"].has("remaining_action_seconds"), "below 30 no seconds")
	set_per(bus, 30.0)
	var thirty: Dictionary = detail(bus)["data"]["action"]
	check(absf(float(thirty["remaining_action_seconds"]) - 0.75) < 0.00001 and not thirty.has("effect_in_seconds"), "30: remaining action time, do not invent effect for wait")
	check(ask(bus, &"ActionCancelRequested", {"entity": &"rat"})["accepted"], "cancel wait")
	check(not detail(bus)["data"]["action"]["active"], "idle has no timer or name")
	check(ask(bus, &"RatBiteStartRequested", {"entity": &"rat", "target": &"hero", "damage": 2, "duration": 0.5})["accepted"], "real bite")
	var bite: Dictionary = detail(bus)["data"]["action"]
	check(bite["name"] == "Укус крысы" and absf(float(bite["effect_in_seconds"]) - 0.5) < 0.00001, "30: real scheduled bite effect time")
	driver.advance_steps(20)
	check(absf(float(detail(bus)["data"]["action"]["effect_in_seconds"]) - 0.3) < 0.00001, "effect countdown progresses")
	check(ask(bus, &"SessionSaveRequested", {})["accepted"], "save mid-bite")
	driver.advance_steps(5)
	check(ask(bus, &"SessionLoadRequested", {})["accepted"], "load mid-bite")
	check(absf(float(detail(bus)["data"]["action"]["effect_in_seconds"]) - 0.3) < 0.00001, "derive detail after load")
	set_per(bus, 5)
	check(not detail(bus)["data"].has("action") and updates.back()["entries"][0].has("hp"), "PER decrease hides action immediately")
	check(ask(bus, &"DetectionHostilitySetRequested", {"a": &"hero", "b": &"rat", "hostile": false})["accepted"], "remove hostility")
	check(not detail(bus)["found"] and ask(bus, &"HotbarDetailsGetRequested", {})["entries"].is_empty(), "no hostile details when neutral")
	check(not detail(bus, &"rat", &"hero")["found"], "not hostile from other observer")
	check(ask(bus, &"DetectionHostilitySetRequested", {"a": &"hero", "b": &"rat", "hostile": true})["accepted"], "restore hostility")
	check(detail(bus)["found"], "restored hostile visible")
	check(ask(bus, &"SpaceBodyRemoveRequested", {"entity": &"rat"})["accepted"], "remove rat body")
	check(not detail(bus)["found"] and ask(bus, &"HotbarDetailsGetRequested", {})["entries"].is_empty(), "loss removes all details")
	check(not updates.is_empty() and updates.back()["entries"].is_empty(), "update clears display")
	print("Detection details tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
