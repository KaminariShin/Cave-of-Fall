extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func run()->void:
	root.get_node("TimeDriver").set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized,"game initialized")
	for pair in [["_floor_atlas",Vector2i(128,128)],["_wall_atlas",Vector2i(128,128)],["_hero_sprite",Vector2i(64,64)],["_enemy_sprite",Vector2i(64,64)],["_ogre_sprite",Vector2i(80,80)],["_rat_sprite",Vector2i(48,48)]]:
		var tex:Texture2D=game.get(pair[0])
		check(tex != null and tex.get_size()==Vector2(pair[1]),"asset "+pair[0])
		if tex != null and pair[0].ends_with("sprite"):
			var image:=tex.get_image()
			check(image.get_pixel(0,0).a<0.1,"transparent background "+pair[0])
	check(game._ui_frame != null and game._ui_frame.get_size()==Vector2(1365,768),"fragment frame loaded")
	check(game._ui_parchment != null and game._ui_slot != null,"fragment panel and button loaded")
	check(game._ui_vials.size()==3 and game._ui_vials[0] != null and game._ui_vials[1] != null and game._ui_vials[2] != null,"three resource vial textures")
	check(is_equal_approx(game._resource_vial_ratio(25,100),0.25) and game._resource_vial_ratio(0,0)==0.0 and game._resource_vial_ratio(200,100)==1.0,"resource vial ratio and zero maximum")
	check(game._ui_frame_image.get_pixel(680,380).a < 0.5 and game._ui_frame_image.get_pixel(20,100).a > 0.5,"frame aperture and opaque controls")
	check(game.FLOOR_TINTS.size()==4 and game.FLOOR_TINTS[0]!=game.FLOOR_TINTS[1] and game.FLOOR_TINTS[1]!=game.FLOOR_TINTS[2] and game.FLOOR_TINTS[2]!=game.FLOOR_TINTS[3],"four floor palettes")
	check(game._ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["size"]==4 and game._ask(&"SpaceBodyGetRequested",{"entity":game.RAT})["data"]["size"]==2,"graphics do not resize bodies")
	game.queue_free();await process_frame
	print("Game demo graphics assets: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
