extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func plan(stamina: Variant, hits: Array) -> Dictionary:
	return ask(&"SimultaneousBlockPlanRequested", {"available_stamina":stamina,"hits":hits})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"defender"}).get("accepted",false), "entity")
	var rng = root.get_node("RngService")._rng
	var original: Dictionary = saver.collect_world_transition_snapshot()
	var pair := [{"id":&"small","damage":5},{"id":&"large","damage":7}]
	var q := plan(4,pair)
	check(q.get("accepted",false), "partial")
	if q.get("accepted",false):
		var d: Dictionary = q["data"]
		check(d["absorbed"] == 8 and d["stamina_cost"] == 4 and d["block_interrupted"] and d["hits"] == [{"id":&"large","damage":7,"blocked":4,"passed":3},{"id":&"small","damage":5,"blocked":4,"passed":1}], "proportions then remainder to smaller")
		pair.reverse()
		check(plan(4,pair)["data"] == d, "same plan for reverse order")
	var snap: Dictionary = saver.collect_world_transition_snapshot()
	check(original["payload"]["sections"]["resources"] == snap["payload"]["sections"]["resources"] and original["payload"]["sections"]["rng"] == snap["payload"]["sections"]["rng"], "no resource or RNG change without tie")
	q = plan(6,pair)
	check(q.get("accepted",false) and q["data"]["absorbed"] == 12 and q["data"]["stamina_cost"] == 6 and not q["data"]["block_interrupted"], "exact stamina keeps block")
	q = plan(7,[{"id":&"odd","damage":11}])
	check(q.get("accepted",false) and q["data"]["stamina_cost"] == 6 and not q["data"]["block_interrupted"], "half stamina cost rounds up")
	q = plan(0,[{"id":&"hit","damage":5}])
	check(q.get("accepted",false) and q["data"]["absorbed"] == 0 and q["data"]["stamina_cost"] == 0 and q["data"]["block_interrupted"], "zero stamina interrupts")
	q = plan(0,[{"id":&"none","damage":0}])
	check(q.get("accepted",false) and not q["data"]["block_interrupted"], "zero incoming does not interrupt")
	check(plan(0,[]).get("accepted",false), "empty")
	var tied := [{"id":&"a","damage":3},{"id":&"b","damage":3},{"id":&"c","damage":3}]
	ask(&"RngSeedRequested", {"seed":1234})
	var state: int = rng.state
	q = plan(1,tied)
	var final_state: int = rng.state
	check(q.get("accepted",false) and q["data"]["absorbed"] == 2 and final_state != state, "tie consumes RNG")
	rng.state = state
	tied.reverse()
	var replay := plan(1,tied)
	check(replay.get("accepted",false) and replay["data"] == q["data"] and rng.state == final_state, "tie reproducible and independent of incoming order")
	var invalid := [plan(0.5,[]),plan(-1,[]),plan(1,[{"id":&"x","damage":1.5}]),plan(1,[{"id":&"x","damage":-1}]),plan(1,[{"id":&"x","damage":1},{"id":&"x","damage":1}]),plan(1,[{"id":"x","damage":1}]),plan(1,[{"id":&"x","damage":1000000000},{"id":&"y","damage":1}])]
	for entry in invalid: check(not entry.get("accepted",true), "invalid rejected")
	q = plan(499999999,[{"id":&"x","damage":999999999},{"id":&"y","damage":1}])
	check(q.get("accepted",false) and q["data"]["absorbed"] == 999999998 and q["data"]["hits"][0]["blocked"] == 999999997 and q["data"]["hits"][1]["blocked"] == 1, "large integer division exact and remainder to smaller")
	print("Simultaneous block plan tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
