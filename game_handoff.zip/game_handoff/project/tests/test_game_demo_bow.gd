extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func key(game:Node,k:Key)->void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func click(game:Control,p:Vector2)->void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*p;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;game._input(e)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame;game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":50}).get("accepted",false),"capacity")
	check(ask(&"ItemCreateRequested",{"id":&"demo_bow_test","base_id":&"bow_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"demo_bow_test"}).get("accepted",false),"bow in inventory")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"inventory open")
	check(game._use_inventory_item(game._inventory_items().find(&"demo_bow_test")) and game._twohand_queue.get("item",null)==&"demo_sword","start swap")
	check(driver.advance_steps(10)==10 and game._twohand_continue() and driver.advance_steps(10)==10,"equip bow via sequence")
	var gear:Dictionary=ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"})["data"]
	check(gear.get("main",null)==&"demo_bow_test" and gear.get("off",null)==null,"two-handed equipped")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close inventory")
	var floors:Array=[]
	for x in range(56,90):
		for y in range(56,68):floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"open test corridor")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":Vector2i(60,60)}).get("accepted",false),"position hero")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.RAT,"anchor":Vector2i(75,61)}).get("accepted",false),"position target")
	var hp:float=ask(&"ResourceGetRequested",{"entity":game.RAT,"resource":&"HP"})["data"]["current"]
	var center:Vector2=game._map_origin()+game._camera_center_world()*game.STEP_PX
	var point:=center+Vector2(120,0)
	key(game,KEY_SPACE)
	var preview:Dictionary=game._direction_preview(point)
	check(preview.get("kind","")=="attack" and not preview.get("tiles",[]).is_empty(),"bow aim preview")
	click(game,point)
	check(game.pending_attack and game.attack_tiles==preview.get("tiles",[]) and ask(&"BowShotStatusRequested",{"entity":game.HERO}).get("active",false),"mouse starts bow action")
	var p:Dictionary=ask(&"BowShotStatusRequested",{"entity":game.HERO})["data"]
	var midpoint:int=ceili(float(p["duration_steps"])/2.0)
	check(driver.advance_steps(midpoint-1)==midpoint-1 and game._strike_before_hit(game.HERO),"pre-release indicator")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save in draw")
	check(driver.advance_steps(1)==1 and not game._strike_before_hit(game.HERO),"release on midpoint")
	check(ask(&"ProjectilesGetRequested",{}).get("projectiles",{}).size()==1,"arrow in flight")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and game.pending_attack and ask(&"BowShotStatusRequested",{"entity":game.HERO}).get("active",false),"restore bow action")
	check(driver.advance_steps(int(p["duration_steps"])-midpoint+1)>0,"finish restored shot")
	check(not game.pending_attack,"recovery clears visual action")
	check(driver.wait_for(1.0),"wait for flight")
	driver.advance_steps(100)
	check(ask(&"ResourceGetRequested",{"entity":game.RAT,"resource":&"HP"})["data"]["current"]<hp,"arrow damages target")
	check(ask(&"ResourceSetRequested",{"entity":game.HERO,"resource":&"Stamina","value":10}).get("accepted",false),"restore stamina")
	key(game,KEY_SPACE);key(game,KEY_RIGHT)
	check(game.pending_attack and ask(&"BowShotStatusRequested",{"entity":game.HERO}).get("active",false),"keyboard direction starts shot")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO,"reason":&"test"}).get("accepted",false) and not game.pending_attack,"interrupt clears bow UI")
	game.queue_free();await process_frame
	print("Game demo bow: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
