extends SceneTree
var failures := 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(entities.create_entity(&"hero"), "entity")
	var add := {"entity": &"hero", "modifier": {"id": "source", "target": "stat.CON", "stage": "additive", "op": "add", "value": 5}}
	check(ask(bus, &"PipelineModifierRegisterRequested", add)["accepted"], "register common modifier")
	check(ask(bus, &"StatGetRequested", {"entity": &"hero", "stat": &"CON"})["value"] == 10.0, "stats use pipeline")
	check(ask(bus, &"ResourceGetRequested", {"entity": &"hero", "resource": &"HP"})["data"]["max"] == 70.0, "resource updates")
	check(ask(bus, &"PipelineModifierRemoveRequested", {"entity": &"hero", "id": "source"})["accepted"], "remove modifier")
	var evaluate := {"entity": &"hero", "target": "test", "base": 3.0, "modifiers": [{"stage": "additive", "op": "add", "value": 2}, {"stage": "multiplicative", "op": "multiply", "value": 2}, {"stage": "threshold", "op": "add", "value": 3, "threshold": 10}, {"stage": "final", "op": "clamp_max", "value": 12}]}
	ask(bus, &"PipelineEvaluateRequested", evaluate)
	check(evaluate["accepted"] and evaluate["value"] == 12.0, "ordered stages")
	check(ask(bus, &"PipelineModifierRegisterRequested", {"entity": &"hero", "modifier": {"id": "percent", "target": "action.duration", "stage": "threshold", "op": "percent_add", "value": 0.2}})["accepted"], "percent modifier")
	var combined := {"entity": &"hero", "target": "action.duration", "base": 1.0, "apply_weight": true}
	ask(bus, &"PipelineEvaluateRequested", combined)
	check(combined["accepted"] and is_equal_approx(combined["value"], 1.2), "percentage contribution")
	ask(bus, &"PipelineModifierRemoveRequested", {"entity": &"hero", "id": "percent"})
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(12, 12)})["accepted"], "map")
	var floors: Array = []
	for x in range(12):
		for y in range(12): floors.append(Vector2i(x, y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})["accepted"], "floors")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(2, 2), "size": 2})["accepted"], "place")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "controlled")
	check(ask(bus, &"MovementConfigureRequested", {"entity": &"hero", "actor_type": "player"})["accepted"], "ruleset default K_move")
	check(ask(bus, &"MovementConfigureRequested", {"entity": &"hero", "actor_type": "player", "K_move": 10})["accepted"], "configure")
	check(ask(bus, &"MovementStepRequested", {"entity": &"hero", "delta": Vector2i.RIGHT})["accepted"], "step")
	driver.advance_steps(7)
	var position := ask(bus, &"MovementPositionGetRequested", {"entity": &"hero"})
	check(position["moving"] and is_equal_approx(position["position"].x, 2.0 + 7.0 / 15.0), "linear interpolation")
	check(ask(bus, &"SpaceBodyGetRequested", {"entity": &"hero"})["data"]["anchor"] == Vector2i(2, 2), "logical occupancy stays until completion")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save mid-step")
	driver.advance_steps(8)
	check(ask(bus, &"SpaceBodyGetRequested", {"entity": &"hero"})["data"]["anchor"] == Vector2i(3, 2), "step completion moves body")
	check(is_equal_approx(driver.game_time, 0.15), "step advances time")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load mid-step")
	check(ask(bus, &"MovementPositionGetRequested", {"entity": &"hero"})["moving"], "segment restored")
	driver.advance_steps(8)
	check(ask(bus, &"SpaceBodyGetRequested", {"entity": &"hero"})["data"]["anchor"] == Vector2i(3, 2), "restored step finishes")
	check(ask(bus, &"MovementStepRequested", {"entity": &"hero", "delta": Vector2i.DOWN})["accepted"], "second step")
	driver.advance_steps(3)
	check(ask(bus, &"ActionInterruptRequested", {"entity": &"hero", "action": &"stagger"})["accepted"], "interrupt movement")
	check(not ask(bus, &"MovementPositionGetRequested", {"entity": &"hero"})["moving"], "interrupted segment cleared")
	driver.advance_steps(20)
	check(ask(bus, &"SpaceBodyGetRequested", {"entity": &"hero"})["data"]["anchor"] == Vector2i(3, 2), "interrupted body remains")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(5, 2)], "kind": 0})["accepted"], "obstacle")
	var path := ask(bus, &"MovementPathFindRequested", {"entity": &"hero", "target": Vector2i(4, 3)})
	check(path["found"] and not path["path"].is_empty() and path["path"][0] != Vector2i(4, 3), "no diagonal corner cutting")
	var aim := ask(bus, &"MovementAimAnchorRequested", {"entity": &"hero", "point": Vector2(8, 8)})
	check(aim["found"] and aim["anchor"] == Vector2i(7, 7), "aim anchor")
	check(ask(bus, &"MovementPathStartRequested", {"entity": &"hero", "target": Vector2i(4, 3)})["accepted"], "path starts")
	driver.advance_steps(15)
	await process_frame
	driver.advance_steps(15)
	await process_frame
	check(ask(bus, &"SpaceBodyGetRequested", {"entity": &"hero"})["data"]["anchor"] == Vector2i(4, 3), "path executes all segments")
	print("Pipeline and movement tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
