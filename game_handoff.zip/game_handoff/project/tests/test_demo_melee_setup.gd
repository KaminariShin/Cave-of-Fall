extends SceneTree
const TEST_PLAYER_LEVEL := 3
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func player_stats_for_level(level: int) -> Dictionary:
	var stats := {"CON":5, "STR":5, "PER":30}
	for _level in range(1, level):
		stats["CON"] += 1
		stats["STR"] += 1
	return stats
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(100,100)}).get("accepted",false),"map")
	check(ask(&"RoomCreateRequested",{"id":&"r","type":"start","origin_cell":Vector2i(2,2),"size_cells":Vector2i(11,11)}).get("accepted",false),"room")
	var player_stats := player_stats_for_level(TEST_PLAYER_LEVEL)
	check(ask(&"EntityCreateRequested",{"entity":&"hero","components":{&"stats":player_stats}}).get("accepted",false),"levelled player")
	check(ask(&"StatGetRequested",{"entity":&"hero","stat":&"CON"}).get("value",0) == 7.0 and ask(&"StatGetRequested",{"entity":&"hero","stat":&"STR"}).get("value",0) == 7.0,"player level 3 applies +1 CON/+1 STR per level after level 1")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(28,28),"size":4}).get("accepted",false),"body")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"controlled")
	check(ask(&"RoomEnterRequested",{"entity":&"hero","room":&"r"}).get("accepted",false),"enter")
	ask(&"RngSeedRequested",{"seed":25})
	var injected := {"done":false}
	var fail_once := func(e):
		if not injected["done"] and str(e.get("id","")).begins_with("demo_sword:"):
			injected["done"] = true
			e["accepted"] = false
	root.get_node("EventBus").subscribe(&"ItemCreateRequested",fail_once)
	var spawn := ask(&"RoomSpawnRequested",{"room":&"r","player":&"hero","entry_tile":Vector2i(28,28),"depth":6,"demo_pool":true,"demo_melee":true,"queue_delay":0.05})
	check(spawn.get("accepted",false) and spawn.get("level",0) == 3 and not spawn.get("units",[]).is_empty(),"level-3 spawn " + str(spawn))
	await process_frame
	await process_frame
	root.get_node("EventBus").unsubscribe(&"ItemCreateRequested",fail_once)
	var failed_id: StringName = spawn["units"][0]["entity"]
	check(ask(&"DemoMeleeSetupStatusRequested",{"entity":failed_id})["status"] == "failed","failure reported")
	check(not ask(&"CombatDamageRequested",{"entity":failed_id,"amount":1}).get("accepted",false),"pending enemy protected")
	var failed_actor: Dictionary = root.get_node("EntityRegistry").get_entity(failed_id)
	check(not failed_actor.has(&"equipment") or failed_actor[&"equipment"].is_empty(),"equipment rolled back")
	check(not ask(&"AIGetRequested",{"entity":failed_id}).get("found",false),"AI rolled back")
	check(ask(&"DemoMeleeSetupRetryRequested",{"entity":failed_id}).get("accepted",false),"retry succeeds")
	for unit in spawn.get("units",[]):
		var id: StringName = unit["entity"]
		var status := ask(&"DemoMeleeSetupStatusRequested",{"entity":id})
		check(status["status"] == "installed","installed " + str(status))
		var hp: Dictionary = ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"})
		check(hp.get("found",false) and hp["data"]["current"] == 39.0 and hp["data"]["max"] == 39.0,"level-3 goblin-profile enemy keeps its original HP growth")
		var gear: Dictionary = ask(&"ComponentGetRequested",{"entity":id,"component":&"equipment"}).get("data",{})
		var main_item: Dictionary = ask(&"ItemGetRequested",{"item":gear.get("main",null)}).get("item_data",{})
		var off_item: Dictionary = ask(&"ItemGetRequested",{"item":gear.get("off",null)}).get("item_data",{})
		check(main_item.get("base_id",null) == &"sword_simple" and off_item.get("base_id",null) in [&"shield_small",&"shield_medium",&"shield_large"],"seeded goblin loadout is sword + shield")
		var ai := ask(&"AIGetRequested",{"entity":id})
		check(ai.get("found",false) and ai.get("data",{}).get("role","") == "melee","common AI")
		var weapon: Dictionary = ai.get("data",{}).get("weapon",{})
		check(weapon.get("strike","")=="demo_creature_thrust","actual spawned mob uses shortened strike")
		var preview := ask(&"WeaponStrikePreviewRequested",{"entity":id,"item":weapon.get("item",null),"strike":weapon.get("strike",""),"kind":"physical","direction":Vector2.RIGHT})
		check(preview.get("accepted",false) and preview.get("strike_data",{}).get("range",-1)==3,"actual spawned mob has range 3")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load")
	await process_frame
	for unit in spawn.get("units",[]): check(ask(&"DemoMeleeSetupStatusRequested",{"entity":unit["entity"]})["status"] == "installed","restored")
	var fighter: StringName = spawn["units"][0]["entity"]
	var moved := false
	for anchor in [Vector2i(25,28),Vector2i(32,28),Vector2i(28,25),Vector2i(28,32),Vector2i(24,28),Vector2i(33,28)]:
		if ask(&"SpaceBodyMoveRequested",{"entity":fighter,"anchor":anchor}).get("accepted",false): moved = true; break
	check(moved,"move fighter near hero")
	var before: float = ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"HP"})["data"]["current"]
	check(driver.wait_for(4.0) and driver.advance_steps(300) == 300,"advance combat")
	var after: float = ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"HP"})["data"]["current"]
	check(after < before,"demo enemy causes damage: " + str([before,after]))
	print("Demo melee setup: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
