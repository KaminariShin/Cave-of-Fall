extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func valid(actor:StringName,tile:Vector2i)->bool:
	var result:=ask(&"LootDropTileCheckRequested",{"entity":actor,"tile":tile})
	return result.get("accepted",false) and result.get("valid",false)
func run()->void:
	bus=root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,40)}).get("accepted",false),"map")
	var floor_tiles:Array=[]
	for y in range(40):
		for x in range(40):floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested",{"entity":&"other"}).get("accepted",false),"entities")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested",{"entity":&"other","anchor":Vector2i(17,12),"size":2}).get("accepted",false),"bodies")
	var before:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()
	check(valid(&"hero",Vector2i(19,12)) and not valid(&"hero",Vector2i(20,12)),"center distance within or outside eight")
	check(valid(&"hero",Vector2i(10,10)) and valid(&"hero",Vector2i(17,12)),"body occupied cells permitted")
	check(not valid(&"hero",Vector2i(-1,12)) and not ask(&"LootDropTileCheckRequested",{"entity":&"missing","tile":Vector2i(12,12)}).get("accepted",true),"invalid actor/out of bounds")
	var direct:=ask(&"LootDropTileResolveRequested",{"entity":&"hero","tile":Vector2i(19,12)})
	check(direct.get("accepted",false) and direct.get("found",false) and direct.get("resolved_tile",null)==Vector2i(19,12),"valid chosen tile unchanged")
	check(before["payload"]["sections"]==root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"],"queries do not mutate world or RNG")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[Vector2i(14,12)],"kind":0}).get("accepted",false),"new wall")
	check(not valid(&"hero",Vector2i(14,12)) and not valid(&"hero",Vector2i(19,12)),"floor and line of sight required")
	var resolved:=ask(&"LootDropTileResolveRequested",{"entity":&"hero","tile":Vector2i(14,12)})
	check(resolved.get("accepted",false) and resolved.get("found",false) and resolved.get("resolved_tile",null)==Vector2i(14,11),"nearest valid fallback and deterministic tie")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[Vector2i(14,12)],"kind":1}).get("accepted",false),"clear wall")
	check(ask(&"EntityCreateRequested",{"entity":&"odd"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested",{"entity":&"odd","anchor":Vector2i(25,25),"size":2}).get("accepted",false),"small body")
	check(valid(&"odd",Vector2i(33,26)) and not valid(&"odd",Vector2i(34,26)),"small-body radius by center")
	var deny:=func(e):e["visible"]=false
	bus.subscribe(&"SpaceLineOfSightRequested",deny)
	var none:=ask(&"LootDropTileResolveRequested",{"entity":&"hero","tile":Vector2i(14,12)})
	bus.unsubscribe(&"SpaceLineOfSightRequested",deny)
	check(none.get("accepted",false) and not none.get("found",true) and not none.has("resolved_tile"),"no valid position reported without invention")
	check(not ask(&"LootDropTileResolveRequested",{"entity":&"hero","tile":"bad"}).get("accepted",true),"malformed input")
	print("Loot drop tile preflight: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
