extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, text: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", text)
func ask(name: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(name, data)
	return data
func set_gear(entity: StringName, gear: Dictionary) -> Dictionary:
	return ask(&"ComponentSetRequested", {"entity":entity, "component":&"equipment", "data":gear})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	for id in [&"hero", &"enemy"]:
		check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted", false), "create entity")
		check(ask(&"InventoryConfigureRequested", {"entity":id, "volume":20}).get("accepted", false), "inventory")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	for id in [&"one", &"two"]:
		check(ask(&"ItemCreateRequested", {"id":id, "base_id":&"sword_simple", "item_level":1}).get("accepted", false), "item")
	check(ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"one"}).get("accepted", false), "give hero")
	check(not set_gear(&"enemy", {"main":&"one"}).get("accepted", false), "cannot equip item held by another entity")
	check(not set_gear(&"hero", {"main":&"one"}).get("accepted", false), "cannot duplicate inventory item as equipment")
	check(not ask(&"EntityCreateRequested", {"entity":&"clone", "components":{&"equipment":{"main":&"one"}}}).get("accepted", false), "creation cannot duplicate held item")
	check(not set_gear(&"enemy", {"main":&"two", "off":&"two"}).get("accepted", false), "same item cannot occupy multiple slots")
	check(set_gear(&"enemy", {"main":&"two"}).get("accepted", false), "unowned item may be assigned to equipment")
	check(not ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"two"}).get("accepted", false), "equipped item cannot enter other inventory")
	var direct := {"entity":&"hero", "data":{"items":[&"one", &"two"], "volume":20.0, "volume_modifiers":[]}}
	check(not ask(&"InventoryCommitRequested", direct).get("accepted", false), "internal inventory commit also checks equipment")
	# Повторная попытка изменить владельца во время проверки блокируется.
	var reentry := {"attempted":false, "accepted":true}
	var attack := func(_e):
		if reentry["attempted"]: return
		reentry["attempted"] = true
		reentry["accepted"] = set_gear(&"enemy", {"main":&"one"}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"LootGetRequested", attack)
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":21}).get("accepted", false), "normal change with reentrant listener")
	root.get_node("EventBus").unsubscribe(&"LootGetRequested", attack)
	check(reentry["attempted"] and not reentry["accepted"], "reentrant mutation blocked")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "valid ownership saves")
	var snap := {"sections":{}, "errors":[]}
	ask(&"SnapshotCollectRequested", snap)
	var broken: Dictionary = snap["sections"].duplicate(true)
	broken["entities"][&"enemy"][&"inventory"]["items"].append(&"one")
	check(not ask(&"ItemOwnershipSnapshotValidateRequested", {"sections":broken}).get("valid", true), "duplicate across inventories rejected")
	var file := FileAccess.open("user://session.save", FileAccess.READ)
	var original: PackedByteArray = file.get_buffer(file.get_length())
	file.close()
	var payload: Dictionary = bytes_to_var(original)
	payload["sections"]["entities"][&"enemy"][&"inventory"]["items"].append(&"one")
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(payload))
	file.close()
	check(not ask(&"SessionLoadRequested", {}).get("accepted", false), "corrupt duplicate save is rejected")
	check(ask(&"InventoryGetRequested", {"entity":&"hero"})["data"]["items"].has(&"one"), "rejected load leaves live inventory unchanged")
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(original)
	file.close()
	check(ask(&"SessionLoadRequested", {}).get("accepted", false), "valid save still loads")
	broken = snap["sections"].duplicate(true)
	broken["entities"][&"hero"][&"equipment"] = {"main":&"one"}
	check(not ask(&"ItemOwnershipSnapshotValidateRequested", {"sections":broken}).get("valid", true), "inventory plus equipped rejected")
	broken = snap["sections"].duplicate(true)
	broken["entities"][&"enemy"][&"equipment"] = {"main":&"missing"}
	check(not ask(&"ItemOwnershipSnapshotValidateRequested", {"sections":broken}).get("valid", true), "missing item rejected")
	broken = snap["sections"].duplicate(true)
	broken["loot"]["ground"][&"one"] = {"tile":Vector2i.ZERO, "source":&"enemy"}
	check(not ask(&"ItemOwnershipSnapshotValidateRequested", {"sections":broken}).get("valid", true), "ground and inventory ownership rejected")
	broken["loot"]["ground"][&"one"] = 5
	check(not ask(&"ItemOwnershipSnapshotValidateRequested", {"sections":broken}).get("valid", true), "malformed ground entry rejected safely")
	print("Item ownership tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
