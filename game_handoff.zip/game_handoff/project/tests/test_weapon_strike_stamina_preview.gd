extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func preview(strike: String = "sword_simple_thrust") -> Dictionary:
	return ask(&"WeaponStrikeStaminaPreviewRequested", {"entity":&"hero", "item":&"sword", "strike":strike})
func set_stamina(n: float) -> void:
	check(ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"Stamina", "value":n}).get("accepted",false), "set stamina")
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(root.get_node("EntityRegistry").create_entity(&"hero", {&"stats":{"CON":10,"STR":10,"DEX":5,"INT":5,"WIS":5,"PER":5}}), "hero")
	check(ask(&"ItemCreateRequested", {"id":&"sword", "base_id":&"sword_simple", "item_level":1}).get("accepted",false), "sword")
	var driver = root.get_node("TimeDriver")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"HP","value":60}).get("accepted",false), "lower HP")
	check(driver.wait_for(0.49), "start time for reserve")
	driver.advance_steps(49)
	set_stamina(0.2)
	check(driver.wait_for(0.01), "advance to reserve")
	driver.advance_steps(1)
	var hp := ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})
	check(float(hp["data"]["reserve"]) > 0, "HP reserve active")
	set_stamina(4.0)
	var protected := preview()
	check(protected.get("accepted",false) and protected["data"]["available"] == 4.0 and protected["data"]["spend"] == 4.0, "reserve not subtracted twice")
	check(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["reserve"] == hp["data"]["reserve"], "preview preserves reserve")
	var st := ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})
	check(st.get("found",false) and st["data"]["max"] >= 10, "resources")
	for row in [[7.0,1.0,1.0,0.84], [6.0,0.75,1.25,1.05], [5.25,0.75,1.25,1.05], [5.0,0.5,1.5,1.25], [1.75,0.5,1.5,1.25], [1.5,0.25,2.0,1.67], [1.0,0.25,2.0,1.67]]:
		set_stamina(row[0])
		var q := preview()
		check(q.get("accepted",false), "preview available " + str(row[0]))
		if q.get("accepted",false):
			var d: Dictionary = q["data"]
			check(d["full_cost"] == 7 and d["can_start"] and is_equal_approx(d["spend"],row[0]) and d["damage_multiplier"] == row[1] and d["duration_multiplier"] == row[2] and is_equal_approx(d["duration"],row[3]), "threshold and final rounding " + str(row[0]))
		check(is_equal_approx(float(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]["current"]),row[0]), "preview does not spend")
	set_stamina(0.99)
	var blocked := preview()
	check(blocked.get("accepted",false) and not blocked["data"]["can_start"] and blocked["data"]["spend"] == 0, "less than one cannot start")
	set_stamina(10)
	var slash := preview("sword_simple_horizontal")
	check(slash.get("accepted",false) and slash["data"]["full_cost"] == 9 and slash["data"]["spend"] == 9, "chopping 7 times 1.2 rounds up")
	var bus = root.get_node("EventBus")
	var overweight := func(e):
		if e.get("entity",null) == &"hero": e["found"] = true; e["modifiers"] = {"stamina_cost_add":0.5,"action_duration_add":0.0}
	bus.subscribe(&"WeightModifiersRequested",overweight)
	var weighted := preview()
	check(weighted.get("accepted",false) and weighted["data"]["full_cost"] == 10 and is_equal_approx(weighted["data"]["raw_cost"],9.45), "weight multiplier before rounding")
	bus.unsubscribe(&"WeightModifiersRequested",overweight)
	check(not preview("unknown").get("accepted",true), "unknown strike")
	check(not ask(&"WeaponStrikeStaminaPreviewRequested", {"entity":&"hero","item":&"missing","strike":"sword_simple_thrust"}).get("accepted",true), "unknown item")
	check(not ask(&"ActionGetRequested", {"entity":&"hero"}).get("found",false), "preview did not start action")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and preview().get("accepted",false), "save and restore")
	print("Weapon strike stamina preview tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
