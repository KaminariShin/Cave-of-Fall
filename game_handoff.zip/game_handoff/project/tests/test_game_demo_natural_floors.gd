extends SceneTree
var bus: Node
var game: Node
var driver: Node
var failures := 0
var run_seed := 42
const MAX_GENERATION_ATTEMPTS := 130
func check(v: bool,label: String) -> void:
	if not v: failures+=1; printerr("FAIL [seed %d]: %s" % [run_seed,label])
func _initialize() -> void: call_deferred("run")
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func exit_anchor(exit: Dictionary) -> Vector2i:
	var anchor := Vector2i(int(exit["x"]),int(exit["y"]))
	match str(exit.get("dirOut","")):
		"west": anchor.x += 1
		"east": anchor.x -= 4
		"north": anchor.y += 1
		"south": anchor.y -= 4
		_: return Vector2i(-1,-1)
	return anchor
func room_entry_anchor(room: Dictionary) -> Vector2i:
	for exit in room.get("exits",[]):
		if exit is Dictionary and exit.get("id",null)==&"entry": return exit_anchor(exit)
	return Vector2i(-1,-1)
func reachable_adjacent_anchor(tile: Vector2i,start: Vector2i,bounds: Dictionary) -> Vector2i:
	if not ask(&"SpaceBodyFitsRequested",{"anchor":start,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false): return Vector2i(-1,-1)
	var queue: Array=[start]
	var visited: Dictionary={start:true}
	var index:=0
	while index<queue.size():
		var anchor: Vector2i=queue[index]
		index+=1
		var adjacent := ((tile.x==anchor.x-1 or tile.x==anchor.x+4) and tile.y>=anchor.y and tile.y<anchor.y+4) or ((tile.y==anchor.y-1 or tile.y==anchor.y+4) and tile.x>=anchor.x and tile.x<anchor.x+4)
		if adjacent: return anchor
		for delta in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var next: Vector2i=anchor+delta
			if not visited.has(next) and ask(&"SpaceBodyFitsRequested",{"anchor":next,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false):
				visited[next]=true
				queue.append(next)
	return Vector2i(-1,-1)
func room_bounds(room: Dictionary) -> Dictionary:
	return {"origin":room["origin_cell"]*4,"size":room["size_cells"]*4}
func first_fitting_anchor(bounds: Dictionary) -> Vector2i:
	var origin: Vector2i = bounds["origin"]
	var size: Vector2i = bounds["size"]
	for y in range(origin.y,origin.y+size.y-3):
		for x in range(origin.x,origin.x+size.x-3):
			var anchor := Vector2i(x,y)
			if ask(&"SpaceBodyFitsRequested",{"anchor":anchor,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false): return anchor
	return Vector2i(-1,-1)
func run() -> void:
	var arguments := OS.get_cmdline_user_args()
	if arguments.size() > 1 or (not arguments.is_empty() and not arguments[0].is_valid_int()):
		printerr("FAIL: expected at most one integer seed argument")
		quit(2)
		return
	if not arguments.is_empty(): run_seed = arguments[0].to_int()
	bus=root.get_node("EventBus")
	var generation_failures: Array=[]
	var generation_failure_observer:=func(event): generation_failures.append(event.duplicate(true))
	bus.subscribe(&"RoomGenerationFailed",generation_failure_observer)
	driver=root.get_node("TimeDriver")
	driver.set_process(false)
	game=load("res://game_demo.tscn").instantiate()
	game.generation_seed = run_seed
	root.add_child(game)
	await process_frame
	var level:=ask(&"LevelMapGetRequested",{})
	check(game.initialized and level.get("found",false) and level.get("map_data",{}).get("seed",null)==run_seed,"demo starts with the requested reproducible seed")
	for floor_no in range(1,5):
		var stack: Array=[game.ROOM]
		var count:=0
		var made_count:=0
		var rejected_count:=0
		var last_generation_error: String=""
		var got: Dictionary={}
		while not stack.is_empty() and count < MAX_GENERATION_ATTEMPTS:
			var room: StringName=stack.pop_back()
			var data: Dictionary=ask(&"RoomGetRequested",{"id":room})["data"]
			for ex in data["exits"]:
				if ex["connected"] or ex["sealed"]: continue
				if count>=MAX_GENERATION_ATTEMPTS: break
				count+=1
				var made:=ask(&"RoomChildGenerateRequested",{"room":room,"exit":ex["id"]})
				if made.get("accepted",false):
					made_count+=1
					stack.append(made["child"])
				else:
					rejected_count+=1
					last_generation_error=str(made.get("error",""))
				if floor_no < 4:
					var st:=ask(&"DungeonStairGetRequested",{})
					if st.get("found",false) and st["data"]["status"]=="placed": got=st["data"]
				else:
					var track:=ask(&"DungeonFloorTrackingGetRequested",{})
					if track["data"].get("boss_candidate",null)!=null: got=track["data"]
				if not got.is_empty(): break
			if not got.is_empty(): break
		check(not got.is_empty(),"natural generation reaches target on floor %d within search budget" % floor_no)
		if got.is_empty():
			var room_state:=ask(&"RoomAllGetRequested",{})
			var rooms: Dictionary=room_state.get("rooms",{})
			var open_exits:=0
			var deepest_room_depth:=0
			var eligible_parents: Array=[]
			var open_details: Array=[]
			for room_id in rooms:
				var room_data: Dictionary=rooms[room_id]
				var cursor: StringName=room_id
				var depth:=0
				var seen: Dictionary={}
				while cursor!=game.ROOM and rooms.has(cursor) and not seen.has(cursor):
					seen[cursor]=true
					var parent=rooms[cursor].get("parent",&"")
					if not parent is StringName or parent==&"": break
					cursor=parent
					depth+=1
				if cursor!=game.ROOM: depth=-1
				else:
					deepest_room_depth=maxi(deepest_room_depth,depth)
					if depth>=5 and str(room_data.get("type","")) in ["fork","crossroads"]: eligible_parents.append(room_id)
				var exits_left: Array=[]
				for exit in room_data.get("exits",[]):
					if not exit.get("connected",false) and not exit.get("sealed",false):
						open_exits+=1
						exits_left.append(exit.get("id",&""))
				if not exits_left.is_empty(): open_details.append({"room":room_id,"type":room_data.get("type",""),"depth":depth,"origin":room_data.get("origin_cell",null),"size":room_data.get("size_cells",null),"exits":exits_left})
			var tracking:=ask(&"DungeonFloorTrackingGetRequested",{})
			var stair_state:=ask(&"DungeonStairGetRequested",{})
			var generation_state:=ask(&"RoomGenerationStatusGetRequested",{})
			printerr("SEED_AUDIT_DIAG seed=%d floor=%d requests=%d accepted=%d rejected=%d rooms=%d stack=%d open_exits=%d deepest=%d eligible_parents=%s tracking=%s stairs=%s generation=%s open_details=%s build_failures=%s last_error=%s" % [run_seed,floor_no,count,made_count,rejected_count,rooms.size(),stack.size(),open_exits,deepest_room_depth,str(eligible_parents),str(tracking),str(stair_state),str(generation_state),str(open_details),str(generation_failures),last_generation_error])
			quit(1)
			return
		if floor_no==4:
			var boss_room: StringName=got["boss_candidate"]
			var boss_room_data: Dictionary=ask(&"RoomGetRequested",{"id":boss_room})["data"]
			var branch: Dictionary={}
			for ex in boss_room_data["exits"]:
				if not ex["connected"] and not ex["sealed"]:
					branch=ask(&"RoomChildGenerateRequested",{"room":boss_room,"exit":ex["id"]})
					if branch.get("accepted",false): break
			var portal:=ask(&"DungeonPortalGetRequested",{})
			var portal_data: Dictionary=portal.get("data",{})
			check(branch.get("accepted",false) and portal.get("found",false) and portal_data.get("status","")=="placed","natural boss branch gets portal: " + str(branch) + " " + str(portal))
			if portal_data.get("status","")=="placed":
				var portal_object:=ask(&"ObjectGetRequested",{"object":portal_data.get("object",&"")})
				check(portal_object.get("found",false) and portal_object.get("data",{}).get("room",null)==portal_data.get("room",null),"portal object exists in the generated room")
				if portal_object.get("found",false):
					var portal_room: StringName=portal_data["room"]
					var portal_room_data: Dictionary=ask(&"RoomGetRequested",{"id":portal_room})["data"]
					var portal_bounds:=room_bounds(portal_room_data)
					var portal_entry:=room_entry_anchor(portal_room_data)
					var portal_anchor:=reachable_adjacent_anchor(portal_object["data"]["tile"],portal_entry,portal_bounds)
					check(portal_anchor.x>=0,"4x4 route reaches the portal from its room entrance")
			# Entering the generated candidate room triggers the real automatic boss spawn.
			var boss_bounds:=room_bounds(boss_room_data)
			var boss_anchor:=first_fitting_anchor(boss_bounds)
			check(boss_anchor.x>=0,"boss room has a 4x4 entry position")
			if boss_anchor.x>=0:
				ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null})
				var moved:=ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":boss_anchor})
				var entered:=ask(&"RoomEnterRequested",{"entity":game.HERO,"room":boss_room})
				check(moved.get("accepted",false) and entered.get("accepted",false),"test enters the generated boss room")
				for i in range(3): await process_frame
				var boss:=ask(&"DungeonBossGetRequested",{})
				check(boss.get("found",false) and boss.get("data",{}).get("room",null)==boss_room,"procedural boss spawns in candidate room")
				if boss.get("found",false):
					var boss_id: StringName=boss["data"]["entity"]
					var ai:=ask(&"AIGetRequested",{"entity":boss_id})
					check(boss["data"].get("loadout",null) is Dictionary and ai.get("found",false) and ai.get("data",{}).get("role","")=="melee","boss has equipment and shared melee AI")
					var chest_status:=ask(&"DungeonBossChestAutoStatusRequested",{})
					for i in range(600):
						if chest_status.get("status","") in ["created","failed"]: break
						await process_frame
						chest_status=ask(&"DungeonBossChestAutoStatusRequested",{})
					check(chest_status.get("status","")=="created","automatic boss chest is placed: " + str(chest_status))
					if chest_status.get("status","")=="created":
						var chest:=ask(&"ObjectGetRequested",{"object":chest_status.get("object",&"")})
						var contents: Array=ask(&"InventoryGetRequested",{"entity":chest_status.get("object",&"")}).get("data",{}).get("items",[])
						check(chest.get("found",false) and chest.get("data",{}).get("room",null)==boss_room and chest.get("data",{}).get("interaction",{}).get("boss_chest",false) and chest.get("data",{}).get("content_fixed",false) and contents.size()>=4 and contents.size()<=8,"boss chest has fixed contents in the boss room")
			break
		var stair: Dictionary=ask(&"ObjectGetRequested",{"object":got["object"]})["data"]
		var info: Dictionary=ask(&"RoomGetRequested",{"id":got["room"]})["data"]
		var bounds: Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
		var tile: Vector2i=stair["tile"]
		var entry_anchor:=room_entry_anchor(info)
		var spot:=reachable_adjacent_anchor(tile,entry_anchor,bounds)
		if spot.x<0:check(false,"floor %d: no 4x4 path from room entry to stair" % floor_no);quit(1);return
		ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null})
		var move:=ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":spot})
		var enter:=ask(&"RoomEnterRequested",{"entity":game.HERO,"room":got["room"]})
		ask(&"CombatDetectionChanged",{"entity":game.HERO,"active":false})
		var ok: bool=game._interact_chest()
		check(move.get("accepted",false) and move.get("anchor",null)==spot and enter.get("accepted",false),"test teleport near stairs")
		check(ok and driver.advance_steps(10)==10,"actual demo descent")
		if not ok:quit(1);return
		var next:=ask(&"DungeonFloorTrackingGetRequested",{})
		if next.get("data",{}).get("floor",0)!=floor_no+1:check(false,"failed descent " + game.message);quit(1);return
		await process_frame
		await process_frame

	game.queue_free()
	await process_frame
	var outcome := "PASS" if failures==0 else "%d failed" % failures
	print("Game demo natural floors (seed %d): %s" % [run_seed,outcome])
	quit(0 if failures==0 else 1)
