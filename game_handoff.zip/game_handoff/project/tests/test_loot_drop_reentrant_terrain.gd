extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(v: bool,s: String) -> void:
	if not v: failures+=1;printerr("FAIL: ",s)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e);return e
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	var id:=&"reactive_drop"
	check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"item")
	var anchor: Vector2i=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
	var tile:=Vector2i(-1,-1)
	for offset in [Vector2i(5,1),Vector2i(-2,1),Vector2i(1,5),Vector2i(1,-2)]:
		var candidate: Vector2i=anchor+offset
		var info:=ask(&"SpaceTileGetRequested",{"tile":candidate})
		if info.get("kind",0)==1 and info.get("occupant",null)==null and info.get("obstacle",null)==null and not info.get("passage",false) and ask(&"LootDropTileCheckRequested",{"entity":game.HERO,"tile":candidate}).get("valid",false): tile=candidate;break
	check(tile.x>=0,"free target")
	if tile.x<0:quit(1);return
	var observed: Dictionary={"attempted":false,"accepted":false}
	var mutation:=func(e):
		if e.get("entity",null)==game.HERO and e.get("before",{}).get("items",[]).has(id) and not e.get("after",{}).get("items",[]).has(id):
			observed["attempted"]=true
			observed["accepted"]=ask(&"SpaceTilesSetRequested",{"tiles":[tile],"kind":0}).get("accepted",false)
	bus.subscribe(&"EntityInventoryChangeCheckRequested",mutation)
	check(ask(&"LootInventoryDropRequested",{"entity":game.HERO,"item":id,"tile":tile}).get("accepted",false),"start")
	check(driver.advance_steps(10)==10,"finish")
	bus.unsubscribe(&"EntityInventoryChangeCheckRequested",mutation)
	check(observed["attempted"] and observed["accepted"],"terrain changed during ownership guard")
	check(game._inventory_items().has(id) and not ask(&"LootGetRequested",{})["items"].has(id),"invalidated drop leaves item in inventory")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"state remains saveable")
	game.queue_free();await process_frame
	print("Drop terrain reentrancy: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
