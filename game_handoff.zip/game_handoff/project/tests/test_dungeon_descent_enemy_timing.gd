extends SceneTree
var failures := 0
var finished: Array = []
var failed: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func run() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"DungeonDescended", func(e): finished.append(e.duplicate(true)))
	bus.subscribe(&"DungeonDescentFailed", func(e): failed.append(e.duplicate(true)))
	var level := ask(&"LevelGenerationRequested", {"level_id":&"floor1", "seed":11, "size_cells":Vector2i(100,60), "start_origin":Vector2i(2,2), "deadend_budget":1})
	check(level.get("accepted", false), "real level")
	check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":&"start"}).get("accepted", false), "tracking")
	var parent: StringName = &"start"
	for i in range(1,7):
		var id := StringName("chain_%d" % i)
		var x := 13 + (i-1)*12
		check(ask(&"RoomCreateRequested", {"id":id, "type":"deadend" if i == 6 else "passage", "origin_cell":Vector2i(x,2), "size_cells":Vector2i(12,12)}).get("accepted", false), "chain room " + str(i))
		if i > 1: check(ask(&"RoomExitAddRequested", {"room":parent, "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false), "parent exit")
		check(ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":"west", "offset_cells":5}).get("accepted", false), "entry")
		check(ask(&"RoomExitConnectRequested", {"room":parent, "exit":&"east", "other_room":id, "other_exit":&"entry"}).get("accepted", false), "connect " + str(i))
		if i == 6:
			var paint: Array = []
			for yy in range(9,55):
				for xx in range(x*4+1, x*4+47): paint.append(Vector2i(xx,yy))
			check(ask(&"SpaceTilesSetRequested", {"tiles":paint, "kind":1}).get("accepted", false), "test geometry for accessible stair")
		ask(&"RoomChildGenerated", {"room":parent, "child":id})
		parent = id
	var stair := ask(&"DungeonStairGetRequested", {})
	check(stair.get("found", false) and stair["data"].get("status", "") == "placed", "real selected stair " + str(stair))
	if failures > 0:
		quit(1)
		return
	var stair_id: StringName = stair["data"]["object"]
	var tile: Vector2i = ask(&"ObjectGetRequested", {"object":stair_id})["data"]["tile"]
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RunStatisticsStartRequested", {"entity":&"hero", "start_room":&"start"}).get("accepted", false), "stats")
	var placed := false
	for y in range(tile.y-4, tile.y+1):
		for x in range(tile.x-4, tile.x+1):
			var a := Vector2i(x,y)
			if not (((tile.x == a.x - 1 or tile.x == a.x + 4) and tile.y >= a.y and tile.y < a.y + 4) or ((tile.y == a.y - 1 or tile.y == a.y + 4) and tile.x >= a.x and tile.x < a.x + 4)): continue
			if ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":a, "size":4}).get("accepted", false):
				placed = true
				break
		if placed: break
	check(placed and ask(&"RoomEnterRequested", {"entity":&"hero", "room":parent}).get("accepted", false), "hero adjacent to stair")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted", false), "inventory")
	check(ask(&"ItemCreateRequested", {"id":&"potion", "base_id":&"potion_hp", "item_level":1}).get("accepted", false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"potion"}).get("accepted", false), "hero item")
	check(ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"HP", "value":23}).get("accepted", false), "hp")
	var mob := {"id":"test_mob", "type_weight":0.4, "species":{"id":"test", "species_weight":0.1}, "tags":[], "base_stats":{"CON":5,"STR":5,"DEX":5,"INT":5,"WIS":5,"PER":5}, "growth_per_level":{"CON":1,"STR":1,"DEX":1,"INT":1,"WIS":1,"PER":1}, "body_size":2, "min_depth":0, "max_depth":null}
	var hero_body: Dictionary = ask(&"SpaceBodyGetRequested", {"entity":&"hero"})["data"]
	var center := Vector2(hero_body["anchor"]) + Vector2.ONE * 2.0
	ask(&"RngSeedRequested", {"seed":42})
	var spawn := ask(&"RoomSpawnRequested", {"room":parent, "player":&"hero", "entry_tile":hero_body["anchor"], "depth":3, "pool":[mob], "queue_delay":0.05})
	check(spawn.get("accepted", false) and not spawn.get("units", []).is_empty() and spawn.get("queue_count", -1) == 0, "real registered enemies")
	if not spawn.get("accepted", false) or spawn.get("units", []).is_empty() or spawn.get("queue_count", -1) != 0:
		quit(1)
		return
	var actors: Array = []
	for unit in spawn["units"]: actors.append(unit["entity"])
	var room: Dictionary = ask(&"RoomGetRequested", {"id":parent})["data"]
	var origin: Vector2i = room["origin_cell"] * 4
	var dims: Vector2i = room["size_cells"] * 4
	for id in actors:
		var relocated := false
		for y in range(origin.y + 2, origin.y + dims.y - 3, 2):
			for x in range(origin.x + 2, origin.x + dims.x - 3, 2):
				var p := Vector2i(x,y)
				var near := Vector2(clampf(center.x, x, x+2), clampf(center.y, y, y+2))
				if center.distance_to(near) <= 19: continue
				if ask(&"SpaceBodyMoveRequested", {"entity":id, "anchor":p}).get("accepted", false):
					relocated = true
					break
			if relocated: break
		check(relocated, "move enemy far")
	var target: StringName = actors[0]
	check(ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"PER", "value":100}).get("accepted", false) and ask(&"StatBaseSetRequested", {"entity":target, "stat":&"PER", "value":100}).get("accepted", false), "long mutual detection range")
	var far: Vector2i = ask(&"SpaceBodyGetRequested", {"entity":target})["data"]["anchor"]
	var near_anchor := Vector2i(-1,-1)
	for y in range(origin.y + 1, origin.y + dims.y - 2):
		for x in range(origin.x + 1, origin.x + dims.x - 2):
			var p := Vector2i(x,y)
			var nearest := Vector2(clampf(center.x, x, x+2), clampf(center.y, y, y+2))
			if center.distance_to(nearest) > 8: continue
			if ask(&"SpaceBodyMoveRequested", {"entity":target, "anchor":p}).get("accepted", false):
				near_anchor = p
				break
		if near_anchor.x >= 0: break
	check(near_anchor.x >= 0, "move enemy near")
	var request := {"entity":&"hero", "level_id":&"floor2", "seed":22, "size_cells":Vector2i(48,48), "deadend_budget":1}
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":parent}).get("accepted", false) and ask(&"GameModeGetRequested", {}).get("mode", "") == "combat", "actual combat near")
	check(not ask(&"DungeonDescendRequested", request.duplicate()).get("accepted", true), "enemy inside radius blocks at start")
	check(ask(&"SpaceBodyMoveRequested", {"entity":target, "anchor":far}).get("accepted", false), "move target back far")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":parent}).get("accepted", false) and ask(&"GameModeGetRequested", {}).get("mode", "") == "combat", "actual combat from distance")
	var start := ask(&"DungeonDescendRequested", request.duplicate())
	check(start.get("accepted", false), "combat start when enemies distant: " + str(start.get("error", "")))
	if not start.get("accepted", false):
		quit(1)
		return
	check(driver.advance_steps(5) == 5, "descent half done")
	check(ask(&"SpaceBodyMoveRequested", {"entity":target, "anchor":near_anchor}).get("accepted", false), "enemy approaches after start")
	check(driver.advance_steps(5) == 5 and finished.size() == 1 and failed.is_empty(), "enemy approaching later does not cancel: " + str(failed))
	check(ask(&"LevelMapGetRequested", {})["map_data"]["level_id"] == &"floor2" and not ask(&"EntityGetRequested", {"entity":target}).get("found", false), "descent and spawned enemy cleanup")
	print("Dungeon descent enemy timing tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
