extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func key(game:Node,code:Key)->void:
	var e:=InputEventKey.new();e.pressed=true;e.keycode=code;game._unhandled_key_input(e)
func wait_action(driver)->bool:
	return ask(&"ActionStartRequested",{"entity":&"demo_hero","action":&"wait","duration":0.01}).get("accepted",false) and driver.advance_steps(1)==1
func text(game:Node,id:StringName)->String:
	return " | ".join(game._inspection_lines(id))
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save";var exists:=FileAccess.file_exists(path);var old:=PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	var bases:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema:Dictionary=root.get_node("DungeonChestLearningService").schema_for(&"armor_cloth_body",bases)
	check(ask(&"ItemCreateRequested",{"id":&"inspect_armour","base_id":&"armor_cloth_body","item_level":1,"rarity":&"magic","learning":schema}).get("accepted",false),"item")
	var vital:={"id":&"pre_vital","category":"prefix","stat":"CON","tier":3,"value":1.0,"level_req":1,"material_id":&"cloth_light","unlock_after":5}
	var agile:={"id":&"pre_agile","category":"prefix","stat":"DEX","tier":3,"value":1.0,"level_req":1,"material_id":&"cloth_light","unlock_after":10}
	check(ask(&"ItemModAttachRequested",{"item":&"inspect_armour","mod":vital}).get("accepted",false) and ask(&"ItemModAttachRequested",{"item":&"inspect_armour","mod":agile}).get("accepted",false),"attach mods")
	check(ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"inspect_armour"}).get("accepted",false),"inventory")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open")
	var idx:int=ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].find(&"inspect_armour")
	check(idx>=0 and idx<9,"first page")
	var t:float=driver.game_time
	key(game,KEY_V);key(game,KEY_1+idx)
	check(game.inspect_mode and game.inspect_item==&"inspect_armour" and driver.game_time==t,"inspect inventory with no time")
	var before:=text(game,&"inspect_armour")
	check(before.contains("Не опознано") and before.contains("0 / 25") and not before.contains("CON:") and not before.contains("DEX:"),"hide locked mod names and values")
	key(game,KEY_1);check(not ask(&"ActionGetRequested",{"entity":game.HERO}).get("found",false),"number cannot use item while details open")
	key(game,KEY_ESCAPE);check(not game.inspect_mode and game.inspect_item==&"","escape exits inspection")
	check(game._use_inventory_item(idx) and driver.advance_steps(10)==10,"equip armour")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close")
	for i in range(5):check(wait_action(driver),"progress to five")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"reopen")
	key(game,KEY_TAB);key(game,KEY_V);key(game,KEY_4)
	check(game.equipment_view and game.inspect_item==&"inspect_armour","inspect worn body slot")
	var five:=text(game,&"inspect_armour")
	check(five.contains("5 / 25") and five.contains("CON:") and not five.contains("DEX:"),"reveal only first mod")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save during inspection")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and game.inventory_open and not game.inspect_mode and game.inspect_item==&"","load resets transient view")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close after load")
	for i in range(5):check(wait_action(driver),"progress to ten")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"reopen at ten")
	var ten:=text(game,&"inspect_armour")
	check(ten.contains("10 / 25") and ten.contains("CON:") and ten.contains("DEX:"),"both revealed")
	check(ask(&"ItemCreateRequested",{"id":&"inspect_known","base_id":&"armor_cloth_body","item_level":1,"rarity":&"magic","learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested",{"item":&"inspect_known","mod":vital}).get("accepted",false) and ask(&"ItemModAttachRequested",{"item":&"inspect_known","mod":agile}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"inspect_known"}).get("accepted",false),"second inspection item")
	check(not text(game,&"inspect_known").contains("DEX:"),"hidden before identify")
	check(ask(&"StatBaseSetRequested",{"entity":game.HERO,"stat":&"INT","value":100}).get("accepted",false) and ask(&"ItemLearningIdentifyRequested",{"entity":game.HERO,"item":&"inspect_known"}).get("accepted",false) and driver.advance_steps(100)==100,"identify item")
	var known:=text(game,&"inspect_known")
	check(known.contains("Опознано") and known.contains("0 / 25") and known.contains("CON:") and known.contains("DEX:"),"identification reveals all mods without usage")
	check(text(game,&"demo_rat_sword")=="Предмет больше недоступен.","cannot inspect another owner's item")
	game.queue_free();await process_frame
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo item inspection: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
