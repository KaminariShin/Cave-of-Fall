extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(begin(4), "fourth floor")
	for i in range(1,17): check(add_room(i,"passage"), "build candidate %d" % i)
	check(tracking().get("boss_candidate",null) == &"node_16", "boss room selected")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_16"})["data"]
	var tile: Vector2i = room["origin_cell"] * 4 + Vector2i(1,1)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"ItemCreateRequested", {"id":&"boss_chest:boss_chest:0:0", "base_id":&"potion_hp", "item_level":1}).get("accepted",false), "occupy first candidate item ID")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var wrong := ask(&"DungeonBossChestProvisionRequested", {"room":&"node_15", "candidate":tile, "chest_id":&"boss_chest"})
	check(not wrong.get("accepted",true) and wrong.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "reject nonboss room without mutation")
	var invalid := ask(&"DungeonBossChestProvisionRequested", {"room":&"node_16", "candidate":room["origin_cell"]*4 + Vector2i(10,10), "chest_id":&"boss_chest"})
	check(not invalid.get("accepted",true) and invalid.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "reject unsafe candidate")
	var mark := {"count":0,"nested":true,"saves":true}
	var fail_add := func(e):
		if e.get("entity",null) == &"boss_chest":
			mark["count"] += 1
			if mark["count"] == 2: e["accepted"] = false
	var observe := func(e):
		if e.get("object",null) == &"boss_chest":
			mark["nested"] = ask(&"DungeonBossChestProvisionRequested", {"room":&"node_16", "candidate":tile, "chest_id":&"another"}).get("accepted",true)
			mark["saves"] = ask(&"SessionSaveRequested",{}).get("accepted",true)
	bus.subscribe(&"InventoryAddRequested",fail_add)
	bus.subscribe(&"ObjectCreated",observe)
	var failed := ask(&"DungeonBossChestProvisionRequested", {"room":&"node_16", "candidate":tile, "chest_id":&"boss_chest"})
	bus.unsubscribe(&"InventoryAddRequested",fail_add)
	bus.unsubscribe(&"ObjectCreated",observe)
	check(not failed.get("accepted",true) and failed.get("rolled_back",false) and mark["count"] == 2 and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "partial materialization and RNG roll back")
	check(not ask(&"ObjectGetRequested", {"object":&"boss_chest"}).get("found",true) and not mark["nested"] and not mark["saves"], "no incomplete chest, reentry and save blocked")
	var checks := {"count":0}
	var reject_final := func(e):
		if e.get("room",null) == &"node_16" and e.get("tile",null) == tile:
			checks["count"] += 1
			if checks["count"] == 3: e["accepted"] = false
	bus.subscribe(&"DungeonChestPositionPreflightRequested",reject_final)
	var final_failure := ask(&"DungeonBossChestProvisionRequested", {"room":&"node_16", "candidate":tile, "chest_id":&"boss_chest"})
	bus.unsubscribe(&"DungeonChestPositionPreflightRequested",reject_final)
	check(not final_failure.get("accepted",true) and final_failure.get("rolled_back",false) and checks["count"] == 3 and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "failed final preflight rolls back completed contents and RNG")
	var result := ask(&"DungeonBossChestProvisionRequested", {"room":&"node_16", "candidate":tile, "chest_id":&"boss_chest"})
	check(result.get("accepted",false), "atomic creation " + str(result))
	if not result.get("accepted",false): quit(1); return
	check(result["items"].size() >= 4 and result["items"].size() <= 8 and result["tile"] == tile and result["items"][0] == &"boss_chest:boss_chest:0:1", "fixed boss count and free item IDs")
	var chest: Dictionary = ask(&"ObjectGetRequested", {"object":&"boss_chest"})["data"]
	check(chest.get("content_fixed",false) and not chest.has("content_draft") and not chest["opened"] and chest["interaction"]["boss_chest"] == true and ask(&"InventoryGetRequested", {"entity":&"boss_chest"})["data"]["items"] == result["items"], "contents fixed and closed")
	check(ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_16", "tile":tile, "existing_object":&"boss_chest"}).get("accepted",false), "placed chest still meets preflight")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"InventoryGetRequested", {"entity":&"boss_chest"})["data"]["items"] == result["items"], "content persists")
	var current: Dictionary = saver.collect_world_transition_snapshot()
	var duplicate := ask(&"DungeonBossChestProvisionRequested", {"room":&"node_16", "candidate":tile + Vector2i(1,0), "chest_id":&"second"})
	check(not duplicate.get("accepted",true) and duplicate.get("rolled_back",false) and current["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "no duplicate")
	print("Boss chest provision tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
