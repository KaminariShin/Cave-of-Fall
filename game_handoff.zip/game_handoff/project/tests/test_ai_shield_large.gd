extends SceneTree
var failures := 0
var bus: Node
var events: Array = []
func _initialize() -> void: call_deferred("run")
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func check(v: bool, label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(80,80)}).get("accepted",false),"map")
	check(ask(&"RoomCreateRequested",{"id":&"A","type":"start","origin_cell":Vector2i(1,1),"size_cells":Vector2i(11,11)}).get("accepted",false),"room")
	for id in [&"hero",&"enemy"]: check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"controlled")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"hero body")
	check(ask(&"RoomEnterRequested",{"entity":&"hero","room":&"A"}).get("accepted",false),"enter")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"enemy","anchor":Vector2i(17,10),"size":4}).get("accepted",false),"enemy body")
	for row in [[&"hero_sword",&"sword_simple"],[&"enemy_sword",&"sword_simple"],[&"shield",&"shield_large"]]:
		check(ask(&"ItemCreateRequested",{"id":row[0],"base_id":row[1],"item_level":1}).get("accepted",false),"item")
	check(ask(&"ComponentSetRequested",{"entity":&"hero","component":&"equipment","data":{"main":&"hero_sword"}}).get("accepted",false),"hero weapon")
	check(ask(&"ComponentSetRequested",{"entity":&"enemy","component":&"equipment","data":{"main":&"enemy_sword","off":&"shield"}}).get("accepted",false),"enemy gear")
	check(ask(&"AIRegisterRequested",{"entity":&"enemy","room":&"A","role":"melee","target":&"hero","detected":true,"wait_duration":0.5,"weapon":{"item":&"enemy_sword","strike":"demo_creature_thrust"}}).get("accepted",false),"AI")
	check(ask(&"ActionStartRequested",{"entity":&"enemy","action":&"wait","duration":0.5}).get("accepted",false),"enemy waits")
	var handler := func(e): events.append(e.duplicate(true))
	bus.subscribe(&"AIDecision",handler)
	var hp: float = ask(&"ResourceGetRequested",{"entity":&"enemy","resource":&"HP"})["data"]["current"]
	var stamina: float = ask(&"ResourceGetRequested",{"entity":&"enemy","resource":&"Stamina"})["data"]["current"]
	var strike := ask(&"WeaponStrikeStartRequested",{"entity":&"hero","item":&"hero_sword","strike":"demo_player_sword_thrust","direction":Vector2.RIGHT})
	check(strike.get("accepted",false),"hero strike " + str(strike))
	check(driver.advance_steps(15)==15,"advance")
	var status := ask(&"ShieldBlockStatusRequested",{"entity":&"enemy"})
	check(status.get("active",false),"enemy raised shield " + str(events))
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save while blocking")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load while blocking")
	driver.advance_steps(40)
	check(ask(&"ResourceGetRequested",{"entity":&"enemy","resource":&"HP"})["data"]["current"] == hp,"shield absorbs melee")
	check(ask(&"ResourceGetRequested",{"entity":&"enemy","resource":&"Stamina"})["data"]["current"] < stamina,"block costs stamina")
	bus.unsubscribe(&"AIDecision",handler)
	print("AI shield large body: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
