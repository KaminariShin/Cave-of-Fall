extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func snap() -> Dictionary: return root.get_node("SaveService").collect_world_transition_snapshot()
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus = root.get_node("EventBus")
	var service = root.get_node("FloorRebuildService")
	var first := ask(&"LevelGenerationRequested", {"level_id":&"floor1", "seed":11, "size_cells":Vector2i(48,48), "deadend_budget":1})
	check(first.get("accepted", false), "generate first")
	if not first.get("accepted", false):
		quit(1)
		return
	var center: Vector2i = (first["map_data"]["rooms"][&"start"]["origin_cell"] + Vector2i(5,5)) * 4
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":20}).get("accepted", false), "inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":center, "size":4}).get("accepted", false), "body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":&"start"}).get("accepted", false), "tracking")
	check(ask(&"RunStatisticsStartRequested", {"entity":&"hero", "start_room":&"start"}).get("accepted", false), "statistics")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"start"}).get("accepted", false), "enter")
	check(ask(&"ItemCreateRequested", {"id":&"hero_item", "base_id":&"potion_hp", "item_level":1}).get("accepted", false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"hero_item"}).get("accepted", false), "hero item")
	check(ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"HP", "value":23}).get("accepted", false), "wounded hero")
	check(ask(&"PeriodicEffectApplyRequested", {"entity":&"hero", "effect":&"poison", "source":&"old_enemy", "damage_type":"physical", "damage_per_tick":1, "base_duration":5.0}).get("accepted", false), "hero poison")
	# Искусственный объект тестирует очистку старой карты; это не правило контента стартовой комнаты.
	var origin: Vector2i = first["map_data"]["rooms"][&"start"]["origin_cell"] * 4
	var made_chest := false
	for y in range(origin.y + 1, origin.y + 43):
		for x in range(origin.x + 1, origin.x + 43):
			if ask(&"ObjectCreateRequested", {"entity":&"test_chest", "room":&"start", "type":"chest", "tile":Vector2i(x,y), "inventory_capacity":10}).get("accepted", false):
				made_chest = true
				break
		if made_chest: break
	check(made_chest, "old-world test object")
	check(ask(&"ItemCreateRequested", {"id":&"old_item", "base_id":&"bandage", "item_level":1}).get("accepted", false) and ask(&"InventoryAddRequested", {"entity":&"test_chest", "item":&"old_item"}).get("accepted", false), "old-world test content")
	var old: Dictionary = snap()["payload"]["sections"]
	check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":1.0}).get("accepted", false), "active action")
	var denied: Dictionary = service.rebuild_next_floor(&"hero", &"floor2", 22, Vector2i(48,48), 1)
	check(not denied.get("committed", true) and denied.get("rolled_back", false) and denied.get("error", "").contains("действие"), "active action denies rebuild")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted", false), "cancel action")
	old = snap()["payload"]["sections"]
	var mutate := func(e):
		if e.get("level_id", &"") == &"floor2": ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"HP", "value":5})
	bus.subscribe(&"LevelGenerated", mutate)
	var bad: Dictionary = service.rebuild_next_floor(&"hero", &"floor2", 22, Vector2i(48,48), 1)
	bus.unsubscribe(&"LevelGenerated", mutate)
	check(not bad.get("committed", true) and bad.get("rolled_back", false), "player mutation after generation rolls back")
	var restored: Dictionary = snap()["payload"]["sections"]
	check(restored["level"] == old["level"] and restored["space"] == old["space"] and restored["rooms"] == old["rooms"] and restored["entities"] == old["entities"] and restored["periodic_effects"] == old["periodic_effects"] and restored["run_statistics"] == old["run_statistics"], "old level, body, stats, items, effects restored")
	var block_create := func(e):
		if e.get("id", &"") == &"start": e["accepted"] = false
	bus.subscribe(&"RoomCreateRequested", block_create)
	bad = service.rebuild_next_floor(&"hero", &"floor2", 22, Vector2i(48,48), 1)
	bus.unsubscribe(&"RoomCreateRequested", block_create)
	check(not bad.get("committed", true) and bad.get("rolled_back", false) and snap()["payload"]["sections"]["level"] == old["level"] and snap()["payload"]["sections"]["space"] == old["space"], "partial generation rolls back old map")
	var result: Dictionary = service.rebuild_next_floor(&"hero", &"floor2", 22, Vector2i(48,48), 1)
	check(result.get("committed", false), "rebuild succeeds: " + str(result.get("error", "")))
	if result.get("committed", false):
		var after: Dictionary = snap()["payload"]["sections"]
		check(result["floor"] == 2 and after["level"]["level_id"] == &"floor2" and after["level"]["seed"] == 22 and after["dungeon_tracking"]["floor"] == 2 and after["run_statistics"]["floor"] == 2, "new level and tracking")
		check(after["space"]["bodies"][&"hero"]["anchor"] == result["anchor"] and after["space"]["bodies"][&"hero"]["size"] == 4 and after["rooms"]["current_room"] == &"start", "hero placed in start room")
		check(not after["entities"].has(&"test_chest") and not after["items"]["instances"].has(&"old_item"), "old object and content cleared")
		check(after["entities"][&"hero"][&"resources"] == old["entities"][&"hero"][&"resources"] and after["entities"][&"hero"][&"inventory"] == old["entities"][&"hero"][&"inventory"] and after["periodic_effects"] == old["periodic_effects"] and after["time"] == old["time"], "resources, item, poison, time preserved")
		check(after["run_statistics"]["visited"][1].has(&"start") and after["run_statistics"]["visited"][2].has(&"start") and after["run_statistics"]["kills"] == 0, "visit history retained")
		check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and snap()["payload"]["sections"]["level"]["level_id"] == &"floor2", "new level save and load")
		var same_id: Dictionary = service.rebuild_next_floor(&"hero", &"floor2", 33, Vector2i(48,48), 1)
		var no_budget: Dictionary = service.rebuild_next_floor(&"hero", &"floor3", 33, Vector2i(48,48), 0)
		check(not same_id.get("committed", true) and not no_budget.get("committed", true), "same ID and missing stair budget denied")
		var third: Dictionary = service.rebuild_next_floor(&"hero", &"floor3", 33, Vector2i(48,48), 1)
		var fourth: Dictionary = service.rebuild_next_floor(&"hero", &"floor4", 44, Vector2i(48,48), 0)
		check(third.get("committed", false) and fourth.get("committed", false), "technical rebuild supports floors three and four: " + str([third.get("error", ""), fourth.get("error", "")]))
		if fourth.get("committed", false):
			var final: Dictionary = snap()["payload"]["sections"]
			check(final["run_statistics"]["floor"] == 4 and final["run_statistics"]["visited"].size() == 4 and final["periodic_effects"] == old["periodic_effects"], "four floors tracked, poison preserved")
			check(not service.rebuild_next_floor(&"hero", &"floor5", 55, Vector2i(48,48), 1).get("committed", true), "fifth floor rejected")
	print("Floor rebuild tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
