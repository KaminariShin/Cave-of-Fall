extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func click(game:Control,pos:Vector2)->void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*pos;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;game._input(e)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var entities=root.get_node("EntityRegistry")
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	game.size=Vector2(1280,720)
	check(game.initialized and game.hero_level==1 and game.hero_xp==0 and game.hero_points==0,"initial progression")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"disable AI")
	check(ask(&"CombatDamageRequested",{"entity":game.RAT,"source":game.HERO,"amount":9999}).get("accepted",false),"kill rat through combat")
	check(game.hero_xp==25 and game.hero_level==1,"rat award")
	check(not ask(&"CombatDamageRequested",{"entity":game.RAT,"source":game.HERO,"amount":9999}).get("accepted",false) and game.hero_xp==25,"no repeated dead award")
	for i in range(3):
		var id:=StringName("progression_test_%d" % i)
		check(entities.create_entity(id),"create target")
		check(ask(&"CombatDamageRequested",{"entity":id,"source":game.HERO,"amount":9999}).get("accepted",false),"kill target")
		check(entities.remove_entity(id),"remove target")
	check(game.hero_level==2 and game.hero_xp==0 and game.hero_points==2,"level up and points")
	check(ask(&"RunStatisticsGetRequested",{})["data"]["level"]==2,"run statistics exposes hero level")
	var next:=StringName("next_level_test")
	check(entities.create_entity(next),"create next-level target")
	check(ask(&"CombatDamageRequested",{"entity":next,"source":game.HERO,"amount":9999}).get("accepted",false) and entities.remove_entity(next),"next level kill")
	check(game.hero_level==2 and game.hero_xp==25,"next-level XP accumulated")
	var other:=StringName("no_reward")
	check(entities.create_entity(other),"create uncredited")
	check(ask(&"CombatDamageRequested",{"entity":other,"source":null,"amount":9999}).get("accepted",false),"other death")
	check(game.hero_xp==25 and entities.remove_entity(other),"no reward without hero killer")
	click(game,game._stats_button_rect().get_center())
	check(driver.advance_steps(1)==1 and game.inventory_open and game.stats_view,"mouse opens stats")
	var before:Dictionary=ask(&"StatGetRequested",{"entity":game.HERO,"stat":&"CON"})
	var hp:float=ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"})["data"]["max"]
	var p:Vector2=game._inventory_rect().position
	click(game,p+Vector2(460,176))
	var after:Dictionary=ask(&"StatGetRequested",{"entity":game.HERO,"stat":&"CON"})
	var hp_after:float=ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"HP"})["data"]["max"]
	check(game.hero_points==1 and after["base"]==before["base"]+1 and hp_after>hp,"allocate CON and recalculate HP max")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save")
	click(game,p+Vector2(460,216));check(game.hero_points==0,"second point")
	click(game,p+Vector2(460,216));check(game.hero_points==0,"no points no increase")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load")
	check(game.hero_level==2 and game.hero_xp==25 and game.hero_points==1 and ask(&"StatGetRequested",{"entity":game.HERO,"stat":&"CON"})["base"]==before["base"]+1,"restore progression and stats")
	check(not game.stats_view,"navigation reset")
	var snapshot:Dictionary=ask(&"SnapshotCollectRequested",{"sections":{},"errors":[]})
	if snapshot.get("sections",{}).has("game_demo"):
		snapshot["sections"]["game_demo"]["progression"]["points"]=99
		check(not ask(&"GameDemoSnapshotValidateRequested",{"sections":snapshot["sections"]}).get("valid",false),"invalid point count rejected")
	else: check(false,"snapshot available")
	check(ask(&"CombatDamageRequested",{"entity":game.HERO,"source":null,"amount":9999}).get("accepted",false),"hero death")
	game._new_game();await process_frame
	check(not game.is_dead and game.hero_level==1 and game.hero_xp==0 and game.hero_points==0,"fresh run resets progression")
	game.queue_free();await process_frame
	print("Game demo progression: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
