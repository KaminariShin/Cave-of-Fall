extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(value: bool, label: String) -> void:
	if not value: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func click(game: Control, pos: Vector2) -> void:
	var e := InputEventMouseButton.new(); e.position=game.get_global_transform_with_canvas()*pos; e.button_index=MOUSE_BUTTON_LEFT; e.pressed=true; game._input(e)
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var path := "user://demo_session.save"
	var existed := FileAccess.file_exists(path)
	var old := PackedByteArray()
	if existed:
		var f := FileAccess.open(path,FileAccess.READ); old=f.get_buffer(f.get_length()); f.close()
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.size=Vector2(1280,720)
	check(game.initialized,"demo initializes")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet tutorial rat")
	check(ask(&"ObjectCreateRequested",{"entity":&"other_chest","type":"chest","room":game.ROOM,"tile":Vector2i(70,70),"inventory_capacity":20.0}).get("accepted",false),"create non-tutorial chest")
	for id in [&"chest_potion_a",&"chest_potion_b",&"chest_potion_c"]:
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false),"create item")
		check(ask(&"InventoryAddRequested",{"entity":&"other_chest","item":id}).get("accepted",false),"fill chest")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":Vector2i(66,69)}).get("accepted",false),"approach chest")
	var start: float = driver.game_time
	check(game._interact_chest(),"F opens non-tutorial chest")
	check(driver.advance_steps(10)==10 and ask(&"ObjectGetRequested",{"object":&"other_chest"})["data"]["opened"],"open in 0.1 s")
	check(game.message.contains("3 предметов"),"shows content count")
	check(game._interact_chest() and game._pickup_open,"F opens selection")
	click(game,game._pickup_row_rect(1).get_center())
	check(game._pickup_open and ask(&"ActionGetRequested",{"entity":game.HERO}).get("data",{}).get("id",null)==&"chest_take","select second chest item by mouse")
	check(driver.advance_steps(5)==5,"half transfer")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save pending transfer")
	check(driver.advance_steps(5)==5,"finish transfer")
	check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].has(&"chest_potion_b"),"selected item owned")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load pending transfer")
	check(driver.advance_steps(5)==5,"finish restored transfer")
	var player: Array = ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]
	var remaining: Array = ask(&"InventoryGetRequested",{"entity":&"other_chest"})["data"]["items"]
	check(player.count(&"chest_potion_b")==1 and remaining == [&"chest_potion_a",&"chest_potion_c"],"single restored transfer")
	check(game._pickup_open and game._pickup_item(&"chest_potion_a") and driver.advance_steps(10)==10,"select next item")
	check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].has(&"chest_potion_a"),"next item owned")
	check(absf(driver.game_time-start-0.3)<0.00001,"opening and two transfers cost 0.3 seconds")
	var inventory := ask(&"InventoryGetRequested",{"entity":game.HERO})
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":inventory["used_volume"]}).get("accepted",false),"fill capacity")
	var before: float = driver.game_time
	check(not game._pickup_item(&"chest_potion_c") and game.message.contains("не помещается") and driver.game_time==before,"capacity rejected without time")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":8.0}).get("accepted",false),"restore capacity")
	check(game._pickup_item(&"chest_potion_c"),"restart third transfer")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO,"reason":&"test"}).get("accepted",false),"interrupt transfer")
	check(ask(&"InventoryGetRequested",{"entity":&"other_chest"})["data"]["items"].has(&"chest_potion_c") and game.message.contains("не завершён"),"interruption leaves item and reports")
	check(game._pickup_item(&"chest_potion_c") and driver.advance_steps(10)==10,"retry after interruption")
	check(not game._interact_chest() and game.message == "Сундук пуст.","empty chest")
	ask(&"DungeonBossChestAutoFailed",{"room":game.ROOM,"error":"нет места"})
	check(game.message.contains("нет места") and game.message.contains("R"),"boss chest failure shown")
	var fake_status := func(e): e["status"]="failed"; e["room"]=game.ROOM
	var fake_retry := func(e): e["accepted"]=true
	bus.subscribe(&"DungeonBossChestAutoStatusRequested",fake_status)
	bus.subscribe(&"DungeonBossChestAutoRetryRequested",fake_retry)
	game._retry_spawns()
	check(game.message.contains("Ищем место"),"R routes retry")
	bus.unsubscribe(&"DungeonBossChestAutoStatusRequested",fake_status)
	bus.unsubscribe(&"DungeonBossChestAutoRetryRequested",fake_retry)
	game.queue_free()
	await process_frame
	if existed:
		var f := FileAccess.open(path,FileAccess.WRITE); f.store_buffer(old); f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo chests: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
