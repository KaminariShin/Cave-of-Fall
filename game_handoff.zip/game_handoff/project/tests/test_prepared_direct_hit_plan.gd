extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func hp(id: StringName) -> int: return int(ask(&"ResourceGetRequested", {"entity":id,"resource":&"HP"})["data"]["current"])
func target(id: StringName) -> Dictionary:
	return {"target":id,"hp_before":hp(id),"physical_protection_percent":50.0,"magical_protection_percent":25.0,"attack_tiles":[Vector2i(4,4)]}
func request(rows: Array) -> Dictionary:
	return {"source":&"hero","targets":rows,"physical":10.0,"magical":2.0,"per":1000,"weakening_multiplier":0.5}
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var rng = root.get_node("RngService")._rng
	for id in [&"hero",&"a",&"z"]:
		check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for id in [&"a",&"z"]: check(ask(&"ResourceSetRequested", {"entity":id,"resource":&"HP","value":20}).get("accepted",false),"HP")
	var rows := [target(&"z"),target(&"a")]
	var original: int = rng.state
	for mode in range(7):
		var bad := request(rows.duplicate(true))
		match mode:
			0: bad["targets"][1]["target"] = &"z"
			1: bad["targets"][0]["physical_protection_percent"] = 75.01
			2: bad["targets"][0]["hp_before"] = 0
			3: bad["targets"][0]["attack_tiles"] = [Vector2.ZERO]
			4: bad["weakening_multiplier"] = 0.3
			5: bad["targets"][0]["target"] = &"hero"
			6: bad["physical"] = 1000000000.0
		check(not ask(&"PreparedDirectHitPlanRequested",bad).get("accepted",true) and rng.state == original,"reject before RNG " + str(mode))
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save RNG")
	var result := ask(&"PreparedDirectHitPlanRequested",request(rows))
	check(result.get("accepted",false),"prepare hits")
	if result.get("accepted",false):
		var hits: Array = result["data"]["hits"]
		check(hits.size() == 2 and hits[0]["target"] == &"a" and hits[1]["target"] == &"z" and hits[0]["critical"] and hits[0]["damage"] == 5 and hits[0]["magical_damage"] == 2,"sort and critical protection weakening ceil")
	check(hp(&"a") == 20 and hp(&"z") == 20 and rng.state != original,"planning only advances RNG")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore")
	rows.reverse()
	var replay := ask(&"PreparedDirectHitPlanRequested",request(rows))
	check(replay.get("accepted",false) and replay["data"] == result["data"],"deterministic sorted rolls after restore")
	check(ask(&"ActionDefinitionRegisterRequested", {"data":{"id":&"plan_test","name":"test","type":&"physical","base_duration":0.01,"phase_completion":true}}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"hero","action":&"plan_test"}).get("accepted",false),"phase action")
	var state := {"planned":false,"sent":0,"resolved":false}
	var bus = root.get_node("EventBus")
	var phase := func(_e):
		var q := ask(&"PreparedDirectHitPlanRequested",request([target(&"z"),target(&"a")]))
		state["planned"] = q.get("accepted",false)
		if state["planned"]:
			for hit in q["data"]["hits"]:
				if ask(&"CombatPhaseHitSubmitRequested",hit.duplicate(true)).get("accepted",false): state["sent"] += 1
	var batch := func(e): state["resolved"] = e.get("accepted",false) and e.get("hit_count",0) == 2
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch)
	check(driver.advance_steps(1) == 1 and state["planned"] and state["sent"] == 2 and state["resolved"] and hp(&"a") == 13 and hp(&"z") == 13,"prepared rows accepted and applied as one phase batch")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch)
	print("Prepared direct hit plan tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
