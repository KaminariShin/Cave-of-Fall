extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func click(game:Control,p:Vector2)->void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*p;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;game._input(e)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame;game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	var center:Vector2=game._map_origin()+game._camera_center_world()*game.STEP_PX
	var original_time:float=driver.game_time
	for degree in [0,17,32,45,78,103,146,192,227,271,315,351]:
		var wanted:=Vector2.from_angle(deg_to_rad(degree))
		game._mouse_aim(center+wanted*130.0)
		check(game.attack_direction.is_equal_approx(wanted),"free direction %d" % degree)
		check(not driver.is_action_active and driver.game_time==original_time,"aiming costs no time")
	var wanted:=Vector2.from_angle(deg_to_rad(-35.0))
	game._mouse_aim(center+wanted*130.0)
	check(game.facing==Vector2i.RIGHT,"block remains nearest cardinal side")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save free direction")
	game._mouse_aim(center+Vector2(0,120))
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and game.attack_direction.is_equal_approx(wanted),"restore direction")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.RAT,"anchor":Vector2i(61,56)}).get("accepted",false),"place diagonal target")
	var hp_before:float=ask(&"ResourceGetRequested",{"entity":game.RAT,"resource":&"HP"})["data"]["current"]
	check(game._start_attack(),"start angled strike")
	var status:Dictionary=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})
	check(status.get("active",false) and Vector2(status["data"]["direction"]).is_equal_approx(wanted),"strike uses exact angle")
	var tiles_before:Array=game.attack_tiles.duplicate()
	check(driver.advance_steps(5)==5 and ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save active angled strike")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load active angled strike")
	check(Vector2(ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})["data"]["direction"]).is_equal_approx(wanted),"active strike direction restored")
	click(game,center+Vector2(-120,0))
	check(Vector2(ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})["data"]["direction"]).is_equal_approx(wanted) and game.attack_tiles==tiles_before,"ongoing strike keeps its direction")
	driver.advance_steps(200)
	var hp_after:float=ask(&"ResourceGetRequested",{"entity":game.RAT,"resource":&"HP"})["data"]["current"]
	print("angled hit rat hp: ",hp_before," -> ",hp_after)
	check(hp_after<hp_before,"angled strike damages diagonal target")
	game.facing=Vector2i.DOWN
	check(game.attack_direction==Vector2.DOWN,"keyboard/cardinal facing updates strike direction")
	game.queue_free();await process_frame
	print("Game demo free-angle attack: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
