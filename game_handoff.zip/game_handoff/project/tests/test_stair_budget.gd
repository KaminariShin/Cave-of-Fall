extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func id(i: int) -> StringName: return StringName("chain_%d" % i)
func budget(room: StringName, value: int) -> Dictionary:
	return ask(&"DungeonDeadendBudgetAvailableRequested", {"room":room, "budget":value})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(500,250)}).get("accepted", false), "map")
	for i in range(6):
		var room_type := "start" if i == 0 else "fork"
		check(ask(&"RoomCreateRequested", {"id":id(i), "type":room_type, "origin_cell":Vector2i(10 if i == 0 else 22 + (i - 1) * 14,20), "size_cells":Vector2i(12,12) if i == 0 else Vector2i(14,14)}).get("accepted", false), "create chain room")
		if i == 0:
			check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":id(0)}).get("accepted", false), "tracking starts before children")
		else:
			check(ask(&"RoomExitAddRequested", {"room":id(i - 1), "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false), "add outgoing")
			check(ask(&"RoomExitAddRequested", {"room":id(i), "id":&"entry", "dir":"west", "offset_cells":5}).get("accepted", false), "add entry")
			check(ask(&"RoomExitConnectRequested", {"room":id(i - 1), "exit":&"east", "other_room":id(i), "other_exit":&"entry"}).get("accepted", false), "connect")
			ask(&"RoomChildGenerated", {"room":id(i - 1), "child":id(i), "type":room_type})
	check(budget(id(1),1).get("budget", -1) == 0, "reserve last deadend at early depth")
	check(budget(id(1),2).get("budget", -1) == 2, "additional early deadends remain allowed")
	check(budget(id(4),1).get("budget", -1) == 0, "child distance five still reserved")
	check(budget(id(5),1).get("budget", -1) == 1, "child distance six may use reservation")
	check(not budget(&"missing",1).get("accepted", false), "unknown parent fails closed")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":1}).get("accepted", false), "set budget")
	check(budget(id(1),0).get("budget", -1) == 0, "zero budget not fabricated")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save and restore before candidate")
	check(budget(id(1),1).get("budget", -1) == 0 and budget(id(5),1).get("budget", -1) == 1, "reservation survives restore")
	check(ask(&"RoomExitAddRequested", {"room":id(1), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "early branch")
	check(ask(&"RoomExitAddRequested", {"room":id(5), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "eligible branch")
	var force_last := func(e): e["value"] = 0.999999
	root.get_node("EventBus").subscribe(&"RngFloatRequested", force_last)
	var early := ask(&"RoomChildGenerateRequested", {"room":id(1), "exit":&"north"})
	check(early.get("accepted", false) and early.get("type", "") != "deadend", "actual generator cannot consume last budget too early")
	var late := ask(&"RoomChildGenerateRequested", {"room":id(5), "exit":&"north"})
	check(late.get("accepted", false) and late.get("type", "") == "deadend", "actual generator can use reserved budget at distance six")
	var tracking: Dictionary = ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
	check(tracking.get("stair_candidate", null) == late.get("child", null), "generated eligible deadend is candidate")
	var stair: Dictionary = ask(&"DungeonStairGetRequested", {}).get("data", {})
	check(stair.get("room", null) == late.get("child", null) and stair.get("status", "") == "placed", "stair placed in generated room")
	check(budget(id(1),1).get("budget", -1) == 1, "reservation released once candidate exists")
	if stair.get("status", "") == "placed":
		check(ask(&"ObjectRemoveRequested", {"object":stair["object"]}).get("accepted", false), "remove stairs before reset")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(120,120)}).get("accepted", false), "reset map")
	check(ask(&"RoomCreateRequested", {"id":&"root4", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)}).get("accepted", false), "fourth-floor start")
	check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":4, "start_room":&"root4"}).get("accepted", false), "fourth-floor tracking")
	check(budget(&"root4",1).get("budget", -1) == 0, "fourth floor reserves last deadend for portal")
	root.get_node("EventBus").unsubscribe(&"RngFloatRequested", force_last)
	print("Stair budget tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
