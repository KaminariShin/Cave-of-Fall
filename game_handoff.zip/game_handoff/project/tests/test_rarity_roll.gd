extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus = root.get_node("EventBus")
	var state := {"values":[], "limits":[], "nested":true, "save":true, "do_nested":false}
	var mock := func(e):
		state["limits"].append([e["min"], e["max"]])
		if state["do_nested"]:
			state["do_nested"] = false
			state["nested"] = ask(&"ItemRarityRollRequested", {"unique_available":true,"artifact_available":true}).get("accepted", true)
			state["save"] = ask(&"SessionSaveRequested", {}).get("accepted", true)
		if not state["values"].is_empty(): e["value"] = state["values"].pop_front()
	bus.subscribe(&"RngIntRequested", mock)
	for pair in [[0,&"normal"], [699,&"normal"], [700,&"magic"], [939,&"magic"], [940,&"rare"], [989,&"rare"], [990,&"unique"], [998,&"unique"], [999,&"artifact"]]:
		state["values"] = [pair[0]]
		state["limits"] = []
		var r := ask(&"ItemRarityRollRequested", {"unique_available":true, "artifact_available":true})
		check(r.get("accepted", false) and r.get("rarity", null) == pair[1] and r.get("draws", 0) == 1 and r.get("excluded", null) == [] and state["limits"] == [[0,999]], "weight boundary %s" % str(pair[0]))
	state["values"] = [999, 990, 940]
	state["limits"] = []
	var reroll := ask(&"ItemRarityRollRequested", {"unique_available":false, "artifact_available":false})
	check(reroll.get("accepted", false) and reroll.get("rarity", null) == &"rare" and reroll.get("excluded", []) == [&"artifact", &"unique"] and reroll.get("draws", 0) == 3 and state["limits"] == [[0,999],[0,998],[0,989]], "unavailable artifact then unique excluded on reroll")
	state["values"] = [995, 990]
	state["limits"] = []
	var other := ask(&"ItemRarityRollRequested", {"unique_available":false, "artifact_available":true})
	check(other.get("accepted", false) and other.get("rarity", null) == &"artifact" and other.get("excluded", []) == [&"unique"] and state["limits"] == [[0,999],[0,990]], "artifact remains in pool")
	state["limits"] = []
	check(not ask(&"ItemRarityRollRequested", {"unique_available":true}).get("accepted", true) and state["limits"].is_empty(), "invalid inputs do not roll")
	state["values"] = [0]
	state["do_nested"] = true
	check(ask(&"ItemRarityRollRequested", {"unique_available":true,"artifact_available":true}).get("accepted", false) and not state["nested"] and not state["save"], "nested request and save blocked")
	state["values"] = [1000]
	var invalid := ask(&"ItemRarityRollRequested", {"unique_available":true,"artifact_available":true})
	check(not invalid.get("accepted", true) and invalid.get("draws", 0) == 1 and not invalid.has("rarity"), "malformed rng rejected")
	bus.unsubscribe(&"RngIntRequested", mock)
	ask(&"RngSeedRequested", {"seed":1234})
	var a: Array = []
	for i in range(20): a.append(ask(&"ItemRarityRollRequested", {"unique_available":false,"artifact_available":false}).get("rarity", null))
	ask(&"RngSeedRequested", {"seed":1234})
	var b: Array = []
	for i in range(20): b.append(ask(&"ItemRarityRollRequested", {"unique_available":false,"artifact_available":false}).get("rarity", null))
	check(a == b and not a.has(null) and not a.has(&"unique") and not a.has(&"artifact"), "seed deterministic and unavailable rarities not returned")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save after rarity draws")
	var next := ask(&"ItemRarityRollRequested", {"unique_available":true,"artifact_available":true})
	check(ask(&"SessionLoadRequested", {}).get("accepted", false), "restore RNG state")
	var replay := ask(&"ItemRarityRollRequested", {"unique_available":true,"artifact_available":true})
	check(next.get("rarity", null) == replay.get("rarity", null) and next.get("draws", null) == replay.get("draws", null), "restored RNG repeats roll")
	print("Rarity roll tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
