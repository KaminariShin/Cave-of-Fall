extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(80,80)}).get("accepted",false) and ask(&"RoomCreateRequested",{"id":&"A","type":"start","origin_cell":Vector2i(1,1),"size_cells":Vector2i(11,11)}).get("accepted",false),"room")
	check(root.get_node("EntityRegistry").create_entity(&"hero",{&"stats":{"CON":100,"PER":30}}),"hero")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(25,22),"size":2}).get("accepted",false) and ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false) and ask(&"RoomEnterRequested",{"entity":&"hero","room":&"A"}).get("accepted",false),"hero position")
	check(root.get_node("EntityRegistry").create_entity(&"archer",{&"stats":{"PER":30}}),"archer")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"archer","anchor":Vector2i(10,22),"size":2}).get("accepted",false) and ask(&"InventoryConfigureRequested",{"entity":&"archer","volume":100}).get("accepted",false),"archer body")
	check(ask(&"ItemCreateRequested",{"id":&"bow","base_id":&"bow_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":&"archer","item":&"bow"}).get("accepted",false) and ask(&"EquipmentEquipRequested",{"entity":&"archer","item":&"bow","slot":"main"}).get("accepted",false),"equip bow")
	check(driver.wait_for(0.1) and driver.advance_steps(10)==10,"finish equip")
	var agent := {"entity":&"archer","room":&"A","role":"melee","target":&"hero","detected":false,"wait_duration":0.05,"weapon":{"item":&"bow","strike":"bow_simple_shot"},"movement":{"actor_type":"goblin"}}
	check(ask(&"AIRegisterRequested",agent).get("accepted",false) and ask(&"DetectionHostilitySetRequested",{"a":&"archer","b":&"hero","hostile":true}).get("accepted",false),"register bow AI")
	var ai = root.get_node("AIService")
	var weapon_agent: Dictionary = ask(&"AIGetRequested",{"entity":&"archer"})["data"]
	var wall_tiles := [Vector2i(19,22),Vector2i(19,23)]
	check(ask(&"SpaceTilesSetRequested",{"tiles":wall_tiles,"kind":0}).get("accepted",false),"wall")
	check(ai._bow_attack(&"archer",&"hero",weapon_agent)==0 and not ask(&"BowShotStatusRequested",{"entity":&"archer"}).get("active",false),"AI does not shoot through wall")
	check(ask(&"SpaceTilesSetRequested",{"tiles":wall_tiles,"kind":1}).get("accepted",false),"clear wall")
	var hp: float=ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"HP"})["data"]["current"]
	var observed := {"shots":0}
	var on_shot := func(e):
		if e.get("entity",null)==&"archer" and e.get("decision","")=="bow_shot": observed["shots"]+=1
	bus.subscribe(&"AIDecision",on_shot)
	check(driver.wait_for(3.0) and driver.advance_steps(10)==10,"simulation starts")
	check(observed["shots"]>=1 and ask(&"BowShotStatusRequested",{"entity":&"archer"}).get("active",false),"AI starts bow shot " + str(observed))
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save draw")
	check(driver.advance_steps(180)==180 and ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"HP"})["data"]["current"]<hp,"AI arrow hits hero")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and driver.advance_steps(180)==180 and ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"HP"})["data"]["current"]<hp,"restored shot hits")
	bus.unsubscribe(&"AIDecision",on_shot)
	print("AI bow: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
