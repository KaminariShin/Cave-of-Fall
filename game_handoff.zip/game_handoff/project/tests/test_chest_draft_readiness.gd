extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11)}).get("accepted",false), "chest")
	check(not ask(&"ChestDraftReadinessRequested", {"object":&"chest"}).get("accepted",true), "no plan rejected")
	var state := {"calls":0}
	var rng := func(e):
		state["calls"] += 1
		e["value"] = 700 if state["calls"] in [5,9,13,17] else e["min"]
	bus.subscribe(&"RngIntRequested",rng)
	var attached := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	bus.unsubscribe(&"RngIntRequested",rng)
	check(attached.get("accepted",false), "magic draft")
	if not attached.get("accepted",false): quit(1); return
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var result := ask(&"ChestDraftReadinessRequested", {"object":&"chest"})
	check(result.get("accepted",false) and not result.get("plain_supported",true) and not result.get("consumables_only",true) and result.get("slots",[]).size() == 4, "magic diagnosed")
	check(result.get("unsupported_mod_ids",[]) == [], "generated mods have implemented effects")
	check(result["slots"][0]["unsupported_mod_ids"] == result["unsupported_mod_ids"] and not result["slots"][0]["plain_supported"], "per-slot details")
	check(before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "query leaves world and RNG unchanged")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ChestDraftReadinessRequested", {"object":&"chest"}).get("unsupported_mod_ids",[]) == result["unsupported_mod_ids"], "save/load")
	check(not ask(&"ChestPlainDraftMaterializeRequested", {"object":&"chest", "item_ids":[&"a",&"b",&"c",&"d"]}).get("accepted",true), "readiness never materializes magic")
	check(ask(&"ObjectCreateRequested", {"entity":&"plain", "type":"chest", "room":&"room", "tile":Vector2i(20,20)}).get("accepted",false), "plain chest")
	var values := [4,0,0,2,0,40,0,0,17,3,0,40,0,2,3]
	var plain_rng := func(e):
		if not values.is_empty(): e["value"] = values.pop_front()
	bus.subscribe(&"RngIntRequested",plain_rng)
	var normal := ask(&"DungeonChestDraftAttachRequested", {"object":&"plain", "kind":"boss", "depth":4})
	bus.unsubscribe(&"RngIntRequested",plain_rng)
	check(normal.get("accepted",false), "normal mixed plan")
	var normal_result := ask(&"ChestDraftReadinessRequested", {"object":&"plain"})
	check(normal_result.get("accepted",false) and normal_result.get("plain_supported",false) and not normal_result.get("consumables_only",true) and normal_result.get("unsupported_mod_ids",[1]).is_empty(), "mixed normal is plain-supported")
	check(ask(&"InventoryConfigureRequested", {"entity":&"plain", "volume":10}).get("accepted",false) and ask(&"ChestPlainDraftMaterializeRequested", {"object":&"plain", "item_ids":[&"p1",&"p2",&"p3",&"p4"]}).get("accepted",false), "plain supported plan materializes")
	check(not ask(&"ChestDraftReadinessRequested", {"object":&"plain"}).get("accepted",true), "finished plan unavailable")
	print("Chest draft readiness tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
