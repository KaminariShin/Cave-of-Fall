extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e);return e
func key(game: Node,k: Key) -> void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save";var had:=FileAccess.file_exists(path);var old:=PackedByteArray()
	if had:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized,"demo started")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"disable enemy in interface test")
	key(game,KEY_B);key(game,KEY_LEFT)
	check(game.message.contains("щит") and not ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",true),"no shield cannot start")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open inventory")
	var inv:Array=ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]
	check(game._use_inventory_item(inv.find(&"demo_shield")) and driver.advance_steps(10)==10,"equip shield")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close inventory")
	game.facing=Vector2i.LEFT
	var t:float=driver.game_time
	key(game,KEY_B);key(game,KEY_LEFT)
	var active:=ask(&"ShieldBlockStatusRequested",{"entity":game.HERO})
	check(active.get("active",false) and active.get("item",null)==&"demo_shield" and active.get("slot","")=="off" and Vector2(active.get("direction",Vector2.ZERO))==Vector2.LEFT,"key starts shield in facing direction")
	check(not game._start_attack() and not game._start_shield_block(),"block occupies action")
	check(driver.advance_steps(20)==20 and ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save active block")
	# Эмулируем старый формат версии 0.192 с кардинальным Vector2i.
	var saver=root.get_node("SaveService")
	var legacy:Dictionary=saver._read(path)
	legacy["ruleset_version"]="0.192.0"
	legacy["sections"]["shield_block_actions"][game.HERO]["direction"]=Vector2i.LEFT
	var written:Dictionary={}
	saver._write(written,path,legacy)
	check(written.get("accepted",false),"write legacy block save")
	check(driver.advance_steps(30)==30 and not ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",true),"block ends after 0.5 seconds")
	check(absf(driver.game_time-t-0.5)<0.000001,"duration")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load active block")
	active=ask(&"ShieldBlockStatusRequested",{"entity":game.HERO})
	check(active.get("active",false) and Vector2(active.get("direction",Vector2.ZERO))==Vector2.LEFT and driver.advance_steps(30)==30 and not ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",true),"restored block ends once")
	game.facing=Vector2i.UP
	check(game._start_shield_block() and driver.advance_steps(5)==5 and ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false) and not ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",true),"block can be interrupted")
	check(game._start_shield_block(Vector2.LEFT) and driver.advance_steps(20)==20,"begin block for repeat key")
	key(game,KEY_B)
	check(driver._action_steps==100 and game.message.contains("продлён"),"B extends current block without direction selection")
	check(driver.advance_steps(30)==30 and ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",false),"extended block stays active past original end")
	check(driver.advance_steps(50)==50 and not ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",true),"extended block finishes")
	game.queue_free();await process_frame
	if had:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo shield block: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
