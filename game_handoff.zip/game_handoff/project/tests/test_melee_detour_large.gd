extends SceneTree
var failures := 0
var visited: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func hp(id: StringName) -> float:
	return float(ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	root.get_node("EventBus").subscribe(&"MovementCompleted",func(e): if e.get("entity",null) == &"enemy": visited.append(e["to"]))
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(80,80)}).get("accepted",false),"map")
	check(ask(&"RoomCreateRequested",{"id":&"r","type":"start","origin_cell":Vector2i(1,1),"size_cells":Vector2i(11,11)}).get("accepted",false),"room")
	check(ask(&"EntityCreateRequested",{"entity":&"hero","components":{&"stats":{"CON":100,"PER":30}}}).get("accepted",false),"hero")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(30,20),"size":4}).get("accepted",false),"hero body")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"RoomEnterRequested",{"entity":&"hero","room":&"r"}).get("accepted",false),"enter")
	check(ask(&"EntityCreateRequested",{"entity":&"blocker"}).get("accepted",false),"blocker")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"blocker","anchor":Vector2i(19,19),"size":4}).get("accepted",false),"blocking body")
	check(ask(&"EntityCreateRequested",{"entity":&"enemy","components":{&"stats":{"PER":30}}}).get("accepted",false),"enemy")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"enemy","anchor":Vector2i(10,18),"size":6}).get("accepted",false),"enemy body")
	check(ask(&"ItemCreateRequested",{"id":&"sword","base_id":&"sword_simple","item_level":1}).get("accepted",false),"sword")
	check(ask(&"ComponentSetRequested",{"entity":&"enemy","component":&"equipment","data":{"main":&"sword"}}).get("accepted",false),"equip")
	check(ask(&"AIRegisterRequested",{"entity":&"enemy","room":&"r","role":"melee","target":&"hero","wait_duration":0.1,"weapon":{"item":&"sword","strike":"sword_simple_thrust"},"movement":{"actor_type":"goblin"}}).get("accepted",false),"register")
	check(ask(&"DetectionHostilitySetRequested",{"a":&"enemy","b":&"hero","hostile":true}).get("accepted",false),"hostility")
	var start_hp := hp(&"hero")
	check(driver.wait_for(8.0) and driver.advance_steps(40) == 40,"start")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save during pursuit")
	check(driver.advance_steps(600) == 600,"advance pursuit")
	var finish_hp := hp(&"hero")
	check(finish_hp < start_hp,"enemy gets around body and hits: " + str([start_hp,finish_hp,visited]))
	var detour := false
	for tile in visited:
		if tile.y <= 13 or tile.y >= 23: detour = true
	check(detour,"uses detour " + str(visited))
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load pursuit")
	check(driver.advance_steps(600) == 600 and hp(&"hero") == finish_hp,"same combat after reload")
	print("Large melee detour: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
