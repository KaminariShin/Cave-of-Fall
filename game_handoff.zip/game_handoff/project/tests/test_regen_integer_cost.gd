extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func res(id: StringName) -> Dictionary:
	return ask(&"ResourceGetRequested", {"entity":&"hero","resource":id})["data"]
func setres(id: StringName,value: float) -> void:
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":id,"value":value}).get("accepted",false),"set resource")
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(root.get_node("EntityRegistry").create_entity(&"hero", {&"stats":{"CON":10}}),"create")
	var service = root.get_node("ResourceService")
	setres(&"HP",50)
	setres(&"Stamina",20)
	for row in [[19,0.25],[18,0.5],[17,0.75],[15,0.0]]:
		service._regen_cycle(&"hero",&"HP")
		check(res(&"Stamina")["current"] == row[0] and is_equal_approx(res(&"HP")["cost_remainder"],row[1]),"whole cost and carry " + str(row))
	check(res(&"HP")["current"] == 52,"four heals accumulated")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"CON","value":20}).get("accepted",false),"high constitution")
	var scaled_hp: float = res(&"HP")["current"]
	check(scaled_hp == 89,"HP percentage preserved after CON increase")
	setres(&"Stamina",1)
	service._regen_cycle(&"hero",&"HP")
	var hp := res(&"HP")
	check(hp["reserve"] == 2 and hp["reserve_filled"] == 1 and hp["cost_remainder"] == 0 and hp["reserve_cost_remainder"] == 0.5 and res(&"Stamina")["current"] == 0,"integer pending reserve")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save pending")
	var pending_snapshot: Dictionary = root.get_node("SaveService").collect_world_transition_snapshot()["payload"]
	for key in ["reserve","reserve_filled","reserve_cost_remainder"]:
		var broken_pending: Dictionary = pending_snapshot.duplicate(true)
		broken_pending["sections"]["entities"][&"hero"][&"resources"][&"HP"][key] = 0.5 if key != "reserve_cost_remainder" else 1.0
		check(not root.get_node("SaveService")._validate_snapshot(broken_pending),"reject broken pending " + key)
	service._regen_cycle(&"hero",&"Stamina")
	hp = res(&"HP")
	check(hp["reserve"] == 0 and hp["cost_remainder"] == 0.5 and hp["current"] == scaled_hp + 1 and res(&"Stamina")["current"] == 2 and res(&"Stamina")["remainder"] == 0.5,"reserve paid with whole regen then heal")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and res(&"HP")["reserve_filled"] == 1,"restore pending")
	setres(&"HP",res(&"HP")["max"])
	hp = res(&"HP")
	check(hp["reserve"] == 0 and hp["cost_remainder"] == 0 and not hp.has("reserve_cost_remainder") and res(&"Stamina")["current"] == 1,"cancel pending refunds and discards staged remainder")
	var saver = root.get_node("SaveService")
	var snapshot: Dictionary = saver.collect_world_transition_snapshot()["payload"]
	for value in [-0.1,1.0,INF,null]:
		var broken: Dictionary = snapshot.duplicate(true)
		broken["sections"]["entities"][&"hero"][&"resources"][&"HP"]["cost_remainder"] = value
		check(not saver._validate_snapshot(broken),"reject invalid cost remainder")
	print("Regen integer cost tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
