extends SceneTree
var failures := 0
var bus: Node
var driver: Node
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	bus.publish(id, data)
	return data
func _initialize() -> void: call_deferred("run")
func run() -> void:
	bus = root.get_node("EventBus")
	driver = root.get_node("TimeDriver")
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized, "demo initializes")
	var ai := ask(&"AIGetRequested", {"entity":game.RAT})
	check(ai.get("found",false) and ai.get("data",{}).get("role","") == "melee" and ai["data"].get("weapon",{}).get("item",null) == &"demo_rat_sword", "demo enemy uses common melee AI")
	check(not ask(&"FogStateGetRequested", {}).get("visible_tiles", []).is_empty(), "terrain visible through fog")
	check(ask(&"SpaceRegionGetRequested", {"origin":Vector2i(48,48),"size":Vector2i(44,44)}).get("floor",{}).has(Vector2i(54,60)), "rendered region includes floor")
	check(not ask(&"SessionSaveRequested", {}).get("accepted", false), "normal save slot protected")
	check(not ask(&"SessionLoadRequested", {}).get("accepted", false), "normal load slot protected")
	check(not ask(&"SessionDeleteOnDeathCheckRequested", {"entity":game.HERO,"allowed":true})["allowed"], "demo protects unrelated session on death")
	# Искусственная лестница не имеет необходимого контекста настоящего спуска.
	check(ask(&"ObjectCreateRequested", {"entity":&"demo_test_stairs", "type":"stairs_down", "room":game.ROOM, "tile":Vector2i(58,60)}).get("accepted", false), "test stair")
	root.get_node("DungeonStairsService").set("_state", {"floor":1, "room":game.ROOM, "status":"placed", "object":&"demo_test_stairs"})
	check(not game._interact_chest() and game.message.contains("Спуск недоступен"), "demo reports blocked descent")
	check(ask(&"ObjectRemoveRequested", {"object":&"demo_test_stairs"}).get("accepted", false), "remove test stair")
	root.get_node("DungeonStairsService").set("_state", {})
	var initial_stamina: float = ask(&"ResourceGetRequested", {"entity":game.HERO,"resource":&"Stamina"})["data"]["current"]
	check(ask(&"ResourceSetRequested", {"entity":game.HERO,"resource":&"Stamina","value":0}).get("accepted",false), "empty stamina for negative test")
	check(not game._start_attack(), "no free attack without stamina")
	check(ask(&"ResourceSetRequested", {"entity":game.HERO,"resource":&"Stamina","value":initial_stamina}).get("accepted",false), "restore stamina")
	check(game._move(Vector2i.RIGHT), "movement begins")
	driver.advance_steps(100)
	check(ask(&"SpaceBodyGetRequested", {"entity":game.HERO})["data"]["anchor"] == Vector2i(55,60), "movement ends")
	check(ask(&"SpaceBodyMoveRequested", {"entity":game.HERO, "anchor":Vector2i(62,60)}).get("accepted",false), "approach rat")
	var initial_hp: float = ask(&"ResourceGetRequested", {"entity":game.HERO,"resource":&"HP"})["data"]["current"]
	for i in range(6):
		check(game._wait(), "wait starts time")
		driver.advance_steps(100)
		if float(ask(&"ResourceGetRequested", {"entity":game.HERO,"resource":&"HP"})["data"]["current"]) < initial_hp: break
	check(float(ask(&"ResourceGetRequested", {"entity":game.HERO,"resource":&"HP"})["data"]["current"]) < initial_hp, "common melee AI actually damages player")
	check(ask(&"DetectionPairGetRequested", {"observer":game.RAT, "target":game.HERO}).get("detected",false), "real AI detects hero")
	check(ask(&"AIUnregisterRequested", {"entity":game.RAT}).get("accepted", false), "disable AI for deterministic combat")
	check(ask(&"SpaceBodyMoveRequested", {"entity":game.RAT, "anchor":Vector2i(70,60)}).get("accepted",false), "restore rat position")
	check(ask(&"SpaceBodyMoveRequested", {"entity":game.HERO, "anchor":Vector2i(62,60)}).get("accepted",false), "position for attack")
	game.facing = Vector2i.RIGHT
	var raw_damage_calls := {"count":0}
	var raw_damage_cb := func(_e): raw_damage_calls["count"] += 1
	bus.subscribe(&"StrikeZoneDamageRequested",raw_damage_cb)
	for i in range(8):
		var dead := ask(&"CombatEntityCanActRequested", {"entity":game.RAT,"allowed":true})
		if not dead.get("allowed",true): break
		var stamina_before: float = ask(&"ResourceGetRequested", {"entity":game.HERO,"resource":&"Stamina"})["data"]["current"]
		check(game._start_attack(), "attack starts %d" % i)
		check(ask(&"ActionGetRequested", {"entity":game.HERO}).get("data",{}).get("id",null) == &"weapon_strike", "real weapon action")
		check(float(ask(&"ResourceGetRequested", {"entity":game.HERO,"resource":&"Stamina"})["data"]["current"]) < stamina_before, "attack spends stamina")
		driver.advance_steps(200)
	bus.unsubscribe(&"StrikeZoneDamageRequested",raw_damage_cb)
	check(raw_damage_calls["count"] == 0, "demo does not apply direct scripted damage")
	var dead := ask(&"CombatEntityCanActRequested", {"entity":game.RAT,"allowed":true})
	check(not dead.get("allowed",true), "rat dies from actual attacks")
	check(ask(&"RunStatisticsGetRequested", {}).get("data", {}).get("kills", 0) == 1, "demo kill counted")
	var loot := ask(&"LootGetRequested", {})
	check(loot.get("items", {}).has(&"demo_trophy"), "real inventory item drops")
	if loot.get("items", {}).has(&"demo_trophy"):
		var tile: Vector2i = loot["items"][&"demo_trophy"]["tile"]
		check(ask(&"SpaceBodyMoveRequested", {"entity":game.HERO,"anchor":tile}).get("accepted",false), "move onto loot")
		# Меч и трофей могут лежать вместе: выбираем нужный предмет.
		for i in range(3):
			if ask(&"InventoryGetRequested", {"entity":game.HERO})["data"]["items"].has(&"demo_trophy"): break
			check(game._pickup(), "pickup starts")
			if game._pickup_open: check(game._pickup_item(&"demo_trophy"), "select trophy")
			driver.advance_steps(100)
		check(ask(&"InventoryGetRequested", {"entity":game.HERO})["data"]["items"].has(&"demo_trophy"), "trophy enters inventory")
		if game._pickup_open: game._pickup_close()
	# Цель не зашита в демосцену: настоящая фаза находит другое тело.
	check(ask(&"EntityCreateRequested", {"entity":&"test_target","components":{&"stats":{"CON":100}}}).get("accepted",false), "second target")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"test_target","anchor":Vector2i(68,58),"size":2}).get("accepted",false), "second target body")
	check(ask(&"SpaceBodyMoveRequested", {"entity":game.HERO,"anchor":Vector2i(62,58)}).get("accepted",false), "position at second target")
	var other_hp: float = ask(&"ResourceGetRequested", {"entity":&"test_target","resource":&"HP"})["data"]["current"]
	game.facing = Vector2i.RIGHT
	check(game._start_attack(), "attack second target")
	driver.advance_steps(200)
	check(float(ask(&"ResourceGetRequested", {"entity":&"test_target","resource":&"HP"})["data"]["current"]) < other_hp, "weapon phase can hit another entity")
	check(ask(&"EntityRemoveRequested", {"entity":&"test_target"}).get("accepted",false), "remove test target")
	check(game._toggle_inventory(), "inventory opens")
	driver.advance_steps(10)
	check(game.inventory_open, "inventory open state")
	var initial_items: Array = ask(&"InventoryGetRequested", {"entity":game.HERO})["data"]["items"]
	check(initial_items.has(&"demo_potion_hp"), "starter potion")
	check(ask(&"ResourceSetRequested", {"entity":game.HERO, "resource":&"HP", "value":10}).get("accepted", false), "hurt hero")
	check(initial_items.find(&"demo_potion_hp") == 0, "first inventory entry")
	var key := InputEventKey.new()
	key.pressed = true
	key.keycode = KEY_1
	game._unhandled_key_input(key)
	check(ask(&"ActionGetRequested", {"entity":game.HERO}).get("data", {}).get("id", &"") == &"consumable_use", "number key starts potion from inventory")
	check(not ask(&"ItemGetRequested", {"item":&"demo_potion_hp"}).get("found", false), "potion consumed")
	driver.advance_steps(50)
	check(float(ask(&"ResourceGetRequested", {"entity":game.HERO, "resource":&"HP"})["data"]["current"]) >= 30, "potion heals through real action")
	check(not game._use_inventory_item(8), "invalid item position rejected")
	check(game._unequip_hand("main"), "unequip starting sword")
	driver.advance_steps(10)
	check(game._toggle_inventory(), "close inventory without sword")
	driver.advance_steps(10)
	check(not game._start_attack(), "no attack without equipped weapon")
	check(game._toggle_inventory(), "reopen inventory")
	driver.advance_steps(10)
	var inventory: Array = ask(&"InventoryGetRequested", {"entity":game.HERO})["data"]["items"]
	check(inventory.has(&"demo_sword"), "starting sword enters inventory")
	check(game._use_inventory_item(inventory.find(&"demo_sword")), "equip sword from inventory")
	driver.advance_steps(10)
	check(ask(&"ComponentGetRequested", {"entity":game.HERO, "component":&"equipment"})["data"].get("main", null) == &"demo_sword", "sword equipped")
	inventory = ask(&"InventoryGetRequested", {"entity":game.HERO})["data"]["items"]
	check(game._use_inventory_item(inventory.find(&"demo_shield")), "equip shield")
	driver.advance_steps(10)
	check(ask(&"EquipmentArmourGetRequested", {"entity":game.HERO}).get("armour", 0) == 5.0, "shield grants armour")
	check(game._unequip_hand("off"), "unequip shield")
	driver.advance_steps(10)
	check(ask(&"InventoryGetRequested", {"entity":game.HERO})["data"]["items"].has(&"demo_shield"), "shield returns to inventory")
	check(game._toggle_inventory(), "inventory closes")
	driver.advance_steps(10)
	check(not game.inventory_open, "inventory closed state")
	check(ask(&"SpaceBodyMoveRequested", {"entity":game.HERO,"anchor":Vector2i(55,70)}).get("accepted",false), "position near chest")
	check(game._interact_chest(), "chest interaction starts")
	driver.advance_steps(20)
	check(ask(&"ObjectGetRequested", {"object":game.CHEST})["data"]["opened"], "chest opens")
	check(ask(&"SpaceBodyMoveRequested", {"entity":game.HERO,"anchor":Vector2i(87,68)}).get("accepted",false), "position at passage")
	for i in range(5):
		check(game._move(Vector2i.RIGHT), "passage movement %d" % i)
		driver.advance_steps(100)
	var exit_data: Dictionary = ask(&"RoomGetRequested", {"id":game.ROOM})["data"]["exits"][0]
	check(exit_data["connected"], "lazy child generated")
	check(game.current_room != game.ROOM, "entered generated room")
	var stats: Dictionary = ask(&"RunStatisticsGetRequested", {}).get("data", {})
	check(stats.get("rooms", 0) >= 2 and float(stats.get("depth", 0.0)) >= 1.2, "demo room and depth tracked")
	var floor_depth := ask(&"DungeonRoomDepthRequested", {"room":game.current_room})
	check(floor_depth.get("accepted", false) and floor_depth.get("distance", 0) >= 1, "demo milestone tracker uses real generated graph")
	print("Game demo tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	game.queue_free()
	await process_frame
	quit(0 if failures == 0 else 1)
