extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(v: bool, text: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",text)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func click(game: Control, pos: Vector2) -> void:
	var e := InputEventMouseButton.new(); e.position=game.get_global_transform_with_canvas()*pos; e.button_index=MOUSE_BUTTON_LEFT; e.pressed=true; game._input(e)
func key(game: Node, k: Key) -> void:
	var e := InputEventKey.new(); e.keycode=k; e.pressed=true; game._unhandled_key_input(e)
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	var game = load("res://game_demo.tscn").instantiate(); root.add_child(game); await process_frame
	game.size = Vector2(1280,720)
	check(game.initialized,"initialized")
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	for id in [&"chosen_potion_a",&"chosen_potion_b"]:
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false),"create")
		check(ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"add")
	click(game,game._inventory_button_rect().get_center()); check(driver.advance_steps(1)==1 and game.inventory_open,"open")
	# Кнопка режима и отмена — предмет остаётся на месте.
	click(game,game._inventory_toolbar_rect(5).get_center()); check(game._drop_mode,"drop mode")
	var index: int = game._inventory_items().find(&"chosen_potion_a")
	click(game,game._inventory_cell_rect(index).get_center())
	check(game._drop_pick.get("item",null)==&"chosen_potion_a","choose item")
	click(game,game._drop_cancel_rect().get_center())
	check(game._inventory_items().has(&"chosen_potion_a") and game._drop_pick.is_empty(),"cancel keeps item")
	# Первый сброс и сохранение на середине действия.
	click(game,game._inventory_cell_rect(index).get_center())
	var tile: Vector2i = game._drop_pick["tile"]
	click(game,game._drop_confirm_rect().get_center())
	check(driver.advance_steps(5)==5 and game._inventory_items().has(&"chosen_potion_a"),"pending drop keeps ownership")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save during drop")
	check(driver.advance_steps(5)==5 and ask(&"LootGetRequested",{})["items"].has(&"chosen_potion_a"),"drop completes")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load during drop")
	check(game._inventory_items().has(&"chosen_potion_a") and not ask(&"LootGetRequested",{})["items"].has(&"chosen_potion_a"),"pending restored without duplicates")
	check(driver.advance_steps(5)==5 and ask(&"LootGetRequested",{})["items"].has(&"chosen_potion_a"),"restored drop completes once")
	# Второй предмет — клавиатурный режим G и выбранная ячейка.
	key(game,KEY_G)
	index=game._inventory_items().find(&"chosen_potion_b")
	game.inventory_page=int(index/9)
	key(game,(KEY_1+index%9) as Key)
	check(game._drop_pick.get("item",null)==&"chosen_potion_b","keyboard chooses second item")
	key(game,KEY_F)
	check(driver.advance_steps(10)==10 and ask(&"LootGetRequested",{})["items"].has(&"chosen_potion_b"),"second drop")
	check(ask(&"LootGetRequested",{})["items"][&"chosen_potion_b"]["tile"]==tile,"both items on same tile")
	click(game,game._inventory_toolbar_rect(4).get_center()); check(driver.advance_steps(1)==1 and not game.inventory_open,"close inventory")
	key(game,KEY_E)
	check(game._pickup_open and game._pickup_candidates().has(&"chosen_potion_a") and game._pickup_candidates().has(&"chosen_potion_b"),"choose from ground")
	var ids: Array=game._pickup_candidates()
	var chosen: int=ids.find(&"chosen_potion_b")
	var used: float=ask(&"InventoryGetRequested",{"entity":game.HERO})["used_volume"]
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":used}).get("accepted",false),"fill inventory")
	click(game,game._pickup_row_rect(chosen).get_center())
	check(not driver.is_action_active and game._pickup_open and ask(&"LootGetRequested",{})["items"].has(&"chosen_potion_b") and not game._inventory_items().has(&"chosen_potion_b"),"full inventory does not start pickup")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":100.0}).get("accepted",false),"restore capacity")
	ids=game._pickup_candidates(); chosen=ids.find(&"chosen_potion_b")
	click(game,game._pickup_row_rect(chosen).get_center())
	check(game._pickup_open and driver.advance_steps(35)==35 and game._pickup_open,"window remains open when loot remains")
	check(game._inventory_items().has(&"chosen_potion_b") and not game._inventory_items().has(&"chosen_potion_a") and ask(&"LootGetRequested",{})["items"].has(&"chosen_potion_a"),"selected item only")
	click(game,game._pickup_row_rect(0).get_center())
	check(driver.advance_steps(35)==35 and not game._pickup_open and game._inventory_items().has(&"chosen_potion_a"),"last item closes empty window")
	game.queue_free(); await process_frame
	print("Game demo loot selection and dropping: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
