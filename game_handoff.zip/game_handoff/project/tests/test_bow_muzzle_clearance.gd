extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func launch()->Dictionary:
	return ask(&"ProjectileLaunchRequested",{"entity":&"hero","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":7.0})
func start()->Dictionary:return ask(&"BowShotStartRequested",{"entity":&"hero","item":&"bow","direction":Vector2.RIGHT})
func run()->void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(35,25)}).get("accepted",false),"map")
	var tiles:Array=[]
	for x in range(35):
		for y in range(25):tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"blocker"]:check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"controlled")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(2,5),"size":2}).get("accepted",false),"hero body")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"blocker","anchor":Vector2i(7,5),"size":2}).get("accepted",false),"blocker body before muzzle")
	check(ask(&"ItemCreateRequested",{"id":&"bow","base_id":&"bow_simple","item_level":1}).get("accepted",false),"bow")
	check(ask(&"ComponentSetRequested",{"entity":&"hero","component":&"equipment","data":{"main":&"bow"}}).get("accepted",false),"equip bow")
	var hp:float=ask(&"ResourceGetRequested",{"entity":&"blocker","resource":&"HP"})["data"]["current"]
	var stamina:float=ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"Stamina"})["data"]["current"]
	check(not launch().get("accepted",true),"body cannot be skipped by technical launch")
	check(not start().get("accepted",true),"body blocks shot before payment")
	check(ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"Stamina"})["data"]["current"]==stamina and ask(&"ResourceGetRequested",{"entity":&"blocker","resource":&"HP"})["data"]["current"]==hp,"denial has no damage or stamina cost")
	check(ask(&"SpaceBodyMoveRequested",{"entity":&"blocker","anchor":Vector2i(12,5)}).get("accepted",false),"move away")
	check(ask(&"ItemCreateRequested",{"id":&"shield","base_id":&"shield_small","item_level":1}).get("accepted",false),"shield")
	check(ask(&"ComponentSetRequested",{"entity":&"blocker","component":&"equipment","data":{"off":&"shield"}}).get("accepted",false),"equip shield")
	check(ask(&"ShieldBlockStartRequested",{"entity":&"blocker","slot":"off","direction":Vector2.LEFT}).get("accepted",false),"block active")
	var zone:Dictionary=ask(&"ShieldBlockZoneRequested",{"entity":&"blocker"})
	var t:Vector2i=zone["data"]["tiles"][0]
	# Test a shield that reaches the muzzle using a longer configurable gap.
	var shield_ray:Dictionary=root.get_node("ProjectileService")._bow_start_obstacle(Vector2(3,float(t.y)+0.5),Vector2.RIGHT,float(t.x)-3.0,&"hero")
	check(shield_ray.get("kind","")=="shield" and shield_ray.get("entity",null)==&"blocker","active shield at muzzle prevents bypass")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[Vector2i(6,6)],"kind":0}).get("accepted",false),"wall")
	check(not start().get("accepted",true) and not launch().get("accepted",true),"wall denies shot")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[Vector2i(6,6)],"kind":1}).get("accepted",false),"restore")
	check(ask(&"ActionCancelRequested",{"entity":&"blocker","reason":&"test"}).get("accepted",false),"cancel block")
	var releases:Array=[]
	var listen:=func(e): releases.append(e.duplicate(true))
	root.get_node("EventBus").subscribe(&"BowShotReleased",listen)
	var shot:=start()
	check(shot.get("accepted",false),"clear start")
	check(ask(&"SpaceBodyMoveRequested",{"entity":&"blocker","anchor":Vector2i(7,5)}).get("accepted",false),"obstacle enters during preparation")
	if shot.get("accepted",false):
		var midpoint:int=ceili(float(shot["data"]["duration_steps"])/2.0)
		check(driver.advance_steps(midpoint)==midpoint and releases.size()==1 and not releases[0].get("accepted",true),"release rechecks obstacle")
		check(ask(&"ResourceGetRequested",{"entity":&"blocker","resource":&"HP"})["data"]["current"]==hp,"moving blocker not bypassed or damaged")
	check(ask(&"ActionCancelRequested",{"entity":&"hero","reason":&"test"}).get("accepted",false),"cancel")
	root.get_node("EventBus").unsubscribe(&"BowShotReleased",listen)
	print("Bow muzzle clearance: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
