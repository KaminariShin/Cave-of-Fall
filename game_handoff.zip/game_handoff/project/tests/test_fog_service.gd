extends SceneTree
var failures := 0
var detections: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	bus.subscribe(&"EntityDetected", func(event): detections.append(event.duplicate()))
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(200, 200)})["accepted"], "map")
	ask(bus, &"RngSeedRequested", {"seed": 42})
	check(ask(bus, &"RoomCreateRequested", {"id": &"start", "type": "start", "origin_cell": Vector2i(2, 2), "size_cells": Vector2i(11, 11)})["accepted"], "start")
	check(ask(bus, &"RoomExitAddRequested", {"room": &"start", "id": &"east", "dir": "east", "offset_cells": 5})["accepted"], "exit")
	check(entities.create_entity(&"hero"), "hero")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "controlled")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(20, 20), "size": 4})["accepted"], "place")
	check(ask(bus, &"RoomEnterRequested", {"entity": &"hero", "room": &"start"})["accepted"], "enter start")
	var unknown_radius := ask(bus, &"FogStateGetRequested", {})
	check(unknown_radius["known_rooms"].size() == 1 and unknown_radius["radius_known"] and unknown_radius["radius"] == 5.0, "PER-based radius from detection service")
	check(not ask(bus, &"FogDetectionRadiusSetRequested", {"entity": &"hero", "radius": -1.0})["accepted"], "invalid radius")
	check(ask(bus, &"FogDetectionRadiusSetRequested", {"entity": &"hero", "radius": 4.0})["accepted"], "set temporary radius")
	var near := ask(bus, &"FogTileGetRequested", {"tile": Vector2i(22, 22)})
	var far := ask(bus, &"FogTileGetRequested", {"tile": Vector2i(35, 35)})
	check(near["room_known"] and near["terrain_visible"], "near tile visible")
	check(far["room_known"] and not far["terrain_visible"], "distant tile hidden but room geometry known")
	var hidden := ask(bus, &"FogTileGetRequested", {"tile": Vector2i(52, 29)})
	check(not hidden["room_known"] and not hidden["terrain_visible"], "next room unknown")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(44, 28)})["accepted"], "move to passage")
	check(not ask(bus, &"FogTileGetRequested", {"tile": Vector2i(22, 22)})["terrain_visible"], "visibility follows player")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(48, 28)})["accepted"], "touch passage")
	var opened := ask(bus, &"FogTileGetRequested", {"tile": Vector2i(52, 29)})
	check(opened["room_known"] and opened["terrain_visible"], "passage opens next room and radius applies")
	var state := ask(bus, &"FogStateGetRequested", {})
	check(state["known_rooms"].size() == 2 and state["visible_tiles"].has(Vector2i(52, 29)), "state includes geometry and visible cells")
	check(detections.is_empty(), "fog does not publish entity detection")
	var save := ask(bus, &"SessionSaveRequested", {})
	check(save.get("accepted", false), "save: " + str(save))
	ask(bus, &"FogDetectionRadiusSetRequested", {"entity": &"hero", "radius": 0.0})
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load")
	var after := ask(bus, &"FogStateGetRequested", {})
	check(after["radius"] == 4.0 and after["known_rooms"].size() == 2 and after["visible_tiles"].has(Vector2i(52, 29)), "radius and room discovery restored")
	ask(bus, &"DetectionRadiusChanged", {"entity": &"hero", "radius": 1.0})
	check(not ask(bus, &"FogTileGetRequested", {"tile": Vector2i(52, 29)})["terrain_visible"], "future detection service updates radius")
	print("Fog tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
