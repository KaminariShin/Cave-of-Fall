extends SceneTree
var failures := 0
var arrivals: Array = []
var repositions: Array = []
var reposition_failures: Array = []
var batch_guards := false
func _initialize() -> void: call_deferred("run_tests")
func check(v: bool, message: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", message)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name,data)
	return data
func mob_def() -> Dictionary:
	return {"id":"queue_test", "type_weight":0.1, "species":{"id":"test", "species_weight":0.2}, "tags":[{"id":"boss", "tag_weight":0.1}], "base_stats":{"CON":10,"STR":10,"DEX":10,"INT":10,"WIS":10,"PER":10}, "growth_per_level":{"CON":2,"STR":2,"DEX":2,"INT":2,"WIS":2,"PER":2}, "body_size":2,"min_depth":0,"max_depth":null}
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"SpawnQueueMobSpawned", func(e): arrivals.append(e.duplicate(true)))
	bus.subscribe(&"RoomRepositioned", func(e): repositions.append(e.duplicate(true)))
	bus.subscribe(&"RoomRepositionFailed", func(e): reposition_failures.append(e.duplicate(true)))
	check(ask(bus, &"SpaceMapConfigureRequested", {"size":Vector2i(160,100)})["accepted"], "map")
	check(ask(bus, &"RoomCreateRequested", {"id":&"r", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)})["accepted"], "room")
	check(ask(bus, &"RoomCreateRequested", {"id":&"b", "type":"start", "origin_cell":Vector2i(20,2), "size_cells":Vector2i(11,11)})["accepted"], "other room")
	check(ask(bus, &"EntityCreateRequested", {"entity":&"hero"})["accepted"], "player")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(28,28), "size":4})["accepted"], "player body")
	check(ask(bus, &"ControlledEntityRequested", {"entity":&"hero"})["accepted"], "control")
	check(ask(bus, &"RoomEnterRequested", {"entity":&"hero", "room":&"r"})["accepted"], "enter")
	var keep := {}
	for x in range(28,32):
		for y in range(28,32): keep[Vector2i(x,y)] = true
	for x in [23,24,26,27]:
		for y in [25,26]: keep[Vector2i(x,y)] = true
	var tiles: Array = []
	for x in range(9,51):
		for y in range(9,51):
			if not keep.has(Vector2i(x,y)): tiles.append(Vector2i(x,y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles":tiles, "kind":0})["accepted"], "sparse floor")
	ask(bus, &"RngSeedRequested", {"seed":42})
	var initial := ask(bus, &"RoomSpawnRequested", {"room":&"r", "player":&"hero", "entry_tile":Vector2i(28,28), "depth":6, "pool":[mob_def()], "queue_delay":0.05})
	check(initial["accepted"], "partial spawn accepted " + str(initial))
	if not initial["accepted"]:
		quit(1)
		return
	check(initial["units"].size() == 2 and initial["queue_count"] == 1 and initial["degraded"] == ["entry_radius","mob_gap"], "partial placed and queue")
	var first: StringName = initial["units"][0]["entity"]
	var survivor: StringName = initial["units"][1]["entity"]
	var before_hp: float = ask(bus, &"ResourceGetRequested", {"entity":survivor,"resource":&"HP"})["data"]["current"]
	ask(bus, &"CombatDamageRequested", {"entity":survivor,"source":&"hero","amount":3.0})
	check(ask(bus, &"CombatDamageRequested", {"entity":first,"source":&"hero","amount":9999})["accepted"], "kill frees space")
	var status: Dictionary = ask(bus, &"RoomSpawnStatusRequested", {"room":&"r"})["data"]
	check(status["placed"].size() == 1 and status["queue"].size() == 1 and status["pending"] != &"", "queue delay scheduled on death")
	var pending: StringName = status["pending"]
	check(ask(bus, &"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":5.0})["accepted"], "time started")
	driver.advance_steps(2)
	check(is_equal_approx(ask(bus, &"ProcessGetRequested", {"id":pending})["data"]["elapsed"], 0.02), "delay advances")
	ask(bus, &"PlayerRoomChanged", {"entity":&"hero", "room":&"b", "room_type":&"start"})
	driver.advance_steps(10)
	check(is_equal_approx(ask(bus, &"ProcessGetRequested", {"id":pending})["data"]["elapsed"], 0.02) and arrivals.is_empty(), "delay freezes outside room")
	check(not ask(bus, &"AIEntityTickAllowedRequested", {"entity":survivor,"allowed":true})["allowed"], "placed NPC frozen outside room")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted",false), "save queue and pending timer")
	var file := FileAccess.open("user://session.save", FileAccess.READ)
	var original: Dictionary = bytes_to_var(file.get_buffer(file.get_length()))
	file.close()
	var broken := original.duplicate(true)
	broken["sections"]["spawn"]["states"][&"r"]["queue"][0].erase("definition")
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(broken))
	file.close()
	check(not ask(bus, &"SessionLoadRequested", {}).get("accepted",false), "reject corrupted queued definition")
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(original))
	file.close()
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted",false), "load queue and pending timer")
	status = ask(bus, &"RoomSpawnStatusRequested", {"room":&"r"})["data"]
	check(status["pending"] == pending and status["queue"].size() == 1, "queue not rerolled on load")
	var guard_cb := func(e):
		if e.get("entity", null) == survivor and e.get("component", null) == &"position":
			var save := ask(bus, &"SessionSaveRequested", {})
			var remove := ask(bus, &"EntityRemoveRequested", {"entity": survivor})
			var damage := ask(bus, &"CombatDamageRequested", {"entity": survivor, "amount": 9999.0})
			batch_guards = not save.get("accepted",false) and not remove.get("accepted",false) and not damage.get("accepted",false)
	bus.subscribe(&"ComponentChanged", guard_cb)
	ask(bus, &"PlayerRoomChanged", {"entity":&"hero", "room":&"r", "room_type":&"start"})
	bus.unsubscribe(&"ComponentChanged", guard_cb)
	check(batch_guards, "relocation blocks save, removal, and damage reentrancy")
	check(not repositions.is_empty() and repositions.back()["targets"].has(survivor), "placed reconsidered on return")
	check(ask(bus, &"ResourceGetRequested", {"entity":survivor,"resource":&"HP"})["data"]["current"] == before_hp - 3.0, "placed HP and identity preserved")
	driver.advance_steps(3)
	check(arrivals.size() == 1, "exactly one delayed spawn")
	status = ask(bus, &"RoomSpawnStatusRequested", {"room":&"r"})["data"]
	check(status["queue"].is_empty() and status["placed"].size() == 2 and status["pending"] == &"", "queue consumed exactly once")
	if not arrivals.is_empty():
		var spawned: StringName = arrivals[0]["entity"]
		check(ask(bus, &"DetectionPairGetRequested", {"observer":&"hero","target":spawned})["hostile"], "queued mob hostile")
		check(ask(bus, &"StatGetRequested", {"entity":spawned,"stat":&"CON"})["value"] == 16, "queued boss tag retained through save/load")
		check(ask(bus, &"ComponentGetRequested", {"entity":spawned,"component":&"species"})["data"]["tags"].has("boss"), "queued tag identity retained")
	driver.advance_steps(10)
	check(arrivals.size() == 1, "no infinite refill")
	var service = root.get_node("SpawnService")
	var positions_before: Dictionary = ask(bus, &"SpaceBodiesGetRequested", {})["bodies"].duplicate(true)
	service._rooms[&"r"]["offset"] = Vector2i(200,200)
	service._reposition(&"r", service._rooms[&"r"])
	check(not reposition_failures.is_empty() and reposition_failures.back()["positions_unchanged"], "unsatisfiable rearrangement reported")
	check(ask(bus, &"SpaceBodiesGetRequested", {})["bodies"] == positions_before, "failed rearrangement keeps all bodies")
	service._rooms[&"r"]["offset"] = Vector2i.ZERO
	print("Spawn queue tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
