extends SceneTree
var failures := 0
var bus: Node
var started: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, s: String) -> void:
	if not v: failures+=1; printerr("FAIL: ",s)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func key(game: Node,k: Key) -> void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func click(game: Control,pos: Vector2) -> void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*pos;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;game._input(e)
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	game.size=Vector2(1280,720)
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":100.0}).get("accepted",false),"capacity")
	var body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]
	var tile:Vector2i=body["anchor"]+Vector2i(2,2)
	for row in [[&"a_small",&"potion_hp"],[&"b_big",&"hammer_simple"],[&"c_small",&"potion_hp"]]:
		check(ask(&"ItemCreateRequested",{"id":row[0],"base_id":row[1],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":row[0]}).get("accepted",false),"create")
		check(ask(&"LootInventoryDropRequested",{"entity":game.HERO,"item":row[0],"tile":tile}).get("accepted",false) and driver.advance_steps(10)==10,"place on ground")
	var used:float=ask(&"InventoryGetRequested",{"entity":game.HERO})["used_volume"]
	var small:float=ask(&"ItemVolumeRequested",{"item":&"a_small"})["volume"]
	var big:float=ask(&"ItemVolumeRequested",{"item":&"b_big"})["volume"]
	check(big > 2*small,"big item larger than remaining capacity")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":used+2*small}).get("accepted",false),"fit just two small items")
	var on_start:=func(e): started.append(e["item"])
	bus.subscribe(&"LootPickupStarted",on_start)
	key(game,KEY_E)
	check(game._pickup_open and game._pickup_candidates()==[&"a_small",&"b_big",&"c_small"],"ordered list")
	var before:float=driver.game_time
	click(game,game._pickup_control_rect(3).get_center())
	check(started==[&"a_small"] and game._pickup_queue_running and game._pickup_open,"take all begins first")
	check(driver.advance_steps(10)==10,"partial first pickup")
	var save:=ask(&"SessionSaveRequested",{"slot":"demo"})
	check(save.get("accepted",false),"save running queue: "+str(save))
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load running queue")
	check(game._pickup_open and game._pickup_queue_running and game._pickup_inflight==&"a_small","queue state restored")
	check(driver.advance_steps(25)==25,"finish first")
	check(game._pickup_open,"window remains during queue")
	await process_frame
	check(started==[&"a_small",&"c_small"],"skips oversized item and starts later fitting item: "+str(started))
	check(driver.advance_steps(35)==35,"finish last fitting item")
	await process_frame
	check(not game._pickup_queue_running and game._pickup_open and game._pickup_candidates()==[&"b_big"],"remaining item stays visible after take all")
	check(absf(driver.game_time-before-0.70)<0.00001,"skipped item costs no time")
	check(game._inventory_items().has(&"a_small") and game._inventory_items().has(&"c_small") and not game._inventory_items().has(&"b_big"),"correct items collected")
	var now:float=driver.game_time
	key(game,KEY_A)
	check(not driver.is_action_active and not game._pickup_queue_running and game._pickup_open and driver.game_time==now and started.size()==2,"take all on full bag makes no attempts")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":100.0}).get("accepted",false),"expand")
	key(game,KEY_A)
	check(driver.advance_steps(35)==35,"collect last")
	await process_frame
	check(not game._pickup_open and not game._pickup_queue_running and game._inventory_items().has(&"b_big"),"empty window closes")
	bus.unsubscribe(&"LootPickupStarted",on_start)
	game.queue_free();await process_frame
	print("Take all sequence and capacity: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
