extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, text: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func exists(id: StringName) -> bool: return ask(&"EntityGetRequested", {"entity":id}).get("found", false)
func item(id: StringName) -> bool: return ask(&"ItemGetRequested", {"item":id}).get("found", false)
func inv(id: StringName) -> Array: return ask(&"InventoryGetRequested", {"entity":id})["data"]["items"]
func mob_def() -> Dictionary:
	return {"id":"cleanup_test", "type_weight":0.1, "species":{"id":"test", "species_weight":0.2}, "tags":[{"id":"boss", "tag_weight":0.1}], "base_stats":{"CON":10,"STR":10,"DEX":10,"INT":10,"WIS":10,"PER":10}, "growth_per_level":{"CON":2,"STR":2,"DEX":2,"INT":2,"WIS":2,"PER":2}, "body_size":2,"min_depth":0,"max_depth":null}
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(100,100)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"r", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(28,28), "size":4}).get("accepted", false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RunStatisticsStartRequested", {"entity":&"hero", "start_room":&"r"}).get("accepted", false), "stats")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"r"}).get("accepted", false), "enter")
	ask(&"RngSeedRequested", {"seed":42})
	var spawn := ask(&"RoomSpawnRequested", {"room":&"r", "player":&"hero", "entry_tile":Vector2i(28,28), "depth":6, "pool":[mob_def()], "queue_delay":0.05})
	check(spawn.get("accepted", false) and spawn.get("units", []).size() >= 3 and spawn.get("queue_count", -1) == 0, "real spawned actors")
	if not spawn.get("accepted", false) or spawn.get("units", []).size() < 3 or spawn.get("queue_count", -1) != 0:
		quit(1)
		return
	var actors: Array = []
	for unit in spawn["units"]: actors.append(unit["entity"])
	actors.sort_custom(func(a,b): return str(a) < str(b))
	var dead1: StringName = actors[0]
	var dead2: StringName = actors[1]
	var survivor: StringName = actors[2]
	for id in [dead1,dead2]:
		check(ask(&"InventoryConfigureRequested", {"entity":id, "volume":10}).get("accepted", false), "mob inventory")
	for spec in [[&"ground_item", dead1], [&"corpse_item", dead2]]:
		check(ask(&"ItemCreateRequested", {"id":spec[0], "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "item")
		check(ask(&"InventoryAddRequested", {"entity":spec[1], "item":spec[0]}).get("accepted", false), "mob item")
	check(ask(&"CombatDamageRequested", {"entity":dead1, "source":&"hero", "amount":9999}).get("accepted", false), "first death")
	check(ask(&"LootGetRequested", {})["items"].has(&"ground_item") and not ask(&"SpaceBodyGetRequested", {"entity":dead1}).get("found", false), "real ground loot and released corpse body")
	check(ask(&"LootEnableSetRequested", {"enabled":false}).get("accepted", false), "disable loot")
	check(ask(&"CombatDamageRequested", {"entity":dead2, "source":&"hero", "amount":9999}).get("accepted", false), "second death")
	check(inv(dead2).has(&"corpse_item"), "unlooted corpse retains inventory")
	check(ask(&"LootEnableSetRequested", {"enabled":true}).get("accepted", false), "enable loot")
	# Даже поддельный spawn-компонент не делает сущность подтверждённой спавном.
	check(ask(&"EntityCreateRequested", {"entity":&"unclassified", "components":{&"spawn":{"room":&"r"}}}).get("accepted", false), "unclassified corpse")
	check(ask(&"CombatDamageRequested", {"entity":&"unclassified", "source":&"hero", "amount":9999}).get("accepted", false), "unclassified death")
	var stats_before: Dictionary = ask(&"RunStatisticsGetRequested", {})["data"]
	check(stats_before["kills"] == 3, "three real kills")
	check(not ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "spawn provenance blocks map reset")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "provenance survives save and load")
	var snapshot := {"sections":{}, "errors":[]}
	ask(&"SnapshotCollectRequested", snapshot)
	var created: Dictionary = snapshot["sections"]["spawn"]["created_entities"]
	check(created.has(dead1) and created.has(dead2) and created.has(survivor) and not created.has(&"unclassified"), "ledger records real creation only")
	var invalid: Dictionary = snapshot["sections"].duplicate(true)
	invalid["spawn"]["created_entities"].erase(survivor)
	check(not ask(&"SpawnSnapshotValidateRequested", {"sections":invalid}).get("valid", true), "reject placed actor missing provenance")
	invalid = snapshot["sections"].duplicate(true)
	invalid["spawn"]["created_entities"][dead1] = &"nonexistent"
	check(not ask(&"SpawnSnapshotValidateRequested", {"sections":invalid}).get("valid", true), "reject mismatched provenance")
	var cleanup = root.get_node("FloorSpawnCleanup")
	var save = root.get_node("SaveService")
	check(not cleanup.discard_spawned_corpses_for_transition().get("accepted", false), "not usable outside transition")
	check(ask(&"ProcessStartRequested", {"id":&"corpse_independent", "entity":dead1, "duration":2.0, "independent":true}).get("accepted", false), "independent corpse process")
	var blocked := {}
	var result: Dictionary = save.run_world_transition_transaction(func(): blocked["result"] = cleanup.discard_spawned_corpses_for_transition(); return true)
	check(not blocked["result"].get("accepted", true) and result.get("rolled_back", false), "independent process blocks corpse cleanup")
	check(ask(&"ProcessInterruptRequested", {"id":&"corpse_independent"}).get("accepted", false), "cancel independent process")
	var veto := func(e):
		if e.get("entity", null) == dead2: e["allowed"] = false
	root.get_node("EventBus").subscribe(&"LootEntityRemovalCheckRequested", veto)
	var failed := {}
	result = save.run_world_transition_transaction(func(): failed["result"] = cleanup.discard_spawned_corpses_for_transition(); return true)
	root.get_node("EventBus").unsubscribe(&"LootEntityRemovalCheckRequested", veto)
	check(not failed["result"].get("accepted", true) and result.get("rolled_back", false), "partial corpse removal rolls back")
	check(exists(dead1) and exists(dead2) and item(&"corpse_item") and inv(dead2).has(&"corpse_item") and ask(&"LootGetRequested", {})["items"].has(&"ground_item"), "rollback restores corpse, item and ground drop")
	var cleaned := {}
	result = save.run_world_transition_transaction(func(): cleaned["result"] = cleanup.discard_spawned_corpses_for_transition(); return cleaned["result"].get("accepted", false))
	check(result.get("committed", false) and cleaned["result"].get("entities", []) == [dead1,dead2] and cleaned["result"].get("items", []) == [&"corpse_item"], "confirmed corpses cleaned")
	check(not exists(dead1) and not exists(dead2) and not item(&"corpse_item") and item(&"ground_item") and ask(&"LootGetRequested", {})["items"].has(&"ground_item"), "unlooted inventory retired but ground loot remains")
	check(exists(survivor) and exists(&"unclassified") and ask(&"RunStatisticsGetRequested", {})["data"]["kills"] == 3, "living and unclassified entities retained and kills unchanged")
	check(not ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "live spawn still blocks reset")
	result = save.run_world_transition_transaction(func(): return cleanup.discard_spawned_actors_for_transition().get("accepted", false))
	check(result.get("committed", false) and ask(&"SpawnMapReconfigureCheckRequested", {"allowed":true})["allowed"], "reset guard lifts once all confirmed spawns removed")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and exists(&"unclassified") and item(&"ground_item"), "cleanup survives save")
	print("Floor spawned corpse cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
