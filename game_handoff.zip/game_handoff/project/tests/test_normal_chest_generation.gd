extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus=root.get_node("EventBus")
	check(begin(1) and add_room(1,"passage") and add_room(2,"passage") and add_room(3,"passage") and add_room(4,"passage"),"connected floor")
	var force:=func(e):
		if e.get("min",0)==1 and e.get("max",0)==4:e["value"]=1
	bus.subscribe(&"RngIntRequested",force)
	check(ask(&"DungeonNormalChestRollRequested",{"room":&"node_1"}).get("selected",false),"preset selected roll")
	bus.unsubscribe(&"RngIntRequested",force)
	var saver=root.get_node("SaveService")
	var before: Dictionary=saver.collect_world_transition_snapshot()
	var calls:={"count":0}
	var reject:=func(e):
		if str(e.get("entity","")).begins_with("normal_chest:"):
			calls["count"]+=1
			if calls["count"]==2:e["accepted"]=false
	bus.subscribe(&"InventoryAddRequested",reject)
	var failed:=ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_1"})
	bus.unsubscribe(&"InventoryAddRequested",reject)
	check(not failed.get("accepted",true) and failed.get("rolled_back",false) and calls["count"]==2 and before["payload"]["sections"]==saver.collect_world_transition_snapshot()["payload"]["sections"],"failed creation rolls back candidate RNG and items")
	var made:=ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_1"})
	check(made.get("accepted",false) and made.get("status","")=="created","selected chest generated " + str(made))
	if not made.get("accepted",false) or made.get("status","")!="created":quit(1);return
	var id: StringName=made["object"]
	var items: Array=made["items"].duplicate()
	check(items.size()>=2 and items.size()<=5,"normal content count")
	check(ask(&"DungeonChestPositionPreflightRequested",{"room":&"node_1","tile":made["tile"],"existing_object":id}).get("accepted",false),"chosen wall position is safe")
	var repeated:=ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_1"})
	check(repeated.get("accepted",false) and repeated.get("existing",false) and repeated.get("object",null)==id,"idempotent")
	var force_no:=func(e):
		if e.get("min",0)==1 and e.get("max",0)==4:e["value"]=4
	bus.subscribe(&"RngIntRequested",force_no)
	var rejected:=ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_2"})
	bus.unsubscribe(&"RngIntRequested",force_no)
	check(rejected.get("accepted",false) and rejected.get("status","")=="not_selected","unselected creates no chest")
	bus.subscribe(&"RngIntRequested",force)
	check(ask(&"DungeonNormalChestRollRequested",{"room":&"node_3"}).get("selected",false),"preset selected for no-position test")
	bus.unsubscribe(&"RngIntRequested",force)
	var origin: Vector2i=coord(3)*4
	var bounds:=Rect2i(origin,Vector2i(48,48))
	var no_wall_candidates:=func(e):
		if e.get("tile",null) is Vector2i and bounds.has_point(e["tile"]):e["kind"]=0
	bus.subscribe(&"SpaceTileGetRequested",no_wall_candidates)
	var no_position:=ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_3"})
	bus.unsubscribe(&"SpaceTileGetRequested",no_wall_candidates)
	check(no_position.get("accepted",false) and no_position.get("status","")=="no_position","no candidates is a fixed no-chest result")
	check(ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_3"}).get("status","")=="no_position","no-position is not retried on repeat")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"save/load generated state")
	check(ask(&"InventoryGetRequested",{"entity":id})["data"]["items"]==items and ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_1"}).get("existing",false),"contents and idempotency persist")
	check(ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_2"}).get("status","")=="not_selected","unselected remains unselected")
	check(ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_3"}).get("status","")=="no_position","no-position remains fixed after load")
	var before_new: Dictionary=saver.collect_world_transition_snapshot()
	var reject_create:=func(e):
		if e.get("room",null)==&"node_4" and e.get("type","")=="chest":e["accepted"]=false
	bus.subscribe(&"RngIntRequested",force)
	bus.subscribe(&"ObjectCreateRequested",reject_create)
	var new_failed:=ask(&"DungeonNormalChestGenerateRequested",{"room":&"node_4"})
	bus.unsubscribe(&"ObjectCreateRequested",reject_create)
	bus.unsubscribe(&"RngIntRequested",force)
	check(not new_failed.get("accepted",true) and new_failed.get("rolled_back",false) and before_new["payload"]["sections"]==saver.collect_world_transition_snapshot()["payload"]["sections"],"failure rolls back even first chance roll")
	check(not ask(&"DungeonNormalChestRollGetRequested",{"room":&"node_4"}).get("found",true),"failed first roll not recorded")
	var snapshot: Dictionary=saver.collect_world_transition_snapshot()
	var corrupt: Dictionary=snapshot["payload"].duplicate(true)
	corrupt["sections"]["normal_chest_generation"][&"node_1"]["object"]= &"missing"
	check(not saver._validate_snapshot(corrupt),"reject inconsistent created object")
	var driver=root.get_node("TimeDriver")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":made["interaction_anchor"],"size":4}).get("accepted",false),"place hero at validated interaction anchor")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":100}).get("accepted",false),"hero inventory")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"RoomEnterRequested",{"entity":&"hero","room":&"node_1"}).get("accepted",false),"enter room")
	check(ask(&"ObjectInteractRequested",{"entity":&"hero","object":id}).get("accepted",false) and driver.advance_steps(10)==10,"open chest")
	check(ask(&"ChestTakeRequested",{"entity":&"hero","object":id,"item":items[0]}).get("accepted",false) and driver.advance_steps(10)==10,"take generated item")
	check(ask(&"InventoryGetRequested",{"entity":&"hero"})["data"]["items"].has(items[0]),"generated item enters hero inventory")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"opened looted chest state persists")
	print("Normal chest generation tests: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
