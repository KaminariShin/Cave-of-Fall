extends SceneTree
var failures := 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(ok: bool, message: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", message)
func run_tests() -> void:
	var registry = root.get_node("EntityRegistry")
	var bus = root.get_node("EventBus")
	var processes = root.get_node("ProcessRegistry")
	var actions = root.get_node("ActionRegistry")
	root.get_node("TimeDriver").set_process(false)
	var player: Dictionary = registry.make_common_components()
	player[&"stats"]["STR"] = 12
	check(registry.create_entity(&"player", player), "create player")
	check(not registry.create_entity(&"player", {}), "reject duplicate")
	player[&"stats"]["STR"] = 99
	check(registry.get_component(&"player", &"stats")["STR"] == 12, "copy input")
	var snapshot: Dictionary = registry.get_component(&"player", &"stats")
	snapshot["STR"] = 42
	check(registry.get_component(&"player", &"stats")["STR"] == 12, "copy output")
	var create_enemy := {"entity": &"enemy", "components": {&"ai": {"behavior": &"idle"}, &"position": {"anchor": null}}, "accepted": false}
	bus.publish(&"EntityCreateRequested", create_enemy)
	check(create_enemy["accepted"], "event creates entity")
	check(registry.query_entities([&"ai", &"position"]) == [&"enemy"], "query components")
	var set_stat := {"entity": &"enemy", "stat": &"STR", "value": 3}
	bus.publish(&"StatBaseSetRequested", set_stat)
	check(set_stat["accepted"], "set stat through pipeline")
	var get := {"entity": &"enemy", "component": &"stats"}
	bus.publish(&"ComponentGetRequested", get)
	check(get["found"] and get["data"]["STR"] == 3, "get event")
	check(actions.start_action(&"enemy", &"attack"), "enemy action")
	check(processes.register_process(&"bound", 0.1, &"enemy"), "bound process")
	check(processes.register_process(&"arrow", 0.1, &"enemy", true), "independent process")
	var remove := {"entity": &"enemy", "accepted": false}
	bus.publish(&"EntityRemoveRequested", remove)
	check(remove["accepted"] and not registry.has_entity(&"enemy"), "remove entity")
	check(actions.get_active_action(&"enemy").is_empty(), "entity removal cancels action")
	check(not processes.has_process(&"bound") and processes.has_process(&"arrow"), "dependent cancelled, independent retained")
	check(not registry.remove_entity(&"enemy"), "double remove fails")
	print("Entity Registry tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
