extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func gear()->Dictionary:return ask(&"ComponentGetRequested",{"entity":&"demo_hero","component":&"equipment"})["data"]
func inventory()->Array:return ask(&"InventoryGetRequested",{"entity":&"demo_hero"})["data"]["items"]
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save";var exists:=FileAccess.file_exists(path);var old:=PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":50}).get("accepted",false),"capacity")
	check(ask(&"ItemCreateRequested",{"id":&"target_hammer","base_id":&"hammer_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"target_hammer"}).get("accepted",false),"hammer")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open inventory")
	check(game._use_inventory_item(inventory().find(&"demo_shield")) and driver.advance_steps(10)==10 and gear().get("off",null)==&"demo_shield","equip shield")
	var idx:=inventory().find(&"target_hammer")
	var volume:float=ask(&"InventoryGetRequested",{"entity":game.HERO})["used_volume"]
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":volume}).get("accepted",false),"full inventory")
	var t:float=driver.game_time
	check(game._use_inventory_item(idx) and game._twohand_queue.get("stage","")=="choose" and not game._drop_pick.is_empty() and gear().get("off",null)==&"demo_shield" and gear().get("main",null)==&"demo_sword" and driver.game_time==t,"full inventory requests drop tile")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save during selection")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load selection")
	await process_frame;await process_frame
	check(game._twohand_queue.get("stage","")=="choose" and not game._drop_pick.is_empty(),"selection restored")
	var fkey:=InputEventKey.new();fkey.pressed=true;fkey.keycode=KEY_F;game._unhandled_key_input(fkey)
	check(game._twohand_queue.get("stage","")=="running" and game._drop_pick.is_empty(),"confirm drop")
	check(driver.advance_steps(10)==10 and gear().get("off",null)==null and ask(&"LootGetRequested",{})["items"].has(&"demo_shield"),"shield on ground")
	check(game._twohand_continue() and game._twohand_queue.get("stage","")=="choose","second drop needed")
	game._unhandled_key_input(fkey)
	check(driver.advance_steps(10)==10 and gear().get("main",null)==null and ask(&"LootGetRequested",{})["items"].has(&"demo_sword"),"sword on ground")
	check(game._twohand_continue() and driver.advance_steps(10)==10 and gear().get("main",null)==&"target_hammer" and game._twohand_queue.is_empty(),"hammer equipped after drops")
	game.queue_free();await process_frame
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo drop sequence: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
