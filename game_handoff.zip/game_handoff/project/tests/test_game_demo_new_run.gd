extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(value: bool,label: String) -> void:
	if not value: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func read_bytes(path: String) -> PackedByteArray:
	if not FileAccess.file_exists(path): return PackedByteArray()
	var f := FileAccess.open(path,FileAccess.READ); var bytes := f.get_buffer(f.get_length()); f.close(); return bytes
func restore(path: String, existed: bool, data: PackedByteArray) -> void:
	if existed:
		var f := FileAccess.open(path,FileAccess.WRITE); f.store_buffer(data); f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var path := "user://demo_session.save"
	var ordinary := "user://session.save"
	var existed := FileAccess.file_exists(path)
	var old := read_bytes(path)
	var normal_existed := FileAccess.file_exists(ordinary)
	var normal := read_bytes(ordinary)
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized and game._fresh_available,"fresh baseline captured")
	check(not root.get_node("SaveService").restart_demo_fresh().get("accepted",true),"cannot restart live run")
	var original: Array = ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].duplicate()
	check(ask(&"ItemCreateRequested",{"id":&"new_run_test_loot","base_id":&"potion_hp","item_level":5}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"new_run_test_loot"}).get("accepted",false),"loot acquired")
	check(game._move(Vector2i.RIGHT) and driver.advance_steps(100)>0,"run advanced")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"old run saved")
	check(ask(&"CombatDamageRequested",{"entity":game.HERO,"amount":999999}).get("accepted",false),"death")
	check(game.is_dead and game._restart_button.visible and not game._restart_button.disabled,"new game button after death")
	game._restart_button.pressed.emit()
	check(not game.is_dead and not game.is_won and not game._restart_button.visible and game.message=="Новый забег начат.","button restarts")
	check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]==original and not ask(&"ItemGetRequested",{"item":&"new_run_test_loot"}).get("found",true),"no old loot")
	check(not root.get_node("CombatService").is_entity_dead(game.HERO) and ask(&"EntityGetRequested",{"entity":game.RAT}).get("found",false),"hero and rat reset")
	check(driver.game_time==0.0 and ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]==Vector2i(54,60),"time and position reset")
	check(ask(&"RunStatisticsGetRequested",{})["data"]["floor"]==1 and not ask(&"RunStatisticsGetRequested",{})["data"]["finished"],"fresh statistics")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"saving works after death restart")
	# Изолированная имитация финишного результата; настоящий портал покрыт отдельно.
	var stats = root.get_node("RunStatisticsService")
	var data: Dictionary = stats.get("_data")
	data["finished"] = true; data["outcome"] = "victory"
	bus.publish(&"RunStatisticsFinished",{"entity":game.HERO,"outcome":"victory"})
	check(game.is_won and game._restart_button.visible,"button after victory")
	var save_service = root.get_node("SaveService")
	var pristine: Dictionary = save_service.get("_demo_fresh_baseline").duplicate(true)
	var damaged: Dictionary = pristine.duplicate(true)
	damaged["sections"]["game_demo"]["room"] = &"missing"
	save_service.set("_demo_fresh_baseline",damaged)
	check(not save_service.restart_demo_fresh().get("accepted",true) and game.is_won and FileAccess.file_exists(path),"invalid baseline rejects without touching result or save")
	save_service.set("_demo_fresh_baseline",pristine)
	game._restart_button.pressed.emit()
	check(not game.is_won and not FileAccess.file_exists(path),"victory restart removes old demo slot")
	check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]==original and ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"fresh inventory and saving after victory")
	check(FileAccess.file_exists(ordinary)==normal_existed and read_bytes(ordinary)==normal,"ordinary save untouched")
	game.queue_free()
	await process_frame
	restore(path,existed,old)
	restore(ordinary,normal_existed,normal)
	print("Game demo new run: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
