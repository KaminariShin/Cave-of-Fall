extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, text: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func exists(id: StringName) -> bool: return ask(&"EntityGetRequested", {"entity":id}).get("found", false)
func item(id: StringName) -> bool: return ask(&"ItemGetRequested", {"item":id}).get("found", false)
func inv(id: StringName) -> Array: return ask(&"InventoryGetRequested", {"entity":id})["data"]["items"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(100,100)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"start", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":20}).get("accepted", false), "hero inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(12,12), "size":4}).get("accepted", false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	for spec in [[&"a_chest", "chest", Vector2i(16,13)], [&"b_chest", "chest", Vector2i(25,25)], [&"c_altar", "altar", Vector2i(30,25)]]:
		check(ask(&"ObjectCreateRequested", {"entity":spec[0], "type":spec[1], "room":&"start", "tile":spec[2], "inventory_capacity":10 if spec[1] == "chest" else null}).get("accepted", false), "create object")
	for spec in [[&"chest_item", &"a_chest"], [&"player_item", &"hero"]]:
		check(ask(&"ItemCreateRequested", {"id":spec[0], "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "create item")
		check(ask(&"InventoryAddRequested", {"entity":spec[1], "item":spec[0]}).get("accepted", false), "give item")
	check(ask(&"ItemCreateRequested", {"id":&"spare", "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "unassigned item for reentry test")
	check(ask(&"MaterialRegisterRequested", {"material":{"id":"object_mat", "name":"Material", "weight_per_unit":1, "volume_per_unit":1, "level":1}}).get("accepted", false), "material")
	check(ask(&"ItemBaseRegisterRequested", {"base":{"id":"object_belt_base", "name":"Belt", "slot":"belt", "materials":[{"material_id":"object_mat", "count":1}]}}).get("accepted", false), "belt base")
	check(ask(&"BeltTypeRegisterRequested", {"definition":{"id":"object_belt_type", "slots_min":1}}).get("accepted", false), "belt type")
	check(ask(&"BeltModuleTypeRegisterRequested", {"definition":{"id":"object_module_type", "slots":1}}).get("accepted", false), "module type")
	check(ask(&"ItemCreateRequested", {"id":&"chest_belt", "base_id":&"object_belt_base", "item_level":1}).get("accepted", false), "chest belt")
	check(ask(&"InventoryAddRequested", {"entity":&"b_chest", "item":&"chest_belt"}).get("accepted", false), "put belt in chest")
	check(ask(&"BeltInitializeRequested", {"item":&"chest_belt", "type_id":&"object_belt_type"}).get("accepted", false), "belt state")
	check(ask(&"BeltModuleInstallRequested", {"item":&"chest_belt", "module":&"object_module", "type_id":&"object_module_type"}).get("accepted", false), "belt module")
	var service = root.get_node("ObjectGenerationService")
	var save = root.get_node("SaveService")
	check(not service.discard_objects_for_transition().get("accepted", false), "not callable outside transition")
	check(ask(&"ObjectInteractRequested", {"entity":&"hero", "object":&"a_chest"}).get("accepted", false), "interaction starts")
	var busy := {}
	var result: Dictionary = save.run_world_transition_transaction(func(): busy["status"] = service.discard_objects_for_transition(); return true)
	check(result.get("committed", false) and not busy["status"].get("accepted", true) and exists(&"a_chest") and item(&"chest_item"), "active interaction blocks cleanup without cancellation")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted", false), "cancel interaction")
	var reentry := {"attempted":false}
	var veto := func(e):
		if e.get("entity", null) == &"b_chest": e["allowed"] = false
		if e.get("entity", null) == &"a_chest" and not reentry["attempted"]:
			reentry["attempted"] = true
			reentry["change"] = ask(&"InventoryAddRequested", {"entity":&"b_chest", "item":&"spare"}).get("accepted", false)
			reentry["remove"] = ask(&"ObjectRemoveRequested", {"object":&"b_chest"}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"LootEntityRemovalCheckRequested", veto)
	var broken := {}
	# Возвращаем true намеренно: частичный сбой должен сам запретить commit.
	result = save.run_world_transition_transaction(func(): broken["status"] = service.discard_objects_for_transition(); return true)
	root.get_node("EventBus").unsubscribe(&"LootEntityRemovalCheckRequested", veto)
	check(not broken["status"].get("accepted", true) and result.get("rolled_back", false) and not result.get("committed", true), "partial failure forces rollback even when caller returns true")
	check(reentry["attempted"] and not reentry["change"] and not reentry["remove"], "reentrant mutation denied")
	check(exists(&"a_chest") and exists(&"b_chest") and item(&"chest_item") and inv(&"a_chest").has(&"chest_item") and inv(&"b_chest").has(&"chest_belt") and ask(&"BeltGetRequested", {"item":&"chest_belt"}).get("found", false), "objects and contents restored after failure")
	check(ask(&"SpaceTileGetRequested", {"tile":Vector2i(16,13)}).get("obstacle", null) == &"a_chest", "obstacle restored")
	var cleaned := {}
	result = save.run_world_transition_transaction(func(): cleaned["status"] = service.discard_objects_for_transition(); return cleaned["status"].get("accepted", false))
	check(result.get("committed", false) and cleaned["status"].get("objects", []).size() == 3 and cleaned["status"].get("items", []) == [&"chest_belt", &"chest_item"], "objects and contents retired")
	check(not exists(&"a_chest") and not exists(&"b_chest") and not exists(&"c_altar") and not item(&"chest_item") and not item(&"chest_belt") and not ask(&"BeltGetRequested", {"item":&"chest_belt"}).get("found", false) and item(&"spare"), "objects and contents gone")
	check(ask(&"SpaceTileGetRequested", {"tile":Vector2i(16,13)}).get("obstacle", null) == null, "obstacle removed")
	check(exists(&"hero") and item(&"player_item") and inv(&"hero").has(&"player_item"), "player and belongings retained")
	check(not ask(&"ItemCreateRequested", {"id":&"chest_item", "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "retired ID blocked")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and not exists(&"a_chest") and item(&"player_item"), "cleanup persists")
	print("Floor object cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
