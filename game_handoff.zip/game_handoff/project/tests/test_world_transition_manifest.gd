extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func add_item(id: StringName, base: StringName, owner: StringName = &"") -> bool:
	if not ask(&"ItemCreateRequested", {"id":id, "base_id":base, "item_level":1}).get("accepted", false): return false
	return owner == &"" or ask(&"InventoryAddRequested", {"entity":owner, "item":id}).get("accepted", false)
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(100,100)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"start", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	for id in [&"hero", &"enemy"]:
		check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted", false), "entity " + str(id))
		check(ask(&"InventoryConfigureRequested", {"entity":id, "volume":10}).get("accepted", false), "inventory")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(10,10), "size":4}).get("accepted", false), "hero body")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"enemy", "anchor":Vector2i(20,20), "size":4}).get("accepted", false), "enemy body")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "room":&"start", "type":"chest", "tile":Vector2i(16,16), "inventory_capacity":10}).get("accepted", false), "chest")
	check(add_item(&"potion", &"potion_hp", &"hero") and add_item(&"sword", &"sword_simple", &"hero") and add_item(&"enemy_item", &"antidote", &"enemy") and add_item(&"chest_item", &"bandage", &"chest") and add_item(&"unassigned", &"bandage"), "items")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"sword", "slot":"main"}).get("accepted", false), "equip sword")
	driver.advance_steps(10)
	var result := ask(&"WorldTransitionManifestRequested", {"entity":&"hero"})
	check(result.get("accepted", false), "manifest constructed")
	if result.get("accepted", false):
		var m: Dictionary = result["manifest"]
		check(m["player_items"] == [&"potion", &"sword"] and m["item_locations"][&"sword"]["kind"] == "equipment", "player inventory and equipment are protected")
		check(m["other_owned_or_ground_items"] == [&"chest_item", &"enemy_item"] and m["unassigned_items"] == [&"unassigned"], "other owners and unknown ownership distinguished")
		check(m["other_entities"].has(&"enemy") and m["world_objects"] == [&"chest"] and m["other_bodies"] == [&"enemy"], "bodies and objects inventoried")
		check(not m["executable"] and m["player_body"]["anchor"] == Vector2i(10,10), "report is not an executable transition")
		m["player_items"].clear()
		check(ask(&"InventoryGetRequested", {"entity":&"hero"})["data"]["items"].has(&"potion"), "report is detached from live state")
	check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.1}).get("accepted", false), "start action")
	var busy := ask(&"WorldTransitionManifestRequested", {"entity":&"hero"})
	check(busy.get("accepted", false) and busy["manifest"]["active_actions"].has(&"hero") and not busy["manifest"]["executable"], "active actions visible, report does not imply readiness")
	driver.advance_steps(10)
	check(not ask(&"WorldTransitionManifestRequested", {"entity":&"enemy"}).get("accepted", false), "noncontrolled rejected")
	# Искусственная копия позволяет проверить конфликт, который публичный API
	# обычно предотвращает. В живой мир копия не применяется.
	var snapshot: Dictionary = root.get_node("SaveService").collect_world_transition_snapshot()
	check(snapshot.get("valid", false), "snapshot available")
	if snapshot.get("valid", false):
		var sections: Dictionary = snapshot["payload"]["sections"].duplicate(true)
		sections["entities"][&"enemy"][&"inventory"]["items"].append(&"potion")
		var report: Dictionary = root.get_node("WorldTransitionManifest").build_manifest(sections, &"hero")
		check(not report.get("valid", true), "conflicting ownership rejected")
		sections["entities"][&"enemy"][&"inventory"]["items"].erase(&"potion")
		sections["entities"][&"hero"][&"equipment"]["main"] = &"unknown_item"
		report = root.get_node("WorldTransitionManifest").build_manifest(sections, &"hero")
		check(not report.get("valid", true), "missing referenced item rejected")
	check(ask(&"EntityCreateRequested", {"entity":&"victim"}).get("accepted", false), "victim")
	check(ask(&"InventoryConfigureRequested", {"entity":&"victim", "volume":10}).get("accepted", false), "victim inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"victim", "anchor":Vector2i(28,28), "size":4}).get("accepted", false), "victim body")
	check(add_item(&"drop", &"potion_hp", &"victim"), "victim item")
	check(ask(&"CombatDamageRequested", {"entity":&"victim", "amount":100000, "damage_type":"magical"}).get("accepted", false), "kill victim")
	var dropped := ask(&"WorldTransitionManifestRequested", {"entity":&"hero"})
	check(dropped.get("accepted", false) and dropped["manifest"]["ground_items"].has(&"drop") and dropped["manifest"]["item_locations"][&"drop"]["kind"] == "ground", "ground loot classified separately")
	var block := func(e): e["errors"].append("snapshot locked")
	root.get_node("EventBus").subscribe(&"SnapshotCollectRequested", block)
	check(not ask(&"WorldTransitionManifestRequested", {"entity":&"hero"}).get("accepted", false), "snapshot guard honored")
	root.get_node("EventBus").unsubscribe(&"SnapshotCollectRequested", block)
	print("World transition manifest tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
