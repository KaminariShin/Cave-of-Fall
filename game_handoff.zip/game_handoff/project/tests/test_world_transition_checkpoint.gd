extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func found(id: StringName) -> bool:
	return ask(&"EntityGetRequested", {"entity":id}).get("found", false)
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var save = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "create hero")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "controlled hero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted", false), "inventory")
	check(ask(&"ItemCreateRequested", {"id":&"potion", "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "create item")
	check(ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"potion"}).get("accepted", false), "give item")
	var hp_before: Dictionary = ask(&"ResourceGetRequested", {"entity":&"hero", "resource":&"HP"})["data"]
	var restored := [0]
	root.get_node("EventBus").subscribe(&"SnapshotRestored", func(_e): restored[0] += 1)
	var saw := {}
	var failed := func():
		saw["session"] = ask(&"SessionSaveRequested", {}).get("accepted", false)
		saw["meta"] = ask(&"MetaSaveRequested", {}).get("accepted", false)
		saw["nested"] = save.run_world_transition_transaction(func(): return true)
		ask(&"EntityCreateRequested", {"entity":&"temporary"})
		ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"HP", "value":1})
		ask(&"InventoryRemoveRequested", {"entity":&"hero", "item":&"potion"})
		return false
	var result: Dictionary = save.run_world_transition_transaction(failed)
	check(not result.get("committed", true) and result.get("rolled_back", false), "failed operation rolls back")
	check(found(&"hero") and not found(&"temporary") and restored[0] == 1, "state restored and listeners notified")
	check(ask(&"ResourceGetRequested", {"entity":&"hero", "resource":&"HP"})["data"] == hp_before, "resources restored")
	check(ask(&"InventoryGetRequested", {"entity":&"hero"})["data"]["items"].has(&"potion") and ask(&"ItemGetRequested", {"item":&"potion"}).get("found", false), "inventory and item restored")
	check(not saw["session"] and not saw["meta"] and not saw["nested"].get("committed", true), "file operations and nesting blocked")
	var success := func():
		ask(&"EntityCreateRequested", {"entity":&"kept"})
		return true
	result = save.run_world_transition_transaction(success)
	check(result.get("committed", false) and found(&"kept") and restored[0] == 1, "valid success commits")
	var rejecting_guard := func(e): e["errors"].append("simulated incomplete world")
	var incomplete := func():
		ask(&"EntityCreateRequested", {"entity":&"partial"})
		root.get_node("EventBus").subscribe(&"SnapshotCollectRequested", rejecting_guard)
		return true
	result = save.run_world_transition_transaction(incomplete)
	root.get_node("EventBus").unsubscribe(&"SnapshotCollectRequested", rejecting_guard)
	check(result.get("rolled_back", false) and not found(&"partial") and found(&"kept"), "incomplete final snapshot rolls back without collecting again")
	var marker := [false]
	root.get_node("EventBus").subscribe(&"SnapshotCollectRequested", rejecting_guard)
	result = save.run_world_transition_transaction(func(): marker[0] = true; return true)
	root.get_node("EventBus").unsubscribe(&"SnapshotCollectRequested", rejecting_guard)
	check(not marker[0] and not result.get("committed", true) and not result.get("rolled_back", true), "unsafe initial state never starts")
	var death := func():
		ask(&"EntityDied", {"entity":&"hero"})
		return false
	# Защита не затрагивает реальный игровой файл во время теста.
	root.get_node("EventBus").subscribe(&"SessionDeleteOnDeathCheckRequested", func(e): e["allowed"] = false)
	result = save.run_world_transition_transaction(death)
	check(result.get("fatal", false) and not result.get("rolled_back", true), "death never rolled back")
	print("World transition checkpoint tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
