extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func plan(hp: Dictionary, hits: Array) -> Dictionary:
	return ask(&"SimultaneousDamagePlanRequested", {"hp_by_target":hp,"hits":hits})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus = root.get_node("EventBus")
	var deaths: Array = []
	var damages: Array = []
	bus.subscribe(&"EntityDied", func(e): deaths.append(e))
	bus.subscribe(&"EntityDamaged", func(e): damages.append(e))
	check(ask(&"EntityCreateRequested", {"entity":&"a"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"b"}).get("accepted",false), "entities")
	var saver = root.get_node("SaveService")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var hits := [{"source":&"a","target":&"b","damage":17},{"source":&"b","target":&"a","damage":12}]
	var q := plan({&"a":10,&"b":15},hits)
	check(q.get("accepted",false), "mutual strike accepted")
	if q.get("accepted",false):
		var rows: Array = q["data"]["targets"]
		check(rows.size() == 2 and rows[0]["target"] == &"a" and rows[1]["target"] == &"b" and rows[0]["lethal"] and rows[1]["lethal"] and rows[0]["killer_candidates"] == [&"b"] and rows[1]["killer_candidates"] == [&"a"] and rows[0]["hp_after"] == 0 and rows[1]["hp_after"] == 0, "mutual lethal results share initial hp")
	var after: Dictionary = saver.collect_world_transition_snapshot()
	check(before.get("valid",false) and after.get("valid",false) and before["payload"]["sections"]["rng"] == after["payload"]["sections"]["rng"] and before["payload"]["sections"]["resources"] == after["payload"]["sections"]["resources"] and deaths.is_empty() and damages.is_empty(), "no RNG or world effects")
	var group := [{"source":&"first","target":&"victim","damage":50},{"source":&"second","target":&"victim","damage":80},{"source":&"third","target":&"victim","damage":80}]
	q = plan({&"victim":10},group)
	check(q.get("accepted",false), "overkill")
	if q.get("accepted",false):
		var row: Dictionary = q["data"]["targets"][0]
		check(row["total_damage"] == 210 and row["hp_lost"] == 10 and row["killer_candidates"] == [&"second",&"third"] and q["data"]["requires_tiebreak"], "killer based on full damage, tie left unresolved")
		group.reverse()
		check(plan({&"victim":10},group)["data"] == q["data"], "input order does not alter results")
	var arrows := [{"source":&"archer","hit_id":&"projectile:1","target":&"victim","damage":8},{"source":&"archer","hit_id":&"projectile:2","target":&"victim","damage":8}]
	var repeated := plan({&"victim":10},arrows)
	check(repeated.get("accepted",false) and repeated["data"]["targets"][0]["total_damage"]==16 and repeated["data"]["targets"][0]["killer_candidates"]==[&"archer"] and not repeated["data"]["requires_tiebreak"],"distinct hits from same source aggregated without fake killer tie")
	arrows[1]["hit_id"]=&"projectile:1"
	check(not plan({&"victim":10},arrows).get("accepted",true),"duplicate impact ID rejected")
	var alive := plan({&"victim":11}, [{"source":&"a","target":&"victim","damage":5}, {"source":&"b","target":&"victim","damage":5}])
	check(alive.get("accepted",false) and alive["data"]["targets"][0]["hp_after"] == 1 and alive["data"]["targets"][0]["killer_candidates"].is_empty() and not alive["data"]["requires_tiebreak"], "survivor has no killer")
	var zero := plan({&"victim":10},[{"source":&"a","target":&"victim","damage":0}])
	check(zero.get("accepted",false) and zero["data"]["targets"][0]["hp_after"] == 10, "zero damage")
	check(plan({},[]).get("accepted",false), "empty batch")
	var bad := [
		[{&"a":0},[{"source":&"b","target":&"a","damage":2}]],
		[{&"a":10},[{"source":&"b","target":&"a","damage":1.5}]],
		[{&"a":10},[{"source":&"b","target":&"a","damage":-1}]],
		[{&"a":10},[{"source":&"b","target":&"missing","damage":1}]],
		[{&"a":10},[{"source":&"b","target":&"a","damage":2},{"source":&"b","target":&"a","damage":3}]],
		[{"a":10},[]]
	]
	for row in bad: check(not plan(row[0],row[1]).get("accepted",true), "invalid batch rejected")
	print("Simultaneous damage plan tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
