extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, text: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",text)
func ask(id: StringName, e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func button(game: Control, pos: Vector2, down: bool) -> void:
	var e := InputEventMouseButton.new(); e.position = game.get_global_transform_with_canvas() * pos; e.button_index = MOUSE_BUTTON_RIGHT; e.pressed = down; game._input(e)
func motion(game: Control, pos: Vector2) -> void:
	var e := InputEventMouseMotion.new(); e.position = game.get_global_transform_with_canvas() * pos; game._input(e)
func anchor(game: Node) -> Vector2i:
	return ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	var game = load("res://game_demo.tscn").instantiate(); root.add_child(game); await process_frame
	game.set_process(false); game.size = Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	var center: Vector2 = game._map_origin()+game._camera_center_world()*game.STEP_PX
	var start := anchor(game)
	button(game,center+Vector2(120,0),true)
	check(driver.is_action_active,"press starts movement")
	game._repeat_mouse_hold(0.3)
	for i in range(4):
		driver.advance_steps(100); game._repeat_mouse_hold(0.01)
	var after := anchor(game)
	check(after.x >= start.x+3 and game._mouse_hold_active,"holding follows cursor as camera moves")
	motion(game,center+Vector2(-120,0))
	driver.advance_steps(100); game._repeat_mouse_hold(0.01)
	driver.advance_steps(100); game._repeat_mouse_hold(0.01)
	driver.advance_steps(100); game._repeat_mouse_hold(0.01)
	var turned := anchor(game)
	check(turned.x < after.x,"cursor changes direction while held")
	motion(game,Vector2(-10,-10)); driver.advance_steps(100); game._repeat_mouse_hold(0.01)
	check(not driver.is_action_active,"outside map stops repeating")
	motion(game,center+Vector2(100,0)); game._repeat_mouse_hold(0.01); check(driver.is_action_active,"returns to map and resumes")
	button(game,center+Vector2(100,0),false); driver.advance_steps(100); await process_frame; game._repeat_mouse_hold(1.0)
	check(not driver.is_action_active and not game._mouse_hold_down,"release ends held path after current step")
	button(game,center+Vector2(100,0),true); button(game,center+Vector2(100,0),false)
	check(driver.is_action_active and not game._mouse_hold_down,"short click still starts normal path")
	var loops := 0
	while loops < 15 and driver.is_action_active:
		driver.advance_steps(100); await process_frame; loops += 1
	check(not driver.is_action_active,"short click path completes")
	button(game,center+Vector2(-100,0),true); game._repeat_mouse_hold(0.3)
	game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT); driver.advance_steps(100); await process_frame
	check(not driver.is_action_active and not game._mouse_hold_down,"focus loss cancels held path")
	game.queue_free(); await process_frame
	print("Game demo mouse hold: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
