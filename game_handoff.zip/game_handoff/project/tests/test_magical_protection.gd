extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func prot() -> Dictionary: return ask(&"MagicalProtectionGetRequested", {"entity":&"hero"})
func add(id: String, value: float) -> bool:
	return ask(&"PipelineModifierRegisterRequested", {"entity":&"hero","modifier":{"id":id,"target":"protection.magical","stage":"additive","op":"add","value":value}}).get("accepted",false)
func remove(id: String) -> bool: return ask(&"PipelineModifierRemoveRequested", {"entity":&"hero","id":id}).get("accepted",false)
func hp() -> float: return float(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["current"])
func set_hp(n: int) -> void: check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"HP","value":n}).get("accepted",false),"set HP")
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(not ask(&"MagicalProtectionGetRequested", {"entity":&"missing"}).get("found",true),"unknown entity")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"hero")
	check(prot().get("percent",null) == 0.0,"default zero")
	check(add("plus",1.234) and add("minus",-1.234),"add opposite")
	check(prot().get("percent",null) == 0.0 and prot()["sources"][0]["percent"] == -1.24 and prot()["sources"][1]["percent"] == 1.24,"each rounded away then summed")
	check(add("large",100.0) and prot()["percent"] == 75.0,"upper cap")
	check(remove("large") and remove("plus") and remove("minus") and add("negative",-20.0) and prot()["percent"] == -20.0,"negative allowed")
	check(not ask(&"PipelineModifierRegisterRequested", {"entity":&"hero","modifier":{"id":"bad","target":"protection.magical","stage":"multiplicative","op":"multiply","value":2}}).get("accepted",true),"unsupported pipeline operation rejected")
	set_hp(20)
	check(ask(&"CombatDamageRequested", {"entity":&"hero","amount":5,"damage_type":"magical"}).get("accepted",false) and hp() == 14,"negative defense increases direct magic")
	check(remove("negative") and add("half",50.0),"half defense")
	set_hp(20)
	check(ask(&"CombatDamageRequested", {"entity":&"hero","amount":5,"damage_type":"magical"}).get("accepted",false) and hp() == 17,"magical direct rounds up after protection")
	set_hp(20)
	check(ask(&"PeriodicEffectApplyRequested", {"entity":&"hero","effect":&"magic_dot","damage_type":"magical","damage_per_tick":1.2,"base_duration":1.0}).get("accepted",false) and driver.wait_for(1.0) and driver.advance_steps(50) == 50 and hp() == 20,"periodic magic accumulates protected fraction")
	check(driver.advance_steps(50) == 50 and hp() == 19,"periodic magic second tick")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and remove("half") and prot()["percent"] == 0.0 and ask(&"SessionLoadRequested",{}).get("accepted",false) and prot()["percent"] == 50.0,"modifier persists through save")
	var broken := func(e):
		if e.get("entity",null) == &"hero": e["found"] = false; e["error"] = "broken"
	bus.subscribe(&"MagicalProtectionGetRequested",broken)
	var before := hp()
	check(not ask(&"CombatDamageRequested", {"entity":&"hero","amount":5,"damage_type":"magical"}).get("accepted",true) and hp() == before,"direct failure closed")
	var errors := {"n":0}
	var failure := func(_e): errors["n"] += 1
	bus.subscribe(&"PeriodicEffectFailed",failure)
	check(ask(&"PeriodicEffectApplyRequested", {"entity":&"hero","effect":&"broken_dot","damage_type":"magical","damage_per_tick":5,"base_duration":0.5}).get("accepted",false) and driver.wait_for(0.5) and driver.advance_steps(50) == 50 and hp() == before and errors["n"] == 1,"periodic failure closed")
	bus.unsubscribe(&"PeriodicEffectFailed",failure); bus.unsubscribe(&"MagicalProtectionGetRequested",broken)
	check(prot().get("found",false) and prot()["percent"] == 50.0,"restored provider")
	print("Magical protection tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
