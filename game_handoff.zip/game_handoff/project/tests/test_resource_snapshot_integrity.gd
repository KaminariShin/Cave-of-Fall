extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, event: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,event)
	return event
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false),"entity")
	var saver = root.get_node("SaveService")
	var snapshot: Dictionary = saver.collect_world_transition_snapshot()
	check(snapshot.get("valid",false),"original snapshot valid")
	var payload: Dictionary = snapshot["payload"]
	check(saver._validate_snapshot(payload),"validate original")
	for resource in [&"HP",&"Stamina",&"MP"]:
		for item in [["current",-1.0],["current",INF],["current",NAN],["current",1000000.0],["current",null],["remainder",-0.1],["remainder",1.0],["remainder",INF],["remainder",null],["timer",-1.0],["timer",INF],["timer",null]]:
			var broken: Dictionary = payload.duplicate(true)
			broken["sections"]["entities"][&"hero"][&"resources"][resource][item[0]] = item[1]
			check(not saver._validate_snapshot(broken), "reject %s %s %s" % [resource,item[0],item[1]])
		var fractional: Dictionary = payload.duplicate(true)
		fractional["sections"]["entities"][&"hero"][&"resources"][resource]["current"] = 0.5
		check(saver._validate_snapshot(fractional),"fractional current remains supported for now " + str(resource))
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"normal save and restore")
	print("Resource snapshot integrity tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
