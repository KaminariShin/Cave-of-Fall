extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func apply(id: StringName,amount: int) -> bool:
	return ask(&"PeriodicEffectApplyRequested", {"entity":&"npc","effect":id,"source":&"hero","damage_type":"magical","damage_per_tick":amount,"base_duration":2.0}).get("accepted",false)
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"entities")
	var maximum: int = int(ask(&"ResourceGetRequested", {"entity":&"npc","resource":&"HP"})["data"]["max"])
	var threshold := ceili(float(maximum)/4.0)
	check(threshold >= 2 and apply(&"a",threshold-1) and apply(&"b",threshold-1),"two small effects")
	check(ask(&"ActionStartRequested", {"entity":&"npc","action":&"attack","duration":5.0}).get("accepted",false) and driver.wait_for(2.0),"start")
	var rows := []
	var on_result := func(e): rows.append(e.duplicate(true))
	var bus = root.get_node("EventBus")
	bus.subscribe(&"DirectDamageStaggerResolved",on_result)
	check(driver.advance_steps(50) == 50 and rows.is_empty() and ask(&"ActionGetRequested", {"entity":&"npc"})["data"]["id"] == &"attack","separate small ticks do not sum")
	check(ask(&"PeriodicEffectRemoveRequested", {"entity":&"npc","effect":&"a"}).get("accepted",false) and ask(&"PeriodicEffectRemoveRequested", {"entity":&"npc","effect":&"b"}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"HP","value":maximum}).get("accepted",false),"reset")
	check(apply(&"a",threshold) and apply(&"b",threshold),"two triggering effects")
	check(driver.advance_steps(50) == 50 and rows.size() == 2 and rows[0].get("accepted",false) and rows[0]["data"].get("applied",false) and rows[1].get("accepted",false) and rows[1]["data"].get("refreshed",false) and ask(&"ActionGetRequested", {"entity":&"npc"})["data"]["id"] == &"stagger","separate triggering ticks apply then refresh")
	bus.unsubscribe(&"DirectDamageStaggerResolved",on_result)
	print("Periodic damage stagger tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
