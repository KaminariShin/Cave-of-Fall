extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func setup_map() -> bool:
	return ask(&"SpaceMapConfigureRequested", {"size":Vector2i(120,120)}).get("accepted", false) and ask(&"RoomCreateRequested", {"id":&"start", "type":"start", "origin_cell":Vector2i(1,7), "size_cells":Vector2i(11,11)}).get("accepted", false) and ask(&"RoomExitAddRequested", {"room":&"start", "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false)
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus = root.get_node("EventBus")
	var fixed_float := func(e): e["value"] = 0.0
	var fixed_int := func(e): e["value"] = e["min"]
	bus.subscribe(&"RngFloatRequested", fixed_float)
	bus.subscribe(&"RngIntRequested", fixed_int)
	check(setup_map(), "setup protected existing floor")
	var existing_tile := Vector2i(50,85)
	check(ask(&"SpaceTilesSetRequested", {"tiles":[existing_tile], "kind":1}).get("accepted", false), "place unrelated existing floor")
	var guarded := ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"})
	check(guarded.get("accepted", false), "find alternate position around existing floor")
	check(ask(&"SpaceTileGetRequested", {"tile":existing_tile}).get("kind", 0) == 1, "existing floor preserved")
	if guarded.get("accepted", false):
		var child: Dictionary = ask(&"RoomGetRequested", {"id":guarded["child"]})["data"]
		check(not Rect2i(child["origin_cell"] * 4, child["size_cells"] * 4).has_point(existing_tile), "new room does not overwrite existing floor")
	check(setup_map(), "setup create retry")
	var state := {"injected":false, "first_tiles":[], "created":0}
	var fail_first_floor := func(e):
		if not state["injected"] and e.get("kind", null) == 1 and e.get("tiles", []).size() > 1000:
			state["injected"] = true
			state["first_tiles"] = e["tiles"].duplicate()
			e["accepted"] = false
	var on_created := func(e):
		if e.get("room", &"") != &"start": state["created"] += 1
	bus.subscribe(&"SpaceTilesSetRequested", fail_first_floor)
	bus.subscribe(&"RoomCreated", on_created)
	var result := ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"})
	bus.unsubscribe(&"SpaceTilesSetRequested", fail_first_floor)
	check(state["injected"] and result.get("accepted", false), "retry after create floor failure")
	check(state["created"] == 1, "only committed room announced")
	if result.get("accepted", false):
		var room: Dictionary = ask(&"RoomGetRequested", {"id":result["child"]})["data"]
		var bounds := Rect2i(room["origin_cell"] * 4, room["size_cells"] * 4)
		var clear := true
		for tile in state["first_tiles"]:
			if not bounds.has_point(tile) and ask(&"SpaceTileGetRequested", {"tile":tile}).get("kind", -1) != 0:
				clear = false
				break
		check(clear, "failed room floor outside successful room rolled back")
	bus.unsubscribe(&"RoomCreated", on_created)
	check(setup_map(), "setup exit retry")
	var exit_state := {"injected":false, "created":0}
	var fail_entry_repair := func(e):
		if exit_state["injected"]: return
		var candidate := ask(&"RoomGetRequested", {"id":&"room_1"})
		if candidate.get("found", false) and candidate["data"]["exits"].size() == 2:
			exit_state["injected"] = true
			e["accepted"] = false
	var committed := func(e):
		if e.get("room", &"") != &"start": exit_state["created"] += 1
	bus.subscribe(&"SpaceRegionGetRequested", fail_entry_repair)
	bus.subscribe(&"RoomCreated", committed)
	result = ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"})
	bus.unsubscribe(&"SpaceRegionGetRequested", fail_entry_repair)
	bus.unsubscribe(&"RoomCreated", committed)
	check(exit_state["injected"] and result.get("accepted", false), "retry after entry repair failure")
	check(exit_state["created"] == 1, "rolled-back room is not announced")
	var rooms: Dictionary = ask(&"RoomAllGetRequested", {})["rooms"]
	check(rooms.size() == 2 and rooms[&"start"]["exits"][0]["connected"], "no orphan after successful retry")
	if result.get("accepted", false):
		var child: Dictionary = rooms[result["child"]]
		check(child["exits"].size() == 2, "passage has entry and required outgoing exit")
	check(setup_map(), "setup offset retry")
	var offset_test := {"injected":false, "center":6}
	# The selected parent exit aligns a 12x12 passage at (12,11). Its
	# north-facing centre offset is checked before any room tiles are written.
	var blocked_center_tile := Vector2i(12,11) * 4 + Vector2i(24,0)
	var block_center_once := func(e):
		if not offset_test["injected"] and e.get("tile", null) == blocked_center_tile:
			offset_test["injected"] = true
			e["occupant"] = &"injected_blocker"
	bus.subscribe(&"SpaceTileGetRequested", block_center_once)
	result = ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"})
	bus.unsubscribe(&"SpaceTileGetRequested", block_center_once)
	check(offset_test["injected"] and result.get("accepted", false), "retry another outgoing exit offset")
	if result.get("accepted", false):
		var child: Dictionary = ask(&"RoomGetRequested", {"id":result["child"]})["data"]
		var outgoing: Array = child["exits"].filter(func(ex): return ex["id"] == &"out_0")
		check(outgoing.size() == 1 and outgoing[0]["dirOut"] == "north" and outgoing[0]["offset_cells"] != offset_test["center"], "same direction uses alternate offset")
	check(setup_map(), "setup blocked rollback")
	var bad := {"injected":false, "incomplete":false, "created":0}
	var corrupt_passage_reply := func(e):
		if bad["injected"] or not e.get("enabled", false): return
		var candidate := ask(&"RoomGetRequested", {"id":&"room_1"})
		if candidate.get("found", false) and candidate["data"]["exits"].size() == 1:
			bad["injected"] = true
			e["accepted"] = false
	var failed := func(_e): bad["incomplete"] = true
	var room_notice := func(e):
		if e.get("room", &"") != &"start": bad["created"] += 1
	bus.subscribe(&"SpacePassageSetRequested", corrupt_passage_reply)
	bus.subscribe(&"RoomGenerationIncomplete", failed)
	bus.subscribe(&"RoomCreated", room_notice)
	result = ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"})
	bus.unsubscribe(&"SpacePassageSetRequested", corrupt_passage_reply)
	bus.unsubscribe(&"RoomGenerationIncomplete", failed)
	bus.unsubscribe(&"RoomCreated", room_notice)
	check(bad["injected"] and bad["incomplete"] and not result.get("accepted", false) and result.has("orphan_room"), "blocked rollback reports incomplete and stops")
	check(bad["created"] == 0, "damaged candidate was not announced as created")
	check(not ask(&"RoomGetRequested", {"id":&"start"})["data"]["exits"][0]["connected"], "parent not falsely connected")
	check(ask(&"RoomGenerationStatusGetRequested", {}).get("incomplete", false), "incomplete state exposed")
	check(not ask(&"SessionSaveRequested", {}).get("accepted", false), "broken map cannot be saved")
	check(not ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"}).get("accepted", false), "generation blocked after unsafe rollback")
	check(not ask(&"RoomCreateRequested", {"id":&"other", "type":"start", "origin_cell":Vector2i(0,0), "size_cells":Vector2i(11,11)}).get("accepted", false), "manual room creation blocked after unsafe rollback")
	check(setup_map() and not ask(&"RoomGenerationStatusGetRequested", {}).get("incomplete", true), "new map clears incomplete state")
	bus.unsubscribe(&"RngFloatRequested", fixed_float)
	bus.unsubscribe(&"RngIntRequested", fixed_int)
	print("Room retry transaction tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
