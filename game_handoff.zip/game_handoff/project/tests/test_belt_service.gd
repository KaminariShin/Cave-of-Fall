extends SceneTree
var failures := 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"MaterialRegisterRequested", {"material": {"id": "mat", "name": "Mat", "weight_per_unit": 1, "volume_per_unit": 1, "level": 1}})["accepted"], "material")
	for base in [{"id": "belt", "name": "belt", "slot": "belt", "materials": [{"material_id": "mat", "count": 1}]}, {"id": "ring", "name": "ring", "slot": "ring", "materials": [{"material_id": "mat", "count": 1}]}]:
		check(ask(bus, &"ItemBaseRegisterRequested", {"base": base})["accepted"], "base")
	for item in [{"id": "belt1", "base_id": "belt"}, {"id": "belt2", "base_id": "belt"}, {"id": "ring1", "base_id": "ring"}]:
		item["item_level"] = 1
		check(ask(bus, &"ItemCreateRequested", item)["accepted"], "item")
	check(ask(bus, &"BeltTypeRegisterRequested", {"definition": {"id": "heavy", "slots_min": 3}})["accepted"], "belt type")
	check(not ask(bus, &"BeltTypeRegisterRequested", {"definition": {"id": "bad", "slots_min": 7}})["accepted"], "minimum exceeds six")
	check(ask(bus, &"BeltModuleTypeRegisterRequested", {"definition": {"id": "small", "slots": 1}})["accepted"], "small type")
	check(ask(bus, &"BeltModuleTypeRegisterRequested", {"definition": {"id": "large", "slots": 2}})["accepted"], "large type")
	check(not ask(bus, &"BeltModuleTypeRegisterRequested", {"definition": {"id": "invalid", "slots": 0}})["accepted"], "positive module size")
	check(not ask(bus, &"BeltInitializeRequested", {"item": &"ring1", "type_id": &"heavy"})["accepted"], "non-belt rejected")
	check(ask(bus, &"BeltInitializeRequested", {"item": &"belt1", "type_id": &"heavy"})["accepted"], "default min slots")
	check(ask(bus, &"BeltInitializeRequested", {"item": &"belt2", "type_id": &"heavy", "slots": 6})["accepted"], "other belt")
	var data: Dictionary = ask(bus, &"BeltGetRequested", {"item": &"belt1"})["data"]
	check(data["slots"] == 3 and data["slots_min"] == 3 and data["slots_max"] == 6, "slot limits")
	check(ask(bus, &"BeltModuleInstallRequested", {"item": &"belt1", "module": &"m1", "type_id": &"large"})["accepted"], "install two slots")
	check(ask(bus, &"BeltModuleInstallRequested", {"item": &"belt1", "module": &"m2", "type_id": &"small"})["accepted"], "fill remaining")
	check(not ask(bus, &"BeltModuleInstallRequested", {"item": &"belt1", "module": &"m3", "type_id": &"small"})["accepted"], "overflow rejected")
	check(not ask(bus, &"BeltModuleInstallRequested", {"item": &"belt2", "module": &"m1", "type_id": &"large"})["accepted"], "duplicate module rejected")
	check(not ask(bus, &"BeltSlotsSetRequested", {"item": &"belt1", "slots": 7})["accepted"], "max six")
	check(ask(bus, &"BeltSlotsSetRequested", {"item": &"belt1", "slots": 4})["accepted"], "increase")
	check(ask(bus, &"BeltModuleInstallRequested", {"item": &"belt1", "module": &"m3", "type_id": &"small"})["accepted"], "install fourth")
	check(not ask(bus, &"BeltSlotsSetRequested", {"item": &"belt1", "slots": 3})["accepted"], "cannot shrink below used")
	var save := ask(bus, &"SessionSaveRequested", {})
	check(save.get("accepted", false), "save: " + str(save))
	check(ask(bus, &"BeltModuleRemoveRequested", {"item": &"belt1", "module": &"m3"})["accepted"], "remove")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load")
	data = ask(bus, &"BeltGetRequested", {"item": &"belt1"})["data"]
	check(data["used_slots"] == 4 and data["modules"].size() == 3, "restore slots and modules")
	print("Belt tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
