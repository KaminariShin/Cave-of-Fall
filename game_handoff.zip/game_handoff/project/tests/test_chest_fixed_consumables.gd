extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11)}).get("accepted",false), "chest")
	check(ask(&"EntityCreateRequested", {"entity":&"probe"}).get("accepted",false), "probe")
	var state := {"calls":0, "fail_at":11, "mutate":false, "save":true, "nested":true}
	var rng := func(e):
		state["calls"] += 1
		var i: int = state["calls"]
		e["value"] = 40 if i in [2,4,6,8] else e["min"]
		if i == 10:
			state["save"] = ask(&"SessionSaveRequested",{}).get("accepted", true)
			state["nested"] = ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12}).get("accepted", true)
			if state["mutate"]: ask(&"StatBaseSetRequested", {"entity":&"probe", "stat":&"CON", "value":44.0})
		if i == 11: e["value"] = e["max"]
		if i == state["fail_at"]: e["value"] = e["max"] + 1
	bus.subscribe(&"RngIntRequested", rng)
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var failed := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	check(not failed.get("accepted",true) and failed.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "bad consumable level roll restores entire world")
	check(not state["save"] and not state["nested"], "save and nested attachment blocked")
	state["calls"] = 0; state["fail_at"] = -1; state["mutate"] = true
	var mutation := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	check(not mutation.get("accepted",true) and mutation.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "foreign world mutation rejected and restored")
	state["calls"] = 0; state["mutate"] = false
	var result := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	bus.unsubscribe(&"RngIntRequested", rng)
	check(result.get("accepted",false), "attach")
	if not result.get("accepted",false): quit(1); return
	var draft: Dictionary = result["draft"].duplicate(true)
	for i in range(4):
		var slot: Dictionary = draft["slots"][i]
		check(slot["category"] == "consumable" and slot["base_id"] == &"potion_hp" and slot["item_level"] == (6 if i == 1 else 5) and slot["rarity"] == &"normal" and slot["mods"].is_empty() and slot["materials"] == [{"material_id":"potion_pack","count":1}], "fixed consumable attributes %d" % i)
	check(not draft["complete"] and saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["instances"] == before["payload"]["sections"]["items"]["instances"], "incomplete, no instances")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save")
	var f := FileAccess.open("user://session.save", FileAccess.READ)
	var saved: Dictionary = bytes_to_var(f.get_buffer(f.get_length())); f.close()
	for kind in [0,1,2,3]:
		var bad: Dictionary = saved.duplicate(true)
		var slot: Dictionary = bad["sections"]["objects"]["objects"][&"chest"]["content_draft"]["slots"][0]
		match kind:
			0: slot["item_level"] = 99
			1: slot["materials"][0]["material_id"] = "cloth_light"
			2: slot["mods"] = [{"id":&"bad"}]
			3: slot["rarity"] = &"magic"
		f = FileAccess.open("user://session.save", FileAccess.WRITE); f.store_buffer(var_to_bytes(bad)); f.close()
		check(not ask(&"SessionLoadRequested",{}).get("accepted",true), "reject invalid consumable %d" % kind)
	f = FileAccess.open("user://session.save", FileAccess.WRITE); f.store_buffer(var_to_bytes(saved)); f.close()
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ObjectGetRequested", {"object":&"chest"})["data"]["content_draft"] == draft, "fixed consumables survive save/load")
	print("Fixed chest consumables tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
