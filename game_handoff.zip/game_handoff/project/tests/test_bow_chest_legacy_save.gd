extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bytes := FileAccess.get_file_as_bytes("res://tests/fixtures/chest_before_physical_affix.save")
	check(not bytes.is_empty(),"legacy fixture present")
	var old = bytes_to_var(bytes)
	check(old is Dictionary,"legacy snapshot format")
	if not old is Dictionary: quit(1); return
	var slot: Dictionary = old["sections"]["objects"]["objects"][&"chest"]["content_draft"]["slots"][0]
	check(slot["base_id"] == &"sword_simple" and slot["mods"].size()==3,"old incomplete pool fixture")
	var saver = root.get_node("SaveService")
	check(saver._validate_snapshot(old),"old snapshot validates")
	var file := FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(bytes); file.close()
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"old session loads")
	check(ask(&"ObjectGetRequested",{"object":&"chest"})["data"]["content_draft"]["slots"][0]==slot,"old loot not rerolled")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"resave and reload")
	var bad: Dictionary = old.duplicate(true)
	bad["sections"]["objects"]["objects"][&"chest"]["content_draft"]["slots"][0]["mods"][0]["value"] = 999
	check(not saver._validate_snapshot(bad),"corrupted existing modifier rejected")
	print("Bow chest legacy save: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
