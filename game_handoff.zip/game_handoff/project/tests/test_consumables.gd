extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(name: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(name, e)
	return e
func create(id: StringName, base: StringName) -> bool:
	return ask(&"ItemCreateRequested", {"id":id, "base_id":base, "item_level":1}).get("accepted", false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":id}).get("accepted", false)
func effect(id: StringName) -> bool:
	return ask(&"PeriodicEffectGetRequested", {"entity":&"hero", "effect":id}).get("found", false)
func apply(id: StringName, damage: float = 1.0) -> bool:
	return ask(&"PeriodicEffectApplyRequested", {"entity":&"hero", "effect":id, "damage_type":"physical", "damage_per_tick":damage, "base_duration":3.0}).get("accepted", false)
func hp() -> float:
	return float(ask(&"ResourceGetRequested", {"entity":&"hero", "resource":&"HP"})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted", false), "inventory")
	for base in [&"antidote", &"bandage", &"potion_hp", &"potion_stamina", &"potion_mana", &"sword_simple"]:
		check(ask(&"ItemBaseGetRequested", {"base_id":base}).get("found", false), "ruleset base loaded " + str(base))
	check(create(&"a1", &"antidote") and create(&"a2", &"antidote") and create(&"b1", &"bandage") and create(&"p1", &"potion_hp"), "create consumables")
	check(ask(&"EntityCreateRequested", {"entity":&"other"}).get("accepted", false), "other entity")
	check(ask(&"InventoryConfigureRequested", {"entity":&"other", "volume":10}).get("accepted", false), "other inventory")
	var race := {"attempted":false, "added":false, "saved":false}
	var on_removed := func(e):
		if e.get("item", null) != &"a1": return
		race["attempted"] = true
		race["added"] = ask(&"InventoryAddRequested", {"entity":&"other", "item":&"a1"}).get("accepted", false)
		race["saved"] = ask(&"SessionSaveRequested", {}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"InventoryItemRemoved", on_removed)
	check(apply(&"poison"), "poison")
	check(ask(&"ConsumableUseRequested", {"entity":&"hero", "item":&"a1"}).get("accepted", false), "begin antidote")
	check(not ask(&"ItemGetRequested", {"item":&"a1"}).get("found", false), "item consumed on start")
	check(race["attempted"] and not race["added"] and not race["saved"], "consumption blocks reentrant add and save")
	root.get_node("EventBus").unsubscribe(&"InventoryItemRemoved", on_removed)
	check(not ask(&"ItemCreateRequested", {"id":&"a1", "base_id":&"antidote", "item_level":1}).get("accepted", false), "consumed id cannot be reused")
	driver.advance_steps(10)
	check(ask(&"ActionInterruptRequested", {"entity":&"hero", "action":&"stagger", "duration":0.2}).get("accepted", false), "interrupt")
	check(effect(&"poison") and not ask(&"ItemGetRequested", {"item":&"a1"}).get("found", false), "interrupted item not returned and effect remains")
	driver.advance_steps(20)
	check(ask(&"ConsumableUseRequested", {"entity":&"hero", "item":&"a2"}).get("accepted", false), "second antidote")
	driver.advance_steps(20)
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save mid use")
	driver.advance_steps(30)
	check(not effect(&"poison"), "antidote clears poison")
	check(ask(&"SessionLoadRequested", {}).get("accepted", false), "restore mid use")
	check(effect(&"poison") and not ask(&"ItemGetRequested", {"item":&"a2"}).get("found", false), "consumed item remains consumed after load")
	driver.advance_steps(30)
	check(not effect(&"poison"), "restored action clears poison")
	check(apply(&"bleeding", 0.0), "apply bleed")
	check(ask(&"ConsumableUseRequested", {"entity":&"hero", "item":&"b1"}).get("accepted", false), "start bandage")
	driver.advance_steps(50)
	check(not effect(&"bleeding"), "bandage clears bleeding")
	check(apply(&"bleeding", 0.0), "bleed again")
	var full: Dictionary = ask(&"ResourceGetRequested", {"entity":&"hero", "resource":&"HP"})["data"]
	ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"HP", "value":full["max"]})
	check(ask(&"ConsumableUseRequested", {"entity":&"hero", "item":&"p1"}).get("accepted", false), "heal even at full hp")
	driver.advance_steps(50)
	check(not effect(&"bleeding") and hp() == float(full["max"]), "active healing clears bleed even at full hp")
	check(create(&"a3", &"antidote") and apply(&"poison"), "prepare coincident cure")
	var before := hp()
	check(ask(&"ConsumableUseRequested", {"entity":&"hero", "item":&"a3"}).get("accepted", false), "cure at tick boundary")
	driver.advance_steps(50)
	check(hp() == before - 1.0 and not effect(&"poison"), "poison tick occurs before coincident cure")
	check(create(&"s1", &"potion_stamina") and create(&"m1", &"potion_mana"), "other potion bases")
	for pair in [[&"s1", &"Stamina"], [&"m1", &"MP"]]:
		var state: Dictionary = ask(&"ResourceGetRequested", {"entity":&"hero", "resource":pair[1]})["data"]
		check(ask(&"ResourceSetRequested", {"entity":&"hero", "resource":pair[1], "value":0}).get("accepted", false), "empty resource")
		check(ask(&"ConsumableUseRequested", {"entity":&"hero", "item":pair[0]}).get("accepted", false), "use resource potion")
		driver.advance_steps(50)
		var restored: Dictionary = ask(&"ResourceGetRequested", {"entity":&"hero", "resource":pair[1]})["data"]
		check(float(restored["current"]) >= minf(20.0, float(state["max"])), "potion restores resource and respects maximum")
	print("Consumable tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
