extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, text: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func item_found(id: StringName) -> bool:
	return ask(&"ItemGetRequested", {"item":id}).get("found", false)
func ground() -> Dictionary:
	return ask(&"LootGetRequested", {})["items"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(48,48)}).get("accepted", false), "map")
	var floor_tiles: Array = []
	for x in range(48):
		for y in range(48): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles, "kind":1}).get("accepted", false), "floor")
	for id in [&"hero", &"victim"]:
		check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted", false), "create entity")
		check(ask(&"InventoryConfigureRequested", {"entity":id, "volume":20}).get("accepted", false), "inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(2,2), "size":2}).get("accepted", false), "hero body")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"victim", "anchor":Vector2i(10,10), "size":2}).get("accepted", false), "victim body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"MaterialRegisterRequested", {"material":{"id":"cleanup_mat", "name":"Material", "weight_per_unit":1, "volume_per_unit":1, "level":1}}).get("accepted", false), "material")
	check(ask(&"ItemBaseRegisterRequested", {"base":{"id":"cleanup_belt", "name":"Belt", "slot":"belt", "materials":[{"material_id":"cleanup_mat", "count":1}]}}).get("accepted", false), "belt base")
	check(ask(&"BeltTypeRegisterRequested", {"definition":{"id":"cleanup_belt_type", "slots_min":1}}).get("accepted", false), "belt type")
	check(ask(&"BeltModuleTypeRegisterRequested", {"definition":{"id":"cleanup_module_type", "slots":1}}).get("accepted", false), "module type")
	for spec in [[&"dropped_belt", &"cleanup_belt", &"victim"], [&"dropped_potion", &"potion_hp", &"victim"], [&"player_potion", &"potion_hp", &"hero"]]:
		check(ask(&"ItemCreateRequested", {"id":spec[0], "base_id":spec[1], "item_level":1}).get("accepted", false), "item creation")
		check(ask(&"InventoryAddRequested", {"entity":spec[2], "item":spec[0]}).get("accepted", false), "give item")
	check(ask(&"BeltInitializeRequested", {"item":&"dropped_belt", "type_id":&"cleanup_belt_type"}).get("accepted", false), "belt metadata")
	check(ask(&"BeltModuleInstallRequested", {"item":&"dropped_belt", "module":&"module_a", "type_id":&"cleanup_module_type"}).get("accepted", false), "belt module")
	check(ask(&"CombatDamageRequested", {"entity":&"victim", "source":&"hero", "amount":999}).get("accepted", false), "kill victim")
	check(ground().size() == 2 and ground().has(&"dropped_belt"), "two genuine ground items")
	var loot = root.get_node("LootService")
	var items = root.get_node("ItemService")
	var save = root.get_node("SaveService")
	check(not loot.discard_ground_for_transition().get("accepted", false), "not available outside transition operation")
	check(not items.retire_world_items_for_transition([&"dropped_belt"]), "retirement without authorization rejected")
	var during := {}
	var trial := func():
		during["discard"] = loot.discard_ground_for_transition()
		during["item_exists"] = item_found(&"dropped_belt")
		during["belt_exists"] = ask(&"BeltGetRequested", {"item":&"dropped_belt"}).get("found", false)
		during["same_id"] = ask(&"ItemCreateRequested", {"id":&"dropped_belt", "base_id":&"cleanup_belt", "item_level":1}).get("accepted", false)
		return false
	var result: Dictionary = save.run_world_transition_transaction(trial)
	check(during["discard"].get("accepted", false) and during["discard"]["items"] == [&"dropped_belt", &"dropped_potion"], "discard all ground items")
	check(not during["item_exists"] and not during["belt_exists"] and not during["same_id"], "item retired and metadata removed inside operation")
	check(result.get("rolled_back", false) and ground().size() == 2 and item_found(&"dropped_belt") and ask(&"BeltGetRequested", {"item":&"dropped_belt"}).get("found", false), "failed operation restores loot, item and belt")
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":Vector2i(10,10)}).get("accepted", false), "reach loot")
	check(ask(&"LootPickupRequested", {"entity":&"hero", "item":&"dropped_potion", "duration":0.1}).get("accepted", false), "start pickup")
	var rejected := {}
	result = save.run_world_transition_transaction(func(): rejected["result"] = loot.discard_ground_for_transition(); return true)
	check(result.get("committed", false) and not rejected["result"].get("accepted", true) and ground().size() == 2, "pending pickup prevents cleanup without cancellation")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted", false), "cancel pickup")
	var reentry := {"attempted":false}
	var observer := func(_e):
		if reentry["attempted"]: return
		reentry["attempted"] = true
		reentry["discard"] = loot.discard_ground_for_transition().get("accepted", false)
		reentry["steal"] = ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"dropped_potion"}).get("accepted", false)
		reentry["remove"] = ask(&"EntityRemoveRequested", {"entity":&"hero"}).get("accepted", false)
		reentry["save"] = ask(&"SessionSaveRequested", {}).get("accepted", false)
	root.get_node("EventBus").subscribe(&"EntityQueryRequested", observer)
	var cleaned := {}
	result = save.run_world_transition_transaction(func(): cleaned["result"] = loot.discard_ground_for_transition(); return cleaned["result"].get("accepted", false))
	root.get_node("EventBus").unsubscribe(&"EntityQueryRequested", observer)
	check(reentry["attempted"] and not reentry["discard"] and not reentry["steal"] and not reentry["remove"] and not reentry["save"], "reentrant operations blocked during cleanup")
	check(result.get("committed", false) and cleaned["result"].get("accepted", false), "successful cleanup committed")
	check(ground().is_empty() and not item_found(&"dropped_belt") and not item_found(&"dropped_potion") and not ask(&"BeltGetRequested", {"item":&"dropped_belt"}).get("found", false), "ground instances and belt metadata gone")
	check(item_found(&"player_potion") and ask(&"InventoryGetRequested", {"entity":&"hero"})["data"]["items"].has(&"player_potion"), "player inventory untouched")
	check(not ask(&"ItemCreateRequested", {"id":&"dropped_potion", "base_id":&"potion_hp", "item_level":1}).get("accepted", false), "retired ID cannot be reused")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and ground().is_empty() and item_found(&"player_potion"), "cleanup persists in save")
	print("Floor ground cleanup tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
