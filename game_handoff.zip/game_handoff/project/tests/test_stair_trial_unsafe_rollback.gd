extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func id(i: int) -> StringName: return StringName("chain_%d" % i)
func budget(room: StringName, value: int) -> Dictionary:
	return ask(&"DungeonDeadendBudgetAvailableRequested", {"room":room, "budget":value})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(500,250)}).get("accepted", false), "map")
	for i in range(6):
		var room_type := "start" if i == 0 else "fork"
		check(ask(&"RoomCreateRequested", {"id":id(i), "type":room_type, "origin_cell":Vector2i(10 if i == 0 else 22 + (i - 1) * 14,20), "size_cells":Vector2i(12,12) if i == 0 else Vector2i(14,14)}).get("accepted", false), "create chain room")
		if i == 0:
			check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":id(0)}).get("accepted", false), "tracking starts before children")
		else:
			check(ask(&"RoomExitAddRequested", {"room":id(i - 1), "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false), "add outgoing")
			check(ask(&"RoomExitAddRequested", {"room":id(i), "id":&"entry", "dir":"west", "offset_cells":5}).get("accepted", false), "add entry")
			check(ask(&"RoomExitConnectRequested", {"room":id(i - 1), "exit":&"east", "other_room":id(i), "other_exit":&"entry"}).get("accepted", false), "connect")
			ask(&"RoomChildGenerated", {"room":id(i - 1), "child":id(i), "type":room_type})
	check(budget(id(1),1).get("budget", -1) == 0, "reserve last deadend at early depth")
	check(budget(id(1),2).get("budget", -1) == 2, "additional early deadends remain allowed")
	check(budget(id(4),1).get("budget", -1) == 0, "child distance five still reserved")
	check(budget(id(5),1).get("budget", -1) == 1, "child distance six may use reservation")
	check(not budget(&"missing",1).get("accepted", false), "unknown parent fails closed")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":1}).get("accepted", false), "set budget")
	check(budget(id(1),0).get("budget", -1) == 0, "zero budget not fabricated")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save and restore before candidate")
	check(budget(id(1),1).get("budget", -1) == 0 and budget(id(5),1).get("budget", -1) == 1, "reservation survives restore")
	check(ask(&"RoomExitAddRequested", {"room":id(1), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "early branch")
	check(ask(&"RoomExitAddRequested", {"room":id(5), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "eligible branch")
	var force_last := func(e): e["value"] = 0.999999
	var force_min := func(e): e["value"] = e["min"]
	var state := {"injected":false, "placed":false, "announced":0}
	var damage_trial := func(e):
		if state["injected"]: return
		state["injected"] = true
		var r: Dictionary = ask(&"RoomGetRequested", {"id":e["room"]})["data"]
		var origin: Vector2i = r["origin_cell"] * 4
		var size: Vector2i = r["size_cells"] * 4
		ask(&"EntityCreateRequested", {"entity":&"trial_blocker"})
		for y in range(origin.y+1, origin.y+size.y-2):
			for x in range(origin.x+1, origin.x+size.x-2):
				if ask(&"SpaceBodyPlaceRequested", {"entity":&"trial_blocker", "anchor":Vector2i(x,y), "size":2}).get("accepted", false):
					state["placed"] = true
					break
			if state["placed"]: break
		e["accepted"] = false
	var announced := func(e):
		if str(e.get("room", "")).begins_with("room_"): state["announced"] += 1
	var bus = root.get_node("EventBus")
	bus.subscribe(&"RngFloatRequested", force_last)
	bus.subscribe(&"RngIntRequested", force_min)
	bus.subscribe(&"DungeonStairTrialRequested", damage_trial)
	bus.subscribe(&"RoomCreated", announced)
	var result := ask(&"RoomChildGenerateRequested", {"room":id(5), "exit":&"north"})
	bus.unsubscribe(&"DungeonStairTrialRequested", damage_trial)
	bus.unsubscribe(&"RoomCreated", announced)
	check(state["injected"] and state["placed"] and not result.get("accepted", true) and result.has("orphan_room"), "unsafe rollback aborts")
	check(ask(&"RoomGenerationStatusGetRequested", {}).get("incomplete", false) and not ask(&"SessionSaveRequested", {}).get("accepted", false), "incomplete state blocks save")
	check(not ask(&"RoomGetRequested", {"id":id(5)})["data"]["exits"].filter(func(ex): return ex["id"] == &"north")[0]["connected"] and state["announced"] == 0 and ask(&"DungeonFloorTrackingGetRequested", {})["data"]["stair_candidate"] == null, "parent and candidate remain uncommitted")
	check(not ask(&"RoomChildGenerateRequested", {"room":id(5), "exit":&"north"}).get("accepted", false), "further generation blocked")
	bus.unsubscribe(&"RngFloatRequested", force_last)
	bus.unsubscribe(&"RngIntRequested", force_min)
	print("Stair trial unsafe rollback tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
