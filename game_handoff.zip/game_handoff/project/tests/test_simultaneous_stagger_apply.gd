extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func resource(id: StringName,r: StringName,key: String) -> float: return float(ask(&"ResourceGetRequested", {"entity":id,"resource":r})["data"][key])
func active(id: StringName) -> Dictionary: return ask(&"ActionGetRequested", {"entity":id})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	for id in [&"hero",&"npc",&"a",&"b"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	var maximum := int(resource(&"hero",&"HP","max"))
	var threshold := ceili(maximum / 4.0)
	check(maximum == int(resource(&"npc",&"HP","max")) and threshold > 1,"fixture")
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"attack","duration":0.7}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"attack","duration":0.7}).get("accepted",false),"start attacks")
	var hits := [{"source":&"a","target":&"hero","damage":threshold},{"source":&"a","target":&"npc","damage":threshold-1},{"source":&"b","target":&"npc","damage":threshold-1}]
	var base := {"hp_by_target":{&"hero":maximum,&"npc":maximum},"hits":hits,"apply_stagger":true}
	var bad := base.duplicate(true); bad["apply_stagger"] = 1
	check(not ask(&"SimultaneousDamageApplyRequested",bad).get("accepted",true),"invalid flag rejected")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save")
	var observed := {"ok":false,"n":0,"nested":true,"save_valid":true}
	var on_interrupt := func(e):
		if e.get("entity",null) == &"hero" and e.get("action",null) == &"attack":
			observed["n"] += 1
			observed["ok"] = resource(&"hero",&"HP","current") == maximum-threshold and resource(&"npc",&"HP","current") == maximum - (threshold-1)*2
			observed["nested"] = ask(&"StaggerApplyRequested", {"target":&"npc","damage":threshold,"expected_max_hp":maximum}).get("accepted",true)
			observed["save_valid"] = root.get_node("SaveService").collect_world_transition_snapshot().get("valid",true)
	bus.subscribe(&"ActionInterrupted",on_interrupt)
	var result := ask(&"SimultaneousDamageApplyRequested",base.duplicate(true))
	check(result.get("accepted",false) and observed["n"] == 1 and observed["ok"] and not observed["nested"] and not observed["save_valid"],"all HP committed before action interruption; nested stagger and save blocked")
	if result.get("accepted",false):
		var outcomes: Array = result["data"]["stagger"]
		check(outcomes.size() == 2 and outcomes[0]["target"] == &"hero" and outcomes[0]["applied"] and outcomes[0]["sources"] == [&"a"] and outcomes[1]["target"] == &"npc" and not outcomes[1]["triggered"] and outcomes[1]["reason"] == "below_threshold","per-source non-summing and outcomes")
	check(active(&"hero")["data"]["id"] == &"stagger" and active(&"npc")["data"]["id"] == &"attack","only hero staggered")
	bus.unsubscribe(&"ActionInterrupted",on_interrupt)
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore")
	var legacy := base.duplicate(true); legacy.erase("apply_stagger")
	result = ask(&"SimultaneousDamageApplyRequested",legacy)
	check(result.get("accepted",false) and not result["data"].has("stagger") and active(&"hero")["data"]["id"] == &"attack","legacy opt out")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore again")
	check(ask(&"ActionCancelRequested", {"entity":&"npc"}).get("accepted",false) and ask(&"ActionDefinitionRegisterRequested", {"data":{"id":&"protected_test","name":"protected","type":&"utility","base_duration":1.0,"interruptible":false}}).get("accepted",false) and ask(&"ActionStartRequested", {"entity":&"npc","action":&"protected_test"}).get("accepted",false),"uninterruptible")
	result = ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"npc":maximum},"hits":[{"source":&"a","target":&"npc","damage":threshold}],"apply_stagger":true})
	check(result.get("accepted",false) and result["data"]["stagger"][0]["reason"] == "uninterruptible" and active(&"npc")["data"]["id"] == &"protected_test","noninterruptible target reports no application")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore for shield")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,30)}).get("accepted",false),"map for shield")
	var floors := []
	for x in range(30):
		for y in range(30): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"shield body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_medium","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip shield")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":2}).get("accepted",false) and ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false),"start shield block")
	result = ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":maximum},"hits":[{"source":&"a","target":&"hero","damage":4,"magical_damage":threshold,"attack_tiles":[Vector2i(10,9)]}],"block":{"target":&"hero","direction":Vector2i.UP,"expected_stamina":2},"apply_stagger":true})
	check(result.get("accepted",false) and result["data"]["block"]["absorbed"] == 4 and result["data"]["resolved_hits"][0]["damage"] == threshold and result["data"]["stagger"][0]["applied"] and active(&"hero")["data"]["id"] == &"stagger","shielded physical plus penetrating magic triggers stagger")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore lethal")
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"HP","value":threshold}).get("accepted",false),"low HP")
	result = ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"npc":threshold},"hits":[{"source":&"a","target":&"npc","damage":threshold}],"apply_stagger":true})
	check(result.get("accepted",false) and result["data"]["stagger"][0]["reason"] == "lethal" and not active(&"npc").get("found",true),"lethal target does not stagger")
	print("Simultaneous stagger apply tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
