extends SceneTree

var failures := 0

func _initialize() -> void:
	call_deferred("run_tests")

func check(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		printerr("FAIL: ", message)

func run_tests() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var turns: Array[float] = []
	driver.turn_finished.connect(func(duration): turns.append(duration))
	check(driver.advance_steps(10) == 0 and is_zero_approx(driver.game_time), "idle freezes time")
	check(not driver.wait_for(0.015), "duration must be a multiple of 0.01")
	check(driver.start_action(&"attack", 0.7), "start attack")
	check(not driver.wait_for(0.1), "reject parallel controlled action")
	check(driver.advance_steps(40) == 40, "attack progresses")
	check(driver.interrupt_with(&"stagger", 0.2), "interrupt")
	check(driver.advance_steps(100) == 20, "stagger ends after 20 steps")
	check(is_equal_approx(driver.game_time, 0.6), "game time is 0.6")
	check(turns.size() == 1 and is_equal_approx(turns[0], 0.6), "turn includes both segments")
	check(driver.wait_for(0.03), "wait starts")
	check(driver.advance_steps(10) == 3, "wait completes")
	check(is_equal_approx(driver.game_time, 0.63), "wait advances time")
	check(driver.start_action(&"attack", 0.01), "start final-step interruption test")
	var on_tick := func(_dt): driver.interrupt_with(&"replacement", 0.02)
	driver.tick.connect(on_tick, CONNECT_ONE_SHOT)
	driver.advance_steps(1)
	check(driver.current_action_id == &"replacement", "interrupt on final step wins")
	check(driver.advance_steps(3) == 2, "replacement gets full duration")
	print("Tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
