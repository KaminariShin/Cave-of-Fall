extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(begin(4), "floor four")
	for i in range(1,17): check(add_room(i, "passage"), "chain")
	check(tracking().get("boss_candidate", null) == &"node_16", "boss room chosen")
	check(ask(&"DungeonDeadendBudgetAvailableRequested", {"room":&"node_15", "budget":1}).get("budget", -1) == 0, "last deadend reserved")
	check(ask(&"DungeonDeadendBudgetAvailableRequested", {"room":&"node_15", "budget":3}).get("budget", -1) == 2, "additional deadends remain")
	check(ask(&"DungeonDeadendBudgetAvailableRequested", {"room":&"node_16", "budget":1}).get("budget", -1) == 1, "reserved budget available to boss branch")
	check(ask(&"RoomExitAddRequested", {"room":&"node_16", "id":&"south", "dir":"south", "offset_cells":5}).get("accepted", false), "outgoing")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":0}).get("accepted", false), "no budget")
	check(not ask(&"RoomChildGenerateRequested", {"room":&"node_16", "exit":&"south"}).get("accepted", true), "missing portal budget fails instead of changing room type")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":1}).get("accepted", false), "reserve budget")
	var bus = root.get_node("EventBus")
	var reject_region := func(e):
		if e.get("origin", Vector2i.ZERO).y >= 152: e["accepted"] = false
	bus.subscribe(&"SpaceRegionGetRequested", reject_region)
	var blocked := ask(&"RoomChildGenerateRequested", {"room":&"node_16", "exit":&"south"})
	bus.unsubscribe(&"SpaceRegionGetRequested", reject_region)
	check(not blocked.get("accepted", true) and tracking().get("portal_candidate", null) == null, "blocked geometry does not choose another type")
	var before_rooms: Dictionary = ask(&"RoomAllGetRequested", {}).get("rooms",{}).duplicate(true)
	var trial_count := {"n":0}
	var reject_trial := func(e): trial_count["n"] += 1; e["accepted"] = false
	bus.subscribe(&"DungeonPortalTrialRequested",reject_trial)
	var no_portal := ask(&"RoomChildGenerateRequested", {"room":&"node_16", "exit":&"south"})
	bus.unsubscribe(&"DungeonPortalTrialRequested",reject_trial)
	check(trial_count["n"] > 0 and not no_portal.get("accepted",true) and tracking().get("portal_candidate",null) == null and not ask(&"DungeonPortalGetRequested",{}).get("found",true), "failed portal preflight rejects branch")
	check(ask(&"RoomAllGetRequested",{}).get("rooms",{}) == before_rooms, "trial rooms and exits fully rolled back")
	# Изменение геометрии ПОСЛЕ успешной пробы не должно выдавать фиктивный портал.
	var state := {"trial":false,"blocked":false,"notice":false}
	var observed_trial := func(e): state["trial"] = e.get("accepted",false)
	var block_after := func(e):
		if e.get("type","") != "deadend" or not state["trial"]: return
		var room: Dictionary = ask(&"RoomGetRequested",{"id":e["room"]})["data"]
		var entry: Dictionary = room["exits"].filter(func(ex): return ex["id"] == &"entry")[0]
		var p := Vector2i(int(entry["x"]),int(entry["y"]))
		match str(entry["dirOut"]):
			"west": p.x+=1
			"east": p.x-=4
			"north": p.y+=1
			"south": p.y-=4
		ask(&"EntityCreateRequested",{"entity":&"portal_late_blocker"})
		state["blocked"] = ask(&"SpaceBodyPlaceRequested",{"entity":&"portal_late_blocker","anchor":p,"size":4}).get("accepted",false)
	var failure := func(_e): state["notice"]=true
	bus.subscribe(&"DungeonPortalTrialRequested",observed_trial)
	bus.subscribe(&"RoomCreated",block_after)
	bus.subscribe(&"DungeonPortalPlacementFailed",failure)
	var generated := ask(&"RoomChildGenerateRequested", {"room":&"node_16","exit":&"south"})
	bus.unsubscribe(&"DungeonPortalTrialRequested",observed_trial)
	bus.unsubscribe(&"RoomCreated",block_after)
	bus.unsubscribe(&"DungeonPortalPlacementFailed",failure)
	check(state["trial"] and state["blocked"] and generated.get("accepted",false),"mutation after trial")
	var portal := ask(&"DungeonPortalGetRequested",{})
	check(portal.get("found",false) and portal["data"]["status"]=="failed" and state["notice"],"failure exposed after mutation")
	check(ask(&"SpaceBodyRemoveRequested",{"entity":&"portal_late_blocker"}).get("accepted",false),"remove blocker")
	check(ask(&"DungeonPortalPlacementRetryRequested",{}).get("accepted",false) and ask(&"DungeonPortalGetRequested",{})["data"]["status"]=="placed","portal placement retry")
	print("Portal trial mutation tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
