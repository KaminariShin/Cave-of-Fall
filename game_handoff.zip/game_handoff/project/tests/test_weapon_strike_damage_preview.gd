extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func preview(actor: StringName, item: StringName, strike: String = "sword_simple_thrust") -> Dictionary:
	return ask(&"WeaponStrikeDamagePreviewRequested", {"entity":actor,"item":item,"strike":strike})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":100}).get("accepted",false), "inventories")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"STR","value":10}).get("accepted",false) and ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0}).get("accepted",false), "stats")
	var snap: Dictionary = root.get_node("SaveService").collect_world_transition_snapshot()
	var bases: Dictionary = snap["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"sword_simple",bases)
	check(ask(&"ItemCreateRequested", {"id":&"blade","base_id":&"sword_simple","item_level":20,"rarity":&"magic","materials":[{"material_id":"iron_common","count":1}],"learning":schema}).get("accepted",false), "sword")
	var mod := {"id":&"suf_physical_damage","category":"suffix","stat":"physical_damage","tier":3,"value":1.0,"level_req":1,"material_id":&"iron_common","unlock_after":5}
	check(ask(&"ItemModAttachRequested", {"item":&"blade","mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"blade"}).get("accepted",false), "mod and own")
	var q := preview(&"hero",&"blade")
	check(q.get("accepted",false) and q["data"]["stat"] == &"STR" and q["data"]["learning_multiplier"] == 0.5 and q["data"]["physical_mod_bonus"] == 0.0 and is_equal_approx(q["data"]["raw_damage"],9.375) and not q["data"]["in_hand"], "unknown base penalty and inactive mod in inventory")
	check(not preview(&"npc",&"blade").get("accepted",true), "must own")
	check(not preview(&"hero",&"blade","fake").get("accepted",true), "invalid strike")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"blade","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10, "damage mod can be equipped")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10, "unequip before transfer")
	var reveal := func(e):
		if e.get("item",null) == &"blade" and e.get("found",false): e["item_data"]["learning_state"]["progress"] = 5
	bus.subscribe(&"ItemGetRequested",reveal)
	q = preview(&"hero",&"blade")
	check(q.get("accepted",false) and q["data"]["learning_multiplier"] == 0.6 and q["data"]["physical_mod_bonus"] == 1.0 and is_equal_approx(q["data"]["raw_damage"],12.5), "projection of revealed mod at five actions")
	bus.unsubscribe(&"ItemGetRequested",reveal)
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"blade"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"blade"}).get("accepted",false), "lend unknown weapon to NPC")
	q = preview(&"npc",&"blade")
	check(q.get("accepted",false) and q["data"]["learning_multiplier"] == 1.0 and q["data"]["physical_mod_bonus"] == 1.0 and not ask(&"ItemGetRequested", {"item":&"blade"})["item_data"]["learning_state"]["identified"], "NPC applies unknown mod without identifying")
	check(ask(&"InventoryRemoveRequested", {"entity":&"npc","item":&"blade"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"blade"}).get("accepted",false), "return unknown weapon")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":100}).get("accepted",false), "raise INT")
	q = preview(&"hero",&"blade")
	check(q.get("accepted",false) and q["data"]["learning_multiplier"] == 1.0 and q["data"]["physical_mod_bonus"] == 0.0 and is_equal_approx(q["data"]["raw_damage"],18.75), "sufficient INT removes penalty without revealing mod")
	check(ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"blade"}).get("accepted",false) and driver.advance_steps(100) == 100, "identify")
	q = preview(&"hero",&"blade")
	check(q.get("accepted",false) and q["data"]["physical_mod_bonus"] == 1.0 and is_equal_approx(q["data"]["raw_damage"],20.0), "identified mod before STR multiplier")
	var corrupt := func(e):
		if e.get("item",null) == &"blade" and e.get("found",false): e["item_data"]["mods"][0]["value"] = 999
	bus.subscribe(&"ItemGetRequested",corrupt)
	check(not preview(&"hero",&"blade").get("accepted",true), "invalid mod rejected")
	bus.unsubscribe(&"ItemGetRequested",corrupt)
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and is_equal_approx(preview(&"hero",&"blade")["data"]["raw_damage"],20.0), "restore")
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"blade"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"blade"}).get("accepted",false), "transfer")
	q = preview(&"npc",&"blade")
	check(q.get("accepted",false) and q["data"]["physical_mod_bonus"] == 1.0 and q["data"]["learning_multiplier"] == 1.0, "NPC projection")
	print("Weapon strike damage preview tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
