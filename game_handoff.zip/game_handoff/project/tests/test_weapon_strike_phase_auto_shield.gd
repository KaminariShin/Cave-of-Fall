extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(id: StringName,r: StringName) -> float:
	return float(ask(&"ResourceGetRequested", {"entity":id,"resource":r})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc",&"other"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5),&"sword",&"sword_simple","main"],[&"npc",Vector2i(10,5),&"shield",&"shield_medium","off"]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"body inventory")
		check(ask(&"ItemCreateRequested", {"id":row[2],"base_id":row[3],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":row[2]}).get("accepted",false),"item")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"HP","value":20}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":1.5}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":7}).get("accepted",false),"resources")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"npc","slot":"off","direction":Vector2i.LEFT}).get("accepted",false),"block")
	var start := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(start.get("accepted",false),"strike")
	if not start.get("accepted",false): quit(1); return
	var midpoint := ceili(float(start["data"]["duration_steps"])/2.0)
	check(driver.advance_steps(midpoint-1) == midpoint-1 and ask(&"SessionSaveRequested",{}).get("accepted",false),"save before midpoint")
	var state := {"batch":false,"blocks":0,"failed":false,"error":false}
	var callback := func(e):
		if not e.get("accepted",false): state["failed"] = true
		state["batch"] = e.get("accepted",false) and e.get("hit_count",0) == 1 and e.get("block_count",0) == 1
		if e.get("accepted",false): state["blocks"] = e["data"]["blocks"][&"npc"]["absorbed"]
	var on_error := func(_e): state["error"] = true
	bus.subscribe(&"CombatPhaseBatchResolved",callback)
	bus.subscribe(&"WeaponStrikeAutoSubmissionFailed",on_error)
	check(driver.advance_steps(1) == 1 and state["failed"] and state["error"] and value(&"npc",&"HP") == 20 and value(&"npc",&"Stamina") == 1.5,"automatic failure rejects without damage")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":1}).get("accepted",false),"restore and use whole stamina")
	check(driver.advance_steps(1) == 1 and state["batch"] and state["blocks"] == 2 and value(&"npc",&"HP") < 20 and value(&"npc",&"Stamina") == 0,"automatic shield collection and damage")
	bus.unsubscribe(&"CombatPhaseBatchResolved",callback)
	bus.unsubscribe(&"WeaponStrikeAutoSubmissionFailed",on_error)
	print("Weapon strike automatic phase shield tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
