extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func click(game:Control,pos:Vector2,button:MouseButton=MOUSE_BUTTON_LEFT)->void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*pos;e.button_index=button;e.pressed=true;game._input(e)
func key(game:Node,k:Key)->void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func gear(game:Node)->Dictionary:return ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"})["data"]
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":100.0}).get("accepted",false),"capacity")
	for i in range(62):
		var id:=StringName("mouse_potion_%d" % i)
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"create item")
	click(game,game._inventory_button_rect().get_center())
	check(driver.advance_steps(1)==1 and game.inventory_open,"mouse opens inventory")
	check(game._inventory_items().size()>63,"multiple visual pages")
	check(game._inventory_art != null and game._equipment_base != null and game._item_icons.size()>=15,"inventory textures and icons")
	check(game._inventory_item_icon(&"demo_sword") != null and gear(game).get("main",null)==&"demo_sword","equipped icon from real item")
	click(game,game._inventory_toolbar_rect(1).get_center());check(game.inventory_page==7,"next 63-cell page")
	var first:Variant=game._inventory_items()[63]
	click(game,game._inventory_cell_rect(0).get_center(),MOUSE_BUTTON_RIGHT)
	check(game.inspect_mode and game.inspect_item==first and game.inventory_page==7,"inspect first item of second page")
	click(game,game._inventory_rect().position+Vector2(60,430));check(not game.inspect_mode,"return from inspect")
	click(game,game._inventory_toolbar_rect(0).get_center());check(game.inventory_page==0,"previous 63-cell page")
	var idx:int=game._inventory_items().find(&"demo_shield")
	check(idx>=0 and idx<63,"shield on first grid")
	click(game,game._inventory_cell_rect(idx).get_center())
	check(driver.advance_steps(10)==10 and gear(game).get("off",null)==&"demo_shield","equip from grid")
	check(game._inventory_item_icon(gear(game).get("off")) != null,"equipped item icon")
	click(game,game._inventory_equipment_rect("off").get_center(),MOUSE_BUTTON_RIGHT)
	check(game.inspect_mode and game.inspect_item==&"demo_shield","inspect equipped item")
	key(game,KEY_ESCAPE)
	click(game,game._inventory_equipment_rect("off").get_center())
	check(driver.advance_steps(10)==10 and gear(game).get("off",null)==null and game._inventory_items().has(&"demo_shield"),"unequip and restore empty icon")
	click(game,game._inventory_toolbar_rect(3).get_center());check(game.identify_mode and not game.equipment_view,"identify mode")
	click(game,game._inventory_toolbar_rect(3).get_center());check(not game.identify_mode,"identify mode closed")
	click(game,game._inventory_toolbar_rect(4).get_center());check(driver.advance_steps(1)==1 and not game.inventory_open,"close button")
	click(game,game._inventory_button_rect().get_center());check(driver.advance_steps(1)==1 and game.inventory_open,"reopen")
	# Full inventory invokes the existing world-drop selector, not silent loss.
	var used:float=ask(&"InventoryGetRequested",{"entity":game.HERO})["used_volume"]
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":used}).get("accepted",false),"full inventory")
	click(game,game._inventory_equipment_rect("main").get_center())
	check(not game._drop_pick.is_empty(),"drop selector opens")
	click(game,game._drop_cancel_rect().get_center());check(game._drop_pick.is_empty(),"cancel drop by mouse")
	click(game,game._inventory_equipment_rect("main").get_center())
	var tile:Vector2i=game._drop_pick.get("tile",Vector2i.ZERO)
	check(ask(&"LootDropTileCheckRequested",{"entity":game.HERO,"tile":tile}).get("valid",false),"drop tile valid")
	click(game,game._drop_confirm_rect().get_center())
	check(game._drop_pick.is_empty() and driver.advance_steps(10)==10 and ask(&"LootGetRequested",{})["items"].has(&"demo_sword"),"confirm mouse drop")
	game.queue_free();await process_frame
	print("Game demo mouse inventory: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
