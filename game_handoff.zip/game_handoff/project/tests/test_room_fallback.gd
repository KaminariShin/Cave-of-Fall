extends SceneTree
var failures := 0
var failed_events: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func setup_map(width: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(width,100)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"start", "type":"start", "origin_cell":Vector2i(1,7), "size_cells":Vector2i(11,11)}).get("accepted", false): return false
	return ask(&"RoomExitAddRequested", {"room":&"start", "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false)
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus = root.get_node("EventBus")
	var force_type := func(e): e["value"] = 0.0
	var force_size := func(e): e["value"] = e["max"]
	bus.subscribe(&"RngFloatRequested", force_type)
	bus.subscribe(&"RngIntRequested", force_size)
	bus.subscribe(&"RoomGenerationFailed", func(e): failed_events.append(e.duplicate(true)))
	check(setup_map(96), "setup map for smaller same-type room")
	var smaller := ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"})
	check(smaller.get("accepted", false) and smaller.get("type", "") == "passage", "fallback keeps original type when smaller size fits")
	if smaller.get("accepted", false):
		var smaller_room: Dictionary = ask(&"RoomGetRequested", {"id":smaller["child"]}).get("data", {})
		check(smaller_room.get("size_cells", Vector2i.ZERO) == Vector2i(12,12), "smallest fitting size of selected type")
	check(setup_map(80), "setup tight map")
	# Восточнее помещается только коридор длины 8, а случайный проход 14х14 нет.
	var result := ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"})
	check(result.get("accepted", false) and result.get("type", "") == "corridor", "fallback to corridor after unplaceable passage")
	if result.get("accepted", false):
		var room: Dictionary = ask(&"RoomGetRequested", {"id":result["child"]}).get("data", {})
		check(room.get("size_cells", Vector2i.ZERO) == Vector2i(8,5), "minimum fitting corridor chosen")
		check(ask(&"RoomGetRequested", {"id":&"start"})["data"]["exits"][0]["connected"], "fallback linked to parent")
	check(failed_events.is_empty(), "no failure on success")
	check(setup_map(76), "setup impossible map")
	result = ask(&"RoomChildGenerateRequested", {"room":&"start", "exit":&"east"})
	check(not result.get("accepted", false) and not str(result.get("error", "")).is_empty(), "explicit failure if no type fits")
	var exit: Dictionary = ask(&"RoomGetRequested", {"id":&"start"})["data"]["exits"][0]
	check(not exit["sealed"] and not exit["connected"], "failed exit remains retryable")
	check(failed_events.size() == 1 and failed_events[0]["room"] == &"start", "failure event")
	bus.unsubscribe(&"RngFloatRequested", force_type)
	bus.unsubscribe(&"RngIntRequested", force_size)
	print("Room fallback tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
