extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(v:bool,label:String)->void:
	if not v:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func run()->void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var bus=root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(30,30)}).get("accepted",false),"map")
	var floors:Array=[]
	for x in range(30):
		for y in range(30):floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"target"]:check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"target","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"body")
	check(ask(&"ItemCreateRequested",{"id":&"shield","base_id":&"shield_medium","item_level":1}).get("accepted",false),"shield")
	check(ask(&"ComponentSetRequested",{"entity":&"target","component":&"equipment","data":{"off":&"shield"}}).get("accepted",false),"equip")
	check(ask(&"ResourceSetRequested",{"entity":&"target","resource":&"HP","value":20}).get("accepted",false),"hp")
	check(ask(&"ResourceSetRequested",{"entity":&"target","resource":&"Stamina","value":4}).get("accepted",false),"stamina")
	check(ask(&"ShieldBlockStartRequested",{"entity":&"target","slot":"off","direction":Vector2i.UP}).get("accepted",false),"shield active")
	var seen:Dictionary={"first":false,"second":false,"block":false,"result":{}}
	var phase:=func(_e):
		if seen["first"]:return
		seen["block"]=ask(&"CombatPhaseBlockSubmitRequested",{"target":&"target","direction":Vector2i.UP,"expected_stamina":4}).get("accepted",false)
		seen["first"]=ask(&"CombatPhaseHitSubmitRequested",{"source":&"hero","hit_id":&"projectile:1","target":&"target","damage":5,"hp_before":20,"attack_tiles":[Vector2i(10,9)]}).get("accepted",false)
		seen["second"]=ask(&"CombatPhaseHitSubmitRequested",{"source":&"hero","hit_id":&"projectile:2","target":&"target","damage":7,"hp_before":20,"attack_tiles":[Vector2i(11,9)]}).get("accepted",false)
	var resolved:=func(e):seen["result"]=e.duplicate(true)
	bus.subscribe(&"TimeCombatPhase",phase);bus.subscribe(&"CombatPhaseBatchResolved",resolved)
	check(driver.wait_for(0.01) and driver.advance_steps(1)==1,"combat phase")
	check(seen["first"] and seen["second"] and seen["block"] and seen["result"].get("accepted",false),"both hits accepted together")
	check(ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"]==16 and ask(&"ResourceGetRequested",{"entity":&"target","resource":&"Stamina"})["data"]["current"]==0,"both hits share shield stamina")
	bus.unsubscribe(&"TimeCombatPhase",phase);bus.unsubscribe(&"CombatPhaseBatchResolved",resolved)
	print("Combat phase distinct impacts: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
