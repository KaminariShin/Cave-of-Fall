extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(value:bool,label:String)->void:
	if not value:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,event:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,event);return event
func resource(id:StringName)->Dictionary:
	return ask(&"ResourceGetRequested",{"entity":&"hero","resource":id})["data"]
func run()->void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	check(root.get_node("EntityRegistry").create_entity(&"hero",{&"stats":{"CON":5}}),"hero")
	check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"HP","value":10}).get("accepted",false),"wounded")
	check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"Stamina","value":20}).get("accepted",false),"stamina")
	var service=root.get_node("ResourceService")
	for i in range(49):service._regen_cycle(&"hero",&"HP")
	check(resource(&"HP")["current"]==10,"whole HP waits until accumulated")
	service._regen_cycle(&"hero",&"HP")
	check(resource(&"HP")["current"]==11,"CON 5 heals 1 HP in 25 game seconds")
	check(resource(&"Stamina")["current"]==18 and is_equal_approx(resource(&"HP")["cost_remainder"],0.5),"cost remains 2.5 stamina per HP")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load")
	check(resource(&"HP")["current"]==11 and is_equal_approx(resource(&"HP")["cost_remainder"],0.5),"regen state survives save")
	print("Low CON HP regeneration: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
