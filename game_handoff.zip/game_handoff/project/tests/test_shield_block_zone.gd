extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func zone(direction: Vector2i, attack: Array = []) -> Dictionary:
	return ask(&"ShieldBlockZoneRequested", {"entity":&"hero","direction":direction,"attack_tiles":attack})
func equip(driver, item: StringName, slot: String) -> bool:
	return ask(&"EquipmentEquipRequested", {"entity":&"hero","item":item,"slot":slot}).get("accepted",false) and driver.advance_steps(10) == 10
func unequip(driver, slot: String) -> bool:
	return ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":slot}).get("accepted",false) and driver.advance_steps(10) == 10
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(40,40)}).get("accepted",false), "map")
	var floors: Array = []
	for x in range(40):
		for y in range(40): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false), "floor")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false), "body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false), "inventory")
	for entry in [[&"small",&"shield_small"],[&"medium",&"shield_medium"],[&"large",&"shield_large"]]:
		check(ask(&"ItemCreateRequested", {"id":entry[0],"base_id":entry[1],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":entry[0]}).get("accepted",false), "shield")
	check(equip(driver,&"small","off") and not zone(Vector2i.UP).get("accepted",true), "inactive shield has no zone")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false), "start off hand")
	for row in [[Vector2i.UP,Vector2i(11,9)],[Vector2i.RIGHT,Vector2i(14,11)],[Vector2i.DOWN,Vector2i(12,14)],[Vector2i.LEFT,Vector2i(9,12)]]:
		if row[0] != Vector2i.UP:
			check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":row[0]}).get("accepted",false), "restart with off direction")
		var q := zone(row[0],[row[1],row[1],Vector2i(0,0)])
		check(q.get("accepted",false) and q["data"]["tiles"] == [row[1]] and q["data"]["intersection"] == [row[1]] and q["data"]["intersects"], "left hand rotation " + str(row[0]))
	check(not zone(Vector2i.UP).get("accepted",true), "cannot rotate active block")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false), "restart up")
	check(ask(&"ShieldBlockZoneRequested", {"entity":&"hero"}).get("data",{}).get("direction",null) == Vector2i.UP, "default direction from action")
	check(not zone(Vector2i.UP,[Vector2i(10,9)]).get("data",{}).get("intersects",true), "no intersection")
	check(not zone(Vector2i(1,1)).get("accepted",true) and not zone(Vector2i.ZERO).get("accepted",true), "invalid direction")
	check(not ask(&"ShieldBlockZoneRequested", {"entity":&"hero","direction":Vector2i.UP,"attack_tiles":[Vector2(10,9)]}).get("accepted",true), "invalid tile")
	check(driver.advance_steps(10) == 10 and ask(&"SessionSaveRequested",{}).get("accepted",false), "save during block")
	check(driver.advance_steps(40) == 40 and ask(&"SessionLoadRequested",{}).get("accepted",false) and zone(Vector2i.UP).get("accepted",false), "zone after loading block")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and unequip(driver,"off") and equip(driver,&"small","main"), "switch small shield hand")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"main","direction":Vector2i.UP}).get("accepted",false), "start main hand")
	for row in [[Vector2i.UP,Vector2i(12,9)],[Vector2i.RIGHT,Vector2i(14,12)],[Vector2i.DOWN,Vector2i(11,14)],[Vector2i.LEFT,Vector2i(9,11)]]:
		if row[0] != Vector2i.UP:
			check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"main","direction":row[0]}).get("accepted",false), "restart with main direction")
		var q := zone(row[0])
		check(q.get("accepted",false) and q["data"]["tiles"] == [row[1]], "right hand rotation " + str(row[0]))
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and unequip(driver,"main") and equip(driver,&"medium","off"), "medium")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false) and zone(Vector2i.UP)["data"]["tiles"] == [Vector2i(10,9),Vector2i(11,9)], "medium width two")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and unequip(driver,"off") and equip(driver,&"large","off"), "large")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false) and zone(Vector2i.UP)["data"]["tiles"] == [Vector2i(10,9),Vector2i(11,9),Vector2i(12,9),Vector2i(13,9)], "large width four")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false), "stop")
	check(ask(&"SpaceBodyRemoveRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(0,0),"size":2}).get("accepted",false), "smaller body")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false) and not zone(Vector2i.UP).get("accepted",true), "large shield refuses body narrower than shield")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and unequip(driver,"off") and equip(driver,&"small","off"), "small on smaller body")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false) and zone(Vector2i.UP)["data"]["tiles"] == [Vector2i(1,-1)], "edge zone is geometric and not clipped")
	print("Shield block zone tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
