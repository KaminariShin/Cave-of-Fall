extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(20,20)})["accepted"], "map")
	var floors: Array = []
	for x in range(20):
		for y in range(20): floors.append(Vector2i(x,y))
	ask(bus, &"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})
	ask(bus, &"MaterialRegisterRequested", {"material": {"id": "material", "name": "material", "weight_per_unit": 1, "volume_per_unit": 1, "level": 1}})
	ask(bus, &"ItemBaseRegisterRequested", {"base": {"id": "base", "name": "thing", "slot": "main", "tags": [], "materials": [{"material_id": "material", "count": 1}]}})
	for id in [&"loot_item", &"retained_item"]:
		check(ask(bus, &"ItemCreateRequested", {"id": id, "base_id": &"base", "item_level": 1})["accepted"], "create item")
	for id in [&"hero", &"enemy1", &"enemy2"]:
		check(entities.create_entity(id), "entity")
	for placement in [[&"hero",Vector2i(2,2)],[&"enemy1",Vector2i(8,8)],[&"enemy2",Vector2i(12,12)]]:
		check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": placement[0], "anchor": placement[1], "size": 2})["accepted"], "body")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "controlled")
	for id in [&"enemy1", &"enemy2"]: ask(bus, &"InventoryConfigureRequested", {"entity": id, "volume": 2})
	ask(bus, &"InventoryAddRequested", {"entity": &"enemy1", "item": &"loot_item"})
	ask(bus, &"InventoryAddRequested", {"entity": &"enemy2", "item": &"retained_item"})
	check(ask(bus, &"CombatDamageRequested", {"entity": &"enemy1", "source": &"hero", "amount": 999})["accepted"], "first death")
	check(ask(bus, &"LootGetRequested", {})["items"].has(&"loot_item") and ask(bus, &"SessionSaveRequested", {})["accepted"], "save contains loot")
	root.get_node("LootService").free()
	var present := {"present": false}
	bus.publish(&"LootModulePresentRequested", present)
	check(not present["present"], "module absent")
	check(not ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "reject existing ground loot save when module absent")
	check(ask(bus, &"CombatDamageRequested", {"entity": &"enemy2", "source": &"hero", "amount": 999})["accepted"], "death still works without module")
	check(ask(bus, &"InventoryGetRequested", {"entity": &"enemy2"})["data"]["items"].has(&"retained_item"), "nothing dropped without module")
	check(not ask(bus, &"SpaceBodyGetRequested", {"entity": &"enemy2"})["found"], "corpse physics independent of loot")
	check(ask(bus, &"SessionSaveRequested", {})["accepted"] and ask(bus, &"SessionLoadRequested", {})["accepted"], "save and load without loot module")
	print("Optional loot tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
