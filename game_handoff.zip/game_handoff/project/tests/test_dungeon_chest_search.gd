extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(begin(4) and add_room(1, "passage") and add_room(2, "passage"), "connected rooms")
	var service = root.get_node("SaveService")
	var before: Dictionary = service.collect_world_transition_snapshot()
	var first := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "scan_limit":40, "check_limit":1})
	check(first.get("accepted", false) and not first.get("found", true) and not first.get("complete", true) and first.get("next_cursor", -1) == 40 and first.get("scanned", -1) == 40, "bounded first page")
	var second := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "cursor":first["next_cursor"], "scan_limit":40, "check_limit":1})
	check(second.get("accepted", false) and second.get("found", false) and second.get("preflight_checked", 0) == 1, "next page finds valid candidate")
	if second.get("found", false):
		var again := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":second["tile"]})
		check(again.get("accepted", false) and again["interaction_anchor"] == second["interaction_anchor"], "found position passes standalone preflight")
		var same := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "cursor":first["next_cursor"], "scan_limit":40, "check_limit":1})
		check(same.get("tile", null) == second["tile"] and same.get("next_cursor", -1) == second["next_cursor"], "stable deterministic selection")
		var next := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "cursor":second["next_cursor"], "scan_limit":40, "check_limit":1})
		check(next.get("found", false) and next["tile"] != second["tile"] and next["next_cursor"] > second["next_cursor"], "resume skips returned candidate")
	check(not ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "cursor":-1}).get("accepted", true), "reject invalid cursor")
	check(not ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "check_limit":5}).get("accepted", true), "reject excessive checks")
	check(not ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "scan_limit":0}).get("accepted", true), "reject zero scan budget")
	check(not ask(&"DungeonChestPositionSearchRequested", {"room":&"missing"}).get("accepted", true), "reject missing room")
	var bus = root.get_node("EventBus")
	var count := {"calls":0}
	var blocked := func(e):
		count["calls"] += 1
		e["fits"] = false
	bus.subscribe(&"SpaceBodyFitsRequested", blocked)
	var cursor := 0
	var pages := 0
	var complete := false
	while not complete and pages < 3000:
		var page := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "cursor":cursor})
		check(page.get("accepted", false) and not page.get("found", true) and page.get("scanned", 999) <= 256 and page.get("preflight_checked", 999) <= 4 and page.get("next_cursor", -1) > cursor, "bounded failed page progresses")
		cursor = page.get("next_cursor", cursor)
		complete = page.get("complete", false)
		pages += 1
	bus.unsubscribe(&"SpaceBodyFitsRequested", blocked)
	check(complete and cursor == 48 * 48 and count["calls"] > 0, "exhausted candidates without false positive")
	var at_end := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "cursor":cursor})
	check(at_end.get("accepted", false) and at_end.get("complete", false) and not at_end.get("found", true) and at_end.get("scanned", -1) == 0, "empty complete tail")
	var after: Dictionary = service.collect_world_transition_snapshot()
	check(before.get("valid", false) and after.get("valid", false) and before["payload"]["sections"] == after["payload"]["sections"], "search does not mutate world or consume RNG")

	if second.get("found", false):
		check(ask(&"ObjectCreateRequested", {"entity":&"occupying_chest", "type":"chest", "room":&"node_1", "tile":second["tile"], "inventory_capacity":100}).get("accepted", false), "occupy previous result")
		check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":second["tile"]}).get("accepted", true), "candidate becomes stale after world changes")
		var rescan := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1", "cursor":first["next_cursor"], "scan_limit":40, "check_limit":1})
		check(rescan.get("found", false) and rescan["tile"] != second["tile"], "rescan skips occupied candidate")
	var reused := {"room":&"node_1", "cursor":0, "tile":Vector2i(1,1), "found":true, "complete":true}
	ask(&"DungeonChestPositionSearchRequested", reused)
	reused["room"] = &"missing"
	ask(&"DungeonChestPositionSearchRequested", reused)
	check(not reused.get("accepted", true) and not reused.has("tile") and not reused.has("found") and not reused.has("complete"), "invalid reuse clears stale result")
	print("Chest position search tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
