extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func state(id: StringName) -> Dictionary:
	return ask(&"ItemGetRequested", {"item":id})["item_data"]["learning_state"]
func wait_action(driver, steps: int = 1) -> bool:
	return ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":steps * 0.01}).get("accepted",false) and driver.advance_steps(steps) == steps
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":20}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc", "volume":20}).get("accepted",false), "inventories")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var learning = root.get_node("DungeonChestLearningService")
	for pair in [[&"armor", &"armor_cloth_body"], [&"shield", &"shield_small"], [&"sword", &"sword_simple"]]:
		check(ask(&"ItemCreateRequested", {"id":pair[0],"base_id":pair[1],"item_level":1,"learning":learning.schema_for(pair[1],bases)}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":pair[0]}).get("accepted",false), "create and own")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"armor","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and state(&"armor")["progress"] == 0, "newly equipped armor not credited for its own equip")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and state(&"armor")["progress"] == 1 and state(&"shield")["progress"] == 0, "previously worn armor learns on equip")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10 and state(&"armor")["progress"] == 2 and state(&"shield")["progress"] == 1 and state(&"sword")["progress"] == 0, "both worn pieces learn; weapon not yet supported")
	var seen := {"atomic":true,"events":0}
	var callback := func(e):
		seen["events"] += 1
		if e["item"] == &"armor": seen["atomic"] = state(&"armor")["progress"] == 3 and state(&"shield")["progress"] == 2
	bus.subscribe(&"ItemLearningProgressChanged",callback)
	check(wait_action(driver) and state(&"armor")["progress"] == 3 and state(&"shield")["progress"] == 2 and seen["atomic"] and seen["events"] == 2, "one action updates both before notifications")
	bus.unsubscribe(&"ItemLearningProgressChanged",callback)
	check(ask(&"MenuTransitionRequested", {"entity":&"hero","menu":"inventory","operation":"open"}).get("accepted",false) and driver.advance_steps(1) == 1 and state(&"armor")["progress"] == 3 and state(&"shield")["progress"] == 2, "menu excluded")
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"wait","duration":1.0}).get("accepted",false) and driver.advance_steps(50) == 50, "start long action")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save pending action")
	var f := FileAccess.open("user://session.save",FileAccess.READ)
	var saved: Dictionary = bytes_to_var(f.get_buffer(f.get_length())); f.close()
	var bad: Dictionary = saved.duplicate(true)
	bad["sections"]["item_learning_progress"][&"hero"]["items"].append(&"missing")
	f = FileAccess.open("user://session.save",FileAccess.WRITE); f.store_buffer(var_to_bytes(bad)); f.close()
	check(not ask(&"SessionLoadRequested",{}).get("accepted",true), "reject corrupt pending")
	f = FileAccess.open("user://session.save",FileAccess.WRITE); f.store_buffer(var_to_bytes(saved)); f.close()
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and state(&"armor")["progress"] == 3 and state(&"shield")["progress"] == 2, "cancel gives no progress")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and driver.advance_steps(50) == 50 and state(&"armor")["progress"] == 4 and state(&"shield")["progress"] == 3, "restored action learns once")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and state(&"shield")["progress"] == 4 and state(&"armor")["progress"] == 5, "successful unequip counts while worn")
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false) and state(&"shield")["progress"] == 4, "progress follows ownership")
	for i in range(20): check(wait_action(driver), "wait for completion %d" % i)
	check(state(&"armor")["progress"] == 25 and state(&"armor")["identified"] and state(&"shield")["progress"] == 4 and state(&"sword")["progress"] == 0, "auto identify at 25; unowned and weapon unchanged")
	check(wait_action(driver) and state(&"armor")["progress"] == 25, "no overrun")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and state(&"armor")["identified"] and state(&"shield")["progress"] == 4, "learned state persists")
	print("Item learning progress tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
