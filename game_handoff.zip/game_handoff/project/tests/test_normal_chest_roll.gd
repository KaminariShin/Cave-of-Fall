extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus=root.get_node("EventBus")
	check(begin(1) and add_room(1,"passage") and add_room(2,"passage"),"connected floor")
	var log:={"calls":0,"nested":true,"save":true}
	var mock:=func(e):
		if e.get("min",0)==1 and e.get("max",0)==4:
			log["calls"]+=1
			log["nested"]=ask(&"DungeonNormalChestRollRequested",{"room":&"node_2"}).get("accepted",true)
			log["save"]=ask(&"SessionSaveRequested",{}).get("accepted",true)
			e["value"]=1 if log["calls"]==1 else 4
	bus.subscribe(&"RngIntRequested",mock)
	var excluded:=ask(&"DungeonNormalChestRollRequested",{"room":&"root"})
	check(not excluded.get("accepted",true) and log["calls"]==0,"start room excluded without roll")
	var first:=ask(&"DungeonNormalChestRollRequested",{"room":&"node_1"})
	check(first.get("accepted",false) and first.get("selected",false) and first.get("roll",0)==1 and not first.get("existing",true),"selected on one of four outcomes")
	check(log["calls"]==1 and not log["nested"] and not log["save"],"one roll, reentrant call and save blocked")
	var second:=ask(&"DungeonNormalChestRollRequested",{"room":&"node_2"})
	check(second.get("accepted",false) and not second.get("selected",true) and second.get("roll",0)==4,"non-selected outcome")
	var duplicate:=ask(&"DungeonNormalChestRollRequested",{"room":&"node_1"})
	check(duplicate.get("accepted",false) and duplicate.get("existing",false) and duplicate.get("roll",0)==1 and log["calls"]==2,"repeat does not reroll")
	bus.unsubscribe(&"RngIntRequested",mock)
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save decisions")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load decisions")
	check(ask(&"DungeonNormalChestRollGetRequested",{"room":&"node_1"}).get("selected",false) and not ask(&"DungeonNormalChestRollGetRequested",{"room":&"node_2"}).get("selected",true),"both outcomes restored")
	var saver=root.get_node("SaveService")
	var snap: Dictionary=saver.collect_world_transition_snapshot()
	var corrupt: Dictionary=snap["payload"].duplicate(true)
	corrupt["sections"]["normal_chest_rolls"][&"node_1"]=5
	check(not saver._validate_snapshot(corrupt),"reject corrupt die result")
	corrupt=snap["payload"].duplicate(true)
	corrupt["sections"]["normal_chest_rolls"][&"root"]=1
	check(not saver._validate_snapshot(corrupt),"reject start-room entry")
	corrupt=snap["payload"].duplicate(true)
	corrupt["sections"]["normal_chest_rolls"][&"missing"]=1
	check(not saver._validate_snapshot(corrupt),"reject unknown-room entry")
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(100,100)}).get("accepted",false),"reset map")
	check(not ask(&"DungeonNormalChestRollGetRequested",{"room":&"node_1"}).get("found",true),"old floor decisions cleared")
	print("Normal chest roll tests: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
