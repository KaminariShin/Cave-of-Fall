extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func reverse(d: String) -> String:
	return {"east":"west","west":"east","north":"south","south":"north"}[d]
func run() -> void:
	bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var path := "user://demo_session.save"
	var existed := FileAccess.file_exists(path)
	var old := PackedByteArray()
	if existed:
		var f := FileAccess.open(path,FileAccess.READ); old=f.get_buffer(f.get_length()); f.close()
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"initialized")
	# Тестовый перевод на четвёртый этаж и вручную соединённый маршрут:
	# это не проверка естественного четырёхэтажного прохождения.
	var tracker = root.get_node("DungeonMilestoneService")
	var state: Dictionary = tracker.get("_floor")
	state["floor"]=4
	var stats = root.get_node("RunStatisticsService")
	stats.get("_data")["floor"]=4
	var positions := [Vector2i(23,12),Vector2i(23,0),Vector2i(35,0),Vector2i(47,0),Vector2i(47,12),Vector2i(35,12),Vector2i(35,24),Vector2i(47,24),Vector2i(47,36),Vector2i(35,36),Vector2i(23,36),Vector2i(11,36),Vector2i(11,48),Vector2i(23,48),Vector2i(35,48),Vector2i(47,48)]
	var dirs := ["east","north","east","east","south","west","south","east","south","west","west","west","south","east","east","east"]
	var parent: StringName = game.ROOM
	for i in range(positions.size()):
		var id := StringName("boss_test_%02d" % i)
		var out := &"east" if i == 0 else StringName("boss_test_out_%02d" % i)
		check(ask(&"RoomCreateRequested",{"id":id,"type":"passage","origin_cell":positions[i],"size_cells":Vector2i(12,12)}).get("accepted",false),"room %d" % i)
		if i > 0: check(ask(&"RoomExitAddRequested",{"room":parent,"id":out,"dir":dirs[i],"offset_cells":5}).get("accepted",false),"parent exit %d" % i)
		check(ask(&"RoomExitAddRequested",{"room":id,"id":&"entry","dir":reverse(dirs[i]),"offset_cells":5}).get("accepted",false),"entry %d" % i)
		check(ask(&"RoomExitConnectRequested",{"room":parent,"exit":out,"other_room":id,"other_exit":&"entry"}).get("accepted",false),"connect %d" % i)
		if i == 15:
			var floor_tiles: Array = []
			for y in range(positions[i].y*4+1,positions[i].y*4+47):
				for x in range(positions[i].x*4+1,positions[i].x*4+47): floor_tiles.append(Vector2i(x,y))
			check(ask(&"SpaceTilesSetRequested",{"tiles":floor_tiles,"kind":1}).get("accepted",false),"clear test boss room")
		ask(&"RoomChildGenerated",{"room":parent,"child":id,"type":"passage"})
		parent=id
	var tracking := ask(&"DungeonFloorTrackingGetRequested",{})
	check(tracking.get("data",{}).get("boss_candidate",null)==parent,"boss candidate selected")
	if tracking.get("data",{}).get("boss_candidate",null)!=parent: quit(1); return
	check(ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null}).get("accepted",false),"remove bounds")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":positions[15]*4+Vector2i(15,15)}).get("accepted",false),"teleport test actor")
	var deny := func(e):
		if e.get("size",0)==6: e["fits"]=false
	bus.subscribe(&"SpaceBodyFitsRequested",deny)
	check(ask(&"RoomEnterRequested",{"entity":game.HERO,"room":parent}).get("accepted",false),"enter boss room")
	check(not ask(&"DungeonBossGetRequested",{}).get("found",true),"blocked boss did not spawn")
	check(game.current_room==parent and game.message.contains("Босс не появился") and game.message.contains("R"),"failure survives room entry")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save failed boss encounter")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load failed boss encounter")
	await process_frame
	await process_frame
	await process_frame
	check(game._spawn_errors.has(parent) and not ask(&"DungeonBossGetRequested",{}).get("found",true),"failure preserved while blocker persists")
	bus.unsubscribe(&"SpaceBodyFitsRequested",deny)
	game._retry_spawns()
	check(ask(&"DungeonBossGetRequested",{}).get("found",false) and game.message.contains("Босс появился"),"R creates boss")
	await process_frame
	await process_frame
	await process_frame
	var boss := ask(&"DungeonBossGetRequested",{})
	var id: StringName = boss.get("data",{}).get("entity",&"")
	check(id!=&"" and boss["data"].get("loadout",null) is Dictionary,"boss equipped")
	check(ask(&"AIGetRequested",{"entity":id}).get("data",{}).get("role","")=="melee","boss common melee AI")
	check(not game._spawn_errors.has(parent),"failure cleared")
	# Отдельно имитируем статусы отказа, чтобы проверить маршрутизацию R;
	# реальный откат оснащения и ИИ покрывают сервисные тесты.
	ask(&"DungeonBossEquipmentAutoFailed",{"entity":id,"error":"test equipment"})
	check(game.message.contains("test equipment"),"equipment error displayed")
	var mock_equip_status := func(e): e["status"]="failed"; e["entity"]=id
	var mock_equip_retry := func(e): e["accepted"]=true
	bus.subscribe(&"DungeonBossEquipmentAutoStatusRequested",mock_equip_status)
	bus.subscribe(&"DungeonBossEquipmentAutoRetryRequested",mock_equip_retry)
	game._retry_spawns()
	check(game.message=="Босс оснащён.","equipment retry routed")
	bus.unsubscribe(&"DungeonBossEquipmentAutoStatusRequested",mock_equip_status)
	bus.unsubscribe(&"DungeonBossEquipmentAutoRetryRequested",mock_equip_retry)
	ask(&"DungeonBossMeleeAIFailed",{"entity":id,"error":"test AI"})
	check(game.message.contains("test AI"),"AI error displayed")
	var mock_ai_status := func(e): e["status"]="failed"; e["entity"]=id
	var mock_ai_retry := func(e): e["accepted"]=true
	bus.subscribe(&"DungeonBossMeleeAIStatusRequested",mock_ai_status)
	bus.subscribe(&"DungeonBossMeleeAIRetryRequested",mock_ai_retry)
	game._retry_spawns()
	check(game.message=="ИИ босса подготовлен.","AI retry routed")
	bus.unsubscribe(&"DungeonBossMeleeAIStatusRequested",mock_ai_status)
	bus.unsubscribe(&"DungeonBossMeleeAIRetryRequested",mock_ai_retry)
	game.queue_free()
	await process_frame
	if existed:
		var f := FileAccess.open(path,FileAccess.WRITE); f.store_buffer(old); f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo boss retry: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
