extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func progress()->int:
	return ask(&"ItemGetRequested",{"item":&"bow"})["item_data"]["learning_state"]["progress"]
func run()->void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,20)}).get("accepted",false),"map")
	var floor_tiles:Array=[]
	for x in range(40):
		for y in range(20):floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(2,5),"size":2}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":100}).get("accepted",false),"inventory")
	var snapshot:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()
	var schema:Dictionary=root.get_node("DungeonChestLearningService").schema_for(&"bow_simple",snapshot["payload"]["sections"]["items"]["bases"])
	check(ask(&"ItemCreateRequested",{"id":&"bow","base_id":&"bow_simple","item_level":1,"learning":schema}).get("accepted",false),"bow")
	check(ask(&"InventoryAddRequested",{"entity":&"hero","item":&"bow"}).get("accepted",false),"own")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"bow","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"equip")
	var shot:=ask(&"BowShotStartRequested",{"entity":&"hero","item":&"bow","direction":Vector2.RIGHT})
	check(shot.get("accepted",false),"shot")
	if not shot.get("accepted",false):quit(1);return
	var steps:int=shot["data"]["duration_steps"]
	check(driver.advance_steps(steps-1)==steps-1 and progress()==0,"not learned before completion")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save before finish")
	check(driver.advance_steps(1)==1 and progress()==1,"finished shot learns once")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and progress()==0 and driver.advance_steps(1)==1 and progress()==1,"restored completion learns once")
	check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"Stamina","value":10}).get("accepted",false),"restore stamina")
	shot=ask(&"BowShotStartRequested",{"entity":&"hero","item":&"bow","direction":Vector2.RIGHT})
	check(shot.get("accepted",false) and ask(&"ActionCancelRequested",{"entity":&"hero","reason":&"test"}).get("accepted",false) and progress()==1,"interrupted shot does not learn")
	print("Bow learning progress: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
