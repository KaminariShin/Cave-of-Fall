extends SceneTree
var failures := 0
var cycles: Array = []
var depleted: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func get_resource(bus, resource: StringName) -> Dictionary:
	var req := {"entity": &"hero", "resource": resource}
	bus.publish(&"ResourceGetRequested", req)
	return req.get("data", {})
func set_resource(bus, resource: StringName, value: float) -> void:
	bus.publish(&"ResourceSetRequested", {"entity": &"hero", "resource": resource, "value": value})
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"RegenCycleDue", func(event): cycles.append(event["resource"]))
	bus.subscribe(&"ResourceDepleted", func(event): depleted.append(event["resource"]))
	check(entities.create_entity(&"hero"), "create entity")
	check(get_resource(bus, &"HP")["max"] == 45.0 and get_resource(bus, &"HP")["current"] == 45.0, "initial HP")
	check(get_resource(bus, &"Stamina")["max"] == 55.0 and get_resource(bus, &"MP")["max"] == 25.0, "initial Stamina and MP")
	# Обратный порядок создания таймеров; обработка всё равно MP, Stamina, HP.
	set_resource(bus, &"HP", 0)
	set_resource(bus, &"Stamina", 10)
	set_resource(bus, &"MP", 10)
	check(depleted == [&"HP"], "depleted emitted on transition to zero")
	check(driver.advance_steps(10) == 0 and get_resource(bus, &"HP")["timer"] == 0.0, "timers freeze idle")
	check(driver.wait_for(0.5), "wait")
	driver.advance_steps(25)
	check(is_equal_approx(get_resource(bus, &"HP")["timer"], 0.25), "timer progress")
	driver.advance_steps(25)
	check(cycles == [&"MP", &"Stamina", &"HP"], "cycle order")
	check(get_resource(bus, &"HP")["current"] == 0.0, "no invented regeneration")
	var set_stat := {"entity": &"hero", "stat": &"CON", "value": 10}
	bus.publish(&"StatBaseSetRequested", set_stat)
	check(get_resource(bus, &"HP")["max"] == 70.0 and get_resource(bus, &"HP")["current"] == 0.0, "larger maximum preserves current")
	set_resource(bus, &"HP", 70.0)
	bus.publish(&"StatBaseSetRequested", {"entity": &"hero", "stat": &"CON", "value": 5})
	check(get_resource(bus, &"HP")["max"] == 45.0 and get_resource(bus, &"HP")["current"] == 45.0, "smaller maximum clamps current")
	check(get_resource(bus, &"HP")["timer"] == 0.0 and get_resource(bus, &"HP")["remainder"] == 0.0, "full resource stops and clears")
	check(not entities.set_component(&"hero", &"resources", {}), "direct resource writes blocked")
	print("Resources tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
