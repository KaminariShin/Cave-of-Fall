extends SceneTree
var failures := 0
var telegraphs: Array = []
var ended: Array = []
var resolved: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func hp(bus, id: StringName) -> float:
	return float(ask(bus, &"ResourceGetRequested", {"entity": id, "resource": &"HP"})["data"]["current"])
func seed_for(bus, small: bool) -> int:
	for seed in range(100):
		ask(bus, &"RngSeedRequested", {"seed": seed})
		if (float(ask(bus, &"RngFloatRequested", {})["value"]) < 0.8) == small:
			return seed
	return -1
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"RatBiteTelegraphStarted", func(e): telegraphs.append(e.duplicate(true)))
	bus.subscribe(&"RatBiteTelegraphEnded", func(e): ended.append(e.duplicate(true)))
	bus.subscribe(&"RatBiteResolved", func(e): resolved.append(e.duplicate(true)))
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(60, 40)})["accepted"], "map")
	var floors: Array = []
	for x in range(60):
		for y in range(40): floors.append(Vector2i(x, y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})["accepted"], "floors")
	# Проверяем каждый бросок по той же RNG-последовательности и сохранённым тегам.
	ask(bus, &"RngSeedRequested", {"seed": 12345})
	var expected: Array = []
	var expected_poison: Array = []
	for i in range(32):
		expected.append(float(ask(bus, &"RngFloatRequested", {})["value"]) < 0.8)
		expected_poison.append(float(ask(bus, &"RngFloatRequested", {})["value"]) < 0.1)
	ask(bus, &"RngSeedRequested", {"seed": 12345})
	for i in range(32):
		var id := StringName("spawn_%d" % i)
		var at := Vector2i(2 + (i % 8) * 6, 2 + int(i / 8) * 6)
		var spawn := ask(bus, &"RatSpawnRequested", {"entity": id, "anchor": at})
		check(spawn["accepted"] and spawn["small"] == expected[i], "spawn RNG " + str(i))
		if spawn["accepted"]:
			if i == 0:
				var hp_resource: Dictionary = ask(bus, &"ResourceGetRequested", {"entity":id, "resource":&"HP"})
				check(hp_resource.get("found", false) and hp_resource["data"]["current"] == 20.0 and hp_resource["data"]["max"] == 20.0, "rat spawns with exactly 20 HP")
			var species: Dictionary = entities.get_component(id, &"species")
			var body: Dictionary = ask(bus, &"SpaceBodyGetRequested", {"entity": id})["data"]
			check(body["size"] == (2 if expected[i] else 4) and species["tags"].has("small") == expected[i] and species["tags"].has("poisonous") == expected_poison[i], "size/tag " + str(i))
	for i in range(32): check(entities.remove_entity(StringName("spawn_%d" % i)), "remove spawn")
	var small_seed := seed_for(bus, true)
	var large_seed := seed_for(bus, false)
	check(small_seed >= 0 and large_seed >= 0, "find deterministic seeds")
	var rocks: Array = []
	for x in range(43, 54):
		for y in range(28, 36):
			if y not in [31, 32]: rocks.append(Vector2i(x, y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": rocks, "kind": 0})["accepted"], "narrow passage")
	check(ask(bus, &"SpaceBodyFitsRequested", {"anchor": Vector2i(45, 31), "size": 2})["fits"] and not ask(bus, &"SpaceBodyFitsRequested", {"anchor": Vector2i(45, 31), "size": 4})["fits"], "2x2 fits passage where 4x4 does not")
	ask(bus, &"RngSeedRequested", {"seed": large_seed})
	check(not ask(bus, &"RatSpawnRequested", {"entity": &"too_large", "anchor": Vector2i(45, 31)})["accepted"] and not entities.has_entity(&"too_large"), "large rat not rerolled or left partially created")
	ask(bus, &"RngSeedRequested", {"seed": small_seed})
	check(ask(bus, &"RatSpawnRequested", {"entity": &"tunnel_rat", "anchor": Vector2i(45, 31)})["accepted"], "small rat in passage")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"tunnel_rat", "anchor": Vector2i(46, 31)})["accepted"], "small rat moves along passage")
	check(entities.remove_entity(&"tunnel_rat"), "remove tunnel rat")
	check(entities.create_entity(&"hero"), "hero")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(7, 4), "size": 4})["accepted"], "place hero")
	ask(bus, &"RngSeedRequested", {"seed": small_seed})
	var small := ask(bus, &"RatSpawnRequested", {"entity": &"rat", "anchor": Vector2i(5, 5)})
	check(small["accepted"] and small["small"] and small["body_size"] == 2, "small rat")
	var zone := ask(bus, &"RatBiteZoneRequested", {"entity": &"rat", "target": &"hero"})
	check(zone["accepted"] and zone["hit"] and zone["direction"] == Vector2i.RIGHT, "east bite")
	check(zone["tiles"] == [Vector2i(7,5), Vector2i(8,5), Vector2i(7,6), Vector2i(8,6)], "exact 2x2 telegraph at body edge")
	check(zone["hit_tiles"].size() == 4, "whole body intersection")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(4, 0)})["accepted"], "hero north")
	var north := ask(bus, &"RatBiteZoneRequested", {"entity": &"rat", "target": &"hero"})
	check(north["direction"] == Vector2i.UP and north["hit"], "north zone")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(1, 4)})["accepted"], "hero west")
	var west := ask(bus, &"RatBiteZoneRequested", {"entity": &"rat", "target": &"hero"})
	check(west["direction"] == Vector2i.LEFT and west["hit"], "west zone")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(4, 7)})["accepted"], "hero south")
	var south := ask(bus, &"RatBiteZoneRequested", {"entity": &"rat", "target": &"hero"})
	check(south["direction"] == Vector2i.DOWN and south["hit"], "south zone")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(7, 7)})["accepted"], "hero diagonal")
	var tie := ask(bus, &"RatBiteZoneRequested", {"entity": &"rat", "target": &"hero"})
	check(tie["direction"] == Vector2i.RIGHT and not tie["hit"], "tie chooses horizontal axis")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(7, 4)})["accepted"], "return hero")
	check(not ask(bus, &"RatBiteStartRequested", {"entity": &"rat", "target": &"hero"})["accepted"], "no invented bite damage/duration")
	check(not ask(bus, &"RatBiteStartRequested", {"entity": &"rat", "target": &"hero", "damage": 4, "duration": 0.015})["accepted"], "duration must be whole ticks")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "control hero")
	check(ask(bus, &"PipelineModifierRegisterRequested", {"entity": &"rat", "modifier": {"id": "damage_bonus", "target": "damage.outgoing", "stage": "additive", "op": "add", "value": 1}})["accepted"], "bite pipeline modifier")
	var bite := ask(bus, &"RatBiteStartRequested", {"entity": &"rat", "target": &"hero", "damage": 4, "duration": 0.05})
	check(bite["accepted"] and telegraphs.size() == 1 and telegraphs[0]["tiles"] == bite["tiles"], "telegraph before resolution")
	check(ask(bus, &"ActionStartRequested", {"entity": &"hero", "action": &"wait", "duration": 0.1})["accepted"], "player wait")
	driver.advance_steps(2)
	check(hp(bus, &"hero") == 45.0 and resolved.is_empty(), "no damage before bite completes")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save active telegraph")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(14, 4)})["accepted"], "evade telegraph")
	driver.advance_steps(3)
	check(resolved.size() == 1 and not resolved[0]["hit"] and hp(bus, &"hero") == 45.0, "miss when target leaves")
	check(not ask(bus, &"PeriodicEffectGetRequested", {"entity":&"hero", "effect":&"poison"}).get("found", false), "miss does not poison")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "restore active telegraph")
	check(ask(bus, &"RatBiteTelegraphGetRequested", {"entity": &"rat"})["found"] and telegraphs.back().get("restored", false), "telegraph restored")
	# Принудительно задаём тег и управляем игровой последовательностью RNG.
	var species: Dictionary = entities.get_component(&"rat", &"species")
	if not species["tags"].has("poisonous"): species["tags"].append("poisonous")
	check(ask(bus, &"ComponentSetRequested", {"entity":&"rat", "component":&"species", "data":species}).get("accepted", false), "set poisonous tag")
	var poison_seed := -1
	for candidate in range(100):
		ask(bus, &"RngSeedRequested", {"seed":candidate})
		if float(ask(bus, &"RngFloatRequested", {})["value"]) < 0.3:
			poison_seed = candidate
			break
	check(poison_seed >= 0, "find poison seed")
	ask(bus, &"RngSeedRequested", {"seed":poison_seed})
	driver.advance_steps(3)
	var poison := ask(bus, &"PeriodicEffectGetRequested", {"entity":&"hero", "effect":&"poison"})
	check(poison.get("found", false) and poison["data"]["source"] == &"rat" and is_equal_approx(float(poison["data"]["damage_per_tick"]), 1.0), "poisonous bite applies poison")
	check(resolved.size() == 2 and resolved[1]["hit"] and resolved[1]["applied"] == 5.0 and hp(bus, &"hero") == 40.0, "bite damage pipeline after restore")
	driver.advance_steps(5)
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save poison after bite")
	check(ask(bus, &"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":0.5}).get("accepted", false), "wait for poison tick")
	driver.advance_steps(45)
	check(hp(bus, &"hero") == 39.0, "poison ticks after half second")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "restore poison after bite")
	check(hp(bus, &"hero") == 40.0 and ask(bus, &"PeriodicEffectGetRequested", {"entity":&"hero", "effect":&"poison"}).get("found", false), "poison and health restored")
	check(ask(bus, &"RatBiteStartRequested", {"entity": &"rat", "target": &"hero", "damage": 4, "duration": 0.05})["accepted"], "bite before attacker moves")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"rat", "anchor": Vector2i(5, 6)})["accepted"], "force rat movement")
	check(not ask(bus, &"RatBiteTelegraphGetRequested", {"entity": &"rat"})["found"] and ended.back()["reason"] == &"attacker_moved", "movement cancels bite")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"rat", "anchor": Vector2i(5, 5)})["accepted"], "restore rat position")
	var cancel := ask(bus, &"RatBiteStartRequested", {"entity": &"rat", "target": &"hero", "damage": 4, "duration": 0.05})
	check(cancel["accepted"], "second bite")
	check(ask(bus, &"CombatDamageRequested", {"entity": &"rat", "source": &"hero", "amount": 100})["accepted"], "kill rat")
	check(not ask(bus, &"RatBiteTelegraphGetRequested", {"entity": &"rat"})["found"] and ended.back()["reason"] == &"entity_died", "death cancels telegraph")
	check(entities.remove_entity(&"rat") and entities.remove_entity(&"hero"), "clear bodies")
	check(entities.create_entity(&"hero2"), "hero 2")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero2", "anchor": Vector2i(10, 4), "size": 4})["accepted"], "place hero2")
	ask(bus, &"RngSeedRequested", {"seed": large_seed})
	var large := ask(bus, &"RatSpawnRequested", {"entity": &"big_rat", "anchor": Vector2i(5, 5)})
	check(large["accepted"] and not large["small"] and large["body_size"] == 4, "normal rat size")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(9,6), Vector2i(9,7)], "kind": 0})["accepted"], "wall before target")
	var blocked := ask(bus, &"RatBiteZoneRequested", {"entity": &"big_rat", "target": &"hero2"})
	check(blocked["tiles"] == [Vector2i(9,6), Vector2i(10,6), Vector2i(9,7), Vector2i(10,7)] and not blocked["hit"], "large centered bite cannot pass wall")
	check(not ask(bus, &"RatBiteStartRequested", {"entity": &"big_rat", "target": &"hero2", "damage": 4, "duration": 0.05})["accepted"], "blocked bite rejected")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(9,7)], "kind": 1})["accepted"], "open LOS")
	var partly := ask(bus, &"RatBiteZoneRequested", {"entity": &"big_rat", "target": &"hero2"})
	check(partly["hit"] and partly["hit_tiles"].has(Vector2i(10,7)) and not partly["hit_tiles"].has(Vector2i(10,6)), "partial body and LOS")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero2"})["accepted"], "control second hero")
	var new_bite := ask(bus, &"RatBiteStartRequested", {"entity": &"big_rat", "target": &"hero2", "damage": 4, "duration": 0.05})
	check(new_bite["accepted"], "large rat telegraphs")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(9,7)], "kind": 0})["accepted"], "block LOS after telegraph")
	check(ask(bus, &"ActionStartRequested", {"entity": &"hero2", "action": &"wait", "duration": 0.05})["accepted"], "wait for blocked strike")
	driver.advance_steps(5)
	check(not resolved.back()["hit"] and hp(bus, &"hero2") == 45.0, "LOS is rechecked when strike resolves")
	print("Rat tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
