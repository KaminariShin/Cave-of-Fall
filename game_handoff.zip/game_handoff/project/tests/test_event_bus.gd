extends SceneTree
var failures := 0
var seen: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(ok: bool, message: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", message)
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var first := func(event): seen.append(event["value"])
	check(bus.subscribe(&"Example", first), "subscribe")
	check(not bus.subscribe(&"Example", first), "no duplicate subscriptions")
	bus.publish(&"Example", {"value": 7})
	check(seen == [7], "receives event")
	check(bus.unsubscribe(&"Example", first), "unsubscribe")
	bus.publish(&"Example", {"value": 9})
	check(seen == [7], "unsubscribed")
	bus.publish(&"NobodyListening", {})
	var control := {"entity": &"hero", "accepted": false}
	bus.publish(&"ControlledEntityRequested", control)
	check(control["accepted"], "control request")
	var finished: Array = []
	bus.subscribe(&"ActionCompleted", func(event): finished.append(event["action"]))
	var request := {"entity": &"hero", "action": &"wait", "duration": 0.02, "accepted": false}
	bus.publish(&"ActionStartRequested", request)
	check(request["accepted"], "event starts action")
	driver.advance_steps(2)
	check(finished == [&"wait"], "completion published")
	print("Event Bus tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
