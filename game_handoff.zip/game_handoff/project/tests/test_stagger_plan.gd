extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func plan(maxima: Dictionary,hits: Array) -> Dictionary: return ask(&"StaggerPlanRequested", {"max_hp_by_target":maxima,"hits":hits})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var hits := [{"source":&"a","target":&"victim","damage":4},{"source":&"b","target":&"victim","damage":4}]
	var q := plan({&"victim":20},hits)
	check(q.get("accepted",false) and not q["data"]["targets"][0]["triggered"] and q["data"]["duration"] == 0.2,"separate subthreshold hits do not add")
	hits[1]["damage"] = 5
	q = plan({&"victim":20},hits)
	check(q.get("accepted",false) and q["data"]["targets"][0]["sources"] == [&"b"],"equal 25 percent triggers")
	q = plan({&"victim":21},hits)
	check(q.get("accepted",false) and not q["data"]["targets"][0]["triggered"],"fractional threshold compared exactly")
	check(not plan({&"victim":20},[hits[0],hits[0]]).get("accepted",true),"duplicate source rejected")
	check(not plan({&"victim":0},hits).get("accepted",true) and not plan({&"victim":20},[{"source":&"a","target":&"victim","damage":-1}]).get("accepted",true),"invalid data rejected")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,30)}).get("accepted",false),"map")
	var floors := []
	for x in range(30):
		for y in range(30): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"a",&"b",&"c"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_medium","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	for row in [[&"HP",20],[&"Stamina",2]]: check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":row[0],"value":row[1]}).get("accepted",false),"resource")
	check(ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false),"start shield")
	var prepared := []
	for row in [[&"a",2,2],[&"b",2,2],[&"c",0,5]]: prepared.append({"source":row[0],"target":&"hero","damage":row[1],"magical_damage":row[2],"attack_tiles":[Vector2i(10,9)]})
	var result := ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":20},"hits":prepared,"block":{"target":&"hero","direction":Vector2i.UP,"expected_stamina":2}})
	check(result.get("accepted",false),"mixed batch")
	if result.get("accepted",false):
		var final: Array = result["data"]["resolved_hits"]
		check(final.size() == 3 and final[0]["physical"] == 0 and final[0]["magical"] == 2 and final[1]["damage"] == 2 and final[2]["damage"] == 5,"per-source damage after block")
		q = plan({&"hero":20},final)
		check(q.get("accepted",false) and q["data"]["targets"][0]["sources"] == [&"c"],"plan uses per-source post-block mixed damage")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"HP","value":1}).get("accepted",false),"set low HP")
	result = ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":1},"hits":[{"source":&"a","target":&"hero","damage":8}]})
	check(result.get("accepted",false) and result["data"]["targets"][0]["hp_lost"] == 1 and result["data"]["resolved_hits"][0]["damage"] == 8,"per-hit damage not limited by remaining HP")
	print("Stagger plan tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
