extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func gear()->Dictionary:return ask(&"ComponentGetRequested",{"entity":&"demo_hero","component":&"equipment"})["data"]
func inventory()->Array:return ask(&"InventoryGetRequested",{"entity":&"demo_hero"})["data"]["items"]
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save";var exists:=FileAccess.file_exists(path);var old:=PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":50}).get("accepted",false),"capacity")
	check(ask(&"ItemCreateRequested",{"id":&"target_hammer","base_id":&"hammer_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"target_hammer"}).get("accepted",false),"hammer")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open inventory")
	check(game._use_inventory_item(inventory().find(&"demo_shield")) and driver.advance_steps(10)==10 and gear().get("off",null)==&"demo_shield","equip shield")
	var idx:=inventory().find(&"target_hammer")
	var volume:float=ask(&"InventoryGetRequested",{"entity":game.HERO})["used_volume"]
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":volume}).get("accepted",false),"full inventory")
	var t:float=driver.game_time
	check(game._use_inventory_item(idx) and game._twohand_queue.get("stage","")=="choose" and not game._drop_pick.is_empty() and gear().get("off",null)==&"demo_shield" and gear().get("main",null)==&"demo_sword" and driver.game_time==t,"full inventory requests drop tile")
	var escape:=InputEventKey.new();escape.pressed=true;escape.keycode=KEY_ESCAPE;game._unhandled_key_input(escape)
	check(game._twohand_queue.is_empty() and game._drop_pick.is_empty() and gear().get("off",null)==&"demo_shield","cancel drop selection safely")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":50}).get("accepted",false),"restore capacity")
	var sequence:Array=[]
	var on_remove:=func(e):
		if e.get("entity",null)==game.HERO:sequence.append(e.get("item",null))
	bus.subscribe(&"ItemUnequipped",on_remove)
	t=driver.game_time
	check(game._use_inventory_item(idx) and game._twohand_queue.get("item",null)==&"demo_shield","shield removed first")
	check(driver.advance_steps(5)==5 and gear().get("off",null)==&"demo_shield","mid first action")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save in first action")
	var saved_file:=FileAccess.open(path,FileAccess.READ)
	var bytes:=saved_file.get_buffer(saved_file.get_length());saved_file.close()
	var saved:Dictionary=bytes_to_var(bytes)
	for corruption in range(4):
		var bad:Dictionary=saved.duplicate(true)
		var q:Dictionary=bad["sections"]["game_demo"]["twohand_queue"]
		match corruption:
			0:q["target"]=&"missing_hammer"
			1:q["stage"]="nonsense"
			2:q["item"]=&"demo_sword"
			3:q["slot"]="head"
		var output:=FileAccess.open(path,FileAccess.WRITE);output.store_buffer(var_to_bytes(bad));output.close()
		check(not ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",true),"reject corrupted queue %d" % corruption)
	var output:=FileAccess.open(path,FileAccess.WRITE);output.store_buffer(bytes);output.close()
	check(driver.advance_steps(5)==5 and gear().get("off",null)==null and game._twohand_queue.get("stage","")=="ready","first removal completed")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and gear().get("off",null)==&"demo_shield" and game._twohand_queue.get("stage","")=="running","restore pending removal")
	sequence.clear()
	check(driver.advance_steps(5)==5 and gear().get("off",null)==null and inventory().count(&"demo_shield")==1,"restored removal completes once")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save between actions")
	check(game._twohand_continue() and game._twohand_queue.get("item",null)==&"demo_sword","sword second")
	check(driver.advance_steps(10)==10 and gear().get("main",null)==null and inventory().count(&"demo_sword")==1,"sword removed")
	check(game._twohand_continue() and game._twohand_queue.get("item",null)==&"target_hammer","hammer third")
	check(driver.advance_steps(5)==5 and ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save during final equip")
	check(driver.advance_steps(5)==5 and gear().get("main",null)==&"target_hammer" and game._twohand_queue.is_empty(),"hammer equipped")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and game._twohand_queue.get("stage","")=="running" and driver.advance_steps(5)==5 and gear().get("main",null)==&"target_hammer" and game._twohand_queue.is_empty(),"resume equip once")
	check(sequence==[&"demo_shield",&"demo_sword"],"ordered transfer " + str(sequence))
	check(absf(driver.game_time-t-0.3)<0.00001,"three steps cost 0.3 seconds")
	bus.unsubscribe(&"ItemUnequipped",on_remove)
	# Cancellation during the first removal leaves both items equipped.
	check(ask(&"EquipmentUnequipRequested",{"entity":game.HERO,"slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"remove hammer")
	check(ask(&"EquipmentEquipRequested",{"entity":game.HERO,"item":&"demo_sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"replace sword")
	check(ask(&"EquipmentEquipRequested",{"entity":game.HERO,"item":&"demo_shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10)==10,"replace shield")
	idx=inventory().find(&"target_hammer")
	check(game._use_inventory_item(idx) and driver.advance_steps(5)==5 and ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel first removal")
	check(game._twohand_queue.is_empty() and game.message.contains("прервана") and gear().get("main",null)==&"demo_sword" and gear().get("off",null)==&"demo_shield","cancel clears sequence")
	# The idle frame actually resumes the saved ready state, without a manual call.
	check(game._use_inventory_item(inventory().find(&"target_hammer")) and driver.advance_steps(10)==10,"restart")
	check(game._twohand_queue.get("stage","")=="ready","between actions")
	await process_frame;await process_frame
	check(game._twohand_queue.get("item",null)==&"demo_sword" and game._twohand_queue.get("stage","")=="running","auto continuation on frame")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel auto continuation")
	check(ask(&"EquipmentUnequipRequested",{"entity":game.HERO,"slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"empty main")
	check(ask(&"EquipmentEquipRequested",{"entity":game.HERO,"item":&"demo_shield","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"shield in main")
	check(ask(&"EquipmentEquipRequested",{"entity":game.HERO,"item":&"demo_sword","slot":"off"}).get("accepted",false) and driver.advance_steps(10)==10,"sword in off")
	check(game._use_inventory_item(inventory().find(&"target_hammer")) and game._twohand_queue.get("slot","")=="main" and game._twohand_queue.get("item",null)==&"demo_shield","shield first when in main")
	check(driver.advance_steps(10)==10 and game._twohand_continue() and game._twohand_queue.get("slot","")=="off" and driver.advance_steps(10)==10 and game._twohand_continue() and driver.advance_steps(10)==10 and gear().get("main",null)==&"target_hammer","opposite hands sequence completed")
	game.queue_free();await process_frame
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo two-handed sequence: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
