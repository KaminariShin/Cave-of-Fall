extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(begin(4) and add_room(1, "passage") and add_room(2, "passage"), "connected rooms")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_1"})["data"]
	var origin: Vector2i = room["origin_cell"] * 4
	var tile := origin + Vector2i(5,1)
	check(ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile}).get("accepted", false), "valid initial chest position")
	check(ask(&"ObjectCreateRequested", {"entity":&"guard_chest", "type":"chest", "room":&"node_1", "tile":tile, "inventory_capacity":10}).get("accepted", false), "place chest")
	check(ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile, "existing_object":&"guard_chest"}).get("accepted", false), "recheck existing chest")
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile, "existing_object":&"forged"}).get("accepted", true), "existing object identity checked")
	var save_service = root.get_node("SaveService")
	var before: Dictionary = save_service.collect_world_transition_snapshot()
	var unsafe := ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"unsafe_north", "dir":"north", "offset_cells":1})
	var after: Dictionary = save_service.collect_world_transition_snapshot()
	check(not unsafe.get("accepted", true), "exit whose 4x4 approach overlaps chest rejected")
	check(before.get("valid", false) and after.get("valid", false) and before["payload"]["sections"] == after["payload"]["sections"], "unsafe exit rejected before world or RNG mutation")
	var safe := ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"safe_north", "dir":"north", "offset_cells":5})
	check(safe.get("accepted", false), "safe new exit permitted")
	var test := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile, "existing_object":&"guard_chest"})
	check(test.get("accepted", false) and test.get("open_exits_checked", 0) == 3, "actual chest stays reachable from all marked exits")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save and reload new exit")
	check(not ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"unsafe_after_load", "dir":"north", "offset_cells":1}).get("accepted", true), "guard survives load")
	check(ask(&"ObjectGetRequested", {"object":&"guard_chest"}).get("found", false), "chest remains")
	print("Chest exit guard tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
