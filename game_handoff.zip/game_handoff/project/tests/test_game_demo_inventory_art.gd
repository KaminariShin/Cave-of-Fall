extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok: failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func click(g:Control,p:Vector2,b:MouseButton=MOUSE_BUTTON_LEFT)->void:
	var e:=InputEventMouseButton.new();e.position=g.get_global_transform_with_canvas()*p;e.button_index=b;e.pressed=true;g._input(e)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(game._inventory_art.get_size()==Vector2(676,444) and game._equipment_base.get_size()==Vector2(312,444) and game.EQUIPMENT_ART_RECTS.size()==12,"art assets and twelve slots")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":100}).get("accepted",false),"capacity")
	for spec in [[&"art_hammer",&"hammer_simple"],[&"art_armour",&"armor_leather_body"]]:
		check(ask(&"ItemCreateRequested",{"id":spec[0],"base_id":spec[1],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":spec[0]}).get("accepted",false),"create item")
	check(game._inventory_item_icon(&"demo_sword")==game._item_icons["sword_simple"] and game._inventory_item_icon(&"art_hammer")==game._item_icons["hammer_simple"] and game._inventory_item_icon(&"art_armour")==game._item_icons["armor_leather_body"],"icons map actual item bases")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open")
	var body_index:int=game._inventory_items().find(&"art_armour")
	click(game,game._inventory_cell_rect(body_index).get_center())
	check(driver.advance_steps(10)==10 and ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"})["data"].get("body")==&"art_armour","equip armor")
	var hammer_index:int=game._inventory_items().find(&"art_hammer")
	click(game,game._inventory_cell_rect(hammer_index).get_center())
	check(driver.advance_steps(10)==10 and game._twohand_continue() and driver.advance_steps(10)==10,"two handed swap")
	var gear:Dictionary=ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"})["data"]
	check(gear.get("main")==&"art_hammer" and gear.get("off")==null,"two handed equipment")
	check(game._inventory_item_icon(gear["main"])==game._item_icons["hammer_simple"],"icon reflects hammer")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false) and ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"save load")
	gear=ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"})["data"]
	check(gear.get("main")==&"art_hammer" and game._inventory_item_icon(gear["main"])==game._item_icons["hammer_simple"],"restored icon")
	click(game,game._inventory_equipment_rect("main").get_center(),MOUSE_BUTTON_RIGHT)
	check(game.inspect_item==&"art_hammer" and game._inspection_lines(game.inspect_item).size()>3,"inspect equipped hammer")
	game.queue_free();await process_frame
	print("Inventory equipment art: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
