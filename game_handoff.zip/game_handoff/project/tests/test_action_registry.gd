extends SceneTree
var failures := 0
var events: Array[String] = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func run_tests() -> void:
	var t = root.get_node("TimeDriver")
	var a = root.get_node("ActionRegistry")
	t.set_process(false)
	a.action_finished.connect(func(entity, id): events.append(str(entity) + ":" + str(id)))
	check(a.set_controlled_entity(&"player"), "controlled entity")
	check(a.start_action(&"enemy", &"attack"), "enemy action")
	check(t.advance_steps(2) == 0, "enemy does not advance time")
	check(is_zero_approx(a.get_active_action(&"enemy")["elapsed"]), "enemy freezes idle")
	check(a.start_action(&"player", &"attack"), "player starts driver")
	t.advance_steps(40)
	check(is_equal_approx(a.get_active_action(&"enemy")["elapsed"], 0.4), "enemy advances with world")
	check(a.interrupt_with(&"player", &"stagger"), "player interruption")
	t.advance_steps(20)
	check(not t.is_action_active and a.get_active_action(&"player").is_empty(), "player finished")
	check(is_equal_approx(t.game_time, 0.6), "turn includes segments")
	check(a.interrupt_with(&"enemy", &"stagger"), "enemy interruption while idle")
	check(a.start_action(&"player", &"wait", 0.2), "wait")
	t.advance_steps(20)
	check(events.has("enemy:stagger") and events.has("player:wait"), "both completed")
	check(a.register_definition({"id": &"locked", "name": "Locked", "type": &"physical", "base_duration": 0.1, "interruptible": false}), "register definition")
	check(a.start_action(&"enemy", &"locked"), "start uninterruptible")
	check(not a.interrupt_with(&"enemy", &"stagger"), "respects interruptibility")
	check(a.interrupt_with(&"enemy", &"stagger", -1.0, true), "forced interrupt")
	a.entity_removed(&"enemy")
	check(a.get_active_action(&"enemy").is_empty(), "entity removal cleans action")
	print("Action Registry tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
