extends SceneTree

var failures := 0
var events: Array[String] = []

func _initialize() -> void:
	call_deferred("run_tests")

func check(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		printerr("FAIL: ", message)

func run_tests() -> void:
	var driver = root.get_node("TimeDriver")
	var registry = root.get_node("ProcessRegistry")
	driver.set_process(false)
	check(not registry.register_process(&"invalid", 0.015), "invalid duration rejected")
	check(registry.register_process(&"arrow", 0.03, &"archer", true, Callable(), func(id): events.append("finish:" + str(id))), "register arrow")
	check(not registry.register_process(&"arrow", 0.03), "duplicate id rejected")
	check(registry.register_process(&"buff", 0.03, &"archer", false, Callable(), Callable(), func(id, reason): events.append(str(id) + ":" + str(reason))), "register buff")
	check(is_zero_approx(registry.get_process_info(&"arrow")["elapsed"]), "idle has not progressed")
	registry.entity_removed(&"archer")
	check(registry.has_process(&"arrow") and not registry.has_process(&"buff"), "independent arrow survives entity removal")
	check(events.has("buff:entity_removed"), "interrupt callback on entity removal")
	check(driver.wait_for(0.03), "start time")
	driver.advance_steps(3)
	check(not registry.has_process(&"arrow") and events.has("finish:arrow"), "arrow completes")
	check(registry.register_process(&"projectile", 0.02, &"", true, func(id, _dt): registry.interrupt_process(id, &"wall"), func(_id): events.append("unexpected completion"), func(_id, reason): events.append(str(reason))), "projectile registers")
	check(driver.wait_for(0.02), "start next action")
	driver.advance_steps(2)
	check(events.has("wall") and not events.has("unexpected completion"), "collision interrupts")
	# Новый процесс с тем же идентификатором не получает текущий шаг.
	var replacement_tick := func(_id, _dt): events.append("replacement tick")
	var replace := func(id, _dt):
		registry.interrupt_process(id)
		registry.register_process(id, 0.01, &"", false, replacement_tick)
	check(registry.register_process(&"same", 0.01, &"", false, replace), "register replaceable")
	check(driver.wait_for(0.02), "start replacement action")
	driver.advance_steps(1)
	check(not events.has("replacement tick"), "replacement waits until next tick")
	driver.advance_steps(1)
	check(events.has("replacement tick"), "replacement ticks next step")
	print("Process Registry tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
