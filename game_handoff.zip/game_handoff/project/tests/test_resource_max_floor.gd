extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func resource(actor: StringName,id: StringName) -> Dictionary:
	return ask(&"ResourceGetRequested", {"entity":actor,"resource":id}).get("data",{})
func set_stat(actor: StringName,id: StringName,value: float) -> bool:
	return ask(&"StatBaseSetRequested", {"entity":actor,"stat":id,"value":value}).get("accepted",false)
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"entities")
	check(set_stat(&"hero",&"CON",5.25) and set_stat(&"hero",&"STR",5.125) and set_stat(&"hero",&"DEX",5.125) and set_stat(&"hero",&"WIS",5.375),"fractional stats")
	check(resource(&"hero",&"HP")["max"] == 46 and resource(&"hero",&"Stamina")["max"] == 57 and resource(&"hero",&"MP")["max"] == 26,"floor after summing all contributions")
	check(resource(&"hero",&"HP")["current"] == 46 and resource(&"hero",&"Stamina")["current"] == 55 and resource(&"hero",&"MP")["current"] == 25,"HP retains full percentage; other resources unchanged")
	for row in [[&"HP",46],[&"Stamina",57],[&"MP",26]]: check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":row[0],"value":row[1]}).get("accepted",false),"fill")
	check(set_stat(&"hero",&"CON",5.0) and resource(&"hero",&"HP")["max"] == 45 and resource(&"hero",&"HP")["current"] == 45 and resource(&"hero",&"Stamina")["max"] == 55 and resource(&"hero",&"Stamina")["current"] == 55 and resource(&"hero",&"MP")["current"] == 26,"smaller floored max clamps current")
	check(set_stat(&"npc",&"CON",5.25) and resource(&"npc",&"Stamina")["max"] == 56 and ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":100}).get("accepted",false),"NPC fractional base")
	var saver = root.get_node("SaveService")
	var snapshot: Dictionary = saver.collect_world_transition_snapshot()
	var bases: Dictionary = snapshot["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	var mod := {"id":&"affix_stamina","category":"affix","stat":"max_stamina","tier":3,"value":4.0,"level_req":1,"material_id":&"iron_common","unlock_after":5}
	check(ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_small","item_level":1,"rarity":&"magic","learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"shield","mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and driver.wait_for(0.1) and driver.advance_steps(10) == 10,"equip NPC resource bonus")
	check(resource(&"npc",&"Stamina")["max"] == 60 and resource(&"npc",&"Stamina")["current"] == 55,"gear bonus before final flooring")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save")
	snapshot = saver.collect_world_transition_snapshot()
	check(snapshot.get("valid",false),"valid snapshot")
	if snapshot.get("valid",false):
		for key in [&"HP",&"Stamina",&"MP"]:
			var broken: Dictionary = snapshot["payload"].duplicate(true)
			broken["sections"]["entities"][&"hero"][&"resources"][key]["max"] = 45.5
			check(not saver._validate_snapshot(broken),"fractional saved maximum rejected " + str(key))
	check(set_stat(&"hero",&"WIS",10.25) and ask(&"SessionLoadRequested",{}).get("accepted",false) and resource(&"hero",&"MP")["max"] == 26 and resource(&"npc",&"Stamina")["max"] == 60,"restore maxima and equipment")
	check(set_stat(&"hero",&"CON",-20) and set_stat(&"hero",&"STR",-20) and set_stat(&"hero",&"DEX",-20) and resource(&"hero",&"HP")["max"] == 0 and resource(&"hero",&"Stamina")["max"] == 0,"negative total clamps to zero")
	print("Resource maximum floor tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
