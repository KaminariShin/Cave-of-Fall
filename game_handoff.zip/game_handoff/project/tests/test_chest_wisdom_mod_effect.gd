extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func wisdom(actor: StringName) -> float:
	var q := ask(&"StatGetRequested", {"entity":actor, "stat":&"WIS"})
	return float(q.get("value",NAN)) if q.get("found",false) else NAN
func mp(actor: StringName) -> Dictionary:
	return ask(&"ResourceGetRequested", {"entity":actor, "resource":&"MP"}).get("data",{})
func state(id: StringName) -> Dictionary:
	return ask(&"ItemGetRequested", {"item":id})["item_data"]["learning_state"]
func wait(driver, actor: StringName, steps: int = 1) -> bool:
	return ask(&"ActionStartRequested", {"entity":actor, "action":&"wait", "duration":steps * 0.01}).get("accepted",false) and driver.advance_steps(steps) == steps
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc", "volume":10}).get("accepted",false), "control and inventory")
	for actor in [&"hero",&"npc"]:
		check(ask(&"StatBaseSetRequested", {"entity":actor, "stat":&"WIS", "value":10}).get("accepted",false), "WIS set")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"INT", "value":10}).get("accepted",false), "INT set")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"armor_cloth_body",bases)
	var mod := {"id":&"suf_wisdom", "category":"suffix", "stat":"WIS", "tier":3, "value":1.0, "level_req":1, "material_id":&"cloth_light", "unlock_after":5}
	check(ask(&"ItemCreateRequested", {"id":&"armor", "base_id":&"armor_cloth_body", "item_level":1, "rarity":&"magic", "learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"armor", "mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"armor"}).get("accepted",false), "armor with wisdom")
	check(ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"MP", "value":50}).get("accepted",false), "fill mana")
	var changes: Array = []
	var observer := func(e):
		if e.get("entity") == &"hero" and e.get("stat") == &"WIS": changes.append([e["old"],e["new"]])
	bus.subscribe(&"StatChanged",observer)
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"armor", "slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and wisdom(&"hero") == 10.0 and mp(&"hero")["max"] == 50.0 and state(&"armor")["progress"] == 0, "high INT does not reveal")
	for i in range(5): check(wait(driver,&"hero"), "wait %d" % i)
	check(state(&"armor")["progress"] == 5 and wisdom(&"hero") == 11.0 and mp(&"hero")["max"] == 55.0 and mp(&"hero")["current"] == 50.0 and changes.has([10.0,11.0]), "reveal increases WIS and MP max without free fill")
	check(ask(&"PipelineModifierRegisterRequested", {"entity":&"hero", "modifier":{"id":"double_wis", "target":"stat.WIS", "stage":"multiplicative", "op":"multiply", "value":2.0}}).get("accepted",false) and wisdom(&"hero") == 22.0 and mp(&"hero")["max"] == 110.0, "additive bonus before multiplicative stage")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and wisdom(&"hero") == 22.0 and mp(&"hero")["max"] == 110.0, "save/load")
	var failed := {"count":0}
	var broken := func(e):
		if e.get("item",null) == &"armor" and e.get("found",false): e["item_data"]["mods"][0]["value"] = 999
	var failure_observer := func(e):
		if e.get("entity",null) == &"hero" and e.get("resource",null) == &"MP": failed["count"] += 1
	var old_mp := mp(&"hero").duplicate(true)
	bus.subscribe(&"ItemGetRequested",broken)
	bus.subscribe(&"ResourceMaxCalculationFailed",failure_observer)
	check(not ask(&"StatGetRequested", {"entity":&"hero", "stat":&"WIS"}).get("found",true) and ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"INT", "value":11}).get("accepted",false) and failed["count"] == 1 and mp(&"hero") == old_mp, "invalid WIS leaves resource batch intact and reports failure")
	bus.unsubscribe(&"ItemGetRequested",broken)
	bus.unsubscribe(&"ResourceMaxCalculationFailed",failure_observer)
	check(ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"INT", "value":10}).get("accepted",false) and mp(&"hero")["max"] == 110.0, "later valid stat change recalculates resources")
	check(ask(&"ResourceSetRequested", {"entity":&"hero", "resource":&"MP", "value":110}).get("accepted",false) and ask(&"EquipmentUnequipRequested", {"entity":&"hero", "slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and wisdom(&"hero") == 20.0 and mp(&"hero")["max"] == 100.0 and mp(&"hero")["current"] == 100.0, "unequip clamps current MP")
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero", "item":&"armor"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc", "item":&"armor"}).get("accepted",false), "transfer")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc", "item":&"armor", "slot":"body"}).get("accepted",false) and wait(driver,&"hero",10) and wisdom(&"npc") == 11.0 and mp(&"npc")["max"] == 55.0, "NPC bonus")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"npc", "slot":"body"}).get("accepted",false) and wait(driver,&"hero",10), "NPC unequip")
	check(ask(&"ItemCreateRequested", {"id":&"fresh", "base_id":&"armor_cloth_body", "item_level":1, "rarity":&"magic", "learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"fresh", "mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc", "item":&"fresh"}).get("accepted",false), "fresh armor")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc", "item":&"fresh", "slot":"body"}).get("accepted",false) and wait(driver,&"hero",10) and state(&"fresh")["progress"] == 0 and not state(&"fresh")["identified"] and wisdom(&"npc") == 11.0 and mp(&"npc")["max"] == 55.0, "NPC gets unrevealed bonus")
	check(ask(&"ControlledEntityRequested", {"entity":&"npc"}).get("accepted",false) and wisdom(&"npc") == 10.0 and mp(&"npc")["max"] == 50.0 and not state(&"fresh")["identified"], "control switch loses bonus and updates max")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and wisdom(&"npc") == 11.0 and mp(&"npc")["max"] == 55.0, "NPC bonus restored")
	var staff_schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"staff_simple",bases)
	check(ask(&"ItemCreateRequested", {"id":&"staff", "base_id":&"staff_simple", "item_level":1, "rarity":&"magic", "learning":staff_schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"staff", "mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"staff"}).get("accepted",false), "staff wisdom")
	var staff_data: Dictionary = ask(&"ItemGetRequested", {"item":&"staff"})["item_data"]
	check(root.get_node("DungeonChestModCatalogService").unsupported_live_effects(staff_data).is_empty(), "wisdom effect recognized")
	check(ask(&"ItemLearningIdentifyRequested", {"entity":&"hero", "item":&"staff"}).get("accepted",false) and driver.advance_steps(100) == 100 and state(&"staff")["progress"] == 0 and state(&"staff")["identified"], "staff identify before reveal")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"staff", "slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10 and wisdom(&"hero") == 22.0 and mp(&"hero")["max"] == 110.0, "identified staff applies wisdom and mana")
	check(ask(&"ItemCreateRequested", {"id":&"blank", "base_id":&"armor_cloth_body", "item_level":1, "rarity":&"magic", "learning":schema}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"blank"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"blank", "slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10, "blank equipped")
	check(not ask(&"ItemModAttachRequested", {"item":&"blank", "mod":mod}).get("accepted",true), "cannot attach wisdom on equipped item")
	bus.unsubscribe(&"StatChanged",observer)
	print("Chest wisdom mod effect tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
