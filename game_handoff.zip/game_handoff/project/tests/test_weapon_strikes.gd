extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(bus, id: StringName, data: Dictionary) -> Dictionary:
	bus.publish(id, data)
	return data
func run() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"SpaceMapConfigureRequested", {"size":Vector2i(30,20)})["accepted"], "map")
	var floors: Array = []
	for x in range(30):
		for y in range(20): floors.append(Vector2i(x,y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles":floors, "kind":1})["accepted"], "floor")
	check(root.get_node("EntityRegistry").create_entity(&"hero"), "hero")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(5,5), "size":2})["accepted"], "body")
	for v in ["short", "long"]:
		check(ask(bus, &"WeaponVariantRegisterRequested", {"definition":{"id":v, "type":"sword", "tags":[]}})["accepted"], "variant")
	var hit := {"id":"slash", "name":"Slash", "variants":["short"], "speed_effectiveness":0.8, "damage":7, "range":6, "zone":{"type":"arc", "angle_degrees":90, "radius":10}}
	check(ask(bus, &"WeaponStrikeRegisterRequested", {"definition":hit})["accepted"], "strike")
	var bad := hit.duplicate(true)
	bad["id"] = "bad"
	bad["zone"] = {"type":"line", "length":0, "width":1}
	check(not ask(bus, &"WeaponStrikeRegisterRequested", {"definition":bad})["accepted"], "invalid shape")
	var list := ask(bus, &"WeaponStrikesGetRequested", {"variant":"short"})
	check(list["found"] and list["strikes"].size() == 1, "list")
	check(ask(bus, &"WeaponStrikesGetRequested", {"variant":"long"})["strikes"].is_empty(), "different variant")
	var preview := {"entity":&"hero", "variant":"short", "strike":"slash", "kind":"physical", "direction":Vector2.RIGHT}
	var r := ask(bus, &"WeaponStrikePreviewRequested", preview.duplicate())
	check(r["accepted"] and r["strike_data"]["damage"] == 7 and is_equal_approx(r["timing"]["duration"],1.25) and r["zone"]["tiles"].has(Vector2i(9,5)), "preview timing and area")
	preview["variant"] = "long"
	check(not ask(bus, &"WeaponStrikePreviewRequested", preview.duplicate())["accepted"], "unavailable")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load")
	check(ask(bus, &"WeaponStrikesGetRequested", {"variant":"short"})["strikes"].size() == 1, "restored")
	print("Weapon strike tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
