extends SceneTree
var failures := 0
var bus: Node
var impacts: Array = []
func _initialize() -> void: call_deferred("run")
func check(v:bool,label:String)->void:
	if not v: failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	bus.publish(id,e);return e
func hp(id:StringName)->float:
	return float(ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"})["data"]["current"])
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,20)}).get("accepted",false),"map")
	var floors:Array=[]
	for x in range(40):
		for y in range(20):floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"archer",&"target"]:
		check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"create " + str(id))
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"archer","anchor":Vector2i(2,5),"size":2}).get("accepted",false),"archer")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"target","anchor":Vector2i(12,5),"size":2}).get("accepted",false),"target")
	var provider:=func(e):
		if e.get("entity",null)==&"target" and e.get("damage_type","")=="physical":e["percent"]=50.0
	var expired:=func(e):impacts.append(e.duplicate(true))
	bus.subscribe(&"PeriodicProtectionGetRequested",provider)
	bus.subscribe(&"ProjectileExpired",expired)
	var initial:=hp(&"target")
	var arrow:=ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":7.0})
	check(arrow.get("accepted",false),"arrow launch")
	check(driver.wait_for(1.0),"time")
	check(driver.advance_steps(15)==15 and ask(&"SessionSaveRequested",{}).get("accepted",false),"save while flying")
	check(driver.advance_steps(50)>0,"advance impact")
	check(hp(&"target")==initial-4.0 and impacts.size()==1 and impacts[0].get("target",null)==&"target","physical protection and upward rounding: 7 -> 4")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore arrow")
	check(driver.advance_steps(50)>0 and hp(&"target")==initial-4.0 and impacts.size()==2,"restored flight applies same damage once")
	bus.unsubscribe(&"PeriodicProtectionGetRequested",provider);bus.unsubscribe(&"ProjectileExpired",expired)
	print("Bow projectile physical mitigation: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
