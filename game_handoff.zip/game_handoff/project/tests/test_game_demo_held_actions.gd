extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func press(game: Node, key: Key, echo := false) -> void:
	var e := InputEventKey.new(); e.keycode = key; e.pressed = true; e.echo = echo; game._unhandled_key_input(e)
func release(game: Node, key: Key) -> void:
	var e := InputEventKey.new(); e.keycode = key; e.pressed = false; game._input(e)
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	var game = load("res://game_demo.tscn").instantiate(); root.add_child(game); await process_frame
	game.set_process(false)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	var start: Vector2i = ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
	press(game,KEY_D)
	check(driver.is_action_active,"first movement starts immediately")
	driver.advance_steps(100); game._repeat_held_input(); check(driver.is_action_active,"movement repeats without key echo")
	driver.advance_steps(100); game._repeat_held_input(); release(game,KEY_D); driver.advance_steps(100); game._repeat_held_input()
	var end: Vector2i = ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
	check(end.x >= start.x+2 and not driver.is_action_active,"release stops after current step")
	press(game,KEY_Q); check(driver.is_action_active and driver.current_action_id==&"wait","wait starts")
	driver.advance_steps(50); game._repeat_held_input(); check(driver.is_action_active and driver.current_action_id==&"wait","wait repeats")
	release(game,KEY_Q); driver.advance_steps(50); game._repeat_held_input(); check(not driver.is_action_active,"wait release stops after interval")
	press(game,KEY_D); driver.advance_steps(100); game._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT); game._repeat_held_input(); check(not driver.is_action_active,"focus loss clears hold")
	press(game,KEY_Q); driver.advance_steps(50); press(game,KEY_ESCAPE); game._repeat_held_input(); check(not driver.is_action_active,"escape cancels repeat")
	press(game,KEY_SPACE); check(game._direction_action=="attack","choose attack")
	press(game,KEY_D); check(game._held_keys.is_empty(),"direction choice does not initiate hold")
	driver.advance_steps(200); game._repeat_held_input(); check(not driver.is_action_active,"direction choice does not cause later walking")
	press(game,KEY_Q); driver.advance_steps(50); press(game,KEY_I)
	check(game._held_keys.is_empty(),"inventory clears hold")
	driver.advance_steps(5); check(game.inventory_open,"inventory opens"); game._repeat_held_input(); check(not driver.is_action_active,"no repeat in inventory")
	press(game,KEY_I); driver.advance_steps(5)
	press(game,KEY_Q); check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save during held wait")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and game._held_keys.is_empty(),"load clears transient hold")
	driver.advance_steps(100); game._repeat_held_input(); check(not driver.is_action_active,"loaded wait does not repeat")
	press(game,KEY_D); press(game,KEY_W); check(game._held_keys.back()==KEY_W,"most recently pressed direction takes priority")
	release(game,KEY_W); check(game._held_keys.back()==KEY_D,"release restores previous direction")
	release(game,KEY_D); driver.advance_steps(100)
	game.queue_free(); await process_frame
	print("Game demo held actions: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
