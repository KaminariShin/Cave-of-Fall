extends SceneTree
var failures := 0
var activated: Array = []
var evaluated: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	var hook = root.get_node("WorldTickHook")
	driver.set_process(false)
	# Тестовые значения не являются игровым балансом; в ruleset таблица пуста.
	hook._definitions = [
		{"id": "quake", "room_types": ["cave"], "chance_per_step": 1.0, "duration": 0.03, "cascade": {"fall": 1.0}},
		{"id": "fall", "room_types": ["cave"], "chance_per_step": 0.0, "duration": 0.02},
		{"id": "forest_only", "room_types": ["forest"], "chance_per_step": 1.0, "duration": 0.01}
	]
	bus.subscribe(&"WorldEventActivated", func(e): activated.append(e.duplicate()))
	bus.subscribe(&"WorldEventChanceEvaluating", func(e): evaluated.append(e.duplicate()))
	bus.publish(&"PlayerRoomChanged", {"room": &"r1", "room_type": &"cave"})
	check(driver.advance_steps(1) == 0 and activated.is_empty(), "idle performs no check")
	check(driver.wait_for(0.01), "wait starts")
	driver.advance_steps(1)
	check(activated.size() == 2, "quake and boosted fall start")
	check(activated[0]["room"] == &"r1" and activated[1]["event"] == &"fall", "correct room and cascade")
	check(evaluated.size() == 2, "other room type not checked")
	check(root.get_node("ProcessRegistry").has_process(activated[0]["process"]), "event is process")
	var save := {}
	bus.publish(&"SessionSaveRequested", save)
	check(save.get("accepted", false), "running world processes can be saved: " + str(save))
	bus.publish(&"PlayerRoomChanged", {"room": &"r2", "room_type": &"forest"})
	check(driver.wait_for(0.01), "another wait starts")
	driver.advance_steps(1)
	check(activated.size() == 3 and activated[2]["room"] == &"r2", "only current room starts events")
	var load := {}
	bus.publish(&"SessionLoadRequested", load)
	check(load.get("accepted", false), "restore active world events")
	check(hook._room_id == &"r1" and hook._active.size() == 2, "room and active set restored")
	print("World Tick Hook tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
