extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func preview(progress: int, identified: bool = false, npc: bool = false) -> Dictionary:
	return ask(&"DungeonChestLearningPreviewRequested", {"object":&"chest", "slot_index":0, "progress":progress, "identified":identified, "npc":npc})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11), "inventory_capacity":20}).get("accepted",false), "chest")
	var count := {"n":0}
	var rng := func(e):
		count["n"] += 1
		e["value"] = 700 if count["n"] in [5,9,13,17] else e["min"]
	bus.subscribe(&"RngIntRequested",rng)
	var result := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	bus.unsubscribe(&"RngIntRequested",rng)
	check(result.get("accepted",false), "plan")
	if not result.get("accepted",false): quit(1); return
	var slot: Dictionary = result["draft"]["slots"][0]
	check(slot["learning"]["progress_kind"] == "weapon_strikes" and slot["learning"]["full_progress"] == 25 and slot["mods"].size() == 4, "weapon learning schema")
	for i in range(4): check(slot["mods"][i]["unlock_after"] == [5,10,15,20][i], "mod unlock step")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	for v in [[0,0.5,0],[4,0.5,0],[5,0.4,1],[10,0.3,2],[15,0.2,3],[20,0.1,4],[25,0.0,4]]:
		var q := preview(v[0])
		check(q.get("accepted",false) and is_equal_approx(q["base_penalty"],v[1]) and q["active_mods"].size() == v[2] and q["globally_identified"] == (v[0] == 25), "preview boundary %d" % v[0])
	var npc := preview(0,false,true)
	check(npc["base_penalty"] == 0.0 and npc["active_mods"].size() == 4 and not npc["globally_identified"], "npc bypass does not identify globally")
	var known := preview(0,true,false)
	check(known["base_penalty"] == 0.0 and known["active_mods"].size() == 4 and known["globally_identified"], "identified bypass")
	check(not preview(26).get("accepted",true) and not ask(&"DungeonChestLearningPreviewRequested", {"object":&"chest", "slot_index":0, "progress":0, "identified":false}).get("accepted",true), "invalid preview")
	check(before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "preview is pure")
	check(ask(&"EntityCreateRequested", {"entity":&"holder"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"holder", "volume":10}).get("accepted",false), "holder")
	var schema: Dictionary = slot["learning"].duplicate(true)
	check(ask(&"ItemCreateRequested", {"id":&"normal_item", "base_id":&"sword_simple", "item_level":1, "learning":schema}).get("accepted",false), "create item with learning schema")
	check(ask(&"InventoryAddRequested", {"entity":&"holder", "item":&"normal_item"}).get("accepted",false), "own item")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save")
	var f := FileAccess.open("user://session.save",FileAccess.READ)
	var saved: Dictionary = bytes_to_var(f.get_buffer(f.get_length())); f.close()
	for corruption in [0,1,2]:
		var bad: Dictionary = saved.duplicate(true)
		match corruption:
			0: bad["sections"]["objects"]["objects"][&"chest"]["content_draft"]["slots"][0]["mods"][0]["unlock_after"] = 1
			1: bad["sections"]["objects"]["objects"][&"chest"]["content_draft"]["slots"][0]["learning"]["full_progress"] = 10
			2: bad["sections"]["items"]["instances"][&"normal_item"]["learning"]["progress_kind"] = "owner_actions"
		f = FileAccess.open("user://session.save",FileAccess.WRITE); f.store_buffer(var_to_bytes(bad)); f.close()
		check(not ask(&"SessionLoadRequested",{}).get("accepted",true), "corrupted learning rejected %d" % corruption)
	f = FileAccess.open("user://session.save",FileAccess.WRITE); f.store_buffer(var_to_bytes(saved)); f.close()
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ItemGetRequested", {"item":&"normal_item"})["item_data"]["learning"] == schema and preview(5)["active_mods"].size() == 1, "schema persists")
	var service = root.get_node("DungeonChestLearningService")
	var bad_schema: Dictionary = schema.duplicate(true); bad_schema["penalty_steps"][2]["penalty"] = 0.9
	check(not service._valid_config(bad_schema), "invalid increasing penalty rejected")
	check(service.schema_for(&"shield_small", saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"])["progress_kind"] == "owner_actions", "shield progress type")
	print("Chest learning draft tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
