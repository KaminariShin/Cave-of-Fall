extends SceneTree
var bus: Node
var driver: Node
var game: Node
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures+=1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func body() -> Vector2i: return ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
func room_data(id: StringName) -> Dictionary: return ask(&"RoomGetRequested",{"id":id})["data"]
func anchor(ex: Dictionary) -> Vector2i:
	var p:=Vector2i(int(ex["x"]),int(ex["y"]))
	match ex["dirOut"]:
		"west":p.x+=1
		"east":p.x-=4
		"north":p.y+=1
		"south":p.y-=4
	return p
func steps_to(goal: Vector2i,area: Dictionary) -> Array:
	var start:=body()
	var queue:Array=[start]
	var prev:Dictionary={start:null}
	var i:=0
	while i<queue.size():
		var p:Vector2i=queue[i];i+=1
		if p==goal:
			var route:Array=[]
			while p!=start:
				var old:Vector2i=prev[p]
				route.push_front(p-old);p=old
			return route
		for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var n:Vector2i=p+d
			if not prev.has(n) and ask(&"SpaceBodyFitsRequested",{"anchor":n,"size":4,"room":area,"ignore_entity":game.HERO}).get("fits",false):
				prev[n]=p;queue.append(n)
	return []
func follow(route: Array) -> bool:
	for d in route:
		var expected: Vector2i=body()+d
		if not game._move(d): print("movement refused ",body()," delta ",d," ",game.message);return false
		driver.advance_steps(300)
		if body()!=expected: print("movement diverged ",body()," expected ",expected," message ",game.message);return false
	return true
func enter_next(room_id: StringName) -> bool:
	var info:Dictionary=room_data(room_id)
	var out:Dictionary={}
	for ex in info["exits"]:
		if not ex["connected"] and not ex["sealed"]:out=ex;break
	if out.is_empty(): print("no unexplored exit");return false
	var goal:=anchor(out)
	var area:Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
	var path:=steps_to(goal,area)
	if path.is_empty() and body()!=goal: print("no walking path ",room_id," ",body()," to ",goal); return false
	if not follow(path): return false
	# Первый шаг на проход запускает ленивую генерацию.
	var delta: Vector2i={"north":Vector2i.UP,"east":Vector2i.RIGHT,"south":Vector2i.DOWN,"west":Vector2i.LEFT}[out["dirOut"]]
	if not follow([delta]): return false
	info=room_data(room_id)
	for ex in info["exits"]:
		if ex["id"]==out["id"]: out=ex;break
	if not out["connected"]: print("exit was not generated ",out);return false
	var child: StringName=out["childId"]
	for i in range(8):
		if game.current_room==child: return true
		if not follow([delta]): return false
	return game.current_room==child
func run() -> void:
	bus=root.get_node("EventBus")
	driver=root.get_node("TimeDriver");driver.set_process(false)
	var path:="user://demo_session.save"
	var existed:=FileAccess.file_exists(path)
	var old:=PackedByteArray()
	if existed:
		var file:=FileAccess.open(path,FileAccess.READ);old=file.get_buffer(file.get_length());file.close()
	game=load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"demo initialized")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet tutorial enemy")
	var forced:={"used":false}
	var select:=func(e):
		if not forced["used"] and e.get("min",0)==1 and e.get("max",0)==4:
			forced["used"]=true;e["value"]=1
	bus.subscribe(&"RngIntRequested",select)
	check(enter_next(game.ROOM),"walk to automatically generated room")
	bus.unsubscribe(&"RngIntRequested",select)
	var room: StringName=game.current_room
	await process_frame
	await process_frame
	var roll:=ask(&"DungeonNormalChestRollGetRequested",{"room":room})
	var state:=ask(&"DungeonNormalChestGenerationGetRequested",{"room":room})
	var auto_state:=ask(&"DungeonNormalChestAutoStatusRequested",{})
	print("roll ",roll," state ",state," auto ",auto_state)
	check(forced["used"] and roll.get("selected",false),"one selected roll")
	check(state.get("found",false) and state["data"].get("status","")=="created","automatic chest created")
	check(auto_state.get("jobs",{}).is_empty(),"no pending failure")
	if state.get("found",false) and state["data"].get("status","")=="created":
		var id: StringName=state["data"]["object"]
		var items: Array=ask(&"InventoryGetRequested",{"entity":id})["data"]["items"].duplicate()
		check(items.size()>=2 and items.size()<=5,"automatic fixed contents")
		check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false) and ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"save load chest")
		await process_frame
		check(ask(&"InventoryGetRequested",{"entity":id})["data"]["items"]==items,"same fixed contents after load")
		check(ask(&"DungeonNormalChestGenerationGetRequested",{"room":room})["data"]["object"]==id,"no reroll after load")
		# Геометрия и взаимодействие изолируются от боя, но тело не телепортируется.
		var spawn:=ask(&"RoomSpawnStatusRequested",{"room":room})
		for enemy in spawn.get("data",{}).get("placed",[]):ask(&"AIUnregisterRequested",{"entity":enemy})
		var info: Dictionary=room_data(room)
		var bounds: Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
		var tile: Vector2i=state["data"]["tile"]
		var walk: Array=[]
		var found:=false
		for y in range(tile.y-4,tile.y+2):
			for x in range(tile.x-4,tile.x+2):
				var p:=Vector2i(x,y)
				var adj:=((tile.x==p.x-1 or tile.x==p.x+4) and tile.y>=p.y and tile.y<p.y+4) or ((tile.y==p.y-1 or tile.y==p.y+4) and tile.x>=p.x and tile.x<p.x+4)
				if adj:
					var candidate:=steps_to(p,bounds)
					if not candidate.is_empty() or body()==p:walk=candidate;found=true;break
			if found:break
		check(found and follow(walk),"walk to generated chest")
		check(game._interact_chest() and driver.advance_steps(10)==10,"open generated chest with F")
		check(game._interact_chest(),"choose generated item with F")
		if game._pickup_open: check(game._pickup_item(items[0]),"select generated item")
		check(driver.advance_steps(10)==10,"take generated item")
		check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].has(items[0]),"generated item in player inventory")
	game.queue_free()
	await process_frame
	if existed:
		var file:=FileAccess.open(path,FileAccess.WRITE);file.store_buffer(old);file.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Demo automatic normal chest: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
