extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func key(game:Node,k:Key)->void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func click(game:Control,p:Vector2,button:MouseButton=MOUSE_BUTTON_LEFT)->void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*p;e.button_index=button;e.pressed=true;game._input(e)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame;game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	var center:Vector2=game._map_origin()+game._camera_center_world()*game.STEP_PX
	var time:float=driver.game_time
	var initial_dir:Vector2=game.attack_direction
	click(game,center+Vector2(100,45))
	check(game._direction_action=="" and not driver.is_action_active and game.attack_direction==initial_dir,"click without selected action does not attack or change direction")
	key(game,KEY_SPACE)
	check(game._direction_action=="attack" and not driver.is_action_active and driver.game_time==time,"select attack without time")
	click(game,center)
	check(game._direction_action=="attack" and not driver.is_action_active,"click on center doesn't choose direction")
	key(game,KEY_B)
	check(game._direction_action=="block" and not driver.is_action_active,"select other action replaces pending one")
	key(game,KEY_ESCAPE)
	check(game._direction_action=="" and not driver.is_action_active and driver.game_time==time,"cancel free")
	key(game,KEY_SPACE)
	var direction:=Vector2(100,-57).normalized()
	click(game,center+Vector2(100,-57))
	var strike:Dictionary=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})
	check(game._direction_action=="" and strike.get("active",false) and Vector2(strike["data"]["direction"]).is_equal_approx(direction),"click confirms attack with free angle")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel test attack")
	key(game,KEY_SPACE);key(game,KEY_DOWN)
	strike=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})
	check(strike.get("active",false) and Vector2(strike["data"]["direction"])==Vector2.DOWN,"keyboard chooses action then direction")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel keyboard strike")
	key(game,KEY_B);click(game,center+Vector2(-100,0))
	check(game._direction_action=="" and not ask(&"ShieldBlockStatusRequested",{"entity":game.HERO}).get("active",false) and game.message.contains("щит"),"failed block reports missing shield")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open")
	var inv:Array=game._inventory_items();check(game._use_inventory_item(inv.find(&"demo_shield")) and driver.advance_steps(10)==10,"equip shield")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close")
	center=game._map_origin()+game._camera_center_world()*game.STEP_PX
	key(game,KEY_B);check(game._direction_action=="block" and not driver.is_action_active,"block waits for direction")
	click(game,center+Vector2(-90,-25))
	var block:Dictionary=ask(&"ShieldBlockStatusRequested",{"entity":game.HERO})
	check(block.get("active",false) and block.get("direction",Vector2.ZERO) is Vector2 and Vector2(block["direction"]).is_equal_approx(Vector2(-90,-25).normalized()),"selected block starts after direction click")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO}).get("accepted",false),"cancel test block")
	key(game,KEY_SPACE)
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save while choosing")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and game._direction_action=="" and not driver.is_action_active,"load cancels transient choice")
	key(game,KEY_SPACE);click(game,center+Vector2(100,0),MOUSE_BUTTON_RIGHT)
	check(game._direction_action=="" and ask(&"MovementPositionGetRequested",{"entity":game.HERO}).get("moving",false),"right click cancels selection and moves")
	game.queue_free();await process_frame
	print("Game demo action then direction: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
