extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(begin(4) and add_room(1, "passage") and add_room(2, "passage"), "connected rooms")
	check(ask(&"RoomExitAddRequested", {"room":&"node_1", "id":&"north_future", "dir":"north", "offset_cells":5}).get("accepted", false), "add unconnected exit")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_1"})["data"]
	var tile: Vector2i = room["origin_cell"] * 4 + Vector2i(1, 1)
	var save_service = root.get_node("SaveService")
	var before: Dictionary = save_service.collect_world_transition_snapshot()
	var result := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile})
	check(result.get("accepted", false) and result.get("connected_exits_checked", 0) == 2 and result.get("open_exits_checked", 0) == 3, "wall candidate reaches connected and pending exits")
	if result.get("accepted", false):
		var a: Vector2i = result["interaction_anchor"]
		check(root.get_node("DungeonChestPreflightService")._adjacent(a, tile), "interaction anchor adjacent")
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":room["origin_cell"] * 4 + Vector2i(10,10)}).get("accepted", true), "reject interior tile away from wall")
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":room["origin_cell"] * 4}).get("accepted", true), "reject wall")
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"missing", "tile":tile}).get("accepted", true), "reject missing room")
	var bus = root.get_node("EventBus")
	var blocked := func(e): e["fits"] = false
	bus.subscribe(&"SpaceBodyFitsRequested", blocked)
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile}).get("accepted", true), "blocked entry rejected")
	bus.unsubscribe(&"SpaceBodyFitsRequested", blocked)
	var service = root.get_node("DungeonChestPreflightService")
	var last_exit: Dictionary = room["exits"][1]
	var other_seed: Vector2i = service._seed(last_exit)
	var block_exit := func(e):
		if e.get("anchor", null) == other_seed: e["fits"] = false
	bus.subscribe(&"SpaceBodyFitsRequested", block_exit)
	var exit_result := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile})
	bus.unsubscribe(&"SpaceBodyFitsRequested", block_exit)
	check(not exit_result.get("accepted", true) and str(exit_result.get("error", "")).contains("проходы"), "reject unreachable second connected exit")
	var future_exit: Dictionary = room["exits"].filter(func(ex): return ex["id"] == &"north_future")[0]
	var future_seed: Vector2i = service._seed(future_exit)
	var block_future := func(e):
		if e.get("anchor", null) == future_seed: e["fits"] = false
	bus.subscribe(&"SpaceBodyFitsRequested", block_future)
	var future_result := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile})
	bus.unsubscribe(&"SpaceBodyFitsRequested", block_future)
	check(not future_result.get("accepted", true) and str(future_result.get("error", "")).contains("проходы"), "reject unreachable unconnected exit")
	var block_interaction := func(e):
		if e.get("anchor", null) is Vector2i and service._adjacent(e["anchor"], tile): e["fits"] = false
	bus.subscribe(&"SpaceBodyFitsRequested", block_interaction)
	var interaction_result := ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile})
	bus.unsubscribe(&"SpaceBodyFitsRequested", block_interaction)
	check(not interaction_result.get("accepted", true) and str(interaction_result.get("error", "")).contains("взаимодействия"), "reject inaccessible interaction despite exits")
	var occupied := func(e):
		if e.get("tile", null) == tile: e["occupant"] = &"blocker"
	bus.subscribe(&"SpaceTileGetRequested", occupied)
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile}).get("accepted", true), "occupied tile rejected")
	bus.unsubscribe(&"SpaceTileGetRequested", occupied)
	var found := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_1"})
	check(found.get("accepted", false) and found.get("found", false) and found.get("connected_exits_checked", 0) == 2 and found.get("open_exits_checked", 0) == 3, "search reports all open exits")
	var reused := {"room":&"node_1", "tile":tile}
	ask(&"DungeonChestPositionPreflightRequested", reused)
	reused["tile"] = room["origin_cell"] * 4
	ask(&"DungeonChestPositionPreflightRequested", reused)
	check(not reused.get("accepted", true) and not reused.has("open_exits_checked") and not reused.has("interaction_anchor"), "failed reuse clears previous result")
	var after: Dictionary = save_service.collect_world_transition_snapshot()
	check(before.get("valid", false) and after.get("valid", false) and before["payload"]["sections"] == after["payload"]["sections"], "preflight does not mutate snapshot or consume RNG")

	# Герой стоит прямо в проходе: он подвижен, но его реальная позиция
	# должна оставаться в той же доступной области; другие тела блокируют.
	var first_seed: Vector2i = service._seed(room["exits"][0])
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false), "create controlled hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":first_seed,"size":4}).get("accepted",false), "hero on entrance")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control hero")
	check(ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1","tile":tile}).get("accepted",false), "hero on doorway does not block own reachability")
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1","tile":first_seed}).get("accepted",true), "chest cannot occupy hero")
	check(ask(&"EntityCreateRequested", {"entity":&"other"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"other","anchor":other_seed,"size":4}).get("accepted",false), "other body on exit")
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1","tile":tile}).get("accepted",true), "other body still blocks exit")
	check(ask(&"SpaceBodyRemoveRequested", {"entity":&"other"}).get("accepted",false) and ask(&"SpaceBodyRemoveRequested", {"entity":&"hero"}).get("accepted",false), "remove fixtures")

	check(ask(&"ObjectCreateRequested", {"entity":&"test_chest", "type":"chest", "room":&"node_1", "tile":tile, "inventory_capacity":100}).get("accepted", false), "preflight candidate accepted by existing object creation")
	if result.get("accepted", false):
		var fit := ask(&"SpaceBodyFitsRequested", {"anchor":result["interaction_anchor"], "size":4, "room":{"origin":room["origin_cell"]*4, "size":room["size_cells"]*4}, "ignore_entity":&""})
		check(fit.get("fits", false), "interaction anchor still fits after actual obstacle creation")
	check(not ask(&"DungeonChestPositionPreflightRequested", {"room":&"node_1", "tile":tile}).get("accepted", true), "existing chest rejected")
	check(ask(&"RoomCreateRequested", {"id":&"isolated", "type":"passage", "origin_cell":Vector2i(2,25), "size_cells":Vector2i(12,12)}).get("accepted", false), "isolated room")
	check(ask(&"RoomExitAddRequested", {"room":&"isolated", "id":&"pending", "dir":"north", "offset_cells":5}).get("accepted", false), "isolated pending exit")
	var isolated := ask(&"DungeonChestPositionPreflightRequested", {"room":&"isolated", "tile":Vector2i(9,101)})
	check(not isolated.get("accepted", true) and str(isolated.get("error", "")).contains("связанного"), "unconnected exits alone do not establish accessible entrance")
	print("Chest position preflight tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
