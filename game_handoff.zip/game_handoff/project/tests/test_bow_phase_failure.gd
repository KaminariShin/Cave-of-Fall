extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,20)}).get("accepted",false),"map")
	var floors: Array = []
	for x in range(40):
		for y in range(20): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"archer",&"target"]: check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"archer","anchor":Vector2i(2,5),"size":2}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested",{"entity":&"target","anchor":Vector2i(12,5),"size":2}).get("accepted",false),"bodies")
	var hp: float = ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"]
	var fake := {"hp_by_target":{&"target":int(hp)},"hits":[{"source":&"ghost","target":&"target","hit_id":&"projectile:999","damage":3,"independent_projectile":true}]}
	check(not ask(&"SimultaneousDamageApplyRequested",fake).get("accepted",true),"untrusted independent source rejected")
	var arrow := ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":7.0})
	check(arrow.get("accepted",false),"launch")
	var seen := {"batch":[],"expired":[]}
	var bad_protection := func(e):
		if e.get("entity",null)==&"target" and e.get("damage_type","")=="physical": e["percent"] = NAN
	var batch := func(e): seen["batch"].append(e.duplicate(true))
	var expired := func(e): seen["expired"].append(e.duplicate(true))
	bus.subscribe(&"PeriodicProtectionGetRequested",bad_protection); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"ProjectileExpired",expired)
	check(driver.wait_for(1.0) and driver.advance_steps(50)==50,"flight")
	bus.unsubscribe(&"PeriodicProtectionGetRequested",bad_protection); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"ProjectileExpired",expired)
	check(seen["batch"].size()==1 and not seen["batch"][0].get("accepted",true),"bad plan fails batch")
	check(seen["expired"].size()==1 and not seen["expired"][0]["direct"].get("accepted",true),"failed impact reports refusal")
	check(ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"]==hp and root.get_node("ProjectileService")._phase_contacts.is_empty(),"no partial damage or stale queue")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"can save after failed phase")
	print("Bow phase failure guard: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
