extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(value: bool, label: String) -> void:
	if not value: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func run() -> void:
	bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"demo starts")
	ask(&"DungeonPortalPlacementFailed",{"room":game.ROOM,"error":"test blocked"})
	check(game.message.contains("test blocked") and game.message.contains("R"),"portal placement error visible")
	var failed_portal := func(e): e["found"]=true; e["data"]={"status":"failed","room":game.ROOM,"object":null}
	var failed_track := func(e): e["found"]=true; e["data"]={"boss_candidate":&"other_room"}
	var retry_portal := func(e): e["accepted"]=true
	bus.subscribe(&"DungeonPortalGetRequested",failed_portal)
	bus.subscribe(&"DungeonFloorTrackingGetRequested",failed_track)
	bus.subscribe(&"DungeonPortalPlacementRetryRequested",retry_portal)
	game._retry_spawns()
	check(game.message=="Портал размещён.","portal placement retry routed")
	bus.unsubscribe(&"DungeonPortalGetRequested",failed_portal)
	bus.unsubscribe(&"DungeonFloorTrackingGetRequested",failed_track)
	bus.unsubscribe(&"DungeonPortalPlacementRetryRequested",retry_portal)
	var hero: Dictionary = ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]
	var tile: Vector2i = hero["anchor"] + Vector2i(hero["size"],1)
	# Рендер и маршрутизация демосцены проверяются на имитированном объекте;
	# настоящие правила портала проверяются test_dungeon_portal_object.gd.
	var fake_portal := func(e): e["found"]=true; e["data"]={"status":"placed","object":&"fake_portal"}
	var fake_object := func(e):
		if e.get("object",null) == &"fake_portal": e["found"]=true; e["data"]={"tile":tile}
	var fake_interact := func(e):
		if e.get("object",null) == &"fake_portal":
			e["accepted"]=true
			bus.publish(&"RunStatisticsFinished",{"entity":game.HERO,"outcome":"victory"})
	bus.subscribe(&"DungeonPortalGetRequested",fake_portal)
	bus.subscribe(&"ObjectGetRequested",fake_object)
	bus.subscribe(&"ObjectInteractRequested",fake_interact)
	check(game._interact_chest() and game.is_won,"F interaction reaches portal victory")
	check(not game._interact_chest(),"victory blocks interaction")
	check(not ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",true),"victory blocks demo save")
	bus.unsubscribe(&"DungeonPortalGetRequested",fake_portal)
	bus.unsubscribe(&"ObjectGetRequested",fake_object)
	bus.unsubscribe(&"ObjectInteractRequested",fake_interact)
	game.queue_free()
	await process_frame
	print("Game demo victory UI: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
