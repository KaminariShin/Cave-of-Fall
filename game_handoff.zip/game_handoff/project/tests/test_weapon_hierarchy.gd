extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"WeaponTypeRegisterRequested", {"definition":{"id":"fixture_sword", "base_attack_time":1.0, "min_percent":0.4}})["accepted"], "type")
	check(ask(bus, &"WeaponTagRegisterRequested", {"definition":{"id":"fixture_light"}})["accepted"], "marker")
	check(ask(bus, &"WeaponTagRegisterRequested", {"definition":{"id":"fixture_heavy", "min_time_bonus":0.2, "stamina_cost_percent":0.1}})["accepted"], "fixture_heavy")
	check(ask(bus, &"WeaponTagRegisterRequested", {"definition":{"id":"fixture_two_handed", "min_time_bonus":0.1, "stamina_cost_percent":-0.03}})["accepted"], "two handed")
	check(not ask(bus, &"WeaponVariantRegisterRequested", {"definition":{"id":"bad", "type":"fixture_sword", "tags":["missing"]}})["accepted"], "unknown tag")
	check(not ask(bus, &"WeaponVariantRegisterRequested", {"definition":{"id":"bad", "type":"fixture_sword", "tags":["fixture_light", "fixture_light"]}})["accepted"], "duplicate tag")
	check(ask(bus, &"WeaponVariantRegisterRequested", {"definition":{"id":"short", "type":"fixture_sword", "tags":["fixture_light"], "base_attack_time":0.9}})["accepted"], "short")
	check(ask(bus, &"WeaponVariantRegisterRequested", {"definition":{"id":"great", "type":"fixture_sword", "tags":["fixture_heavy", "fixture_two_handed"], "base_attack_time":1.4}})["accepted"], "great")
	var data := ask(bus, &"WeaponVariantResolveRequested", {"variant":"short"})
	check(data["found"] and data["data"]["base_attack_time"] == 0.9 and data["data"]["min_percent"] == 0.4 and data["data"]["tags"] == ["fixture_light"], "inherit and marker")
	data = ask(bus, &"WeaponVariantResolveRequested", {"variant":"great"})
	check(data["found"] and is_equal_approx(data["data"]["min_time_bonus"], 0.3) and is_equal_approx(data["data"]["stamina_cost_percent"], 0.07), "stack bonuses")
	check(ask(bus, &"ItemBaseRegisterRequested", {"base":{"id":"sword_base", "name":"Sword", "weapon_variant":"great"}})["accepted"], "base")
	check(ask(bus, &"ItemCreateRequested", {"id":&"blade", "base_id":&"sword_base", "item_level":0})["accepted"], "item")
	check(ask(bus, &"WeaponItemResolveRequested", {"item":&"blade"})["data"]["id"] == "great", "item resolution")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load")
	check(ask(bus, &"WeaponItemResolveRequested", {"item":&"blade"})["found"], "restore hierarchy")
	print("Weapon hierarchy tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
