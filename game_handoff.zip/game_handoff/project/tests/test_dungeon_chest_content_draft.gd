extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus = root.get_node("EventBus")
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"probe_entity"}).get("accepted", false), "probe entity")
	var state := {"values":[], "limits":[], "nested":true, "save":true, "probe":false, "mutate":false}
	var mock := func(e):
		state["limits"].append([e["min"],e["max"]])
		if state["probe"]:
			state["probe"] = false
			state["nested"] = ask(&"DungeonChestContentDraftRequested", {"kind":"normal", "depth":1.0}).get("accepted", true)
			state["save"] = ask(&"SessionSaveRequested", {}).get("accepted", true)
		if state["mutate"]:
			state["mutate"] = false
			ask(&"StatBaseSetRequested", {"entity":&"probe_entity", "stat":&"CON", "value":50.0})
		if not state["values"].is_empty(): e["value"] = state["values"].pop_front()
	bus.subscribe(&"RngIntRequested", mock)
	var pre: Dictionary = saver.collect_world_transition_snapshot()
	check(not ask(&"DungeonChestContentDraftRequested", {"kind":"bad", "depth":4}).get("accepted", true) and state["limits"].is_empty(), "invalid kind no RNG")
	check(not ask(&"DungeonChestContentDraftRequested", {"kind":"normal", "depth":-1}).get("accepted", true) and state["limits"].is_empty(), "invalid depth no RNG")
	var service = root.get_node("DungeonChestContentDraftService")
	var original: Dictionary = service._pools.duplicate(true)
	for invalid_pool in [[], [{"id":"missing_base", "weight":1}], [{"id":"potion_hp", "weight":1}], [{"id":"sword_simple", "weight":0}], [{"id":"sword_simple", "weight":1}, {"id":"sword_simple", "weight":1}]]:
		service._pools["equipment"] = invalid_pool
		var rejected := ask(&"DungeonChestContentDraftRequested", {"kind":"normal", "depth":1})
		check(not rejected.get("accepted", true) and state["limits"].is_empty(), "invalid pool rejected before RNG")
	service._pools = original
	state["values"] = [4,39,0,2,0,40,0,99,17,0,19,3,990,990,940]
	state["limits"] = []
	state["probe"] = true
	var boss := ask(&"DungeonChestContentDraftRequested", {"kind":"boss", "depth":4.0})
	check(boss.get("accepted", false) and not boss.get("rolled_back", true) and not state["nested"] and not state["save"], "boss draft and reentrant guards")
	if boss.get("accepted", false):
		var draft: Dictionary = boss["draft"]
		var slots: Array = draft["slots"]
		check(not draft["complete"] and slots.size() == 4 and draft["kind"] == "boss", "four incomplete plans")
		check(slots[0] == {"category":"equipment", "base_id":&"sword_simple", "item_level":2, "rarity":&"normal"}, "category 39 selects equipment, low level and normal")
		check(slots[1] == {"category":"consumable", "base_id":&"potion_hp", "item_level":null, "rarity":null}, "category 40 selects consumable")
		check(slots[2]["base_id"] == &"bandage" and slots[3] == {"category":"equipment", "base_id":&"armor_iron_body", "item_level":3, "rarity":&"rare"}, "weighted pool bounds and special fallback")
		check(state["limits"] == [[4,8],[0,99],[0,19],[2,3],[0,999],[0,99],[0,17],[0,99],[0,17],[0,99],[0,19],[2,3],[0,999],[0,990],[0,989]], "exact ranges and reroll weights")
	var post: Dictionary = saver.collect_world_transition_snapshot()
	var b: Dictionary = pre["payload"]["sections"].duplicate(true)
	var a: Dictionary = post["payload"]["sections"].duplicate(true)
	b.erase("rng"); a.erase("rng")
	check(pre.get("valid", false) and post.get("valid", false) and a == b, "successful draft changes no world except RNG")
	state["values"] = [5,40,0,40,0,40,0,40,0,40,0]
	state["limits"] = []
	var normal := ask(&"DungeonChestContentDraftRequested", {"kind":"normal", "depth":0.0})
	check(normal.get("accepted", false) and normal["draft"]["slots"].size() == 5 and state["limits"][0] == [2,5], "normal chest count uses 2 through 5")
	var before_error: Dictionary = saver.collect_world_transition_snapshot()
	state["values"] = [2,100]
	state["limits"] = []
	var failed := ask(&"DungeonChestContentDraftRequested", {"kind":"normal", "depth":1})
	var after_error: Dictionary = saver.collect_world_transition_snapshot()
	check(not failed.get("accepted", true) and failed.get("rolled_back", false) and not failed.has("draft") and before_error["payload"]["sections"] == after_error["payload"]["sections"], "invalid RNG rolls back whole snapshot including RNG")
	state["values"] = [2,40,0,40,0]
	state["mutate"] = true
	var mutation_before: Dictionary = saver.collect_world_transition_snapshot()
	var mutation := ask(&"DungeonChestContentDraftRequested", {"kind":"normal", "depth":1})
	var mutation_after: Dictionary = saver.collect_world_transition_snapshot()
	check(not mutation.get("accepted", true) and mutation.get("rolled_back", false) and mutation_before["payload"]["sections"] == mutation_after["payload"]["sections"], "foreign serializable mutation forces rollback")
	bus.unsubscribe(&"RngIntRequested", mock)
	ask(&"RngSeedRequested", {"seed":478})
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save RNG before plan")
	var first := ask(&"DungeonChestContentDraftRequested", {"kind":"normal", "depth":5.0})
	check(ask(&"SessionLoadRequested", {}).get("accepted", false), "restore RNG")
	var replay := ask(&"DungeonChestContentDraftRequested", {"kind":"normal", "depth":5.0})
	check(first.get("accepted", false) and replay.get("accepted", false) and first["draft"] == replay["draft"], "same RNG reproduces draft")
	print("Chest content draft tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
