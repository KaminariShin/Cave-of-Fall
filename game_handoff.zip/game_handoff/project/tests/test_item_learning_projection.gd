extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func project(actor: StringName, item: StringName) -> Dictionary:
	return ask(&"ItemLearningProjectionRequested", {"entity":actor,"item":item})
func wait(driver) -> bool:
	return ask(&"ActionStartRequested", {"entity":&"hero","action":&"wait","duration":0.01}).get("accepted",false) and driver.advance_steps(1) == 1
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":20}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":20}).get("accepted",false), "inventories")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	check(ask(&"ItemCreateRequested", {"id":&"shield", "base_id":&"shield_small", "item_level":5, "rarity":&"magic", "learning":schema}).get("accepted",false), "create")
	# Технически прикреплённые примеры; реальные эффекты модов ещё не подключены.
	check(ask(&"ItemModAttachRequested", {"item":&"shield", "mod":{"id":&"m1", "category":"prefix", "stat":"CON", "value":1, "unlock_after":5}}).get("accepted",false), "first fixture mod")
	check(ask(&"ItemModAttachRequested", {"item":&"shield", "mod":{"id":&"m2", "category":"suffix", "stat":"PER", "value":1, "unlock_after":10}}).get("accepted",false), "second fixture mod")
	check(ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false), "own")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var first := project(&"hero",&"shield")
	check(first.get("accepted",false) and first["data"]["progress"] == 0 and first["data"]["base_penalty"] == 0.5 and first["data"]["base_multiplier"] == 0.5 and first["data"]["active_mods"].is_empty() and first["data"]["inactive_mods"] == [&"m1",&"m2"] and not first["data"]["globally_identified"], "projection from real state")
	check(not project(&"npc",&"shield").get("accepted",true) and not project(&"hero",&"missing").get("accepted",true), "wrong ownership or item rejected")
	check(before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "read-only, no RNG")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "equip")
	for i in range(5): check(wait(driver), "wait")
	var learned := project(&"hero",&"shield")
	check(learned.get("accepted",false) and learned["data"]["progress"] == 5 and is_equal_approx(learned["data"]["base_penalty"],0.4) and learned["data"]["active_mods"] == [&"m1"] and learned["data"]["inactive_mods"] == [&"m2"], "progress enables first mod in projection")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and project(&"hero",&"shield")["data"] == learned["data"], "projection after load")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "unequip")
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false), "transfer to NPC")
	var npc := project(&"npc",&"shield")
	check(npc.get("accepted",false) and npc["data"]["progress"] == 6 and npc["data"]["base_penalty"] == 0.0 and npc["data"]["active_mods"] == [&"m1",&"m2"] and npc["data"]["npc"] and not npc["data"]["globally_identified"], "NPC no penalty without global identification")
	check(ask(&"InventoryRemoveRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and project(&"hero",&"shield")["data"]["progress"] == 6, "progress follows item")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":10}).get("accepted",false) and ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and driver.advance_steps(100) == 100, "identify")
	var known := project(&"hero",&"shield")
	check(known["data"]["globally_identified"] and known["data"]["base_penalty"] == 0.0 and known["data"]["active_mods"] == [&"m1",&"m2"], "identified enables all in projection")
	check(ask(&"ItemCreateRequested", {"id":&"bad", "base_id":&"shield_small", "item_level":1, "rarity":&"magic", "learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"bad","mod":{"id":&"missing_gate","category":"prefix"}}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"bad"}).get("accepted",false) and not project(&"hero",&"bad").get("accepted",true), "missing mod unlock rejected without guessing")
	print("Item learning projection tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
