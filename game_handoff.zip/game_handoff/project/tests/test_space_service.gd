extends SceneTree
var failures := 0
var entries: Array = []
var moves: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	bus.subscribe(&"SpacePassageEntered", func(e): entries.append(e.duplicate()))
	bus.subscribe(&"EntityMoved", func(e): moves.append(e.duplicate()))
	check(ask(bus, &"SpaceCellToTileRequested", {"cell": Vector2i(2, 3)})["tile"] == Vector2i(8, 12), "cell to tile")
	check(ask(bus, &"SpaceTileToCellRequested", {"tile": Vector2i(-1, -5)})["cell"] == Vector2i(-1, -2), "negative floor division")
	check(ask(bus, &"SpaceTileToCanvasRequested", {"tile": Vector2i(2, 3)})["canvas"] == Vector2(28, 42), "tile to canvas")
	check(ask(bus, &"SpaceCanvasToTileRequested", {"canvas": Vector2(-0.1, 14.0)})["tile"] == Vector2i(-1, 1), "canvas to tile")
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(16, 12)})["accepted"], "configure")
	check(ask(bus, &"SpaceTileGetRequested", {"tile": Vector2i(0, 0)})["kind"] == 0, "rock default")
	var floor_tiles: Array = []
	for x in range(16):
		for y in range(12):
			floor_tiles.append(Vector2i(x, y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": floor_tiles, "kind": 1})["accepted"], "paint floor")
	check(not entities.create_entity(&"bad", {&"position": {"anchor": Vector2i.ZERO}}), "reject bypass placement")
	check(entities.create_entity(&"hero") and entities.create_entity(&"rat"), "create units")
	var room := {"origin": Vector2i.ZERO, "size": Vector2i(8, 8)}
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i.ZERO, "size": 4, "room": room})["accepted"], "place 4x4")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"rat", "anchor": Vector2i(5, 0), "size": 2})["accepted"], "place 2x2")
	check(not ask(bus, &"SpaceBodyFitsRequested", {"anchor": Vector2i(3, 0), "size": 4, "ignore_entity": &"hero", "room": room})["fits"], "collision")
	check(not ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(3, 0)})["accepted"], "collision blocks movement")
	check(not ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i.ZERO], "kind": 0})["accepted"], "cannot paint occupied tile rock")
	check(not ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(10, 10)})["accepted"], "cannot reset with bodies")
	var clamped := ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(100, 100)})
	check(clamped["accepted"] and clamped["anchor"] == Vector2i(4, 4), "room clamping")
	var body := ask(bus, &"SpaceBodyGetRequested", {"entity": &"hero"})
	check(body["data"]["center"] == Vector2(6, 6), "center is anchor + B/2")
	check(entities.get_component(&"hero", &"position")["anchor"] == Vector2i(4, 4), "position synchronized")
	check(not entities.set_component(&"hero", &"position", {"anchor": Vector2i.ZERO}), "position direct write blocked")
	check(ask(bus, &"SpaceBodyRoomSetRequested", {"entity": &"hero", "room": null})["accepted"], "clear room clamp")
	check(ask(bus, &"SpaceBodyRemoveRequested", {"entity": &"rat"})["accepted"], "remove blocking rat")
	var passage := [Vector2i(8, 0), Vector2i(8, 1), Vector2i(8, 2), Vector2i(8, 3)]
	check(ask(bus, &"SpacePassageSetRequested", {"tiles": passage})["accepted"], "four-tile passage")
	check(not ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(8, 0)], "kind": 0})["accepted"], "passage must be removed before rock")
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(5, 0)})["accepted"], "enter passage")
	check(entries.size() == 1 and entries[0]["entity"] == &"hero", "passage trigger")
	check(moves.size() == 2 and moves[1]["to"] == Vector2i(5, 0), "move events")
	var save := ask(bus, &"SessionSaveRequested", {})
	check(save.get("accepted", false), "save spatial state: " + str(save))
	check(ask(bus, &"SpaceBodyRemoveRequested", {"entity": &"hero"})["accepted"], "remove body")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load spatial state")
	check(ask(bus, &"SpaceBodyGetRequested", {"entity": &"hero"})["data"]["anchor"] == Vector2i(5, 0), "restore body")
	check(ask(bus, &"SpaceTileGetRequested", {"tile": Vector2i(8, 0)})["occupant"] == &"hero", "restore occupancy")
	check(entities.remove_entity(&"hero"), "remove entity")
	check(ask(bus, &"SpaceTileGetRequested", {"tile": Vector2i(8, 0)})["occupant"] == null, "cleanup after entity removal")
	print("Space tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
