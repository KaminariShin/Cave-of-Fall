extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func ask(id: StringName, e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func check(v: bool, text: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",text)
func visible(t: Vector2i) -> bool:
	var one := ask(&"FogTileGetRequested",{"tile":t})
	var all := ask(&"FogStateGetRequested",{})
	check(one.get("terrain_visible",false) == all.get("visible_tiles",[]).has(t),"single tile and full state agree " + str(t))
	return one.get("terrain_visible",false)
func run() -> void:
	bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(80,80)}).get("accepted",false),"map")
	check(ask(&"RoomCreateRequested",{"id":&"start","type":"start","origin_cell":Vector2i(1,1),"size_cells":Vector2i(12,12)}).get("accepted",false),"room")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(18,18),"size":4}).get("accepted",false),"place")
	check(ask(&"RoomEnterRequested",{"entity":&"hero","room":&"start"}).get("accepted",false),"enter")
	check(ask(&"FogDetectionRadiusSetRequested",{"entity":&"hero","radius":15.0}).get("accepted",false),"radius")
	check(visible(Vector2i(27,20)),"open floor visible")
	var wall: Array = []
	for y in range(8,33): wall.append(Vector2i(25,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":wall,"kind":0}).get("accepted",false),"wall")
	check(visible(Vector2i(25,20)),"front wall visible")
	check(not visible(Vector2i(26,20)) and not visible(Vector2i(27,20)),"wall hides floor behind it")
	check(not visible(Vector2i(29,24)) and visible(Vector2i(24,20)),"wall blocks angled view but not near floor")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[Vector2i(25,20)],"kind":1}).get("accepted",false),"door open")
	check(visible(Vector2i(27,20)),"can see through open door")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load")
	check(visible(Vector2i(25,20)) and not visible(Vector2i(27,20)),"wall occlusion restored")
	var fog = root.get_node("FogService")
	var floors := {Vector2i(2,2):true,Vector2i(3,3):true}
	check(not fog._line_visible(Vector2(2.5,2.5),Vector2i(3,3),floors),"cannot see between touching wall corners")
	floors[Vector2i(3,2)]=true; floors[Vector2i(2,3)]=true
	check(fog._line_visible(Vector2(2.5,2.5),Vector2i(3,3),floors),"open diagonal visible")
	print("Fog wall visibility: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
