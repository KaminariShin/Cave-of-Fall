extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11), "inventory_capacity":0.1}).get("accepted",false), "chest")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false), "hero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted",false), "hero inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(10,10), "size":4}).get("accepted",false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"room"}).get("accepted",false), "enter")
	var state := {"n":0}
	var rng := func(e):
		state["n"] += 1
		e["value"] = 40 if state["n"] in [2,4,6,8] else e["min"]
	bus.subscribe(&"RngIntRequested",rng)
	var attached := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	bus.unsubscribe(&"RngIntRequested",rng)
	check(attached.get("accepted",false), "plan")
	if not attached.get("accepted",false): quit(1); return
	var ids := [&"citem1", &"citem2", &"citem3", &"citem4"]
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var fail_capacity := ask(&"ChestConsumableDraftMaterializeRequested", {"object":&"chest", "item_ids":ids})
	check(not fail_capacity.get("accepted",true) and fail_capacity.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "capacity failure rolls back all")
	check(ask(&"InventoryConfigureRequested", {"entity":&"chest", "volume":10}).get("accepted",false), "raise capacity")
	before = saver.collect_world_transition_snapshot()
	var probe := {"nested":true, "save":true, "once":true}
	var observer := func(_e):
		if probe["once"]:
			probe["once"] = false
			probe["nested"] = ask(&"ChestConsumableDraftMaterializeRequested", {"object":&"chest", "item_ids":ids}).get("accepted",true)
			probe["save"] = ask(&"SessionSaveRequested", {}).get("accepted",true)
			ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"CON", "value":42.0})
	bus.subscribe(&"ItemCreated",observer)
	var changed := ask(&"ChestConsumableDraftMaterializeRequested", {"object":&"chest", "item_ids":ids})
	bus.unsubscribe(&"ItemCreated",observer)
	check(not changed.get("accepted",true) and changed.get("rolled_back",false) and not probe["nested"] and not probe["save"] and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "foreign mutation, nested action and save guarded")
	check(not ask(&"ChestConsumableDraftMaterializeRequested", {"object":&"chest", "item_ids":[&"same",&"same",&"a",&"b"]}).get("accepted",true), "duplicate ids reject")
	var done := ask(&"ChestConsumableDraftMaterializeRequested", {"object":&"chest", "item_ids":ids})
	check(done.get("accepted",false), "materialize consumables")
	if not done.get("accepted",false): print(done); quit(1); return
	var obj: Dictionary = ask(&"ObjectGetRequested", {"object":&"chest"})["data"]
	check(obj.get("content_fixed",false) and not obj.has("content_draft"), "draft finalized")
	check(ask(&"InventoryGetRequested", {"entity":&"chest"})["data"]["items"] == ids, "all real items owned by chest")
	for i in range(ids.size()):
		var item: Dictionary = ask(&"ItemGetRequested", {"item":ids[i]})["item_data"]
		var slot: Dictionary = attached["draft"]["slots"][i]
		check(item["base_id"] == slot["base_id"] and item["item_level"] == slot["item_level"] and item["materials"] == slot["materials"] and item["mods"].is_empty(), "item matches plan")
	check(saver.collect_world_transition_snapshot()["payload"]["sections"]["rng"] == before["payload"]["sections"]["rng"], "materialization uses no RNG")
	check(ask(&"ItemCreateRequested", {"id":&"extra", "base_id":&"potion_hp", "item_level":1}).get("accepted",false), "extra item")
	check(not ask(&"InventoryAddRequested", {"entity":&"chest", "item":&"extra"}).get("accepted",true), "fixed chest cannot be replenished before opening")
	check(not ask(&"ChestConsumableDraftMaterializeRequested", {"object":&"chest", "item_ids":ids}).get("accepted",true), "cannot generate twice")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"InventoryGetRequested", {"entity":&"chest"})["data"]["items"] == ids, "materialized content persists")
	check(ask(&"ObjectInteractRequested", {"entity":&"hero", "object":&"chest"}).get("accepted",false) and driver.advance_steps(10) == 10, "finalized chest opens")
	check(ask(&"ChestTakeRequested", {"entity":&"hero", "object":&"chest", "item":ids[0]}).get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"InventoryGetRequested", {"entity":&"hero"})["data"]["items"].has(ids[0]), "actual consumable can be taken")
	check(ask(&"ObjectCreateRequested", {"entity":&"equipment_chest", "type":"chest", "room":&"room", "tile":Vector2i(20,20), "inventory_capacity":10}).get("accepted",false), "second chest")
	var minroll := func(e): e["value"] = e["min"]
	bus.subscribe(&"RngIntRequested",minroll)
	check(ask(&"DungeonChestDraftAttachRequested", {"object":&"equipment_chest", "kind":"boss", "depth":1}).get("accepted",false), "equipment draft")
	bus.unsubscribe(&"RngIntRequested",minroll)
	before = saver.collect_world_transition_snapshot()
	var equipment := ask(&"ChestConsumableDraftMaterializeRequested", {"object":&"equipment_chest", "item_ids":[&"d1",&"d2",&"d3",&"d4"]})
	check(not equipment.get("accepted",true) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "equipment draft conservatively rejected")
	print("Chest consumable materialization tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
