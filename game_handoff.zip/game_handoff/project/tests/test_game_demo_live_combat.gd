extends SceneTree
var bus: Node
var game: Node
var driver: Node
var failures := 0
func _initialize() -> void: call_deferred("run")
func ask(id: StringName, e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func alive(id: StringName) -> bool:
	return ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false)
func hp(id: StringName) -> float:
	return float(ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"})["data"]["current"])
func pos(id: StringName) -> Vector2i:
	return ask(&"SpaceBodyGetRequested",{"entity":id})["data"]["anchor"]
func walk_to_loot(tile: Vector2i) -> bool:
	var start := pos(game.HERO)
	var data: Dictionary = ask(&"RoomGetRequested",{"id":game.ROOM})["data"]
	var bounds := {"origin":data["origin_cell"]*4,"size":data["size_cells"]*4}
	var queue: Array = [start]
	var prev: Dictionary = {start:null}
	var index := 0
	var goal := Vector2i(-1,-1)
	while index < queue.size():
		var p: Vector2i = queue[index]
		index += 1
		if Rect2i(p,Vector2i(4,4)).has_point(tile): goal=p;break
		for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var n: Vector2i=p+d
			if not prev.has(n) and ask(&"SpaceBodyFitsRequested",{"anchor":n,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false):
				prev[n]=p;queue.append(n)
	if goal.x<0:return false
	var route: Array=[]
	while goal != start:
		var p: Vector2i=prev[goal]
		route.push_front(goal-p)
		goal=p
	for d in route:
		var expected: Vector2i=pos(game.HERO)+d
		if not game._move(d):return false
		driver.advance_steps(200)
		if pos(game.HERO)!=expected:return false
	return true
func run() -> void:
	bus = root.get_node("EventBus")
	driver = root.get_node("TimeDriver")
	driver.set_process(false)
	game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"demo setup")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open inventory")
	var inv:Array=game._inventory_items()
	check(game._use_inventory_item(inv.find(&"demo_shield")) and driver.advance_steps(10)==10,"equip shield")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close inventory")
	var blocks:Dictionary={"absorbed":0,"hits":0}
	bus.subscribe(&"CombatPhaseBatchResolved",func(e):
		var b:Dictionary=e.get("data",{}).get("blocks",{}).get(game.HERO,{})
		if not b.is_empty(): blocks["hits"]+=1;blocks["absorbed"]+=int(b.get("absorbed",0)))
	var hero_start := hp(game.HERO)
	var rat_start := hp(game.RAT)
	var attacks := 0
	for i in range(35):
		if not alive(game.HERO) or not alive(game.RAT): break
		var h: Vector2i = pos(game.HERO)
		var r: Vector2i = pos(game.RAT)
		var delta: Vector2 = Vector2(r+Vector2i.ONE-(h+Vector2i(2,2)))
		var aim: Vector2 = delta.normalized() if delta.length_squared()>0.0 else Vector2.RIGHT
		var preview := ask(&"WeaponStrikePreviewRequested",{"entity":game.HERO,"item":&"demo_sword","strike":game.STRIKE,"kind":"physical","direction":aim})
		var rat_rect := Rect2i(r,Vector2i(2,2))
		var in_zone := false
		for tile in preview.get("zone",{}).get("tiles",[]):
			if rat_rect.has_point(tile): in_zone=true;break
		var enemy_action:=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.RAT})
		var enemy_time:=ask(&"ActionGetRequested",{"entity":game.RAT})
		var threat:=false
		if enemy_action.get("active",false) and enemy_time.get("found",false):
			var mid:float=ceilf(float(enemy_action["data"]["duration_steps"])/2.0)*0.01
			var remaining:float=mid-float(enemy_time["data"]["elapsed"])
			threat=remaining>0 and remaining<=0.5
		if threat:
			game._start_shield_block(aim)
		elif in_zone:
			game.attack_direction=aim
			if game._start_attack(): attacks += 1
		else:
			var d := Vector2i(signi(int(delta.x)),0) if absf(delta.x)>=absf(delta.y) else Vector2i(0,signi(int(delta.y)))
			if d == Vector2i.ZERO or not game._move(d): game._wait()
		driver.advance_steps(100)
	print("combat result attacks=",attacks," hero_hp=",hp(game.HERO)," rat_alive=",alive(game.RAT)," positions=",pos(game.HERO) if alive(game.HERO) else Vector2i(-1,-1),"/",pos(game.RAT) if alive(game.RAT) else Vector2i(-1,-1))
	check(attacks>0,"player attacks using demo controls")
	check(blocks["hits"]>0 and blocks["absorbed"]>0,"enemy strike absorbed by shield")
	check(not alive(game.RAT) or hp(game.RAT)<rat_start,"player damages live enemy")
	check(not alive(game.RAT),"player defeats live tutorial rat")
	if not alive(game.RAT):
		check(ask(&"RunStatisticsGetRequested",{}).get("data",{}).get("kills",0)==1,"combat kill recorded")
		var loot: Dictionary=ask(&"LootGetRequested",{}).get("items",{})
		check(loot.has(&"demo_trophy"),"combat loot dropped")
		if loot.has(&"demo_trophy"):
			check(walk_to_loot(loot[&"demo_trophy"]["tile"]),"walk to trophy without teleport")
			for i in range(3):
				if ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].has(&"demo_trophy"):break
				check(game._pickup(),"real pickup action")
				driver.advance_steps(100)
			check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].has(&"demo_trophy"),"trophy in inventory")
	game.queue_free()
	await process_frame
	print("Game demo live combat: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
