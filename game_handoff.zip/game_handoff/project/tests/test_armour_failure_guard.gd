extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func hp() -> float:
	return float(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false), "hero")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":10}).get("accepted",false), "control and inventory")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0}).get("accepted",false), "insufficient INT")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	check(ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_small","item_level":20,"learning":schema}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false), "shield")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "equip")
	var okay := ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"physical","percent":0.0})
	check(okay.get("percent",null) is float and float(okay["percent"]) > 0 and not okay.has("protection_error"), "valid protection")
	var broken_material := func(e):
		if e.get("material",null) == &"iron_common": e["found"] = false
	bus.subscribe(&"MaterialGetRequested",broken_material)
	var bad := ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"physical","percent":0.0})
	check(bad.get("percent",42) == null and bad.has("protection_error"), "provider reports error not zero")
	var before := hp()
	var hit := ask(&"CombatDamageRequested", {"entity":&"hero","damage_type":"physical","amount":2})
	check(not hit.get("accepted",true) and hit.has("error") and hp() == before, "direct physical damage rejected, HP intact")
	var failures_seen := {"n":0}
	var on_failure := func(_e): failures_seen["n"] += 1
	bus.subscribe(&"PeriodicEffectFailed",on_failure)
	check(ask(&"PeriodicEffectApplyRequested", {"entity":&"hero","effect":&"poison","damage_type":"physical","damage_per_tick":3.0,"base_duration":1.0}).get("accepted",false), "apply periodic")
	check(driver.wait_for(1.0) and driver.advance_steps(50) == 50 and hp() == before and failures_seen["n"] == 1, "bad protection rejects periodic tick")
	bus.unsubscribe(&"MaterialGetRequested",broken_material)
	check(driver.advance_steps(50) == 50 and hp() < before, "next tick works after recovery")
	bus.unsubscribe(&"PeriodicEffectFailed",on_failure)
	var broken_learning := func(e):
		if e.get("item",null) == &"shield" and e.get("found",false): e["item_data"]["learning"]["full_progress"] = 0
	bus.subscribe(&"ItemGetRequested",broken_learning)
	before = hp()
	bad = ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"physical","percent":0.0})
	check(bad.get("percent",42) == null and not ask(&"CombatDamageRequested", {"entity":&"hero","damage_type":"physical","amount":2}).get("accepted",true) and hp() == before, "invalid learning schema cannot bypass defense")
	bus.unsubscribe(&"ItemGetRequested",broken_learning)
	var corrupt_formula := func(e): e["accepted"] = false
	bus.subscribe(&"ArmourProtectionCalculateRequested",corrupt_formula)
	bad = ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"physical","percent":0.0})
	check(bad.get("percent",42) == null and bad.has("protection_error"), "formula failure not zero")
	bus.unsubscribe(&"ArmourProtectionCalculateRequested",corrupt_formula)
	var magical := ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"magical","percent":12.0})
	check(magical["percent"] == 12.0 and not magical.has("protection_error"), "nonphysical unchanged")
	var after := ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"physical","percent":0.0})
	check(after.get("percent",null) is float and float(after["percent"]) > 0, "normal protection restored")
	print("Armour failure guard tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
