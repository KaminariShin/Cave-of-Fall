extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool, label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func plan(d = Vector2.RIGHT, strike = "sword_simple_thrust") -> Dictionary:
	return ask(&"WeaponStrikeStartPlanRequested", {"entity":&"hero","item":&"sword","strike":strike,"direction":d})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(5,5),"size":2}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false),"inventory")
	check(ask(&"ItemCreateRequested", {"id":&"sword","base_id":&"sword_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"sword"}).get("accepted",false),"item")
	check(not plan().get("accepted",true),"inventory weapon rejected")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"sword","slot":"main"}).get("accepted",false),"equip")
	check(root.get_node("TimeDriver").advance_steps(10) == 10,"complete equip")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":4}).get("accepted",false),"stamina")
	var p := plan(Vector2(3,4))
	if not p.get("accepted",false): print("plan error: ",p)
	check(p.get("accepted",false),"valid plan")
	if p.get("accepted",false):
		var d: Dictionary = p["data"]
		check(d["direction"].is_equal_approx(Vector2(0.6,0.8)) and d["full_cost"] == 7 and d["spend"] == 4 and d["damage_multiplier"] == 0.5 and d["midpoint_step"] == ceili(d["duration_steps"]/2.0),"normalized, weakened, midpoint")
	check(ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]["current"] == 4 and not ask(&"ActionGetRequested", {"entity":&"hero"}).get("found",false),"no side effects")
	check(not plan(Vector2.ZERO).get("accepted",true) and not plan(Vector2(INF,0)).get("accepted",true) and not plan(Vector2.RIGHT,"unknown").get("accepted",true),"invalid requests")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":0.5}).get("accepted",false) and not plan().get("accepted",true),"insufficient stamina")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":4}).get("accepted",false),"restore stamina")
	check(ask(&"ActionStartRequested", {"entity":&"hero","action":&"wait","duration":0.1}).get("accepted",false) and not plan().get("accepted",true),"busy actor")
	print("Weapon strike start plan tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
