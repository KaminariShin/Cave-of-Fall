extends SceneTree

var failures := 0
var topology_requests := 0
var all_room_requests := 0

func _initialize() -> void:
	call_deferred("run")

func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)

func ask(id: StringName, event: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, event)
	return event

func reverse(direction: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}.get(direction, "")

func add_link(parent: StringName, child: StringName, origin: Vector2i, direction: String, index: int) -> bool:
	var made := ask(&"RoomCreateRequested", {"id":child, "type":"passage", "origin_cell":origin, "size_cells":Vector2i(12,12)})
	if not made.get("accepted", false): return false
	var parent_exit := StringName("link_%d" % index)
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":direction, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":child, "id":&"entry", "dir":reverse(direction), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":child, "other_exit":&"entry"}).get("accepted", false): return false
	ask(&"RoomChildGenerated", {"room":parent, "child":child, "type":"passage"})
	return true

func count_topology(_event: Dictionary) -> void:
	topology_requests += 1

func count_all_rooms(_event: Dictionary) -> void:
	all_room_requests += 1

func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(240,240)}).get("accepted", false), "configure map")
	check(ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(12,12)}).get("accepted", false), "create start room")
	bus.subscribe(&"RoomTopologyGetRequested", count_topology)
	bus.subscribe(&"RoomAllGetRequested", count_all_rooms)
	check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":&"root"}).get("accepted", false), "begin depth tracking")
	check(topology_requests == 1 and all_room_requests == 0, "tracking uses one compact topology query")
	check(add_link(&"root", &"node_1", Vector2i(14,2), "east", 1), "link root to first child")
	check(add_link(&"node_1", &"node_2", Vector2i(14,14), "south", 2), "link first child to second")
	check(add_link(&"node_2", &"node_3", Vector2i(2,14), "west", 3), "link second child to third")
	var milestones = root.get_node("DungeonMilestoneService")
	check(int(milestones._depth_cache.get(&"node_3", -1)) == 3, "tree depths extend incrementally when a child is connected")
	check(topology_requests == 1 and all_room_requests == 0, "ordinary child generation avoids full room copies and repeated BFS")
	var before_shortcut := ask(&"DungeonRoomDepthRequested", {"room":&"node_3"})
	check(before_shortcut.get("accepted", false) and before_shortcut.get("distance", -1) == 3, "cached distance is correct before shortcut")
	check(ask(&"RoomExitAddRequested", {"room":&"root", "id":&"shortcut_out", "dir":"south", "offset_cells":5}).get("accepted", false), "add shortcut start exit")
	check(ask(&"RoomExitAddRequested", {"room":&"node_3", "id":&"shortcut_in", "dir":"north", "offset_cells":5}).get("accepted", false), "add shortcut destination exit")
	check(ask(&"RoomExitConnectRequested", {"room":&"root", "exit":&"shortcut_out", "other_room":&"node_3", "other_exit":&"shortcut_in"}).get("accepted", false), "connect shortcut")
	check(not milestones._depth_cache_ready, "non-tree connection invalidates distances that may be shorter")
	var after_shortcut := ask(&"DungeonRoomDepthRequested", {"room":&"node_3"})
	check(after_shortcut.get("accepted", false) and after_shortcut.get("distance", -1) == 1, "topology rebuild finds the shorter path")
	check(topology_requests == 2 and all_room_requests == 0, "one compact rebuild replaces full graph copies")
	var topology := ask(&"RoomTopologyGetRequested", {})
	var adjacency: Dictionary = topology.get("topology", {})
	var types: Dictionary = topology.get("room_types", {})
	check(topology.get("room_count", -1) == 4 and adjacency.get(&"root", []).has(&"node_3") and types.get(&"root", "") == "start", "topology query returns compact connected neighbours and types")
	check(not topology.has("rooms") and not topology.has("floor_list"), "topology query omits room geometry and floor copies")
	bus.unsubscribe(&"RoomTopologyGetRequested", count_topology)
	bus.unsubscribe(&"RoomAllGetRequested", count_all_rooms)
	print("Dungeon depth cache: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
