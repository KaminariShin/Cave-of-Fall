extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(v:bool,s:String)->void:
	if not v: failures+=1;printerr("FAIL: ",s)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func text(game:Node,id:StringName)->String:return " | ".join(game._inspection_lines(id))
func key(game:Node,k:Key)->void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	game.size=Vector2(1280,720)
	check(game.initialized and ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":200.0}).get("accepted",false),"capacity")
	for row in [[&"armor_cloth_body",4.0,0],[&"armor_leather_body",8.0,0],[&"armor_iron_body",20.0,0],[&"shield_small",5.0,1],[&"shield_medium",10.0,2],[&"shield_large",20.0,4]]:
		var base:StringName=row[0];var id:=StringName("inspect_"+str(base))
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":base,"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"create "+str(base))
		var t:=text(game,id)
		check(t.contains("Броня материалов: %.2f"%float(row[1])) and t.contains("Вклад в броню: %.2f"%float(row[1])),"armour values "+str(base))
		check(t.contains("Вес:") and t.contains("Объём:") and t.contains("Прогноз по текущим статам"),"other properties "+str(base))
		if int(row[2])>0: check(t.contains("Ширина блока: %d физ. клеток"%int(row[2])) and t.contains("Блок: 0,5 с"),"shield data "+str(base))
	var bases:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema:Dictionary=root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	var mod:={"id":&"pre_armour","category":"prefix","stat":"armor","tier":3,"value":2.0,"level_req":1,"material_id":&"iron_common","unlock_after":5}
	check(ask(&"StatBaseSetRequested",{"entity":game.HERO,"stat":&"INT","value":0}).get("accepted",false),"low INT")
	check(ask(&"ItemCreateRequested",{"id":&"magic_shield","base_id":&"shield_small","item_level":20,"rarity":&"magic","learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested",{"item":&"magic_shield","mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"magic_shield"}).get("accepted",false),"magic shield")
	var hidden:=text(game,&"magic_shield")
	check(hidden.contains("Броня материалов: 5.00") and hidden.contains("Вклад в броню: 2.50") and hidden.contains("50%") and not hidden.contains("Броня: +2"),"hidden mod and learning penalty")
	check(ask(&"EquipmentEquipRequested",{"entity":game.HERO,"item":&"magic_shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10)==10,"equip")
	var actual:Dictionary=ask(&"EquipmentArmourGetRequested",{"entity":game.HERO})
	check(actual.get("found",false) and is_equal_approx(float(actual["armour"]),2.5) and text(game,&"magic_shield").contains("Вклад в броню: 2.50") and not text(game,&"magic_shield").contains("Прогноз"),"equipped contribution matches game")
	for i in range(5): check(ask(&"ActionStartRequested",{"entity":game.HERO,"action":&"wait","duration":0.01}).get("accepted",false) and driver.advance_steps(1)==1,"learn")
	actual=ask(&"EquipmentArmourGetRequested",{"entity":game.HERO})
	check(is_equal_approx(float(actual["armour"]),5.0) and text(game,&"magic_shield").contains("Вклад в броню: 5.00") and text(game,&"magic_shield").contains("Броня: +2"),"revealed bonus and penalty match actual")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open inventory")
	game.inspect_mode=true;game.inspect_item=&"magic_shield";game.inspect_page=0
	game.queue_redraw();await process_frame
	check(game._inspection_lines(&"magic_shield").size()>13,"multiple inspection pages")
	key(game,KEY_RIGHT);check(game.inspect_page==1,"keyboard pagination")
	var click:=InputEventMouseButton.new();click.position=game.get_global_transform_with_canvas()*(game._inventory_rect().position+Vector2(40,389));click.button_index=MOUSE_BUTTON_LEFT;click.pressed=true;game._input(click)
	check(game.inspect_page==0,"mouse pagination")
	game.queue_free();await process_frame
	print("Armour and shield inspection: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
