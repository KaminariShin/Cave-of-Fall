extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,20)}).get("accepted",false),"map")
	var floors: Array = []
	for x in range(40):
		for y in range(20): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"archer",&"target"]: check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"archer","anchor":Vector2i(2,5),"size":2}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested",{"entity":&"target","anchor":Vector2i(12,5),"size":2}).get("accepted",false),"bodies")
	check(ask(&"ResourceSetRequested",{"entity":&"target","resource":&"HP","value":10}).get("accepted",false),"target HP")
	var a := ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":7.0})
	var b := ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":9.0})
	check(a.get("accepted",false) and b.get("accepted",false),"launch two arrows")
	check(ask(&"CombatDamageRequested",{"entity":&"archer","amount":10000}).get("accepted",false) and ask(&"EntityRemoveRequested",{"entity":&"archer"}).get("accepted",false),"remove shooter")
	var seen := {"batch":[],"expired":[],"death":[],"before":-1.0}
	var phase := func(_e):
		if not root.get_node("ProjectileService")._phase_contacts.is_empty():
			seen["before"] = ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"]
	var batch := func(e): seen["batch"].append(e.duplicate(true))
	var expired := func(e): seen["expired"].append(e.duplicate(true))
	var death := func(e):
		if e.get("entity",null)==&"target": seen["death"].append(e.duplicate(true))
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"ProjectileExpired",expired); bus.subscribe(&"EntityDied",death)
	check(driver.wait_for(1.0) and driver.advance_steps(10)==10,"advance pre-impact")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save in flight")
	check(driver.advance_steps(50)>0,"advance to hit")
	check(seen["before"]==10 and seen["batch"].size()==1 and seen["batch"][0].get("accepted",false) and seen["batch"][0].get("hit_count",0)==2,"two hits committed from common HP")
	if seen["batch"].size()==1 and seen["batch"][0].get("accepted",false):
		var hits: Array = seen["batch"][0]["data"]["resolved_hits"]
		check(hits.size()==2 and hits[0]["hit_id"]!=hits[1]["hit_id"] and hits[0]["damage"]+hits[1]["damage"]==16,"two distinct arrow damages")
	check(seen["death"].size()==1 and seen["death"][0].get("killer",null)==&"archer" and seen["death"][0].get("simultaneous",false),"killer attribution to removed owner")
	check(seen["expired"].size()==2 and seen["expired"].all(func(e):return e["direct"].get("accepted",false) and e["direct"].get("simultaneous",false)),"two committed expiration notices")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"restore airborne arrows")
	seen["batch"].clear(); seen["expired"].clear(); seen["death"].clear(); seen["before"]=-1.0
	check(driver.advance_steps(50)>0 and seen["batch"].size()==1 and seen["batch"][0].get("hit_count",0)==2 and seen["death"].size()==1 and seen["expired"].size()==2,"restore resolves both once")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"ProjectileExpired",expired); bus.unsubscribe(&"EntityDied",death)
	print("Bow phase multi runtime: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
