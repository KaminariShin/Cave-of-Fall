extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(value: bool, label: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func inv(id: StringName) -> Array:
	return ask(&"InventoryGetRequested", {"entity":id})["data"]["items"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11), "inventory_capacity":10}).get("accepted", false), "chest")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":2}).get("accepted", false), "hero capacity")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(10,10), "size":4}).get("accepted", false), "place hero")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"room"}).get("accepted", false), "enter")
	check(ask(&"MaterialRegisterRequested", {"material":{"id":"mat_take", "name":"material", "weight_per_unit":1, "volume_per_unit":1, "level":1}}).get("accepted", false), "material")
	check(ask(&"ItemBaseRegisterRequested", {"base":{"id":"base_take", "name":"item", "slot":"main", "tags":[], "materials":[{"material_id":"mat_take", "count":1}]}}).get("accepted", false), "base")
	for id in [&"item_a", &"item_b", &"item_c"]:
		check(ask(&"ItemCreateRequested", {"id":id, "base_id":&"base_take", "item_level":1}).get("accepted", false), "create item")
		check(ask(&"InventoryAddRequested", {"entity":&"chest", "item":id}).get("accepted", false), "stock chest")
	var take := {"entity":&"hero", "object":&"chest", "item":&"item_a"}
	check(not ask(&"ChestTakeRequested", take.duplicate()).get("accepted", true), "closed chest rejected")
	check(not ask(&"ActionStartRequested", {"entity":&"hero", "action":&"chest_take"}).get("accepted", true), "cannot directly start internal action")
	check(ask(&"ObjectInteractRequested", {"entity":&"hero", "object":&"chest"}).get("accepted", false), "open action")
	check(driver.advance_steps(10) == 10, "open complete")
	check(not root.get_node("EntityRegistry").transfer_chest_item(&"hero", &"chest", &"item_a"), "internal commit unauthorized")
	var state := {"consistent":true, "completed":0, "interrupt":0, "nested":true, "save":true, "observed":false}
	var observe := func(_e):
		state["consistent"] = state["consistent"] and inv(&"hero").has(&"item_a") and not inv(&"chest").has(&"item_a")
	var on_component := func(e):
		if e.get("entity", null) == &"hero" and e.get("component", null) == &"inventory" and not state["observed"]:
			state["observed"] = true
			state["nested"] = ask(&"InventoryRemoveRequested", {"entity":&"hero", "item":&"item_a"}).get("accepted", true)
			state["save"] = ask(&"SessionSaveRequested", {}).get("accepted", true)
	var completed := func(_e): state["completed"] += 1
	var interrupted := func(_e): state["interrupt"] += 1
	bus.subscribe(&"InventoryItemRemoved", observe)
	bus.subscribe(&"ComponentChanged", on_component)
	bus.subscribe(&"ChestTakeCompleted", completed)
	bus.subscribe(&"ChestTakeInterrupted", interrupted)
	var t: float = driver.game_time
	check(ask(&"ChestTakeRequested", take.duplicate()).get("accepted", false), "start chest take")
	check(driver.game_time == t and inv(&"chest").has(&"item_a") and not inv(&"hero").has(&"item_a"), "no transfer at start")
	check(not ask(&"InventoryRemoveRequested", {"entity":&"chest", "item":&"item_a"}).get("accepted", true), "pending chest mutation blocked")
	check(not ask(&"EntityRemoveRequested", {"entity":&"chest"}).get("accepted", true), "pending chest deletion blocked")
	check(not ask(&"ActionInterruptRequested", {"entity":&"hero", "action":&"stagger", "force":true}).get("accepted", true) and ask(&"ActionGetRequested", {"entity":&"hero"})["data"]["id"] == &"chest_take", "stagger cannot interrupt transfer")
	check(driver.advance_steps(5) == 5 and inv(&"chest").has(&"item_a"), "not transferred midway")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save pending transfer")
	var file := FileAccess.open("user://session.save", FileAccess.READ)
	var saved: Dictionary = bytes_to_var(file.get_buffer(file.get_length()))
	file.close()
	var invalid: Dictionary = saved.duplicate(true)
	invalid["sections"]["chest_transfers"][&"hero"]["item"] = &"missing"
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(invalid))
	file.close()
	check(not ask(&"SessionLoadRequested", {}).get("accepted", true), "reject malformed pending transfer save")
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(saved))
	file.close()
	check(driver.advance_steps(5) == 5 and inv(&"hero").has(&"item_a") and not inv(&"chest").has(&"item_a") and state["completed"] == 1 and state["consistent"] and state["observed"] and not state["nested"] and not state["save"], "atomic transfer and guarded notifications at 0.1 seconds")
	check(ask(&"SessionLoadRequested", {}).get("accepted", false) and inv(&"chest").has(&"item_a") and not inv(&"hero").has(&"item_a"), "restore pending transfer")
	check(driver.advance_steps(5) == 5 and inv(&"hero").has(&"item_a") and state["completed"] == 2, "restored action completes")
	bus.unsubscribe(&"InventoryItemRemoved", observe)
	bus.unsubscribe(&"ComponentChanged", on_component)
	var b := {"entity":&"hero", "object":&"chest", "item":&"item_b"}
	check(ask(&"ChestTakeRequested", b.duplicate()).get("accepted", false), "start second")
	check(driver.advance_steps(5) == 5 and ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted", false), "cancel mid-transfer")
	check(inv(&"chest").has(&"item_b") and not inv(&"hero").has(&"item_b") and state["interrupt"] == 1, "cancel preserves item")
	check(ask(&"ChestTakeRequested", b.duplicate()).get("accepted", false) and driver.advance_steps(10) == 10 and inv(&"hero").has(&"item_b"), "take second item")
	var before: float = driver.game_time
	check(not ask(&"ChestTakeRequested", {"entity":&"hero", "object":&"chest", "item":&"item_c"}).get("accepted", true) and inv(&"chest").has(&"item_c") and driver.game_time == before, "capacity rejects without time")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":3}).get("accepted", false), "increase capacity")
	check(ask(&"ChestTakeRequested", {"entity":&"hero", "object":&"chest", "item":&"item_c"}).get("accepted", false), "start item c")
	check(ask(&"ItemGeometryModifiersSetRequested", {"item":&"item_c", "volume_modifier":2.0}).get("accepted", false), "change item volume during action")
	check(driver.advance_steps(10) == 10 and inv(&"chest").has(&"item_c") and not inv(&"hero").has(&"item_c"), "completion checks capacity and leaves item")
	check(ask(&"ItemGeometryModifiersSetRequested", {"item":&"item_c", "volume_modifier":1.0}).get("accepted", false), "restore item volume")
	check(ask(&"ChestTakeRequested", {"entity":&"hero", "object":&"chest", "item":&"item_c"}).get("accepted", false), "restart item c")
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":Vector2i(20,20)}).get("accepted", false), "move away")
	check(not ask(&"ActionGetRequested", {"entity":&"hero"}).get("found", false) and inv(&"chest").has(&"item_c"), "moving away cancels and keeps item")
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":Vector2i(10,10)}).get("accepted", false), "return to chest")
	check(ask(&"ChestTakeRequested", {"entity":&"hero", "object":&"chest", "item":&"item_c"}).get("accepted", false) and driver.advance_steps(10) == 10 and inv(&"chest").is_empty(), "empty chest through normal transfers")
	check(ask(&"ItemCreateRequested", {"id":&"spare_chest_item", "base_id":&"base_take", "item_level":1}).get("accepted", false), "new unattached item")
	check(not ask(&"InventoryAddRequested", {"entity":&"chest", "item":&"spare_chest_item"}).get("accepted", true) and inv(&"chest").is_empty(), "opened chest does not refill by inventory add")
	var altered: Dictionary = ask(&"InventoryGetRequested", {"entity":&"chest"})["data"]
	altered["items"].append(&"spare_chest_item")
	check(not ask(&"InventoryCommitRequested", {"entity":&"chest", "data":altered}).get("accepted", true) and inv(&"chest").is_empty(), "direct inventory commit cannot refill opened chest")
	check(not ask(&"ObjectRemoveRequested", {"object":&"chest"}).get("accepted", true) and not ask(&"EntityRemoveRequested", {"entity":&"chest"}).get("accepted", true) and ask(&"SpaceTileGetRequested", {"tile":Vector2i(14,11)}).get("obstacle", null) == &"chest", "empty chest persists and remains obstacle")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and inv(&"chest").is_empty() and ask(&"ObjectGetRequested", {"object":&"chest"})["data"]["opened"] and ask(&"SpaceTileGetRequested", {"tile":Vector2i(14,11)}).get("obstacle", null) == &"chest", "empty opened chest persists across save")
	var cleanup: Dictionary = root.get_node("SaveService").run_world_transition_transaction(func(): return root.get_node("ObjectGenerationService").discard_objects_for_transition().get("accepted", false))
	check(cleanup.get("committed", false) and not ask(&"ObjectGetRequested", {"object":&"chest"}).get("found", true) and ask(&"SpaceTileGetRequested", {"tile":Vector2i(14,11)}).get("obstacle", null) == null and inv(&"hero").size() == 3, "authorized transition removes empty chest and keeps player's loot")
	bus.unsubscribe(&"ChestTakeCompleted", completed)
	bus.unsubscribe(&"ChestTakeInterrupted", interrupted)
	print("Chest transfer tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
