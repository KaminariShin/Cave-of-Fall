extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(resource: StringName) -> float:
	return float(ask(&"ResourceGetRequested", {"entity":&"hero","resource":resource})["data"]["current"])
func set_value(resource: StringName,n: int) -> void:
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":resource,"value":n}).get("accepted",false),"set resource")
func start() -> bool: return ask(&"ShieldBlockStartRequested", {"entity":&"hero","slot":"off","direction":Vector2i.UP}).get("accepted",false)
func active() -> bool: return ask(&"ShieldBlockStatusRequested", {"entity":&"hero"}).get("active",false)
func hit(source: StringName, damage: int, x: int) -> Dictionary:
	return {"source":source,"target":&"hero","damage":damage,"attack_tiles":[Vector2i(x,9)]}
func apply(hp: int, stamina: int, hits: Array) -> Dictionary:
	return ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":hp},"hits":hits,"block":{"target":&"hero","direction":Vector2i.UP,"expected_stamina":stamina}})
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(40,40)}).get("accepted",false),"map")
	var floors: Array = []
	for x in range(40):
		for y in range(40): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"a",&"b",&"c"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"control and body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_medium","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false),"shield")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	set_value(&"HP",20); set_value(&"Stamina",4)
	check(start(),"block")
	var inputs := [hit(&"a",5,10),hit(&"b",7,11),hit(&"c",2,20)]
	var rng = root.get_node("RngService")._rng
	var rng_before: int = rng.state
	check(not apply(20,5,inputs).get("accepted",true) and value(&"HP") == 20 and value(&"Stamina") == 4 and active() and rng.state == rng_before,"stale stamina rejected")
	var deny := func(e):
		if e.get("entity",null) == &"hero": e["allowed"] = false
	bus.subscribe(&"CombatDamageAllowedRequested",deny)
	check(not apply(20,4,inputs).get("accepted",true) and value(&"HP") == 20 and value(&"Stamina") == 4 and rng.state == rng_before,"guard rejects before rolling")
	bus.unsubscribe(&"CombatDamageAllowedRequested",deny)
	var change_stamina := func(e):
		if e.get("entity",null) == &"hero" and e.get("active",false): ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":3})
	bus.subscribe(&"ShieldBlockStatusRequested",change_stamina)
	check(not apply(20,4,inputs).get("accepted",true) and value(&"HP") == 20 and value(&"Stamina") == 3 and rng.state == rng_before, "mutation during geometry rejected without own RNG use")
	bus.unsubscribe(&"ShieldBlockStatusRequested",change_stamina)
	set_value(&"Stamina",4)
	var observed := {"consistent":false,"reason":null}
	var interrupted := func(e):
		if e.get("entity",null) == &"hero":
			observed["consistent"] = value(&"HP") == 14 and value(&"Stamina") == 0
			observed["reason"] = e.get("reason",null)
	bus.subscribe(&"ShieldBlockInterrupted",interrupted)
	var q := apply(20,4,inputs)
	check(q.get("accepted",false),"batch accepted")
	if q.get("accepted",false): check(q["data"]["block"]["absorbed"] == 8 and q["data"]["block"]["stamina_cost"] == 4 and q["data"]["targets"][0]["total_damage"] == 6,"absorbed and unblocked damage combined")
	check(value(&"HP") == 14 and value(&"Stamina") == 0 and not active() and observed["consistent"] and observed["reason"] == &"shield_exhausted","atomic commit before interrupt")
	bus.unsubscribe(&"ShieldBlockInterrupted",interrupted)
	set_value(&"HP",20); set_value(&"Stamina",6)
	check(start(),"second block")
	q = apply(20,6,[hit(&"a",5,10),hit(&"b",7,11)])
	check(q.get("accepted",false) and value(&"HP") == 20 and value(&"Stamina") == 0 and active() and not q["data"]["block"]["block_interrupted"],"exact coverage keeps block")
	q = apply(20,0,[hit(&"c",2,20)])
	check(q.get("accepted",false) and value(&"HP") == 18 and active(),"nonintersecting hit is not blocked or interrupting")
	q = apply(18,0,[hit(&"c",2,10)])
	check(q.get("accepted",false) and value(&"HP") == 16 and not active(),"intersecting hit at zero interrupts")
	set_value(&"HP",20); set_value(&"Stamina",4)
	check(start(),"block repeated-source hits")
	var arrows: Array = [{"source":&"a","hit_id":&"projectile:1","target":&"hero","damage":5,"attack_tiles":[Vector2i(10,9)]},{"source":&"a","hit_id":&"projectile:2","target":&"hero","damage":7,"attack_tiles":[Vector2i(11,9)]}]
	var multi := ask(&"SimultaneousDamageApplyRequested", {"hp_by_target":{&"hero":20},"hits":arrows,"block":{"target":&"hero","direction":Vector2i.UP,"expected_stamina":4},"apply_stagger":true})
	check(multi.get("accepted",false) and value(&"HP")==16 and value(&"Stamina")==0 and multi.get("data",{}).get("block",{}).get("absorbed",0)==8,"shield distributes stamina across distinct hits of same source")
	check(not active(),"insufficient stamina interrupts block")
	check(root.get_node("SaveService").collect_world_transition_snapshot().get("valid",false),"snapshot after")
	print("Simultaneous shield apply tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
