extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11), "inventory_capacity":0.5}).get("accepted",false), "chest")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted",false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(10,10), "size":4}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"room"}).get("accepted",false), "control and place")
	var state := {"calls":0}
	var rng := func(e):
		state["calls"] += 1
		e["value"] = 700 if state["calls"] in [5,9,13,17] else e["min"]
	bus.subscribe(&"RngIntRequested",rng)
	var attached := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	bus.unsubscribe(&"RngIntRequested",rng)
	check(attached.get("accepted",false), "magic draft")
	if not attached.get("accepted",false): quit(1); return
	var slots: Array = attached["draft"]["slots"]
	var ids := [&"magic1",&"magic2",&"magic3",&"magic4"]
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var rejected := {"count":0}
	var deny_attach := func(e):
		rejected["count"] += 1
		if rejected["count"] == 2: e["allowed"] = false
	bus.subscribe(&"ItemModCanAttachRequested",deny_attach)
	var mod_fail := ask(&"ChestDraftMaterializeRequested", {"object":&"chest", "item_ids":ids})
	bus.unsubscribe(&"ItemModCanAttachRequested",deny_attach)
	check(not mod_fail.get("accepted",true) and mod_fail.get("rolled_back",false) and rejected["count"] == 2 and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "mod attach failure rolls back partially created item")
	var failed := ask(&"ChestDraftMaterializeRequested", {"object":&"chest", "item_ids":ids})
	check(not failed.get("accepted",true) and failed.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "capacity failure rolls back")
	check(ask(&"InventoryConfigureRequested", {"entity":&"chest", "volume":10}).get("accepted",false), "expand")
	before = saver.collect_world_transition_snapshot()
	var done := ask(&"ChestDraftMaterializeRequested", {"object":&"chest", "item_ids":ids})
	check(done.get("accepted",false), "magic materializes " + str(done))
	if not done.get("accepted",false): quit(1); return
	for i in range(4):
		var item: Dictionary = ask(&"ItemGetRequested", {"item":ids[i]})["item_data"]
		check(item["base_id"] == slots[i]["base_id"] and item["rarity"] == &"magic" and item["mods"] == slots[i]["mods"] and item["materials"] == slots[i]["materials"] and item["item_level"] == slots[i]["item_level"] and item["learning"] == slots[i]["learning"] and item["learning_state"] == {"progress":0,"identified":false}, "item matches plan %d" % i)
	var req := ask(&"ItemIdentificationRequirementCalculateRequested", {"rank":1, "item_level":slots[0]["item_level"]})
	check(req.get("accepted",false) and ask(&"ItemGetRequested", {"item":ids[0]})["item_data"]["int_req"] == req["value"], "magic rank used in identification requirement")
	check(before["payload"]["sections"]["rng"] == saver.collect_world_transition_snapshot()["payload"]["sections"]["rng"], "no reroll")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false), "save load")
	check(ask(&"ObjectInteractRequested", {"entity":&"hero", "object":&"chest"}).get("accepted",false) and driver.advance_steps(10) == 10, "open")
	check(ask(&"ChestTakeRequested", {"entity":&"hero", "object":&"chest", "item":ids[0]}).get("accepted",false) and driver.advance_steps(10) == 10, "take")
	var equip := ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":ids[0], "slot":"main"})
	check(equip.get("accepted",false) and driver.advance_steps(10)==10 and ask(&"ComponentGetRequested", {"entity":&"hero", "component":&"equipment"})["data"].get("main",null)==ids[0], "equip generated magic weapon")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	check(ask(&"ItemCreateRequested", {"id":&"guard_shield", "base_id":&"shield_small", "item_level":20, "rarity":&"magic", "learning":schema}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"guard_shield"}).get("accepted",false), "create guard shield")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"guard_shield", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "equip before unsupported mod")
	var unsupported: Dictionary = {"id":&"suf_physical_damage", "category":"suffix", "stat":"physical_damage", "material_id":&"iron_common", "tier":3, "level_req":1, "value":1, "unlock_after":15}
	check(not ask(&"ItemModAttachRequested", {"item":&"guard_shield", "mod":unsupported}).get("accepted",true), "unsupported mod rejected on equipped item")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "unequip shield")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"guard_shield", "slot":"off"}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"guard_shield", "mod":unsupported}).get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"ComponentGetRequested", {"entity":&"hero", "component":&"equipment"})["data"].get("off",null) == null, "recheck at action completion prevents late mod")
	check(ask(&"ObjectCreateRequested", {"entity":&"rare_chest", "type":"chest", "room":&"room", "tile":Vector2i(20,20), "inventory_capacity":10}).get("accepted",false), "rare chest")
	state["calls"] = 0
	var rare_rng := func(e):
		state["calls"] += 1
		e["value"] = 940 if state["calls"] in [5,9,13,17] else e["min"]
	bus.subscribe(&"RngIntRequested",rare_rng)
	var rare := ask(&"DungeonChestDraftAttachRequested", {"object":&"rare_chest", "kind":"boss", "depth":12})
	bus.unsubscribe(&"RngIntRequested",rare_rng)
	check(rare.get("accepted",false) and rare["draft"]["slots"][0]["rarity"] == &"rare", "rare plan")
	var rare_ids := [&"rare1",&"rare2",&"rare3",&"rare4"]
	var rare_before: Dictionary = saver.collect_world_transition_snapshot()
	var rare_done := ask(&"ChestDraftMaterializeRequested", {"object":&"rare_chest", "item_ids":rare_ids})
	check(rare_done.get("accepted",false), "rare materializes " + str(rare_done))
	if rare_done.get("accepted",false):
		var actual: Dictionary = ask(&"ItemGetRequested", {"item":rare_ids[0]})["item_data"]
		var plan: Dictionary = rare["draft"]["slots"][0]
		var rare_req := ask(&"ItemIdentificationRequirementCalculateRequested", {"rank":2,"item_level":plan["item_level"]})
		check(actual["rarity"] == &"rare" and actual["mods"] == plan["mods"] and actual["int_req"] == rare_req.get("value",null) and rare_before["payload"]["sections"]["rng"] == saver.collect_world_transition_snapshot()["payload"]["sections"]["rng"], "rare mods, rank and RNG")
	print("Magic chest materialization tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
