extends SceneTree
var failures := 0
var damage_events: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	bus.subscribe(&"EntityDamaged", func(e): damage_events.append(e.duplicate()))
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(30, 20)})["accepted"], "map")
	var floors: Array = []
	for x in range(30):
		for y in range(20): floors.append(Vector2i(x, y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})["accepted"], "floor")
	check(entities.create_entity(&"hero") and entities.create_entity(&"rat") and entities.create_entity(&"behind"), "entities")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(5, 5), "size": 2})["accepted"], "hero body")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"rat", "anchor": Vector2i(8, 5), "size": 2})["accepted"], "rat body")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"behind", "anchor": Vector2i(3, 5), "size": 2})["accepted"], "behind body")
	var common := {"entity": &"hero", "weapon_type": "sword", "direction": Vector2.RIGHT, "shape": {"type": "arc", "angle_degrees": 90, "radius": 10}}
	var zone := ask(bus, &"StrikeZoneGetRequested", common.duplicate(true))
	check(zone["accepted"] and zone["center"] == Vector2(6, 6), "center")
	check(is_equal_approx(zone["min_distance"], 2.7) and is_equal_approx(zone["max_distance"], 9.35), "band")
	check(not zone["tiles"].has(Vector2i(8, 5)) and zone["tiles"].has(Vector2i(9, 5)), "inner band and tile center")
	check(not zone["tiles"].has(Vector2i(2, 5)), "arc faces direction")
	var test := common.duplicate(true)
	test["target"] = &"rat"
	ask(bus, &"StrikeZoneBodyTestRequested", test)
	check(test["accepted"] and test["hit"] and test["hit_tiles"].has(Vector2i(9, 5)) and not test["hit_tiles"].has(Vector2i(8, 5)), "partial body intersection")
	for tile in test["hit_tiles"]:
		check(zone["tiles"].has(tile), "hit agrees with highlight")
	check(ask(bus, &"PipelineModifierRegisterRequested", {"entity": &"hero", "modifier": {"id": "bonus_damage", "target": "damage.outgoing", "stage": "additive", "op": "add", "value": 3}})["accepted"], "register damage bonus")
	var attack := common.duplicate(true)
	attack["amount"] = 7
	attack["targets"] = [&"rat", &"rat", &"behind", &"hero"]
	ask(bus, &"StrikeZoneDamageRequested", attack)
	check(attack["accepted"] and attack["hits"].size() == 1 and attack["hits"][0]["entity"] == &"rat" and attack["hits"][0]["applied"] == 10, "one pipeline damage per body")
	check(damage_events.size() == 1, "one damage event")
	var line := common.duplicate(true)
	line["shape"] = {"type": "line", "length": 8, "width": 1}
	ask(bus, &"StrikeZoneGetRequested", line)
	check(line["accepted"] and line["tiles"].has(Vector2i(9, 5)) and not line["tiles"].has(Vector2i(9, 4)), "line length and width")
	var cone := common.duplicate(true)
	cone["shape"] = {"type": "cone", "length": 4, "angle_degrees": 60}
	ask(bus, &"StrikeZoneGetRequested", cone)
	check(cone["accepted"] and cone["tiles"].has(Vector2i(9, 5)) and not cone["tiles"].has(Vector2i(10, 5)), "cone length and angle")
	var diameter := common.duplicate(true)
	diameter["shape"] = {"type": "arc", "diameter": 8, "angle_degrees": 60}
	ask(bus, &"StrikeZoneGetRequested", diameter)
	check(diameter["tiles"] == cone["tiles"], "diameter is twice radius")
	var invalid := common.duplicate(true)
	invalid["direction"] = Vector2.ZERO
	check(not ask(bus, &"StrikeZoneGetRequested", invalid)["accepted"], "zero direction rejected")
	invalid = common.duplicate(true)
	invalid.erase("shape")
	check(not ask(bus, &"StrikeZoneGetRequested", invalid)["accepted"], "undefined shape rejected")
	invalid = common.duplicate(true)
	invalid["shape"] = {"type": "arc", "angle_degrees": 0, "radius": 10}
	check(not ask(bus, &"StrikeZoneGetRequested", invalid)["accepted"], "invalid angle rejected")
	# Уберём крысу, затем поставим две стены перед новой позицией тела.
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"rat", "anchor": Vector2i(11, 5)})["accepted"], "move rat")
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": [Vector2i(8, 5), Vector2i(8, 6)], "kind": 0})["accepted"], "wall")
	var blocked := line.duplicate(true)
	blocked["target"] = &"rat"
	ask(bus, &"StrikeZoneBodyTestRequested", blocked)
	check(blocked["accepted"] and not blocked["hit"], "rock blocks LOS to body")
	var blocked_attack := line.duplicate(true)
	blocked_attack["targets"] = [&"rat"]
	blocked_attack["amount"] = 7
	ask(bus, &"StrikeZoneDamageRequested", blocked_attack)
	check(blocked_attack["accepted"] and blocked_attack["hits"].is_empty() and damage_events.size() == 1, "wall blocks actual damage")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "control hero")
	check(ask(bus, &"MovementConfigureRequested", {"entity": &"hero", "actor_type": "player", "K_move": 10})["accepted"], "configure movement")
	check(ask(bus, &"MovementStepRequested", {"entity": &"hero", "delta": Vector2i.UP})["accepted"], "move hero")
	root.get_node("TimeDriver").advance_steps(7)
	var moving_zone := ask(bus, &"StrikeZoneGetRequested", common.duplicate(true))
	check(moving_zone["accepted"] and is_equal_approx(moving_zone["center"].y, 6.0 - 7.0 / 15.0), "zone follows interpolated attacker")
	print("Strike zone tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
