extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func fits(anchor: Vector2i, floor: Dictionary) -> bool:
	for dx in range(4):
		for dy in range(4):
			if not floor.has(anchor + Vector2i(dx,dy)): return false
	return true
func can_walk(start: Vector2i, target: Vector2i, floor: Dictionary) -> bool:
	if not fits(start, floor) or not fits(target, floor): return false
	var seen := {start: true}
	var queue: Array = [start]
	var idx := 0
	while idx < queue.size():
		var p: Vector2i = queue[idx]
		idx += 1
		if p == target: return true
		for delta in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = p + delta
			if not seen.has(next) and fits(next, floor):
				seen[next] = true
				queue.append(next)
	return false
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"LevelGenerationRequested", {"level_id": &"test", "seed": 55, "size_cells": Vector2i(160,160)})["accepted"], "level")
	var rooms := [["start", Vector2i(5,5), Vector2i(11,11)], ["passage",Vector2i(30,5),Vector2i(12,12)], ["deadend",Vector2i(55,5),Vector2i(11,11)], ["fork",Vector2i(5,30),Vector2i(14,14)], ["crossroads",Vector2i(30,30),Vector2i(15,15)], ["corridor",Vector2i(55,30),Vector2i(10,5)]]
	for entry in rooms:
		var type: String = entry[0]
		var id := StringName("test_" + type)
		var origin: Vector2i = entry[1]
		var size: Vector2i = entry[2]
		check(ask(bus, &"RoomCreateRequested", {"id": id, "type": type, "origin_cell": origin, "size_cells": size})["accepted"], type + " create")
		var directions := ["north", "south", "west", "east"] if type != "corridor" else ["west", "east"]
		for direction in directions:
			var along := size.x if direction in ["north", "south"] else size.y
			check(ask(bus, &"RoomExitAddRequested", {"room": id, "id": StringName(direction), "dir": direction, "offset_cells": int(along / 2)})["accepted"], type + " exit " + direction)
		var room: Dictionary = ask(bus, &"RoomGetRequested", {"id": id})["data"]
		var floor: Dictionary = {}
		for tile in room["floor_tiles"]: floor[tile] = true
		var bounds := origin * 4
		var footprint_center := (origin + Vector2i(int(size.x / 2),int(size.y / 2))) * 4
		for exit in room["exits"]:
			var target := Vector2i(exit["x"], exit["y"])
			if exit["dirOut"] == "east": target.x = bounds.x + size.x * 4 - 4
			if exit["dirOut"] == "south": target.y = bounds.y + size.y * 4 - 4
			check(can_walk(footprint_center, target, floor), type + " 4x4 can reach " + str(exit["dirOut"]))
	print("Cave exit tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
