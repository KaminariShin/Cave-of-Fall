extends SceneTree
var failures := 0
var summons: Array = []
func _initialize() -> void: call_deferred("run_tests")
func check(v: bool, message: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",message)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name,data)
	return data
func base_type() -> Dictionary:
	return {"id":"unit", "type_weight":0.3, "species":{"id":"demo","species_weight":0.2}, "tags":[], "body_size":4, "min_depth":0, "max_depth":null, "base_stats":{"CON":5,"STR":5,"DEX":5,"INT":5,"WIS":5,"PER":5}, "growth_per_level":{"CON":0,"STR":0,"DEX":0,"INT":0,"WIS":0,"PER":0}}
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var spawn_service = root.get_node("SpawnService")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"AISummoned", func(e): summons.append(e.duplicate(true)))
	var demo: Dictionary = spawn_service._demo_pool[0].duplicate(true)
	demo["tag_options"] = spawn_service._demo_tag_options.duplicate(true)
	check(spawn_service._valid_mob(demo), "opt-in demo tag weights and probabilities are valid")
	var rat := base_type()
	rat["species"] = {"id":"rat", "species_weight":0.2, "small_tag_weight":0.3}
	check(spawn_service._valid_mob(rat), "rat needs explicit small tag weight")
	ask(bus,&"RngSeedRequested",{"seed":880})
	var count := 0
	for i in range(5000):
		var resolved: Dictionary = spawn_service._resolve_tags(rat)
		var small := false
		for t in resolved["tags"]:
			if t["id"] == "small": small = true
		check(resolved["body_size"] == (2 if small else 4), "rat body follows small tag")
		if small: count += 1
	check(count > 3750 and count < 4250, "rat small approximately 80 percent")
	var large_rat := rat.duplicate(true)
	large_rat["tags"] = [{"id":"large", "tag_weight":0.5}]
	var resolved_large: Dictionary = spawn_service._resolve_tags(large_rat)
	check(resolved_large["body_size"] == 6 and resolved_large["tags"].size() == 1, "forced large excludes automatic small")
	var bad := base_type()
	bad["tags"] = [{"id":"small","tag_weight":0.1},{"id":"large","tag_weight":0.1}]
	check(not spawn_service._valid_mob(bad), "large and small mutually exclusive")
	bad = base_type()
	bad["tag_options"] = [{"id":"small","tag_weight":0.1,"probability":0.5},{"id":"large","tag_weight":0.1,"probability":0.5}]
	check(not spawn_service._valid_mob(bad), "ambiguous independent size choices rejected")
	var optional := base_type()
	optional["tag_options"] = [{"id":"boss","tag_weight":0.4,"probability":1.0},{"id":"poisonous","tag_weight":0.6,"probability":0.0}]
	var chosen: Dictionary = spawn_service._resolve_tags(optional)
	check(chosen["tags"].size() == 1 and chosen["tags"][0]["id"] == "boss", "optional tags use per-type probability")
	check(ask(bus,&"SpaceMapConfigureRequested",{"size":Vector2i(100,100)})["accepted"],"map")
	check(ask(bus,&"RoomCreateRequested",{"id":&"r","type":"start","origin_cell":Vector2i(2,2),"size_cells":Vector2i(11,11)})["accepted"],"room")
	ask(bus,&"EntityCreateRequested",{"entity":&"hero"})
	ask(bus,&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(28,28),"size":4})
	ask(bus,&"ControlledEntityRequested",{"entity":&"hero"})
	ask(bus,&"RoomEnterRequested",{"entity":&"hero","room":&"r"})
	var hybrid := base_type()
	for name in ["boss","large","archer","summoner","poisonous"]: hybrid["tags"].append({"id":name,"tag_weight":0.1})
	hybrid["summoner_ai"] = {"wait_duration":0.05}
	ask(bus,&"RngSeedRequested",{"seed":42})
	var result := ask(bus,&"RoomSpawnRequested",{"room":&"r","player":&"hero","entry_tile":Vector2i(28,28),"depth":6,"pool":[hybrid],"queue_delay":0.05})
	check(result["accepted"] and result["units"].size() == 1,"tagged spawn " + str(result))
	if not result["accepted"] or result["units"].is_empty():
		quit(1)
		return
	var unit: Dictionary = result["units"][0]
	var id: StringName = unit["entity"]
	check(unit["body_size"] == 6 and unit["stats"]["CON"] == 9 and unit["stats"]["STR"] == 9 and unit["stats"]["DEX"] == 7, "boss plus large stats and size")
	check(is_equal_approx(unit["weight"],3.0) and unit["tags"].size() == 5,"all tag weights stack")
	var component: Dictionary = ask(bus,&"ComponentGetRequested",{"entity":id,"component":&"spawn"})["data"]
	check(component["required_weapon"] == "bow" and component["weapon_ready"] == false, "archer requirement marker, no fabricated bow")
	check(not component["summoner_ai_pending"] and ask(bus,&"AIGetRequested",{"entity":id})["found"], "summoner auto registers when wait supplied")
	var stat := ask(bus,&"StatGetRequested",{"entity":id,"stat":&"STR"})
	check(stat["base"] == 5 and stat["value"] == 9, "tag bonuses go through modifier pipeline")
	var hp: Dictionary = ask(bus,&"ResourceGetRequested",{"entity":id,"resource":&"HP"})["data"]
	check(hp["current"] == hp["max"], "new mob resources full after tag modifiers")
	check(ask(bus,&"SessionSaveRequested",{}).get("accepted",false), "save tags and AI")
	check(ask(bus,&"SessionLoadRequested",{}).get("accepted",false), "restore tags and AI")
	check(ask(bus,&"StatGetRequested",{"entity":id,"stat":&"STR"})["value"] == 9, "tag bonuses persist")
	# Explicitly detect target to exercise the existing 2-second summon action.
	ask(bus,&"AITargetSetRequested",{"entity":id,"target":&"hero","detected":true})
	check(ask(bus,&"ActionStartRequested",{"entity":&"hero","action":&"wait","duration":5.0})["accepted"],"advance time")
	driver.advance_steps(1)
	var action := ask(bus,&"ActionGetRequested",{"entity":id})
	check(action["found"] and action["data"]["id"] == &"ai_summon", "summoner begins action")
	var mana: float = ask(bus,&"ResourceGetRequested",{"entity":id,"resource":&"MP"})["data"]["current"]
	driver.advance_steps(200)
	check(not summons.is_empty() and summons[0]["entity"] == id, "summoner creates rat after two seconds")
	check(ask(bus,&"ResourceGetRequested",{"entity":id,"resource":&"MP"})["data"]["current"] == mana - 10, "summon costs 10 mana")
	check(ask(bus,&"RoomCreateRequested",{"id":&"r2","type":"start","origin_cell":Vector2i(13,2),"size_cells":Vector2i(11,11)})["accepted"],"second room")
	check(ask(bus,&"SpaceBodyRoomSetRequested",{"entity":&"hero","room":null})["accepted"],"clear room bounds")
	check(ask(bus,&"SpaceBodyMoveRequested",{"entity":&"hero","anchor":Vector2i(72,28)})["accepted"],"move to second room")
	check(ask(bus,&"RoomEnterRequested",{"entity":&"hero","room":&"r2"})["accepted"],"enter second room")
	var deferred := base_type()
	deferred["tags"] = [{"id":"summoner", "tag_weight":0.5}]
	ask(bus,&"RngSeedRequested",{"seed":42})
	var later := ask(bus,&"RoomSpawnRequested",{"room":&"r2","player":&"hero","entry_tile":Vector2i(72,28),"depth":6,"pool":[deferred]})
	check(later["accepted"] and later["units"].size() == 1,"spawn summoner without invented wait")
	if later["accepted"] and not later["units"].is_empty():
		var deferred_id: StringName = later["units"][0]["entity"]
		check(not ask(bus,&"AIGetRequested",{"entity":deferred_id})["found"] and ask(bus,&"ComponentGetRequested",{"entity":deferred_id,"component":&"spawn"})["data"]["summoner_ai_pending"],"missing AI settings are explicit")
		check(ask(bus,&"SpawnSummonerAIConfigureRequested",{"entity":deferred_id,"wait_duration":0.05})["accepted"],"configure delayed summoner AI")
		check(ask(bus,&"AIGetRequested",{"entity":deferred_id})["found"] and not ask(bus,&"ComponentGetRequested",{"entity":deferred_id,"component":&"spawn"})["data"]["summoner_ai_pending"],"pending marker cleared")
	print("Mob tag tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
