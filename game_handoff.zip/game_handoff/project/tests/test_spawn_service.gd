extends SceneTree
var failures := 0
var blocked_save := false
var nested_blocked := false
func _initialize() -> void: call_deferred("run_tests")
func check(condition: bool, text: String) -> void:
	if not condition:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, event: Dictionary) -> Dictionary:
	bus.publish(name, event)
	return event
func setup_world(bus, seed_value: int) -> void:
	var bodies := ask(bus, &"SpaceBodiesGetRequested", {})
	for id in bodies.get("bodies", {}): ask(bus, &"EntityRemoveRequested", {"entity": id})
	check(ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(100,100)})["accepted"], "map setup")
	check(ask(bus, &"RoomCreateRequested", {"id": &"r", "type": "start", "origin_cell": Vector2i(2,2), "size_cells": Vector2i(11,11)})["accepted"], "room setup")
	check(ask(bus, &"EntityCreateRequested", {"entity": &"hero"})["accepted"], "hero create")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(28,28), "size": 4})["accepted"], "hero place")
	ask(bus, &"RngSeedRequested", {"seed": seed_value})
func request(bus, extra: Dictionary = {}) -> Dictionary:
	var q := {"room": &"r", "player": &"hero", "entry_tile": Vector2i(28,28), "depth": 6, "demo_pool": true}
	q.merge(extra, true)
	return ask(bus, &"RoomSpawnRequested", q)
func tiny_floor(bus) -> void:
	var keep := {}
	for x in range(28,32):
		for y in range(28,32): keep[Vector2i(x,y)] = true
	for x in [23,24,26,27]:
		for y in [25,26]: keep[Vector2i(x,y)] = true
	var to_clear: Array = []
	for x in range(9,51):
		for y in range(9,51):
			if not keep.has(Vector2i(x,y)): to_clear.append(Vector2i(x,y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": to_clear, "kind": 0})["accepted"], "prepare sparse room")
func custom_mob(type_weight: float) -> Dictionary:
	return {"id": "custom", "type_weight": type_weight, "species": {"id": "s", "species_weight": 0.2}, "tags": [{"id": "tag", "tag_weight": 0.1}], "base_stats": {"CON": 10, "STR": 10, "DEX": 10, "INT": 10, "WIS": 10, "PER": 10}, "growth_per_level": {"CON": 2, "STR": 2, "DEX": 2, "INT": 2, "WIS": 2, "PER": 2}, "body_size": 2, "min_depth": 4, "max_depth": 9}
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var service = root.get_node("SpawnService")
	root.get_node("TimeDriver").set_process(false)
	setup_world(bus, 42)
	var nested_callback := func(e):
		if e.get("id", null) == &"r": nested_blocked = not request(bus)["accepted"]
	bus.subscribe(&"RoomGetRequested", nested_callback)
	var save_callback := func(e):
		if str(e.get("entity", "")).begins_with("spawn_"):
			blocked_save = not ask(bus, &"SessionSaveRequested", {}).get("accepted", false)
	bus.subscribe(&"EntityCreated", save_callback)
	var invalid := request(bus, {"entry_tile": Vector2i(20,20)})
	check(not invalid["accepted"], "player must cover entry")
	invalid = request(bus, {"demo_pool": false, "pool": [{"id": "broken"}]})
	check(not invalid["accepted"], "reject invalid pool")
	var spawn := request(bus)
	check(spawn["accepted"], "demo spawn " + str(spawn))
	check(spawn["level"] == 3 and spawn["budget"] >= 3 and spawn["budget"] <= 12, "depth formulas")
	check(not spawn["units"].is_empty(), "spawned example mobs")
	check(blocked_save, "save blocked during spawn")
	check(nested_blocked, "reentrant spawn is blocked before room lookup")
	bus.unsubscribe(&"RoomGetRequested", nested_callback)
	var paid := 0.0
	for unit in spawn["units"]:
		paid += unit["weight"]
		check(unit["weight"] == 3.0 and unit["stats"]["CON"] == 3.0 and unit["stats"]["PER"] == 13.0, "weight and per-level stat growth")
		check(unit["overload_requested"] is bool, "2 percent overload is a marker")
		check(ask(bus, &"DetectionPairGetRequested", {"observer": &"hero", "target": unit["entity"]})["hostile"], "spawned enemy is hostile to player")
		var hp: Dictionary = ask(bus, &"ResourceGetRequested", {"entity":unit["entity"], "resource":&"HP"})
		check(hp.get("found", false) and hp["data"]["current"] == 39.0 and hp["data"]["max"] == 39.0, "level-3 demo goblin surrogate retains HP growth")
		var body: Dictionary = ask(bus, &"SpaceBodyGetRequested", {"entity": unit["entity"]})["data"]
		check(body["anchor"] == unit["anchor"] and not Rect2i(body["anchor"], Vector2i.ONE * body["size"]).has_point(Vector2i(28,28)), "body placed away from entry tile")
	check(is_equal_approx(paid + spawn["remaining_budget"], spawn["budget"]), "budget conserved")
	check(not request(bus)["accepted"], "room spawned only once")
	check(ask(bus, &"SessionSaveRequested", {})["accepted"], "save spawn status")
	var file := FileAccess.open("user://session.save", FileAccess.READ)
	var snapshot: Dictionary = bytes_to_var(file.get_buffer(file.get_length()))
	file.close()
	var broken := snapshot.duplicate(true)
	broken["sections"]["spawn"]["rooms"][&"missing_room"] = true
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(broken))
	file.close()
	check(not ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "reject corrupted spawn room reference")
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(snapshot))
	file.close()
	check(ask(bus, &"SessionLoadRequested", {})["accepted"], "load spawn status")
	check(ask(bus, &"RoomSpawnStatusRequested", {"room": &"r"})["spawned"], "status persists")
	var first: Array = spawn["units"].duplicate(true)
	bus.unsubscribe(&"EntityCreated", save_callback)
	setup_world(bus, 42)
	var replay := request(bus)
	check(replay["accepted"] and replay["units"] == first and replay["budget"] == spawn["budget"], "same RNG seed and sequence reproduce spawn")
	setup_world(bus, 42)
	var level_one := request(bus, {"depth":2})
	check(level_one.get("accepted",false) and level_one.get("level",0) == 1 and not level_one.get("units",[]).is_empty(), "level-one demo goblin surrogate spawns")
	for unit in level_one.get("units",[]):
		var hp: Dictionary = ask(bus, &"ResourceGetRequested", {"entity":unit["entity"], "resource":&"HP"})
		check(hp.get("found",false) and hp["data"]["current"] == 30.0 and hp["data"]["max"] == 30.0, "initial goblin surrogate HP is 30")
	setup_world(bus, 13)
	var offset_failure := request(bus, {"offset_cells": Vector2i(200,200)})
	check(not offset_failure["accepted"] and not ask(bus, &"RoomSpawnStatusRequested", {"room": &"r"})["spawned"], "out-of-room offset cannot spawn and does not mark room")
	# Isolate greedy placement/degradation against actual physical floor and hero occupancy.
	var bounds := {"origin": Vector2i(8,8), "size": Vector2i(44,44)}
	var member := {"definition": {"body_size": 2}}
	var entry := Vector2i(28,28)
	var radius_anchors := [Vector2i(25,25)]
	check(service.call("_plan", [member], radius_anchors, bounds, entry, true, true).is_empty(), "radius blocks")
	check(service.call("_plan", [member], radius_anchors, bounds, entry, false, true).size() == 1, "radius can degrade")
	var gap_anchors := [Vector2i(10,10), Vector2i(12,10)]
	check(service.call("_plan", [member,member], gap_anchors, bounds, entry, true, true).size() == 1, "gap blocks second")
	check(service.call("_plan", [member,member], gap_anchors, bounds, entry, true, false).size() == 2, "gap can degrade")
	var both_anchors := [Vector2i(25,25), Vector2i(23,25)]
	check(service.call("_plan", [member,member], both_anchors, bounds, entry, true, false).is_empty(), "radius alone still blocks")
	check(service.call("_plan", [member,member], both_anchors, bounds, entry, false, true).size() == 1, "gap alone still blocks")
	check(service.call("_plan", [member,member], both_anchors, bounds, entry, false, false).size() == 2, "both conditions degrade")
	check(service.call("_plan", [member], [entry], bounds, entry, false, false).is_empty(), "entry tile prohibition never degrades")
	check(service.call("_plan", [member], [Vector2i(0,0)], bounds, entry, false, false).is_empty(), "bodyFits never degrades")
	setup_world(bus, 42)
	tiny_floor(bus)
	var tight := request(bus, {"demo_pool": false, "pool": [custom_mob(0.3)]})
	check(tight["accepted"] and tight["units"].size() == 2 and tight["degraded"] == ["entry_radius", "mob_gap"], "real spawn degrades both restrictions " + str(tight))
	if tight["accepted"] and not tight["units"].is_empty():
		check(is_equal_approx(tight["units"][0]["weight"], 1.8) and tight["units"][0]["stats"]["CON"] == 14, "custom type species tag weight and growth")
	setup_world(bus, 42)
	tiny_floor(bus)
	var no_space := request(bus, {"demo_pool": false, "pool": [custom_mob(0.1)]})
	check(not no_space["accepted"] and not ask(bus, &"RoomSpawnStatusRequested", {"room": &"r"})["spawned"], "all-or-nothing on insufficient space")
	check(ask(bus, &"SpaceBodiesGetRequested", {})["bodies"].size() == 1, "no partial mob bodies on failure")
	setup_world(bus, 23)
	var overloaded := request(bus)
	check(overloaded["accepted"] and overloaded["units"].size() >= 1 and overloaded["units"][0]["overload_requested"], "deterministic 2 percent marker")
	if overloaded["accepted"] and not overloaded["units"].is_empty():
		var spawn_component := ask(bus, &"ComponentGetRequested", {"entity": overloaded["units"][0]["entity"], "component": &"spawn"})
		check(spawn_component["data"]["overload_requested"], "overload marker stored on entity")
	setup_world(bus, 42)
	var shallow := request(bus, {"depth": 2, "demo_pool": false, "pool": [custom_mob(0.3)]})
	check(shallow["accepted"] and shallow["units"].is_empty(), "pool filtered by depth")
	setup_world(bus, 42)
	var expensive := custom_mob(20.0)
	expensive["id"] = "too_expensive"
	var affordable := request(bus, {"demo_pool": false, "pool": [expensive, custom_mob(0.3)]})
	check(affordable["accepted"] and not affordable["units"].is_empty() and affordable["units"][0]["type_id"] == "custom", "select affordable mob instead of expensive")
	setup_world(bus, 42)
	var fractional := request(bus, {"depth": 5.8, "demo_pool": false, "pool": [custom_mob(0.3)]})
	check(fractional["accepted"] and fractional["level"] == 2 and fractional["budget"] >= 2.9 and fractional["budget"] <= 11.6, "fractional depth affects spawn")
	setup_world(bus, 42)
	var small_rat := custom_mob(1.0)
	small_rat["species"] = {"id":"rat", "species_weight":0.0, "small_tag_weight":-0.5}
	small_rat["tags"] = []
	var negative := request(bus, {"demo_pool":false, "pool":[small_rat]})
	check(negative["accepted"] and not negative["units"].is_empty(), "negative small-tag weight accepted")
	for unit in negative.get("units", []):
		check(is_equal_approx(float(unit["weight"]), 1.5) or is_equal_approx(float(unit["weight"]), 3.0), "rat weight uses small tag")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save negative tags")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load negative tags")
	print("Spawn tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
