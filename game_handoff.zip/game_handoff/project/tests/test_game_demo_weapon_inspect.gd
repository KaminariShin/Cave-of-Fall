extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func key(game: Node, k: Key) -> void:
	var e := InputEventKey.new(); e.keycode=k; e.pressed=true; game._unhandled_key_input(e)
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver"); driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate(); root.add_child(game); await process_frame
	game.size=Vector2(1280,720)
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"setup")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":100}).get("accepted",false),"capacity")
	for spec in [[&"inspect_sword",&"sword_simple","demo_player_sword_thrust",15,"линия"],[&"inspect_hammer",&"hammer_simple","demo_player_hammer_slam",12,"дуга"],[&"inspect_bow",&"bow_simple","bow_simple_shot",7,"Дальность стрелы"]]:
		var id: StringName=spec[0]
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":spec[1],"item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"create "+str(id))
		var txt: String=" | ".join(game._inspection_lines(id))
		var cost: Dictionary=ask(&"WeaponStrikeStaminaPreviewRequested",{"entity":game.HERO,"item":id,"strike":spec[2]})
		var damage: Dictionary=ask(&"BowShotDamagePreviewRequested" if spec[1]==&"bow_simple" else &"WeaponStrikeDamagePreviewRequested",{"entity":game.HERO,"item":id,"strike":spec[2]})
		check(txt.contains("Базовый урон: "+str(spec[3])) and txt.contains(spec[4]),"actual strike "+str(id))
		check(cost.get("accepted",false) and txt.contains("Полная стоимость: "+str(cost.get("data",{}).get("full_cost","?"))),"stamina "+str(id))
		check(damage.get("accepted",false) and txt.contains("Расчёт урона: %.2f" % float(damage.get("data",{}).get("nonnegative_damage",-1))),"damage "+str(id))
		check(txt.contains("текущим статам") and not txt.contains("крысы"),"inventory caveat "+str(id))
		if spec[1]==&"sword_simple" or spec[1]==&"hammer_simple": check(txt.contains("Зона: от 0.0 до 5.0"),"updated displayed melee zone")
		if spec[1]==&"bow_simple": check(txt.contains("Дальность стрелы: 16.0"),"updated displayed flight distance")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"inventory open")
	var idx:int=game._inventory_items().find(&"inspect_bow")
	check(game._use_inventory_item(idx) and driver.advance_steps(10)==10 and game._twohand_continue() and driver.advance_steps(10)==10,"equip bow")
	var equipped:String=" | ".join(game._inspection_lines(&"inspect_bow"))
	check(equipped.contains("двуручное") and not equipped.contains("текущим статам"),"equipped bow")
	game.inspect_mode=true; game.inspect_item=&"inspect_bow"; game.inspect_page=0
	game.queue_redraw(); await process_frame
	check(game.inspect_page==0,"draw inspection")
	# Force enough content for pagination and check actual keyboard and mouse input.
	var bases:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema:Dictionary=root.get_node("DungeonChestLearningService").schema_for(&"sword_simple",bases)
	check(ask(&"ItemCreateRequested",{"id":&"inspect_magic_sword","base_id":&"sword_simple","item_level":1,"rarity":&"magic","learning":schema}).get("accepted",false),"magic item")
	var mod := {"id":&"suf_physical_damage","category":"suffix","stat":"physical_damage","tier":3,"value":1.0,"level_req":1,"material_id":&"iron_common","unlock_after":5}
	check(ask(&"ItemModAttachRequested",{"item":&"inspect_magic_sword","mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":&"inspect_magic_sword"}).get("accepted",false),"hidden mod")
	var hidden_damage: Dictionary=ask(&"WeaponStrikeDamagePreviewRequested",{"entity":game.HERO,"item":&"inspect_magic_sword","strike":"demo_player_sword_thrust"})
	check(hidden_damage.get("accepted",false) and is_zero_approx(float(hidden_damage.get("data",{}).get("physical_mod_bonus",-1))),"hidden damage bonus inactive")
	var hidden:String=" | ".join(game._inspection_lines(&"inspect_magic_sword"))
	check(not hidden.contains("Физический урон: +1") and not hidden.contains("suf_physical_damage"),"hidden mod remains hidden")
	game.inspect_item=&"inspect_magic_sword";game.inspect_page=0;game.queue_redraw();await process_frame
	if game._inspection_lines(game.inspect_item).size()>13:
		key(game,KEY_RIGHT); check(game.inspect_page==1,"keyboard page forward")
		var click:=InputEventMouseButton.new();click.position=game.get_global_transform_with_canvas()*(game._inventory_rect().position+Vector2(40,389));click.button_index=MOUSE_BUTTON_LEFT;click.pressed=true;game._input(click)
		check(game.inspect_page==0,"mouse page back")
	else: check(false,"fixture has multiple pages")
	game.queue_free(); await process_frame
	print("Weapon inspection: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
