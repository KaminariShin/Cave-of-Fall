extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func preview(id: StringName, level: int) -> Dictionary:
	return ask(&"DungeonChestEquipmentMaterialsPreviewRequested", {"base_id":id, "item_level":level})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var expected := ["iron_common", "iron_common", "steel_common", "steel_common", "steel_tempered", "steel_tempered"]
	var leather := ["leather_thin", "leather_thin", "leather_hardened", "leather_hardened", "leather_scale", "leather_scale"]
	for i in range(6):
		var result := preview(&"sword_simple", i+1)
		check(result.get("accepted",false) and result.get("materials",[]) == [{"material_id":expected[i],"count":3},{"material_id":leather[i],"count":1}], "sword materials level %d" % (i+1))
	var cloth := preview(&"armor_cloth_body", 5)
	check(cloth.get("materials",[]) == [{"material_id":"cloth_runic","count":8}] and cloth.get("material_level",0) == 5, "cloth level 5")
	for base in [&"sword_simple", &"staff_simple", &"bow_simple", &"hammer_simple", &"shield_small", &"shield_medium", &"shield_large", &"armor_cloth_body", &"armor_leather_body", &"armor_iron_body"]:
		for level in [1,3,5]: check(preview(base, level).get("accepted",false), "each pool equipment resolves")
	check(not preview(&"potion_hp", 1).get("accepted",true) and not preview(&"unknown",1).get("accepted",true) and not preview(&"sword_simple",0).get("accepted",true), "invalid input rejected")
	check(not ask(&"DungeonChestEquipmentMaterialsPreviewRequested", {"base_id":&"sword_simple", "item_level":1.0}).get("accepted",true), "fractional type rejected")
	var service = root.get_node("DungeonChestMaterialsService")
	var original: Dictionary = service._families.duplicate(true)
	service._families["iron_common"][1] = "missing"
	check(not preview(&"sword_simple",3).get("accepted",true), "missing mapped material rejects")
	service._families["iron_common"][1] = "iron_common"
	check(not preview(&"sword_simple",3).get("accepted",true), "wrong material tier rejects")
	service._families = original
	var after: Dictionary = saver.collect_world_transition_snapshot()
	check(before.get("valid",false) and after.get("valid",false) and before["payload"]["sections"] == after["payload"]["sections"], "no RNG or world changes")
	check(ask(&"SessionSaveRequested", {}).get("accepted",false) and ask(&"SessionLoadRequested", {}).get("accepted",false) and preview(&"sword_simple",5).get("materials",[]) == [{"material_id":"steel_tempered","count":3},{"material_id":"leather_scale","count":1}], "save load")
	print("Chest material preview tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
