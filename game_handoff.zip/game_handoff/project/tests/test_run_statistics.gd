extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func stats() -> Dictionary:
	return ask(&"RunStatisticsGetRequested", {}).get("data", {})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(120,80)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"start", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted", false), "start room")
	check(ask(&"RoomCreateRequested", {"id":&"next", "type":"start", "origin_cell":Vector2i(12,1), "size_cells":Vector2i(11,11)}).get("accepted", false), "next room")
	check(ask(&"RoomExitAddRequested", {"room":&"start", "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false), "east exit")
	check(ask(&"RoomExitAddRequested", {"room":&"next", "id":&"west", "dir":"west", "offset_cells":5}).get("accepted", false), "west exit")
	check(ask(&"RoomExitConnectRequested", {"room":&"start", "exit":&"east", "other_room":&"next", "other_exit":&"west"}).get("accepted", false), "connect rooms")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(10,10), "size":4}).get("accepted", false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control")
	check(ask(&"RunStatisticsStartRequested", {"entity":&"hero", "start_room":&"start"}).get("accepted", false), "start stats")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"start"}).get("accepted", false), "enter start")
	check(stats().get("rooms", -1) == 1 and is_equal_approx(float(stats().get("depth", 0)), 1.0), "start counts and depth one")
	check(ask(&"SpaceBodyRoomSetRequested", {"entity":&"hero", "room":null}).get("accepted", false), "clear room boundary")
	check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero", "anchor":Vector2i(52,10)}).get("accepted", false), "move to next")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"next"}).get("accepted", false), "enter next")
	check(stats().get("rooms", 0) == 2 and is_equal_approx(float(stats().get("depth", 0)), 1.2), "distance and fractional depth")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"next"}).get("accepted", false) and stats()["rooms"] == 2, "repeat visits not double counted")
	check(ask(&"EntityCreateRequested", {"entity":&"victim"}).get("accepted", false), "victim")
	check(ask(&"CombatDamageRequested", {"entity":&"victim", "source":&"hero", "amount":999}).get("accepted", false), "kill by player")
	check(stats()["kills"] == 1, "kill counted")
	check(ask(&"EntityCreateRequested", {"entity":&"other_victim"}).get("accepted", false), "other victim")
	check(ask(&"CombatDamageRequested", {"entity":&"other_victim", "source":&"enemy", "amount":999}).get("accepted", false) and stats()["kills"] == 1, "other kill excluded")
	check(stats()["stats"].get("CON", null) == 5 and stats()["level"] == null, "effective stats, unavailable level explicit")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save statistics")
	check(not ask(&"RunStatisticsFloorBeginRequested", {"floor":3, "start_room":&"start"}).get("accepted", false), "reject skip floor")
	check(ask(&"RunStatisticsFloorBeginRequested", {"floor":2, "start_room":&"start"}).get("accepted", false), "begin floor 2 manually")
	# Симулируем вход в комнату с тем же ID: счётчик разделён по этажам.
	ask(&"PlayerRoomChanged", {"entity":&"hero", "room":&"start"})
	check(stats()["rooms"] == 3 and stats()["depth"] == 2.0, "same room id on next floor counted separately")
	check(ask(&"SessionLoadRequested", {}).get("accepted", false), "load statistics")
	check(stats()["rooms"] == 2 and stats()["floor"] == 1 and stats()["kills"] == 1 and is_equal_approx(stats()["depth"], 1.2), "restored stats")
	check(ask(&"CombatDamageRequested", {"entity":&"hero", "source":&"enemy", "amount":999}).get("accepted", false), "hero death")
	var final := stats()
	check(final["finished"] and final["outcome"] == "death" and final["kills"] == 1 and final["stats"].get("CON", null) == 5, "death freezes final stats")
	check(not ask(&"SessionSaveRequested", {}).get("accepted", false), "no saving dead session")
	print("Run statistics tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
