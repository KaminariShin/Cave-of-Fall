extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func bfs(start: Vector2i, cells: Dictionary) -> Dictionary:
	var found := {start: true}
	var queue: Array = [start]
	var i := 0
	while i < queue.size():
		var p: Vector2i = queue[i]
		i += 1
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var q: Vector2i = p + d
			if cells.has(q) and not found.has(q):
				found[q] = true
				queue.append(q)
	return found
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var sizes := {"start": Vector2i(11,11), "passage": Vector2i(12,12), "deadend": Vector2i(11,11), "fork": Vector2i(14,14), "crossroads": Vector2i(15,15), "corridor": Vector2i(10,5)}
	for type in sizes:
		var req := {"id": StringName(type), "type": type, "origin": Vector2i(10,10), "size": sizes[type], "seed": 123, "entry_dir": "west"}
		var a := ask(bus, &"CaveGeometryBuildRequested", req.duplicate(true))
		var b := ask(bus, &"CaveGeometryBuildRequested", req.duplicate(true))
		check(a["accepted"] and a["cells"] == b["cells"] and not a["cells"].is_empty(), type + " deterministic")
		var cells: Dictionary = {}
		for c in a["cells"]:
			check(c.x > 0 and c.y > 0 and c.x < sizes[type].x - 1 and c.y < sizes[type].y - 1, type + " perimeter intact")
			cells[c] = true
		check(bfs(a["cells"][0], cells).size() == cells.size(), type + " logical cells connected")
		check(cells.size() < (sizes[type].x - 2) * (sizes[type].y - 2), type + " non-rectangular")
	ask(bus, &"RngSeedRequested", {"seed": 456})
	var expected: float = ask(bus, &"RngFloatRequested", {})["value"]
	ask(bus, &"RngSeedRequested", {"seed": 456})
	ask(bus, &"CaveGeometryBuildRequested", {"id": &"local", "type": "start", "origin": Vector2i.ZERO, "size": Vector2i(11,11), "seed": 123})
	check(ask(bus, &"RngFloatRequested", {})["value"] == expected, "geometry uses independent deterministic room RNG")
	var crossing := ask(bus, &"CaveGeometryBuildRequested", {"id": &"crossroads", "type": "crossroads", "origin": Vector2i.ZERO, "size": Vector2i(15,15), "seed": 9})
	for point in [Vector2i(7,1), Vector2i(13,7), Vector2i(7,13), Vector2i(1,7)]:
		check(crossing["cells"].has(point), "crossroads arm reaches " + str(point))
	var fork := ask(bus, &"CaveGeometryBuildRequested", {"id": &"fork", "type": "fork", "origin": Vector2i.ZERO, "size": Vector2i(14,14), "seed": 8, "entry_dir": "west"})
	check(fork["cells"].has(Vector2i(7,1)) and fork["cells"].has(Vector2i(12,7)) and not fork["cells"].has(Vector2i(12,1)), "fork arms with rock wedge")
	var level := ask(bus, &"LevelGenerationRequested", {"level_id": &"guard", "seed": 3, "size_cells": Vector2i(96,96)})
	check(level["accepted"], "level for guard")
	check(ask(bus, &"RoomCreateRequested", {"id": &"tunnel", "type": "corridor", "origin_cell": Vector2i(10,20), "size_cells": Vector2i(8,5)})["accepted"], "corridor")
	var tunnel: Dictionary = ask(bus, &"RoomGetRequested", {"id": &"tunnel"})["data"]
	check(tunnel["guards"].size() == 2 and tunnel["guards"][0]["size"] == Vector2i(6,9), "two 9 by 6 guard boxes")
	check(not ask(bus, &"RoomCreateRequested", {"id": &"blocked", "type": "passage", "origin_cell": Vector2i(19,19), "size_cells": Vector2i(12,12)})["accepted"], "unrelated room cannot overlap end guard")
	check(ask(bus, &"RoomCreateRequested", {"id": &"far", "type": "passage", "origin_cell": Vector2i(25,20), "size_cells": Vector2i(12,12)})["accepted"], "unrelated room outside guard allowed")
	check(ask(bus, &"RoomCreateRequested", {"id": &"tunnel2", "type": "corridor", "origin_cell": Vector2i(10,60), "size_cells": Vector2i(8,5)})["accepted"], "second corridor")
	check(ask(bus, &"RoomExitAddRequested", {"room": &"tunnel2", "id": &"east", "dir": "east", "offset_cells": 2})["accepted"], "corridor exit")
	var child := ask(bus, &"RoomChildGenerateRequested", {"room": &"tunnel2", "exit": &"east"})
	check(child["accepted"], "connected child allowed to overlap its parent guard")
	var start: Dictionary = ask(bus, &"RoomGetRequested", {"id": &"start"})["data"]
	var origin: Vector2i = start["origin_cell"] * 4
	check(ask(bus, &"RoomExitAddRequested", {"room": &"start", "id": &"west", "dir": "west", "offset_cells": 5})["accepted"], "second start exit")
	var wall: Array = []
	for y in range(origin.y + 1, origin.y + 43): wall.append(Vector2i(origin.x + 21, y))
	check(ask(bus, &"SpaceTilesSetRequested", {"tiles": wall, "kind": 0})["accepted"], "wall across room including center")
	check(ask(bus, &"RoomConnectivityRepairRequested", {"room": &"start"})["accepted"], "repair blocked exits with deterministic L corridor")
	start = ask(bus, &"RoomGetRequested", {"id": &"start"})["data"]
	var floor: Dictionary = {}
	for tile in start["floor_tiles"]: floor[tile] = true
	check(bfs(start["exits"][0]["tiles"][0], floor).size() == floor.size(), "all physical floor tiles connected after repair")
	for ex in start["exits"]:
		for tile in ex["tiles"]: check(floor.has(tile), "exit reachable after repair")
	var reopened := false
	for tile in wall:
		if floor.has(tile): reopened = true
	check(reopened, "L repair reopens barrier")
	for x in range(44):
		for y in range(44):
			if x != 0 and y != 0 and x != 43 and y != 43: continue
			var tile := origin + Vector2i(x,y)
			var is_exit := false
			for ex in start["exits"]:
				if ex["tiles"].has(tile): is_exit = true
			check(floor.has(tile) == is_exit, "perimeter floor only at exits")
	print("Cave geometry tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
