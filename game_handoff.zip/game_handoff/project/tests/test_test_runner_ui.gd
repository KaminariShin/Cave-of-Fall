extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var ui = load("res://test_runner.tscn").instantiate()
	root.add_child(ui)
	check(ui.names.has("test_accumulator.gd"), "UI discovers tests")
	var index: int = ui.names.find("test_accumulator.gd")
	ui.list.select(index)
	ui.selected_button.emit_signal("pressed")
	var summary: Dictionary = await ui.service.run_finished
	check(summary["passed"] == 1 and summary["total"] == 1, "UI selected run")
	check(ui.list.get_item_text(index).contains("PASS"), "UI result list")
	check(ui.status.text.contains("Завершено") and not ui.open_button.disabled, "UI summary")
	check(ui.output.text.contains("Accumulator tests: PASS"), "UI result log")
	ui.queue_free()
	print("Test runner UI tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
