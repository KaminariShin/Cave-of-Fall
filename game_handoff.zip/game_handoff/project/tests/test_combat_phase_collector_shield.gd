extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value(id: StringName,r: StringName) -> int: return int(ask(&"ResourceGetRequested", {"entity":id,"resource":r})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,30)}).get("accepted",false),"map")
	var floors := []
	for x in range(30):
		for y in range(30): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":&"npc","anchor":Vector2i(10,10),"size":4}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":100}).get("accepted",false) and ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_medium","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and driver.wait_for(0.1) and driver.advance_steps(10) == 10,"equip")
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"Stamina","value":0}).get("accepted",false) and ask(&"ShieldBlockStartRequested", {"entity":&"npc","slot":"off","direction":Vector2i.UP}).get("accepted",false) and driver.wait_for(0.5),"block")
	var seen := {"hit":false,"block":false,"resolved":false,"hp_before":0,"hp_after":0,"interrupted":0}
	var phase := func(_e):
		var status := ask(&"ShieldBlockStatusRequested", {"entity":&"npc"})
		if status.get("active",false) and status.get("ending",false):
			seen["hp_before"] = value(&"npc",&"HP")
			var stamina := value(&"npc",&"Stamina")
			seen["block"] = ask(&"CombatPhaseBlockSubmitRequested", {"target":&"npc","direction":Vector2i.UP,"expected_stamina":stamina}).get("accepted",false)
			seen["hit"] = ask(&"CombatPhaseHitSubmitRequested", {"source":&"hero","target":&"npc","damage":stamina*2+1,"magical_damage":1,"hp_before":seen["hp_before"],"attack_tiles":[Vector2i(10,9)]}).get("accepted",false)
	var batch := func(e):
		seen["resolved"] = e.get("accepted",false) and e.get("hit_count",0) == 1 and e.get("block_count",0) == 1
		seen["hp_after"] = value(&"npc",&"HP")
	var interrupted := func(e):
		if e.get("entity",null) == &"npc" and e.get("reason",null) == &"shield_exhausted": seen["interrupted"] += 1
	bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"ShieldBlockInterrupted",interrupted)
	check(driver.advance_steps(50) == 50 and seen["block"] and seen["hit"] and seen["resolved"] and seen["hp_after"] == seen["hp_before"]-2 and seen["interrupted"] == 1,"collector submits mixed hit and ending shield into one batch")
	bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"ShieldBlockInterrupted",interrupted)
	print("Combat phase collector shield tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
