extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func value_hp(id: StringName) -> float: return float(ask(&"ResourceGetRequested", {"entity":id,"resource":&"HP"})["data"]["current"])
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floor_tiles: Array = []
	for x in range(30):
		for y in range(20): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false),"floor")
	for id in [&"hero",&"npc"]: check(ask(&"EntityCreateRequested", {"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false),"control")
	for row in [[&"hero",Vector2i(5,5)],[&"npc",Vector2i(10,5)]]:
		check(ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false),"body")
		check(ask(&"InventoryConfigureRequested", {"entity":row[0],"volume":100}).get("accepted",false),"inventory")
		var item := StringName(str(row[0])+"_sword")
		check(ask(&"ItemCreateRequested", {"id":item,"base_id":&"sword_simple","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":row[0],"item":item}).get("accepted",false),"item")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"npc_sword","slot":"main"}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"hero_sword","slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10,"equip")
	for actor in [&"hero",&"npc"]: check(ask(&"StatBaseSetRequested", {"entity":actor,"stat":&"CON","value":100}).get("accepted",false),"high HP")
	for actor in [&"hero",&"npc"]: check(ask(&"ResourceSetRequested", {"entity":actor,"resource":&"Stamina","value":7}).get("accepted",false),"stamina")
	var npc := ask(&"WeaponStrikeStartRequested", {"entity":&"npc","item":&"npc_sword","strike":"sword_simple_thrust","direction":Vector2.LEFT})
	var hero := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"hero_sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(npc.get("accepted",false) and hero.get("accepted",false) and npc["data"]["duration_steps"] == hero["data"]["duration_steps"],"two synchronous strikes")
	if not npc.get("accepted",false) or not hero.get("accepted",false): quit(1); return
	var midpoint := ceili(float(hero["data"]["duration_steps"])/2.0)
	var bus = root.get_node("EventBus")
	var state := {"early":false,"npc":false,"duplicate":false,"hits":false,"batch":false,"order":true,"resolved":0,"old_hero":0,"old_npc":0}
	var pre_tick := func(_e):
		if driver._action_elapsed_steps == midpoint:
			var q := ask(&"ActionInterruptRequested", {"entity":&"hero","action":&"stagger","duration":0.2})
			state["early"] = q.get("accepted",false) and q.get("deferred",false)
			state["duplicate"] = not ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",true)
	var tick := func(_e):
		if driver._action_elapsed_steps == midpoint:
			var q := ask(&"ActionCancelRequested", {"entity":&"npc","reason":&"test"})
			state["npc"] = q.get("accepted",false) and q.get("deferred",false)
	var phase := func(e):
		if e.get("actions",[]).size() == 2:
			state["old_hero"] = value_hp(&"hero")
			state["old_npc"] = value_hp(&"npc")
			var q := ask(&"WeaponStrikePhaseAutoSubmitRequested",{})
			state["hits"] = q.get("accepted",false) and q["data"]["hit_count"] == 2
	var batch := func(e): state["batch"] = e.get("accepted",false) and e.get("hit_count",0) == 2
	var resolved := func(e):
		state["resolved"] += 1
		state["order"] = state["order"] and state["batch"] and e.get("applied",false) and value_hp(&"hero") < state["old_hero"] and value_hp(&"npc") < state["old_npc"]
	bus.subscribe(&"TimeProcessesTick",pre_tick); bus.subscribe(&"Tick",tick); bus.subscribe(&"TimeCombatPhase",phase); bus.subscribe(&"CombatPhaseBatchResolved",batch); bus.subscribe(&"WeaponStrikeDeferredInterruptionResolved",resolved)
	check(driver.advance_steps(midpoint) == midpoint and state["early"] and state["npc"] and state["duplicate"] and state["hits"] and state["batch"] and state["resolved"] == 2 and state["order"] and ask(&"ActionGetRequested", {"entity":&"hero"}).get("data",{}).get("id",null) == &"stagger" and not ask(&"ActionGetRequested", {"entity":&"npc"}).get("found",true),"ordinary requests defer before and after tick until both hits commit")
	bus.unsubscribe(&"TimeProcessesTick",pre_tick); bus.unsubscribe(&"Tick",tick); bus.unsubscribe(&"TimeCombatPhase",phase); bus.unsubscribe(&"CombatPhaseBatchResolved",batch); bus.unsubscribe(&"WeaponStrikeDeferredInterruptionResolved",resolved)
	check(driver.advance_steps(20) == 20, "finish replacement stagger")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":7}).get("accepted",false),"refill")
	check(ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"hero_sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT}).get("accepted",false),"new strike")
	var early := {"ok":false}
	var cancel_early := func(_e):
		var q := ask(&"ActionCancelRequested", {"entity":&"hero","reason":&"test"})
		early["ok"] = q.get("accepted",false) and not q.get("deferred",false)
	bus.subscribe(&"TimeProcessesTick",cancel_early)
	check(driver.advance_steps(1) == 1 and early["ok"] and not ask(&"ActionGetRequested", {"entity":&"hero"}).get("found",true),"early interruption stays immediate")
	bus.unsubscribe(&"TimeProcessesTick",cancel_early)
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":7}).get("accepted",false),"refill again")
	var last := ask(&"WeaponStrikeStartRequested", {"entity":&"hero","item":&"hero_sword","strike":"sword_simple_thrust","direction":Vector2.RIGHT})
	check(last.get("accepted",false) and driver.advance_steps(ceili(float(last["data"]["duration_steps"])/2.0)) > 0,"advance past midpoint")
	var cancelled := ask(&"ActionCancelRequested", {"entity":&"hero","reason":&"after_hit"})
	check(cancelled.get("accepted",false) and not cancelled.get("deferred",false) and not ask(&"ActionGetRequested", {"entity":&"hero"}).get("found",true) and ask(&"SessionSaveRequested",{}).get("accepted",false),"post-midpoint cancellation immediate and queue cleared")
	print("Weapon strike midpoint interruption tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
