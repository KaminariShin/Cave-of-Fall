extends SceneTree
var failures := 0
var generated: Array = []
func _initialize() -> void: call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	bus.subscribe(&"LevelGenerated", func(e): generated.append(e.duplicate(true)))
	var level := ask(bus, &"LevelGenerationRequested", {"level_id": &"cave", "seed": 44, "size_cells": Vector2i(96,96), "deadend_budget": 1})
	check(level["accepted"], "level generation: " + str(level))
	if not level["accepted"]:
		quit(1)
		return
	check(generated.size() == 1 and generated[0]["level_id"] == &"cave", "level generated event")
	var data: Dictionary = level["map_data"]
	check(data["rooms"].size() == 1 and data["rooms"].has(&"start"), "only start initially")
	var start: Dictionary = data["rooms"][&"start"]
	check(start["generated_cave"] and start["size_cells"] == Vector2i(11,11) and not start["floor_list"].is_empty(), "logical cave floors")
	check(start["exits"].size() == 1 and not start["exits"][0]["connected"], "exit is lazy")
	check(start["rect"]["position"] == start["origin_cell"] and start["floorList"] == start["floor_list"], "logical room rect and floorList exported")
	check(start["exits"][0]["x"] == start["origin_cell"].x + 10 and start["exits"][0]["y"] == start["origin_cell"].y + 5, "exported exit coordinates are logical cells")
	var origin: Vector2i = start["origin_cell"]
	for cell in start["floor_list"]:
		check(cell.x >= origin.x and cell.y >= origin.y and cell.x < origin.x + 11 and cell.y < origin.y + 11, "logical floor in room")
	var replay := ask(bus, &"LevelGenerationRequested", {"level_id": &"cave", "seed": 44, "size_cells": Vector2i(96,96), "deadend_budget": 1})
	check(replay["accepted"] and replay["map_data"]["rooms"][&"start"]["floor_list"] == start["floor_list"], "same seed reproduces initial geometry")
	var different := ask(bus, &"LevelGenerationRequested", {"level_id": &"cave", "seed": 45, "size_cells": Vector2i(96,96), "deadend_budget": 1})
	check(different["accepted"] and different["map_data"]["rooms"][&"start"]["floor_list"] != start["floor_list"], "different seed changes cave shape")
	var defaults := ask(bus, &"LevelGenerationRequested", {"level_id": &"defaults"})
	check(defaults["accepted"] and defaults["map_data"]["size_cells"] == Vector2i(96,96), "event works with level_id only")
	check(not ask(bus, &"LevelGenerationRequested", {"level_id": &"bad", "size_cells": Vector2i(10,10)})["accepted"] and ask(bus, &"LevelMapGetRequested", {})["map_data"]["level_id"] == &"defaults", "invalid request leaves current level")
	check(ask(bus, &"LevelGenerationRequested", {"level_id": &"cave", "seed": 44, "size_cells": Vector2i(96,96), "deadend_budget": 1})["accepted"], "restore test level")
	var center := (origin + Vector2i(5,5)) * 4
	check(entities.create_entity(&"hero"), "hero")
	check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": center, "size": 4})["accepted"], "hero at center")
	check(ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})["accepted"], "control")
	check(ask(bus, &"RoomEnterRequested", {"entity": &"hero", "room": &"start"})["accepted"], "enter start")
	var saved := ask(bus, &"SessionSaveRequested", {})
	check(saved["accepted"], "save before lazy child")
	var file := FileAccess.open("user://session.save", FileAccess.READ)
	var payload: Dictionary = bytes_to_var(file.get_buffer(file.get_length()))
	file.close()
	var broken := payload.duplicate(true)
	broken["sections"]["level"]["seed"] += 1
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(broken))
	file.close()
	check(not ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "reject mismatched level seed")
	file = FileAccess.open("user://session.save", FileAccess.WRITE)
	file.store_buffer(var_to_bytes(payload))
	file.close()
	var child := ask(bus, &"RoomChildGenerateRequested", {"room": &"start", "exit": &"east"})
	check(child["accepted"], "lazy child: " + str(child))
	if child["accepted"]:
		var before: Dictionary = ask(bus, &"RoomGetRequested", {"id": child["child"]})["data"]
		check(before["generated_cave"] and not before["floor_list"].is_empty() and before["exits"][0]["connected"], "child geometry and connection")
		check(ask(bus, &"SessionLoadRequested", {})["accepted"], "load before generation")
		var again := ask(bus, &"RoomChildGenerateRequested", {"room": &"start", "exit": &"east"})
		check(again["accepted"], "regenerate child")
		if again["accepted"]:
			var after: Dictionary = ask(bus, &"RoomGetRequested", {"id": again["child"]})["data"]
			check(after["type"] == before["type"] and after["origin_cell"] == before["origin_cell"] and after["floor_list"] == before["floor_list"] and after["floor_tiles"] == before["floor_tiles"], "seed and restore reproduce full child")
	check(ask(bus, &"SessionLoadRequested", {})["accepted"], "restore before crossing")
	var exit_data: Dictionary = ask(bus, &"RoomGetRequested", {"id": &"start"})["data"]["exits"][0]
	var threshold := Vector2i(int(exit_data["x"]) - 3, int(exit_data["y"]))
	check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": threshold})["accepted"], "4x4 hero can stand at exit")
	var start_after: Dictionary = ask(bus, &"RoomGetRequested", {"id": &"start"})["data"]
	check(start_after["exits"][0]["connected"] and ask(bus, &"LevelMapGetRequested", {})["map_data"]["rooms"].size() == 2, "actual passage touch creates child lazily")
	if start_after["exits"][0]["connected"]:
		var destination: Dictionary = ask(bus, &"RoomGetRequested", {"id": start_after["exits"][0]["childId"]})["data"]
		for t in destination["floor_tiles"]:
			var q := ask(bus, &"SpaceTileGetRequested", {"tile": t})
			check(q["kind"] == 1, "stored tiles are floor")
		var child_entry: Dictionary = destination["exits"][0]
		for tile in child_entry["tiles"]:
			check(destination["floor_tiles"].has(tile), "all entrance tiles reachable")
		for x in range(threshold.x + 1, threshold.x + 5):
			check(ask(bus, &"SpaceBodyMoveRequested", {"entity": &"hero", "anchor": Vector2i(x, threshold.y)})["accepted"], "4x4 hero traverses doorway step " + str(x))
	check(ask(bus, &"SessionSaveRequested", {})["accepted"] and ask(bus, &"SessionLoadRequested", {})["accepted"] and ask(bus, &"LevelMapGetRequested", {})["found"], "level state saves")
	print("Level generation tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
