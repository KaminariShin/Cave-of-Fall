extends SceneTree
var failures := 0
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	check(ask(bus, &"MaterialRegisterRequested", {"material": {"id": "steel", "name": "steel", "weight_per_unit": 1, "volume_per_unit": 1, "level": 8}})["accepted"], "material")
	check(ask(bus, &"MaterialRegisterRequested", {"material": {"id": "oak", "name": "oak", "weight_per_unit": 1, "volume_per_unit": 1, "level": 20}})["accepted"], "second material")
	check(ask(bus, &"ItemBaseRegisterRequested", {"base": {"id": "base", "name": "base", "materials": [{"material_id": "steel", "count": 1}]}})["accepted"], "base")
	check(ask(bus, &"ItemCreateRequested", {"id": &"item", "base_id": &"base", "item_level": 7, "rarity": &"magic"})["accepted"], "item")
	var tiers := [{"tier": 1, "value": 10, "level_req": 10, "weight": 1}, {"tier": 2, "value": 4, "level_req": 5, "weight": 10}]
	for category in ["prefix", "suffix", "affix"]:
		check(ask(bus, &"ModDefinitionRegisterRequested", {"definition": {"id": category, "category": category, "stat": "CON", "tiers": tiers}})["accepted"], "register " + category)
	check(ask(bus, &"ModDefinitionRegisterRequested", {"definition": {"id":"prefix2", "category":"prefix", "stat":"CON", "tiers":tiers}})["accepted"], "register second prefix")
	var prefix := ask(bus, &"ModRollApplyRequested", {"item": &"item", "mod_id": &"prefix"})
	check(prefix["accepted"] and prefix["mod"]["tier"] == 2, "level filters high tier")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"item", "mod_id": &"prefix"})["accepted"], "duplicate ID forbidden")
	check(ask(bus, &"ModRollApplyRequested", {"item": &"item", "mod_id": &"prefix2"})["accepted"], "different second prefix allowed")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"item", "mod_id": &"prefix"})["accepted"], "magic prefix limit")
	check(ask(bus, &"ModRollApplyRequested", {"item": &"item", "mod_id": &"suffix"})["accepted"], "separate suffix")
	check(ask(bus, &"ItemCreateRequested", {"id": &"normal", "base_id": &"base", "item_level": 7})["accepted"], "normal item")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"normal", "mod_id": &"affix"})["accepted"], "normal disallows affix")
	check(ask(bus, &"ModRollApplyRequested", {"item": &"item", "mod_id": &"affix"})["accepted"], "magic rarity enables affix")
	var item := ask(bus, &"ItemGetRequested", {"item": &"item"})
	check(item["item_data"]["mods"].size() == 4, "categories stored")
	check(not ask(bus, &"ItemCreateRequested", {"id": &"no_level", "base_id": &"base", "rarity": &"magic"})["accepted"], "missing item level rejected")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"no_level", "mod_id": &"prefix"})["accepted"], "missing level rejects roll")
	var mixed := [{"material_id": "steel", "count": 1}, {"material_id": "oak", "count": 1}]
	check(ask(bus, &"ItemCreateRequested", {"id": &"mixed", "base_id": &"base", "rarity": &"magic", "item_level": 20, "materials": mixed})["accepted"], "mixed item")
	check(not ask(bus, &"ModRollApplyRequested", {"item": &"mixed", "mod_id": &"prefix"})["accepted"], "mixed material requires selection")
	var low := ask(bus, &"ModRollApplyRequested", {"item": &"mixed", "mod_id": &"prefix", "material_id": &"steel"})
	check(low["accepted"] and low["mod"]["tier"] == 2, "material level restricts tier")
	check(ask(bus, &"ItemCreateRequested", {"id": &"weighted_a", "base_id": &"base", "rarity": &"magic", "item_level": 20, "materials": [{"material_id": "oak", "count": 1}]})["accepted"], "weighted item A")
	check(ask(bus, &"ItemCreateRequested", {"id": &"weighted_b", "base_id": &"base", "rarity": &"magic", "item_level": 20, "materials": [{"material_id": "oak", "count": 1}]})["accepted"], "weighted item B")
	var sample := {"value": 0.0}
	bus.subscribe(&"RngFloatRequested", func(req): req["value"] = sample["value"])
	check(ask(bus, &"ModRollApplyRequested", {"item": &"weighted_a", "mod_id": &"prefix"})["mod"]["tier"] == 1, "weight interval 1/11")
	sample["value"] = 0.5
	check(ask(bus, &"ModRollApplyRequested", {"item": &"weighted_b", "mod_id": &"prefix"})["mod"]["tier"] == 2, "weight interval 10/11")
	var save := ask(bus, &"SessionSaveRequested", {})
	check(save.get("accepted", false), "save mods: " + str(save))
	var load := ask(bus, &"SessionLoadRequested", {})
	check(load.get("accepted", false), "load mods: " + str(load))
	check(ask(bus, &"ItemGetRequested", {"item": &"item"})["item_data"]["mods"].size() == 4, "rolled mods restored")
	check(ask(bus, &"ModDefinitionGetRequested", {"id": &"prefix"})["found"], "definitions restored")
	print("Mod tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
