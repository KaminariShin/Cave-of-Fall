extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var path := "user://demo_session.save"
	var old_exists := FileAccess.file_exists(path)
	var old := PackedByteArray()
	if old_exists:
		var f := FileAccess.open(path,FileAccess.READ)
		old = f.get_buffer(f.get_length()); f.close()
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"setup")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet start")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":Vector2i(87,68)}).get("accepted",false),"start passage")
	for i in range(5):
		check(game._move(Vector2i.RIGHT),"walk %d" % i)
		driver.advance_steps(100)
	var room: StringName = game.current_room
	check(room != game.ROOM,"entered child")
	await process_frame
	await process_frame
	await process_frame
	var state := ask(&"RoomSpawnStatusRequested", {"room":room})
	check(state.get("spawned",false),"automatic spawn " + str(game.message) + " " + str(state))
	var units: Array = state.get("data",{}).get("placed",[]).duplicate()
	check(not units.is_empty(),"room contains enemies")
	for id in units:
		var setup := ask(&"DemoMeleeSetupStatusRequested", {"entity":id})
		var ai := ask(&"AIGetRequested", {"entity":id})
		check(setup.get("status","") == "installed" and ai.get("data",{}).get("role","") == "melee","equipped with common AI " + str(setup))
	for id in units:
		check(ask(&"AIGetRequested",{"entity":id}).get("data",{}).get("weapon",{}).get("strike","")=="demo_creature_thrust","new enemy reduced reach")
		# Simulate the previous 0.192 save where spawned enemies had old strike.
		root.get_node("AIService")._agents[id]["weapon"]["strike"]="sword_simple_thrust"
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save populated room with legacy reach")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load populated room")
	await process_frame
	await process_frame
	var after: Array = ask(&"RoomSpawnStatusRequested", {"room":room}).get("data",{}).get("placed",[])
	check(after == units,"no duplicate on load")
	game._room_changed({"entity":game.HERO,"room":room})
	await process_frame
	check(ask(&"RoomSpawnStatusRequested", {"room":room}).get("data",{}).get("placed",[]) == units,"repeat room notification does not respawn")
	for id in units:
		var restored: Dictionary = ask(&"AIGetRequested", {"entity":id}).get("data",{})
		check(restored.get("role","") == "melee","AI restored")
		check(restored.get("weapon",{}).get("strike","") == "demo_creature_thrust","legacy saved enemy migrated")
	if not units.is_empty():
		# Отдельно проверяем, что настоящий удар игрока способен поражать
		# сгенерированного врага, а не только учебную крысу.
		for id in units: ask(&"AIUnregisterRequested", {"entity":id})
		var enemy: StringName = units[0]
		var info: Dictionary = ask(&"RoomGetRequested", {"id":room})["data"]
		var origin: Vector2i = info["origin_cell"] * 4
		var size: Vector2i = info["size_cells"] * 4
		var bounds := {"origin":origin,"size":size}
		var placed := false
		for y in range(origin.y+2,origin.y+size.y-6):
			for x in range(origin.x+2,origin.x+size.x-9):
				var hero_anchor := Vector2i(x,y)
				var enemy_anchor := hero_anchor + Vector2i(6,1)
				var hero_fit: bool = ask(&"SpaceBodyFitsRequested", {"anchor":hero_anchor,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false)
				var enemy_fit: bool = ask(&"SpaceBodyFitsRequested", {"anchor":enemy_anchor,"size":2,"room":bounds,"ignore_entity":enemy}).get("fits",false)
				if hero_fit and enemy_fit and ask(&"SpaceBodyMoveRequested", {"entity":game.HERO,"anchor":hero_anchor}).get("accepted",false) and ask(&"SpaceBodyMoveRequested", {"entity":enemy,"anchor":enemy_anchor}).get("accepted",false):
					placed = true; break
			if placed: break
		check(placed,"position for real combat")
		if placed:
			var hp: float = ask(&"ResourceGetRequested", {"entity":enemy,"resource":&"HP"})["data"]["current"]
			game.facing = Vector2i.RIGHT
			check(game._start_attack(),"start real player strike")
			driver.advance_steps(150)
			var after_hp: float = ask(&"ResourceGetRequested", {"entity":enemy,"resource":&"HP"})["data"]["current"]
			check(after_hp < hp,"player damages spawned enemy")
	game.queue_free()
	await process_frame
	if old_exists:
		var f := FileAccess.open(path,FileAccess.WRITE); f.store_buffer(old); f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo auto spawn: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
