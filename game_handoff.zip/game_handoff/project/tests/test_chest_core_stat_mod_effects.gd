extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func stat(actor: StringName, name: StringName) -> float:
	var q := ask(&"StatGetRequested", {"entity":actor,"stat":name})
	return float(q.get("value",NAN)) if q.get("found",false) else NAN
func resource(actor: StringName, name: StringName) -> Dictionary:
	return ask(&"ResourceGetRequested", {"entity":actor,"resource":name}).get("data",{})
func capacity(actor: StringName) -> float:
	return float(ask(&"WeightGetRequested", {"entity":actor}).get("data",{}).get("capacity_kg",NAN))
func state(id: StringName) -> Dictionary:
	return ask(&"ItemGetRequested", {"item":id})["item_data"]["learning_state"]
func wait(driver, actor: StringName, steps: int = 1) -> bool:
	return ask(&"ActionStartRequested", {"entity":actor,"action":&"wait","duration":steps*0.01}).get("accepted",false) and driver.advance_steps(steps) == steps
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":20}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":20}).get("accepted",false), "control and inventory")
	for actor in [&"hero",&"npc"]:
		for key in [&"CON",&"STR",&"DEX",&"INT"]:
			check(ask(&"StatBaseSetRequested", {"entity":actor,"stat":key,"value":10}).get("accepted",false), "base stats")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var cases := [
		{"name":&"CON", "mod":&"pre_vital", "base":&"armor_cloth_body", "material":&"cloth_light", "hp":5.0, "stamina":5.0},
		{"name":&"STR", "mod":&"pre_strength", "base":&"armor_leather_body", "material":&"leather_thin", "hp":2.0, "stamina":3.0},
		{"name":&"DEX", "mod":&"pre_agile", "base":&"armor_cloth_body", "material":&"cloth_light", "hp":2.0, "stamina":3.0},
		{"name":&"INT", "mod":&"pre_mind", "base":&"armor_cloth_body", "material":&"cloth_light", "hp":0.0, "stamina":0.0}]
	for index in range(cases.size()):
		var c: Dictionary = cases[index]
		var id := StringName("core_%d" % index)
		var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(c["base"],bases)
		var mod := {"id":c["mod"], "category":"prefix", "stat":str(c["name"]), "tier":3, "value":1.0, "level_req":1, "material_id":c["material"], "unlock_after":5}
		check(ask(&"ItemCreateRequested", {"id":id,"base_id":c["base"],"item_level":1,"rarity":&"magic","learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":id,"mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":id}).get("accepted",false), "create %s" % c["name"])
		check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":id,"slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and stat(&"hero",c["name"]) == 10.0, "unknown inactive %s" % c["name"])
		for n in range(5): check(wait(driver,&"hero"), "progress")
		check(stat(&"hero",c["name"]) == 11.0 and resource(&"hero",&"HP")["max"] == 90.0+c["hp"] and resource(&"hero",&"Stamina")["max"] == 110.0+c["stamina"] and capacity(&"hero") == (75.0 if c["name"] == &"STR" else 70.0), "stat and dependent values %s" % c["name"])
		check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and stat(&"hero",c["name"]) == 11.0, "save %s" % c["name"])
		check(ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and stat(&"hero",c["name"]) == 10.0 and resource(&"hero",&"HP")["max"] == 90.0 and resource(&"hero",&"Stamina")["max"] == 110.0 and capacity(&"hero") == 70.0, "unequip %s" % c["name"])
	var shield_schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	var strength := {"id":&"pre_strength", "category":"prefix", "stat":"STR", "tier":3, "value":1.0, "level_req":1, "material_id":&"iron_common", "unlock_after":5}
	check(ask(&"ItemCreateRequested", {"id":&"npc_shield","base_id":&"shield_small","item_level":1,"rarity":&"magic","learning":shield_schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"npc_shield","mod":strength}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"npc_shield"}).get("accepted",false), "fresh npc shield")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"npc_shield","slot":"off"}).get("accepted",false) and wait(driver,&"hero",10) and state(&"npc_shield")["progress"] == 0 and not state(&"npc_shield")["identified"] and stat(&"npc",&"STR") == 11.0 and capacity(&"npc") == 75.0, "NPC immediate bonus")
	check(ask(&"ControlledEntityRequested", {"entity":&"npc"}).get("accepted",false) and stat(&"npc",&"STR") == 10.0 and capacity(&"npc") == 70.0 and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and stat(&"npc",&"STR") == 11.0 and capacity(&"npc") == 75.0, "control switch updates dependent weight")
	var schema2: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"armor_cloth_body",bases)
	var vital := {"id":&"pre_vital", "category":"prefix", "stat":"CON", "tier":3, "value":1.0, "level_req":1, "material_id":&"cloth_light", "unlock_after":5}
	var agile := {"id":&"pre_agile", "category":"prefix", "stat":"DEX", "tier":3, "value":1.0, "level_req":1, "material_id":&"cloth_light", "unlock_after":10}
	check(ask(&"ItemCreateRequested", {"id":&"mixed","base_id":&"armor_cloth_body","item_level":1,"rarity":&"magic","learning":schema2}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"mixed","mod":vital}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"mixed","mod":agile}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"mixed"}).get("accepted",false), "two stat mods")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"mixed","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10, "equip mixed")
	for n in range(5): check(wait(driver,&"hero"),"mixed progress 5")
	check(stat(&"hero",&"CON") == 11 and stat(&"hero",&"DEX") == 10 and resource(&"hero",&"HP")["max"] == 95, "first unlock")
	for n in range(5): check(wait(driver,&"hero"),"mixed progress 10")
	check(stat(&"hero",&"CON") == 11 and stat(&"hero",&"DEX") == 11 and resource(&"hero",&"HP")["max"] == 97 and resource(&"hero",&"Stamina")["max"] == 118, "second unlock")
	var corrupt := func(e):
		if e.get("item",null) == &"mixed" and e.get("found",false): e["item_data"]["mods"][0]["value"] = 999
	bus.subscribe(&"ItemGetRequested",corrupt)
	check(not ask(&"StatGetRequested", {"entity":&"hero","stat":&"CON"}).get("found",true), "corrupt mod rejects stat query")
	bus.unsubscribe(&"ItemGetRequested",corrupt)
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":5}).get("accepted",false), "clear body and lower INT")
	var mind := {"id":&"pre_mind", "category":"prefix", "stat":"INT", "tier":3, "value":1.0, "level_req":1, "material_id":&"cloth_light", "unlock_after":5}
	check(ask(&"ItemCreateRequested", {"id":&"mind_test","base_id":&"armor_cloth_body","item_level":1,"rarity":&"magic","learning":schema2}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"mind_test","mod":mind}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"mind_test"}).get("accepted",false), "mind threshold item")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"mind_test","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and stat(&"hero",&"INT") == 5.0 and is_equal_approx(float(ask(&"EquipmentArmourGetRequested", {"entity":&"hero"})["armour"]),2.0), "INT below requirement penalizes armor")
	for n in range(5): check(wait(driver,&"hero"),"mind progress")
	check(stat(&"hero",&"INT") == 6.0 and not state(&"mind_test")["identified"] and is_equal_approx(float(ask(&"EquipmentArmourGetRequested", {"entity":&"hero"})["armour"]),4.0), "revealed INT bonus removes penalty without identification")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":4}).get("accepted",false) and is_equal_approx(float(ask(&"EquipmentArmourGetRequested", {"entity":&"hero"})["armour"]),2.4), "INT drop restores progressed penalty")
	print("Chest core stat mod effect tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
