extends SceneTree
var failures := 0
var selected: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, e)
	return e
func name_for(i: int) -> StringName:
	return &"root" if i == 0 else StringName("node_%d" % i)
func coord(i: int) -> Vector2i:
	var row: int = int(i / 6)
	var position: int = i % 6
	var col: int = position if row % 2 == 0 else 5 - position
	return Vector2i(2 + col * 12, 2 + row * 12)
func direction(from: Vector2i, to: Vector2i) -> String:
	var delta := to - from
	if delta.x > 0: return "east"
	if delta.x < 0: return "west"
	if delta.y > 0: return "south"
	return "north"
func reverse(dir: String) -> String:
	return {"north":"south", "south":"north", "east":"west", "west":"east"}[dir]
func begin(floor_no: int) -> bool:
	if not ask(&"SpaceMapConfigureRequested", {"size":Vector2i(320,200)}).get("accepted", false): return false
	if not ask(&"RoomCreateRequested", {"id":&"root", "type":"start", "origin_cell":coord(0), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	return ask(&"DungeonFloorTrackingBeginRequested", {"floor":floor_no, "start_room":&"root"}).get("accepted", false)
func add_room(index: int, type: String, block_entry: bool = false) -> bool:
	var parent := name_for(index - 1)
	var id := name_for(index)
	var out_dir := direction(coord(index - 1), coord(index))
	var parent_exit := StringName("out_%d" % index)
	if not ask(&"RoomCreateRequested", {"id":id, "type":type, "origin_cell":coord(index), "size_cells":Vector2i(12,12)}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":parent, "id":parent_exit, "dir":out_dir, "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitAddRequested", {"room":id, "id":&"entry", "dir":reverse(out_dir), "offset_cells":5}).get("accepted", false): return false
	if not ask(&"RoomExitConnectRequested", {"room":parent, "exit":parent_exit, "other_room":id, "other_exit":&"entry"}).get("accepted", false): return false
	if block_entry:
		var child: Dictionary = ask(&"RoomGetRequested", {"id":id})["data"]
		var entry: Dictionary = child["exits"][0]
		var seed := Vector2i(int(entry["x"]), int(entry["y"]))
		match entry["dirOut"]:
			"west": seed.x += 1
			"east": seed.x -= 4
			"north": seed.y += 1
			"south": seed.y -= 4
		if not ask(&"EntityCreateRequested", {"entity":&"blocker"}).get("accepted", false): return false
		if not ask(&"SpaceBodyPlaceRequested", {"entity":&"blocker", "anchor":seed, "size":4}).get("accepted", false): return false
	# Реальная геометрия и связи RoomService; событие обычно публикует
	# ленивый генератор после создания очередного потомка.
	ask(&"RoomChildGenerated", {"room":parent, "child":id, "type":type})
	return true
func tracking() -> Dictionary:
	return ask(&"DungeonFloorTrackingGetRequested", {}).get("data", {})
func reachable_stair(room_id: StringName, stair_tile: Vector2i) -> bool:
	var room: Dictionary = ask(&"RoomGetRequested", {"id":room_id})["data"]
	var entry: Dictionary = room["exits"][0]
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match entry["dirOut"]:
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
	var bounds := {"origin":room["origin_cell"] * 4, "size":room["size_cells"] * 4}
	var queue: Array = [seed]
	var seen := {seed:true}
	var index := 0
	while index < queue.size():
		var a: Vector2i = queue[index]
		index += 1
		if not ask(&"SpaceBodyFitsRequested", {"anchor":a, "size":4, "room":bounds, "ignore_entity":&""}).get("fits", false): continue
		if ((stair_tile.x == a.x - 1 or stair_tile.x == a.x + 4) and stair_tile.y >= a.y and stair_tile.y < a.y + 4) or ((stair_tile.y == a.y - 1 or stair_tile.y == a.y + 4) and stair_tile.x >= a.x and stair_tile.x < a.x + 4): return true
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = a + d
			if not seen.has(next):
				seen[next] = true
				queue.append(next)
	return false
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	# Этот тест управляет прежним постраничным поиском через mock.
	root.get_node("DungeonBossChestAutoService").set("_quick_search",false)
	check(begin(4), "floor")
	for i in range(1,17): check(add_room(i,"passage"), "chain %d" % i)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"boss_chest:node_16:0"}).get("accepted",false), "hero and occupied chest ID")
	var parent: Dictionary = ask(&"RoomGetRequested", {"id":&"node_15"})["data"]
	var ex: Dictionary = parent["exits"].filter(func(x): return x["childId"] == &"node_16")[0]
	var entry := Vector2i(int(ex["x"])-4, int(ex["y"]))
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":entry,"size":4}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"RoomEnterRequested", {"entity":&"hero","room":&"node_15"}).get("accepted",false), "hero at entry")
	for x in range(entry.x+1,entry.x+6): check(ask(&"SpaceBodyMoveRequested", {"entity":&"hero","anchor":Vector2i(x,entry.y)}).get("accepted",false), "enter")
	check(ask(&"DungeonBossGetRequested",{}).get("found",false), "boss spawned and auto scheduled")
	var room: Dictionary = ask(&"RoomGetRequested", {"id":&"node_16"})["data"]
	var origin: Vector2i = room["origin_cell"] * 4
	var bounds := {"origin":origin,"size":room["size_cells"]*4}
	var moved := false
	for offset in [Vector2i(10,10),Vector2i(20,10),Vector2i(30,10),Vector2i(10,30),Vector2i(30,30)]:
		var target: Vector2i = origin+offset
		if ask(&"SpaceBodyFitsRequested", {"anchor":target,"size":4,"room":bounds,"ignore_entity":&"hero"}).get("fits",false):
			moved = ask(&"SpaceBodyMoveRequested", {"entity":&"hero","anchor":target}).get("accepted",false)
			if moved: break
	check(moved and ask(&"RoomCurrentGetRequested",{}).get("room",null) == &"node_16", "move clear of entry")
	var search := ask(&"DungeonChestPositionSearchRequested", {"room":&"node_16"})
	var cursor := 0
	while search.get("accepted",false) and not search.get("found",false) and not search.get("complete",false) and cursor < 2304:
		cursor = search["next_cursor"]
		search = ask(&"DungeonChestPositionSearchRequested", {"room":&"node_16","cursor":cursor})
	check(search.get("accepted",false) and search.get("found",false), "real preflight candidate")
	if not search.get("found",false): quit(1); return
	var candidate: Dictionary = search.duplicate(true)
	var simulation := {"mode":"empty"}
	var mock := func(e):
		if e.get("room",null) != &"node_16": return
		if simulation["mode"] == "hold":
			e["accepted"] = true; e["found"] = false; e["complete"] = false; e["next_cursor"] = e.get("cursor",0)+1
		elif simulation["mode"] == "empty" or e.get("cursor",0) >= candidate["next_cursor"]:
			e["accepted"] = true; e["found"] = false; e["complete"] = true; e["next_cursor"] = 2304
		else:
			e["accepted"] = true; e["found"] = true; e["complete"] = false; e["next_cursor"] = candidate["next_cursor"]
			for key in ["tile","interaction_anchor","connected_exits_checked","open_exits_checked"]: e[key] = candidate[key]
	var bus = root.get_node("EventBus")
	bus.subscribe(&"DungeonChestPositionSearchRequested",mock)
	for i in range(8): await process_frame
	var failed := ask(&"DungeonBossChestAutoStatusRequested",{})
	check(failed.get("status","") == "failed" and str(failed.get("error","")).contains("не найдена"), "empty search reports failure " + str(failed))
	simulation["mode"] = "hold"
	check(ask(&"DungeonBossChestAutoRetryRequested", {"room":&"node_16"}).get("accepted",false), "retry search")
	for i in range(2): await process_frame
	check(ask(&"DungeonBossChestAutoStatusRequested",{}).get("status","") == "searching", "incremental search")
	# Изменение карты другой комнаты: старая выборка отменяется, поиск сам начинается заново.
	check(ask(&"SpaceTilesSetRequested", {"tiles":[Vector2i(1,1)],"kind":1}).get("accepted",false), "world changes during search")
	for i in range(4): await process_frame
	check(ask(&"DungeonBossChestAutoStatusRequested",{}).get("status","") == "searching" and root.get_node("DungeonBossChestAutoService").get("_world_change_retries") == 1, "world change restarted automatically")
	for n in range(3):
		check(ask(&"SpaceTilesSetRequested", {"tiles":[Vector2i(1,1)],"kind":0 if n % 2 == 0 else 1}).get("accepted",false), "repeat world change")
		for i in range(4): await process_frame
	check(ask(&"DungeonBossChestAutoStatusRequested",{}).get("status","") == "failed", "bounded retry eventually reports failure")
	check(ask(&"DungeonBossChestAutoRetryRequested", {"room":&"node_16"}).get("accepted",false), "manual retry after limit")
	for i in range(4): await process_frame
	check(ask(&"DungeonBossChestAutoStatusRequested",{}).get("status","") == "searching", "manual retry restarts cleanly")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false), "restore during transient search")
	simulation["mode"] = "one"
	for i in range(12): await process_frame
	var result := ask(&"DungeonBossChestAutoStatusRequested",{})
	check(result.get("status","") == "created" and result.get("room",null) == &"node_16", "automatic provision success " + str(result))
	if result.get("status","") != "created": quit(1); return
	var chest: StringName = result["object"]
	check(chest == &"boss_chest:node_16:1", "avoids occupied object ID")
	var objects: Dictionary = ask(&"RoomObjectsGetRequested", {"room":&"node_16"})["objects"]
	check(objects[chest].get("content_fixed",false) and objects[chest]["interaction"].get("boss_chest",false) and ask(&"InventoryGetRequested", {"entity":chest})["data"]["items"].size() in [4,5,6,7,8], "finished chest")
	var saver = root.get_node("SaveService")
	var before: Dictionary = saver.collect_world_transition_snapshot()
	check(ask(&"DungeonBossChestAutoRetryRequested", {"room":&"node_16"}).get("accepted",false), "idempotent retry")
	for i in range(6): await process_frame
	check(ask(&"DungeonBossChestAutoStatusRequested",{}).get("object",null) == chest and before["payload"]["sections"]["rng"] == saver.collect_world_transition_snapshot()["payload"]["sections"]["rng"], "no duplicate or reroll")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false), "save and load")
	for i in range(6): await process_frame
	check(ask(&"DungeonBossChestAutoStatusRequested",{}).get("status","") == "created" and ask(&"DungeonBossChestAutoStatusRequested",{}).get("object",null) == chest, "restore recognizes chest")
	bus.unsubscribe(&"DungeonChestPositionSearchRequested",mock)
	print("Automatic boss chest tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
