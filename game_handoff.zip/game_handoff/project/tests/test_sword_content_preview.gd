extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,data)
	return data
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,60)}).get("accepted",false), "map")
	var floor_tiles: Array = []
	for x in range(80):
		for y in range(60): floor_tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floor_tiles,"kind":1}).get("accepted",false), "floor")
	check(root.get_node("EntityRegistry").create_entity(&"hero", {&"stats":{"DEX":5,"INT":5,"PER":5}}), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(15,15),"size":4}).get("accepted",false), "body")
	check(ask(&"ItemCreateRequested", {"id":&"sword", "base_id":&"sword_simple", "item_level":1}).get("accepted",false), "create actual simple sword")
	var resolved := ask(&"WeaponItemResolveRequested", {"item":&"sword"})
	check(resolved.get("found",false) and resolved["data"]["id"] == "sword_simple_variant" and resolved["data"]["base_stamina_cost"] == 7 and resolved["data"]["tags"] == ["one_handed"], "instance resolves its defined variant and cost")
	var list := ask(&"WeaponStrikesGetRequested", {"item":&"sword"})
	var ids:Array=[]
	for row in list.get("strikes",[]): ids.append(row.get("id",""))
	check(list.get("found",false) and ids.has("sword_simple_thrust") and ids.has("sword_simple_horizontal") and ids.has("sword_simple_vertical"), "three original sword techniques available")
	check(ids.has("demo_player_sword_thrust") and ids.has("demo_rat_thrust") and ids.has("demo_creature_thrust"), "separate demo ranges available")
	var cases := [["sword_simple_thrust",15,1.2,"piercing",0.84], ["sword_simple_horizontal",7,0.8,"chopping",1.25], ["sword_simple_vertical",10,1.0,"chopping",1.0]]
	for c in cases:
		var q := ask(&"WeaponStrikePreviewRequested", {"entity":&"hero","item":&"sword","strike":c[0],"kind":"physical","direction":Vector2.RIGHT})
		check(q.get("accepted",false), "preview " + c[0])
		if not q.get("accepted",false): continue
		var d: Dictionary = q["strike_data"]
		check(d["damage"] == c[1] and is_equal_approx(d["speed_effectiveness"],c[2]) and d["technique"] == c[3] and is_equal_approx(q["timing"]["duration"],c[4]), "stats " + c[0])
		check(q["zone"]["tiles"].has(Vector2i(25,16)) and not q["zone"]["tiles"].has(Vector2i(26,16)) and is_equal_approx(q["zone"]["max_distance"],9.35), "adjusted reach " + c[0])
	var bad := {"id":"bad_reach","name":"invalid","variants":["sword_simple_variant"],"damage":1,"speed_effectiveness":1,"range":6,"zone":{"type":"arc","angle_degrees":60,"reach_bound":true,"radius":4}}
	check(not ask(&"WeaponStrikeRegisterRequested", {"definition":bad}).get("accepted",true), "ambiguous reach rejected")
	bad["zone"] = {"type":"line","width":2,"reach_bound":true}
	bad["technique"] = "unknown"
	check(not ask(&"WeaponStrikeRegisterRequested", {"definition":bad}).get("accepted",true), "unknown technique rejected")
	check(ask(&"SessionSaveRequested", {}).get("accepted",false) and ask(&"SessionLoadRequested", {}).get("accepted",false), "save and load")
	var restored := ask(&"WeaponStrikePreviewRequested", {"entity":&"hero","item":&"sword","strike":"sword_simple_thrust","kind":"physical","direction":Vector2.RIGHT})
	check(restored.get("accepted",false) and restored["strike_data"]["zone"].get("reach_bound",false), "preview after load")
	check(not ask(&"ActionGetRequested", {"entity":&"hero"}).get("found",false), "preview does not start action")
	print("Sword content preview tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
