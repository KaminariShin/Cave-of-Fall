extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func id(i: int) -> StringName: return StringName("chain_%d" % i)
func budget(room: StringName, value: int) -> Dictionary:
	return ask(&"DungeonDeadendBudgetAvailableRequested", {"room":room, "budget":value})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(500,250)}).get("accepted", false), "map")
	for i in range(6):
		var room_type := "start" if i == 0 else "fork"
		check(ask(&"RoomCreateRequested", {"id":id(i), "type":room_type, "origin_cell":Vector2i(10 if i == 0 else 22 + (i - 1) * 14,20), "size_cells":Vector2i(12,12) if i == 0 else Vector2i(14,14)}).get("accepted", false), "create chain room")
		if i == 0:
			check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":id(0)}).get("accepted", false), "tracking starts before children")
		else:
			check(ask(&"RoomExitAddRequested", {"room":id(i - 1), "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false), "add outgoing")
			check(ask(&"RoomExitAddRequested", {"room":id(i), "id":&"entry", "dir":"west", "offset_cells":5}).get("accepted", false), "add entry")
			check(ask(&"RoomExitConnectRequested", {"room":id(i - 1), "exit":&"east", "other_room":id(i), "other_exit":&"entry"}).get("accepted", false), "connect")
			ask(&"RoomChildGenerated", {"room":id(i - 1), "child":id(i), "type":room_type})
	check(budget(id(1),1).get("budget", -1) == 0, "reserve last deadend at early depth")
	check(budget(id(1),2).get("budget", -1) == 2, "additional early deadends remain allowed")
	check(budget(id(4),1).get("budget", -1) == 0, "child distance five still reserved")
	check(budget(id(5),1).get("budget", -1) == 1, "child distance six may use reservation")
	check(not budget(&"missing",1).get("accepted", false), "unknown parent fails closed")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":1}).get("accepted", false), "set budget")
	check(budget(id(1),0).get("budget", -1) == 0, "zero budget not fabricated")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save and restore before candidate")
	check(budget(id(1),1).get("budget", -1) == 0 and budget(id(5),1).get("budget", -1) == 1, "reservation survives restore")
	check(ask(&"RoomExitAddRequested", {"room":id(1), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "early branch")
	check(ask(&"RoomExitAddRequested", {"room":id(5), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "eligible branch")
	var service = root.get_node("DungeonStairsService")
	var bus = root.get_node("EventBus")
	var force_last := func(e): e["value"] = 0.999999
	var force_min := func(e): e["value"] = e["min"]
	var state := {"checked":false, "baseline":false, "blocked_entry":true, "occupied":true, "after":false, "fit_queries":0, "tile_queries":0}
	var block_body := func(e):
		state["fit_queries"] += 1
		e["fits"] = false
	var occupy_tiles := func(e):
		state["tile_queries"] += 1
		e["occupant"] = &"simulated_occupant"
	var check_trial := func(e):
		if state["checked"]: return
		state["checked"] = true
		state["baseline"] = e.get("accepted", false)
		bus.subscribe(&"SpaceBodyFitsRequested", block_body)
		state["blocked_entry"] = service._probe_room(e["room"], e["floor"])
		bus.unsubscribe(&"SpaceBodyFitsRequested", block_body)
		bus.subscribe(&"SpaceTileGetRequested", occupy_tiles)
		state["occupied"] = service._probe_room(e["room"], e["floor"])
		bus.unsubscribe(&"SpaceTileGetRequested", occupy_tiles)
		state["after"] = service._probe_room(e["room"], e["floor"])
	bus.subscribe(&"RngFloatRequested", force_last)
	bus.subscribe(&"RngIntRequested", force_min)
	bus.subscribe(&"DungeonStairTrialRequested", check_trial)
	var result := ask(&"RoomChildGenerateRequested", {"room":id(5), "exit":&"north"})
	bus.unsubscribe(&"DungeonStairTrialRequested", check_trial)
	bus.unsubscribe(&"RngFloatRequested", force_last)
	bus.unsubscribe(&"RngIntRequested", force_min)
	check(state["checked"] and state["baseline"], "baseline candidate viable")
	check(state["fit_queries"] > 0 and not state["blocked_entry"], "inaccessible entrance rejected")
	check(state["tile_queries"] > 0 and not state["occupied"], "occupied candidate cells rejected")
	check(state["after"] and result.get("accepted", false), "probes do not alter world")
	check(ask(&"DungeonStairGetRequested", {}).get("data", {}).get("status", "") == "placed", "real placement succeeds")
	print("Stair trial obstacles tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
