extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(100,100)}).get("accepted",false) and ask(&"RoomCreateRequested",{"id":&"r","type":"start","origin_cell":Vector2i(2,2),"size_cells":Vector2i(11,11)}).get("accepted",false),"room")
	check(ask(&"EntityCreateRequested",{"entity":&"hero","components":{&"stats":{"CON":100,"PER":30}}}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(28,28),"size":4}).get("accepted",false) and ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false) and ask(&"RoomEnterRequested",{"entity":&"hero","room":&"r"}).get("accepted",false),"hero")
	ask(&"RngSeedRequested",{"seed":42})
	var spawn := ask(&"RoomSpawnRequested",{"room":&"r","player":&"hero","entry_tile":Vector2i(28,28),"depth":6,"demo_pool":true,"demo_melee":true,"queue_delay":0.05})
	check(spawn.get("accepted",false) and not spawn.get("units",[]).is_empty(),"spawn")
	if not spawn.get("accepted",false) or spawn.get("units",[]).is_empty(): quit(1); return
	var enemy: StringName = spawn["units"][0]["entity"]
	var rolls := [50,1,1,1,0,0]
	var override := func(e):
		if not rolls.is_empty(): e["value"]=rolls.pop_front()
	bus.subscribe(&"RngIntRequested",override)
	var installed: Dictionary = root.get_node("DemoMeleeSetupService")._attempt(enemy)
	bus.unsubscribe(&"RngIntRequested",override)
	check(installed.get("accepted",false) and rolls.is_empty(),"install forced hammer, armour and potion " + str(installed))
	if not installed.get("accepted",false): quit(1); return
	var gear: Dictionary=ask(&"ComponentGetRequested",{"entity":enemy,"component":&"equipment"})["data"]
	var inv: Dictionary=ask(&"InventoryGetRequested",{"entity":enemy})["data"]
	var bow: StringName=gear["main"]
	var armour: StringName=gear["body"]
	var potion: StringName=inv["items"][0]
	check(ask(&"ItemGetRequested",{"item":bow})["item_data"]["base_id"]==&"hammer_simple" and not gear.has("off"),"hammer is two-handed")
	check(ask(&"ItemGetRequested",{"item":armour})["item_data"]["base_id"]==&"armor_cloth_body" and ask(&"ItemGetRequested",{"item":potion})["item_data"]["base_id"]==&"potion_hp","armor and extra item created")
	check(ask(&"AIGetRequested",{"entity":enemy})["data"]["weapon"]["strike"]=="demo_player_hammer_slam","AI uses hammer")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"save and load")
	check(ask(&"ComponentGetRequested",{"entity":enemy,"component":&"equipment"})["data"]==gear and ask(&"InventoryGetRequested",{"entity":enemy})["data"]==inv,"saved loadout not rerolled")
	check(ask(&"CombatDamageRequested",{"entity":enemy,"source":&"hero","amount":9999}).get("accepted",false),"kill")
	var ground: Dictionary=ask(&"LootGetRequested",{})["items"]
	check(ground.has(bow) and ground.has(armour) and ground.has(potion),"equipped items and extra drop")
	print("Demo hammer loot: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
