extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var r := ask(&"DungeonDepthCalculateRequested", {"floor":2, "distance":6})
	check(r.get("accepted", false) and is_equal_approx(r.get("depth", 0), 3.2) and r.get("enemy_level", 0) == 2, "depth and level")
	check(not ask(&"DungeonDepthCalculateRequested", {"floor":5, "distance":0}).get("accepted", false), "reject floor five")
	r = ask(&"PeriodicDurationCalculateRequested", {"base_duration":2.25, "CON":5})
	check(r.get("accepted", false) and is_equal_approx(r.get("duration", 0), 2.5), "half rounding up")
	r = ask(&"PeriodicDurationCalculateRequested", {"base_duration":0.01, "CON":5})
	check(r.get("accepted", false) and is_equal_approx(r.get("duration", 0), 0.5), "minimum duration")
	check(not ask(&"PeriodicDurationCalculateRequested", {"base_duration":5, "CON":-45}).get("accepted", false), "invalid denominator")
	r = ask(&"ArmourProtectionCalculateRequested", {"armour":5, "percent_sources":[-1.234]})
	check(r.get("accepted", false) and is_equal_approx(r.get("percent", 0), 3.53), "armour and negative rounding")
	r = ask(&"ArmourProtectionCalculateRequested", {"armour":100, "percent_sources":[50]})
	check(r.get("accepted", false) and is_equal_approx(r.get("percent", 0), 75), "protection cap")
	check(not ask(&"ArmourProtectionCalculateRequested", {"armour":-1}).get("accepted", false), "negative armour rejected")
	print("Agreed rules tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
