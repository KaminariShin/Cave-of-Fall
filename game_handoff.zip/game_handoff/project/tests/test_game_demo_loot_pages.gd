extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(v: bool, s: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",s)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func key(game: Node,k: Key) -> void:
	var e:=InputEventKey.new();e.keycode=k;e.pressed=true;game._unhandled_key_input(e)
func click(game: Control,pos: Vector2) -> void:
	var e:=InputEventMouseButton.new();e.position=game.get_global_transform_with_canvas()*pos;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;game._input(e)
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	game.size=Vector2(1280,720)
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	var body: Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]
	var tile: Vector2i=body["anchor"]+Vector2i(2,2)
	for i in range(9):
		var id:=StringName("ground_page_%02d"%i)
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"create")
		check(ask(&"LootInventoryDropRequested",{"entity":game.HERO,"item":id,"tile":tile}).get("accepted",false) and driver.advance_steps(10)==10,"drop")
	check(ask(&"FogDetectionRadiusSetRequested",{"entity":game.HERO,"radius":0.0}).get("accepted",false),"limit vision")
	key(game,KEY_E)
	check(not game._pickup_open and game._pickup_candidates().is_empty(),"hidden ground contents not revealed")
	check(ask(&"FogDetectionRadiusSetRequested",{"entity":game.HERO,"radius":5.0}).get("accepted",false),"restore vision")
	key(game,KEY_E)
	check(game._pickup_open and game._pickup_candidates().size()==9,"opens paged list")
	click(game,game._pickup_control_rect(1).get_center())
	check(game._pickup_page==1,"next page mouse")
	key(game,KEY_2)
	check(game._pickup_open and driver.advance_steps(35)==35 and game._pickup_open,"keyboard select keeps window open")
	check(game._inventory_items().has(&"ground_page_08") and not game._inventory_items().has(&"ground_page_07"),"correct item selected from second page")
	key(game,KEY_ESCAPE)
	check(not game._pickup_open and game._pickup_candidates().size()==8,"cancel without pickup")
	game.queue_free();await process_frame
	print("Loot selection pages: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
