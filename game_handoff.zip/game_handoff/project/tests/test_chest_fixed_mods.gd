extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11)}).get("accepted",false), "chest")
	var state := {"calls":0, "fail_at":20, "nested":true, "save":true}
	var rng := func(e):
		state["calls"] += 1
		if state["calls"] > 17 and state["nested"]:
			state["nested"] = ask(&"DungeonChestEquipmentModDraftRequested", {"base_id":&"sword_simple", "item_level":5, "rarity":&"magic"}).get("accepted", true)
			state["save"] = ask(&"SessionSaveRequested", {}).get("accepted",true)
		e["value"] = 700 if state["calls"] in [5,9,13,17] else e["min"]
		if state["calls"] == state["fail_at"]: e["value"] = e["max"]+1
	bus.subscribe(&"RngIntRequested", rng)
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var failed := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	check(not failed.get("accepted",true) and failed.get("rolled_back",false) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "failure during mod roll rolls everything back")
	check(not state["nested"] and not state["save"], "reentry and save blocked during mod roll")
	state["calls"] = 0; state["fail_at"] = -1
	var result := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12})
	bus.unsubscribe(&"RngIntRequested",rng)
	check(result.get("accepted",false), "attach fixed mods")
	if not result.get("accepted",false): quit(1); return
	var draft: Dictionary = result["draft"].duplicate(true)
	check(draft["slots"].size() == 4 and not draft["complete"], "four slots remain incomplete")
	for slot in draft["slots"]:
		var ids: Array = []
		for mod in slot["mods"]: ids.append(mod["id"])
		check(slot["rarity"] == &"magic" and ids == [&"pre_strength", &"pre_agile", &"suf_physical_damage", &"suf_perception"], "fixed unique mod IDs and limits")
	var current: Dictionary = saver.collect_world_transition_snapshot()
	check(current.get("valid",false) and before["payload"]["sections"]["items"]["instances"] == current["payload"]["sections"]["items"]["instances"], "no items created")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false), "save")
	var f := FileAccess.open("user://session.save", FileAccess.READ)
	var saved: Dictionary = bytes_to_var(f.get_buffer(f.get_length())); f.close()
	for corruption in [0,1,2,3]:
		var invalid: Dictionary = saved.duplicate(true)
		var mods: Array = invalid["sections"]["objects"]["objects"][&"chest"]["content_draft"]["slots"][0]["mods"]
		match corruption:
			0: mods[0]["value"] = 999
			1: mods[1]["id"] = mods[0]["id"]
			2: mods.remove_at(0)
			3: mods[0]["material_id"] = &"cloth_runic"
		f = FileAccess.open("user://session.save", FileAccess.WRITE); f.store_buffer(var_to_bytes(invalid)); f.close()
		check(not ask(&"SessionLoadRequested",{}).get("accepted",true), "invalid saved mod rejected %d" % corruption)
	f = FileAccess.open("user://session.save", FileAccess.WRITE); f.store_buffer(var_to_bytes(saved)); f.close()
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"ObjectGetRequested", {"object":&"chest"})["data"]["content_draft"] == draft, "fixed mod plan persists")
	check(not ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":12}).get("accepted",true), "no reroll")
	print("Fixed chest mod tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
