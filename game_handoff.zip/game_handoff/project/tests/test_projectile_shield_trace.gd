extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(v:bool,label:String)->void:
	if not v:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func run()->void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,30)}).get("accepted",false),"map")
	var floors:Array=[]
	for x in range(40):
		for y in range(30):floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"first",&"second",&"shooter"]:check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"ControlledEntityRequested",{"entity":&"first"}).get("accepted",false),"control")
	for entry in [[&"first",Vector2i(10,10),&"s1"],[&"second",Vector2i(20,10),&"s2"]]:
		check(ask(&"SpaceBodyPlaceRequested",{"entity":entry[0],"anchor":entry[1],"size":4}).get("accepted",false),"body")
		check(ask(&"ItemCreateRequested",{"id":entry[2],"base_id":&"shield_small","item_level":1}).get("accepted",false),"shield item")
		check(ask(&"ComponentSetRequested",{"entity":entry[0],"component":&"equipment","data":{"off":entry[2]}}).get("accepted",false),"equip")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"shooter","anchor":Vector2i(2,10),"size":2}).get("accepted",false),"shooter")
	var service=root.get_node("ProjectileService")
	var bodies:Array=service._body_snapshot()
	check(not service._first_shield(Vector2(4,12.5),Vector2.RIGHT,25.0,bodies,&"shooter").get("hit",true),"inactive shield ignored")
	check(ask(&"ShieldBlockStartRequested",{"entity":&"first","slot":"off","direction":Vector2i.LEFT}).get("accepted",false),"first shield active")
	check(ask(&"ShieldBlockStartRequested",{"entity":&"second","slot":"off","direction":Vector2i.LEFT}).get("accepted",false),"second shield active")
	var firstzone:Dictionary=ask(&"ShieldBlockZoneRequested",{"entity":&"first"})
	var tile:Vector2i=firstzone["data"]["tiles"][0]
	var trace:Dictionary=service._first_shield(Vector2(4,float(tile.y)+0.5),Vector2.RIGHT,25.0,bodies,&"shooter")
	check(trace.get("hit",false) and trace.get("entity",null)==&"first" and trace.get("tile",null)==tile and is_equal_approx(trace.get("distance",-1.0),float(tile.x)-4.0),"nearest actual shield")
	trace=service._first_shield(Vector2(4,float(tile.y)+0.5),Vector2.RIGHT,3.0,bodies,&"shooter")
	check(not trace.get("hit",true),"limited segment")
	trace=service._first_shield(Vector2(4,float(tile.y)+0.5),Vector2.RIGHT,25.0,bodies,&"first")
	check(trace.get("hit",false) and trace.get("entity",null)==&"second","own shield excluded")
	var start:=Vector2(tile)+Vector2(-2,-2)
	var d:=Vector2.ONE.normalized()
	trace=service._first_shield(start,d,6.0,bodies,&"shooter")
	check(trace.get("hit",false) and trace.get("entity",null)==&"first","diagonal segment crosses shield")
	var ray_start:=Vector2(4,float(tile.y)+0.5)
	var contact:Dictionary=service._trace_arrow_contact(ray_start,Vector2.RIGHT,25.0,bodies,&"shooter")
	check(contact.get("kind","")=="shield" and contact.get("entity",null)==&"first","shield precedes body")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[Vector2i(6,tile.y)],"kind":0}).get("accepted",false),"place wall")
	contact=service._trace_arrow_contact(ray_start,Vector2.RIGHT,25.0,bodies,&"shooter")
	check(contact.get("kind","")=="wall" and contact.get("tile",null)==Vector2i(6,tile.y),"wall precedes shield")
	check(ask(&"SpaceTilesSetRequested",{"tiles":[Vector2i(6,tile.y)],"kind":1}).get("accepted",false),"restore floor")
	var artificial_bodies:Array=[{"entity":&"other","position":Vector2(7,tile.y),"size":1}]
	artificial_bodies.append_array(bodies)
	contact=service._trace_arrow_contact(ray_start,Vector2.RIGHT,25.0,artificial_bodies,&"shooter")
	check(contact.get("kind","")=="body" and contact.get("entity",null)==&"other","another body precedes shield")
	contact=service._trace_arrow_contact(ray_start,Vector2.RIGHT,1.0,bodies,&"shooter")
	check(not contact.get("hit",true),"no contact within segment")
	var stamina:float=ask(&"ResourceGetRequested",{"entity":&"first","resource":&"Stamina"})["data"]["current"]
	var t:float=driver.game_time
	trace=service._first_shield(Vector2(4,float(tile.y)+0.5),Vector2.RIGHT,25.0,bodies,&"shooter")
	check(driver.game_time==t and ask(&"ResourceGetRequested",{"entity":&"first","resource":&"Stamina"})["data"]["current"]==stamina,"trace has no gameplay cost")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save blocking")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load blocking")
	bodies=service._body_snapshot()
	trace=service._first_shield(Vector2(4,float(tile.y)+0.5),Vector2.RIGHT,25.0,bodies,&"shooter")
	check(trace.get("hit",false) and trace.get("entity",null)==&"first","trace preserved after save")
	print("Projectile shield trace foundation: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
