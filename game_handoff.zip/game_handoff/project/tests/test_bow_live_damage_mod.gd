extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func preview() -> Dictionary: return ask(&"BowShotDamagePreviewRequested",{"entity":&"hero","item":&"bow","strike":"bow_simple_shot"})
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(50,20)}).get("accepted",false),"map")
	var tiles: Array = []
	for x in range(50):
		for y in range(20): tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":tiles,"kind":1}).get("accepted",false),"floor")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false) and ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(2,5),"size":2}).get("accepted",false),"body")
	check(ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":100}).get("accepted",false),"inventory")
	check(ask(&"StatBaseSetRequested",{"entity":&"hero","stat":&"DEX","value":5}).get("accepted",false) and ask(&"StatBaseSetRequested",{"entity":&"hero","stat":&"INT","value":100}).get("accepted",false),"stats")
	var bases: Dictionary = root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"bow_simple",bases)
	var mats := [{"material_id":"leather_thin","count":1}]
	check(ask(&"ItemCreateRequested",{"id":&"bow","base_id":&"bow_simple","item_level":1,"rarity":&"magic","materials":mats,"learning":schema}).get("accepted",false),"bow")
	var mod := {"id":&"suf_physical_damage","category":"suffix","stat":"physical_damage","tier":3,"value":1.0,"level_req":1,"material_id":&"leather_thin","unlock_after":5}
	check(ask(&"ItemModAttachRequested",{"item":&"bow","mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":&"hero","item":&"bow"}).get("accepted",false),"mod and inventory")
	var equip := ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"bow","slot":"main"})
	check(equip.get("accepted",false) and driver.advance_steps(10)==10,"real equip")
	if not equip.get("accepted",false): quit(1); return
	var injected := mod.duplicate(true); injected["id"] = &"suf_physical_damage_other"
	check(not ask(&"ItemModAttachRequested",{"item":&"bow","mod":injected}).get("accepted",true),"equipped item rejects unsupported draft mod")
	check(preview().get("data",{}).get("physical_mod_bonus",-1)==0.0,"unknown affix inactive")
	for i in range(5):
		check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"Stamina","value":20}).get("accepted",false),"stamina")
		var shot := ask(&"BowShotStartRequested",{"entity":&"hero","item":&"bow","direction":Vector2.RIGHT})
		check(shot.get("accepted",false),"shot %d" % i)
		if shot.get("accepted",false): driver.advance_steps(shot["data"]["duration_steps"])
	check(ask(&"ItemGetRequested",{"item":&"bow"})["item_data"]["learning_state"]["progress"]==5,"five completed shots")
	check(preview().get("data",{}).get("physical_mod_bonus",0)==1.0 and preview().get("data",{}).get("nonnegative_damage",0)==8.0,"revealed affix increases damage")
	# После переноса точки выпуска ранее выпущенные стрелы летят дольше.
	check(driver.wait_for(2.0),"wait for earlier arrows")
	driver.advance_steps(200)
	check(ask(&"ProjectilesGetRequested",{}).get("projectiles",{}).is_empty(),"old arrows expired before spawning target")
	check(ask(&"EntityCreateRequested",{"entity":&"target"}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested",{"entity":&"target","anchor":Vector2i(12,5),"size":2}).get("accepted",false),"target")
	var hp: float = ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"]
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save")
	for run_index in range(2):
		if run_index == 1: check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load")
		check(ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"Stamina","value":20}).get("accepted",false),"refill")
		var shot := ask(&"BowShotStartRequested",{"entity":&"hero","item":&"bow","direction":Vector2.RIGHT})
		check(shot.get("accepted",false),"live shot")
		if shot.get("accepted",false):
			driver.advance_steps(shot["data"]["duration_steps"])
			if ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"] == hp:
				check(driver.wait_for(1.0),"wait for arrow flight")
				driver.advance_steps(100)
		check(ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"]==hp-8,"actual arrow deals modded damage %d" % run_index)
	print("Bow live damage mod: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
