extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(v:bool,label:String)->void:
	if not v:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func hp()->float:return float(ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"])
func run()->void:
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,20)}).get("accepted",false),"map")
	var floors:Array=[]
	for x in range(40):
		for y in range(20):floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"archer",&"target"]:check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"entity")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"archer","anchor":Vector2i(2,5),"size":2}).get("accepted",false),"archer")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"target","anchor":Vector2i(15,5),"size":2}).get("accepted",false),"target")
	var before:=hp()
	var arrow:=ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10,"damage":7})
	check(arrow.get("accepted",false),"launch")
	check(ask(&"CombatDamageRequested",{"entity":&"archer","amount":10000}).get("accepted",false),"archer dies")
	check(ask(&"EntityRemoveRequested",{"entity":&"archer"}).get("accepted",false),"remove archer")
	check(ask(&"ProjectileGetRequested",{"id":arrow.get("id",&"")}).get("found",false),"independent arrow survives owner removal")
	check(driver.wait_for(1.0) and driver.advance_steps(20)==20,"advance flight")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save after owner removal")
	check(driver.advance_steps(60)>0 and hp()==before-7,"arrow hits after owner removal")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and hp()==before,"restore orphaned projectile")
	check(driver.advance_steps(60)>0 and hp()==before-7,"restored orphaned arrow hits once")
	print("Bow arrow survives removed owner: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
