extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	ask(bus, &"SpaceMapConfigureRequested", {"size": Vector2i(20,20)})
	var floors: Array = []
	for x in range(20):
		for y in range(20): floors.append(Vector2i(x,y))
	ask(bus, &"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})
	ask(bus, &"MaterialRegisterRequested", {"material": {"id": "m", "name": "M", "weight_per_unit": 1, "volume_per_unit": 1, "level": 1}})
	ask(bus, &"ItemBaseRegisterRequested", {"base": {"id": "b", "name": "B", "materials": [{"material_id": "m", "count": 1}]}})
	for id in [&"hero", &"enemy1", &"enemy2"]:
		check(entities.create_entity(id), "entity")
	for p in [[&"hero",Vector2i(2,2)],[&"enemy1",Vector2i(8,8)],[&"enemy2",Vector2i(12,12)]]:
		check(ask(bus, &"SpaceBodyPlaceRequested", {"entity": p[0], "anchor": p[1], "size": 2})["accepted"], "body")
	ask(bus, &"ControlledEntityRequested", {"entity": &"hero"})
	for pair in [[&"enemy1", &"item1"], [&"enemy2", &"item2"]]:
		check(ask(bus, &"ItemCreateRequested", {"id": pair[1], "base_id": &"b", "item_level": 1})["accepted"], "item")
		ask(bus, &"InventoryConfigureRequested", {"entity": pair[0], "volume": 2})
		check(ask(bus, &"InventoryAddRequested", {"entity": pair[0], "item": pair[1]})["accepted"], "inventory")
	var nested := {"done": false}
	bus.subscribe(&"LootItemDropped", func(e):
		if e["item"] == &"item1" and not nested["done"]:
			nested["done"] = true
			ask(bus, &"CombatDamageRequested", {"entity": &"enemy2", "source": &"hero", "amount": 999})
	)
	check(ask(bus, &"CombatDamageRequested", {"entity": &"enemy1", "source": &"hero", "amount": 999})["accepted"], "first death")
	var loot: Dictionary = ask(bus, &"LootGetRequested", {})["items"]
	check(nested["done"] and loot.has(&"item1") and loot.has(&"item2") and loot[&"item2"]["tile"] == Vector2i(13,13), "nested death is queued and retains its corpse position")
	check(ask(bus, &"SessionSaveRequested", {})["accepted"] and ask(bus, &"SessionLoadRequested", {})["accepted"], "nested drops save and restore")
	print("Reentrant loot tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
