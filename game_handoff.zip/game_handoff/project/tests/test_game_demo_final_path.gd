extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func reverse(d: String) -> String:
	return {"east":"west","west":"east","north":"south","south":"north"}[d]
func run() -> void:
	bus = root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var path := "user://demo_session.save"
	var existed := FileAccess.file_exists(path)
	var old := PackedByteArray()
	if existed:
		var f := FileAccess.open(path,FileAccess.READ); old=f.get_buffer(f.get_length()); f.close()
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"initialized")
	# Тестовый перевод на четвёртый этаж и вручную соединённый маршрут:
	# это не проверка естественного четырёхэтажного прохождения.
	var tracker = root.get_node("DungeonMilestoneService")
	var state: Dictionary = tracker.get("_floor")
	state["floor"]=4
	var stats = root.get_node("RunStatisticsService")
	stats.get("_data")["floor"]=4
	var positions := [Vector2i(23,12),Vector2i(35,12),Vector2i(35,24),Vector2i(23,24),Vector2i(11,24),Vector2i(11,36),Vector2i(23,36),Vector2i(35,36),Vector2i(35,48),Vector2i(47,48),Vector2i(47,36),Vector2i(47,24),Vector2i(47,12),Vector2i(47,0),Vector2i(35,0),Vector2i(23,0)]
	var dirs := ["east","east","south","west","west","south","east","east","south","east","north","north","north","north","west","west"]
	var parent: StringName = game.ROOM
	for i in range(positions.size()):
		var id := StringName("boss_test_%02d" % i)
		var out := &"east" if i == 0 else StringName("boss_test_out_%02d" % i)
		check(ask(&"RoomCreateRequested",{"id":id,"type":"passage","origin_cell":positions[i],"size_cells":Vector2i(12,12)}).get("accepted",false),"room %d" % i)
		if i > 0: check(ask(&"RoomExitAddRequested",{"room":parent,"id":out,"dir":dirs[i],"offset_cells":5}).get("accepted",false),"parent exit %d" % i)
		check(ask(&"RoomExitAddRequested",{"room":id,"id":&"entry","dir":reverse(dirs[i]),"offset_cells":5}).get("accepted",false),"entry %d" % i)
		check(ask(&"RoomExitConnectRequested",{"room":parent,"exit":out,"other_room":id,"other_exit":&"entry"}).get("accepted",false),"connect %d" % i)
		if i == 15:
			var floor_tiles: Array = []
			for y in range(positions[i].y*4+1,positions[i].y*4+47):
				for x in range(positions[i].x*4+1,positions[i].x*4+47): floor_tiles.append(Vector2i(x,y))
			check(ask(&"SpaceTilesSetRequested",{"tiles":floor_tiles,"kind":1}).get("accepted",false),"clear test boss room")
		ask(&"RoomChildGenerated",{"room":parent,"child":id,"type":"passage"})
		parent=id
	var tracking := ask(&"DungeonFloorTrackingGetRequested",{})
	check(tracking.get("data",{}).get("boss_candidate",null)==parent,"boss candidate selected")
	if tracking.get("data",{}).get("boss_candidate",null)!=parent: quit(1); return
	# Генерируем реальную комнату портала за выбранной комнатой босса.
	check(ask(&"RoomExitAddRequested",{"room":parent,"id":&"portal_out","dir":"west","offset_cells":5}).get("accepted",false),"boss room portal exit")
	check(ask(&"RoomGenerationConfigureRequested",{"deadend_budget":1}).get("accepted",false),"portal budget")
	var placement_errors: Array = []
	var trials := {"total":0,"rejected":0}
	var trial_observer := func(e):
		trials["total"] += 1
		if not e.get("accepted",false): trials["rejected"] += 1
	bus.subscribe(&"DungeonPortalPlacementFailed",func(e): placement_errors.append(e.duplicate(true)))
	bus.subscribe(&"DungeonPortalTrialRequested",trial_observer)
	var generated := ask(&"RoomChildGenerateRequested",{"room":parent,"exit":&"portal_out"})
	bus.unsubscribe(&"DungeonPortalTrialRequested",trial_observer)
	check(generated.get("accepted",false),"generate portal room " + str(generated))
	check(trials["total"] > 0 and placement_errors.is_empty(),"portal trial before successful placement " + str(trials))
	if not generated.get("accepted",false): quit(1); return
	var portal := ask(&"DungeonPortalGetRequested",{})
	check(portal.get("found",false) and portal.get("data",{}).get("status","")=="placed","real portal placed " + str(portal) + " result " + str(generated) + " errors " + str(placement_errors))
	if not portal.get("found",false) or portal.get("data",{}).get("status","")!="placed": quit(1); return
	check(ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null}).get("accepted",false),"remove bounds")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":positions[15]*4+Vector2i(25,25)}).get("accepted",false),"teleport into boss room")
	check(ask(&"RoomEnterRequested",{"entity":game.HERO,"room":parent}).get("accepted",false),"enter boss room")
	await process_frame
	await process_frame
	await process_frame
	var boss := ask(&"DungeonBossGetRequested",{})
	check(boss.get("found",false),"boss spawned")
	if not boss.get("found",false): quit(1); return
	var id: StringName = boss["data"]["entity"]
	check(boss["data"].get("loadout",null) is Dictionary and ask(&"AIGetRequested",{"entity":id}).get("data",{}).get("role","")=="melee","real boss equipped with common AI")
	# Быстрый автопоиск может успеть раньше теста; иначе используем
	# прежний ограниченный ручной поиск, не создавая второй сундук.
	var auto := ask(&"DungeonBossChestAutoStatusRequested",{})
	var chest_id: StringName = auto.get("object",&"") if auto.get("status","")=="created" else &"test_boss_chest"
	var search: Dictionary = {}
	if auto.get("status","")=="created":
		var obj: Dictionary = ask(&"ObjectGetRequested",{"object":chest_id})["data"]
		search = ask(&"DungeonChestPositionPreflightRequested",{"room":parent,"tile":obj["tile"],"existing_object":chest_id})
		check(search.get("accepted",false),"existing automatic chest safe")
	else:
		root.get_node("DungeonBossChestAutoService")._reset({})
		search = ask(&"DungeonChestPositionSearchRequested",{"room":parent})
		var cursor := 0
		while search.get("accepted",false) and not search.get("found",false) and not search.get("complete",false) and cursor < 2304:
			cursor = search["next_cursor"]
			search = ask(&"DungeonChestPositionSearchRequested",{"room":parent,"cursor":cursor})
		check(search.get("found",false),"safe boss chest position")
		if not search.get("found",false): quit(1); return
		var provision := ask(&"DungeonBossChestProvisionRequested",{"room":parent,"candidate":search["tile"],"chest_id":chest_id})
		check(provision.get("accepted",false),"boss chest provisioned " + str(provision))
		if not provision.get("accepted",false): quit(1); return
	if not search.has("interaction_anchor"): quit(1); return
	var items: Array = ask(&"InventoryGetRequested",{"entity":chest_id})["data"]["items"].duplicate()
	check(items.size() >= 4 and items.size() <= 8,"fixed 4-8 chest items")
	check(ask(&"CombatDamageRequested",{"entity":id,"source":game.HERO,"amount":999999}).get("accepted",false),"test defeats boss by injected damage")
	ask(&"CombatDetectionChanged",{"entity":game.HERO,"active":false})
	var target: Vector2i = search["interaction_anchor"]
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":target}).get("accepted",false),"test teleport to chest")
	check(game._interact_chest() and root.get_node("TimeDriver").advance_steps(10)==10,"open actual boss chest via demo")
	check(game._interact_chest() and game._pickup_open and game._pickup_item(items[0]) and root.get_node("TimeDriver").advance_steps(10)==10,"select and take actual boss chest item")
	check(ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"].has(items[0]),"boss item transferred")
	if game._pickup_open: game._pickup_close()
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save before victory")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load before victory")
	var portal_obj: Dictionary = ask(&"ObjectGetRequested",{"object":portal["data"]["object"]})["data"]
	var tile: Vector2i = portal_obj["tile"]
	var room: Dictionary = ask(&"RoomGetRequested",{"id":generated["child"]})["data"]
	var bounds := {"origin":room["origin_cell"]*4,"size":room["size_cells"]*4}
	var anchor := Vector2i(-1,-1)
	for y in range(tile.y-4,tile.y+2):
		for x in range(tile.x-4,tile.x+2):
			var a := Vector2i(x,y)
			var adjacent := ((tile.x==a.x-1 or tile.x==a.x+4) and tile.y>=a.y and tile.y<a.y+4) or ((tile.y==a.y-1 or tile.y==a.y+4) and tile.x>=a.x and tile.x<a.x+4)
			if adjacent and ask(&"SpaceBodyFitsRequested",{"anchor":a,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false): anchor=a; break
		if anchor.x>=0: break
	check(anchor.x>=0,"portal adjacent anchor")
	ask(&"SpaceBodyRoomSetRequested",{"entity":game.HERO,"room":null})
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":anchor}).get("accepted",false),"test teleport near portal")
	check(ask(&"RoomEnterRequested",{"entity":game.HERO,"room":generated["child"]}).get("accepted",false),"enter portal room")
	ask(&"CombatDetectionChanged",{"entity":game.HERO,"active":false})
	var time: float = root.get_node("TimeDriver").game_time
	check(game._interact_chest() and game.is_won and root.get_node("TimeDriver").game_time==time,"real portal victory via demo without time")
	check(ask(&"RunStatisticsGetRequested",{})["data"]["outcome"]=="victory" and game._restart_button.visible,"victory result")
	game._restart_button.pressed.emit()
	check(not game.is_won and game.message=="Новый забег начат." and not FileAccess.file_exists(path),"new run after actual portal victory")
	check(ask(&"DungeonFloorTrackingGetRequested",{})["data"]["floor"]==1 and not ask(&"ItemGetRequested",{"item":items[0]}).get("found",true),"no boss loot carried")
	game.queue_free()
	await process_frame
	if existed:
		var f := FileAccess.open(path,FileAccess.WRITE); f.store_buffer(old); f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo final path: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
