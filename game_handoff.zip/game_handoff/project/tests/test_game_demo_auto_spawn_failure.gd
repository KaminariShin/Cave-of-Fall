extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var path := "user://demo_session.save"
	var old_exists := FileAccess.file_exists(path)
	var old := PackedByteArray()
	if old_exists:
		var f := FileAccess.open(path,FileAccess.READ); old = f.get_buffer(f.get_length()); f.close()
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"initialized")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet start")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":Vector2i(87,68)}).get("accepted",false),"door")
	for i in range(5):
		check(game._move(Vector2i.RIGHT),"walk")
		driver.advance_steps(100)
	var room: StringName = game.current_room
	check(room != game.ROOM,"child entered")
	var reject_depth := func(e):
		if e.get("room",null) == room: e["accepted"] = false
	bus.subscribe(&"DungeonRoomDepthRequested",reject_depth)
	await process_frame
	await process_frame
	check(game._spawn_errors.has(room) and game.message.contains("Спавн не выполнен"),"failure visible")
	check(not ask(&"RoomSpawnStatusRequested",{"room":room}).get("spawned",false),"failed room not marked")
	bus.unsubscribe(&"DungeonRoomDepthRequested",reject_depth)
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save failure")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load failure")
	await process_frame
	check(game._spawn_errors.has(room) and not ask(&"RoomSpawnStatusRequested",{"room":room}).get("spawned",false),"failure persists without silent retry")
	var retry_key := InputEventKey.new()
	retry_key.pressed = true; retry_key.keycode = KEY_R
	game._unhandled_key_input(retry_key)
	await process_frame
	await process_frame
	var status := ask(&"RoomSpawnStatusRequested",{"room":room})
	check(status.get("spawned",false) and not game._spawn_errors.has(room),"R retries and spawns")
	for id in status.get("data",{}).get("placed",[]): check(ask(&"DemoMeleeSetupStatusRequested",{"entity":id}).get("status","") == "installed","retry equipment")
	game.queue_free()
	await process_frame
	if old_exists:
		var f := FileAccess.open(path,FileAccess.WRITE); f.store_buffer(old); f.close()
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo auto spawn failure: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
