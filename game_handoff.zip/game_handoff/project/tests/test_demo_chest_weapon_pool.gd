extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func run() -> void:
	bus=root.get_node("EventBus")
	root.get_node("TimeDriver").set_process(false)
	var rules:=ask(&"RulesetGetRequested",{})
	var pool:Array=rules["ruleset"]["parameters"]["chest_draft_pools"]["equipment"]
	var service=root.get_node("DungeonChestContentDraftService")
	var item_service=root.get_node("ItemService")
	var valid:Array=service._validated_pool("equipment",item_service.get("_bases"))
	check(valid.size()==pool.size() and valid.size()==9,"equipment pool valid")
	var weapons:Array=[]
	var total:=0
	for row in valid:
		total+=int(row["weight"])
		var base:=ask(&"ItemBaseGetRequested",{"base_id":row["id"]})
		check(base.get("found",false),"base exists")
		if base.get("data",{}).get("slot","")=="weapon":
			weapons.append(row["id"])
			check(str(base["data"].get("weapon_variant","")) in ["sword_simple_variant","hammer_simple_variant","bow_simple_variant"],"weapon attack implemented")
	check(weapons==[&"sword_simple",&"hammer_simple",&"bow_simple"],"sword hammer and bow appear in weapon pool")
	check(total==20,"weights sum to 20")
	var values := {"roll":0}
	var force := func(e): e["value"]=values["roll"]
	bus.subscribe(&"RngIntRequested",force)
	var counts:={}
	for i in range(total):
		values["roll"]=i
		var picked: StringName=service._pick(valid,{"error":""})
		counts[picked]=counts.get(picked,0)+1
		check(picked not in [&"staff_simple",&""],"every weighted outcome excludes unimplemented weapon")
	bus.unsubscribe(&"RngIntRequested",force)
	for row in valid:check(counts.get(row["id"],0)==int(row["weight"]),"weight for " + str(row["id"]))
	print("Demo chest weapon pool: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
