extends SceneTree
var failures:=0
func _initialize()->void:call_deferred("run")
func check(ok:bool,label:String)->void:
	if not ok:failures+=1;printerr("FAIL: ",label)
func ask(id:StringName,e:Dictionary)->Dictionary:
	root.get_node("EventBus").publish(id,e);return e
func hp()->Dictionary:return ask(&"ResourceGetRequested",{"entity":&"hero","resource":&"HP"})["data"]
func stat(id:StringName,value:float)->bool:return ask(&"StatBaseSetRequested",{"entity":&"hero","stat":id,"value":value}).get("accepted",false)
func sethp(value:float)->bool:return ask(&"ResourceSetRequested",{"entity":&"hero","resource":&"HP","value":value}).get("accepted",false)
func run()->void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false),"entity")
	check(stat(&"CON",16) and hp()["max"]==100 and hp()["current"]==100,"full 45 becomes full 100")
	check(sethp(75) and ask(&"SessionSaveRequested",{}).get("accepted",false),"save 75 percent")
	check(stat(&"CON",36) and hp()["max"]==200 and hp()["current"]==150,"75 of 100 becomes 150 of 200")
	check(stat(&"CON",16) and hp()["max"]==100 and hp()["current"]==75,"reverse preserves percentage")
	check(stat(&"CON",6) and hp()["max"]==50 and hp()["current"]==38,"37.5 rounds to nearest 38")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and hp()["max"]==100 and hp()["current"]==75,"save restores fraction")
	check(stat(&"CON",36) and hp()["current"]==150,"same result after load")
	check(sethp(0) and stat(&"CON",16) and hp()["current"]==0,"zero never revived by max change")
	check(sethp(1) and stat(&"CON",-2) and hp()["max"]==10 and hp()["current"]==1,"positive HP retains one at smaller positive maximum")
	check(sethp(7.5) and stat(&"WIS",9) and hp()["current"]==7.5,"unrelated stat does not round or change HP")
	check(sethp(0) and stat(&"CON",-4) and hp()["max"]==0 and stat(&"CON",16) and hp()["max"]==100 and hp()["current"]==0,"zero maximum does not resurrect")
	print("HP percentage on maximum changes: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
