extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(40,20)}).get("accepted",false),"map")
	var floors: Array = []
	for x in range(40):
		for y in range(20): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":floors,"kind":1}).get("accepted",false),"floor")
	for id in [&"archer",&"target"]: check(ask(&"EntityCreateRequested",{"entity":id}).get("accepted",false),"create")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"archer","anchor":Vector2i(2,5),"size":2}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested",{"entity":&"target","anchor":Vector2i(20,5),"size":2}).get("accepted",false),"bodies")
	var a := ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":7.0})
	var b := ask(&"ProjectileLaunchRequested",{"entity":&"archer","weapon_type":"bow","direction":Vector2.RIGHT,"speed":10.0,"damage":9.0})
	check(a.get("accepted",false) and b.get("accepted",false),"two arrows")
	var sa: Dictionary = ask(&"ProjectileGetRequested",{"id":a["id"]})["data"]
	var sb: Dictionary = ask(&"ProjectileGetRequested",{"id":b["id"]})["data"]
	var hp: float = ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"]
	var contacts := [{"shot":sb,"target":&"target","attack_tiles":[Vector2i(19,6)]},{"shot":sa,"target":&"target","attack_tiles":[Vector2i(19,6)]}]
	check(not ask(&"ProjectilePhasePlanRequested",{"contacts":contacts}).get("accepted",true),"outside phase rejected")
	check(ask(&"CombatDamageRequested",{"entity":&"archer","amount":10000}).get("accepted",false) and ask(&"EntityRemoveRequested",{"entity":&"archer"}).get("accepted",false),"owner removed")
	var observed := {"called":false}
	var protection := func(e):
		if e.get("entity",null)==&"target" and e.get("damage_type","")=="physical": e["percent"] = 50.0
	var phase := func(_e):
		observed["called"] = true
		var plan := ask(&"ProjectilePhasePlanRequested",{"contacts":contacts})
		check(plan.get("accepted",false),"plan two contacts after owner removal: " + str(plan))
		if plan.get("accepted",false):
			var hits: Array = plan["data"]["hits"]
			check(hits.size()==2 and hits[0]["hit_id"]==a["id"] and hits[1]["hit_id"]==b["id"],"stable independent IDs")
			check(hits[0]["damage"]==4 and hits[1]["damage"]==5 and hits[0]["hp_before"]==int(hp) and hits[1]["hp_before"]==int(hp),"protection, ceil and common HP")
			check(hits[0]["source"]==&"archer" and hits[0]["attack_tiles"]==[Vector2i(19,6)],"owner attribution and contact tile")
		check(not ask(&"ProjectilePhasePlanRequested",{"contacts":[contacts[0],contacts[0]]}).get("accepted",true),"duplicate arrow rejected")
		var corrupt: Array = contacts.duplicate(true); corrupt[0]["shot"]["direct_damage"] = NAN
		check(not ask(&"ProjectilePhasePlanRequested",{"contacts":corrupt}).get("accepted",true),"invalid damage rejected")
		var noise := func(q):
			if q.get("entity",null)==&"target" and q.get("target",null)=="damage.incoming":
				ask(&"ResourceSetRequested",{"entity":&"target","resource":&"HP","value":hp-1})
		bus.subscribe(&"PipelineEvaluateRequested",noise)
		check(not ask(&"ProjectilePhasePlanRequested",{"contacts":contacts}).get("accepted",true),"resource mutation during planning rejects whole plan")
		bus.unsubscribe(&"PipelineEvaluateRequested",noise)
		ask(&"ResourceSetRequested",{"entity":&"target","resource":&"HP","value":hp})
	bus.subscribe(&"PeriodicProtectionGetRequested",protection); bus.subscribe(&"TimeCombatPhase",phase)
	check(driver.wait_for(0.01) and driver.advance_steps(1)==1,"run phase")
	bus.unsubscribe(&"PeriodicProtectionGetRequested",protection); bus.unsubscribe(&"TimeCombatPhase",phase)
	check(observed["called"] and ask(&"ResourceGetRequested",{"entity":&"target","resource":&"HP"})["data"]["current"]==hp,"planning does not apply damage")
	print("Projectile phase planner: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
