extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func resource(actor: StringName, name: StringName) -> Dictionary:
	return ask(&"ResourceGetRequested", {"entity":actor,"resource":name}).get("data",{})
func state(id: StringName) -> Dictionary:
	return ask(&"ItemGetRequested", {"item":id})["item_data"]["learning_state"]
func wait(driver, actor: StringName, steps: int = 1) -> bool:
	return ask(&"ActionStartRequested", {"entity":actor,"action":&"wait","duration":steps*0.01}).get("accepted",false) and driver.advance_steps(steps) == steps
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":20}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":20}).get("accepted",false), "control and inventory")
	for actor in [&"hero",&"npc"]:
		for key in [&"CON",&"STR",&"DEX",&"INT",&"WIS"]:
			check(ask(&"StatBaseSetRequested", {"entity":actor,"stat":key,"value":10}).get("accepted",false), "base stats")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"armor_cloth_body",bases)
	var cases := [
		{"resource":&"HP", "id":&"affix_hp", "stat":"max_hp", "baseline":90.0},
		{"resource":&"Stamina", "id":&"affix_stamina", "stat":"max_stamina", "baseline":110.0},
		{"resource":&"MP", "id":&"affix_mana", "stat":"max_mp", "baseline":50.0}]
	for index in range(cases.size()):
		var c: Dictionary = cases[index]
		var id := StringName("affix_%d" % index)
		var mod := {"id":c["id"],"category":"affix","stat":c["stat"],"tier":3,"value":4.0,"level_req":1,"material_id":&"cloth_light","unlock_after":5}
		check(ask(&"ItemCreateRequested", {"id":id,"base_id":&"armor_cloth_body","item_level":1,"rarity":&"magic","learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":id,"mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":id}).get("accepted",false), "create %s" % c["id"])
		check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":c["resource"],"value":c["baseline"]}).get("accepted",false), "fill before reveal")
		check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":id,"slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and resource(&"hero",c["resource"])["max"] == c["baseline"], "unknown affix inactive")
		for n in range(5): check(wait(driver,&"hero"), "progress")
		check(state(id)["progress"] == 5 and resource(&"hero",c["resource"])["max"] == c["baseline"]+4.0 and resource(&"hero",c["resource"])["current"] == c["baseline"] + (4.0 if c["resource"] == &"HP" else 0.0), "revealed max preserves HP percentage and leaves other resources %s" % c["resource"])
		check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and resource(&"hero",c["resource"])["max"] == c["baseline"]+4.0, "save/load %s" % c["resource"])
		check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":c["resource"],"value":c["baseline"]+4.0}).get("accepted",false) and ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10 and resource(&"hero",c["resource"])["max"] == c["baseline"] and resource(&"hero",c["resource"])["current"] == c["baseline"], "unequip clamps %s" % c["resource"])
	var shield_schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	var hp := {"id":&"affix_hp","category":"affix","stat":"max_hp","tier":3,"value":4.0,"level_req":1,"material_id":&"iron_common","unlock_after":5}
	check(ask(&"ItemCreateRequested", {"id":&"fresh","base_id":&"shield_small","item_level":1,"rarity":&"magic","learning":shield_schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"fresh","mod":hp}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"fresh"}).get("accepted",false), "fresh shield")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"fresh","slot":"off"}).get("accepted",false) and wait(driver,&"hero",10) and state(&"fresh")["progress"] == 0 and not state(&"fresh")["identified"] and resource(&"npc",&"HP")["max"] == 94.0, "NPC unrevealed affix")
	check(ask(&"ResourceSetRequested", {"entity":&"npc","resource":&"HP","value":94}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"npc"}).get("accepted",false) and resource(&"npc",&"HP")["max"] == 90.0 and resource(&"npc",&"HP")["current"] == 90.0, "control change removes unknown affix and clamps")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and resource(&"npc",&"HP")["max"] == 94.0 and resource(&"npc",&"HP")["current"] == 94.0, "NPC returns and full health percentage remains full")
	var mixed_hp := {"id":&"affix_hp","category":"affix","stat":"max_hp","tier":3,"value":4.0,"level_req":1,"material_id":&"cloth_light","unlock_after":5}
	var mixed_stamina := {"id":&"affix_stamina","category":"affix","stat":"max_stamina","tier":3,"value":4.0,"level_req":1,"material_id":&"cloth_light","unlock_after":10}
	check(ask(&"ItemCreateRequested", {"id":&"mixed","base_id":&"armor_cloth_body","item_level":1,"rarity":&"magic","learning":schema}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"mixed","mod":mixed_hp}).get("accepted",false) and ask(&"ItemModAttachRequested", {"item":&"mixed","mod":mixed_stamina}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"mixed"}).get("accepted",false), "two affixes")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"mixed","slot":"body"}).get("accepted",false) and driver.advance_steps(10) == 10, "equip mixed")
	for n in range(5): check(wait(driver,&"hero"),"first progress")
	check(resource(&"hero",&"HP")["max"] == 94.0 and resource(&"hero",&"Stamina")["max"] == 110.0, "first affix unlocked")
	for n in range(5): check(wait(driver,&"hero"),"second progress")
	check(resource(&"hero",&"HP")["max"] == 94.0 and resource(&"hero",&"Stamina")["max"] == 114.0, "second affix unlocked")
	var before_hp := resource(&"hero",&"HP").duplicate(true)
	var before_sp := resource(&"hero",&"Stamina").duplicate(true)
	var failure := {"count":0}
	var bad := func(e):
		if e.get("item",null) == &"mixed" and e.get("found",false): e["item_data"]["mods"][1]["value"] = 999
	var report := func(e):
		if e.get("entity",null) == &"hero" and e.get("resource",null) == &"Stamina": failure["count"] += 1
	bus.subscribe(&"ItemGetRequested",bad)
	bus.subscribe(&"ResourceMaxCalculationFailed",report)
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":11}).get("accepted",false) and failure["count"] == 1 and resource(&"hero",&"HP") == before_hp and resource(&"hero",&"Stamina") == before_sp, "invalid affix leaves all resources intact")
	bus.unsubscribe(&"ItemGetRequested",bad)
	bus.unsubscribe(&"ResourceMaxCalculationFailed",report)
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":10}).get("accepted",false) and resource(&"hero",&"Stamina")["max"] == 114.0, "successful retry on next stat change")
	print("Chest resource mod effect tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
