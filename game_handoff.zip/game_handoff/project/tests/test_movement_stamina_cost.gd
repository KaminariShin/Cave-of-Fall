extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func stamina() -> Dictionary:
	return ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"Stamina"})["data"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false),"entity")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(12,12)}).get("accepted",false),"map")
	var floors: Array = []
	for x in range(12):
		for y in range(12): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floor")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero","anchor":Vector2i(2,2),"size":2}).get("accepted",false) and ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"MovementConfigureRequested", {"entity":&"hero","actor_type":"player"}).get("accepted",false),"body and config")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":1}).get("accepted",false),"stamina")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.RIGHT}).get("accepted",false),"first step")
	check(driver.advance_steps(5) == 5,"partial advance")
	check(is_equal_approx(stamina()["movement_remainder"],1.0/12.0),"partial cost proportional")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save in movement")
	var saver = root.get_node("SaveService")
	var payload: Dictionary = saver.collect_world_transition_snapshot()["payload"]
	var broken: Dictionary = payload.duplicate(true)
	broken["sections"]["movement"]["moves"][&"hero"]["charged_progress"] = 0.0
	check(not saver._validate_snapshot(broken),"reject mismatched charged progress")
	check(driver.advance_steps(10) == 10 and is_equal_approx(stamina()["movement_remainder"],0.25),"first completion cost quarter")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false) and driver.advance_steps(10) == 10 and is_equal_approx(stamina()["movement_remainder"],0.25),"restored segment charged once")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.RIGHT}).get("accepted",false) and driver.advance_steps(15) == 15,"second step")
	check(stamina()["current"] == 1 and is_equal_approx(stamina()["movement_remainder"],0.5),"two steps accumulate half stamina")
	check(ask(&"ResourceSetRequested", {"entity":&"hero","resource":&"Stamina","value":10}).get("accepted",false),"restore stamina for remaining tests")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.DOWN}).get("accepted",false) and driver.advance_steps(6) == 6,"third partial")
	check(ask(&"ActionCancelRequested", {"entity":&"hero"}).get("accepted",false) and is_equal_approx(stamina()["movement_remainder"],0.6),"interruption charges only travelled distance")
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i(1,1)}).get("accepted",false) and driver.advance_steps(15) == 15,"diagonal movement")
	check(is_equal_approx(stamina()["movement_remainder"],0.6 + sqrt(2.0) * 0.25),"diagonal cost proportional to distance")
	check(ask(&"PipelineModifierRegisterRequested", {"entity":&"hero","modifier":{"id":"test_move_cost","target":"action.stamina_cost","stage":"multiplicative","op":"multiply","value":2.0}}).get("accepted",false),"register cost multiplier")
	var before: float = stamina()["movement_remainder"]
	var free: float = stamina()["current"]
	check(ask(&"MovementStepRequested", {"entity":&"hero","delta":Vector2i.DOWN}).get("accepted",false) and driver.advance_steps(15) == 15,"modified movement")
	check(is_equal_approx(stamina()["movement_remainder"],fposmod(before+0.5,1.0)) and (stamina()["current"] == free-1 or (free == 0 and stamina()["movement_debt"] == 1)),"cost modifiers apply before accumulation")
	print("Movement stamina cost tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
