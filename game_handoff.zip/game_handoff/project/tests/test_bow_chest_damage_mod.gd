extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver"); driver.set_process(false)
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(80,80)}).get("accepted",false),"map")
	check(ask(&"RoomCreateRequested",{"id":&"room","type":"start","origin_cell":Vector2i(1,1),"size_cells":Vector2i(11,11)}).get("accepted",false),"room")
	check(ask(&"ObjectCreateRequested",{"entity":&"chest","type":"chest","room":&"room","tile":Vector2i(14,11),"inventory_capacity":30}).get("accepted",false),"chest")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested",{"entity":&"hero","volume":30}).get("accepted",false),"hero")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(10,10),"size":4}).get("accepted",false) and ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false) and ask(&"RoomEnterRequested",{"entity":&"hero","room":&"room"}).get("accepted",false),"location")
	var state := {"count":0}
	var rng := func(e):
		state["count"] += 1
		if state["count"] in [3,7,11,15]: e["value"] = 4
		elif state["count"] in [5,9,13,17]: e["value"] = 700
		else: e["value"] = e["min"]
	bus.subscribe(&"RngIntRequested",rng)
	var draft := ask(&"DungeonChestDraftAttachRequested",{"object":&"chest","kind":"boss","depth":0})
	bus.unsubscribe(&"RngIntRequested",rng)
	check(draft.get("accepted",false),"generate chest")
	if not draft.get("accepted",false): quit(1); return
	var slot: Dictionary = draft["draft"]["slots"][0]
	var mod: Dictionary = {}
	for m in slot["mods"]:
		if m["id"] == &"suf_physical_damage": mod = m
	check(slot["base_id"] == &"bow_simple" and slot["rarity"] == &"magic" and not mod.is_empty(),"bow and physical mod generated: " + str(slot))
	check(ask(&"ChestDraftReadinessRequested",{"object":&"chest"}).get("unsupported_mod_ids",[1]).is_empty(),"effects ready")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"save/load chest before opening")
	check(ask(&"ChestDraftMaterializeRequested",{"object":&"chest","item_ids":[&"bow",&"item2",&"item3",&"item4"]}).get("accepted",false),"materialize without reroll")
	check(ask(&"ObjectInteractRequested",{"entity":&"hero","object":&"chest"}).get("accepted",false) and driver.advance_steps(10)==10 and ask(&"ChestTakeRequested",{"entity":&"hero","object":&"chest","item":&"bow"}).get("accepted",false) and driver.advance_steps(10)==10,"open and take bow")
	var equipped := ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"bow","slot":"main"})
	check(equipped.get("accepted",false) and driver.advance_steps(10)==10,"equip generated bow " + str(equipped))
	var preview := ask(&"BowShotDamagePreviewRequested",{"entity":&"hero","item":&"bow","strike":"bow_simple_shot"})
	check(preview.get("accepted",false) and preview["data"]["physical_mod_bonus"] == 0.0,"unrevealed bonus inactive")
	# Полное опознание раскрывает бонус без ручной подмены состояния.
	check(ask(&"StatBaseSetRequested",{"entity":&"hero","stat":&"INT","value":100}).get("accepted",false),"INT for identify")
	check(ask(&"EquipmentUnequipRequested",{"entity":&"hero","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"unequip to identify")
	check(ask(&"ItemLearningIdentifyRequested",{"entity":&"hero","item":&"bow"}).get("accepted",false) and driver.advance_steps(100)==100,"identify")
	check(ask(&"EquipmentEquipRequested",{"entity":&"hero","item":&"bow","slot":"main"}).get("accepted",false) and driver.advance_steps(10)==10,"reequip")
	preview = ask(&"BowShotDamagePreviewRequested",{"entity":&"hero","item":&"bow","strike":"bow_simple_shot"})
	check(preview.get("accepted",false) and not mod.is_empty() and preview["data"]["physical_mod_bonus"] == mod.get("value",-1),"real generated bonus active")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false),"save/load equipped bow")
	print("Bow chest damage mod: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
