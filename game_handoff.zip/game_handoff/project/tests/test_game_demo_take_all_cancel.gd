extends SceneTree
var failures:=0
var bus:Node
func _initialize()->void:call_deferred("run")
func check(v:bool,s:String)->void:
	if not v:failures+=1;printerr("FAIL: ",s)
func ask(id:StringName,e:Dictionary)->Dictionary:bus.publish(id,e);return e
func run()->void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game);await process_frame
	ask(&"AIUnregisterRequested",{"entity":game.RAT})
	var body:Dictionary=ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]
	var tile:Vector2i=body["anchor"]+Vector2i(2,2)
	for id in [&"cancel_a",&"cancel_b"]:
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":&"potion_hp","item_level":1}).get("accepted",false) and ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"item")
		check(ask(&"LootInventoryDropRequested",{"entity":game.HERO,"item":id,"tile":tile}).get("accepted",false) and driver.advance_steps(10)==10,"ground")
	check(game._pickup() and game._pickup_open,"open")
	game._pickup_all()
	check(driver.advance_steps(5)==5,"start")
	check(ask(&"ActionCancelRequested",{"entity":game.HERO,"reason":&"test"}).get("accepted",false),"interrupt")
	await process_frame
	check(game._pickup_open and not game._pickup_queue_running and not driver.is_action_active and game._pickup_candidates().size()==2,"interruption stops queue and keeps loot")
	game._pickup_all()
	game._pickup_close()
	check(driver.advance_steps(35)==35,"current action completes after closing")
	await process_frame
	check(not game._pickup_open and not game._pickup_queue_running and not driver.is_action_active and game._inventory_items().has(&"cancel_a") and not game._inventory_items().has(&"cancel_b"),"closing stops queue after current item")
	game.queue_free();await process_frame
	print("Take all cancellation: ","PASS" if failures==0 else "%d failed"%failures)
	quit(0 if failures==0 else 1)
