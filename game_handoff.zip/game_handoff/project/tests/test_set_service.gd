extends SceneTree
var failures := 0
var activated: Array = []
var deactivated: Array = []
func _initialize() -> void:
	call_deferred("run_tests")
func check(value: bool, text: String) -> void:
	if not value:
		failures += 1
		printerr("FAIL: ", text)
func ask(bus, name: StringName, data: Dictionary) -> Dictionary:
	bus.publish(name, data)
	return data
func stat(bus, entity: StringName, name: StringName) -> float:
	return ask(bus, &"StatGetRequested", {"entity": entity, "stat": name})["value"]
func create(bus, id: StringName, base: StringName, rarity: StringName = &"normal", set_id = null) -> bool:
	return ask(bus, &"ItemCreateRequested", {"id": id, "base_id": base, "rarity": rarity, "set_id": set_id, "item_level": 5})["accepted"]
func run_tests() -> void:
	var bus = root.get_node("EventBus")
	var entities = root.get_node("EntityRegistry")
	root.get_node("TimeDriver").set_process(false)
	bus.subscribe(&"SetBonusActivated", func(e): activated.append(e.duplicate()))
	bus.subscribe(&"SetBonusDeactivated", func(e): deactivated.append(e.duplicate()))
	check(ask(bus, &"MaterialRegisterRequested", {"material": {"id": "mat", "name": "Mat", "weight_per_unit": 1, "volume_per_unit": 1, "level": 10}})["accepted"], "material")
	for base in [{"id": "key", "name": "Key", "item_type_id": "relic", "materials": [{"material_id": "mat", "count": 1}]}, {"id": "part", "name": "Part", "item_type_id": "armor", "materials": [{"material_id": "mat", "count": 1}]}]:
		check(ask(bus, &"ItemBaseRegisterRequested", {"base": base})["accepted"], "base")
	check(create(bus, &"relic", &"key", &"unique", &"set_a"), "unique key")
	check(create(bus, &"armor1", &"part") and create(bus, &"armor2", &"part"), "fillers")
	check(entities.create_entity(&"hero"), "hero")
	var definition := {"id": "set_a", "name": "Set A", "rank": "unique", "binding": "item_id", "item_ids": ["relic"], "item_type_ids": ["armor"], "bonuses": [{"id": "three", "required_pieces": 3, "effect": {"target": "stat", "stat": "CON", "stage": "additive", "op": "add", "value": 3}}, {"id": "four", "required_pieces": 4, "effect": {"target": "generic", "name": "future_effect"}}]}
	check(ask(bus, &"SetDefinitionRegisterRequested", {"definition": definition})["accepted"], "set registration")
	check(entities.set_component(&"hero", &"equipment", {"main": &"relic", "off": &"armor1"}), "equip two")
	var state := ask(bus, &"SetStateGetRequested", {"entity": &"hero", "set_id": &"set_a"})
	check(state["found"] and not state["data"]["base_active"] and stat(bus, &"hero", &"CON") == 5.0, "one plus one is below minimum three")
	entities.set_component(&"hero", &"equipment", {"main": &"relic", "off": &"armor1", "armor": [&"armor2"]})
	state = ask(bus, &"SetStateGetRequested", {"entity": &"hero", "set_id": &"set_a"})
	check(state["data"]["base_active"] and state["data"]["matching_pieces"] == 3, "one plus two matching activates")
	check(state["data"]["active_bonuses"].has(&"three") and not state["data"]["active_bonuses"].has(&"four"), "bonus thresholds")
	check(stat(bus, &"hero", &"CON") == 8.0 and activated.size() == 1, "modifier pipeline and signal")
	var save := ask(bus, &"SessionSaveRequested", {})
	check(save.get("accepted", false), "save active set")
	entities.set_component(&"hero", &"equipment", {"main": &"relic", "off": &"armor1"})
	check(stat(bus, &"hero", &"CON") == 5.0 and deactivated.size() == 1, "removing restores stat")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false), "load")
	check(stat(bus, &"hero", &"CON") == 8.0, "restore no double modifier")
	entities.set_component(&"hero", &"equipment", {"main": &"not_found"})
	check(stat(bus, &"hero", &"CON") == 5.0, "invalid equipment removes stale bonus")
	# Три фиксированных item_id: подходящие типы не заменяют отсутствующий ID.
	check(create(bus, &"fixed1", &"key", &"unique") and create(bus, &"fixed2", &"key", &"unique") and create(bus, &"fixed3", &"key", &"unique"), "fixed items")
	var ids := {"id": "set_ids", "name": "Set IDs", "rank": "unique", "binding": "item_id", "item_ids": ["fixed1", "fixed2", "fixed3"], "item_type_ids": ["armor"], "bonuses": []}
	check(ask(bus, &"SetDefinitionRegisterRequested", {"definition": ids})["accepted"], "id set")
	entities.set_component(&"hero", &"equipment", {"main": &"fixed1", "off": &"fixed2", "armor": [&"armor1"]})
	check(not ask(bus, &"SetStateGetRequested", {"entity": &"hero", "set_id": &"set_ids"})["data"]["base_active"], "three-item id requires three actual ids")
	entities.set_component(&"hero", &"equipment", {"main": &"fixed1", "off": &"fixed2", "armor": [&"fixed3"]})
	check(ask(bus, &"SetStateGetRequested", {"entity": &"hero", "set_id": &"set_ids"})["data"]["base_active"], "three concrete ids activate")
	# Три вещи без ключевого артефакта не включают бонус, даже если
	# заданный числовой порог уже выполнен.
	check(create(bus, &"artifact_key", &"key", &"artifact", &"artifact_set"), "create set artifact")
	var artifact_set := {"id":"artifact_set", "name":"Artifact set", "rank":"unique", "binding":"item_id", "item_ids":["artifact_key", "fixed1", "fixed2", "fixed3"], "item_type_ids":[], "required_artifact_id":"artifact_key", "bonuses":[{"id":"three", "required_pieces":3, "effect":{"target":"stat", "stat":"STR", "stage":"additive", "op":"add", "value":4}}]}
	var invalid: Dictionary = artifact_set.duplicate(true)
	invalid["id"] = "invalid_artifact_set"
	invalid["required_artifact_id"] = "not_listed"
	check(not ask(bus, &"SetDefinitionRegisterRequested", {"definition":invalid}).get("accepted", false), "reject artifact outside fixed items")
	check(ask(bus, &"SetDefinitionRegisterRequested", {"definition":artifact_set}).get("accepted", false), "register set with artifact")
	entities.set_component(&"hero", &"equipment", {"main":&"fixed1", "off":&"fixed2", "armor":[&"fixed3"]})
	var artifact_state := ask(bus, &"SetStateGetRequested", {"entity":&"hero", "set_id":&"artifact_set"})
	check(artifact_state["data"]["matching_pieces"] == 3 and not artifact_state["data"]["base_active"] and not artifact_state["data"]["required_artifact_present"] and stat(bus, &"hero", &"STR") == 5.0, "missing artifact suppresses bonus")
	entities.set_component(&"hero", &"equipment", {"main":&"fixed1", "off":&"fixed2", "armor":[&"fixed3", &"artifact_key"]})
	artifact_state = ask(bus, &"SetStateGetRequested", {"entity":&"hero", "set_id":&"artifact_set"})
	check(artifact_state["data"]["base_active"] and artifact_state["data"]["required_artifact_present"] and stat(bus, &"hero", &"STR") == 9.0, "equipped artifact enables bonus")
	check(ask(bus, &"SessionSaveRequested", {}).get("accepted", false), "save artifact bonus")
	entities.set_component(&"hero", &"equipment", {"main":&"fixed1", "off":&"fixed2", "armor":[&"fixed3"]})
	check(stat(bus, &"hero", &"STR") == 5.0, "artifact removal revokes bonus")
	check(ask(bus, &"SessionLoadRequested", {}).get("accepted", false) and stat(bus, &"hero", &"STR") == 9.0, "artifact set survives save")
	# Даже без явного поля обнаруживается уже созданный артефакт,
	# перечисленный среди фиксированных ID данного сета.
	var automatic := {"id":"auto_set", "name":"Auto", "rank":"unique", "binding":"item_id", "item_ids":["auto_art", "fixed1", "fixed2", "fixed3"], "item_type_ids":[], "bonuses":[{"id":"b", "required_pieces":3, "effect":{"target":"stat", "stat":"DEX", "stage":"additive", "op":"add", "value":2}}]}
	entities.set_component(&"hero", &"equipment", {"main":&"fixed1", "off":&"fixed2", "armor":[&"fixed3"]})
	check(ask(bus, &"SetDefinitionRegisterRequested", {"definition":automatic}).get("accepted", false) and stat(bus, &"hero", &"DEX") == 7.0, "before artifact exists regular set bonus")
	check(create(bus, &"auto_art", &"key", &"artifact", &"auto_set"), "create later artifact")
	check(stat(bus, &"hero", &"DEX") == 5.0, "artifact creation recalculates and disables incomplete set")
	entities.set_component(&"hero", &"equipment", {"main":&"fixed1", "off":&"fixed2", "armor":[&"fixed3", &"auto_art"]})
	check(stat(bus, &"hero", &"DEX") == 7.0, "automatically detected artifact enables bonus")
	print("Set tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
