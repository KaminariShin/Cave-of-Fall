extends SceneTree
var bus: Node
var driver: Node
var game: Node
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool,label: String) -> void:
	if not v: failures+=1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary: bus.publish(id,e); return e
func body() -> Vector2i: return ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
func room_data(id: StringName) -> Dictionary: return ask(&"RoomGetRequested",{"id":id})["data"]
func anchor(ex: Dictionary) -> Vector2i:
	var p:=Vector2i(int(ex["x"]),int(ex["y"]))
	match ex["dirOut"]:
		"west":p.x+=1
		"east":p.x-=4
		"north":p.y+=1
		"south":p.y-=4
	return p
func steps_to(goal: Vector2i,area: Dictionary) -> Array:
	var start:=body()
	var queue:Array=[start]
	var prev:Dictionary={start:null}
	var i:=0
	while i<queue.size():
		var p:Vector2i=queue[i];i+=1
		if p==goal:
			var route:Array=[]
			while p!=start:
				var old:Vector2i=prev[p]
				route.push_front(p-old);p=old
			return route
		for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var n:Vector2i=p+d
			if not prev.has(n) and ask(&"SpaceBodyFitsRequested",{"anchor":n,"size":4,"room":area,"ignore_entity":game.HERO}).get("fits",false):
				prev[n]=p;queue.append(n)
	return []
func follow(route: Array) -> bool:
	for d in route:
		var expected: Vector2i=body()+d
		if not game._move(d): print("movement refused ",body()," delta ",d," ",game.message);return false
		driver.advance_steps(300)
		if body()!=expected: print("movement diverged ",body()," expected ",expected," message ",game.message);return false
	return true
func enter_next(room_id: StringName) -> bool:
	var info:Dictionary=room_data(room_id)
	var out:Dictionary={}
	for ex in info["exits"]:
		if not ex["connected"] and not ex["sealed"]:out=ex;break
	if out.is_empty(): print("no unexplored exit");return false
	var goal:=anchor(out)
	var area:Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
	var path:=steps_to(goal,area)
	if path.is_empty() and body()!=goal: print("no walking path ",room_id," ",body()," to ",goal); return false
	if not follow(path): return false
	# Первый шаг на проход запускает ленивую генерацию.
	var delta: Vector2i={"north":Vector2i.UP,"east":Vector2i.RIGHT,"south":Vector2i.DOWN,"west":Vector2i.LEFT}[out["dirOut"]]
	if not follow([delta]): return false
	info=room_data(room_id)
	for ex in info["exits"]:
		if ex["id"]==out["id"]: out=ex;break
	if not out["connected"]: print("exit was not generated ",out);return false
	var child: StringName=out["childId"]
	for i in range(8):
		if game.current_room==child: return true
		if not follow([delta]): return false
	return game.current_room==child
func alive(id: StringName) -> bool:
	return ask(&"CombatEntityCanActRequested",{"entity":id,"allowed":true}).get("allowed",false)
func hp(id: StringName) -> float:
	return float(ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"})["data"]["current"])
func pos(id: StringName) -> Vector2i:
	return ask(&"SpaceBodyGetRequested",{"entity":id})["data"]["anchor"]
func next_step_toward_enemy(enemy: StringName, room: StringName) -> Vector2i:
	var start:=pos(game.HERO)
	var target:=pos(enemy)+Vector2i.ONE
	var info:=room_data(room)
	var bounds: Dictionary={"origin":info["origin_cell"]*4,"size":info["size_cells"]*4}
	var queue: Array=[start]
	var prev: Dictionary={start:null}
	var index:=0
	var goal:=Vector2i(-1,-1)
	while index<queue.size():
		var p: Vector2i=queue[index];index+=1
		var d: Vector2i=target-(p+Vector2i(2,2))
		if (absi(d.x)>=4 and absi(d.x)<=6 and absi(d.y)<=1) or (absi(d.y)>=4 and absi(d.y)<=6 and absi(d.x)<=1):
			goal=p;break
		for dir in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var n: Vector2i=p+dir
			if not prev.has(n) and ask(&"SpaceBodyFitsRequested",{"anchor":n,"size":4,"room":bounds,"ignore_entity":game.HERO}).get("fits",false):
				prev[n]=p;queue.append(n)
	if goal.x<0 or goal==start:return Vector2i.ZERO
	while prev[goal]!=start:goal=prev[goal]
	return goal-start
func run() -> void:
	bus=root.get_node("EventBus")
	driver=root.get_node("TimeDriver");driver.set_process(false)
	var save_path:="user://demo_session.save"
	var save_existed:=FileAccess.file_exists(save_path)
	var old_save:=PackedByteArray()
	if save_existed:
		var file:=FileAccess.open(save_path,FileAccess.READ)
		old_save=file.get_buffer(file.get_length());file.close()
	game=load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"demo initialized")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open initial inventory")
	var initial_items: Array=game._inventory_items()
	check(game._use_inventory_item(initial_items.find(&"demo_shield")) and driver.advance_steps(10)==10,"equip shield")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close initial inventory")
	var attacks := 0
	for i in range(35):
		if not alive(game.HERO) or not alive(game.RAT):break
		var h: Vector2i = pos(game.HERO)
		var r: Vector2i = pos(game.RAT)
		var delta: Vector2 = Vector2(r+Vector2i.ONE-(h+Vector2i(2,2)))
		var aim: Vector2 = delta.normalized() if delta.length_squared()>0.0 else Vector2.RIGHT
		var preview := ask(&"WeaponStrikePreviewRequested",{"entity":game.HERO,"item":&"demo_sword","strike":game.STRIKE,"kind":"physical","direction":aim})
		var rat_rect := Rect2i(r,Vector2i(2,2))
		var in_zone := false
		for tile in preview.get("zone",{}).get("tiles",[]):
			if rat_rect.has_point(tile): in_zone=true;break
		var enemy_action:=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.RAT})
		var enemy_time:=ask(&"ActionGetRequested",{"entity":game.RAT})
		var threat:=false
		if enemy_action.get("active",false) and enemy_time.get("found",false):
			var mid:float=ceilf(float(enemy_action["data"]["duration_steps"])/2.0)*0.01
			var remaining:float=mid-float(enemy_time["data"]["elapsed"])
			threat=remaining>0 and remaining<=0.5
		if threat:
			game._start_shield_block(aim)
		elif in_zone:
			game.attack_direction=aim
			if game._start_attack(): attacks += 1
		else:
			var d := Vector2i(signi(int(delta.x)),0) if absf(delta.x)>=absf(delta.y) else Vector2i(0,signi(int(delta.y)))
			if d == Vector2i.ZERO or not game._move(d): game._wait()
		driver.advance_steps(100)
	check(alive(game.HERO) and not alive(game.RAT),"actual tutorial combat")
	if not alive(game.HERO) or alive(game.RAT):quit(1);return
	print("after rat hp ",hp(game.HERO))
	check(game._toggle_inventory(),"inventory")
	driver.advance_steps(20)
	var items: Array=ask(&"InventoryGetRequested",{"entity":game.HERO})["data"]["items"]
	check(game._use_inventory_item(items.find(&"demo_potion_hp")),"use real potion")
	driver.advance_steps(100)
	check(game._toggle_inventory(),"close inventory")
	driver.advance_steps(100)
	check(enter_next(game.ROOM),"real walk into first room")
	# Фиксируем ГСЧ теста перед отложенным спавном для стабильной встречи.
	ask(&"RngSeedRequested",{"seed":3})
	await process_frame
	await process_frame
	await process_frame
	var current: StringName=game.current_room
	var spawn:=ask(&"RoomSpawnStatusRequested",{"room":current})
	print("spawns ",spawn," hero ",pos(game.HERO)," hp ",hp(game.HERO))
	var units: Array=spawn.get("data",{}).get("placed",[])
	check(not units.is_empty(),"spawned an enemy")
	if units.is_empty():quit(1);return
	var enemy: StringName=units[0]
	check(ask(&"AIGetRequested",{"entity":enemy}).get("data",{}).get("role","")=="melee","spawn uses active common AI")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save populated first room")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load populated first room")
	await process_frame
	await process_frame
	check(ask(&"AIGetRequested",{"entity":enemy}).get("data",{}).get("role","")=="melee","spawn AI survives reload")
	check(ask(&"RoomSpawnStatusRequested",{"room":current}).get("data",{}).get("placed",[])==units,"no duplicate spawns on reload")
	var initial := hp(game.HERO)
	var defense:Dictionary={"absorbed":0}
	var on_phase:=func(e):
		var block:Dictionary=e.get("data",{}).get("blocks",{}).get(game.HERO,{})
		defense["absorbed"]+=int(block.get("absorbed",0))
	bus.subscribe(&"CombatPhaseBatchResolved",on_phase)
	attacks=0
	var enemy_detected:=false
	for i in range(70):
		if not alive(game.HERO) or not alive(enemy):break
		var enemy_body: Dictionary=ask(&"SpaceBodyGetRequested",{"entity":enemy})["data"]
		var enemy_rect:=Rect2i(enemy_body["anchor"],Vector2i.ONE*int(enemy_body["size"]))
		var enemy_center:=Vector2(enemy_body["anchor"])+Vector2.ONE*float(enemy_body["size"])*0.5
		var hero_center:=Vector2(pos(game.HERO))+Vector2.ONE*2.0
		var aim:Vector2=(enemy_center-hero_center).normalized()
		var preview:=ask(&"WeaponStrikePreviewRequested",{"entity":game.HERO,"item":&"demo_sword","strike":game.STRIKE,"kind":"physical","direction":aim})
		var in_zone:=false
		for tile in preview.get("zone",{}).get("tiles",[]):
			if enemy_rect.has_point(tile):in_zone=true;break
		var enemy_action:=ask(&"WeaponStrikeActionStatusRequested",{"entity":enemy})
		var enemy_time:=ask(&"ActionGetRequested",{"entity":enemy})
		var threat:=false
		if enemy_action.get("active",false) and enemy_time.get("found",false):
			var mid:float=ceilf(float(enemy_action["data"]["duration_steps"])/2.0)*0.01
			var remaining:float=mid-float(enemy_time["data"]["elapsed"])
			threat=remaining>0 and remaining<=0.5
		if threat:
			game._start_shield_block(aim)
		elif in_zone:
			game.attack_direction=aim
			if game._start_attack():attacks+=1
		else:
			var move:=next_step_toward_enemy(enemy,current)
			if move==Vector2i.ZERO or not game._move(move):game._wait()
		driver.advance_steps(100)
		if alive(enemy) and ask(&"DetectionPairGetRequested",{"observer":enemy,"target":game.HERO}).get("detected",false):enemy_detected=true
	print("spawn detected hero at sampled steps: ",enemy_detected)
	print("enemy result ","alive=",alive(enemy)," hero alive=",alive(game.HERO)," hp=",hp(game.HERO)," initial=",initial," attacks=",attacks," enemy pos=",pos(enemy) if alive(enemy) else Vector2i(-1,-1))
	check(enemy_detected,"spawned enemy detects hero")
	bus.unsubscribe(&"CombatPhaseBatchResolved",on_phase)
	check(hp(game.HERO)<initial or defense["absorbed"]>0,"spawned enemy hits or is blocked")
	check(not alive(enemy),"defeat spawned enemy")
	check(alive(game.HERO),"survive enemy")
	check(ask(&"RunStatisticsGetRequested",{}).get("data",{}).get("kills",0)==2,"both kills recorded")
	game.queue_free()
	await process_frame
	if save_existed:
		var file:=FileAccess.open(save_path,FileAccess.WRITE);file.store_buffer(old_save);file.close()
	elif FileAccess.file_exists(save_path):DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
	print("Game demo first encounter: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
