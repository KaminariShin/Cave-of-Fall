extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName,e: Dictionary) -> Dictionary:
	bus.publish(id,e); return e
func bytes_at(path: String) -> PackedByteArray:
	if not FileAccess.file_exists(path): return PackedByteArray()
	var f := FileAccess.open(path,FileAccess.READ)
	return f.get_buffer(f.get_length())
func put_bytes(path: String, data: PackedByteArray) -> void:
	var f := FileAccess.open(path,FileAccess.WRITE)
	f.store_buffer(data); f.close()
func run() -> void:
	bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var path := "user://demo_session.save"
	var old_exists := FileAccess.file_exists(path)
	var old := bytes_at(path)
	var ordinary_path := "user://session.save"
	var ordinary_exists := FileAccess.file_exists(ordinary_path)
	var ordinary := bytes_at(ordinary_path)
	var game = load("res://game_demo.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.initialized,"initialized")
	check(not ask(&"SessionSaveRequested",{}).get("accepted",false),"demo cannot write normal slot")
	check(not ask(&"SessionSaveRequested",{"slot":"invalid"}).get("accepted",false),"invalid slot rejected")
	var save_key := InputEventKey.new()
	save_key.pressed = true; save_key.keycode = KEY_F5
	game._unhandled_key_input(save_key)
	check(game.message == "Демо сохранено." and FileAccess.file_exists(path),"F5 saves demo")
	check(FileAccess.file_exists(ordinary_path) == ordinary_exists and bytes_at(ordinary_path) == ordinary,"normal slot untouched")
	var start: Vector2i = ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"]
	check(game._move(Vector2i.RIGHT),"move")
	driver.advance_steps(100)
	check(ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"] != start,"moved")
	var load_key := InputEventKey.new()
	load_key.pressed = true; load_key.keycode = KEY_F9
	game._unhandled_key_input(load_key)
	check(game.message == "Демо загружено.","F9 loads demo")
	check(ask(&"SpaceBodyGetRequested",{"entity":game.HERO})["data"]["anchor"] == start and game.facing == Vector2i.RIGHT,"position and facing restored")
	check(game._toggle_inventory(),"open inventory")
	driver.advance_steps(10)
	check(game.inventory_open,"inventory open")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save inventory")
	check(game._toggle_inventory(),"close inventory")
	driver.advance_steps(10)
	check(not game.inventory_open,"inventory closed")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false) and game.inventory_open,"inventory state restored")
	check(game._toggle_inventory(),"close restored inventory")
	driver.advance_steps(10)
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet target")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":Vector2i(62,60)}).get("accepted",false),"position")
	game.facing = Vector2i.RIGHT
	check(game._start_attack(),"start real strike")
	check(driver.advance_steps(20) == 20,"partial strike")
	check(game.pending_attack and not game.attack_tiles.is_empty(),"strike visual active")
	var tiles: Array = game.attack_tiles.duplicate()
	var saved_hp: float = ask(&"ResourceGetRequested",{"entity":game.RAT,"resource":&"HP"})["data"]["current"]
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save mid strike")
	var valid_bytes := bytes_at(path)
	driver.advance_steps(100)
	var after_hp: float = ask(&"ResourceGetRequested",{"entity":game.RAT,"resource":&"HP"})["data"]["current"]
	check(after_hp < saved_hp,"strike deals damage")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load mid strike")
	check(game.pending_attack and game.attack_tiles == tiles and ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO}).get("active",false),"strike state restored")
	driver.advance_steps(100)
	check(float(ask(&"ResourceGetRequested",{"entity":game.RAT,"resource":&"HP"})["data"]["current"]) == after_hp and not game.pending_attack,"combat replays deterministically")
	var payload: Dictionary = bytes_to_var(valid_bytes)
	payload["sections"]["game_demo"]["room"] = &"missing"
	put_bytes(path,var_to_bytes(payload))
	check(not ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"reject invalid scene state")
	check(float(ask(&"ResourceGetRequested",{"entity":game.RAT,"resource":&"HP"})["data"]["current"]) == after_hp,"failed load preserves state")
	payload = bytes_to_var(valid_bytes)
	payload["sections"]["rooms"]["rooms"] = []
	put_bytes(path,var_to_bytes(payload))
	check(not ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"reject malformed nested scene data")
	put_bytes(path,valid_bytes)
	check(ask(&"CombatDamageRequested",{"entity":game.HERO,"amount":999999}).get("accepted",false),"death")
	check(game.is_dead and not FileAccess.file_exists(path),"demo slot removed on death")
	check(FileAccess.file_exists(ordinary_path) == ordinary_exists and bytes_at(ordinary_path) == ordinary,"ordinary slot preserved on demo death")
	game.queue_free()
	await process_frame
	if old_exists: put_bytes(path,old)
	elif FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo save: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
