extends SceneTree
func _initialize() -> void:
	print("TEST_USER_DIR=", OS.get_user_data_dir())
	print("Runner isolation probe: PASS")
	quit(0)
