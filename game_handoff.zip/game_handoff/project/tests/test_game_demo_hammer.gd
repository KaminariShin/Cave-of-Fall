extends SceneTree
var failures := 0
var bus: Node
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	bus.publish(id,e);return e
func inventory() -> Array:
	return ask(&"InventoryGetRequested",{"entity":&"demo_hero"})["data"]["items"]
func hp(id: StringName) -> float:
	return float(ask(&"ResourceGetRequested",{"entity":id,"resource":&"HP"})["data"]["current"])
func run() -> void:
	bus=root.get_node("EventBus")
	var driver=root.get_node("TimeDriver");driver.set_process(false)
	var path := "user://demo_session.save"
	var exists:=FileAccess.file_exists(path)
	var old:=PackedByteArray()
	if exists:
		var f:=FileAccess.open(path,FileAccess.READ);old=f.get_buffer(f.get_length());f.close()
	var game=load("res://game_demo.tscn").instantiate();root.add_child(game)
	await process_frame
	check(game.initialized,"setup")
	check(ask(&"AIUnregisterRequested",{"entity":game.RAT}).get("accepted",false),"quiet tutorial rat")
	check(ask(&"InventoryConfigureRequested",{"entity":game.HERO,"volume":50.0}).get("accepted",false),"capacity")
	check(ask(&"ObjectCreateRequested",{"entity":&"hammer_chest","type":"chest","room":game.ROOM,"tile":Vector2i(70,70),"inventory_capacity":20.0}).get("accepted",false),"prepare chest")
	var bases:Dictionary=root.get_node("SaveService").collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema:Dictionary=root.get_node("DungeonChestLearningService").schema_for(&"hammer_simple",bases)
	check(ask(&"ItemCreateRequested",{"id":&"found_hammer","base_id":&"hammer_simple","item_level":1,"learning":schema}).get("accepted",false),"create hammer")
	check(ask(&"InventoryAddRequested",{"entity":&"hammer_chest","item":&"found_hammer"}).get("accepted",false),"hammer into chest")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":Vector2i(66,69)}).get("accepted",false),"test approach chest")
	check(game._interact_chest() and driver.advance_steps(10)==10,"open chest")
	check(game._interact_chest() and game._pickup_item(&"found_hammer") and driver.advance_steps(10)==10 and inventory().has(&"found_hammer"),"take hammer via F")
	for base in [&"staff_simple"]:
		var id:=StringName("unsupported_"+str(base))
		check(ask(&"ItemCreateRequested",{"id":id,"base_id":base,"item_level":1}).get("accepted",false),"unsupported item")
		check(ask(&"InventoryAddRequested",{"entity":game.HERO,"item":id}).get("accepted",false),"unsupported into inventory")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"open inventory")
	check(game._unequip_hand("main") and driver.advance_steps(10)==10,"remove sword")
	for id in [&"unsupported_staff_simple"]:
		var idx:=inventory().find(id)
		check(idx>=0 and not game._use_inventory_item(idx) and game.message.contains("не реализована") and inventory().has(id),"unsupported weapon refused safely")
	var index:=inventory().find(&"found_hammer")
	check(index>=0 and game._use_inventory_item(index) and driver.advance_steps(10)==10,"equip hammer")
	check(ask(&"ComponentGetRequested",{"entity":game.HERO,"component":&"equipment"})["data"].get("main",null)==&"found_hammer","hammer in hand")
	check(game._toggle_inventory() and driver.advance_steps(1)==1,"close inventory")
	check(ask(&"EntityCreateRequested",{"entity":&"hammer_target","components":{&"stats":{"CON":100}}}).get("accepted",false),"target")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hammer_target","anchor":Vector2i(68,58),"size":2}).get("accepted",false),"target body")
	check(ask(&"SpaceBodyMoveRequested",{"entity":game.HERO,"anchor":Vector2i(62,58)}).get("accepted",false),"test attack position")
	game.facing=Vector2i.RIGHT
	var before:=hp(&"hammer_target")
	var stamina:float=ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"})["data"]["current"]
	check(game._start_attack(),"hammer attack begins")
	var active:=ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})
	check(active.get("active",false) and active["data"]["strike"]=="demo_player_hammer_slam","hammer strike selected")
	check(ask(&"ResourceGetRequested",{"entity":game.HERO,"resource":&"Stamina"})["data"]["current"]<stamina,"stamina spent")
	check(driver.advance_steps(10)==10 and game.pending_attack,"partially through attack")
	check(ask(&"SessionSaveRequested",{"slot":"demo"}).get("accepted",false),"save attack")
	var steps:int=driver.advance_steps(200)
	print("attack advance ",steps," pending ",game.pending_attack)
	var after:=hp(&"hammer_target")
	check(after<before and not game.pending_attack,"real hammer damage")
	check(ask(&"ItemGetRequested",{"item":&"found_hammer"})["item_data"]["learning_state"]["progress"]==1,"demo hammer learns from strike")
	check(ask(&"SessionLoadRequested",{"slot":"demo"}).get("accepted",false),"load attack")
	check(ask(&"WeaponStrikeActionStatusRequested",{"entity":game.HERO})["data"]["strike"]=="demo_player_hammer_slam","restore hammer action")
	var replay_steps:int=driver.advance_steps(200)
	print("replay advance ",replay_steps," hp ",hp(&"hammer_target")," expected ",after)
	check(hp(&"hammer_target")==after and not game.pending_attack and ask(&"ItemGetRequested",{"item":&"found_hammer"})["item_data"]["learning_state"]["progress"]==1,"restore replays damage and learns once")
	game.queue_free();await process_frame
	if exists:
		var f:=FileAccess.open(path,FileAccess.WRITE);f.store_buffer(old);f.close()
	elif FileAccess.file_exists(path):DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Game demo hammer: ","PASS" if failures==0 else "%d failed" % failures)
	quit(0 if failures==0 else 1)
