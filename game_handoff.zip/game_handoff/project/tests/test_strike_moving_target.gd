extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(v: bool, label: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ",label)
func ask(name: StringName,e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(name,e)
	return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(30,20)}).get("accepted",false),"map")
	var floors := []
	for y in range(20):
		for x in range(30): floors.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested", {"tiles":floors,"kind":1}).get("accepted",false),"floors")
	for row in [[&"hero",Vector2i(5,5)],[&"rat",Vector2i(8,5)]]:
		check(ask(&"EntityCreateRequested", {"entity":row[0]}).get("accepted",false) and ask(&"SpaceBodyPlaceRequested", {"entity":row[0],"anchor":row[1],"size":2}).get("accepted",false),"entity body")
	check(ask(&"ControlledEntityRequested", {"entity":&"rat"}).get("accepted",false) and ask(&"MovementConfigureRequested", {"entity":&"rat","actor_type":"player","K_move":10}).get("accepted",false),"configure")
	var shape := {"entity":&"hero","weapon_type":"sword","direction":Vector2.RIGHT,"shape":{"type":"arc","angle_degrees":90,"radius":10}}
	var z := ask(&"StrikeZoneGetRequested",shape.duplicate(true))
	check(z.get("accepted",false) and z["tiles"].has(Vector2i(10,5)),"zone includes new leading tile")
	var request := shape.duplicate(true); request["target"] = &"rat"
	var before := ask(&"StrikeZoneBodyTestRequested",request.duplicate(true))
	check(before.get("accepted",false) and not before["hit_tiles"].has(Vector2i(10,5)),"touching boundary is not intersection")
	check(ask(&"MovementStepRequested", {"entity":&"rat","delta":Vector2i.RIGHT}).get("accepted",false) and driver.advance_steps(1) == 1,"start target movement")
	var position := ask(&"MovementPositionGetRequested", {"entity":&"rat"})
	check(position.get("found",false) and position["position"].x > 8 and position["position"].x < 9,"continuous position")
	var mid := ask(&"StrikeZoneBodyTestRequested",request.duplicate(true))
	check(mid.get("accepted",false) and mid["hit_tiles"].has(Vector2i(10,5)),"positive overlap at leading edge")
	var found := false
	for tile in mid.get("hit_tiles",[]):
		if tile == Vector2i(10,5): found = true
		check(z["tile_set"].has(tile),"matches displayed zone")
	check(found,"tile present")
	var damage := shape.duplicate(true); damage["amount"] = 1; damage["targets"] = [&"rat",&"rat"]
	var d := ask(&"StrikeZoneDamageRequested",damage)
	check(d.get("accepted",false) and d["hits"].size() == 1 and d["hits"][0]["hit_tiles"].has(Vector2i(10,5)),"direct damage uses continuous intersection once")
	var bad_pos := func(e):
		if e.get("entity",null) == &"rat": e["position"] = Vector2(INF,0)
	bus.subscribe(&"MovementPositionGetRequested",bad_pos)
	check(not ask(&"StrikeZoneBodyTestRequested",request.duplicate(true)).get("accepted",true) and not ask(&"StrikeZoneDamageRequested",damage.duplicate(true)).get("accepted",true),"invalid target position rejects")
	bus.unsubscribe(&"MovementPositionGetRequested",bad_pos)
	check(driver.advance_steps(100) > 0,"finish move")
	var after := ask(&"StrikeZoneBodyTestRequested",request.duplicate(true))
	check(after.get("accepted",false) and after["hit_tiles"].has(Vector2i(10,5)),"final body at destination")
	# Explicitly test the trailing edge with a fixed one-tile zone.
	var service = root.get_node("StrikeZoneService")
	var body := {"anchor":Vector2i(9,5),"size":2}
	var fixed := {Vector2i(8,5):true,Vector2i(9,5):true,Vector2i(11,5):true}
	var edges: Dictionary = service._body_tiles_in_zone(&"rat",body,fixed)
	check(edges.get("accepted",false) and edges["tiles"] == [Vector2i(9,5)],"touching either edge excluded")
	print("Moving strike target tests: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
