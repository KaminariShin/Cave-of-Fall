extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, event: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, event)
	return event
func gear() -> Dictionary:
	var q := ask(&"ComponentGetRequested", {"entity":&"hero", "component":&"equipment"})
	return q.get("data", {})
func inv() -> Array:
	return ask(&"InventoryGetRequested", {"entity":&"hero"})["data"]["items"]
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "create hero")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "control hero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10.0}).get("accepted", false), "configure inventory")
	check(ask(&"MaterialRegisterRequested", {"material":{"id":"equipment_test_mat", "name":"mat", "weight_per_unit":1, "volume_per_unit":1, "armor_per_unit":2, "level":1}}).get("accepted", false), "material")
	for def in [{"id":"equipment_test_sword", "slot":"weapon", "tags":[]}, {"id":"equipment_test_shield", "slot":"shield", "tags":[]}, {"id":"equipment_test_two", "slot":"weapon", "tags":["two_handed"]}]:
		def["name"] = def["id"]
		def["materials"] = [{"material_id":"equipment_test_mat", "count":1}]
		check(ask(&"ItemBaseRegisterRequested", {"base":def}).get("accepted", false), "base " + def["id"])
		var id := StringName(def["id"] + "_item")
		check(ask(&"ItemCreateRequested", {"id":id, "base_id":StringName(def["id"]), "item_level":1}).get("accepted", false), "item")
		check(ask(&"InventoryAddRequested", {"entity":&"hero", "item":id}).get("accepted", false), "inventory add")
	var sword := &"equipment_test_sword_item"
	var shield := &"equipment_test_shield_item"
	var two := &"equipment_test_two_item"
	check(not ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":sword, "slot":"head"}).get("accepted", false), "reject incompatible slot")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":sword, "slot":"main"}).get("accepted", false), "start equip")
	driver.advance_steps(5)
	check(inv().has(sword) and gear().get("main", null) == null, "no change mid-action")
	check(not ask(&"ActionInterruptRequested", {"entity":&"hero", "action":&"stagger", "duration":0.2}).get("accepted", false), "stagger does not interrupt equip")
	var snapshot := {"sections":{}, "errors":[]}
	ask(&"SnapshotCollectRequested", snapshot)
	check(ask(&"EquipmentSnapshotValidateRequested", {"sections":snapshot["sections"]}).get("valid", false), "valid pending snapshot")
	var missing: Dictionary = snapshot["sections"].duplicate(true)
	missing["items"]["instances"].erase(sword)
	check(not ask(&"EquipmentSnapshotValidateRequested", {"sections":missing}).get("valid", false), "reject missing pending item")
	var displaced: Dictionary = snapshot["sections"].duplicate(true)
	displaced["entities"][&"hero"][&"inventory"]["items"].erase(sword)
	check(not ask(&"EquipmentSnapshotValidateRequested", {"sections":displaced}).get("valid", false), "reject item absent from inventory")
	var orphan: Dictionary = snapshot["sections"].duplicate(true)
	orphan["equipment_actions"].erase(&"hero")
	check(not ask(&"EquipmentSnapshotValidateRequested", {"sections":orphan}).get("valid", false), "reject action without pending transfer")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false), "save during equip")
	driver.advance_steps(5)
	check(not inv().has(sword) and gear().get("main", null) == sword, "equip completed")
	check(not ask(&"InventoryAddRequested", {"entity":&"hero", "item":sword}).get("accepted", false), "cannot duplicate equipped item into inventory")
	check(ask(&"SessionLoadRequested", {}).get("accepted", false), "load mid-equip")
	check(inv().has(sword) and gear().get("main", null) == null, "restore mid-action ownership")
	driver.advance_steps(5)
	check(gear().get("main", null) == sword and not inv().has(sword), "restored equip completes")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":shield, "slot":"off"}).get("accepted", false), "equip shield off")
	driver.advance_steps(10)
	check(gear().get("off", null) == shield, "shield equipped")
	var armour := ask(&"EquipmentArmourGetRequested", {"entity":&"hero"})
	check(armour.get("found", false) and is_equal_approx(float(armour.get("armour", 0)), 2.0), "shield contributes armour but sword does not")
	var protection := ask(&"PeriodicProtectionGetRequested", {"entity":&"hero", "damage_type":"physical", "percent":0.0})
	check(is_equal_approx(float(protection["percent"]), 1.97), "armour protects periodic physical damage")
	var physical := ask(&"CombatDamageRequested", {"entity":&"hero", "amount":1.01, "damage_type":"physical"})
	check(physical.get("accepted", false) and is_equal_approx(float(physical.get("applied", 0.0)), 1.0), "direct physical damage uses armour before rounding")
	var magical := ask(&"CombatDamageRequested", {"entity":&"hero", "amount":1.01, "damage_type":"magical"})
	check(magical.get("accepted", false) and is_equal_approx(float(magical.get("applied", 0.0)), 2.0), "armour does not reduce magical damage")
	check(not ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":two, "slot":"main"}).get("accepted", false), "no unsafe two-handed replacement")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero", "slot":"off"}).get("accepted", false), "unequip shield")
	driver.advance_steps(10)
	check(inv().has(shield) and gear().get("off", null) == null, "shield moved to inventory")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero", "slot":"main"}).get("accepted", false), "unequip sword")
	driver.advance_steps(10)
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":two, "slot":"main"}).get("accepted", false), "start two-handed weapon")
	driver.advance_steps(10)
	check(gear().get("main", null) == two and not ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":shield, "slot":"off"}).get("accepted", false), "two-handed blocks off hand")
	print("Equipment actions tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
