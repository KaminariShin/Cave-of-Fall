extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var saver = root.get_node("SaveService")
	var bus = root.get_node("EventBus")
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(80,80)}).get("accepted",false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"room", "type":"start", "origin_cell":Vector2i(1,1), "size_cells":Vector2i(11,11)}).get("accepted",false), "room")
	check(ask(&"ObjectCreateRequested", {"entity":&"chest", "type":"chest", "room":&"room", "tile":Vector2i(14,11), "inventory_capacity":1.0}).get("accepted",false), "chest")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false), "hero")
	check(ask(&"InventoryConfigureRequested", {"entity":&"hero", "volume":10}).get("accepted",false), "hero inventory")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(10,10), "size":4}).get("accepted",false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false), "control")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"room"}).get("accepted",false), "enter")
	var values := [4,0,0,2,0,40,0,0,19,3,0,40,0,2,3]
	var rng := func(e):
		if not values.is_empty(): e["value"] = values.pop_front()
	bus.subscribe(&"RngIntRequested",rng)
	var attached := ask(&"DungeonChestDraftAttachRequested", {"object":&"chest", "kind":"boss", "depth":4})
	bus.unsubscribe(&"RngIntRequested",rng)
	check(attached.get("accepted",false) and values.is_empty(), "mixed plan")
	if not attached.get("accepted",false): quit(1); return
	var slots: Array = attached["draft"]["slots"]
	check(slots[0]["base_id"] == &"sword_simple" and slots[1]["category"] == "consumable" and slots[2]["base_id"] == &"armor_iron_body" and slots[2]["materials"][0]["material_id"] == "steel_common", "plan positions and upgraded materials")
	var ids := [&"plain_sword", &"plain_potion", &"plain_armor", &"plain_potion2"]
	var before: Dictionary = saver.collect_world_transition_snapshot()
	var created := {"n":0}
	var observer := func(_e): created["n"] += 1
	bus.subscribe(&"ItemCreated",observer)
	var rejected := ask(&"ChestPlainDraftMaterializeRequested", {"object":&"chest", "item_ids":ids})
	bus.unsubscribe(&"ItemCreated",observer)
	check(not rejected.get("accepted",true) and rejected.get("rolled_back",false) and created["n"] >= 2 and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "midstream capacity failure rolls back all")
	check(ask(&"InventoryConfigureRequested", {"entity":&"chest", "volume":10}).get("accepted",false), "capacity")
	before = saver.collect_world_transition_snapshot()
	check(not ask(&"ChestConsumableDraftMaterializeRequested", {"object":&"chest", "item_ids":ids}).get("accepted",true), "old consumable-only contract unchanged")
	var done := ask(&"ChestPlainDraftMaterializeRequested", {"object":&"chest", "item_ids":ids})
	check(done.get("accepted",false), "mixed materialization")
	if not done.get("accepted",false): print(done); quit(1); return
	for i in range(ids.size()):
		var item: Dictionary = ask(&"ItemGetRequested", {"item":ids[i]})["item_data"]
		check(item["base_id"] == slots[i]["base_id"] and item["materials"] == slots[i]["materials"] and item["item_level"] == slots[i]["item_level"] and item["rarity"] == &"normal" and item["mods"].is_empty(), "item matches plan %d" % i)
	check(ask(&"ItemGetRequested", {"item":ids[0]})["item_data"].get("learning", null) == slots[0]["learning"] and ask(&"ItemGetRequested", {"item":ids[2]})["item_data"]["learning"]["progress_kind"] == "owner_actions", "materialized equipment retains learning schema")
	check(saver.collect_world_transition_snapshot()["payload"]["sections"]["rng"] == before["payload"]["sections"]["rng"], "no reroll")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and ask(&"InventoryGetRequested", {"entity":&"chest"})["data"]["items"] == ids, "save and load")
	check(ask(&"ObjectInteractRequested", {"entity":&"hero", "object":&"chest"}).get("accepted",false) and driver.advance_steps(10) == 10, "open")
	check(ask(&"ChestTakeRequested", {"entity":&"hero", "object":&"chest", "item":ids[0]}).get("accepted",false) and driver.advance_steps(10) == 10, "take equipment")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":ids[0], "slot":"main"}).get("accepted",false) and driver.advance_steps(10) == 10 and ask(&"ComponentGetRequested", {"entity":&"hero", "component":&"equipment"})["data"].get("main",null) == ids[0], "equip actual sword")
	check(ask(&"ObjectCreateRequested", {"entity":&"magic_chest", "type":"chest", "room":&"room", "tile":Vector2i(20,20), "inventory_capacity":30}).get("accepted",false), "magic chest")
	var state := {"n":0}
	var magic_rng := func(e):
		state["n"] += 1
		e["value"] = 700 if state["n"] in [5,9,13,17] else e["min"]
	bus.subscribe(&"RngIntRequested",magic_rng)
	var magic := ask(&"DungeonChestDraftAttachRequested", {"object":&"magic_chest", "kind":"boss", "depth":1})
	bus.unsubscribe(&"RngIntRequested",magic_rng)
	check(magic.get("accepted",false) and magic.get("draft",{}).get("slots",[])[0]["rarity"] == &"magic", "magic plan")
	before = saver.collect_world_transition_snapshot()
	check(not ask(&"ChestPlainDraftMaterializeRequested", {"object":&"magic_chest", "item_ids":[&"x1",&"x2",&"x3",&"x4"]}).get("accepted",true) and before["payload"]["sections"] == saver.collect_world_transition_snapshot()["payload"]["sections"], "magic rejects without changes")
	print("Plain chest materialization tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
