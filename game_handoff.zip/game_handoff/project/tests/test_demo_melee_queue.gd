extends SceneTree
var failures := 0
var arrivals: Array = []
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok: failures += 1; printerr("FAIL: ",label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e); return e
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	root.get_node("EventBus").subscribe(&"SpawnQueueMobSpawned",func(e): arrivals.append(e.duplicate(true)))
	check(ask(&"SpaceMapConfigureRequested",{"size":Vector2i(100,100)}).get("accepted",false),"map")
	check(ask(&"RoomCreateRequested",{"id":&"r","type":"start","origin_cell":Vector2i(2,2),"size_cells":Vector2i(11,11)}).get("accepted",false),"room")
	check(ask(&"EntityCreateRequested",{"entity":&"hero"}).get("accepted",false),"hero")
	check(ask(&"SpaceBodyPlaceRequested",{"entity":&"hero","anchor":Vector2i(28,28),"size":4}).get("accepted",false),"body")
	check(ask(&"ControlledEntityRequested",{"entity":&"hero"}).get("accepted",false),"control")
	check(ask(&"RoomEnterRequested",{"entity":&"hero","room":&"r"}).get("accepted",false),"enter")
	var keep := {}
	for x in range(28,32):
		for y in range(28,32): keep[Vector2i(x,y)] = true
	for x in [23,24,26,27]:
		for y in [25,26]: keep[Vector2i(x,y)] = true
	var tiles: Array = []
	for x in range(9,51):
		for y in range(9,51):
			if not keep.has(Vector2i(x,y)): tiles.append(Vector2i(x,y))
	check(ask(&"SpaceTilesSetRequested",{"tiles":tiles,"kind":0}).get("accepted",false),"sparse")
	# Test-only budget weights force a queue while keeping the demo definition.
	var service = root.get_node("SpawnService")
	service._demo_pool[0]["type_weight"] = 0.1
	service._demo_pool[0]["species"]["species_weight"] = 0.2
	ask(&"RngSeedRequested",{"seed":42})
	var spawn := ask(&"RoomSpawnRequested",{"room":&"r","player":&"hero","entry_tile":Vector2i(28,28),"depth":6,"demo_pool":true,"demo_melee":true,"queue_delay":0.05})
	check(spawn.get("accepted",false) and spawn.get("units",[]).size() >= 1 and spawn.get("queue_count",0) >= 1,"queue spawn " + str(spawn))
	if not spawn.get("accepted",false) or spawn.get("units",[]).is_empty(): quit(1); return
	await process_frame
	await process_frame
	var first: StringName = spawn["units"][0]["entity"]
	check(ask(&"DemoMeleeSetupStatusRequested",{"entity":first})["status"] == "installed","first installed")
	check(ask(&"CombatDamageRequested",{"entity":first,"source":&"hero","amount":9999}).get("accepted",false),"kill frees space")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false),"save queued")
	check(ask(&"SessionLoadRequested",{}).get("accepted",false),"load queued")
	check(ask(&"ActionStartRequested",{"entity":&"hero","action":&"wait","duration":1.0}).get("accepted",false),"start time")
	check(driver.advance_steps(10) == 10,"advance")
	await process_frame
	await process_frame
	check(not arrivals.is_empty(),"queue arrived")
	if not arrivals.is_empty():
		var id: StringName = arrivals[0]["entity"]
		check(ask(&"DemoMeleeSetupStatusRequested",{"entity":id})["status"] == "installed","queue installed " + str(ask(&"DemoMeleeSetupStatusRequested",{"entity":id})))
		check(ask(&"AIGetRequested",{"entity":id}).get("data",{}).get("role","") == "melee","queue common AI")
		check(ask(&"AIGetRequested",{"entity":id}).get("data",{}).get("weapon",{}).get("strike","") in ["demo_creature_thrust","demo_player_hammer_slam","bow_simple_shot"],"queued enemy has supported strike")
	print("Demo melee queue: ","PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
