extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func id(i: int) -> StringName: return StringName("chain_%d" % i)
func budget(room: StringName, value: int) -> Dictionary:
	return ask(&"DungeonDeadendBudgetAvailableRequested", {"room":room, "budget":value})
func run() -> void:
	root.get_node("TimeDriver").set_process(false)
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(500,250)}).get("accepted", false), "map")
	for i in range(6):
		var room_type := "start" if i == 0 else "fork"
		check(ask(&"RoomCreateRequested", {"id":id(i), "type":room_type, "origin_cell":Vector2i(10 if i == 0 else 22 + (i - 1) * 14,20), "size_cells":Vector2i(12,12) if i == 0 else Vector2i(14,14)}).get("accepted", false), "create chain room")
		if i == 0:
			check(ask(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":id(0)}).get("accepted", false), "tracking starts before children")
		else:
			check(ask(&"RoomExitAddRequested", {"room":id(i - 1), "id":&"east", "dir":"east", "offset_cells":5}).get("accepted", false), "add outgoing")
			check(ask(&"RoomExitAddRequested", {"room":id(i), "id":&"entry", "dir":"west", "offset_cells":5}).get("accepted", false), "add entry")
			check(ask(&"RoomExitConnectRequested", {"room":id(i - 1), "exit":&"east", "other_room":id(i), "other_exit":&"entry"}).get("accepted", false), "connect")
			ask(&"RoomChildGenerated", {"room":id(i - 1), "child":id(i), "type":room_type})
	check(budget(id(1),1).get("budget", -1) == 0, "reserve last deadend at early depth")
	check(budget(id(1),2).get("budget", -1) == 2, "additional early deadends remain allowed")
	check(budget(id(4),1).get("budget", -1) == 0, "child distance five still reserved")
	check(budget(id(5),1).get("budget", -1) == 1, "child distance six may use reservation")
	check(not budget(&"missing",1).get("accepted", false), "unknown parent fails closed")
	check(ask(&"RoomGenerationConfigureRequested", {"deadend_budget":1}).get("accepted", false), "set budget")
	check(budget(id(1),0).get("budget", -1) == 0, "zero budget not fabricated")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "save and restore before candidate")
	check(budget(id(1),1).get("budget", -1) == 0 and budget(id(5),1).get("budget", -1) == 1, "reservation survives restore")
	check(ask(&"RoomExitAddRequested", {"room":id(1), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "early branch")
	check(ask(&"RoomExitAddRequested", {"room":id(5), "id":&"north", "dir":"north", "offset_cells":5}).get("accepted", false), "eligible branch")
	var force_last := func(e): e["value"] = 0.999999
	var force_min := func(e): e["value"] = e["min"]
	var state := {"trials":0, "announced":0, "first_origin":Vector2i.ZERO, "first_size":Vector2i.ZERO, "parent_unconnected":true, "selected_early":false}
	var reject_first := func(e):
		state["trials"] += 1
		if state["trials"] != 1: return
		var candidate := ask(&"RoomGetRequested", {"id":e["room"]})
		state["first_origin"] = candidate["data"]["origin_cell"]
		state["first_size"] = candidate["data"]["size_cells"]
		state["parent_unconnected"] = not ask(&"RoomGetRequested", {"id":id(5)})["data"]["exits"].filter(func(ex): return ex["id"] == &"north")[0]["connected"]
		state["selected_early"] = ask(&"DungeonFloorTrackingGetRequested", {})["data"].get("stair_candidate", null) != null
		e["accepted"] = false
	var created := func(e):
		if str(e.get("room", "")).begins_with("room_"): state["announced"] += 1
	var bus = root.get_node("EventBus")
	bus.subscribe(&"RngFloatRequested", force_last)
	bus.subscribe(&"RngIntRequested", force_min)
	bus.subscribe(&"DungeonStairTrialRequested", reject_first)
	bus.subscribe(&"RoomCreated", created)
	var result := ask(&"RoomChildGenerateRequested", {"room":id(5), "exit":&"north"})
	bus.unsubscribe(&"DungeonStairTrialRequested", reject_first)
	bus.unsubscribe(&"RoomCreated", created)
	check(result.get("accepted", false) and result.get("type", "") == "deadend" and state["trials"] >= 2, "retry a failed stair candidate")
	check(state["announced"] == 1 and state["parent_unconnected"] and not state["selected_early"], "failed trial not connected, selected or published")
	check(not ask(&"RoomGenerationStatusGetRequested", {}).get("incomplete", true), "normal rollback remains healthy")
	if result.get("accepted", false):
		var room: Dictionary = ask(&"RoomGetRequested", {"id":result["child"]})["data"]
		var final_rect := Rect2i(room["origin_cell"] * 4, room["size_cells"] * 4)
		var first_origin: Vector2i = state["first_origin"] * 4
		var first_extent: Vector2i = state["first_size"] * 4
		var clean := true
		for y in range(first_origin.y, first_origin.y + first_extent.y):
			for x in range(first_origin.x, first_origin.x + first_extent.x):
				var p := Vector2i(x,y)
				if not final_rect.has_point(p) and ask(&"SpaceTileGetRequested", {"tile":p}).get("kind", 0) != 0: clean = false
		check(clean, "failed trial terrain outside committed room removed")
		var stair := ask(&"DungeonStairGetRequested", {})
		check(stair.get("found", false) and stair["data"].get("status", "") == "placed" and stair["data"]["room"] == result["child"], "published first suitable deadend has actual stair")
		check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false), "result saves")
	bus.unsubscribe(&"RngFloatRequested", force_last)
	bus.unsubscribe(&"RngIntRequested", force_min)
	print("Stair trial retry tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
