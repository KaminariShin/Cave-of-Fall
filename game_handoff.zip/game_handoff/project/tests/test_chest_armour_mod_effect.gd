extends SceneTree
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
	if not ok:
		failures += 1
		printerr("FAIL: ", label)
func ask(id: StringName, e: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id,e)
	return e
func armour(id: StringName) -> Dictionary:
	return ask(&"EquipmentArmourGetRequested", {"entity":id})
func state(id: StringName) -> Dictionary:
	return ask(&"ItemGetRequested", {"item":id})["item_data"]["learning_state"]
func wait_action(driver, steps: int = 1) -> bool:
	return ask(&"ActionStartRequested", {"entity":&"hero","action":&"wait","duration":steps * 0.01}).get("accepted",false) and driver.advance_steps(steps) == steps
func run() -> void:
	var driver = root.get_node("TimeDriver")
	driver.set_process(false)
	var bus = root.get_node("EventBus")
	var saver = root.get_node("SaveService")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"EntityCreateRequested", {"entity":&"npc"}).get("accepted",false), "entities")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"hero","volume":10}).get("accepted",false) and ask(&"InventoryConfigureRequested", {"entity":&"npc","volume":10}).get("accepted",false), "control/inventory")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0}).get("accepted",false), "low INT")
	var bases: Dictionary = saver.collect_world_transition_snapshot()["payload"]["sections"]["items"]["bases"]
	var schema: Dictionary = root.get_node("DungeonChestLearningService").schema_for(&"shield_small",bases)
	var early_mod := {"id":&"pre_armour", "category":"prefix", "stat":"armor", "tier":3, "value":2.0, "level_req":1, "material_id":&"iron_common", "unlock_after":5}
	check(ask(&"ItemCreateRequested", {"id":&"early", "base_id":&"shield_small", "item_level":20, "rarity":&"magic", "learning":schema}).get("accepted",false), "create early shield")
	check(ask(&"ItemModAttachRequested", {"item":&"early", "mod":early_mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc", "item":&"early"}).get("accepted",false), "early shield to NPC")
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc", "item":&"early", "slot":"off"}).get("accepted",false) and wait_action(driver,10) and state(&"early")["progress"] == 0 and not state(&"early")["identified"] and is_equal_approx(armour(&"npc")["armour"],7.0), "NPC uses unrevealed mod at zero progress")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"npc", "slot":"off"}).get("accepted",false) and wait_action(driver,10) and ask(&"InventoryRemoveRequested", {"entity":&"npc", "item":&"early"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero", "item":&"early"}).get("accepted",false), "transfer early shield")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"INT", "value":10}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"early", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and state(&"early")["progress"] < 5 and is_equal_approx(armour(&"hero")["armour"],5.0), "high INT alone does not activate unrevealed mod")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and state(&"early")["progress"] < 5, "unequip before reveal")
	check(ask(&"ItemLearningIdentifyRequested", {"entity":&"hero", "item":&"early"}).get("accepted",false) and driver.advance_steps(100) == 100 and state(&"early")["identified"] and state(&"early")["progress"] < 5, "identify before reveal")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero", "stat":&"INT", "value":0}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero", "item":&"early", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and is_equal_approx(armour(&"hero")["armour"],7.0), "identification activates mod before reveal")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"hero", "slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "clear early shield")
	check(ask(&"ItemCreateRequested", {"id":&"shield","base_id":&"shield_small","item_level":20,"rarity":&"magic","learning":schema}).get("accepted",false), "create")
	var mod := {"id":&"pre_armour", "category":"prefix", "stat":"armor", "tier":3, "value":2.0, "level_req":1, "material_id":&"iron_common", "unlock_after":5}
	check(ask(&"ItemModAttachRequested", {"item":&"shield","mod":mod}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false), "attach fixed mod and own")
	check(ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and is_equal_approx(armour(&"hero")["armour"],2.5), "unknown shield mod initially inactive")
	for i in range(4): check(wait_action(driver), "wait %d" % i)
	check(state(&"shield")["progress"] == 4 and is_equal_approx(armour(&"hero")["armour"],2.5), "mod inactive before fifth action")
	check(wait_action(driver) and state(&"shield")["progress"] == 5 and is_equal_approx(armour(&"hero")["armour"],5.0), "fifth action: base armor 3 plus mod 2")
	var protection := ask(&"PeriodicProtectionGetRequested", {"entity":&"hero","damage_type":"physical","percent":0.0})
	var expected := ask(&"ArmourProtectionCalculateRequested", {"armour":5.0,"percent_sources":[]})
	check(is_equal_approx(protection["percent"],expected["percent"]), "actual protection reflects mod")
	check(ask(&"SessionSaveRequested",{}).get("accepted",false) and ask(&"SessionLoadRequested",{}).get("accepted",false) and is_equal_approx(armour(&"hero")["armour"],5.0), "save/load")
	var mutate := func(e):
		if e.get("item",null) == &"shield" and e.get("found",false): e["item_data"]["mods"][0]["value"] = 999.0
	bus.subscribe(&"ItemGetRequested",mutate)
	var broken := armour(&"hero")
	var hp_before: float = ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["current"]
	check(not broken.get("found",true) and not ask(&"CombatDamageRequested", {"entity":&"hero","damage_type":"physical","amount":1}).get("accepted",true) and ask(&"ResourceGetRequested", {"entity":&"hero","resource":&"HP"})["data"]["current"] == hp_before, "invalid mod value fails closed")
	bus.unsubscribe(&"ItemGetRequested",mutate)
	var corrupt := {"mode":0}
	var invalid_mod := func(e):
		if e.get("item",null) != &"shield" or not e.get("found",false): return
		var m: Dictionary = e["item_data"]["mods"][0]
		match corrupt["mode"]:
			0: m["tier"] = 1; m["value"] = 6.0; m["level_req"] = 5
			1: m["material_id"] = &"cloth_light"
			2: m["unlock_after"] = 10
			3: e["item_data"].erase("learning")
	bus.subscribe(&"ItemGetRequested",invalid_mod)
	for i in range(4):
		corrupt["mode"] = i
		check(not armour(&"hero").get("found",true), "reject ineligible tier, material, or reveal step %d" % i)
	bus.unsubscribe(&"ItemGetRequested",invalid_mod)
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":10}).get("accepted",false) and not state(&"shield")["identified"] and is_equal_approx(armour(&"hero")["armour"],7.0), "sufficient INT removes base penalty, unlocked mod retained")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0}).get("accepted",false) and ask(&"EquipmentUnequipRequested", {"entity":&"hero","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10, "unequip")
	check(ask(&"InventoryRemoveRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false), "transfer NPC")
	var progress: int = state(&"shield")["progress"]
	check(ask(&"EquipmentEquipRequested", {"entity":&"npc","item":&"shield","slot":"off"}).get("accepted",false) and wait_action(driver,10) and is_equal_approx(armour(&"npc")["armour"],7.0) and state(&"shield")["progress"] == progress and not state(&"shield")["identified"], "NPC uses mod without learning or global identification")
	check(ask(&"EquipmentUnequipRequested", {"entity":&"npc","slot":"off"}).get("accepted",false) and wait_action(driver,10), "NPC removes")
	check(ask(&"InventoryRemoveRequested", {"entity":&"npc","item":&"shield"}).get("accepted",false) and ask(&"InventoryAddRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false), "return player")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":10}).get("accepted",false) and ask(&"ItemLearningIdentifyRequested", {"entity":&"hero","item":&"shield"}).get("accepted",false) and driver.advance_steps(100) == 100 and state(&"shield")["identified"], "identify")
	check(ask(&"StatBaseSetRequested", {"entity":&"hero","stat":&"INT","value":0}).get("accepted",false) and ask(&"EquipmentEquipRequested", {"entity":&"hero","item":&"shield","slot":"off"}).get("accepted",false) and driver.advance_steps(10) == 10 and is_equal_approx(armour(&"hero")["armour"],7.0), "identified mod always active and full base")
	print("Chest armour mod effect tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
