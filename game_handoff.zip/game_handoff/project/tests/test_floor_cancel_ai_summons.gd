extends SceneTree
var failures := 0
var children: Array = []
func _initialize() -> void: call_deferred("run")
func check(v: bool, text: String) -> void:
	if not v:
		failures += 1
		printerr("FAIL: ", text)
func ask(id: StringName, data: Dictionary) -> Dictionary:
	root.get_node("EventBus").publish(id, data)
	return data
func active(id: StringName) -> Dictionary: return ask(&"ActionGetRequested", {"entity":id}).get("data", {})
func mana(id: StringName) -> float: return float(ask(&"ResourceGetRequested", {"entity":id, "resource":&"MP"})["data"]["current"])
func run() -> void:
	var bus = root.get_node("EventBus")
	var driver = root.get_node("TimeDriver")
	var ai = root.get_node("AIService")
	var save = root.get_node("SaveService")
	driver.set_process(false)
	bus.subscribe(&"AISummoned", func(e): children.append(e["summon"]))
	check(ask(&"SpaceMapConfigureRequested", {"size":Vector2i(100,100)}).get("accepted", false), "map")
	check(ask(&"RoomCreateRequested", {"id":&"r", "type":"start", "origin_cell":Vector2i(2,2), "size_cells":Vector2i(11,11)}).get("accepted", false), "room")
	check(ask(&"EntityCreateRequested", {"entity":&"hero"}).get("accepted", false), "hero")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"hero", "anchor":Vector2i(12,12), "size":4}).get("accepted", false), "hero body")
	check(ask(&"ControlledEntityRequested", {"entity":&"hero"}).get("accepted", false), "controlled")
	check(ask(&"RoomEnterRequested", {"entity":&"hero", "room":&"r"}).get("accepted", false), "room enter")
	check(ask(&"EntityCreateRequested", {"entity":&"a"}).get("accepted", false), "a")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"a", "anchor":Vector2i(24,24), "size":4}).get("accepted", false), "a body")
	check(ask(&"AIRegisterRequested", {"entity":&"a", "room":&"r", "role":"summoner", "target":&"hero", "detected":true, "wait_duration":0.05}).get("accepted", false), "a AI")
	check(ask(&"ActionStartRequested", {"entity":&"hero", "action":&"wait", "duration":15.0}).get("accepted", false), "hero wait")
	ask(&"ResourceSetRequested", {"entity":&"a", "resource":&"MP", "value":25})
	driver.advance_steps(205)
	check(children.size() == 1, "completed summon")
	check(ask(&"EntityCreateRequested", {"entity":&"b"}).get("accepted", false), "b")
	check(ask(&"SpaceBodyPlaceRequested", {"entity":&"b", "anchor":Vector2i(35,35), "size":4}).get("accepted", false), "b body")
	check(ask(&"AIRegisterRequested", {"entity":&"b", "room":&"r", "role":"summoner", "target":&"hero", "detected":true, "wait_duration":0.05}).get("accepted", false), "b AI")
	ask(&"ResourceSetRequested", {"entity":&"b", "resource":&"MP", "value":25})
	driver.advance_steps(1)
	check(active(&"a").get("id", &"") == &"ai_summon" and active(&"b").get("id", &"") == &"ai_summon", "two pending summons")
	if children.is_empty() or active(&"a").get("id", &"") != &"ai_summon" or active(&"b").get("id", &"") != &"ai_summon":
		quit(1)
		return
	var child: StringName = children[0]
	var before_a := active(&"a")
	var before_b := active(&"b")
	var mana_a := mana(&"a")
	var mana_b := mana(&"b")
	check(not ai.cancel_pending_summons_for_transition().get("accepted", false), "outside transaction rejected")
	var observed := {"nested":true, "start":true, "cancelled_b":false}
	var callback := func(e):
		if e.get("entity", &"") != &"a" or e.get("reason", &"") != &"floor_transition": return
		observed["nested"] = ai.cancel_pending_summons_for_transition().get("accepted", true)
		observed["start"] = ask(&"ActionStartRequested", {"entity":&"a", "action":&"wait", "duration":0.1}).get("accepted", true)
		observed["cancelled_b"] = ask(&"ActionCancelRequested", {"entity":&"b"}).get("accepted", false)
	bus.subscribe(&"ActionInterrupted", callback)
	var out := {}
	var result: Dictionary = save.run_world_transition_transaction(func(): out["r"] = ai.cancel_pending_summons_for_transition(); return true)
	bus.unsubscribe(&"ActionInterrupted", callback)
	check(not observed["nested"] and not observed["start"] and observed["cancelled_b"], "reentrant start blocked, conflicting cancellation detected")
	check(not out["r"].get("accepted", true) and result.get("rolled_back", false), "forced rollback despite caller returning true")
	check(active(&"a") == before_a and active(&"b") == before_b and mana(&"a") == mana_a and mana(&"b") == mana_b, "pending actions and mana restored")
	check(ask(&"EntityGetRequested", {"entity":child}).get("found", false), "completed child survives rollback")
	var interruptions: Array = []
	var record := func(e):
		if e.get("reason", &"") == &"floor_transition": interruptions.append(e.get("entity"))
	bus.subscribe(&"ActionInterrupted", record)
	result = save.run_world_transition_transaction(func(): out["r"] = ai.cancel_pending_summons_for_transition(); return out["r"].get("accepted", false))
	bus.unsubscribe(&"ActionInterrupted", record)
	check(result.get("committed", false) and out["r"].get("entities", []) == [&"a", &"b"] and interruptions == [&"a", &"b"], "both pending summons canceled")
	check(active(&"a").is_empty() and active(&"b").is_empty() and active(&"hero").get("id", &"") == &"wait", "only summon actions canceled")
	check(mana(&"a") == mana_a and mana(&"b") == mana_b and ask(&"EntityGetRequested", {"entity":child}).get("found", false), "no mana charged, child preserved")
	check(ask(&"SessionSaveRequested", {}).get("accepted", false) and ask(&"SessionLoadRequested", {}).get("accepted", false) and active(&"a").is_empty(), "cancel persists")
	result = save.run_world_transition_transaction(func(): out["r"] = ai.cancel_pending_summons_for_transition(); return out["r"].get("accepted", false))
	check(result.get("committed", false) and out["r"].get("entities", [1]).is_empty(), "empty step is idempotent")
	print("Floor cancel AI summons tests: ", "PASS" if failures == 0 else "%d failed" % failures)
	quit(0 if failures == 0 else 1)
