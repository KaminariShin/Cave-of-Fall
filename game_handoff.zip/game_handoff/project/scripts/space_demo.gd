extends Control
## Изолированный стенд слоя пространства. Не демонстрирует действия или время.
const TILE_PX := 14
const OFFSET := Vector2(28, 74)
const MAP_SIZE := Vector2i(24, 16)
const HERO := &"space_demo_player"
var floors: Dictionary = {}
var passages: Dictionary = {}
var hero_anchor := Vector2i(2, 2)
var message := "Стрелки: переместить тело на один тайл."

func _ready() -> void:
	var map_request := {"size": MAP_SIZE, "accepted": false}
	EventBus.publish(&"SpaceMapConfigureRequested", map_request)
	if not map_request["accepted"]:
		message = "Не удалось создать тестовую карту."
		queue_redraw()
		return
	var tiles: Array = []
	for x in range(1, MAP_SIZE.x - 1):
		for y in range(1, MAP_SIZE.y - 1):
			if x == 12 and (y < 6 or y > 9):
				continue
			var tile := Vector2i(x, y)
			tiles.append(tile)
			floors[tile] = true
	EventBus.publish(&"SpaceTilesSetRequested", {"tiles": tiles, "kind": 1})
	var opening := [Vector2i(12, 6), Vector2i(12, 7), Vector2i(12, 8), Vector2i(12, 9)]
	var passage_request := {"tiles": opening, "accepted": false}
	EventBus.publish(&"SpacePassageSetRequested", passage_request)
	if passage_request["accepted"]:
		for tile in opening:
			passages[tile] = true
	var create := {"entity": HERO, "accepted": false}
	EventBus.publish(&"EntityCreateRequested", create)
	var place := {"entity": HERO, "anchor": hero_anchor, "size": 4, "accepted": false}
	EventBus.publish(&"SpaceBodyPlaceRequested", place)
	if not place["accepted"]:
		message = "Не удалось разместить тестовое тело."
	queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed:
		return
	var shift := Vector2i.ZERO
	match event.keycode:
		KEY_LEFT: shift = Vector2i.LEFT
		KEY_RIGHT: shift = Vector2i.RIGHT
		KEY_UP: shift = Vector2i.UP
		KEY_DOWN: shift = Vector2i.DOWN
		_: return
	var request := {"entity": HERO, "anchor": hero_anchor + shift, "accepted": false}
	EventBus.publish(&"SpaceBodyMoveRequested", request)
	if request["accepted"]:
		hero_anchor = request["anchor"]
		message = "Стрелки: переместить тело на один тайл."
	else:
		message = "Тело не помещается: скала или граница."
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("181e28"))
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(28, 29), "Стенд пространства: тело 4×4, проём 4 тайла", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_string(font, Vector2(28, 53), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("c9d4e5"))
	for x in range(MAP_SIZE.x):
		for y in range(MAP_SIZE.y):
			var tile := Vector2i(x, y)
			var color := Color("414d5d") if floors.has(tile) else Color("161b23")
			if passages.has(tile):
				color = Color("bea04f")
			draw_rect(Rect2(OFFSET + Vector2(tile) * TILE_PX, Vector2(TILE_PX - 1, TILE_PX - 1)), color)
	var body_rect := Rect2(OFFSET + Vector2(hero_anchor) * TILE_PX + Vector2.ONE, Vector2.ONE * (4 * TILE_PX - 2))
	draw_rect(body_rect, Color("5ed6c1"))
	draw_string(font, Vector2(28, 326), "Якорь: %s   Центр: %s" % [hero_anchor, Vector2(hero_anchor) + Vector2(2, 2)], HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
	draw_string(font, Vector2(28, 348), "Тест сетки: реальное игровое время не продвигается.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("c9d4e5"))
