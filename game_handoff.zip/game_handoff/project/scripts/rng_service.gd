extends Node
## Одна последовательность для всех систем; состояние можно сохранять.
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.seed = 0
	EventBus.subscribe(&"RngSeedRequested", _on_seed)
	EventBus.subscribe(&"RngIntRequested", _on_int)
	EventBus.subscribe(&"RngFloatRequested", _on_float)
	EventBus.subscribe(&"SnapshotCollectRequested", _on_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _on_apply)

func _on_seed(event: Dictionary) -> void:
	_rng.seed = int(event.get("seed", 0))
	event["accepted"] = true

func _on_int(event: Dictionary) -> void:
	var minimum := int(event.get("min", 0))
	var maximum := int(event.get("max", 0))
	if minimum > maximum:
		event["accepted"] = false
		return
	event["value"] = _rng.randi_range(minimum, maximum)
	event["accepted"] = true

func _on_float(event: Dictionary) -> void:
	event["value"] = _rng.randf()
	event["accepted"] = true

func _on_collect(event: Dictionary) -> void:
	event["sections"]["rng"] = {"seed": _rng.seed, "state": _rng.state}

func _on_apply(event: Dictionary) -> void:
	var state: Dictionary = event["sections"]["rng"]
	_rng.seed = state["seed"]
	_rng.state = state["state"]
