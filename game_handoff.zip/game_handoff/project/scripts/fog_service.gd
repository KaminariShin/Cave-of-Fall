extends Node
## Видимость ограничена радиусом и непрозрачной геометрией стен.
## Слух и обнаружение живых существ принадлежат DetectionService.
var _controlled: StringName = &""
var _radii: Dictionary = {}       # entity -> radius в физических тайлах
var _known_rooms: Dictionary = {} # room -> {origin, size}, оба Vector2i
var _scale := 4

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		_scale = int(rules["ruleset"].get("parameters", {}).get("space", {}).get("tiles_per_cell", 4))
	EventBus.subscribe(&"ControlledEntityRequested", _controlled_requested)
	EventBus.subscribe(&"FogDetectionRadiusSetRequested", _set_radius)
	EventBus.subscribe(&"DetectionRadiusChanged", _detection_radius_changed)
	EventBus.subscribe(&"FogStateGetRequested", _get_state)
	EventBus.subscribe(&"FogTileGetRequested", _get_tile)
	EventBus.subscribe(&"RoomDiscovered", _room_discovered)
	EventBus.subscribe(&"PlayerRoomChanged", _player_room_changed)
	EventBus.subscribe(&"EntityMoved", _entity_moved)
	EventBus.subscribe(&"SpaceBodyPlaced", _body_changed)
	EventBus.subscribe(&"SpaceBodyRemoved", _body_changed)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"SpaceMapConfigured", _map_configured)
	EventBus.subscribe(&"SpaceTilesChanged", _geometry_changed)
	EventBus.subscribe(&"SpacePassageChanged", _geometry_changed)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"SnapshotRestored", _snapshot_restored)

func _controlled_requested(event: Dictionary) -> void:
	if event.get("accepted", false):
		_controlled = event.get("entity", &"")
		_notify()

func _set_radius(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var radius = event.get("radius", null)
	var owner := {"entity": entity, "found": false}
	EventBus.publish(&"EntityGetRequested", owner)
	if not owner["found"] or not _valid_radius(radius):
		return
	if radius == null:
		_radii.erase(entity)
	else:
		_radii[entity] = float(radius)
	event["accepted"] = true
	if entity == _controlled:
		_notify()

## Тот же контракт для будущего сервиса обнаружения/PER.
func _detection_radius_changed(event: Dictionary) -> void:
	var request := {"entity": event.get("entity", &""), "radius": event.get("radius", null)}
	_set_radius(request)

func _get_state(event: Dictionary) -> void:
	var observer := _observer_data()
	event["controlled"] = _controlled
	event["known_rooms"] = _room_geometry()
	event["radius_known"] = observer["radius_known"]
	event["observer_placed"] = observer["placed"]
	event["visible_tiles"] = []
	if not observer["radius_known"] or not observer["placed"]:
		return
	event["radius"] = observer["radius"]
	event["center"] = observer["center"]
	var center: Vector2 = observer["center"]
	var radius: float = observer["radius"]
	var visible: Dictionary = {}
	var sight := _sight_context(center, radius)
	for id in _known_rooms:
		var room: Dictionary = _known_rooms[id]
		var origin: Vector2i = room["origin"]
		var extent: Vector2i = room["size"]
		# Для очень большого радиуса сначала ограничиваем рамкой комнаты,
		# затем преобразуем в int: это избегает переполнения floori/ceili.
		var min_x := int(maxf(float(origin.x), floor(center.x - radius - 0.5)))
		var min_y := int(maxf(float(origin.y), floor(center.y - radius - 0.5)))
		var max_x := int(minf(float(origin.x + extent.x - 1), ceil(center.x + radius - 0.5)))
		var max_y := int(minf(float(origin.y + extent.y - 1), ceil(center.y + radius - 0.5)))
		for x in range(min_x, max_x + 1):
			for y in range(min_y, max_y + 1):
				var tile := Vector2i(x, y)
				if _within_radius(tile, center, radius) and _line_visible(center,tile,sight):
					visible[tile] = true
	event["visible_tiles"] = visible.keys()

func _get_tile(event: Dictionary) -> void:
	var tile = event.get("tile", null)
	event["accepted"] = tile is Vector2i
	if not event["accepted"]:
		return
	var room := _room_for_tile(tile)
	event["room_known"] = room != &""
	event["room"] = room if room != &"" else null
	var observer := _observer_data()
	event["radius_known"] = observer["radius_known"]
	event["terrain_visible"] = false
	if event["room_known"] and observer["placed"] and observer["radius_known"]:
		var center: Vector2 = observer["center"]
		var radius: float = observer["radius"]
		if _within_radius(tile,center,radius): event["terrain_visible"] = _line_visible(center,tile,_sight_context(center,radius))

# Снимок пола ограничен радиусом и границами карты. Пустые клетки — стены.
func _sight_context(center: Vector2, radius: float) -> Dictionary:
	var map := {}
	EventBus.publish(&"SpaceMapGetRequested",map)
	if not map.get("configured",false): return {}
	var size: Vector2i = map["size"]
	var low := Vector2i(int(maxf(0.0,floor(center.x-radius-1.0))),int(maxf(0.0,floor(center.y-radius-1.0))))
	var high := Vector2i(int(minf(float(size.x),ceil(center.x+radius+1.0))),int(minf(float(size.y),ceil(center.y+radius+1.0))))
	if high.x <= low.x or high.y <= low.y: return {}
	var region := {"origin":low,"size":high-low}
	EventBus.publish(&"SpaceRegionGetRequested",region)
	return region.get("floor",{}) if region.get("accepted",false) else {}

# Supercover DDA из центра тела к центру цели: последняя стена видна,
# но за ней луч не проходит. На точной границе двух стен нельзя видеть
# через точку их соприкосновения (щель нулевой ширины).
func _line_visible(start: Vector2, target: Vector2i, floors: Dictionary) -> bool:
	var cell := Vector2i(floori(start.x),floori(start.y))
	if cell == target: return true
	var delta := Vector2(target)+Vector2.ONE*0.5-start
	var sx := signi(int(signf(delta.x)))
	var sy := signi(int(signf(delta.y)))
	var tx := INF if sx == 0 else ((float(cell.x+1) if sx > 0 else float(cell.x))-start.x)/delta.x
	var ty := INF if sy == 0 else ((float(cell.y+1) if sy > 0 else float(cell.y))-start.y)/delta.y
	var dx := INF if sx == 0 else absf(1.0/delta.x)
	var dy := INF if sy == 0 else absf(1.0/delta.y)
	while cell != target:
		if absf(tx-ty) < 0.00000001:
			# Одной непрозрачной стороны достаточно: луч не просачивается по краю стены.
			if not floors.has(cell+Vector2i(sx,0)) or not floors.has(cell+Vector2i(0,sy)): return false
			cell += Vector2i(sx,sy)
			tx += dx
			ty += dy
		elif tx < ty:
			cell.x += sx
			tx += dx
		else:
			cell.y += sy
			ty += dy
		if cell == target: return true
		if not floors.has(cell): return false
	return true

func _room_discovered(event: Dictionary) -> void:
	_add_known_room(event.get("room", &""))
	_notify()

func _add_known_room(room_id: StringName) -> void:
	var request := {"id": room_id, "found": false}
	EventBus.publish(&"RoomGetRequested", request)
	if request["found"] and request["data"]["discovered"]:
		var data: Dictionary = request["data"]
		_known_rooms[room_id] = {"origin": data["origin_cell"] * _scale, "size": data["size_cells"] * _scale}

func _player_room_changed(event: Dictionary) -> void:
	if event.get("entity", &"") == _controlled:
		_notify()

func _entity_moved(event: Dictionary) -> void:
	if event.get("entity", &"") == _controlled:
		_notify()

func _body_changed(event: Dictionary) -> void:
	if event.get("entity", &"") == _controlled:
		_notify()

func _entity_removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	_radii.erase(entity)
	if entity == _controlled:
		_controlled = &""
		_notify()

func _map_configured(_event: Dictionary) -> void:
	_known_rooms.clear()
	_notify()

func _observer_data() -> Dictionary:
	var result := {"radius_known": _radii.has(_controlled), "placed": false}
	if result["radius_known"]:
		result["radius"] = _radii[_controlled]
	var body := {"entity": _controlled, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	if body["found"]:
		result["placed"] = true
		result["center"] = body["data"]["center"]
	return result

func _room_geometry() -> Array:
	var result: Array = []
	for id in _known_rooms:
		result.append({"room": id, "origin": _known_rooms[id]["origin"], "size": _known_rooms[id]["size"]})
	return result

func _room_for_tile(tile: Vector2i) -> StringName:
	for id in _known_rooms:
		var room: Dictionary = _known_rooms[id]
		var origin: Vector2i = room["origin"]
		var size: Vector2i = room["size"]
		if tile.x >= origin.x and tile.y >= origin.y and tile.x < origin.x + size.x and tile.y < origin.y + size.y:
			return id
	return &""

func _within_radius(tile: Vector2i, center: Vector2, radius: float) -> bool:
	# distance_to не возводит большой радиус в квадрат вручную.
	return (Vector2(tile) + Vector2(0.5, 0.5)).distance_to(center) <= radius

func _valid_radius(radius: Variant) -> bool:
	return radius == null or ((radius is int or radius is float) and is_finite(float(radius)) and float(radius) >= 0.0)

func _notify() -> void:
	EventBus.publish(&"FogVisibilityChanged", {"entity": _controlled})

func _snapshot_collect(event: Dictionary) -> void:
	event["sections"]["fog"] = {"controlled": _controlled, "radii": _radii.duplicate(true)}

func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["fog"]
	_controlled = data["controlled"]
	_radii = data["radii"].duplicate(true)
	_known_rooms.clear()

func _snapshot_restored(_event: Dictionary) -> void:
	_known_rooms.clear()
	var query := {"rooms": []}
	EventBus.publish(&"DiscoveredRoomsGetRequested", query)
	for room_id in query["rooms"]:
		_add_known_room(room_id)
	_notify()

func _geometry_changed(_event: Dictionary) -> void:
	_notify()
