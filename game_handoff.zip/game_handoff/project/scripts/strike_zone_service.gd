extends Node
## Единственный расчёт тайлов зоны: его используют подсветка, проверка тела и урон.
const MAX_REGION_TILES := 300000
const EPS := 0.000001
var _weapons: Dictionary = {}
var _shapes: Dictionary = {}
var _inner_offset := -0.3
var _outer_offset := 0.35

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var data: Dictionary = rules["ruleset"].get("parameters", {}).get("combat", {})
		_weapons = data.get("weapons", {}).duplicate(true)
		_shapes = data.get("strike_shapes", {}).duplicate(true)
		_inner_offset = float(data.get("strike_band_inner_offset", -0.3))
		_outer_offset = float(data.get("strike_band_outer_offset", 0.35))
	EventBus.subscribe(&"StrikeZoneGetRequested", _get_zone)
	EventBus.subscribe(&"StrikeZoneBodyTestRequested", _test_body)
	EventBus.subscribe(&"StrikeZoneDamageRequested", _damage_bodies)

## entity, direction, weapon_type и shape/shape_id; результат tiles — для подсветки.
func _get_zone(event: Dictionary) -> void:
	for key in ["tiles", "tile_set", "center", "min_distance", "max_distance", "error"]:
		event.erase(key)
	var result := _build_zone(event)
	event.merge(result, true)

func _test_body(event: Dictionary) -> void:
	event.erase("hit_tiles")
	event.erase("error")
	event["accepted"] = false
	event["hit"] = false
	var target = event.get("target", null)
	if not (target is StringName or target is String):
		event["error"] = "Нужна цель"
		return
	var zone := _build_zone(event)
	if not zone["accepted"]:
		event["error"] = zone.get("error", "Недопустимая зона")
		return
	var body := _body(StringName(str(target)))
	if body.is_empty():
		event["error"] = "У цели нет тела"
		return
	var intersection := _body_tiles_in_zone(StringName(str(target)), body, zone["tile_set"])
	if not intersection["accepted"]:
		event["error"] = intersection["error"]
		return
	var hit_tiles: Array = intersection["tiles"]
	event["accepted"] = true
	event["hit"] = not hit_tiles.is_empty()
	event["hit_tiles"] = hit_tiles

## targets передаёт вызывающая боевая логика; фракции/союзники пока не заданы.
## Каждый объект получает урон один раз даже при пересечении нескольких тайлов.
func _damage_bodies(event: Dictionary) -> void:
	event.erase("hits")
	event.erase("error")
	event["accepted"] = false
	var attacker: StringName = event.get("entity", &"")
	var amount = event.get("amount", null)
	var targets = event.get("targets", null)
	if not _valid_number(amount) or float(amount) < 0.0 or not targets is Array:
		event["error"] = "Нужны неотрицательный amount и список targets"
		return
	for target in targets:
		if not (target is StringName or target is String) or str(target).is_empty():
			event["error"] = "Недопустимая цель"
			return
	var alive := {"entity": attacker, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	if not alive["allowed"]:
		event["error"] = "Носитель погиб"
		return
	var zone := _build_zone(event)
	if not zone["accepted"]:
		event["error"] = zone.get("error", "Недопустимая зона")
		return
	# Сначала фиксируем пересечения, затем рассылаем урон; обработчики могут менять мир.
	var hits: Array = []
	var seen: Dictionary = {}
	for target in targets:
		var id := StringName(str(target))
		if id == attacker or seen.has(id):
			continue
		seen[id] = true
		var body := _body(id)
		if body.is_empty():
			continue
		var intersection := _body_tiles_in_zone(id, body, zone["tile_set"])
		if not intersection["accepted"]:
			event["error"] = intersection["error"]
			return
		var hit_tiles: Array = intersection["tiles"]
		if not hit_tiles.is_empty():
			hits.append({"entity": id, "hit_tiles": hit_tiles})
	for hit in hits:
		var damage := {"entity": hit["entity"], "source": attacker, "amount": float(amount), "accepted": false}
		if event.has("damage_type"): damage["damage_type"] = event["damage_type"]
		EventBus.publish(&"CombatDamageRequested", damage)
		hit["accepted"] = damage["accepted"]
		hit["applied"] = damage.get("applied", 0.0)
	event["accepted"] = true
	event["hits"] = hits

func _build_zone(event: Dictionary) -> Dictionary:
	var entity: StringName = event.get("entity", &"")
	var body := _body(entity)
	if body.is_empty():
		return _fail("У атакующего нет тела")
	var raw_direction = event.get("direction", null)
	if not (raw_direction is Vector2 or raw_direction is Vector2i):
		return _fail("Нужен ненулевой direction")
	var direction := Vector2(raw_direction)
	var magnitude := direction.length()
	if not is_finite(direction.x) or not is_finite(direction.y) or not is_finite(magnitude) or magnitude <= EPS:
		return _fail("Нужен конечный ненулевой direction")
	direction /= magnitude
	var weapon_id := str(event.get("weapon_type", ""))
	if not _weapons.has(weapon_id):
		return _fail("Неизвестный weapon_type")
	var weapon: Dictionary = _weapons[weapon_id]
	var reach = event.get("range", weapon.get("range", null))
	var gap = event.get("gap", weapon.get("gap", null))
	if not _valid_number(reach) or float(reach) < 0.0 or not _valid_number(gap) or float(gap) < 0.0:
		return _fail("range и gap должны быть неотрицательными")
	var shape = event.get("shape", null)
	if shape == null and event.has("shape_id"):
		shape = _shapes.get(str(event["shape_id"]), null)
	if shape == null:
		shape = weapon.get("shape", null)
	if not shape is Dictionary:
		return _fail("Параметры формы не заданы")
	# reach_bound означает: форма ограничена общей полосой дальности, без
	# независимого фиксированного радиуса от центра тела.
	if shape.has("reach_bound"):
		if not shape["reach_bound"] is bool: return _fail("Некорректный reach_bound")
		if shape["reach_bound"]:
			if shape.has("radius") or shape.has("diameter") or shape.has("length"): return _fail("Нельзя сочетать reach_bound с размером")
			shape = shape.duplicate(true)
			var outer: float = float(body["size"]) / 2.0 + float(gap) + float(reach) + _outer_offset
			if not is_finite(outer) or outer <= 0: return _fail("Некорректная дальность")
			if shape.get("type", "") == "arc": shape["radius"] = outer
			elif shape.get("type", "") == "line": shape["length"] = outer
			else: return _fail("reach_bound доступен для линии и дуги")
	var form := _validate_shape(shape)
	if not form["accepted"]:
		return form
	var movement := {"entity": entity, "found": false}
	EventBus.publish(&"MovementPositionGetRequested", movement)
	var position: Vector2 = movement["position"] if movement["found"] else Vector2(body["anchor"])
	var center: Vector2 = position + Vector2.ONE * float(body["size"]) / 2.0
	var map := {"configured": false}
	EventBus.publish(&"SpaceMapGetRequested", map)
	if not map["configured"]:
		return _fail("Карта не задана")
	var map_size: Vector2i = map["size"]
	if not is_finite(center.x) or not is_finite(center.y) or center.x < 0 or center.y < 0 or center.x >= map_size.x or center.y >= map_size.y:
		return _fail("Центр вне карты")
	var half_body := float(body["size"]) / 2.0
	var min_dist: float = maxf(0.0, half_body + float(gap) + _inner_offset)
	var max_dist: float = half_body + float(gap) + float(reach) + _outer_offset
	if not is_finite(min_dist) or not is_finite(max_dist) or max_dist < min_dist:
		return _fail("Недопустимая полоса расстояний")
	var extent: float = minf(max_dist, float(form["extent"]))
	# Обрезаем ДО преобразования в int, чтобы большие параметры не переполнили координаты.
	var x0 := floori(maxf(0.0, center.x - extent - 1.0))
	var y0 := floori(maxf(0.0, center.y - extent - 1.0))
	var x1 := ceili(minf(float(map_size.x), center.x + extent + 1.0))
	var y1 := ceili(minf(float(map_size.y), center.y + extent + 1.0))
	if (x1 - x0) * (y1 - y0) > MAX_REGION_TILES:
		return _fail("Слишком большая область проверки")
	var region := {"origin": Vector2i(x0, y0), "size": Vector2i(x1 - x0, y1 - y0), "accepted": false}
	EventBus.publish(&"SpaceRegionGetRequested", region)
	if not region["accepted"]:
		return _fail("Не удалось получить карту")
	var floors: Dictionary = region["floor"]
	var from := Vector2i(floori(center.x), floori(center.y))
	var tiles: Array = []
	var tile_set: Dictionary = {}
	for y in range(y0, y1):
		for x in range(x0, x1):
			var tile := Vector2i(x, y)
			if not floors.has(tile):
				continue
			var delta := Vector2(tile) + Vector2(0.5, 0.5) - center
			var distance := delta.length()
			if distance + EPS < min_dist or distance - EPS > max_dist:
				continue
			if not _in_shape(delta, distance, direction, form):
				continue
			if not _line_of_sight(from, tile, floors):
				continue
			tiles.append(tile)
			tile_set[tile] = true
	return {"accepted": true, "tiles": tiles, "tile_set": tile_set, "center": center, "min_distance": min_dist, "max_distance": max_dist}

func _validate_shape(shape: Dictionary) -> Dictionary:
	var kind := str(shape.get("type", ""))
	var result := {"accepted": true, "type": kind}
	if kind == "line":
		if not _valid_number(shape.get("length", null)) or float(shape["length"]) <= 0.0 or not _valid_number(shape.get("width", null)) or float(shape["width"]) <= 0.0:
			return _fail("Для линии нужны положительные length и width")
		result["length"] = float(shape["length"])
		result["width"] = float(shape["width"])
		# Дальний угол полосы находится дальше её длины.
		result["extent"] = sqrt(pow(result["length"], 2) + pow(result["width"] / 2.0, 2))
	elif kind == "arc" or kind == "cone":
		var angle = shape.get("angle_degrees", null)
		if not _valid_number(angle) or float(angle) <= 0.0 or float(angle) > 360.0:
			return _fail("angle_degrees должен быть в (0, 360]")
		var distance = null
		if kind == "arc":
			if shape.has("radius") and shape.has("diameter"):
				return _fail("Укажите radius или diameter, но не оба")
			if shape.has("radius"):
				distance = shape["radius"]
			elif _valid_number(shape.get("diameter", null)):
				distance = float(shape["diameter"]) / 2.0
		else:
			distance = shape.get("length", null)
		if not _valid_number(distance) or float(distance) <= 0.0:
			return _fail("Для дуги нужен radius или diameter; для конуса length")
		result["extent"] = float(distance)
		result["angle_degrees"] = float(angle)
	else:
		return _fail("Неизвестная форма")
	if not is_finite(float(result["extent"])):
		return _fail("Размер формы слишком велик")
	return result

func _in_shape(delta: Vector2, distance: float, direction: Vector2, form: Dictionary) -> bool:
	if form["type"] == "line":
		var along := delta.dot(direction)
		var across := absf(delta.x * direction.y - delta.y * direction.x)
		return along >= -EPS and along <= float(form["length"]) + EPS and across <= float(form["width"]) / 2.0 + EPS
	if distance > float(form["extent"]) + EPS:
		return false
	if distance <= EPS or float(form["angle_degrees"]) >= 360.0:
		return true
	var cosine := direction.dot(delta) / distance
	return cosine + EPS >= cos(deg_to_rad(float(form["angle_degrees"]) / 2.0))

## Обычный Bresenham, включает начальный и конечный тайл; только пол прозрачен.
func _line_of_sight(from: Vector2i, to: Vector2i, floors: Dictionary) -> bool:
	var x := from.x
	var y := from.y
	var dx := absi(to.x - x)
	var dy := -absi(to.y - y)
	var sx := 1 if x < to.x else -1
	var sy := 1 if y < to.y else -1
	var error := dx + dy
	while true:
		if not floors.has(Vector2i(x, y)):
			return false
		if x == to.x and y == to.y:
			return true
		var e2 := error * 2
		if e2 >= dy:
			error += dy
			x += sx
		if e2 <= dx:
			error += dx
			y += sy
	return false

func _body(entity: StringName) -> Dictionary:
	var query := {"entity": entity, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", query)
	return query.get("data", {}) if query["found"] else {}

# Положительная площадь, а не касание края; положение берётся в текущем
# игровом шаге. Логическая занятость карты при этом не меняется.
func _body_tiles_in_zone(entity: StringName, body: Dictionary, zone: Dictionary) -> Dictionary:
	var size = body.get("size",null)
	var anchor = body.get("anchor",null)
	if not size is int or size <= 0 or size > 10000 or not anchor is Vector2i: return _fail("Некорректное тело цели")
	var query := {"entity":entity,"found":false}
	EventBus.publish(&"MovementPositionGetRequested",query)
	var p = query.get("position",null)
	if not query.get("found",false) or not p is Vector2 or not is_finite(p.x) or not is_finite(p.y): return _fail("Положение цели недоступно")
	# Обход ограничен числом тайлов уже рассчитанной зоны, не размером тела.
	var hits: Array = []
	for tile in zone:
		if float(tile.x) < p.x + size and float(tile.x + 1) > p.x and float(tile.y) < p.y + size and float(tile.y + 1) > p.y:
			hits.append(tile)
	hits.sort_custom(func(a,b): return a.y < b.y or (a.y == b.y and a.x < b.x))
	return {"accepted":true,"tiles":hits}

func _valid_number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))
func _fail(message: String) -> Dictionary:
	return {"accepted": false, "error": message}
