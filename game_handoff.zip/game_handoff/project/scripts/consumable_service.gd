extends Node
## Самостоятельное применение расходников только из инвентаря; пояс пока не подключён.
const ACTION := &"consumable_use"
const KINDS := ["antidote", "bandage", "heal_hp", "heal_stamina", "heal_mp"]
var _pending: Dictionary = {}
var _busy: Dictionary = {}

func _ready() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION, "name":"Применить расходник", "type":&"utility", "base_duration":0.5, "interruptible":true}})
	EventBus.subscribe(&"ConsumableUseRequested", _use)
	EventBus.subscribe(&"ActionCompleted", _completed)
	EventBus.subscribe(&"ActionInterrupted", _interrupted)
	EventBus.subscribe(&"EntityDied", _removed)
	EventBus.subscribe(&"EntityRemoved", _removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _restore)
	EventBus.subscribe(&"ConsumableSnapshotValidateRequested", _validate)

func _use(e: Dictionary) -> void:
	e["accepted"] = false
	var entity = e.get("entity", null)
	var id = e.get("item", null)
	if not entity is StringName or entity == &"" or not id is StringName or id == &"" or _pending.has(entity) or _busy.has(entity): return
	var item := {"item":id, "found":false}
	EventBus.publish(&"ItemGetRequested", item)
	if not item["found"] or str(item["base"].get("slot", "")) != "consumable": return
	var kind := str(item["base"].get("consumable_kind", ""))
	var amount = item["base"].get("consumable_amount", 0)
	if kind not in KINDS or not (amount is int or amount is float) or not is_finite(float(amount)) or amount < 0 or float(amount) != floorf(float(amount)) or amount > 1000000 or (kind.begins_with("heal_") and amount == 0): return
	amount = int(amount)
	var inventory := {"entity":entity, "found":false}
	EventBus.publish(&"InventoryGetRequested", inventory)
	if not inventory.get("found", false) or not inventory["data"].get("items", []).has(id): return
	_busy[entity] = true
	_pending[entity] = {"kind":kind, "amount":amount, "item":id}
	var start := {"entity":entity, "action":ACTION, "duration":0.5, "accepted":false}
	EventBus.publish(&"ActionStartRequested", start)
	if not start["accepted"]:
		_pending.erase(entity)
		_busy.erase(entity)
		return
	var consume := {"entity":entity, "item":id, "accepted":false}
	EventBus.publish(&"ItemConsumeFromInventoryRequested", consume)
	if not consume["accepted"]:
		_pending.erase(entity)
		var action := {"entity":entity, "found":false}
		EventBus.publish(&"ActionGetRequested", action)
		if action.get("found", false) and action["data"].get("id", null) == ACTION:
			EventBus.publish(&"ActionCancelRequested", {"entity":entity, "reason":&"consumable_unavailable"})
		_busy.erase(entity)
		return
	_busy.erase(entity)
	e["accepted"] = true

func _completed(e: Dictionary) -> void:
	var entity: StringName = e.get("entity", &"")
	if e.get("action", null) != ACTION or not _pending.has(entity): return
	var op: Dictionary = _pending[entity]
	_pending.erase(entity)
	var kind: String = op["kind"]
	var success := false
	if kind in ["antidote", "bandage"]:
		var effect := &"poison" if kind == "antidote" else &"bleeding"
		EventBus.publish(&"PeriodicEffectRemoveRequested", {"entity":entity, "effect":effect})
		# Применение успешно и если эффекта не было.
		success = true
	else:
		var resource: StringName = {"heal_hp":&"HP", "heal_stamina":&"Stamina", "heal_mp":&"MP"}[kind]
		var query := {"entity":entity, "resource":resource, "found":false}
		EventBus.publish(&"ResourceGetRequested", query)
		if query.get("found", false):
			var set := {"entity":entity, "resource":resource, "value":float(query["data"]["current"]) + float(op["amount"]), "accepted":false}
			EventBus.publish(&"ResourceSetRequested", set)
			success = set["accepted"]
			if success and resource == &"HP": EventBus.publish(&"PeriodicEffectRemoveRequested", {"entity":entity, "effect":&"bleeding"})
	EventBus.publish(&"ConsumableUseCompleted", {"entity":entity, "item":op["item"], "kind":kind, "success":success})

func _interrupted(e: Dictionary) -> void:
	var entity = e.get("entity", &"")
	if e.get("action", null) == ACTION: _pending.erase(entity)

func _removed(e: Dictionary) -> void:
	_pending.erase(e.get("entity", &""))

func _collect(e: Dictionary) -> void:
	if not _busy.is_empty():
		e["errors"].append("Нельзя сохранять во время начала применения расходника")
		return
	e["sections"]["consumable_actions"] = _pending.duplicate(true)

func _restore(e: Dictionary) -> void:
	_pending = e["sections"]["consumable_actions"].duplicate(true)
	_busy.clear()

func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary or not sections.get("consumable_actions", null) is Dictionary or not sections.get("actions", {}).get("active", null) is Dictionary or not sections.get("entities", null) is Dictionary or not sections.get("items", {}).get("retired", null) is Dictionary: return
	var actions: Dictionary = sections["actions"]["active"]
	for entity in sections["consumable_actions"]:
		var op = sections["consumable_actions"][entity]
		if not entity is StringName or not sections["entities"].has(entity) or not op is Dictionary or op.get("kind", "") not in KINDS or not op.get("amount", null) is int or op["amount"] < 0 or (str(op["kind"]).begins_with("heal_") and op["amount"] == 0): return
		if not op.get("item", null) is StringName or not sections["items"]["retired"].has(op["item"]): return
		if not actions.has(entity) or not actions[entity] is Dictionary or actions[entity].get("id", null) != ACTION: return
	for entity in actions:
		if actions[entity] is Dictionary and actions[entity].get("id", null) == ACTION and not sections["consumable_actions"].has(entity): return
	e["valid"] = true
