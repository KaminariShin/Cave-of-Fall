extends Node
## Явная техническая операция до боя; автоматическое оснащение спавна ещё не подключено.
var _busy := false
var _boss: StringName = &""
var _authorize_ownership := false
var _recording := false
var _record_items: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"DungeonBossEquipmentInstallRequested", _request)
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested", _ownership_guard)
	EventBus.subscribe(&"LootEntityRemovalCheckRequested", _removal_guard)
	EventBus.subscribe(&"CombatDamageAllowedRequested", _damage_guard)
	EventBus.subscribe(&"ActionStartAllowedRequested", _action_guard)

func _ownership_guard(e: Dictionary) -> void:
	if not _busy: return
	if _authorize_ownership and e.get("entity", null) == _boss:
		_authorize_ownership = false # одна авторизованная запись, без повторного входа
	else: e["allowed"] = false
func _removal_guard(e: Dictionary) -> void:
	if _busy and e.get("entity", null) == _boss: e["allowed"] = false
func _damage_guard(e: Dictionary) -> void:
	if _busy and e.get("entity", null) == _boss: e["allowed"] = false
func _action_guard(e: Dictionary) -> void:
	if _busy and e.get("entity", null) == _boss: e["allowed"] = false

func authorizes_loadout_record(entity: StringName, items: Dictionary) -> bool:
	return _busy and _recording and entity == _boss and items == _record_items

func _request(e: Dictionary) -> void:
	e["accepted"] = false
	e["rolled_back"] = false
	var id = e.get("entity", null)
	if _busy or not id is StringName or id == &"":
		e["error"] = "Оснащение недоступно"; return
	_busy = true
	_boss = id
	var work := {"error":"", "items":{}}
	var tx: Dictionary = SaveService.run_world_transition_transaction(func(): return _execute(id, work))
	_authorize_ownership = false
	_recording = false
	_record_items.clear()
	_boss = &""
	_busy = false
	e["accepted"] = tx.get("committed", false)
	e["rolled_back"] = tx.get("rolled_back", false)
	if not e["accepted"]:
		e["error"] = work["error"] if not work["error"].is_empty() else tx.get("error", "Не удалось оснастить босса")
		return
	e["items"] = work["items"].duplicate(true)
	EventBus.publish(&"DungeonBossEquipmentInstalled", {"entity":id, "items":e["items"].duplicate(true)})

func _execute(id: StringName, work: Dictionary) -> bool:
	var snap: Dictionary = SaveService._collect_transition_snapshot()
	if not snap.get("valid", false): return _fail(work, "Исходный снимок недоступен")
	var s: Dictionary = snap["payload"]["sections"]
	var boss: Dictionary = s["spawn"]["boss"]
	if boss.get("status", "") != "alive" or boss.get("entity", null) != id or boss.get("loadout", null) != null or s["combat"]["dead"].has(id) or not s["entities"].has(id) or not s["space"]["bodies"].has(id) or s["actions"]["active"].has(id): return _fail(work, "Нужен живой зафиксированный босс без действия")
	var before_actor: Dictionary = s["entities"][id].duplicate(true)
	var before_gear = before_actor.get(&"equipment", {})
	if not before_gear is Dictionary or not before_gear.is_empty(): return _fail(work, "Экипировка босса уже занята")
	var spawn = before_actor.get(&"spawn", null)
	if not spawn is Dictionary or spawn.get("type_id", "") != "final_ogre" or not spawn.get("level", null) is int or spawn["level"] < 1: return _fail(work, "Неизвестный тип или уровень босса")
	var level: int = spawn["level"]
	var items: Dictionary = s["items"]["instances"]
	var retired: Dictionary = s["items"]["retired"]
	var hammer := _free_id(id, "hammer", items, retired)
	var armour := _free_id(id, "armour", items, retired)
	if hammer == &"" or armour == &"": return _fail(work, "Нет свободных ID вещей")
	for spec in [[hammer, &"hammer_simple"], [armour, &"armor_iron_body"]]:
		var create := {"id":spec[0], "base_id":spec[1], "item_level":level, "rarity":&"normal", "accepted":false}
		EventBus.publish(&"ItemCreateRequested", create)
		if not create.get("accepted", false): return _fail(work, "Не удалось создать вещь босса")
	var slots := {"main":hammer, "body":armour}
	_authorize_ownership = true
	var equip := {"entity":id, "component":&"equipment", "data":slots, "accepted":false}
	EventBus.publish(&"ComponentSetRequested", equip)
	_authorize_ownership = false
	if not equip.get("accepted", false): return _fail(work, "Не удалось назначить вещи боссу")
	_record_items = slots.duplicate(true)
	_recording = true
	var recorded: bool = SpawnService.record_boss_loadout(id, slots)
	_recording = false
	_record_items.clear()
	if not recorded: return _fail(work, "Не удалось зафиксировать выдачу экипировки")
	var expected_boss := boss.duplicate(true)
	expected_boss["loadout"] = slots.duplicate(true)
	var after: Dictionary = SaveService._collect_transition_snapshot()
	if not after.get("valid", false): return _fail(work, "Результат оснащения не прошёл проверку")
	var a: Dictionary = after["payload"]["sections"]
	var actor: Dictionary = a["entities"].get(id, {})
	if actor.get(&"equipment", null) != slots or a["spawn"]["boss"] != expected_boss or a["time"] != s["time"] or a["rng"] != s["rng"]: return _fail(work, "Состояние изменилось во время оснащения")
	actor = actor.duplicate(true)
	if before_actor.has(&"equipment"): actor[&"equipment"] = before_gear
	else: actor.erase(&"equipment")
	if actor != before_actor: return _fail(work, "Персонаж босса изменился во время оснащения")
	for spec in [[hammer, &"hammer_simple"], [armour, &"armor_iron_body"]]:
		var item = a["items"]["instances"].get(spec[0], null)
		var base = a["items"]["bases"].get(spec[1], null)
		if not item is Dictionary or not base is Dictionary or item.get("base_id", null) != spec[1] or item.get("item_level", null) != level or item.get("rarity", null) != &"normal" or item.get("mods", null) != [] or item.get("materials", null) != base.get("materials", null): return _fail(work, "Созданная вещь изменилась")
	work["items"] = slots
	return true

func _free_id(boss: StringName, kind: String, items: Dictionary, retired: Dictionary) -> StringName:
	for n in range(10000):
		var id := StringName("boss_%s_%s_%d" % [str(boss), kind, n])
		if not items.has(id) and not retired.has(id): return id
	return &""
func _fail(work: Dictionary, error: String) -> bool:
	work["error"] = error
	return false
