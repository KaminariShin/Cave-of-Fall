extends Node
## Подготовка данных, без записи профиля и без завершения забега.
var _busy := false

func _ready() -> void:
	EventBus.subscribe(&"VictoryCheckpointPrepareRequested", _prepare)

func _prepare(e: Dictionary) -> void:
	e["accepted"] = false
	e["executable"] = false
	e.erase("checkpoint")
	var actor = e.get("entity", null)
	var portal = e.get("object", null)
	if _busy or not actor is StringName or actor == &"" or not portal is StringName or portal == &"":
		e["error"] = "Подготовка недоступна"; return
	_busy = true
	var collected: Dictionary = SaveService.collect_world_transition_snapshot()
	if not collected.get("valid", false):
		_busy = false
		e["error"] = collected.get("error", "Снимок недоступен"); return
	var payload: Dictionary = collected["payload"]
	var sections: Dictionary = payload["sections"]
	var error := _check(sections, actor, portal)
	if not error.is_empty():
		_busy = false
		e["error"] = error; return
	var manifest: Dictionary = WorldTransitionManifest.build_manifest(sections, actor)
	if not manifest.get("valid", false):
		_busy = false
		e["error"] = manifest.get("error", "Не удалось проверить владение"); return
	# Полный валидированный снимок намеренно не выдаётся за переносимый профиль:
	# в нём есть и временные эффекты, и объекты/существа старого этажа.
	e["checkpoint"] = {"actor":actor, "portal":portal, "snapshot":payload.duplicate(true), "manifest":manifest["manifest"].duplicate(true), "profile_ready":false}
	e["accepted"] = true
	_busy = false

func _check(s: Dictionary, actor: StringName, portal: StringName) -> String:
	var stats: Dictionary = s["run_statistics"]
	var tracking: Dictionary = s["dungeon_tracking"]
	var p: Dictionary = s["dungeon_portal"]
	var boss: Dictionary = s["spawn"]["boss"]
	if stats.is_empty() or stats.get("finished", true) or stats.get("entity", null) != actor or stats.get("floor", 0) != 4 or tracking.get("floor", 0) != 4 or stats.get("root", null) != tracking.get("root", null) or not s["level"].get("active", false): return "Активный забег четвёртого этажа не подготовлен"
	if s["game_mode"].get("controlled", null) != actor or s["actions"].get("controlled", null) != actor or not s["entities"].has(actor) or s["combat"]["dead"].has(actor): return "Нужен живой управляемый персонаж"
	if s["game_mode"].get("mode", "") != "exploration": return "Условия портала в бою не определены"
	if s["actions"]["active"].has(actor) or s["time"].get("active", true): return "Выполняется действие или шаг времени"
	if boss.get("status", "") != "defeated" or boss.get("room", null) != tracking.get("boss_candidate", null): return "Босс не побеждён"
	if p.get("status", "") != "placed" or p.get("object", null) != portal or p.get("room", null) != tracking.get("portal_candidate", null): return "Выбранный портал отсутствует"
	var obj = s["objects"]["objects"].get(portal, null)
	var body = s["space"]["bodies"].get(actor, null)
	var room = s["rooms"]["rooms"].get(p["room"], null)
	if not obj is Dictionary or obj.get("type", "") != "portal_exit" or obj.get("room", null) != p["room"] or not body is Dictionary or not room is Dictionary: return "Портал, тело или комната отсутствуют"
	var a: Vector2i = body["anchor"]
	var n: int = body["size"]
	var tile: Vector2i = obj["tile"]
	var bounds := Rect2i(room["origin_cell"] * 4, room["size_cells"] * 4)
	var adjacent := ((tile.x == a.x - 1 or tile.x == a.x + n) and tile.y >= a.y and tile.y < a.y + n) or ((tile.y == a.y - 1 or tile.y == a.y + n) and tile.x >= a.x and tile.x < a.x + n)
	if not bounds.encloses(Rect2i(a, Vector2i.ONE * n)) or not adjacent: return "Нужно находиться рядом с порталом"
	return ""
