extends Node
## Геометрия в локальных логических клетках; глобальную RNG не расходует.
var _passes := 2
var _pocket_probability := 0.25
func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var data: Dictionary = rules["ruleset"].get("parameters", {}).get("cave_generation", {})
		_passes = clampi(int(data.get("hall_cellular_passes", 2)), 0, 6)
		_pocket_probability = clampf(float(data.get("corridor_pocket_probability", 0.25)), 0.0, 1.0)
	EventBus.subscribe(&"CaveGeometryBuildRequested", _build)

func _build(event: Dictionary) -> void:
	event["accepted"] = false
	var size = event.get("size", null)
	var type := str(event.get("type", ""))
	var origin = event.get("origin", null)
	var seed = event.get("seed", null)
	if not size is Vector2i or size.x < 5 or size.y < 5 or size.x > 128 or size.y > 128 or not origin is Vector2i or not seed is int or type not in ["start", "passage", "deadend", "corridor", "fork", "crossroads"]: return
	var rng := RandomNumberGenerator.new()
	rng.seed = int(seed) ^ int(("%s:%s:%d:%d:%d:%d" % [str(event.get("id", "")), type, origin.x, origin.y, size.x, size.y]).hash())
	var floor: Dictionary = {}
	match type:
		"corridor": floor = _corridor(size, rng)
		"fork": floor = _fork(size, str(event.get("entry_dir", "west")), rng)
		"crossroads": floor = _crossroads(size)
		_: floor = _hall(size, rng)
	var center := Vector2i(int(size.x / 2), int(size.y / 2))
	floor[center] = true
	floor = _connected(center, floor)
	var cells: Array = floor.keys()
	cells.sort_custom(func(a, b): return a.y < b.y or (a.y == b.y and a.x < b.x))
	event["cells"] = cells
	event["accepted"] = true

func _hall(size: Vector2i, rng: RandomNumberGenerator) -> Dictionary:
	var cells := {}
	var cx := (float(size.x) - 1.0) / 2.0
	var cy := (float(size.y) - 1.0) / 2.0
	var rx := maxf(2.0, (float(size.x) - 3.0) / 2.0)
	var ry := maxf(2.0, (float(size.y) - 3.0) / 2.0)
	for x in range(1, size.x - 1):
		for y in range(1, size.y - 1):
			var dist := pow((float(x) - cx) / rx, 2) + pow((float(y) - cy) / ry, 2)
			if dist < 0.55 or (dist < 1.10 and rng.randf() < clampf(1.5 - dist, 0.12, 0.85)):
				cells[Vector2i(x,y)] = true
	for _i in range(_passes):
		var next := {}
		for x in range(1, size.x - 1):
			for y in range(1, size.y - 1):
				var neighbors := 0
				for dx in range(-1, 2):
					for dy in range(-1, 2):
						if cells.has(Vector2i(x + dx, y + dy)): neighbors += 1
				if neighbors >= 5: next[Vector2i(x,y)] = true
		cells = next
	return cells
func _corridor(size: Vector2i, rng: RandomNumberGenerator) -> Dictionary:
	var cells := {}
	var horizontal := size.x > size.y
	var length := size.x if horizontal else size.y
	var width := size.y if horizontal else size.x
	var axis := int(width / 2)
	# При ширине 5 оставляем по логической стене с обеих сторон оси:
	# физические карманы создаются в RoomService и не расширяют ось целиком.
	if width == 5:
		for t in range(1, length - 1):
			cells[Vector2i(t,axis) if horizontal else Vector2i(axis,t)] = true
		return cells
	for t in range(1, length - 1):
		var previous := axis
		if t > 1 and rng.randf() < 0.38:
			axis = clampi(axis + (-1 if rng.randi_range(0, 1) == 0 else 1), 1, width - 2)
		cells[Vector2i(t, previous) if horizontal else Vector2i(previous, t)] = true
		cells[Vector2i(t, axis) if horizontal else Vector2i(axis, t)] = true
		if rng.randf() < _pocket_probability:
			var side := clampi(axis + (-1 if rng.randi_range(0, 1) == 0 else 1), 1, width - 2)
			cells[Vector2i(t, side) if horizontal else Vector2i(side, t)] = true
	return cells
func _crossroads(size: Vector2i) -> Dictionary:
	var cells := {}
	var center := Vector2i(int(size.x / 2), int(size.y / 2))
	for direction in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
		_arm(cells, size, center, direction, 2)
	return cells
func _fork(size: Vector2i, entry_dir: String, rng: RandomNumberGenerator) -> Dictionary:
	var cells := {}
	var center := Vector2i(int(size.x / 2), int(size.y / 2))
	var cx := float(center.x)
	var cy := float(center.y)
	for x in range(1, size.x - 1):
		for y in range(1, size.y - 1):
			var d := pow((x - cx) / 3.2, 2) + pow((y - cy) / 2.8, 2)
			if d <= 1.0 or (d < 1.3 and rng.randf() < 0.2): cells[Vector2i(x,y)] = true
	var dirs := {"north": Vector2i.UP, "east": Vector2i.RIGHT, "south": Vector2i.DOWN, "west": Vector2i.LEFT}
	var exits: Array = []
	for name in ["north", "east", "south", "west"]:
		if name != entry_dir and exits.size() < 2: exits.append(dirs[name])
	for direction in exits: _arm(cells, size, center, direction, 3 + rng.randi_range(0,1))
	if dirs.has(entry_dir): _arm(cells, size, center, dirs[entry_dir], 2)
	return cells
func _arm(cells: Dictionary, size: Vector2i, center: Vector2i, direction: Vector2i, thickness: int) -> void:
	var length := size.x if direction.x != 0 else size.y
	var p := center
	for _t in range(length):
		if p.x < 1 or p.y < 1 or p.x >= size.x - 1 or p.y >= size.y - 1: break
		for offset in range(-int(thickness / 2), thickness - int(thickness / 2)):
			var q := p + (Vector2i(0,offset) if direction.x != 0 else Vector2i(offset,0))
			if q.x >= 1 and q.y >= 1 and q.x < size.x - 1 and q.y < size.y - 1: cells[q] = true
		p += direction
func _connected(start: Vector2i, cells: Dictionary) -> Dictionary:
	var found := {start: true}
	var queue: Array = [start]
	var i := 0
	while i < queue.size():
		var p: Vector2i = queue[i]
		i += 1
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var q: Vector2i = p + d
			if cells.has(q) and not found.has(q):
				found[q] = true
				queue.append(q)
	return found
