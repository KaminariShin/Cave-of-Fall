extends Node
## Очередь существует только в пределах одного шага, после commit HP.
var _pending: Array = []
var _resolving := false
func _ready() -> void:
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
func _collect(e: Dictionary) -> void:
	if _resolving or not _pending.is_empty(): e["errors"].append("Нельзя сохранять до завершения фазового пошатывания")
func authorized() -> bool:
	return _resolving and TimeDriver._post_combat_phase and TimeDriver._settling
func stage(rows: Array) -> void:
	# Вызывается только владельцем уже фиксированного боевого пакета.
	if not SimultaneousDamageApplyService.authorizes_phase_effects() or not _pending.is_empty() or _resolving: return
	_pending = rows.duplicate(true)
func resolve() -> void:
	if not TimeDriver._post_combat_phase or not TimeDriver._settling or _resolving or _pending.is_empty(): return
	_resolving = true
	var outcomes: Array = []
	for row in _pending:
		var outcome := {"target":row["target"],"sources":row["sources"].duplicate(),"triggered":row["triggered"],"applied":false}
		if not row["triggered"]: outcome["reason"] = "below_threshold"
		elif row["lethal"]: outcome["reason"] = "lethal"
		else:
			var q := {"target":row["target"],"damage":row["damage"],"expected_max_hp":row["max_hp"],"accepted":false}
			StaggerApplyService.apply_from_phase(q)
			if q.get("accepted",false): outcome.merge(q["data"],true)
			else: outcome["reason"] = "apply_failed"; outcome["error"] = q.get("error","Не удалось применить")
		outcomes.append(outcome)
	_pending.clear()
	# Держим блокировку вложенного вызова/сохранения до конца уведомления.
	EventBus.publish(&"PhaseStaggerResolved", {"outcomes":outcomes})
	_resolving = false
