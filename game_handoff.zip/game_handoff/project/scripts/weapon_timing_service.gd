extends Node
## Computes attack duration; execution and strike selection are separate systems.
var _k: Variant = null
var _baseline: Variant = null
func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var timing: Dictionary = rules["ruleset"].get("parameters", {}).get("weapon_timing", {})
		_k = timing.get("K_attack", null)
		_baseline = timing.get("stat_baseline", null)
	EventBus.subscribe(&"WeaponAttackTimingRequested", _calculate)

func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))
func _calculate(event: Dictionary) -> void:
	event["accepted"] = false
	var actor = event.get("entity", null)
	var kind := str(event.get("kind", ""))
	var effectiveness = event.get("speed_effectiveness", null)
	if not actor is StringName or actor == &"" or kind not in ["physical", "magical", "combined"] or not _number(effectiveness) or float(effectiveness) <= 0 or not _number(_k) or float(_k) <= 0 or not _number(_baseline):
		event["error"] = "Нужны персонаж, тип удара, положительная эффективность и настройки"
		return
	if event.has("item") == event.has("variant"):
		event["error"] = "Укажите ровно один item или variant"
		return
	var weapon := {"found":false}
	if event.has("item"):
		weapon["item"] = event["item"]
		EventBus.publish(&"WeaponItemResolveRequested", weapon)
	else:
		weapon["variant"] = event["variant"]
		EventBus.publish(&"WeaponVariantResolveRequested", weapon)
	if not weapon["found"]:
		event["error"] = "Оружие или вид не найден"
		return
	var stats: Array = []
	for name in ([&"DEX", &"INT"] if kind == "combined" else ([&"DEX"] if kind == "physical" else [&"INT"])):
		var stat := {"entity":actor, "stat":name, "found":false}
		EventBus.publish(&"StatGetRequested", stat)
		if not stat["found"] or not _number(stat.get("value", null)):
			event["error"] = "Характеристика недоступна"
			return
		stats.append(float(stat["value"]))
	var value: float = (stats[0] + stats[1]) / 2.0 if stats.size() == 2 else stats[0]
	var denom := 1.0 + (value - float(_baseline)) / float(_k)
	var w: Dictionary = weapon["data"]
	var floor_value: float = w["base_attack_time"] * (w["min_percent"] + w["min_time_bonus"])
	if not is_finite(denom) or denom <= 0 or not is_finite(floor_value) or floor_value < 0:
		event["error"] = "Некорректный знаменатель или пол"
		return
	var raw: float = w["base_attack_time"] / float(effectiveness) / denom
	if not is_finite(raw) or raw <= 0: return
	var pipeline := {"entity":actor, "target":"action.duration", "base":raw, "apply_weight":true, "accepted":false}
	EventBus.publish(&"PipelineEvaluateRequested", pipeline)
	if not pipeline["accepted"] or not _number(pipeline.get("value", null)) or float(pipeline["value"]) <= 0:
		event["error"] = "Конвейер длительности недоступен или вернул неположительное значение"
		return
	var unrounded: float = maxf(float(pipeline["value"]), floor_value)
	if not is_finite(unrounded) or unrounded > 10000000.0: return
	var duration := maxf(0.01, ceil(unrounded / 0.01 - 0.000000001) * 0.01)
	event["accepted"] = true
	event["data"] = {"weapon":w, "stat":value, "K_attack":_k, "effectiveness":float(effectiveness), "raw_duration":raw, "modified_duration":pipeline["value"], "floor":floor_value, "unrounded_duration":unrounded, "duration":duration}
