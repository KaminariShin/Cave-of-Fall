extends Node
## Индивидуальные типизированные удары и периодические тики, уже после HP commit.
const LIMIT := 1000000000
const MAX_QUEUED := 10000
var _pending: Array = []
var _resolving := false
func _ready() -> void:
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
func _collect(e: Dictionary) -> void:
	if _resolving or not _pending.is_empty(): e["errors"].append("Нельзя сохранять до разрешения прямого пошатывания")
func authorized() -> bool:
	return _resolving and TimeDriver._settling and TimeDriver._post_combat_phase
func _int_value(v: Variant, minimum: int) -> bool:
	return (v is int or v is float) and is_finite(float(v)) and float(v) >= minimum and float(v) <= LIMIT and floorf(float(v)) == float(v)
func record(target: StringName, source: Variant, damage: Variant, maximum: Variant, lethal: bool) -> Dictionary:
	if not _int_value(damage,0) or not _int_value(maximum,1):
		return _failed(target,"Некорректный итоговый урон или максимум HP")
	var amount := int(damage)
	var max_hp := int(maximum)
	if amount * 4 < max_hp: return {"status":"below_threshold"}
	if lethal or CombatService.is_entity_dead(target): return {"status":"lethal"}
	var row := {"target":target,"source":source,"damage":amount,"max_hp":max_hp}
	if TimeDriver._stepping:
		if _resolving or _pending.size() >= MAX_QUEUED: return _failed(target,"Очередь пошатывания недоступна или переполнена")
		_pending.append(row)
		return {"status":"queued"}
	if TimeDriver._settling: return _failed(target,"Шаг уже завершается")
	var q := {"target":target,"damage":amount,"expected_max_hp":max_hp}
	StaggerApplyService._apply(q)
	_report(row,q)
	return {"status":"resolved","accepted":q.get("accepted",false),"data":q.get("data",{}).duplicate(true),"error":q.get("error","")}
func _failed(target: StringName, message: String) -> Dictionary:
	EventBus.publish(&"DirectDamageStaggerFailed", {"target":target,"error":message})
	return {"status":"failed","error":message}
func _report(row: Dictionary, q: Dictionary) -> void:
	var event := {"target":row["target"],"source":row["source"],"damage":row["damage"],"max_hp":row["max_hp"],"accepted":q.get("accepted",false)}
	if q.get("accepted",false): event["data"] = q.get("data",{}).duplicate(true)
	else: event["error"] = q.get("error","Не удалось применить пошатывание")
	EventBus.publish(&"DirectDamageStaggerResolved",event)
func resolve() -> void:
	if not TimeDriver._settling or not TimeDriver._post_combat_phase or _resolving or _pending.is_empty(): return
	_resolving = true
	# Порядок совпадает с фактическим порядком отдельных попаданий: каждый
	# проходит порог независимо, повтор способен обновить пошатывание.
	for row in _pending:
		var q := {"target":row["target"],"damage":row["damage"],"expected_max_hp":row["max_hp"]}
		StaggerApplyService.apply_from_direct_phase(q)
		_report(row,q)
	_pending.clear()
	_resolving = false
