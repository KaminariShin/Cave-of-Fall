extends Node
## Источники — сохранённые additive/add модификаторы pipeline.
const MAX_SOURCES := 10000
const MAX_ABS_PERCENT := 1000000000.0
func _ready() -> void:
	EventBus.subscribe(&"MagicalProtectionGetRequested",_get_protection)
	EventBus.subscribe(&"PhysicalProtectionSourcesGetRequested",_get_physical_sources)
func _get_protection(e: Dictionary) -> void:
	_calculate(e,"protection.magical",true)
func _get_physical_sources(e: Dictionary) -> void:
	_calculate(e,"protection.physical",false)
func _calculate(e: Dictionary, target: String, cap: bool) -> void:
	e["found"] = false
	e.erase("percent"); e.erase("sources"); e.erase("error")
	var entity = e.get("entity",null)
	if not entity is StringName or entity == &"" or not EntityRegistry.has_entity(entity): e["error"] = "Персонаж недоступен"; return
	var list = ModifierPipeline._modifiers.get(entity,[])
	if not list is Array or list.size() > MAX_SOURCES: e["error"] = "Некорректный список модификаторов"; return
	var units := 0
	var sources: Array = []
	for mod in list:
		if not mod is Dictionary: e["error"] = "Некорректный модификатор"; return
		if str(mod.get("target","")) != target: continue
		var v = mod.get("value",null)
		if not ModifierPipeline._valid(mod) or str(mod.get("stage","")) != "additive" or str(mod.get("op","")) != "add" or not (v is int or v is float) or not is_finite(float(v)) or absf(float(v)) > MAX_ABS_PERCENT:
			e["error"] = "Некорректный источник процентной защиты"; return
		# Согласованный расчёт округляет каждый источник от нуля до 0,01 п.п.
		var n := int(signf(float(v)) * ceil(absf(float(v)) * 100.0 - 0.000000001))
		units += n
		sources.append({"id":mod["id"],"percent":float(n)/100.0})
	if absf(float(units)) > MAX_ABS_PERCENT * 100.0: e["error"] = "Переполнение процентной защиты"; return
	sources.sort_custom(func(a,b): return str(a["id"]) < str(b["id"]))
	e["percent"] = float(mini(units,7500) if cap else units)/100.0
	e["sources"] = sources
	e["found"] = true
