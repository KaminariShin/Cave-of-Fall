extends Node
## Консервативная композиция внутренних шагов, НЕ спуск и не смена карты.
var _busy := false

# Вызывается внутренним кодом, не событием игрока. Владеет своей транзакцией.
func clean_known_floor(actor: StringName) -> Dictionary:
	if _busy or actor == &"": return {"committed":false, "error":"Очистка уже выполняется или не задан персонаж"}
	var work := {"error":"", "steps":{}}
	var transaction: Dictionary = SaveService.run_world_transition_transaction(func(): return clean_known_floor_in_transaction(actor, work))
	transaction["steps"] = work["steps"].duplicate(true)
	if not work["error"].is_empty(): transaction["error"] = work["error"]
	return transaction

# Используется только внутренним кодом, которому принадлежит транзакция.
func clean_known_floor_in_transaction(actor: StringName, work: Dictionary) -> bool:
	if _busy or not SaveService.world_transition_operation_active() or actor == &"": return _fail(work, "Очистка недоступна")
	_busy = true
	var ok := _execute(actor, work)
	_busy = false
	return ok

func _execute(actor: StringName, work: Dictionary) -> bool:
	var initial: Dictionary = SaveService._collect_transition_snapshot()
	if not initial.get("valid", false): return _fail(work, "Не удалось проверить исходное состояние")
	var before: Dictionary = initial["payload"]["sections"]
	var report: Dictionary = WorldTransitionManifest.build_manifest(before, actor)
	if not report.get("valid", false): return _fail(work, str(report.get("error", "Неверный персонаж")))
	var manifest: Dictionary = report["manifest"]
	if manifest["player_body"] == null: return _fail(work, "У персонажа нет тела")
	if not manifest["unassigned_items"].is_empty(): return _fail(work, "Есть предметы без определённого владельца")
	if not manifest["pending_loot"].is_empty() or not manifest["pending_object_interactions"].is_empty(): return _fail(work, "Выполняется подбор или взаимодействие с объектом")
	var classified := {}
	for id in before["objects"]["objects"]:
		if not _claim(classified, id, "object", actor): return _fail(work, "Пересекающаяся классификация сущностей")
	var placed := {}
	for state in before["spawn"]["states"].values():
		for id in state["placed"]: placed[id] = true
	for id in before["spawn"]["created_entities"]:
		if not before["combat"]["dead"].has(id) and not placed.has(id): return _fail(work, "Не размещённое живое существо спавна требует отдельной обработки")
		if not _claim(classified, id, "spawn", actor): return _fail(work, "Пересекающаяся классификация сущностей")
	for id in before["ai"]["tracked"]:
		if not _claim(classified, id, "summon", actor): return _fail(work, "Пересекающаяся классификация сущностей")
	if before.has("game_demo") and before["entities"].has(&"demo_rat"):
		var demo_rat = before["entities"][&"demo_rat"]
		if not demo_rat is Dictionary or demo_rat.get(&"demo_floor_actor",{}).get("type",null) != "tutorial_rat" or demo_rat.get(&"species",{}).get("id",null) != "rat" or not _claim(classified, &"demo_rat", "demo", actor): return _fail(work, "Неверный учебный противник")
	for id in manifest["other_entities"]:
		if not classified.has(id): return _fail(work, "Неизвестная сущность: %s" % str(id))
	var recognized_processes := {}
	for id in before["projectiles"]["active"]: recognized_processes[id] = true
	for id in before["detection"]["noises"]: recognized_processes[id] = true
	for state in before["spawn"]["states"].values():
		if state["pending"] != &"": recognized_processes[state["pending"]] = true
	for process in before["processes"]:
		if recognized_processes.has(process["id"]): continue
		if process["independent"]: return _fail(work, "Независимый процесс требует отдельной обработки: %s" % str(process["id"]))
		if process["entity_id"] != actor and not classified.has(process["entity_id"]): return _fail(work, "Процесс с неопределённым владельцем: %s" % str(process["id"]))
	var calls := [
		["pending_summons", Callable(AIService, "cancel_pending_summons_for_transition")],
		["spawn_queues", Callable(SpawnService, "cancel_queues_for_transition")],
		["projectiles", Callable(ProjectileService, "discard_projectiles_for_transition")],
		["noises", Callable(DetectionService, "discard_noises_for_transition")],
		["ground", Callable(LootService, "discard_ground_for_transition")],
		["objects", Callable(ObjectGenerationService, "discard_objects_for_transition")],
		["summons", Callable(FloorSpawnCleanup, "discard_ai_summons_for_transition")],
		["dead_spawned", Callable(FloorSpawnCleanup, "discard_spawned_corpses_for_transition")],
		["live_spawned", Callable(FloorSpawnCleanup, "discard_spawned_actors_for_transition")],
	]
	if before.has("game_demo"): calls.append(["demo_actor", Callable(FloorSpawnCleanup, "discard_demo_actor_for_transition")])
	for call in calls:
		var result: Dictionary = call[1].call()
		work["steps"][call[0]] = result.duplicate(true)
		if not result.get("accepted", false): return _fail(work, "Шаг %s: %s" % [call[0], result.get("error", "отказ")])
		if not SaveService.world_transition_operation_active(): return _fail(work, "Операция была прервана")
	var final: Dictionary = SaveService._collect_transition_snapshot()
	if not final.get("valid", false): return _fail(work, "Итоговый снимок недоступен")
	var after: Dictionary = final["payload"]["sections"]
	var last: Dictionary = WorldTransitionManifest.build_manifest(after, actor)
	if not last.get("valid", false): return _fail(work, "Итоговый персонаж некорректен")
	var m: Dictionary = last["manifest"]
	if not m["other_entities"].is_empty() or not m["other_bodies"].is_empty() or not m["world_objects"].is_empty() or not m["ground_items"].is_empty() or not m["unassigned_items"].is_empty() or not after["projectiles"]["active"].is_empty() or not after["detection"]["noises"].is_empty(): return _fail(work, "После очистки остались несопоставленные объекты")
	if m["player_items"] != manifest["player_items"] or after["entities"][actor] != before["entities"][actor] or m["player_body"] != manifest["player_body"]: return _fail(work, "Изменились персонаж, тело или владение вещами")
	for id in manifest["player_items"]:
		if after["items"]["instances"].get(id, null) != before["items"]["instances"].get(id, null) or after["belts"]["items"].get(id, null) != before["belts"]["items"].get(id, null): return _fail(work, "Изменились вещи персонажа")
	if after["time"] != before["time"] or after["run_statistics"] != before["run_statistics"] or after["actions"]["active"].get(actor, null) != before["actions"]["active"].get(actor, null) or after["resources"]["timers"].get(actor, null) != before["resources"]["timers"].get(actor, null) or after["periodic_effects"].get(actor, null) != before["periodic_effects"].get(actor, null): return _fail(work, "Изменились время, действие, эффекты или статистика персонажа")
	for pair in [["pipeline", "modifiers"], ["sets", "active"], ["magic_inventory", "active"]]:
		if after[pair[0]][pair[1]].get(actor, null) != before[pair[0]][pair[1]].get(actor, null): return _fail(work, "Изменились модификаторы персонажа")
	for key in ["config", "moves", "paths"]:
		if after["movement"][key].get(actor, null) != before["movement"][key].get(actor, null): return _fail(work, "Изменилось движение персонажа")
	var expected_player_processes := {}
	for process in before["processes"]:
		if process["entity_id"] == actor and not recognized_processes.has(process["id"]): expected_player_processes[process["id"]] = process
	var actual_player_processes := {}
	for process in after["processes"]:
		if process["independent"] or process["entity_id"] != actor: return _fail(work, "После очистки остался неразрешённый процесс")
		actual_player_processes[process["id"]] = process
	if actual_player_processes != expected_player_processes: return _fail(work, "Изменились процессы персонажа")
	return true

func _claim(classified: Dictionary, id: Variant, kind: String, actor: StringName) -> bool:
	if not id is StringName or id == actor or classified.has(id): return false
	classified[id] = kind
	return true

func _fail(work: Dictionary, error: String) -> bool:
	work["error"] = error
	SaveService.fail_world_transition(error)
	return false
