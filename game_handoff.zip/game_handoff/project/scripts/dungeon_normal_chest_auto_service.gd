extends Node
## Сохраняемая очередь для демосцены: бросок при создании связанной комнаты,
## содержимое создаётся после завершения текущего шага времени.
var _enabled := false
var _jobs: Dictionary = {}
var _busy := false

func _ready() -> void:
	set_process(false)
	EventBus.subscribe(&"DungeonNormalChestAutoEnableRequested",_enable)
	EventBus.subscribe(&"DungeonNormalChestAutoStatusRequested",_status)
	EventBus.subscribe(&"DungeonNormalChestAutoRetryRequested",_retry)
	EventBus.subscribe(&"RoomChildGenerated",_child)
	EventBus.subscribe(&"RoomRemoved",_room_removed)
	EventBus.subscribe(&"SpaceMapConfigured",_map_reset)
	EventBus.subscribe(&"TimeStepSettled",_settled)
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
	EventBus.subscribe(&"SnapshotApplyRequested",_apply)
	EventBus.subscribe(&"SnapshotRestored",_restored)
	EventBus.subscribe(&"NormalChestAutoSnapshotValidateRequested",_validate)

func _enable(e: Dictionary) -> void:
	e["accepted"]=false
	if _busy or not e.get("enabled",null) is bool:return
	_enabled=e["enabled"]
	if not _enabled:_jobs.clear()
	set_process(_enabled and not _jobs.is_empty())
	e["accepted"]=true
func _map_reset(_e: Dictionary) -> void:
	_jobs.clear();set_process(false)
func _room_removed(e: Dictionary) -> void:
	_jobs.erase(e.get("room",null))
func _status(e: Dictionary) -> void:
	e["enabled"]=_enabled;e["jobs"]=_jobs.duplicate(true)
func _retry(e: Dictionary) -> void:
	e["accepted"]=false;e["count"]=0
	if _busy or not _enabled:return
	for room in _jobs:
		if _jobs[room]["status"]=="failed":
			_jobs[room]={"status":"pending","error":""}
			e["count"]+=1
	if e["count"]>0:
		e["accepted"]=true;set_process(true)
func _child(e: Dictionary) -> void:
	if not _enabled:return
	var room=e.get("child",null)
	if not room is StringName or room==&"" or _jobs.has(room):return
	if not DungeonNormalChestRollService._eligible(room):return
	var existing: Dictionary={"room":room}
	EventBus.publish(&"DungeonNormalChestRollGetRequested",existing)
	if existing.get("found",false):return
	var roll: Dictionary={"room":room}
	EventBus.publish(&"DungeonNormalChestRollRequested",roll)
	if not roll.get("accepted",false):
		_jobs[room]={"status":"failed","error":str(roll.get("error","Не удалось выбрать сундук"))}
		EventBus.publish(&"DungeonNormalChestAutoFailed",{"room":room,"error":_jobs[room]["error"]})
		return
	if roll.get("selected",false):
		_jobs[room]={"status":"pending","error":""}
		set_process(true)
func _settled(_e: Dictionary) -> void:
	if _enabled:_run_one()
func _process(_delta: float) -> void:
	_run_one()
func _run_one() -> void:
	if not _enabled or _busy or TimeDriver._stepping or RoomService._busy or SaveService._transition_busy:return
	var room: StringName=&""
	for id in _jobs:
		if _jobs[id].get("status","")=="pending":room=id;break
	if room==&"":set_process(false);return
	_busy=true
	var result: Dictionary={"room":room}
	EventBus.publish(&"DungeonNormalChestGenerateRequested",result)
	_busy=false
	if not _enabled or not _jobs.has(room):return
	if result.get("accepted",false):
		_jobs.erase(room)
		EventBus.publish(&"DungeonNormalChestAutoFinished",{"room":room,"status":result.get("status",""),"object":result.get("object",null)})
	else:
		_jobs[room]={"status":"failed","error":str(result.get("error","Ошибка создания сундука"))}
		EventBus.publish(&"DungeonNormalChestAutoFailed",{"room":room,"error":_jobs[room]["error"]})
	set_process(not _jobs.is_empty())
func _collect(e: Dictionary) -> void:
	e["sections"]["normal_chest_auto"]={"enabled":_enabled,"jobs":_jobs.duplicate(true)}
func _apply(e: Dictionary) -> void:
	var data: Dictionary=e["sections"]["normal_chest_auto"]
	_enabled=data["enabled"];_jobs=data["jobs"].duplicate(true)
func _restored(_e: Dictionary) -> void:
	set_process(_enabled and not _jobs.is_empty())
func _validate(e: Dictionary) -> void:
	e["valid"]=false
	var s=e.get("sections",null)
	if not s is Dictionary or not s.get("normal_chest_auto",null) is Dictionary or not s.get("normal_chest_rolls",null) is Dictionary or not s.get("rooms",{}).get("rooms",null) is Dictionary:return
	var data: Dictionary=s["normal_chest_auto"]
	if data.size()!=2 or not data.get("enabled",null) is bool or not data.get("jobs",null) is Dictionary:return
	if not data["enabled"] and not data["jobs"].is_empty():return
	for room in data["jobs"]:
		var job=data["jobs"][room]
		if not room is StringName or not s["rooms"]["rooms"].has(room) or not job is Dictionary or job.size()!=2 or job.get("status","") not in ["pending","failed"] or not job.get("error",null) is String:return
		if job["status"]=="pending" and job["error"]!="":return
		if job["status"]=="failed" and job["error"].is_empty():return
	e["valid"]=true
