extends Node
## Чистая агрегация уже рассчитанных целых попаданий из одного снимка.
## Не читает мир, не выбирает случайную ничью, не наносит урон.
const MAX_HITS := 10000
const MAX_NUMBER := 1000000000
func _ready() -> void:
	EventBus.subscribe(&"SimultaneousDamagePlanRequested", _plan)

func _integer(v: Variant, minimum: int) -> bool:
	return v is int and v >= minimum and v <= MAX_NUMBER

func _plan(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("data")
	e.erase("error")
	var hp = e.get("hp_by_target",null)
	var hits = e.get("hits",null)
	if not hp is Dictionary or hp.size() > MAX_HITS or not hits is Array or hits.size() > MAX_HITS:
		e["error"] = "Нужны словарь HP и ограниченный список попаданий"; return
	for target in hp:
		if not target is StringName or target == &"" or not _integer(hp[target],1):
			e["error"] = "Нужны ID целей и положительные целые HP снимка"; return
	var pairs := {}
	var groups := {}
	for hit in hits:
		if not hit is Dictionary:
			e["error"] = "Некорректное попадание"; return
		var source = hit.get("source",null)
		var target = hit.get("target",null)
		var amount = hit.get("damage",null)
		if not source is StringName or source == &"" or not target is StringName or target == &"" or not hp.has(target) or not _integer(amount,0):
			e["error"] = "Нужны источник, цель и целый итоговый урон"; return
		# По умолчанию ID — атакующий (старый контракт). Разным снарядам
		# одного атакующего нужны отдельные ID, но убийцей остаётся источник.
		var hit_id = hit.get("hit_id",source)
		if not hit_id is StringName or hit_id == &"": e["error"] = "Некорректный ID попадания"; return
		if not pairs.has(target): pairs[target] = {}
		if pairs[target].has(hit_id): e["error"] = "Повторный ID попадания по цели"; return
		pairs[target][hit_id] = true
		if not groups.has(target): groups[target] = []
		groups[target].append({"source":source,"damage":amount})
	var targets: Array = groups.keys()
	targets.sort_custom(func(a,b): return str(a) < str(b))
	var result: Array = []
	for target in targets:
		var total := 0
		var max_damage := -1
		var candidates: Array = []
		for hit in groups[target]:
			var damage: int = hit["damage"]
			total += damage
			if damage > max_damage:
				max_damage = damage
				candidates = [hit["source"]]
			elif damage == max_damage and not candidates.has(hit["source"]): candidates.append(hit["source"])
		var before: int = hp[target]
		var lethal := total >= before
		if not lethal: candidates.clear()
		candidates.sort_custom(func(a,b): return str(a) < str(b))
		result.append({"target":target,"hp_before":before,"total_damage":total,"hp_after":maxi(0,before-total),"hp_lost":mini(before,total),"lethal":lethal,"killer_candidates":candidates})
	e["data"] = {"targets":result,"requires_tiebreak":result.any(func(row): return row["killer_candidates"].size() > 1)}
	e["accepted"] = true
