extends Node
## Выбор только редкости; предметы и шаблоны здесь не создаются.
const ORDER := [&"normal", &"magic", &"rare", &"unique", &"artifact"]
var _weights: Dictionary = {}
var _busy := false

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules.get("found", false):
		var weights = rules["ruleset"].get("parameters", {}).get("rarity_roll_weights", {})
		if weights is Dictionary:
			for id in ORDER:
				var value = weights.get(str(id), null)
				if (value is int or value is float) and is_finite(float(value)) and value > 0 and value <= 1000000 and floorf(float(value)) == float(value): _weights[id] = int(value)
	EventBus.subscribe(&"ItemRarityRollRequested", _roll)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_guard)

func _roll(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["rarity", "excluded", "draws", "error"]: e.erase(key)
	var unique_available = e.get("unique_available", null)
	var artifact_available = e.get("artifact_available", null)
	if _busy or not unique_available is bool or not artifact_available is bool or _weights.size() != ORDER.size():
		e["error"] = "Нужны явные признаки доступности шаблона и артефакта"; return
	var total := 0
	for id in ORDER: total += _weights[id]
	if total <= 0 or total > 1000000:
		e["error"] = "Некорректная таблица весов"; return
	_busy = true
	var weights := _weights.duplicate()
	var excluded: Array = []
	var draws := 0
	while draws < 3:
		var limit := 0
		for id in ORDER: limit += weights.get(id, 0)
		var rng := {"min":0, "max":limit - 1, "accepted":false}
		EventBus.publish(&"RngIntRequested", rng)
		draws += 1
		var value = rng.get("value", null)
		if not rng.get("accepted", false) or not value is int or value < 0 or value >= limit:
			_busy = false
			e["error"] = "ГСЧ не вернул допустимое значение; его состояние могло измениться"
			e["draws"] = draws
			return
		var selected: StringName = &""
		var boundary := 0
		for id in ORDER:
			boundary += weights.get(id, 0)
			if value < boundary:
				selected = id
				break
		var available: bool = not ((selected == &"unique" and not unique_available) or (selected == &"artifact" and not artifact_available))
		if available:
			_busy = false
			e["accepted"] = true
			e["rarity"] = selected
			e["excluded"] = excluded
			e["draws"] = draws
			return
		weights[selected] = 0
		excluded.append(selected)
	_busy = false
	e["error"] = "Не удалось выбрать редкость"
	e["draws"] = draws

func _snapshot_guard(e: Dictionary) -> void:
	if _busy: e["errors"].append("Нельзя сохранять во время выбора редкости")
