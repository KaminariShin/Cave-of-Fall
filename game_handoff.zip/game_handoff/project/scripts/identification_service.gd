extends Node
## Требование вычисляется при создании и хранится в экземпляре предмета.
var _rarity_multiplier := 5.0
var _level_divisor := 10.0

func _ready() -> void:
	var request := {"found": false}
	EventBus.publish(&"RulesetGetRequested", request)
	if request["found"]:
		var params: Dictionary = request["ruleset"].get("parameters", {}).get("identification", {})
		_rarity_multiplier = float(params.get("rarity_multiplier", 5.0))
		_level_divisor = float(params.get("level_divisor", 10.0))
	EventBus.subscribe(&"ItemIdentificationRequirementCalculateRequested", _calculate_on_creation)
	EventBus.subscribe(&"IdentificationRequirementGetRequested", _get_requirement)
	EventBus.subscribe(&"IdentificationCheckRequested", _check)
	EventBus.subscribe(&"IdentificationUseCheckRequested", _check_use)

func _calculate_on_creation(event: Dictionary) -> void:
	event["accepted"] = false
	var rank = event.get("rank", null)
	var level = event.get("item_level", null)
	if not _nonnegative(rank) or not _nonnegative(level) or not is_finite(_rarity_multiplier) or _rarity_multiplier < 0.0 or not is_finite(_level_divisor) or _level_divisor <= 0.0:
		return
	var value := float(rank) * _rarity_multiplier + float(level) / _level_divisor
	if not is_finite(value):
		return
	event["value"] = ceil(value)
	event["accepted"] = true

func _get_requirement(event: Dictionary) -> void:
	var item := _read_item(event.get("item", &""))
	event["found"] = not item.is_empty() and _nonnegative(item.get("int_req", null))
	if event["found"]:
		event["value"] = item["int_req"]

## Проверка по текущему эффективному INT; постоянного флага знания пока нет.
func _check(event: Dictionary) -> void:
	event["found"] = false
	var item := _read_item(event.get("item", &""))
	if item.is_empty() or not _nonnegative(item.get("int_req", null)):
		return
	var query := {"entity": event.get("entity", &""), "stat": &"INT", "found": false}
	EventBus.publish(&"StatGetRequested", query)
	if not query["found"]:
		return
	event["found"] = true
	event["requirement"] = item["int_req"]
	event["effective_int"] = query["value"]
	if item.has("learning_state"):
		var known: bool = item["learning_state"]["identified"]
		var mode := {}
		EventBus.publish(&"GameModeGetRequested", mode)
		var controlled = mode.get("entity", &"")
		var npc: bool = controlled is StringName and controlled != &"" and event.get("entity", &"") != controlled
		event["globally_identified"] = known
		event["identified"] = known or npc
	else:
		# Старый низкоуровневый контракт для предметов без схемы изучения.
		event["identified"] = float(query["value"]) >= float(item["int_req"])

## Каркас: неопознанность сама по себе не запрещает экипировку.
## Реальные экипировка, дебафф и изучение — будущие механики.
func _check_use(event: Dictionary) -> void:
	var query := {"entity": event.get("entity", &""), "item": event.get("item", &"")}
	_check(query)
	event["found"] = query["found"]
	if not event["found"]:
		return
	event["identified"] = query["identified"]
	event["identification_blocks_equip"] = false
	event["unidentified_use"] = not query["identified"]

func _read_item(item_id: StringName) -> Dictionary:
	var request := {"item": item_id, "found": false}
	EventBus.publish(&"ItemGetRequested", request)
	return request.get("item_data", {}) if request["found"] else {}

func _nonnegative(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0
