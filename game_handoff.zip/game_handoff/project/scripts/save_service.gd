extends Node
## Отдельные слоты забега и мета-прогрессии. Файлы только в user://.
const SESSION_PATH := "user://session.save"
const DEMO_SESSION_PATH := "user://demo_session.save"
const META_PATH := "user://meta.save"
const FORMAT_VERSION := 61
const MAX_FILE_BYTES := 16 * 1024 * 1024
var _controlled: StringName = &""
var _session_ended := false
# Синхронная внутренняя операция; никаких отложенных Callable или файловых эффектов.
var _transition_busy := false
var _transition_operation_active := false
var _transition_failure := ""
var _demo_fresh_baseline: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"SessionSaveRequested", _save_session)
	EventBus.subscribe(&"SessionLoadRequested", _load_session)
	EventBus.subscribe(&"MetaSaveRequested", _save_meta)
	EventBus.subscribe(&"MetaLoadRequested", _load_meta)
	EventBus.subscribe(&"ControlledEntityRequested", _control_changed)
	EventBus.subscribe(&"EntityDied", _entity_died)

func _control_changed(event: Dictionary) -> void:
	if event.get("accepted", false):
		_controlled = event.get("entity", &"")

func _entity_died(event: Dictionary) -> void:
	if _controlled != &"" and event.get("entity", &"") == _controlled:
		_session_ended = true
		var deletion := {"entity": _controlled, "allowed": true}
		EventBus.publish(&"SessionDeleteOnDeathCheckRequested", deletion)
		if deletion.get("allowed", true) and FileAccess.file_exists(SESSION_PATH):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(SESSION_PATH))

# Внутренний строительный блок будущего перехода. Он восстанавливает только
# сериализуемое состояние зарегистрированных сервисов: уже опубликованные
# события и внешние эффекты НЕ откатываются. Вызывающий код обязан быть
# синхронным, не изменять файлы и сам учитывать эти ограничения.
# Никакое событие шины не предоставляет этот метод игроку.
func run_world_transition_transaction(operation: Callable) -> Dictionary:
	if _transition_busy or _session_ended or not operation.is_valid() or operation.get_argument_count() != 0:
		return {"committed":false, "rolled_back":false, "error":"Операция недоступна"}
	_transition_busy = true
	var before := _collect_transition_snapshot()
	if not before.get("valid", false):
		_transition_busy = false
		return {"committed":false, "rolled_back":false, "error":str(before.get("error", "Не удалось собрать снимок"))}
	if _session_ended:
		_transition_busy = false
		return {"committed":false, "rolled_back":false, "fatal":true, "error":"Персонаж погиб во время подготовки операции"}
	_transition_failure = ""
	_transition_operation_active = true
	var result: Variant = operation.call()
	_transition_operation_active = false
	# Смерть окончательна: никогда не восстанавливаем состояние до смерти.
	if _session_ended:
		_transition_busy = false
		return {"committed":false, "rolled_back":false, "fatal":true, "error":"Персонаж погиб во время операции"}
	var after := _collect_transition_snapshot() if result is bool and result and _transition_failure.is_empty() else {"valid":false, "error":_transition_failure if not _transition_failure.is_empty() else "Операция не завершилась успешно"}
	if _session_ended:
		_transition_busy = false
		return {"committed":false, "rolled_back":false, "fatal":true, "error":"Персонаж погиб во время проверки операции"}
	if after.get("valid", false):
		_transition_busy = false
		return {"committed":true, "rolled_back":false}
	# Текущее состояние может быть неполным — например, после неудачного
	# создания комнаты. Проверять его пригодность к сохранению перед откатом
	# нельзя; исходный снимок уже валидирован и хранится только здесь.
	EventBus.publish(&"SnapshotApplyRequested", {"sections":before["payload"]["sections"].duplicate(true)})
	_controlled = before["payload"]["sections"]["actions"]["controlled"]
	EventBus.publish(&"SnapshotRestored", {})
	_transition_busy = false
	if _session_ended:
		return {"committed":false, "rolled_back":false, "fatal":true, "error":"Персонаж погиб во время уведомления о восстановлении"}
	return {"committed":false, "rolled_back":true, "error":str(after.get("error", "Некорректное состояние после операции"))}

# Только демосцена: исходное состояние создаётся из уже валидированного
# стартового мира, а не принимается от пользователя или из старого сохранения.
func capture_demo_fresh_baseline() -> Dictionary:
	if _transition_busy or _session_ended or not _demo_fresh_baseline.is_empty():
		return {"accepted":false, "error":"Начальное состояние недоступно"}
	_transition_busy = true
	var result := _collect_transition_snapshot()
	_transition_busy = false
	if not result.get("valid",false): return {"accepted":false,"error":result.get("error","Некорректное начало")}
	var sections: Dictionary = result["payload"]["sections"]
	var run: Dictionary = sections.get("run_statistics",{})
	if not sections.has("game_demo") or run.get("entity",null) != &"demo_hero" or run.get("floor",0) != 1 or run.get("finished",true) or sections.get("actions",{}).get("controlled",null) != &"demo_hero":
		return {"accepted":false,"error":"Это не старт демосцены"}
	_demo_fresh_baseline = result["payload"].duplicate(true)
	return {"accepted":true}

func clear_demo_fresh_baseline() -> void:
	if not _transition_busy: _demo_fresh_baseline.clear()

# Новый обычный забег — только после окончания текущего. Старый демо-слот
# удаляется до изменения мира; обычный и мета-слоты не затрагиваются.
func restart_demo_fresh() -> Dictionary:
	if _transition_busy or _demo_fresh_baseline.is_empty(): return {"accepted":false,"error":"Начальное состояние недоступно"}
	var run := {"found":false}
	EventBus.publish(&"RunStatisticsGetRequested", run)
	if not run.get("found",false) or run["data"].get("entity",null) != &"demo_hero" or not run["data"].get("finished",false) or run["data"].get("outcome","") not in ["death","victory"]:
		return {"accepted":false,"error":"Текущий забег ещё не завершён"}
	_transition_busy = true
	if not _validate_snapshot(_demo_fresh_baseline):
		_transition_busy = false
		return {"accepted":false,"error":"Начальное состояние повреждено"}
	if FileAccess.file_exists(DEMO_SESSION_PATH):
		var error := DirAccess.remove_absolute(ProjectSettings.globalize_path(DEMO_SESSION_PATH))
		if error != OK:
			_transition_busy = false
			return {"accepted":false,"error":"Не удалось удалить старое демо-сохранение"}
	var sections: Dictionary = _demo_fresh_baseline["sections"].duplicate(true)
	_session_ended = false
	EventBus.publish(&"SnapshotApplyRequested", {"sections":sections})
	_controlled = sections["actions"]["controlled"]
	EventBus.publish(&"SnapshotRestored", {})
	_transition_busy = false
	return {"accepted":true}

# Только для внутренних шагов внутри синхронной операции перехода.
func world_transition_operation_active() -> bool:
	return _transition_busy and _transition_operation_active and not _session_ended

# Принудительный откат после частично выполненного внутреннего шага,
# даже если вызывающий код по ошибке возвратил true.
func fail_world_transition(reason: String) -> void:
	if world_transition_operation_active() and _transition_failure.is_empty():
		_transition_failure = reason if not reason.is_empty() else "Ошибка операции с миром"

# Доступ к снимку для внутренней инвентаризации; записи и вложенные операции
# на время синхронного сбора заблокированы. Не применяет снимок.
func collect_world_transition_snapshot() -> Dictionary:
	if _transition_busy or _session_ended:
		return {"valid":false, "error":"Сбор снимка сейчас недоступен"}
	_transition_busy = true
	var result := _collect_transition_snapshot()
	_transition_busy = false
	if _session_ended: return {"valid":false, "error":"Персонаж погиб во время сбора снимка"}
	return result

func _collect_transition_snapshot() -> Dictionary:
	var snapshot := {"sections":{}, "errors":[]}
	EventBus.publish(&"SnapshotCollectRequested", snapshot)
	if not snapshot["errors"].is_empty(): return {"valid":false, "error":str(snapshot["errors"])}
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if not rules.get("found", false): return {"valid":false, "error":"Ruleset недоступен"}
	var payload := {"format":FORMAT_VERSION, "ruleset_version":rules["ruleset"].get("version", null), "sections":snapshot["sections"]}
	if not _is_safe_data(payload, 0) or not _validate_snapshot(payload): return {"valid":false, "error":"Неполный или некорректный снимок реестров"}
	return {"valid":true, "payload":payload.duplicate(true)}

func _slot_path(event: Dictionary) -> String:
	var slot = event.get("slot", "session")
	if slot == "session": return SESSION_PATH
	if slot == "demo": return DEMO_SESSION_PATH
	return ""

func _save_session(event: Dictionary) -> void:
	var path := _slot_path(event)
	if path.is_empty(): _fail(event, "Неизвестный слот"); return
	if _transition_busy:
		_fail(event, "Сохранение заблокировано во время операции с миром")
		return
	if _session_ended:
		_fail(event, "Забег завершён смертью управляемой сущности")
		return
	var snapshot := {"sections": {}, "errors": []}
	EventBus.publish(&"SnapshotCollectRequested", snapshot)
	if not snapshot["errors"].is_empty():
		_fail(event, str(snapshot["errors"]))
		return
	if snapshot["sections"].has("game_demo") != (path == DEMO_SESSION_PATH):
		_fail(event, "Тип слота не соответствует сценарию")
		return
	var rule_request := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rule_request)
	if not rule_request["found"]:
		_fail(event, "Ruleset недоступен")
		return
	var payload := {"format": FORMAT_VERSION, "ruleset_version": rule_request["ruleset"]["version"], "sections": snapshot["sections"]}
	if not _validate_snapshot(payload):
		_fail(event, "Неполный или некорректный снимок реестров")
		return
	_write(event, path, payload)

func _load_session(event: Dictionary) -> void:
	var path := _slot_path(event)
	if path.is_empty(): _fail(event, "Неизвестный слот"); return
	if _transition_busy:
		_fail(event, "Загрузка заблокирована во время операции с миром")
		return
	if _session_ended:
		_fail(event, "Забег завершён смертью управляемой сущности")
		return
	var check := {"sections": {}, "errors": []}
	EventBus.publish(&"SnapshotCollectRequested", check)
	if not check["errors"].is_empty():
		_fail(event, "Сейчас нельзя применить сохранение: %s" % str(check["errors"]))
		return
	var payload = _read(path)
	if not payload is Dictionary or not _validate_snapshot(payload):
		_fail(event, "Нет сохранения или повреждён формат")
		return
	if payload["sections"].has("game_demo") != (path == DEMO_SESSION_PATH):
		_fail(event, "Тип слота не соответствует сценарию")
		return
	var rule_request := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rule_request)
	# Демо 0.192 совместимо: старые блоки сохраняли кардинальный Vector2i,
	# который новая геометрия принимает без изменения.
	var legacy_demo: bool = payload["sections"].has("game_demo") and payload["ruleset_version"] == "0.192.0" and rule_request.get("ruleset",{}).get("version","") == "0.193.0"
	if not rule_request["found"] or (payload["ruleset_version"] != rule_request["ruleset"]["version"] and not legacy_demo):
		_fail(event, "Версия ruleset не совпадает с сохранением")
		return
	if payload["sections"].has("loot"):
		var loot = payload["sections"]["loot"]
		var module := {"present": false}
		EventBus.publish(&"LootModulePresentRequested", module)
		if not module["present"] and (not loot["ground"].is_empty() or not loot["pending"].is_empty()):
			_fail(event, "Сохранение содержит лут: для загрузки требуется LootService")
			return
	if payload["sections"].has("game_demo"):
		DemoMeleeSetupService.fix_loaded_demo_enemy_reach(payload["sections"])
	EventBus.publish(&"SnapshotApplyRequested", {"sections": payload["sections"]})
	EventBus.publish(&"SnapshotRestored", {})
	_controlled = payload["sections"]["actions"]["controlled"]
	event["accepted"] = true

func _save_meta(event: Dictionary) -> void:
	if _transition_busy:
		_fail(event, "Запись мета-сохранения заблокирована во время операции с миром")
		return
	var data = event.get("data", {})
	if not data is Dictionary:
		_fail(event, "Мета-прогрессия должна быть словарём")
		return
	_write(event, META_PATH, {"format": FORMAT_VERSION, "data": data})

func _load_meta(event: Dictionary) -> void:
	if _transition_busy:
		_fail(event, "Загрузка мета-сохранения заблокирована во время операции с миром")
		return
	var payload = _read(META_PATH)
	if not payload is Dictionary or payload.get("format", -1) != FORMAT_VERSION or not payload.get("data", null) is Dictionary:
		_fail(event, "Нет сохранения мета-прогрессии или повреждён формат")
		return
	event["data"] = payload["data"]
	event["accepted"] = true

func _write(event: Dictionary, path: String, payload: Dictionary) -> void:
	if not _is_safe_data(payload, 0):
		_fail(event, "Сохранение содержит объект, Callable или другие неподдерживаемые данные")
		return
	var bytes := var_to_bytes(payload)
	if bytes.size() > MAX_FILE_BYTES:
		_fail(event, "Сохранение слишком велико")
		return
	var temp := path + ".tmp"
	var file := FileAccess.open(temp, FileAccess.WRITE)
	if file == null:
		_fail(event, "Не удалось открыть временный файл")
		return
	file.store_buffer(bytes)
	var err := file.get_error()
	file.close()
	if err != OK:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(temp))
		_fail(event, "Ошибка записи")
		return
	var rename_error := DirAccess.rename_absolute(ProjectSettings.globalize_path(temp), ProjectSettings.globalize_path(path))
	if rename_error != OK:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(temp))
		_fail(event, "Не удалось заменить файл сохранения")
		return
	event["accepted"] = true

func _read(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		return null
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > MAX_FILE_BYTES:
		return null
	var data = bytes_to_var(file.get_buffer(file.get_length()))
	return data if _is_safe_data(data, 0) else null

## Не разрешаем объекты и их десериализацию. Ограничение глубины защищает от циклов.
func _is_safe_data(value: Variant, depth: int) -> bool:
	if depth > 64:
		return false
	match typeof(value):
		TYPE_NIL, TYPE_BOOL, TYPE_INT, TYPE_FLOAT, TYPE_STRING, TYPE_STRING_NAME, TYPE_VECTOR2, TYPE_VECTOR2I, TYPE_VECTOR3, TYPE_VECTOR3I, TYPE_COLOR:
			return true
		TYPE_ARRAY:
			for item in value:
				if not _is_safe_data(item, depth + 1):
					return false
			return true
		TYPE_DICTIONARY:
			for key in value:
				if not _is_safe_data(key, depth + 1) or not _is_safe_data(value[key], depth + 1):
					return false
			return true
		_:
			return false

func _validate_snapshot(payload: Dictionary) -> bool:
	if payload.get("format", -1) != FORMAT_VERSION or not payload.get("ruleset_version", null) is String:
		return false
	var sections = payload.get("sections", null)
	if not sections is Dictionary:
		return false
	for name in ["time", "actions", "entities", "rng", "world_hook", "resources", "items", "mods", "sets", "magic_inventory", "belts", "space", "rooms", "fog", "pipeline", "movement", "combat", "projectiles", "rats", "ai", "detection", "game_mode", "level", "spawn", "objects", "menus", "weapons", "weapon_strikes"]:
		if not sections.get(name, null) is Dictionary:
			return false
	if not sections.get("processes", null) is Array:
		return false
	var demo_check := {"sections":sections, "valid":not sections.has("game_demo")}
	EventBus.publish(&"GameDemoSnapshotValidateRequested", demo_check)
	if not demo_check.get("valid",false): return false
	var t: Dictionary = sections["time"]
	var a: Dictionary = sections["actions"]
	var rng: Dictionary = sections["rng"]
	for key in ["total_steps", "action_steps", "elapsed_steps", "turn_steps"]:
		if not t.get(key, null) is int or t[key] < 0:
			return false
	if not t.get("active", null) is bool or not t.get("action_id", null) is StringName or not (t.get("real_accumulator", null) is float or t.get("real_accumulator", null) is int):
		return false
	if not a.get("definitions", null) is Dictionary or not a.get("active", null) is Dictionary or not a.get("order", null) is Array or not a.get("controlled", null) is StringName or not a.get("driver_active", null) is bool or not a.has("game_time"):
		return false
	for definition in a["definitions"].values():
		if not definition is Dictionary or (definition.has("phase_completion") and not definition["phase_completion"] is bool): return false
		var trigger = definition.get("phase_trigger","completion")
		if not trigger is String or trigger not in ["completion","midpoint"] or (trigger == "midpoint" and definition.get("phase_completion",false) != true): return false
	if not sections["detection"].get("seen", null) is Dictionary or not sections["detection"].get("hostile", null) is Dictionary or not sections["detection"].get("noises", null) is Dictionary or not sections["detection"].get("forced", null) is Dictionary or not sections["detection"].get("radii", null) is Dictionary or not sections["detection"].get("controlled", null) is StringName or not sections["detection"].get("step", null) is int or not sections["detection"].get("sequence", null) is int:
		return false
	if not sections["ai"].get("agents", null) is Dictionary or not sections["ai"].get("summons", null) is Dictionary or not sections["ai"].get("tracked", null) is Dictionary or not sections["ai"].get("pending", null) is Dictionary or not sections["ai"].get("room", null) is StringName or not sections["ai"].get("controlled", null) is StringName or not sections["ai"].get("sequence", null) is int:
		return false
	if not sections["rats"].get("bites", null) is Dictionary:
		return false
	if not sections["projectiles"].get("active", null) is Dictionary or not sections["projectiles"].get("sequence", null) is int:
		return false
	if not sections["combat"].get("dead", null) is Dictionary or not sections["combat"].get("watches", null) is Dictionary:
		return false
	if not sections["pipeline"].get("modifiers", null) is Dictionary or not sections["movement"].get("config", null) is Dictionary or not sections["movement"].get("moves", null) is Dictionary:
		return false
	var movement_check := {"sections":sections, "valid":false}
	EventBus.publish(&"MovementSnapshotValidateRequested", movement_check)
	if not movement_check["valid"]: return false
	if not sections["fog"].get("radii", null) is Dictionary or not sections["fog"].get("controlled", null) is StringName:
		return false
	if not sections["level"].get("active", null) is bool or not sections["level"].get("level_id", null) is StringName or not sections["level"].get("seed", null) is int or not sections["level"].get("size_cells", null) is Vector2i:
		return false
	if not sections["rooms"].get("cave_enabled", null) is bool or not sections["rooms"].get("cave_seed", null) is int:
		return false
	if not sections["rooms"].get("rooms", null) is Dictionary or not sections["rooms"].get("pending", null) is Dictionary:
		return false
	if not sections["spawn"].get("rooms", null) is Dictionary or not sections["spawn"].get("sequence", null) is int or sections["spawn"]["sequence"] < 0: return false
	for spawned_room in sections["spawn"]["rooms"]:
		if not spawned_room is StringName or not sections["rooms"]["rooms"].has(spawned_room) or not sections["spawn"]["rooms"][spawned_room] is bool or not sections["spawn"]["rooms"][spawned_room]: return false
	var room_state: Dictionary = sections["rooms"]
	if not room_state.get("controlled", null) is StringName or not room_state.get("current_room", null) is StringName or not room_state.get("deadend_budget", null) is int or room_state["deadend_budget"] < 0 or not room_state.get("sequence", null) is int or room_state["sequence"] < 0:
		return false
	if not sections["space"].get("size", null) is Vector2i or not sections["space"].get("floor", null) is Dictionary or not sections["space"].get("passages", null) is Dictionary or not sections["space"].get("bodies", null) is Dictionary or not sections["space"].get("obstacles", null) is Dictionary:
		return false
	if not sections["belts"].get("types", null) is Dictionary or not sections["belts"].get("module_types", null) is Dictionary or not sections["belts"].get("items", null) is Dictionary:
		return false
	if not sections["magic_inventory"].get("active", null) is Dictionary:
		return false
	if not sections["sets"].get("definitions", null) is Dictionary or not sections["sets"].get("active", null) is Dictionary:
		return false
	if not sections["mods"].get("definitions", null) is Dictionary:
		return false
	if not sections["items"].get("materials", null) is Dictionary or not sections["items"].get("bases", null) is Dictionary or not sections["items"].get("instances", null) is Dictionary:
		return false
	for item in sections["items"]["instances"].values():
		if item is Dictionary and item.has("learning"):
			var base = item.get("base_id", null)
			if not base is StringName: return false
			var learning: Dictionary = DungeonChestLearningService.schema_for(base, sections["items"]["bases"])
			if learning.is_empty() or item["learning"] != learning: return false
			var state = item.get("learning_state", null)
			if not state is Dictionary or state.size() != 2 or not state.get("progress", null) is int or state["progress"] < 0 or state["progress"] > learning["full_progress"] or not state.get("identified", null) is bool or (state["progress"] == learning["full_progress"] and not state["identified"]): return false
		elif item is Dictionary and item.has("learning_state"): return false
	if not sections["items"].get("retired", null) is Dictionary: return false
	for id in sections["items"]["retired"]:
		if not id is StringName or id == &"" or sections["items"]["retired"][id] != true or sections["items"]["instances"].has(id): return false
	var learning_progress_check := {"sections":sections, "valid":false}
	EventBus.publish(&"ItemLearningProgressSnapshotValidateRequested", learning_progress_check)
	if not learning_progress_check["valid"]: return false
	var identify_check := {"sections":sections, "valid":false}
	EventBus.publish(&"ItemIdentificationActionSnapshotValidateRequested", identify_check)
	if not identify_check["valid"]: return false
	var block_check := {"sections":sections, "valid":false}
	EventBus.publish(&"ShieldBlockSnapshotValidateRequested", block_check)
	if not block_check["valid"]: return false
	var strike_action_check := {"sections":sections, "valid":false}
	EventBus.publish(&"WeaponStrikeActionSnapshotValidateRequested", strike_action_check)
	if not strike_action_check["valid"]: return false
	var bow_check := {"sections":sections, "valid":false}
	EventBus.publish(&"BowShotSnapshotValidateRequested", bow_check)
	if not bow_check["valid"]: return false
	var hand_check := {"sections":sections, "valid":false}
	EventBus.publish(&"ShieldHandSnapshotValidateRequested", hand_check)
	if not hand_check["valid"]: return false
	var consumable_check := {"sections":sections, "valid":false}
	EventBus.publish(&"ConsumableSnapshotValidateRequested", consumable_check)
	if not consumable_check["valid"]: return false
	var chest_transfer_check := {"sections":sections, "valid":false}
	EventBus.publish(&"ChestTransferSnapshotValidateRequested", chest_transfer_check)
	if not chest_transfer_check["valid"]: return false
	if not sections["resources"].get("timers", null) is Dictionary:
		return false
	var world: Dictionary = sections["world_hook"]
	if not world.get("room", null) is StringName or not world.get("room_type", null) is StringName or not world.get("active", null) is Dictionary or not world.get("sequence", null) is int or not world.get("enabled", null) is bool:
		return false
	if not rng.get("seed", null) is int or not rng.get("state", null) is int:
		return false
	for id in a["order"]:
		if not id is StringName or not a["active"].has(id):
			return false
	var processes_by_id: Dictionary = {}
	for p in sections["processes"]:
		if not p is Dictionary:
			return false
		if not p.get("id", null) is StringName or not p.get("entity_id", null) is StringName or not p.get("independent", null) is bool or not p.get("duration_steps", null) is int or not p.get("elapsed_steps", null) is int:
			return false
		if processes_by_id.has(p["id"]) or p["duration_steps"] < 1 or p["elapsed_steps"] < 0 or p["elapsed_steps"] >= p["duration_steps"]:
			return false
		processes_by_id[p["id"]] = p
	var descent_check := {"sections":sections, "valid":false}
	EventBus.publish(&"DungeonDescentSnapshotValidateRequested", descent_check)
	if not descent_check["valid"]: return false
	var stair_check := {"sections":sections, "valid":false}
	EventBus.publish(&"DungeonStairSnapshotValidateRequested", stair_check)
	if not stair_check["valid"]: return false
	var portal_check := {"sections":sections, "valid":false}
	EventBus.publish(&"DungeonPortalSnapshotValidateRequested", portal_check)
	if not portal_check["valid"]: return false
	var dungeon_check := {"sections":sections, "valid":false}
	EventBus.publish(&"DungeonTrackingSnapshotValidateRequested", dungeon_check)
	if not dungeon_check["valid"]: return false
	var normal_chest_check := {"sections":sections,"valid":false}
	EventBus.publish(&"NormalChestRollSnapshotValidateRequested",normal_chest_check)
	if not normal_chest_check["valid"]: return false
	var normal_generation_check := {"sections":sections,"valid":false}
	EventBus.publish(&"NormalChestGenerationSnapshotValidateRequested",normal_generation_check)
	if not normal_generation_check["valid"]: return false
	var normal_auto_check := {"sections":sections,"valid":false}
	EventBus.publish(&"NormalChestAutoSnapshotValidateRequested",normal_auto_check)
	if not normal_auto_check["valid"]: return false
	var stats_check := {"sections":sections, "valid":false}
	EventBus.publish(&"RunStatisticsSnapshotValidateRequested", stats_check)
	if not stats_check["valid"]: return false
	var ownership_check := {"sections":sections, "valid":false}
	EventBus.publish(&"ItemOwnershipSnapshotValidateRequested", ownership_check)
	if not ownership_check["valid"]: return false
	var equipment_check := {"sections": sections, "valid": false}
	EventBus.publish(&"EquipmentSnapshotValidateRequested", equipment_check)
	if not equipment_check["valid"]: return false
	var periodic_check := {"sections": sections, "valid": false}
	EventBus.publish(&"PeriodicSnapshotValidateRequested", periodic_check)
	if not periodic_check["valid"]: return false
	var resource_check := {"sections": sections, "valid": false}
	EventBus.publish(&"ResourceSnapshotValidateRequested", resource_check)
	if not resource_check["valid"]: return false
	var strike_check := {"sections": sections, "valid": false}
	EventBus.publish(&"WeaponStrikeSnapshotValidateRequested", strike_check)
	if not strike_check["valid"]: return false
	var weapon_check := {"sections": sections, "valid": false}
	EventBus.publish(&"WeaponSnapshotValidateRequested", weapon_check)
	if not weapon_check["valid"]: return false
	var menu_check := {"sections": sections, "valid": false}
	EventBus.publish(&"MenuSnapshotValidateRequested", menu_check)
	if not menu_check["valid"]: return false
	var object_check := {"sections": sections, "valid": false}
	EventBus.publish(&"ObjectSnapshotValidateRequested", object_check)
	if not object_check["valid"]: return false
	var spawn_check := {"sections": sections, "valid": false}
	EventBus.publish(&"SpawnSnapshotValidateRequested", spawn_check)
	if not spawn_check["valid"]: return false
	if not _valid_detection(sections["detection"], sections, processes_by_id):
		return false
	if not _valid_game_mode(sections["game_mode"], sections):
		return false
	if not _valid_level(sections["level"], sections):
		return false
	if sections.has("loot") and not _valid_loot(sections["loot"], sections):
		return false
	var ai_state: Dictionary = sections["ai"]
	if ai_state["sequence"] < 0:
		return false
	for entity in ai_state["agents"]:
		var agent = ai_state["agents"][entity]
		if not entity is StringName or not agent is Dictionary or not agent.get("room", null) is StringName or not agent.get("target", null) is StringName or agent.get("role", "") not in ["rat", "summoner", "melee"] or not agent.get("detected", null) is bool or not agent.get("dirty", null) is bool or not agent.get("reactive", null) is bool:
			return false
		if not (agent.get("wait_duration", null) is int or agent.get("wait_duration", null) is float) or not is_finite(float(agent["wait_duration"])) or float(agent["wait_duration"]) <= 0.0 or not agent.get("bite", null) is Dictionary or not agent.get("staff_attack", null) is Dictionary:
			return false
		if agent.get("retreat_hp_ratio", null) != null and (not (agent["retreat_hp_ratio"] is int or agent["retreat_hp_ratio"] is float) or not is_finite(float(agent["retreat_hp_ratio"])) or float(agent["retreat_hp_ratio"]) < 0.0 or float(agent["retreat_hp_ratio"]) > 1.0):
			return false
		if agent["role"] == "melee":
			var weapon = agent.get("weapon",null)
			if not weapon is Dictionary or not weapon.get("item",null) is StringName or weapon["item"] == &"" or not (weapon.get("strike",null) is String or weapon.get("strike",null) is StringName) or str(weapon["strike"]).is_empty(): return false
		if agent["role"] == "rat" and not _valid_ai_attack(agent["bite"], false):
			return false
		if agent["role"] == "summoner" and not agent["staff_attack"].is_empty() and not _valid_ai_attack(agent["staff_attack"], true):
			return false
	for owner in ai_state["summons"]:
		if not owner is StringName or not ai_state["summons"][owner] is Array:
			return false
		var unique: Dictionary = {}
		for child in ai_state["summons"][owner]:
			if not child is StringName or unique.has(child):
				return false
			unique[child] = true
	for child in ai_state["tracked"]:
		if not child is StringName or child == &"" or not ai_state["tracked"][child] is StringName or not sections["entities"].get(child, null) is Dictionary or not sections["rooms"]["rooms"].has(ai_state["tracked"][child]):
			return false
		var species = sections["entities"][child].get(&"species", null)
		if not species is Dictionary or species.get("id", "") != "rat": return false
	for actor in ai_state["pending"]:
		var pending = ai_state["pending"][actor]
		if not actor is StringName or not ai_state["agents"].has(actor) or not pending is Dictionary or pending.get("kind", "") not in ["summon", "staff"] or not a["active"].get(actor, null) is Dictionary:
			return false
		if pending["kind"] == "summon":
			if a["active"][actor].get("id", &"") != &"ai_summon" or not pending.get("room", null) is StringName:
				return false
		else:
			if a["active"][actor].get("id", &"") != &"ai_staff_attack" or not pending.get("target", null) is StringName or not pending.get("anchor", null) is Vector2i or not pending.get("direction", null) is Vector2 or not pending.get("config", null) is Dictionary or not pending.get("tiles", null) is Array or not pending.get("announced", false):
				return false
			if not is_finite(pending["direction"].x) or not is_finite(pending["direction"].y) or pending["direction"].length_squared() <= 0.0000001 or not _valid_ai_attack(pending["config"], true):
				return false
			var watched = sections["combat"]["watches"].get(actor, null)
			if not watched is Dictionary or watched.get("target", &"") != pending["target"] or watched.get("action", &"") != &"ai_staff_attack":
				return false
			for tile in pending["tiles"]:
				if not tile is Vector2i:
					return false
	for rat in sections["rats"]["bites"]:
		var bite = sections["rats"]["bites"][rat]
		if not rat is StringName or not bite is Dictionary or not bite.get("target", null) is StringName or not bite.get("anchor", null) is Vector2i or not bite.get("center", null) is Vector2 or not bite.get("direction", null) is Vector2i or not bite.get("tiles", null) is Array or not bite.get("announced", false):
			return false
		if not is_finite(bite["center"].x) or not is_finite(bite["center"].y) or bite["direction"] not in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN] or bite["tiles"].size() != 4:
			return false
		var unique_tiles: Dictionary = {}
		for tile in bite["tiles"]:
			if not tile is Vector2i or unique_tiles.has(tile):
				return false
			unique_tiles[tile] = true
		for key in ["duration", "damage"]:
			if not (bite.get(key, null) is int or bite.get(key, null) is float) or not is_finite(float(bite[key])):
				return false
		if bite["duration"] <= 0.0 or bite["damage"] < 0.0 or not a["active"].get(rat, null) is Dictionary or a["active"][rat].get("id", &"") != &"rat_bite":
			return false
		var watches: Dictionary = sections["combat"]["watches"]
		if not watches.get(rat, null) is Dictionary or watches[rat].get("target", &"") != bite["target"] or watches[rat].get("action", &"") != &"rat_bite":
			return false
	var projectiles: Dictionary = sections["projectiles"]["active"]
	if sections["projectiles"]["sequence"] < 0:
		return false
	for id in projectiles:
		var shot = projectiles[id]
		if not id is StringName or not shot is Dictionary or shot.get("id", null) != id or not processes_by_id.has(id):
			return false
		if not processes_by_id[id]["independent"] or processes_by_id[id]["entity_id"] != shot.get("owner", null):
			return false
		if not shot.get("owner", null) is StringName or not shot.get("impact_target", null) is StringName or shot.get("weapon_type", "") not in ["bow", "fireball"] or not shot.get("last_free_tile", null) is Vector2i:
			return false
		for key in ["origin", "position", "direction", "last_free"]:
			if not shot.get(key, null) is Vector2 or not is_finite(shot[key].x) or not is_finite(shot[key].y):
				return false
		for key in ["speed", "range", "distance", "direct_damage", "blast_damage"]:
			if not (shot.get(key, null) is int or shot.get(key, null) is float) or not is_finite(float(shot[key])):
				return false
		if shot["speed"] <= 0.0 or shot["range"] <= 0.0 or shot["distance"] < 0.0 or shot["distance"] > shot["range"] + 0.0001:
			return false
	return _is_safe_data(payload, 0)

func _valid_level(level: Dictionary, sections: Dictionary) -> bool:
	if not level["active"]:
		return true
	if level["level_id"] == &"" or level["size_cells"].x < 24 or level["size_cells"].y < 24 or level["size_cells"].x > 512 or level["size_cells"].y > 512:
		return false
	var rooms_state: Dictionary = sections["rooms"]
	if not rooms_state["cave_enabled"] or rooms_state["cave_seed"] != level["seed"] or not rooms_state["rooms"].has(&"start"):
		return false
	var scale := 4
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	var guard_width := 9
	var guard_depth := 6
	if rules["found"]:
		var parameters: Dictionary = rules["ruleset"].get("parameters", {})
		scale = int(parameters.get("space", {}).get("tiles_per_cell", 4))
		guard_width = int(parameters.get("cave_generation", {}).get("guard_width", 9))
		guard_depth = int(parameters.get("cave_generation", {}).get("guard_depth", 6))
	if guard_width < 1 or guard_depth < 1: return false
	if scale < 1 or sections["space"]["size"] != level["size_cells"] * scale: return false
	var world_floor: Dictionary = sections["space"]["floor"]
	var all_rooms: Dictionary = rooms_state["rooms"]
	for id in all_rooms:
		var a = all_rooms[id]
		if not id is StringName or not a is Dictionary or a.get("id", null) != id or not a.get("origin_cell", null) is Vector2i or not a.get("size_cells", null) is Vector2i or not a.get("parent", null) is StringName or not a.get("guards", null) is Array: return false
		var rect_a := Rect2i(a["origin_cell"], a["size_cells"])
		if rect_a.position.x < 0 or rect_a.position.y < 0 or rect_a.size.x <= 0 or rect_a.size.y <= 0 or rect_a.end.x > level["size_cells"].x or rect_a.end.y > level["size_cells"].y: return false
		if a["parent"] != &"" and not all_rooms.has(a["parent"]): return false
		if a.get("type", "") == "corridor":
			var o: Vector2i = a["origin_cell"]
			var extent: Vector2i = a["size_cells"]
			var expected: Array = []
			if extent.x > extent.y:
				var y := o.y + floori(float(extent.y - guard_width) / 2.0)
				expected = [{"origin": Vector2i(o.x - guard_depth, y), "size": Vector2i(guard_depth,guard_width)}, {"origin": Vector2i(o.x + extent.x, y), "size": Vector2i(guard_depth,guard_width)}]
			else:
				var x := o.x + floori(float(extent.x - guard_width) / 2.0)
				expected = [{"origin": Vector2i(x, o.y - guard_depth), "size": Vector2i(guard_width,guard_depth)}, {"origin": Vector2i(x, o.y + extent.y), "size": Vector2i(guard_width,guard_depth)}]
			if a["guards"] != expected: return false
		else:
			if not a["guards"].is_empty(): return false
		for other in all_rooms:
			if other == id: continue
			var b = all_rooms[other]
			if not b is Dictionary or not b.get("origin_cell", null) is Vector2i or not b.get("size_cells", null) is Vector2i or not b.get("parent", null) is StringName: return false
			var rect_b := Rect2i(b["origin_cell"], b["size_cells"])
			if rect_a.intersects(rect_b): return false
			if b["parent"] != id and a["parent"] != other:
				for guard in a["guards"]:
					if rect_b.intersects(Rect2i(guard["origin"], guard["size"])): return false
	for id in all_rooms:
		var room = rooms_state["rooms"][id]
		if not room is Dictionary or not room.get("generated_cave", false) or not room.get("origin_cell", null) is Vector2i or not room.get("size_cells", null) is Vector2i or not room.get("floor_list", null) is Array or not room.get("floor_tiles", null) is Array or not room.get("exits", null) is Array or not room.get("guards", null) is Array:
			return false
		var bounds := Rect2i(room["origin_cell"] * scale, room["size_cells"] * scale)
		var tile_set: Dictionary = {}
		var cells: Dictionary = {}
		for tile in room["floor_tiles"]:
			if not tile is Vector2i or not bounds.has_point(tile) or not world_floor.has(tile) or tile_set.has(tile): return false
			tile_set[tile] = true
			cells[Vector2i(floori(float(tile.x) / scale), floori(float(tile.y) / scale))] = true
		if tile_set.is_empty(): return false
		for x in range(bounds.position.x, bounds.end.x):
			for y in range(bounds.position.y, bounds.end.y):
				var tile := Vector2i(x,y)
				if world_floor.has(tile) != tile_set.has(tile): return false
		var logical: Dictionary = {}
		for cell in room["floor_list"]:
			if not cell is Vector2i or logical.has(cell): return false
			logical[cell] = true
		if logical != cells: return false
		var reachable: Dictionary = {room["floor_tiles"][0]: true}
		var queue: Array = [room["floor_tiles"][0]]
		var head := 0
		while head < queue.size():
			var tile: Vector2i = queue[head]
			head += 1
			for delta in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
				var next: Vector2i = tile + delta
				if tile_set.has(next) and not reachable.has(next):
					reachable[next] = true
					queue.append(next)
		if reachable.size() != tile_set.size(): return false
		for exit in room["exits"]:
			if not exit is Dictionary or not exit.get("tiles", null) is Array: return false
			for tile in exit["tiles"]:
				if not tile is Vector2i or not tile_set.has(tile): return false
	return true

func _valid_loot(data: Variant, sections: Dictionary) -> bool:
	if not data is Dictionary or not data.get("enabled", null) is bool or not data.get("ground", null) is Dictionary or not data.get("pending", null) is Dictionary or not data.get("processed", null) is Dictionary:
		return false
	var entities: Dictionary = sections["entities"]
	var instances: Dictionary = sections["items"]["instances"]
	for item in data["ground"]:
		var drop = data["ground"][item]
		if not item is StringName or not instances.has(item) or not drop is Dictionary or not drop.get("tile", null) is Vector2i or not drop.get("source", null) is StringName:
			return false
		if not sections["space"]["floor"].has(drop["tile"]):
			return false
		for entity in entities:
			var state = entities[entity]
			if not state is Dictionary: return false
			var inventory_data = state.get(&"inventory", {})
			if not inventory_data is Dictionary: return false
			var inventory = inventory_data.get("items", [])
			if not inventory is Array or inventory.has(item): return false
			if _equipment_has_item(state.get(&"equipment", {}), item, 0): return false
	if not data["enabled"] and not data["pending"].is_empty(): return false
	var reserved: Dictionary = {}
	for actor in data["pending"]:
		var pending = data["pending"][actor]
		if not actor is StringName or actor != sections["actions"]["controlled"] or not entities.has(actor) or not pending is Dictionary or not pending.get("item", null) is StringName or not data["ground"].has(pending["item"]) or reserved.has(pending["item"]):
			return false
		if not sections["actions"]["active"].get(actor, null) is Dictionary or sections["actions"]["active"][actor].get("id", &"") != &"loot_pickup":
			return false
		reserved[pending["item"]] = true
	var dropping = data.get("drop_pending",{})
	if not dropping is Dictionary or (not data["enabled"] and not dropping.is_empty()): return false
	for actor in dropping:
		var p = dropping[actor]
		if not actor is StringName or actor != sections["actions"]["controlled"] or not entities.has(actor) or not p is Dictionary or p.size() != 2 or not p.get("item",null) is StringName or not instances.has(p["item"]) or not p.get("tile",null) is Vector2i or data["ground"].has(p["item"]) or not entities[actor].get(&"inventory",{}).get("items",[]).has(p["item"]): return false
		var t: Vector2i = p["tile"]
		var map_size: Vector2i = sections["space"]["size"]
		if t.x < 0 or t.y < 0 or t.x >= map_size.x or t.y >= map_size.y or sections["actions"]["active"].get(actor,{}).get("id",null) != &"loot_inventory_drop": return false
	for actor in sections["actions"]["active"]:
		if sections["actions"]["active"][actor].get("id",null) == &"loot_inventory_drop" and not dropping.has(actor): return false
	for actor in data["processed"]:
		if not actor is StringName or not entities.has(actor) or not sections["combat"]["dead"].has(actor) or data["processed"][actor] != true: return false
	return true

func _equipment_has_item(value: Variant, item: StringName, depth: int) -> bool:
	if depth > 32: return true
	if value is String or value is StringName: return StringName(str(value)) == item
	if value is Dictionary:
		if value.has("id"): return _equipment_has_item(value["id"], item, depth + 1)
		for child in value.values():
			if _equipment_has_item(child, item, depth + 1): return true
	elif value is Array:
		for child in value:
			if _equipment_has_item(child, item, depth + 1): return true
	return false

func _valid_game_mode(data: Dictionary, sections: Dictionary) -> bool:
	if not data.get("mode", null) is String or data["mode"] not in ["exploration", "combat"] or not data.get("controlled", null) is StringName or not data.get("room", null) is StringName:
		return false
	if data["controlled"] != sections["actions"]["controlled"] or data["controlled"] != sections["detection"]["controlled"]:
		return false
	var detection: Dictionary = sections["detection"]
	var controlled: StringName = data["controlled"]
	var active := false
	for other in detection["hostile"].get(controlled, {}):
		if detection["seen"].get(controlled, {}).has(other) and detection["seen"].get(other, {}).has(controlled):
			active = true
			break
	return (data["mode"] == "combat") == active

func _valid_detection(data: Dictionary, sections: Dictionary, processes: Dictionary) -> bool:
	if data["step"] < 0 or data["step"] != sections["time"]["total_steps"] or data["sequence"] < 0 or data["controlled"] != sections["actions"]["controlled"]:
		return false
	var entities: Dictionary = sections["entities"]
	var bodies: Dictionary = sections["space"]["bodies"]
	for id in data["radii"]:
		var radius = data["radii"][id]
		if not id is StringName or not entities.has(id) or not (radius is int or radius is float) or not is_finite(float(radius)) or float(radius) < 0.0:
			return false
	for observer in data["seen"]:
		if not observer is StringName or not entities.has(observer) or not bodies.has(observer) or not data["seen"][observer] is Dictionary:
			return false
		for target in data["seen"][observer]:
			if not target is StringName or target == observer or not entities.has(target) or not bodies.has(target) or data["seen"][observer][target] not in ["vision", "noise", "forced"]:
				return false
	for observer in data["hostile"]:
		if not observer is StringName or not entities.has(observer) or not data["hostile"][observer] is Dictionary:
			return false
		for target in data["hostile"][observer]:
			if not target is StringName or target == observer or not entities.has(target) or data["hostile"][observer][target] != true or not data["hostile"].get(target, null) is Dictionary or not data["hostile"][target].get(observer, false):
				return false
	for observer in data["forced"]:
		if not observer is StringName or not entities.has(observer) or not data["forced"][observer] is Dictionary:
			return false
		for target in data["forced"][observer]:
			if not target is StringName or target == observer or not entities.has(target) or not data["forced"][observer][target] is int or data["forced"][observer][target] < data["step"]:
				return false
	for id in data["noises"]:
		var noise = data["noises"][id]
		if not id is StringName or not noise is Dictionary or not processes.has(id) or not noise.get("source", null) is StringName or noise["source"] == &"" or not noise.get("position", null) is Vector2 or not is_finite(noise["position"].x) or not is_finite(noise["position"].y) or noise.get("kind", "") not in ["strike", "shot", "explosion"]:
			return false
		if not (noise.get("radius", null) is int or noise.get("radius", null) is float) or not is_finite(float(noise["radius"])) or float(noise["radius"]) < 0.0 or not processes[id]["independent"] or processes[id]["entity_id"] != noise["source"]:
			return false
	return true

func _valid_ai_attack(data: Dictionary, staff: bool) -> bool:
	for key in ["damage", "duration", "stamina_cost"]:
		if not (data.get(key, null) is int or data.get(key, null) is float) or not is_finite(float(data[key])) or float(data[key]) < 0.0:
			return false
	if float(data["duration"]) < 0.01 or absf(roundf(float(data["duration"]) / 0.01) * 0.01 - float(data["duration"])) > 0.000001:
		return false
	if staff:
		if not data.get("shape", null) is Dictionary:
			return false
		for key in ["range", "gap"]:
			if not (data.get(key, null) is int or data.get(key, null) is float) or not is_finite(float(data[key])) or float(data[key]) < 0.0:
				return false
	return true

func _fail(event: Dictionary, reason: String) -> void:
	event["accepted"] = false
	event["error"] = reason
