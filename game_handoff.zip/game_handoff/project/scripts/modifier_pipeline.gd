extends Node
## Единый вычислитель: база -> add -> multiply -> threshold -> final.
var _modifiers: Dictionary = {} # entity -> [{id,target,stage,op,value,...}]
const STAGES := ["additive", "multiplicative", "threshold", "final"]

func _ready() -> void:
	EventBus.subscribe(&"PipelineEvaluateRequested", _evaluate)
	EventBus.subscribe(&"PipelineModifierRegisterRequested", _register)
	EventBus.subscribe(&"PipelineModifierRemoveRequested", _remove)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)

func _register(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var mod = event.get("modifier", null)
	if entity == &"" or not _valid(mod):
		return
	var exists := {"entity": entity, "found": false}
	EventBus.publish(&"EntityGetRequested", exists)
	if not exists["found"]:
		return
	var list: Array = _modifiers.get(entity, [])
	for existing in list:
		if str(existing["id"]) == str(mod["id"]):
			return
	var before := _stat_snapshot(entity, str(mod["target"]))
	list.append(mod.duplicate(true))
	_modifiers[entity] = list
	var after := _stat_snapshot(entity, str(mod["target"]))
	if before.get("found", false) and after.get("found", false) and not is_finite(float(after["value"])):
		list.pop_back()
		return
	event["accepted"] = true
	_stat_notify(entity, str(mod["target"]), before, after)
	EventBus.publish(&"PipelineModifierChanged", {"entity": entity, "target": mod["target"]})

func _remove(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var id := str(event.get("id", ""))
	var list: Array = _modifiers.get(entity, [])
	for i in range(list.size()):
		if str(list[i]["id"]) != id:
			continue
		var target := str(list[i]["target"])
		var before := _stat_snapshot(entity, target)
		list.remove_at(i)
		if list.is_empty():
			_modifiers.erase(entity)
		var after := _stat_snapshot(entity, target)
		event["accepted"] = true
		_stat_notify(entity, target, before, after)
		EventBus.publish(&"PipelineModifierChanged", {"entity": entity, "target": target})
		return

func _evaluate(event: Dictionary) -> void:
	event["accepted"] = false
	var base = event.get("base", null)
	var entity: StringName = event.get("entity", &"")
	var target := str(event.get("target", ""))
	var local = event.get("modifiers", [])
	if not _number(base) or target.is_empty() or not local is Array:
		return
	var combined: Array = []
	for mod in _modifiers.get(entity, []):
		if str(mod["target"]) == target:
			combined.append(mod)
	for mod in local:
		if not _valid_operation(mod):
			return
		combined.append(mod)
	var percent := 0.0
	if event.get("apply_weight", false) and target in ["action.duration", "action.stamina_cost"]:
		var weight := {"entity": entity, "found": false}
		EventBus.publish(&"WeightModifiersRequested", weight)
		if not weight["found"]:
			event["error"] = "Штраф веса не определён"
			return
		percent = float(weight["modifiers"]["action_duration_add" if target == "action.duration" else "stamina_cost_add"])
	var value := float(base)
	for stage in STAGES:
		var stage_base := value
		if stage == "threshold":
			# Процентные штрафы разных источников складываются между собой.
			for mod in combined:
				if str(mod["op"]) == "percent_add" and (not mod.has("threshold") or stage_base >= float(mod["threshold"])):
					percent += float(mod["value"])
			value *= 1.0 + percent
		for mod in combined:
			if str(mod["stage"]) != stage or str(mod["op"]) == "percent_add":
				continue
			if mod.has("threshold") and stage_base < float(mod["threshold"]):
				continue
			match str(mod["op"]):
				"add": value += float(mod["value"])
				"multiply": value *= float(mod["value"])
				"clamp_min": value = maxf(value, float(mod["value"]))
				"clamp_max": value = minf(value, float(mod["value"]))
				"round": value = round(value)
				"floor": value = floor(value)
				"ceil": value = ceil(value)
			if not is_finite(value):
				return
	event["value"] = value
	event["accepted"] = true

func _valid(mod: Variant) -> bool:
	if not mod is Dictionary or str(mod.get("id", "")).is_empty() or str(mod.get("target", "")).is_empty() or not _valid_operation(mod): return false
	# Процентная защита складывается из отдельных источников; произвольные
	# стадии pipeline не выражают это правило и не допускаются для цели.
	if str(mod["target"]) in ["protection.magical","protection.physical"]:
		return str(mod.get("stage","")) == "additive" and str(mod.get("op","")) == "add" and absf(float(mod["value"])) <= 1000000000.0
	return true

func _valid_operation(mod: Variant) -> bool:
	if not mod is Dictionary:
		return false
	var stage := str(mod.get("stage", ""))
	var op := str(mod.get("op", ""))
	if stage not in STAGES:
		return false
	if stage == "additive" and op != "add":
		return false
	if stage == "multiplicative" and op not in ["multiply", "percent_add"]:
		return false
	if stage == "threshold" and op not in ["add", "multiply", "percent_add"]:
		return false
	if stage == "final" and op not in ["add", "multiply", "clamp_min", "clamp_max", "round", "floor", "ceil"]:
		return false
	if op not in ["round", "floor", "ceil"] and not _number(mod.get("value", null)):
		return false
	return not mod.has("threshold") or (stage == "threshold" and _number(mod["threshold"]))

func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

func _stat_snapshot(entity: StringName, target: String) -> Dictionary:
	if not target.begins_with("stat."):
		return {"found": false}
	var query := {"entity": entity, "stat": StringName(target.trim_prefix("stat.")), "found": false}
	EventBus.publish(&"StatGetRequested", query)
	return query

func _stat_notify(entity: StringName, target: String, before: Dictionary, after: Dictionary) -> void:
	if before.get("found", false) and after.get("found", false) and before["value"] != after["value"]:
		EventBus.publish(&"StatChanged", {"entity": entity, "stat": StringName(target.trim_prefix("stat.")), "old": before["value"], "new": after["value"]})

func _entity_removed(event: Dictionary) -> void:
	_modifiers.erase(event.get("entity", &""))
func _snapshot_collect(event: Dictionary) -> void:
	event["sections"]["pipeline"] = {"modifiers": _modifiers.duplicate(true)}
func _snapshot_apply(event: Dictionary) -> void:
	_modifiers = event["sections"]["pipeline"]["modifiers"].duplicate(true)
