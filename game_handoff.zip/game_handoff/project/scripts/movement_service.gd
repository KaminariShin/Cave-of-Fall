extends Node
## Каркас шагов/pathTo/aimAnchor. Движение инициирует действие Action Registry.
const MOVEMENT_COST_FACTOR := 0.5 # Пользователь: базовая стоимость передвижения вдвое ниже.
const STEPS := [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT, Vector2i(1,-1), Vector2i(1,1), Vector2i(-1,1), Vector2i(-1,-1)]
var _config: Dictionary = {} # entity -> {base_hundredths, K_move}
var _moves: Dictionary = {}  # entity -> {from,to,start,duration}
var _paths: Dictionary = {}  # entity -> оставшиеся якоря
var _time := 0.0
var _base_speeds: Dictionary = {}
var _default_k: Variant = null
var _aim_range := 8

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var data: Dictionary = rules["ruleset"].get("parameters", {}).get("movement", {})
		_base_speeds = data.get("base_hundredths_per_tile", {}).duplicate(true)
		_default_k = data.get("K_move", null)
		_aim_range = int(data.get("aim_search_radius_tiles", 8))
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data": {"id": &"move", "name": "Перемещение", "type": &"physical", "base_duration": 0.01, "interruptible": true}})
	EventBus.subscribe(&"MovementConfigureRequested", _configure)
	EventBus.subscribe(&"MovementStepRequested", _step_requested)
	EventBus.subscribe(&"MovementPathFindRequested", _path_find_requested)
	EventBus.subscribe(&"MovementPathStartRequested", _path_start_requested)
	EventBus.subscribe(&"MovementPathCancelRequested", _path_cancel_requested)
	EventBus.subscribe(&"MovementAimAnchorRequested", _aim_requested)
	EventBus.subscribe(&"MovementPositionGetRequested", _position_requested)
	EventBus.subscribe(&"MovementStepTowardRequested", _step_toward_requested)
	EventBus.subscribe(&"MovementMeleeApproachStepRequested", _melee_approach_step)
	EventBus.subscribe(&"ActionCompleted", _action_completed)
	EventBus.subscribe(&"ActionInterrupted", _action_interrupted)
	EventBus.subscribe(&"TimeStepStarted", _time_step)
	# ResourceService подписан раньше: регенерация текущего шага уже завершена.
	EventBus.subscribe(&"TimeResourcesTick", _charge_progress_tick)
	EventBus.subscribe(&"MovementSnapshotValidateRequested", _snapshot_validate)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"SnapshotRestored", _snapshot_restored)

func _configure(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var base = event.get("base_hundredths", _base_speeds.get(str(event.get("actor_type", "")), null))
	var k = event.get("K_move", _default_k)
	if entity == &"" or not _positive(base) or not _positive(k):
		event["error"] = "Нужны положительные база и K_move"
		return
	var owner := {"entity": entity, "found": false}
	EventBus.publish(&"EntityGetRequested", owner)
	if not owner["found"]:
		return
	_config[entity] = {"base_hundredths": float(base), "K_move": float(k)}
	event["accepted"] = true

func _step_requested(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var delta = event.get("delta", null)
	if not delta is Vector2i or (delta == Vector2i.ZERO) or absi(delta.x) > 1 or absi(delta.y) > 1:
		return
	_paths.erase(entity)
	event["accepted"] = _start_step(entity, delta)

func _start_step(entity: StringName, delta: Vector2i) -> bool:
	if not _config.has(entity) or _moves.has(entity):
		return false
	var body := _get_body(entity)
	if body.is_empty():
		return false
	var from: Vector2i = body["anchor"]
	if not _can_step(entity, body, from, delta):
		return false
	var stat := {"entity": entity, "stat": &"DEX", "found": false}
	EventBus.publish(&"StatGetRequested", stat)
	if not stat["found"]:
		return false
	var denom := 1.0 + (float(stat["value"]) - 5.0) / float(_config[entity]["K_move"])
	if not is_finite(denom) or denom <= 0.0:
		return false
	var duration: float = float(_config[entity]["base_hundredths"]) / 100.0 / denom
	var pipeline := {"entity": entity, "target": "action.duration", "base": duration, "apply_weight": true, "accepted": false}
	EventBus.publish(&"PipelineEvaluateRequested", pipeline)
	if not pipeline["accepted"] or not _positive(pipeline["value"]):
		return false
	duration = maxf(0.01, ceil(float(pipeline["value"]) / 0.01 - 0.000000001) * 0.01)
	var state := _stamina_state(entity)
	if state.is_empty(): return false
	var initial_duration := maxf(0.01, ceil(duration * (1.5 if _slowed(state) else 1.0) / 0.01 - 0.000000001) * 0.01)
	_moves[entity] = {"from": from, "to": from + delta, "start": _time, "duration": duration, "progress":0.0, "charged_progress": 0.0}
	var start := {"entity": entity, "action": &"move", "duration": initial_duration, "accepted": false}
	EventBus.publish(&"ActionStartRequested", start)
	if not start["accepted"]:
		_moves.erase(entity)
		return false
	EventBus.publish(&"MovementStarted", {"entity": entity, "from": from, "to": from + delta, "duration": initial_duration})
	return true

func _action_completed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if event.get("action", &"") != &"move" or not _moves.has(entity):
		return
	if not _charge_to_now(entity):
		_moves.erase(entity)
		_paths.erase(entity)
		EventBus.publish(&"MovementCostFailed", {"entity":entity})
		return
	if not _moves.has(entity): return
	var move: Dictionary = _moves[entity]
	_moves.erase(entity)
	var target := {"entity": entity, "anchor": move["to"], "accepted": false}
	EventBus.publish(&"SpaceBodyMoveRequested", target)
	if not target["accepted"] or target.get("anchor", null) != move["to"]:
		_paths.erase(entity)
		EventBus.publish(&"MovementBlocked", {"entity": entity, "target": move["to"]})
		return
	EventBus.publish(&"MovementCompleted", {"entity": entity, "from": move["from"], "to": move["to"]})
	if _paths.has(entity) and not _paths[entity].is_empty():
		call_deferred("_continue_path", entity)
	else:
		_paths.erase(entity)

func _continue_path(entity: StringName) -> void:
	if _moves.has(entity):
		return
	if not _paths.has(entity) or _paths[entity].is_empty():
		return
	var body := _get_body(entity)
	if body.is_empty():
		_paths.erase(entity)
		return
	var next: Vector2i = _paths[entity].pop_front()
	if not _start_step(entity, next - body["anchor"]):
		_paths.erase(entity)
		EventBus.publish(&"MovementPathStopped", {"entity": entity})

func _action_interrupted(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if event.get("action", &"") != &"move" or not _moves.has(entity): return
	if not _charge_to_now(entity): EventBus.publish(&"MovementCostFailed", {"entity":entity})
	if not _moves.has(entity): return
	var move: Dictionary = _moves[entity]
	var progress := float(move["progress"])
	# Убираем сегмент до пространственных событий, чтобы вложенное прерывание
	# или смена комнаты не переместили тело дважды.
	_moves.erase(entity)
	_paths.erase(entity)
	var anchor = _snap_interrupted(entity, move, progress)
	EventBus.publish(&"MovementInterrupted", {"entity": entity, "anchor": anchor, "progress":progress})

func _snap_interrupted(entity: StringName, move: Dictionary, progress: float) -> Variant:
	var body := _get_body(entity)
	if body.is_empty(): return null
	var origin: Vector2i = move["from"]
	var target: Vector2i = move["to"]
	# Если внешняя операция уже переместила тело, нельзя возвращать его назад.
	if body["anchor"] != origin: return body["anchor"]
	var point := Vector2(origin).lerp(Vector2(target), progress)
	var candidates: Array[Vector2i] = [origin, target]
	var delta := target - origin
	if delta.x != 0 and delta.y != 0:
		candidates.append(origin + Vector2i(delta.x, 0))
		candidates.append(origin + Vector2i(0, delta.y))
	candidates.sort_custom(func(a: Vector2i,b: Vector2i) -> bool:
		var da := Vector2(a).distance_squared_to(point)
		var db := Vector2(b).distance_squared_to(point)
		if absf(da - db) > 0.000000000001: return da < db
		if a == target: return true
		if b == target: return false
		if a == origin: return true
		if b == origin: return false
		return a.y < b.y if a.y != b.y else a.x < b.x
	)
	for candidate in candidates:
		# Исходный якорь занят самим телом всё время шага и является
		# резервной позицией. Даже при ошибке проверки его не освобождаем.
		if candidate == origin: return origin
		if not _fits(entity,body,candidate): continue
		var request := {"entity":entity,"anchor":candidate,"accepted":false}
		EventBus.publish(&"SpaceBodyMoveRequested",request)
		if request.get("accepted",false) and request.get("anchor",null) == candidate: return candidate
		var current := _get_body(entity)
		if current.is_empty(): return null
		if current["anchor"] != origin: return current["anchor"]
	return origin

func _time_step(event: Dictionary) -> void:
	_time = float(event["game_time"])

func _stamina_state(entity: StringName) -> Dictionary:
	var query := {"entity":entity,"resource":&"Stamina","found":false}
	EventBus.publish(&"ResourceGetRequested",query)
	return query.get("data",{}) if query.get("found",false) else {}

func _slowed(state: Dictionary) -> bool:
	return float(state.get("current",0.0)) < 1.0 or float(state.get("movement_debt",0.0)) > 0.0

# После регенерации и перед Tick. Переход через ноль внутри шага времени
# делится на две части, чтобы оставшаяся часть сразу шла с новой скоростью.
func _charge_progress_tick(_event: Dictionary) -> void:
	for entity in _moves.keys():
		if not _moves.has(entity): continue
		var move: Dictionary = _moves[entity]
		if float(move["start"]) >= _time: continue
		var query := {"entity":entity, "allowed":true}
		EventBus.publish(&"AIEntityTickAllowedRequested", query)
		if not query.get("allowed",false): continue
		if not _advance_move_tick(entity, move) and _moves.has(entity):
			var cancelled := {"entity":entity, "reason":&"movement_cost_failed", "accepted":false}
			EventBus.publish(&"ActionCancelRequested", cancelled)
			EventBus.publish(&"MovementCostFailed", {"entity":entity})

func _advance_move_tick(entity: StringName, move: Dictionary) -> bool:
	var remaining_time := 0.01
	for iteration in range(2):
		if remaining_time <= 0.000000000001 or not _moves.has(entity) or not is_same(_moves[entity],move): break
		var state := _stamina_state(entity)
		if state.is_empty(): return false
		var slow := _slowed(state)
		var duration := float(move["duration"])
		var old := float(move["progress"])
		var delta := minf(1.0 - old, remaining_time / (duration * (1.5 if slow else 1.0)))
		if delta <= 0.0: break
		if not slow:
			var cost := {"entity":entity,"target":"action.stamina_cost","base":0.5,"apply_weight":true,"accepted":false}
			EventBus.publish(&"PipelineEvaluateRequested",cost)
			if not _moves.has(entity) or not is_same(_moves[entity],move): return true
			if not cost.get("accepted",false) or not (cost.get("value",null) is int or cost.get("value",null) is float) or not is_finite(float(cost["value"])) or float(cost["value"]) < 0.0: return false
			var per_segment := float(cost["value"]) * MOVEMENT_COST_FACTOR * Vector2(move["to"] - move["from"]).length()
			if per_segment > 0.0:
				var until_empty := (floorf(float(state["current"])) - float(state["movement_remainder"])) / per_segment
				if until_empty > 0.0: delta = minf(delta,until_empty)
		move["progress"] = minf(1.0, old + delta)
		if float(move["progress"]) >= 1.0 - 0.000000000001: move["progress"] = 1.0
		remaining_time = maxf(0.0, remaining_time - delta * duration * (1.5 if slow else 1.0))
		if not _charge_to_now(entity): return false
	if not _moves.has(entity) or not is_same(_moves[entity],move): return true
	var state := _stamina_state(entity)
	if state.is_empty(): return false
	var left := maxf(0.0, 1.0 - float(move["progress"]))
	var remaining := int(ceil(left * float(move["duration"]) * (1.5 if _slowed(state) else 1.0) / 0.01 - 0.000000001))
	return ActionRegistry.retime_move_after_tick(entity, remaining)

func _charge_to_now(entity: StringName) -> bool:
	if not _moves.has(entity): return true
	var move: Dictionary = _moves[entity]
	var progress := float(move["progress"])
	var previous := float(move["charged_progress"])
	if progress <= previous: return true
	# Проводим модификаторы стоимости для целого тайла и умножаем на
	# фактически пройденную долю; диагональ учитывает длину пути.
	var cost := {"entity":entity, "target":"action.stamina_cost", "base":0.5, "apply_weight":true, "accepted":false}
	EventBus.publish(&"PipelineEvaluateRequested", cost)
	if not _moves.has(entity) or not is_same(_moves[entity],move): return true
	if not cost.get("accepted",false) or not (cost.get("value",null) is int or cost.get("value",null) is float) or not is_finite(float(cost["value"])) or float(cost["value"]) < 0.0: return false
	var amount := float(cost["value"]) * MOVEMENT_COST_FACTOR * Vector2(move["to"] - move["from"]).length() * (progress - previous)
	# Защита от повторного начисления при вложенном событии; неудачная
	# передача откатывает метку, если сегмент всё ещё существует.
	move["charged_progress"] = progress
	var request := {"entity":entity, "amount":amount, "accepted":false}
	EventBus.publish(&"MovementStaminaChargeRequested", request)
	if not request.get("accepted",false):
		if _moves.has(entity) and is_same(_moves[entity],move): move["charged_progress"] = previous
		return false
	return true

func _position_requested(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var body := _get_body(entity)
	event["found"] = not body.is_empty()
	if not event["found"]:
		return
	var position := Vector2(body["anchor"])
	if _moves.has(entity):
		var move: Dictionary = _moves[entity]
		var progress := float(move["progress"])
		position = Vector2(move["from"]).lerp(Vector2(move["to"]), progress)
	event["position"] = position
	event["moving"] = _moves.has(entity)

func _path_find_requested(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var target = event.get("target", null)
	event["found"] = false
	if not target is Vector2i:
		return
	var body := _get_body(entity)
	if body.is_empty():
		return
	var result := _find_path(entity, body, target, int(event.get("max_nodes", 20000)))
	event["found"] = result["found"]
	if result["found"]:
		event["path"] = result["path"]

# Отменяет только будущие шаги; текущий начатый шаг заканчивается штатно.
func _path_cancel_requested(event: Dictionary) -> void:
	var entity = event.get("entity", null)
	event["accepted"] = entity is StringName and entity != &""
	if event["accepted"]:
		event["had_path"] = _paths.has(entity)
		_paths.erase(entity)

func _path_start_requested(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	if _moves.has(entity):
		return
	var query := {"entity": entity, "target": event.get("target", null), "max_nodes": event.get("max_nodes", 20000)}
	_path_find_requested(query)
	if not query["found"]:
		return
	var path: Array = query["path"]
	if path.is_empty():
		event["accepted"] = true
		return
	_paths[entity] = path.duplicate()
	var body := _get_body(entity)
	var next: Vector2i = _paths[entity].pop_front()
	if _start_step(entity, next - body["anchor"]):
		event["accepted"] = true
	else:
		_paths.erase(entity)

func _find_path(entity: StringName, body: Dictionary, target: Vector2i, limit: int) -> Dictionary:
	var start: Vector2i = body["anchor"]
	if start == target:
		return {"found": true, "path": []}
	if limit < 1 or not _fits(entity, body, target):
		return {"found": false}
	var queue: Array = [start]
	var parents := {start: start}
	var head := 0
	while head < queue.size() and parents.size() <= mini(limit, 20000):
		var current: Vector2i = queue[head]
		head += 1
		for delta in STEPS:
			var next: Vector2i = current + delta
			if parents.has(next) or not _can_step(entity, body, current, delta):
				continue
			parents[next] = current
			if next == target:
				var path: Array = []
				var node := target
				while node != start:
					path.push_front(node)
					node = parents[node]
				return {"found": true, "path": path}
			queue.append(next)
	return {"found": false}

func _aim_requested(event: Dictionary) -> void:
	event["found"] = false
	var entity: StringName = event.get("entity", &"")
	var point = event.get("point", null)
	var body := _get_body(entity)
	if body.is_empty() or not point is Vector2 or not is_finite(point.x) or not is_finite(point.y):
		return
	var target: Vector2 = point - Vector2.ONE * float(body["size"]) / 2.0
	var ideal := Vector2i(roundi(target.x), roundi(target.y))
	# Кольца вокруг ближайшего целого якоря; внутри кольца сортировка по расстоянию.
	for ring in range(_aim_range + 1):
		var candidates: Array = []
		for y in range(-ring, ring + 1):
			for x in range(-ring, ring + 1):
				if maxi(absi(x), absi(y)) == ring:
					candidates.append(ideal + Vector2i(x, y))
		candidates.sort_custom(func(a, b): return Vector2(a).distance_squared_to(target) < Vector2(b).distance_squared_to(target))
		for candidate in candidates:
			if _fits(entity, body, candidate):
				event["found"] = true
				event["anchor"] = candidate
				return

func _step_toward_requested(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var target = event.get("target", null)
	var body := _get_body(entity)
	if body.is_empty() or not target is Vector2i:
		return
	var delta: Vector2i = target - body["anchor"]
	if delta == Vector2i.ZERO:
		return
	var x_step := Vector2i(signi(delta.x), 0)
	var y_step := Vector2i(0, signi(delta.y))
	var candidates := [x_step, y_step] if absi(delta.x) >= absi(delta.y) else [y_step, x_step]
	for step in candidates:
		if step != Vector2i.ZERO and _start_step(entity, step):
			event["accepted"] = true
			return
	# Длительность ожидания задаёт вызывающая система; время NPC не запускает само себя.
	if event.has("wait_duration") and _positive(event["wait_duration"]):
		var wait := {"entity": entity, "action": &"wait", "duration": event["wait_duration"], "accepted": false}
		EventBus.publish(&"ActionStartRequested", wait)
		event["accepted"] = wait["accepted"]
		event["waiting"] = wait["accepted"]
	EventBus.publish(&"MovementNoPath", {"entity": entity})

# Ограниченный поиск одного шага к свободной стороне тела цели. Маршрут
# пересчитывается после каждого шага и не сохраняется между тиками.
func _melee_approach_step(event: Dictionary) -> void:
	event["accepted"] = false
	event["reason"] = "Маршрут не найден"
	var actor = event.get("entity",null)
	var target = event.get("target",null)
	if not actor is StringName or not target is StringName or actor == target or actor == &"" or target == &"": return
	var body := _get_body(actor)
	var victim := _get_body(target)
	if body.is_empty() or victim.is_empty() or _moves.has(actor): return
	var start: Vector2i = body["anchor"]
	var target_anchor: Vector2i = victim["anchor"]
	var actor_size: int = body["size"]
	var target_size: int = victim["size"]
	if _adjacent_bodies(start,actor_size,target_anchor,target_size):
		event["reason"] = "Уже рядом с целью"
		return
	# A*: одинаковые оценки разрешаются порядком добавления, что делает
	# результат воспроизводимым. Лимит защищает время тика в тупике.
	var frontier: Array = [start]
	var best := {start:0}
	var parent := {start:start}
	var closed := {}
	const LIMIT := 512
	while not frontier.is_empty() and closed.size() < LIMIT:
		var index := 0
		var score := 2147483647
		for i in range(frontier.size()):
			var node: Vector2i = frontier[i]
			var candidate: int = int(best[node]) + _approach_heuristic(node,actor_size,target_anchor,target_size)
			if candidate < score: score = candidate; index = i
		var current: Vector2i = frontier.pop_at(index)
		if closed.has(current): continue
		closed[current] = true
		if _adjacent_bodies(current,actor_size,target_anchor,target_size):
			var next := current
			while parent[next] != start: next = parent[next]
			if _start_step(actor,next-start):
				event["accepted"] = true
				event["next"] = next
				event.erase("reason")
			return
		for delta in STEPS:
			var next: Vector2i = current + delta
			if closed.has(next) or not _can_step(actor,body,current,delta): continue
			var cost: int = int(best[current]) + (14 if delta.x != 0 and delta.y != 0 else 10)
			if not best.has(next) or cost < int(best[next]):
				best[next] = cost
				parent[next] = current
				if not frontier.has(next): frontier.append(next)
	if closed.size() >= LIMIT: event["reason"] = "Достигнут предел поиска"

func _adjacent_bodies(a: Vector2i, n: int, b: Vector2i, m: int) -> bool:
	var overlap_x := a.x < b.x + m and b.x < a.x + n
	var overlap_y := a.y < b.y + m and b.y < a.y + n
	return ((a.x+n == b.x or b.x+m == a.x) and overlap_y) or ((a.y+n == b.y or b.y+m == a.y) and overlap_x)

func _approach_heuristic(a: Vector2i, n: int, b: Vector2i, m: int) -> int:
	var dx := maxi(maxi(b.x-(a.x+n),a.x-(b.x+m)),0)
	var dy := maxi(maxi(b.y-(a.y+n),a.y-(b.y+m)),0)
	return 10 * maxi(dx,dy)

func _can_step(entity: StringName, body: Dictionary, from: Vector2i, delta: Vector2i) -> bool:
	if not _fits(entity, body, from + delta):
		return false
	if delta.x != 0 and delta.y != 0:
		return _fits(entity, body, from + Vector2i(delta.x, 0)) and _fits(entity, body, from + Vector2i(0, delta.y))
	return true

func _fits(entity: StringName, body: Dictionary, anchor: Vector2i) -> bool:
	var query := {"anchor": anchor, "size": body["size"], "room": body["room"], "ignore_entity": entity}
	EventBus.publish(&"SpaceBodyFitsRequested", query)
	return query.get("fits", false)

func _get_body(entity: StringName) -> Dictionary:
	var query := {"entity": entity, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", query)
	return query.get("data", {}) if query["found"] else {}

func _positive(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) > 0.0
func _entity_removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	_config.erase(entity)
	_moves.erase(entity)
	_paths.erase(entity)
func _snapshot_collect(event: Dictionary) -> void:
	event["sections"]["movement"] = {"config": _config.duplicate(true), "moves": _moves.duplicate(true), "paths": _paths.duplicate(true), "time": _time}
func _snapshot_validate(event: Dictionary) -> void:
	event["valid"] = false
	var sections = event.get("sections",null)
	if not sections is Dictionary or not sections.get("movement",null) is Dictionary: return
	var state: Dictionary = sections["movement"]
	var moves = state.get("moves",null)
	var now = state.get("time",null)
	if not moves is Dictionary or not (now is float or now is int) or not is_finite(float(now)) or float(now) < 0.0: return
	for entity in moves:
		var move = moves[entity]
		if not entity is StringName or not move is Dictionary or not move.get("from",null) is Vector2i or not move.get("to",null) is Vector2i: return
		var duration = move.get("duration",null)
		var start = move.get("start",null)
		var charged = move.get("charged_progress",null)
		if not _positive(duration) or not (start is float or start is int) or not is_finite(float(start)) or float(start) > float(now) + 0.000001: return
		if not (charged is float or charged is int) or not is_finite(float(charged)) or float(charged) < 0.0 or float(charged) > 1.0: return
		var progress = move.get("progress",null)
		if not (progress is float or progress is int) or not is_finite(float(progress)) or float(progress) < 0.0 or float(progress) >= 1.0: return
		if absf(float(progress) - float(charged)) > 0.000001: return
		var actions = sections.get("actions",{})
		if not actions is Dictionary or not actions.get("active",{}) is Dictionary or not actions["active"].get(entity,null) is Dictionary or actions["active"][entity].get("id",null) != &"move": return
		var action: Dictionary = actions["active"][entity]
		if not action.get("elapsed",null) is int or not action.get("steps",null) is int or action["elapsed"] < 0 or action["steps"] <= action["elapsed"]: return
		if actions.get("controlled",null) == entity:
			var time = sections.get("time",null)
			if not time is Dictionary or not time.get("active",false) or time.get("action_id",null) != &"move" or time.get("elapsed_steps",null) != action["elapsed"] or time.get("action_steps",null) != action["steps"]: return
	event["valid"] = true

func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["movement"]
	_config = data["config"].duplicate(true)
	_moves = data["moves"].duplicate(true)
	_paths = data["paths"].duplicate(true)
	_time = float(data["time"])

func _snapshot_restored(_event: Dictionary) -> void:
	for entity in _paths.keys():
		if not _moves.has(entity) and not _paths[entity].is_empty():
			call_deferred("_continue_path", entity)
