extends Node
## Информация — проекция уже обнаруженного; фактическое обнаружение не меняется.
var _thresholds := {"hp": 5.0, "action_timer": 10.0, "action_name": 20.0, "effect_time": 30.0}
var _last_hotbar: Dictionary = {}
var _publishing := false
var _dirty := false

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var thresholds = rules["ruleset"].get("parameters", {}).get("detection", {}).get("detail_thresholds", {})
		if _valid_thresholds(thresholds): _thresholds = thresholds.duplicate(true)
	EventBus.subscribe(&"DetectionDetailsGetRequested", _details_get)
	EventBus.subscribe(&"HotbarDetailsGetRequested", _hotbar_get)
	EventBus.subscribe(&"HotbarChanged", _changed)
	EventBus.subscribe(&"ControlledEntityRequested", _controlled_changed)
	EventBus.subscribe(&"StatChanged", _stat_changed)
	EventBus.subscribe(&"ResourceChanged", _changed)
	EventBus.subscribe(&"ActionStarted", _changed)
	EventBus.subscribe(&"ActionCompleted", _changed)
	EventBus.subscribe(&"ActionInterrupted", _changed)
	EventBus.subscribe(&"RatBiteTelegraphStarted", _changed)
	EventBus.subscribe(&"AIWeaponTelegraphStarted", _changed)
	EventBus.subscribe(&"Tick", _changed)
	EventBus.subscribe(&"SnapshotRestored", _restored)

func _valid_thresholds(data: Variant) -> bool:
	if not data is Dictionary: return false
	var previous := 0.0
	for key in ["hp", "action_timer", "action_name", "effect_time"]:
		var value = data.get(key, null)
		if not (value is int or value is float) or not is_finite(float(value)) or float(value) < previous:
			return false
		previous = float(value)
	return true

func _details_get(event: Dictionary) -> void:
	event["found"] = false
	event["data"] = {}
	var observer: StringName = event.get("observer", &"")
	var target: StringName = event.get("target", &"")
	var pair := {"observer": observer, "target": target}
	EventBus.publish(&"DetectionPairGetRequested", pair)
	if not pair["detected"] or not pair["hostile"]:
		return
	var per := {"entity": observer, "stat": &"PER", "found": false}
	EventBus.publish(&"StatGetRequested", per)
	if not per["found"] or not is_finite(float(per["value"])):
		return
	var value := float(per["value"])
	var result := {"target": target}
	if value >= float(_thresholds["hp"]):
		var hp := {"entity": target, "resource": &"HP", "found": false}
		EventBus.publish(&"ResourceGetRequested", hp)
		if hp["found"]:
			result["hp"] = {"current": hp["data"]["current"], "max": hp["data"]["max"]}
	if value >= float(_thresholds["action_timer"]):
		var action := {"entity": target, "found": false}
		EventBus.publish(&"ActionGetRequested", action)
		var action_info := {"active": action["found"]}
		if action["found"]:
			var allowed := {"entity": target, "allowed": true}
			EventBus.publish(&"AIEntityTickAllowedRequested", allowed)
			if not allowed["allowed"]: action_info["paused"] = true
			var current: Dictionary = action["data"]
			var duration := float(current["duration"])
			var elapsed := float(current["elapsed"])
			action_info["progress"] = clampf(elapsed / duration, 0.0, 1.0) if duration > 0.0 else 0.0
			if value >= float(_thresholds["action_name"]):
				var definition := {"action": current["id"], "found": false}
				EventBus.publish(&"ActionDefinitionGetRequested", definition)
				if definition["found"]: action_info["name"] = definition["data"]["name"]
			if value >= float(_thresholds["effect_time"]):
				var remaining := maxf(0.0, duration - elapsed)
				action_info["remaining_action_seconds"] = remaining
				if allowed["allowed"] and _effect_at_end(target, current["id"]):
					action_info["effect_in_seconds"] = remaining
		result["action"] = action_info
	event["data"] = result
	event["found"] = true

func _effect_at_end(entity: StringName, action: StringName) -> bool:
	if action == &"rat_bite":
		var bite := {"entity": entity, "found": false}
		EventBus.publish(&"RatBiteTelegraphGetRequested", bite)
		return bite["found"] and bite["data"].get("announced", false)
	if action in [&"ai_summon", &"ai_staff_attack"]:
		var pending := {"entity": entity, "action": action, "scheduled": false}
		EventBus.publish(&"AIActionEffectScheduledRequested", pending)
		return pending["scheduled"]
	return false

func _hotbar_get(event: Dictionary) -> void:
	var bar := {}
	EventBus.publish(&"HotbarGetRequested", bar)
	var entries: Array = []
	for target in bar["hostiles"]:
		var details := {"observer": bar["entity"], "target": target, "found": false}
		_details_get(details)
		if details["found"]: entries.append(details["data"])
	event["entity"] = bar["entity"]
	event["entries"] = entries
	event["combat_detected"] = bar["combat_detected"]

func _controlled_changed(event: Dictionary) -> void:
	if event.get("accepted", false): _changed(event)
func _stat_changed(event: Dictionary) -> void:
	# Может меняться PER наблюдателя или максимум HP цели (например, CON).
	_changed(event)
func _changed(_event: Dictionary) -> void:
	if _publishing:
		_dirty = true
		return
	_publishing = true
	# Повторяем после вложенного изменения, но не допускаем бесконечный цикл подписчика.
	for _attempt in range(8):
		_dirty = false
		var bar := {}
		_hotbar_get(bar)
		if bar != _last_hotbar:
			_last_hotbar = bar.duplicate(true)
			EventBus.publish(&"HotbarDetailsChanged", bar.duplicate(true))
		if not _dirty: break
	_publishing = false
func _restored(_event: Dictionary) -> void:
	_last_hotbar = {}
	_changed({})
