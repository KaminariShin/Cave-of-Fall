extends Node
## Синхронная шина: издатель не знает подписчиков.
signal event_published(event: StringName, payload: Dictionary)

var _subscribers: Dictionary = {}

func subscribe(event: StringName, handler: Callable) -> bool:
	if event == &"" or not handler.is_valid():
		return false
	if not _subscribers.has(event):
		_subscribers[event] = []
	var listeners: Array = _subscribers[event]
	if listeners.has(handler):
		return false
	listeners.append(handler)
	return true

func unsubscribe(event: StringName, handler: Callable) -> bool:
	if not _subscribers.has(event):
		return false
	var listeners: Array = _subscribers[event]
	if not listeners.has(handler):
		return false
	listeners.erase(handler)
	if listeners.is_empty():
		_subscribers.erase(event)
	return true

## Обработчики получают один Dictionary, в порядке подписки. Снимок списка
## обеспечивает предсказуемость при изменении подписок во время публикации.
func publish(event: StringName, payload: Dictionary = {}) -> void:
	if _subscribers.has(event):
		var snapshot: Array = _subscribers[event].duplicate()
		for handler in snapshot:
			if handler.is_valid():
				handler.call(payload)
	event_published.emit(event, payload)
