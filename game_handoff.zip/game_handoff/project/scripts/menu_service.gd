extends Node
## Requests describe UI transitions; gameplay transitions finish through ActionRegistry.
const GAMEPLAY := ["inventory", "chest", "trade", "craft", "workbench", "dialogue", "equipment", "stats"]
const UI_ONLY := ["hotbar", "health_bars", "minimap", "tooltips", "pause", "settings", "save"]
const ACTION := &"menu_transition"
var _pending: Dictionary = {}
var _busy := false

func _ready() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION, "name":"Открытие или закрытие меню", "type":&"utility", "base_duration":0.01, "interruptible":true}})
	EventBus.subscribe(&"MenuTransitionRequested", _transition)
	EventBus.subscribe(&"ActionCompleted", _completed)
	EventBus.subscribe(&"ActionInterrupted", _interrupted)
	EventBus.subscribe(&"EntityRemoved", _removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"MenuSnapshotValidateRequested", _validate)

func _transition(event: Dictionary) -> void:
	event["accepted"] = false
	var menu := str(event.get("menu", ""))
	var op := str(event.get("operation", ""))
	if op not in ["open", "close"]: return
	if menu in UI_ONLY:
		event["accepted"] = true
		EventBus.publish(&"MenuTransitionCompleted", {"menu":menu, "operation":op, "gameplay":false})
		return
	if menu not in GAMEPLAY or _busy: return
	var actor = event.get("entity", null)
	if not actor is StringName or actor == &"" or _pending.has(actor): return
	var mode := {}
	EventBus.publish(&"GameModeGetRequested", mode)
	if mode.get("entity", &"") != actor: return
	_pending[actor] = {"menu":menu, "operation":op}
	_busy = true
	var start := {"entity":actor, "action":ACTION, "duration":0.01, "accepted":false}
	EventBus.publish(&"ActionStartRequested", start)
	_busy = false
	var current := {"entity":actor, "found":false}
	EventBus.publish(&"ActionGetRequested", current)
	if not start["accepted"] or not _pending.has(actor) or not current["found"] or current["data"].get("id", &"") != ACTION:
		_pending.erase(actor)
		return
	event["accepted"] = true
	EventBus.publish(&"MenuTransitionStarted", {"entity":actor, "menu":menu, "operation":op, "duration":0.01})

func _completed(event: Dictionary) -> void:
	var actor = event.get("entity", &"")
	if event.get("action", &"") != ACTION or not _pending.has(actor): return
	var data: Dictionary = _pending[actor]
	_pending.erase(actor)
	EventBus.publish(&"MenuTransitionCompleted", {"entity":actor, "menu":data["menu"], "operation":data["operation"], "gameplay":true})

func _interrupted(event: Dictionary) -> void:
	var actor = event.get("entity", &"")
	if event.get("action", &"") != ACTION or not _pending.has(actor): return
	var data: Dictionary = _pending[actor]
	_pending.erase(actor)
	EventBus.publish(&"MenuTransitionInterrupted", {"entity":actor, "menu":data["menu"], "operation":data["operation"], "reason":event.get("reason", &"cancelled")})

func _removed(event: Dictionary) -> void:
	_pending.erase(event.get("entity", &""))

func _collect(event: Dictionary) -> void:
	if _busy:
		event["errors"].append("Нельзя сохранять во время запуска меню")
		return
	event["sections"]["menus"] = {"pending":_pending.duplicate(true)}
func _apply(event: Dictionary) -> void:
	_pending = event["sections"]["menus"]["pending"].duplicate(true)
	_busy = false
func _validate(event: Dictionary) -> void:
	event["valid"] = false
	var s = event.get("sections", {})
	if not s.get("menus", null) is Dictionary or not s["menus"].get("pending", null) is Dictionary: return
	if not s.get("actions", null) is Dictionary or not s["actions"].get("active", null) is Dictionary: return
	var active: Dictionary = s["actions"]["active"]
	var pending: Dictionary = s["menus"]["pending"]
	for actor in pending:
		var p = pending[actor]
		if not actor is StringName or actor != s["actions"].get("controlled", &"") or not p is Dictionary or p.get("menu", "") not in GAMEPLAY or p.get("operation", "") not in ["open", "close"]: return
		if not active.has(actor) or not active[actor] is Dictionary or active[actor].get("id", &"") != ACTION: return
	for actor in active:
		if active[actor] is Dictionary and active[actor].get("id", &"") == ACTION and not pending.has(actor): return
	event["valid"] = true
