extends Node
## Только черновой розыгрыш; предметы не создаются и моды не применяются.
var _busy := false
var _rolling := false
var _limits: Dictionary = {}

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules.get("found", false):
		for row in rules["ruleset"].get("tables", {}).get("rarities", []):
			if not row is Dictionary or str(row.get("id", "")) not in ["normal", "magic", "rare"]: continue
			var limits := {}
			for category in ["prefix", "suffix", "affix"]:
				var value = row.get(category + "_max", null)
				if not (value is int or value is float) or not is_finite(float(value)) or float(value) != floorf(float(value)) or float(value) < 0 or float(value) > 20:
					limits.clear(); break
				limits[category] = int(value)
			if limits.size() == 3: _limits[StringName(row["id"])] = limits
	EventBus.subscribe(&"DungeonChestEquipmentModDraftRequested", _request)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_guard)

func _snapshot_guard(e: Dictionary) -> void:
	if _rolling: e["errors"].append("Нельзя сохранять во время розыгрыша модов")

func _request(e: Dictionary) -> void:
	e["accepted"] = false
	e["rolled_back"] = false
	for key in ["mods", "materials", "error", "fatal"]: e.erase(key)
	var base = e.get("base_id", null)
	var level = e.get("item_level", null)
	var rarity = e.get("rarity", null)
	if _busy or not base is StringName or base == &"" or not level is int or level < 1 or level > 1000000 or rarity not in [&"normal", &"magic", &"rare"] or not _limits.has(rarity):
		e["error"] = "Нужны база, целый уровень и поддерживаемая редкость"; return
	_busy = true
	var work := {"mods":[], "materials":[], "error":""}
	var tx: Dictionary = SaveService.run_world_transition_transaction(func(): return _execute(base, level, rarity, work))
	_rolling = false
	_busy = false
	e["accepted"] = tx.get("committed",false)
	e["rolled_back"] = tx.get("rolled_back",false)
	if tx.get("fatal",false): e["fatal"] = true
	if e["accepted"]:
		e["mods"] = work["mods"].duplicate(true)
		e["materials"] = work["materials"].duplicate(true)
	else: e["error"] = work["error"] if not work["error"].is_empty() else tx.get("error", "Розыгрыш недоступен")

# Разрешено только внутри внешней транзакции. Блокировка общая с публичным запросом.
func roll_for_transition(base: StringName, level: int, rarity: StringName, work: Dictionary) -> bool:
	if not SaveService.world_transition_operation_active() or _busy or not _limits.has(rarity): return false
	_busy = true
	var ok := _execute(base, level, rarity, work, true)
	_rolling = false
	_busy = false
	return ok

# Проверка записанных значений, лимитов, совместимости и исчерпания пулов.
# Без бросков, событий и изменения мира.
func validate_fixed_mods(entry: Dictionary, items: Dictionary) -> bool:
	var rarity = entry.get("rarity", null)
	var mods = entry.get("mods", null)
	var stacks = entry.get("materials", null)
	var base = entry.get("base_id", null)
	var level = entry.get("item_level", null)
	if not rarity is StringName or not _limits.has(rarity) or not mods is Array or not stacks is Array or not base is StringName or not level is int or DungeonChestModCatalogService._catalog.is_empty(): return false
	var limits: Dictionary = _limits[rarity]
	var used := {}
	var index := 0
	for category in ["prefix", "suffix", "affix"]:
		var count := 0
		while index < mods.size() and mods[index] is Dictionary and mods[index].get("category", null) == category:
			var mod: Dictionary = mods[index]
			var id = mod.get("id", null)
			var material = mod.get("material_id", null)
			if not id is StringName or used.has(id) or not material is StringName or count >= limits[category]: return false
			var candidates: Dictionary = DungeonChestModCatalogService.candidates_for_snapshot(base, level, material, category, used, items, true)
			if not candidates.get("accepted", false): return false
			var valid := false
			for row in candidates["candidates"]:
				if row["id"] != id: continue
				for tier in row["tiers"]:
					if mod == {"id":id, "category":category, "stat":row["stat"], "material_id":material, "tier":tier["tier"], "level_req":tier["level_req"], "value":tier["value"], "unlock_after":DungeonChestLearningService.gate_for(index)}: valid = true
			if not valid: return false
			used[id] = true
			index += 1
			count += 1
		if count < limits[category]:
			for stack in stacks:
				if not stack is Dictionary or not stack.get("material_id", null) is String: return false
				var candidates: Dictionary = DungeonChestModCatalogService.candidates_for_snapshot(base, level, StringName(stack["material_id"]), category, used, items, true)
				if not candidates.get("accepted", false): return false
				for remaining in candidates["candidates"]:
					# Сохранения старого пула могли завершить суффиксы до добавления
					# физического урона. Другие отсутствующие кандидаты не допускаются.
					if remaining.get("id",null) != &"suf_physical_damage": return false
	return index == mods.size()

func _execute(base: StringName, level: int, rarity: StringName, work: Dictionary, playable_only: bool = false) -> bool:
	var before: Dictionary = SaveService._collect_transition_snapshot()
	if not before.get("valid",false): return _fail(work, "Снимок недоступен")
	var items: Dictionary = before["payload"]["sections"]["items"]
	var materials: Array = DungeonChestMaterialsService._resolve(base, level, items["bases"], items["materials"])
	if materials.is_empty() or DungeonChestModCatalogService._catalog.is_empty() or not DungeonChestModCatalogService._catalog_valid(DungeonChestModCatalogService._catalog): return _fail(work, "Рецепт или каталог недоступен")
	var limits: Dictionary = _limits[rarity]
	var used := {}
	var selected: Array = []
	_rolling = true
	for category in ["prefix","suffix","affix"]:
		for attempt in range(limits[category]):
			var eligible: Array = []
			for stack in materials:
				var id := StringName(stack["material_id"])
				var result: Dictionary = DungeonChestModCatalogService.candidates_for_snapshot(base, level, id, category, used, items, playable_only)
				if not result.get("accepted",false):
					_rolling = false
					return _fail(work,"Не удалось проверить пул")
				if not result["candidates"].is_empty(): eligible.append({"material":id, "candidates":result["candidates"]})
			if eligible.is_empty(): break
			var material_index := _roll(eligible.size(), work)
			if material_index < 0: _rolling = false; return false
			var chosen_material: Dictionary = eligible[material_index]
			var mod_index := _weighted(chosen_material["candidates"], work)
			if mod_index < 0: _rolling = false; return false
			var mod: Dictionary = chosen_material["candidates"][mod_index]
			var tier_index := _weighted(mod["tiers"], work)
			if tier_index < 0: _rolling = false; return false
			var tier: Dictionary = mod["tiers"][tier_index]
			used[mod["id"]] = true
			selected.append({"id":mod["id"], "category":category, "stat":mod["stat"], "material_id":chosen_material["material"], "tier":tier["tier"], "level_req":tier["level_req"], "value":tier["value"]})
	_rolling = false
	var after: Dictionary = SaveService._collect_transition_snapshot()
	if not after.get("valid",false): return _fail(work,"Состояние после бросков недоступно")
	var a: Dictionary = after["payload"]["sections"].duplicate(true)
	var b: Dictionary = before["payload"]["sections"].duplicate(true)
	a.erase("rng"); b.erase("rng")
	if a != b: return _fail(work,"Мир изменился во время выбора")
	work["mods"] = selected
	work["materials"] = materials
	return true

func _roll(n: int, work: Dictionary) -> int:
	if n <= 0 or n > 1000000: _fail(work,"Некорректные веса"); return -1
	var q := {"min":0,"max":n - 1,"accepted":false}
	EventBus.publish(&"RngIntRequested",q)
	var value = q.get("value", null)
	if not q.get("accepted",false) or not value is int or value < 0 or value >= n:
		_fail(work,"Ошибка ГСЧ"); return -1
	return value

func _weighted(rows: Array, work: Dictionary) -> int:
	var total := 0
	for row in rows:
		if not row is Dictionary or not row.get("weight",null) is int or row["weight"] < 1: _fail(work,"Некорректный вес"); return -1
		total += row["weight"]
	var value := _roll(total,work)
	if value < 0: return -1
	var cursor := 0
	for i in range(rows.size()):
		cursor += rows[i]["weight"]
		if value < cursor: return i
	_fail(work,"Ошибка выбора")
	return -1

func _fail(work: Dictionary, message: String) -> bool:
	work["error"] = message
	return false
