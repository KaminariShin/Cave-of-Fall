extends Node
## Внутренние шаги для размещённых живых и подтверждённых погибших существ SpawnService.
var _busy := false
var _targets: Dictionary = {}
var _ownership: Dictionary = {}
var _discard_ids: Array = []
var _removing: StringName = &""

func _ready() -> void:
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested", _ownership_guard)
	EventBus.subscribe(&"LootEntityRemovalCheckRequested", _removal_guard)
	EventBus.subscribe(&"ProcessStartAllowedRequested", _process_guard)
	EventBus.subscribe(&"CombatDamageAllowedRequested", _damage_guard)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_guard)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)

# Ожидающие очереди нужно остановить отдельным шагом до вызова.
# Вызов без синхронной операции перехода отклоняется.
func discard_spawned_actors_for_transition() -> Dictionary:
	return _discard_spawned("living")

# Мёртвых выбираем только по сохранённому журналу созданных спавном ID.
func discard_spawned_corpses_for_transition() -> Dictionary:
	return _discard_spawned("dead")

# Призванные остаются жить после смерти или удаления призывателя.
func discard_ai_summons_for_transition() -> Dictionary:
	return _discard_spawned("summoned")

# Специально помеченный учебный NPC демосцены; не обобщает удаление
# неизвестных сущностей. Вызывается только из контролируемой транзакции.
func discard_demo_actor_for_transition() -> Dictionary:
	return _discard_spawned("demo")

func _selection(mode: String) -> Dictionary:
	if mode == "demo":
		if not SaveService.world_transition_operation_active(): return {"accepted":false,"error":"Нет операции перехода"}
		var id := &"demo_rat"
		if not EntityRegistry.has_entity(id): return {"accepted":true,"entities":[]}
		var actor: Dictionary = EntityRegistry.get_entity(id)
		if actor.get(&"demo_floor_actor",{}).get("type",null) != "tutorial_rat" or actor.get(&"species",{}).get("id",null) != "rat": return {"accepted":false,"error":"Неизвестный демо-противник"}
		return {"accepted":true,"entities":[id]}
	if mode == "summoned": return AIService.summoned_for_transition()
	return SpawnService.dead_actors_for_transition() if mode == "dead" else SpawnService.placed_actors_for_transition()

func _discard_spawned(mode: String) -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy:
		return {"accepted":false, "error":"Очистка существ недоступна"}
	var selected := _selection(mode)
	if not selected.get("accepted", false): return selected
	var actors: Array = selected["entities"]
	_busy = true
	_targets.clear()
	_ownership.clear()
	for actor in actors: _targets[actor] = true
	var ids: Array = []
	var seen := {}
	var error := ""
	var control := {}
	EventBus.publish(&"GameModeGetRequested", control)
	if not ProcessRegistry.independent_processes_for_entities(actors).is_empty(): error = "У существа есть независимый процесс; требуется отдельная очистка"
	for actor in actors:
		if not error.is_empty(): break
		if not actor is StringName or actor == &"" or actor == control.get("entity", &""):
			error = "Недопустимая или управляемая сущность в спавне"
			break
		var entity := {"entity":actor, "found":false}
		var body := {"entity":actor, "found":false}
		EventBus.publish(&"EntityGetRequested", entity)
		EventBus.publish(&"SpaceBodyGetRequested", body)
		var is_dead := CombatService.is_entity_dead(actor)
		if not entity.get("found", false) or (not is_dead and not body.get("found", false)) or (mode not in ["summoned", "demo"] and is_dead != (mode == "dead")):
			error = "Существо отсутствует или его состояние изменилось"
			break
		var data: Dictionary = entity["data"]
		if data.has(&"world_object") or (mode not in ["summoned", "demo"] and not data.get(&"spawn", null) is Dictionary) or (mode in ["summoned", "demo"] and (not data.get(&"species", null) is Dictionary or data[&"species"].get("id", "") != "rat")):
			error = "Сущность не является зарегистрированным существом спавна"
			break
		var inventory = data.get(&"inventory", null)
		var equipment = data.get(&"equipment", {})
		if not inventory is Dictionary or not inventory.get("items", null) is Array or not equipment is Dictionary:
			error = "Некорректное содержимое существа"
			break
		var refs: Array = []
		if not _collect_ids(inventory["items"], refs, 0) or not _collect_ids(equipment, refs, 0):
			error = "Некорректные ссылки на вещи существа"
			break
		for id in refs:
			if seen.has(id):
				error = "Повторное владение предметом существа"
				break
			seen[id] = true
			var item := {"item":id, "found":false}
			EventBus.publish(&"ItemGetRequested", item)
			if not item.get("found", false):
				error = "Предмет существа отсутствует"
				break
			ids.append(id)
		if not error.is_empty(): break
		_ownership[actor] = {"inventory":inventory["items"].duplicate(true), "equipment":equipment.duplicate(true)}
	var again := _selection(mode)
	if not again.get("accepted", false) or again.get("entities", []) != actors or not ProcessRegistry.independent_processes_for_entities(actors).is_empty() or not SaveService.world_transition_operation_active():
		error = "Состояние существ или процессов изменилось во время проверки"
	ids.sort_custom(func(a, b): return str(a) < str(b))
	if error.is_empty():
		_discard_ids = ids.duplicate()
		for actor in actors:
			var record: Dictionary = _ownership[actor]
			if not EntityRegistry.clear_spawned_ownership_for_transition(actor, record["inventory"], record["equipment"]):
				error = "Не удалось очистить вещи существа"
				break
		if error.is_empty() and not ItemService.retire_world_items_for_transition(ids): error = "Не удалось списать вещи существ"
		_discard_ids.clear()
	if error.is_empty():
		for actor in actors:
			_removing = actor
			var remove := {"entity":actor, "accepted":false}
			EventBus.publish(&"EntityRemoveRequested", remove)
			_removing = &""
			if not remove.get("accepted", false):
				error = "Не удалось удалить существо %s" % str(actor)
				break
			if not SaveService.world_transition_operation_active():
				error = "Операция перехода прервана"
				break
	if error.is_empty():
		for actor in actors:
			if EntityRegistry.has_entity(actor):
				error = "Существо было повторно создано во время очистки"
				break
		var final_spawn := _selection(mode)
		if not final_spawn.get("accepted", false): error = "Очереди спавна изменились во время очистки"
		else:
			for actor in actors:
				if final_spawn["entities"].has(actor): error = "Существо осталось в реестре спавна"
		if not ProcessRegistry.independent_processes_for_entities(actors).is_empty(): error = "Появился независимый процесс существа"
	_reset()
	if not error.is_empty():
		SaveService.fail_world_transition(error)
		return {"accepted":false, "error":error}
	return {"accepted":true, "entities":actors, "items":ids}

func is_clearing_ownership(entity: StringName, inventory: Array, equipment: Dictionary) -> bool:
	return _busy and SaveService.world_transition_operation_active() and _ownership.has(entity) and _ownership[entity]["inventory"] == inventory and _ownership[entity]["equipment"] == equipment
func is_discarding_items(ids: Array) -> bool:
	return _busy and SaveService.world_transition_operation_active() and ids == _discard_ids
func _ownership_guard(e: Dictionary) -> void:
	if _busy and _targets.has(e.get("entity", null)): e["allowed"] = false
func _removal_guard(e: Dictionary) -> void:
	if _busy and _targets.has(e.get("entity", null)) and e.get("entity", null) != _removing: e["allowed"] = false
func _damage_guard(e: Dictionary) -> void:
	if _busy and _targets.has(e.get("entity", null)): e["allowed"] = false
func _process_guard(e: Dictionary) -> void:
	if _busy and _targets.has(e.get("entity", null)): e["allowed"] = false
func _snapshot_guard(e: Dictionary) -> void:
	if _busy: e["errors"].append("Нельзя сохранять во время очистки существ этажа")
func _snapshot_apply(_e: Dictionary) -> void: _reset()
func _reset() -> void:
	_busy = false
	_targets.clear()
	_ownership.clear()
	_discard_ids.clear()
	_removing = &""
func _collect_ids(value: Variant, result: Array, depth: int) -> bool:
	if depth > 32: return false
	if value == null: return true
	if value is String or value is StringName:
		if str(value).is_empty(): return false
		result.append(StringName(str(value)))
		return true
	if value is Array:
		for child in value:
			if not _collect_ids(child, result, depth + 1): return false
		return true
	if value is Dictionary:
		if value.has("id"): return _collect_ids(value["id"], result, depth + 1)
		for child in value.values():
			if not _collect_ids(child, result, depth + 1): return false
		return true
	return false
