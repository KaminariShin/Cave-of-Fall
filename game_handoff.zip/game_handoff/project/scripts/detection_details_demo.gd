extends Control
var info: Label
var hp_bar: ProgressBar
var action_bar: ProgressBar
var name_label: Label
var timing_label: Label
var per_label: Label
var status: Label

func _ready() -> void:
	var background := ColorRect.new()
	background.color = Color("141e2a")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)
	var box := VBoxContainer.new()
	box.position = Vector2(36, 22)
	box.size = Vector2(645, 320)
	box.add_theme_constant_override("separation", 8)
	add_child(box)
	var title := Label.new()
	title.text = "Обнаружение: детализация по PER"
	title.add_theme_font_size_override("font_size", 23)
	box.add_child(title)
	per_label = Label.new()
	box.add_child(per_label)
	var slider := HSlider.new()
	slider.min_value = 4
	slider.max_value = 30
	slider.step = 1
	slider.value = 4
	slider.custom_minimum_size = Vector2(0, 24)
	box.add_child(slider)
	info = Label.new()
	box.add_child(info)
	hp_bar = ProgressBar.new()
	hp_bar.custom_minimum_size = Vector2(0, 22)
	box.add_child(hp_bar)
	name_label = Label.new()
	box.add_child(name_label)
	action_bar = ProgressBar.new()
	action_bar.custom_minimum_size = Vector2(0, 22)
	action_bar.show_percentage = false
	box.add_child(action_bar)
	timing_label = Label.new()
	box.add_child(timing_label)
	var button := Button.new()
	button.text = "Крыса готовит укус (2 с)"
	box.add_child(button)
	status = Label.new()
	box.add_child(status)
	EventBus.subscribe(&"HotbarDetailsChanged", _show_bar)
	_setup_world()
	slider.value_changed.connect(_set_per)
	button.pressed.connect(_bite)
	_set_per(4)
	_show_bar({})

func _setup_world() -> void:
	EventBus.publish(&"SpaceMapConfigureRequested", {"size": Vector2i(20,20)})
	var floors: Array = []
	for x in range(20):
		for y in range(20): floors.append(Vector2i(x,y))
	EventBus.publish(&"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})
	EntityRegistry.create_entity(&"hero")
	EventBus.publish(&"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(2,2), "size": 2})
	# Сид выбирается на стенде, правила спавна при этом не обходятся.
	for seed in range(100):
		EventBus.publish(&"RngSeedRequested", {"seed": seed})
		var sample := {}
		EventBus.publish(&"RngFloatRequested", sample)
		if float(sample["value"]) < 0.8:
			EventBus.publish(&"RngSeedRequested", {"seed": seed})
			break
	EventBus.publish(&"RatSpawnRequested", {"entity": &"rat", "anchor": Vector2i(4,2)})
	EventBus.publish(&"ControlledEntityRequested", {"entity": &"hero"})
	EventBus.publish(&"DetectionHostilitySetRequested", {"a": &"hero", "b": &"rat", "hostile": true})
	EventBus.publish(&"ActionStartRequested", {"entity": &"hero", "action": &"wait", "duration": 60.0})

func _set_per(value: float) -> void:
	per_label.text = "PER наблюдателя: %d   •   пороги: 5 / 10 / 20 / 30" % int(value)
	EventBus.publish(&"StatBaseSetRequested", {"entity": &"hero", "stat": &"PER", "value": value})
	_show_bar({})
func _bite() -> void:
	var request := {"entity": &"rat", "target": &"hero", "duration": 2.0, "damage": 0.0}
	EventBus.publish(&"RatBiteStartRequested", request)
	status.text = "Укус начат." if request["accepted"] else "Крыса уже готовит укус или действие недоступно."
func _show_bar(_event: Dictionary) -> void:
	var bar := {}
	EventBus.publish(&"HotbarDetailsGetRequested", bar)
	var entries: Array = bar.get("entries", [])
	if entries.is_empty():
		info.text = "Нет взаимно обнаруженных врагов."
		hp_bar.visible = false
		action_bar.visible = false
		name_label.text = ""
		timing_label.text = ""
		return
	var data: Dictionary = entries[0]
	info.text = "Враждебная сущность: крыса"
	hp_bar.visible = data.has("hp")
	if hp_bar.visible:
		hp_bar.max_value = maxf(1.0, float(data["hp"]["max"]))
		hp_bar.value = float(data["hp"]["current"])
	var action: Dictionary = data.get("action", {})
	action_bar.visible = action.get("active", false)
	name_label.text = "Действие: " + str(action.get("name", "неизвестно")) if action_bar.visible else "Действие не показано или отсутствует"
	if action_bar.visible: action_bar.value = float(action["progress"]) * 100.0
	timing_label.text = "До срабатывания: %.2f с" % float(action["effect_in_seconds"]) if action.has("effect_in_seconds") else "Точный момент срабатывания скрыт или неизвестен"
