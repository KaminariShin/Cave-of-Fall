extends Node
## Выбор комнат-кандидатов; не создаёт лестницу, босса, портал или переход.
var _floor: Dictionary = {}
var _depth_cache_root: StringName = &""
var _depth_cache: Dictionary = {}
var _depth_cache_ready := false

func _ready() -> void:
	EventBus.subscribe(&"DungeonFloorTrackingBeginRequested", _begin)
	EventBus.subscribe(&"DungeonFloorTrackingGetRequested", _get_tracking)
	EventBus.subscribe(&"DungeonRoomDepthRequested", _get_depth)
	EventBus.subscribe(&"DungeonDeadendBudgetAvailableRequested", _deadend_budget_available)
	EventBus.subscribe(&"DungeonStairTrialRequiredRequested", _stair_trial_required)
	EventBus.subscribe(&"DungeonPortalBranchPolicyRequested", _portal_branch_policy)
	EventBus.subscribe(&"DungeonPortalRoomCheckRequested", _portal_room_check)
	EventBus.subscribe(&"RoomChildGenerated", _child_generated)
	EventBus.subscribe(&"RoomsConnected", _rooms_connected)
	EventBus.subscribe(&"RoomRemoved", _room_removed)
	EventBus.subscribe(&"SpaceMapConfigured", _map_reset)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"DungeonTrackingSnapshotValidateRequested", _validate)

func _begin(e: Dictionary) -> void:
	e["accepted"] = false
	var floor_no = e.get("floor", null)
	var root = e.get("start_room", null)
	if not _floor.is_empty() or not floor_no is int or floor_no < 1 or floor_no > 4 or not root is StringName or root == &"": return
	var query := {"room_count":-1}
	EventBus.publish(&"RoomTopologyGetRequested", query)
	var room_types = query.get("room_types", null)
	# Начало отслеживания после генерации других комнат не гарантирует
	# выбор первой подходящей и поэтому отклоняется.
	if int(query.get("room_count", -1)) != 1 or not room_types is Dictionary or room_types.get(root, "") != "start": return
	_floor = {"floor":floor_no, "root":root, "stair_candidate":null, "boss_candidate":null, "portal_candidate":null}
	_depth_cache_root = root
	_depth_cache = {root:0}
	_depth_cache_ready = true
	e["accepted"] = true

func _clear_depth_cache() -> void:
	_depth_cache_root = &""
	_depth_cache.clear()
	_depth_cache_ready = false

func _map_reset(_e: Dictionary) -> void:
	_floor.clear()
	_clear_depth_cache()

func _room_removed(_e: Dictionary) -> void:
	_clear_depth_cache()

func _rooms_connected(e: Dictionary) -> void:
	if not _depth_cache_ready or _floor.is_empty() or _depth_cache_root != _floor.get("root", &""):
		return
	var first = e.get("room", null)
	var second = e.get("other_room", null)
	if not first is StringName or not second is StringName:
		_clear_depth_cache()
		return
	if not _depth_cache.has(first) or not _depth_cache.has(second):
		# Новая ветвь не меняет расстояния уже достижимых комнат. При
		# необходимости неизвестный конец будет разрешён топологическим BFS.
		return
	if absi(int(_depth_cache[first]) - int(_depth_cache[second])) > 1:
		# Новая связь может сократить путь от старта; пересчитаем по графу.
		_clear_depth_cache()

func _child_generated(e: Dictionary) -> void:
	if _depth_cache_ready and not _floor.is_empty() and _depth_cache_root == _floor.get("root", &""):
		var parent = e.get("room", null)
		var child = e.get("child", null)
		if parent is StringName and child is StringName and _depth_cache.has(parent):
			if not _depth_cache.has(child):
				_depth_cache[child] = int(_depth_cache[parent]) + 1
			elif absi(int(_depth_cache[parent]) - int(_depth_cache[child])) > 1:
				_clear_depth_cache()
	var room = e.get("child", null)
	if not room is StringName or room == &"": return
	var info := {"id":room, "found":false}
	EventBus.publish(&"RoomGetRequested", info)
	if not info["found"]: return
	var depth := {"room":room, "accepted":false}
	_get_depth(depth)
	if not depth["accepted"]: return
	var floor_no: int = _floor["floor"]
	var kind := ""
	if floor_no < 4 and _floor["stair_candidate"] == null and info["data"].get("type", "") == "deadend" and depth["distance"] > 5:
		_floor["stair_candidate"] = room
		kind = "stairs"
	elif floor_no == 4 and _floor["boss_candidate"] == null and info["data"].get("type", "") == "passage" and depth["distance"] > 15:
		_floor["boss_candidate"] = room
		kind = "boss"
	elif floor_no == 4 and _floor["boss_candidate"] != null and _floor["portal_candidate"] == null and e.get("room", null) == _floor["boss_candidate"] and info["data"].get("parent", null) == _floor["boss_candidate"] and info["data"].get("type", "") == "deadend":
		var linked := false
		for ex in info["data"].get("exits", []):
			if ex.get("connected", false) and ex.get("childId", null) == _floor["boss_candidate"]: linked = true
		if linked:
			_floor["portal_candidate"] = room
			kind = "portal"
	if not kind.is_empty():
		EventBus.publish(&"DungeonMilestoneCandidateSelected", {"floor":floor_no, "room":room, "kind":kind, "distance":depth["distance"], "depth":depth["depth"]})

func _get_tracking(e: Dictionary) -> void:
	e["found"] = not _floor.is_empty()
	if e["found"]: e["data"] = _floor.duplicate(true)

func _get_depth(e: Dictionary) -> void:
	e["accepted"] = false
	if _floor.is_empty(): return
	var room = e.get("room", null)
	if not room is StringName or room == &"": return
	var distance := -1
	if _depth_cache_ready and _depth_cache_root == _floor.get("root", &""):
		distance = int(_depth_cache.get(room, -1))
	if distance < 0:
		if not _rebuild_depth_cache():
			e["error"] = "Не удалось построить топологию комнат"
			return
		distance = int(_depth_cache.get(room, -1))
	if distance < 0:
		e["error"] = "Комната не связана со стартом этажа"
		return
	var calculation := {"floor":_floor["floor"], "distance":distance, "accepted":false}
	EventBus.publish(&"DungeonDepthCalculateRequested", calculation)
	if not calculation["accepted"]: return
	e["accepted"] = true
	e["distance"] = distance
	e["depth"] = calculation["depth"]
	e["enemy_level"] = calculation["enemy_level"]

func _rebuild_depth_cache() -> bool:
	if _floor.is_empty(): return false
	var root = _floor.get("root", null)
	if not root is StringName or root == &"": return false
	var query := {"topology":{}}
	EventBus.publish(&"RoomTopologyGetRequested", query)
	var topology = query.get("topology", null)
	if not topology is Dictionary or not topology.has(root): return false
	var distances: Dictionary = {root:0}
	var queue: Array = [root]
	var head := 0
	while head < queue.size():
		var current: StringName = queue[head]
		head += 1
		var neighbors = topology.get(current, null)
		if not neighbors is Array: return false
		for next in neighbors:
			if not next is StringName or not topology.has(next): continue
			if distances.has(next): continue
			distances[next] = int(distances[current]) + 1
			queue.append(next)
	_depth_cache_root = root
	_depth_cache = distances
	_depth_cache_ready = true
	return true

# До первого подходящего тупика не расходуем последнюю единицу бюджета
# на ветви, глубина которых ещё не подходит для лестницы.
func _deadend_budget_available(e: Dictionary) -> void:
	e["accepted"] = false
	var parent = e.get("room", null)
	var budget = e.get("budget", null)
	if not parent is StringName or not budget is int or budget < 0: return
	var available: int = budget
	if not _floor.is_empty() and int(_floor["floor"]) < 4 and _floor["stair_candidate"] == null and budget == 1:
		var distance := {"room":parent, "accepted":false}
		_get_depth(distance)
		if not distance["accepted"]:
			e["error"] = "Не удалось определить расстояние до родительской комнаты"
			return
		if int(distance["distance"]) + 1 <= 5: available = 0
	# Последний тупик четвёртого этажа бережём для комнаты за боссом.
	if not _floor.is_empty() and _floor["floor"] == 4 and _floor["portal_candidate"] == null and parent != _floor["boss_candidate"]:
		available = maxi(0, available - 1)
	e["accepted"] = true
	e["budget"] = available

# Только исходящий переход выбранной комнаты босса ведёт в тупик портала.
func _portal_branch_policy(e: Dictionary) -> void:
	e["accepted"] = false
	e["required"] = false
	var parent = e.get("room", null)
	if not parent is StringName or parent == &"": return
	e["accepted"] = true
	if not _floor.is_empty() and _floor["floor"] == 4 and _floor["boss_candidate"] == parent and _floor["portal_candidate"] == null:
		e["required"] = true

# При RoomCreated выбор ещё не опубликован, но связанная проба уже имеет
# parent; защита работает и в этом синхронном промежутке.
func _portal_room_check(e: Dictionary) -> void:
	e["accepted"] = false
	e["protected"] = false
	var room = e.get("room", null)
	if not room is StringName or room == &"": return
	var q := {"id":room, "found":false}
	EventBus.publish(&"RoomGetRequested", q)
	if not q.get("found", false): return
	e["accepted"] = true
	if _floor.is_empty() or _floor["floor"] != 4: return
	var data: Dictionary = q["data"]
	e["protected"] = room == _floor["portal_candidate"] or (_floor["boss_candidate"] != null and data.get("type", "") == "deadend" and data.get("parent", null) == _floor["boss_candidate"] and _floor["portal_candidate"] == null)

# Для ещё не опубликованной пробы ребёнка: distance(parent)+1.
func _stair_trial_required(e: Dictionary) -> void:
	e["accepted"] = false
	e["required"] = false
	var parent = e.get("room", null)
	var type = e.get("type", null)
	if not parent is StringName or not type is String: return
	if _floor.is_empty() or _floor["floor"] >= 4 or _floor["stair_candidate"] != null or type != "deadend":
		e["accepted"] = true
		return
	var distance := {"room":parent, "accepted":false}
	_get_depth(distance)
	if not distance.get("accepted", false): return
	e["accepted"] = true
	e["required"] = int(distance["distance"]) + 1 > 5
	e["floor"] = _floor["floor"]

func _distance(rooms: Dictionary, root: StringName, target: StringName) -> int:
	if not rooms.has(root) or not rooms.has(target): return -1
	var distances := {root:0}
	var queue: Array = [root]
	var index := 0
	while index < queue.size():
		var room: StringName = queue[index]
		index += 1
		if room == target: return int(distances[room])
		if not rooms[room] is Dictionary: return -1
		var exits = rooms[room].get("exits", [])
		if not exits is Array: return -1
		for exit in exits:
			if not exit is Dictionary: return -1
			var next = exit.get("childId", null)
			if exit.get("connected", false) and next is StringName and rooms.has(next) and not distances.has(next):
				distances[next] = int(distances[room]) + 1
				queue.append(next)
	return -1

func _collect(e: Dictionary) -> void:
	e["sections"]["dungeon_tracking"] = _floor.duplicate(true)
func _apply(e: Dictionary) -> void:
	_floor = e["sections"]["dungeon_tracking"].duplicate(true)
	_clear_depth_cache()
	if not _floor.is_empty():
		var root = _floor.get("root", null)
		if root is StringName and root != &"":
			_depth_cache_root = root
			_depth_cache = {root:0}
			_depth_cache_ready = true
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary or not sections.get("dungeon_tracking", null) is Dictionary or not sections.get("rooms", {}).get("rooms", null) is Dictionary: return
	var data: Dictionary = sections["dungeon_tracking"]
	if data.is_empty():
		e["valid"] = true
		return
	var rooms: Dictionary = sections["rooms"]["rooms"]
	var floor_no = data.get("floor", null)
	var root = data.get("root", null)
	if not floor_no is int or floor_no < 1 or floor_no > 4 or not root is StringName or not rooms.has(root) or not rooms[root] is Dictionary or str(rooms[root].get("type", "")) != "start": return
	if not data.has("stair_candidate") or not data.has("boss_candidate") or not data.has("portal_candidate"): return
	for key in ["stair_candidate", "boss_candidate"]:
		var id = data[key]
		if id == null: continue
		if not id is StringName or not rooms.has(id) or not rooms[id] is Dictionary or (key == "stair_candidate" and floor_no == 4) or (key == "boss_candidate" and floor_no != 4): return
		var type := "deadend" if key == "stair_candidate" else "passage"
		var threshold := 5 if key == "stair_candidate" else 15
		if str(rooms[id].get("type", "")) != type or _distance(rooms, root, id) <= threshold: return
	var portal = data["portal_candidate"]
	if portal != null:
		var boss = data["boss_candidate"]
		if floor_no != 4 or not portal is StringName or not boss is StringName or not rooms.get(portal, null) is Dictionary: return
		if rooms[portal].get("type", "") != "deadend" or rooms[portal].get("parent", null) != boss: return
		var linked := false
		for ex in rooms[portal].get("exits", []):
			if ex.get("connected", false) and ex.get("childId", null) == boss: linked = true
		if not linked: return
	e["valid"] = true
