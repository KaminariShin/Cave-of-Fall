extends Node
## Явно включаемый простой враг demo-пула. Выполнение после фиксации спавна.
var _busy := false
var _generation := 0
var _errors: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"RoomSpawned", _schedule)
	EventBus.subscribe(&"SpawnQueueMobSpawned", _schedule)
	EventBus.subscribe(&"PlayerRoomChanged", _schedule)
	EventBus.subscribe(&"SnapshotRestored", _restore)
	EventBus.subscribe(&"SpaceMapConfigured", _reset)
	EventBus.subscribe(&"EntityRemoved", _removed)
	EventBus.subscribe(&"DemoMeleeSetupStatusRequested", _status)
	EventBus.subscribe(&"DemoMeleeSetupRetryRequested", _retry)
	EventBus.subscribe(&"CombatDamageAllowedRequested", _damage_guard)
	EventBus.subscribe(&"CombatTargetActionAllowedRequested", _target_guard)
	EventBus.subscribe(&"ActionStartAllowedRequested", _action_guard)

func _needs(id: Variant) -> bool:
	if not id is StringName or not EntityRegistry.has_entity(id): return false
	var spawn: Dictionary = EntityRegistry.get_component(id,&"spawn")
	return spawn.get("demo_melee",false) and not spawn.has("demo_melee_item")
func _damage_guard(e: Dictionary) -> void:
	if _needs(e.get("entity",null)): e["allowed"] = false; e["reason"] = "Ожидается оснащение противника"
func _target_guard(e: Dictionary) -> void:
	if _needs(e.get("target",null)): e["allowed"] = false; e["reason"] = "Ожидается оснащение противника"
func _action_guard(e: Dictionary) -> void:
	if _needs(e.get("entity",null)): e["allowed"] = false
func _schedule(_event: Dictionary) -> void:
	call_deferred("_run", _generation)
func _restore(_event: Dictionary) -> void:
	if _busy: return
	_generation += 1
	_errors.clear()
	_schedule({})
func _reset(_event: Dictionary) -> void:
	_generation += 1
	_errors.clear()
func _removed(event: Dictionary) -> void:
	_errors.erase(event.get("entity",null))
func _status(event: Dictionary) -> void:
	var id = event.get("entity",null)
	event["status"] = "none"
	if _errors.has(id): event["status"] = "failed"; event["error"] = _errors[id]; return
	if not id is StringName or not EntityRegistry.has_entity(id): return
	var spawn: Dictionary = EntityRegistry.get_component(id,&"spawn")
	if spawn.get("demo_melee",false): event["status"] = "installed" if spawn.has("demo_melee_item") else "waiting"
func _retry(event: Dictionary) -> void:
	var id = event.get("entity",null)
	event["accepted"] = false
	if not id is StringName or not _errors.has(id): return
	_errors.erase(id)
	var result := _attempt(id)
	event.merge(result,true)
func _run(generation: int) -> void:
	if generation != _generation or _busy or SpawnService._busy: return
	for id in SpawnService._created_entities.keys():
		if not _errors.has(id): _attempt(id)
func _attempt(id: StringName) -> Dictionary:
	if _busy or SpawnService._busy or not EntityRegistry.has_entity(id) or CombatService.is_entity_dead(id): return {"accepted":false,"error":"Существо недоступно"}
	var spawn: Dictionary = EntityRegistry.get_component(id,&"spawn")
	if not spawn.get("demo_melee",false) or spawn.has("demo_melee_item"): return {"accepted":false,"error":"Не ожидает оснащения"}
	var room = SpawnService._created_entities.get(id,null)
	var current := {}
	EventBus.publish(&"RoomCurrentGetRequested",current)
	if current.get("transitioning",true) or current.get("room",null) != room or not current.get("entity",null) is StringName: return {"accepted":false,"error":"Игрок не в комнате"}
	_busy = true
	var work := {"error":"", "item":&""}
	var tx: Dictionary = SaveService.run_world_transition_transaction(func(): return _install(id,room,current["entity"],work))
	_busy = false
	if not tx.get("committed",false):
		var message := str(work["error"]) if not str(work["error"]).is_empty() else str(tx.get("error","Ошибка оснащения"))
		_errors[id] = message
		EventBus.publish(&"DemoMeleeSetupFailed", {"entity":id,"error":message,"rolled_back":tx.get("rolled_back",false)})
		return {"accepted":false,"error":message,"rolled_back":tx.get("rolled_back",false)}
	_errors.erase(id)
	EventBus.publish(&"DemoMeleeSetupInstalled", {"entity":id,"item":work["item"]})
	return {"accepted":true,"item":work["item"]}
func _fail(work: Dictionary, message: String) -> bool:
	work["error"] = message
	return false
func _install(id: StringName, room: StringName, target: StringName, work: Dictionary) -> bool:
	var snap: Dictionary = SaveService._collect_transition_snapshot()
	if not snap.get("valid",false): return _fail(work,"Снимок недоступен")
	var s: Dictionary = snap["payload"]["sections"]
	var state = s["spawn"]["states"].get(room,null)
	var actor = s["entities"].get(id,null)
	if not state is Dictionary or not state.get("placed",[]).has(id) or state.get("player",null) != target or not actor is Dictionary or s["combat"]["dead"].has(id) or not s["space"]["bodies"].has(id) or s["actions"]["active"].has(id) or s["ai"]["agents"].has(id): return _fail(work,"Состояние существа изменилось")
	var spawn = actor.get(&"spawn",{})
	if not spawn.get("demo_melee",false) or spawn.has("demo_melee_item") or not spawn.get("level",null) is int: return _fail(work,"Неверные данные спавна")
	var gear = actor.get(&"equipment",{})
	if not gear is Dictionary or not gear.is_empty(): return _fail(work,"Экипировка занята")
	# Черновой баланс: 40% меч, 30% молот, 30% лук; 50% броня,
	# 35% щит для мечника, 40% один дополнительный расходник.
	var w := _roll(1,100)
	var armour_roll := _roll(1,100)
	var shield_roll := _roll(1,100)
	var extra_roll := _roll(1,100)
	if w < 0 or armour_roll < 0 or shield_roll < 0 or extra_roll < 0: return _fail(work,"Не удалось выбрать комплект")
	var weapon_base: StringName = &"sword_simple" if w <= 40 else (&"hammer_simple" if w <= 70 else &"bow_simple")
	var strike := "demo_creature_thrust" if weapon_base == &"sword_simple" else ("demo_player_hammer_slam" if weapon_base == &"hammer_simple" else "bow_simple_shot")
	var armour_base: StringName = &""
	var shield_base: StringName = &""
	var extra_base: StringName = &""
	if armour_roll <= 50:
		var choice := _roll(0,2)
		if choice < 0: return _fail(work,"Не удалось выбрать броню")
		armour_base = [&"armor_cloth_body",&"armor_leather_body",&"armor_iron_body"][choice]
	if weapon_base == &"sword_simple" and shield_roll <= 35:
		var choice := _roll(0,2)
		if choice < 0: return _fail(work,"Не удалось выбрать щит")
		shield_base = [&"shield_small",&"shield_medium",&"shield_large"][choice]
	if extra_roll <= 40:
		var choice := _roll(0,4)
		if choice < 0: return _fail(work,"Не удалось выбрать добычу")
		extra_base = [&"potion_hp",&"potion_stamina",&"potion_mana",&"antidote",&"bandage"][choice]
	var rng_state: int = RngService._rng.state
	var item := _create_loadout_item(id,"sword",weapon_base,spawn["level"],s)
	if item == &"": return _fail(work,"Оружие не создано")
	var slots := {"main":item}
	if armour_base != &"":
		var armour := _create_loadout_item(id,"body",armour_base,spawn["level"],s)
		if armour == &"": return _fail(work,"Броня не создана")
		slots["body"] = armour
	if shield_base != &"":
		var shield := _create_loadout_item(id,"shield",shield_base,spawn["level"],s)
		if shield == &"": return _fail(work,"Щит не создан")
		slots["off"] = shield
	var equip := {"entity":id,"component":&"equipment","data":slots,"accepted":false}
	EventBus.publish(&"ComponentSetRequested",equip)
	if not equip.get("accepted",false): return _fail(work,"Комплект не надет")
	if extra_base != &"":
		var extra := _create_loadout_item(id,"loot",extra_base,spawn["level"],s)
		if extra == &"": return _fail(work,"Добыча не создана")
		var inventory := {"entity":id,"volume":100.0}
		EventBus.publish(&"InventoryConfigureRequested",inventory)
		if not inventory.get("accepted",false): return _fail(work,"Инвентарь недоступен")
		var add := {"entity":id,"item":extra}
		EventBus.publish(&"InventoryAddRequested",add)
		if not add.get("accepted",false): return _fail(work,"Добыча не помещается")
	var ai := {"entity":id,"room":room,"role":"melee","target":target,"detected":false,"wait_duration":0.1,"weapon":{"item":item,"strike":strike},"movement":{"actor_type":"goblin"},"accepted":false}
	EventBus.publish(&"AIRegisterRequested",ai)
	if not ai.get("accepted",false): return _fail(work,"ИИ не зарегистрирован: " + str(ai.get("error","")))
	var marked: Dictionary = spawn.duplicate(true)
	marked["demo_melee_item"] = item
	var set_spawn := {"entity":id,"component":&"spawn","data":marked,"accepted":false}
	EventBus.publish(&"ComponentSetRequested",set_spawn)
	if not set_spawn.get("accepted",false): return _fail(work,"Не записан комплект")
	var after: Dictionary = SaveService._collect_transition_snapshot()
	if not after.get("valid",false): return _fail(work,"Итоговый снимок недоступен")
	var final: Dictionary = after["payload"]["sections"]
	if final["entities"].get(id,{}).get(&"equipment",{}).get("main",null) != item or final["entities"].get(id,{}).get(&"spawn",{}).get("demo_melee_item",null) != item or final["ai"]["agents"].get(id,{}).get("weapon",{}).get("item",null) != item or final["time"] != s["time"] or int(final["rng"]["state"]) != rng_state: return _fail(work,"Результат изменился")
	work["item"] = item
	return true

func _roll(low: int, high: int) -> int:
	var q := {"min":low,"max":high,"accepted":false}
	EventBus.publish(&"RngIntRequested",q)
	var value = q.get("value",null)
	return value if q.get("accepted",false) and value is int and value >= low and value <= high else -1

func _create_loadout_item(actor: StringName, part: String, base: StringName, level: int, sections: Dictionary) -> StringName:
	var item: StringName = &""
	for n in range(10000):
		var candidate := StringName("demo_%s:%s:%d" % [part,str(actor).uri_encode(),n])
		if not sections["items"]["instances"].has(candidate) and not sections["items"]["retired"].has(candidate): item = candidate; break
	if item == &"": return &""
	var create := {"id":item,"base_id":base,"item_level":level,"accepted":false}
	EventBus.publish(&"ItemCreateRequested",create)
	return item if create.get("accepted",false) else &""

# Только миграция ранее созданных обычных демо-врагов при загрузке слота.
# Уже выполняющийся удар не переписывается; следующие удары используют ИИ.
func fix_loaded_demo_enemy_reach(sections: Dictionary) -> void:
	var agents: Dictionary = sections.get("ai",{}).get("agents",{})
	var entities: Dictionary = sections.get("entities",{})
	for id in agents:
		var spawn = entities.get(id,{}).get(&"spawn",{})
		var agent = agents[id]
		if not spawn is Dictionary or not spawn.get("demo_melee",false) or not agent is Dictionary: continue
		var weapon = agent.get("weapon",{})
		if weapon is Dictionary and weapon.get("item",null) == spawn.get("demo_melee_item",null) and weapon.get("strike","") == "sword_simple_thrust":
			weapon["strike"] = "demo_creature_thrust"
