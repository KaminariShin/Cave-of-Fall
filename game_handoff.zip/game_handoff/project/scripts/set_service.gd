extends Node
## Сеты не меняют характеристики напрямую и не занимают слоты обычных модов.
var _definitions: Dictionary = {}
var _active: Dictionary = {} # entity -> set -> bonus_id -> effect
var _evaluating: Dictionary = {}
var _pending: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"SetDefinitionRegisterRequested", _register)
	EventBus.subscribe(&"SetDefinitionGetRequested", _get_definition)
	EventBus.subscribe(&"SetStateGetRequested", _get_state)
	EventBus.subscribe(&"SetBonusEffectsGetRequested", _get_effects)
	EventBus.subscribe(&"EntityCreated", _on_entity_created)
	EventBus.subscribe(&"ItemCreated", _on_item_created)
	EventBus.subscribe(&"EntityRemoved", _on_entity_removed)
	EventBus.subscribe(&"ComponentChanged", _on_component_changed)
	EventBus.subscribe(&"ComponentRemoved", _on_component_changed)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		for data in rules["ruleset"].get("tables", {}).get("sets", []):
			_register({"definition": data})

func _register(event: Dictionary) -> void:
	event["accepted"] = false
	var data = event.get("definition", null)
	if not data is Dictionary:
		return
	var id := StringName(str(data.get("id", "")))
	var binding := str(data.get("binding", ""))
	var rank := str(data.get("rank", ""))
	if id == &"" or _definitions.has(id) or str(data.get("name", "")).is_empty() or binding not in ["item_id", "item_type"] or rank not in ["normal", "magic", "rare", "unique"]:
		return
	if not data.get("item_ids", []) is Array or not data.get("item_type_ids", []) is Array or not data.get("bonuses", null) is Array:
		return
	var item_ids: Array = data.get("item_ids", [])
	var item_types: Array = data.get("item_type_ids", [])
	if (binding == "item_id" and item_ids.is_empty()) or (binding == "item_type" and item_types.is_empty()):
		return
	if not _valid_ids(item_ids) or not _valid_ids(item_types):
		return
	# Артефактный ключ указывается явным ID экземпляра среди фиксированных
	# предметов сета; необязательное поле для старых сетов без артефакта.
	var artifact = data.get("required_artifact_id", null)
	if artifact != null:
		if not (artifact is String or artifact is StringName) or str(artifact).is_empty() or binding != "item_id" or not _contains_id(item_ids, artifact): return
	var seen: Dictionary = {}
	for bonus in data["bonuses"]:
		if not bonus is Dictionary or str(bonus.get("id", "")).is_empty() or seen.has(str(bonus["id"])):
			return
		if not bonus.get("required_pieces", null) is int or bonus["required_pieces"] < 1 or not bonus.get("effect", null) is Dictionary:
			return
		seen[str(bonus["id"])] = true
	_definitions[id] = data.duplicate(true)
	event["accepted"] = true
	var query := {"components": [&"equipment"], "entities": []}
	EventBus.publish(&"EntityQueryRequested", query)
	for entity in query["entities"]:
		_recalculate(entity)

func _valid_ids(ids: Array) -> bool:
	var seen: Dictionary = {}
	for value in ids:
		if not (value is String or value is StringName) or str(value).is_empty() or seen.has(str(value)):
			return false
		seen[str(value)] = true
	return true

func _get_definition(event: Dictionary) -> void:
	var id := StringName(str(event.get("id", "")))
	event["found"] = _definitions.has(id)
	if event["found"]:
		event["data"] = _definitions[id].duplicate(true)

func _get_state(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var set_id: StringName = event.get("set_id", &"")
	event["found"] = _definitions.has(set_id)
	if not event["found"]:
		return
	var equipped := _equipment(entity)
	if not equipped["ok"]:
		event["found"] = false
		event["error"] = equipped.get("error", "Ошибка экипировки")
		return
	var match_data := _match_set(_definitions[set_id], set_id, equipped["items"])
	event["data"] = match_data
	event["data"]["active_bonuses"] = _active.get(entity, {}).get(set_id, {}).keys()

func _get_effects(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var effects: Array = []
	for set_id in _active.get(entity, {}):
		for bonus_id in _active[entity][set_id]:
			effects.append({"set_id": set_id, "bonus_id": bonus_id, "effect": _active[entity][set_id][bonus_id].duplicate(true)})
	event["effects"] = effects

func _on_entity_created(event: Dictionary) -> void:
	_recalculate(event.get("entity", &""))

func _on_item_created(_event: Dictionary) -> void:
	# Создание перечисленного в определении артефакта может изменить
	# условия уже существующего сета; пересчитать всех владельцев.
	var query := {"components":[&"equipment"], "entities":[]}
	EventBus.publish(&"EntityQueryRequested", query)
	for entity in query["entities"]: _recalculate(entity)

func _on_entity_removed(event: Dictionary) -> void:
	_active.erase(event.get("entity", &""))

func _on_component_changed(event: Dictionary) -> void:
	if event.get("component", &"") == &"equipment":
		_recalculate(event.get("entity", &""))

func _recalculate(entity: StringName) -> void:
	if _evaluating.has(entity):
		_pending[entity] = true
		return
	_evaluating[entity] = true
	_recalculate_once(entity)
	while _pending.has(entity):
		_pending.erase(entity)
		_recalculate_once(entity)
	_evaluating.erase(entity)

func _recalculate_once(entity: StringName) -> void:
	var equipment := _equipment(entity)
	if not equipment["ok"]:
		var previous: Dictionary = _active.get(entity, {})
		_active.erase(entity)
		for set_id in previous:
			for bonus_id in previous[set_id]:
				_remove_effect(entity, set_id, bonus_id, previous[set_id][bonus_id])
		EventBus.publish(&"SetEvaluationFailed", {"entity": entity, "error": equipment.get("error", "Экипировка недоступна")})
		return
	var current: Dictionary = _active.get(entity, {})
	_active[entity] = current
	var desired := {}
	for set_id in _definitions:
		var definition: Dictionary = _definitions[set_id]
		var match_data := _match_set(definition, set_id, equipment["items"])
		var bonuses := {}
		if match_data["base_active"]:
			for bonus in definition["bonuses"]:
				if match_data["matching_pieces"] >= int(bonus["required_pieces"]):
					bonuses[StringName(str(bonus["id"]))] = bonus["effect"].duplicate(true)
		if not bonuses.is_empty():
			desired[set_id] = bonuses
	# Сначала снять старые модификаторы, затем поставить новые.
	for set_id in current.keys():
		for bonus_id in current[set_id].keys():
			if not desired.has(set_id) or not desired[set_id].has(bonus_id):
				var old_effect: Dictionary = current[set_id][bonus_id]
				current[set_id].erase(bonus_id)
				_remove_effect(entity, set_id, bonus_id, old_effect)
		if current[set_id].is_empty():
			current.erase(set_id)
	for set_id in desired:
		for bonus_id in desired[set_id]:
			if current.has(set_id) and current[set_id].has(bonus_id):
				continue
			var effect: Dictionary = desired[set_id][bonus_id]
			if _apply_effect(entity, set_id, bonus_id, effect):
				if not current.has(set_id):
					current[set_id] = {}
				current[set_id][bonus_id] = effect.duplicate(true)
				EventBus.publish(&"SetBonusActivated", {"entity": entity, "set_id": set_id, "bonus": bonus_id, "effect": effect.duplicate(true)})
			else:
				EventBus.publish(&"SetBonusActivationFailed", {"entity": entity, "set_id": set_id, "bonus": bonus_id})
	if current.is_empty():
		_active.erase(entity)
	else:
		_active[entity] = current

func _apply_effect(entity: StringName, set_id: StringName, bonus_id: StringName, effect: Dictionary) -> bool:
	# Прочие цели доступны будущему конвейеру через SetBonusEffectsGetRequested.
	if str(effect.get("target", "")) != "stat":
		return true
	var modifier := effect.duplicate(true)
	modifier.erase("target")
	modifier["id"] = _modifier_id(set_id, bonus_id)
	var request := {"entity": entity, "modifier": modifier, "accepted": false}
	EventBus.publish(&"StatModifierAddRequested", request)
	return request["accepted"]

func _remove_effect(entity: StringName, set_id: StringName, bonus_id: StringName, effect: Dictionary) -> void:
	if str(effect.get("target", "")) == "stat":
		EventBus.publish(&"StatModifierRemoveRequested", {"entity": entity, "id": _modifier_id(set_id, bonus_id)})
	EventBus.publish(&"SetBonusDeactivated", {"entity": entity, "set_id": set_id, "bonus": bonus_id, "effect": effect.duplicate(true)})

func _modifier_id(set_id: StringName, bonus_id: StringName) -> String:
	return "set:%s:%s" % [str(set_id).uri_encode(), str(bonus_id).uri_encode()]

func _equipment(entity: StringName) -> Dictionary:
	var query := {"entity": entity, "component": &"equipment", "found": false}
	EventBus.publish(&"ComponentGetRequested", query)
	if not query["found"]:
		# Реестр сущностей — источник истины о существовании владельца.
		var owner := {"entity": entity, "found": false}
		EventBus.publish(&"EntityGetRequested", owner)
		return {"ok": true, "items": []} if owner["found"] else {"ok": false, "error": "Сущность не найдена"}
	var ids: Array[StringName] = []
	if not _collect_ids(query["data"], ids, 0):
		return {"ok": false, "error": "Некорректные данные слотов"}
	var items: Array = []
	for id in ids:
		var item := {"item": id, "found": false}
		EventBus.publish(&"ItemGetRequested", item)
		if not item["found"]:
			return {"ok": false, "error": "Неизвестный экипированный предмет: %s" % id}
		items.append({"id": id, "instance": item["item_data"], "base": item["base"]})
	return {"ok": true, "items": items}

func _collect_ids(value: Variant, ids: Array[StringName], depth: int) -> bool:
	if depth > 32:
		return false
	if value == null:
		return true
	if value is String or value is StringName:
		var id := StringName(str(value))
		if id != &"" and not ids.has(id):
			ids.append(id)
		return id != &""
	if value is Dictionary:
		if value.has("id"):
			return _collect_ids(value["id"], ids, depth + 1)
		return _collect_ids(value.values(), ids, depth + 1)
	if value is Array:
		for child in value:
			if not _collect_ids(child, ids, depth + 1):
				return false
		return true
	return false

func _match_set(definition: Dictionary, set_id: StringName, equipped: Array) -> Dictionary:
	var concrete := 0
	var typed := 0
	var id_list: Array = definition.get("item_ids", [])
	var type_list: Array = definition.get("item_type_ids", [])
	var artifact_id = definition.get("required_artifact_id", null)
	var required_artifacts: Array[StringName] = []
	if artifact_id != null: required_artifacts.append(StringName(str(artifact_id)))
	# Определение может быть зарегистрировано раньше создания экземпляра.
	# Любой перечисленный экземпляр-артефакт данного сета обязателен.
	for id in id_list:
		var artifact_query := {"item":StringName(str(id)), "found":false}
		EventBus.publish(&"ItemGetRequested", artifact_query)
		if artifact_query["found"] and str(artifact_query["item_data"].get("rarity", "")) == "artifact" and str(artifact_query["item_data"].get("set_id", "")) == str(set_id):
			var required_id := StringName(str(id))
			if not required_artifacts.has(required_id): required_artifacts.append(required_id)
	var found_artifacts: Array[StringName] = []
	for item in equipped:
		var instance: Dictionary = item["instance"]
		# Артефакт, принадлежащий другому сету, не участвует во втором.
		if str(instance.get("rarity", "")) == "artifact" and str(instance.get("set_id", "")) != str(set_id):
			continue
		if required_artifacts.has(item["id"]) and str(instance.get("rarity", "")) == "artifact" and str(instance.get("set_id", "")) == str(set_id): found_artifacts.append(item["id"])
		var is_concrete := _contains_id(id_list, item["id"])
		var type_match := _contains_id(type_list, item["base"].get("item_type_id", ""))
		if str(definition["binding"]) == "item_id":
			if is_concrete:
				concrete += 1
			elif type_match:
				typed += 1
		elif type_match and str(instance.get("rarity", "")) in ["normal", "magic", "rare"]:
			typed += 1
	var total := concrete + typed
	var base_active := false
	if str(definition["binding"]) == "item_type":
		base_active = typed >= 3
	elif id_list.size() >= 3:
		base_active = concrete >= 3
		total = concrete
	else:
		base_active = concrete == id_list.size() and typed >= 1 and total >= 3
	var artifact_present := found_artifacts.size() == required_artifacts.size()
	base_active = base_active and artifact_present
	return {"base_active": base_active, "matching_pieces": total, "concrete_pieces": concrete, "type_pieces": typed, "required_artifact_present": artifact_present}

func _contains_id(list: Array, value: Variant) -> bool:
	if str(value).is_empty():
		return false
	for entry in list:
		if str(entry) == str(value):
			return true
	return false

func _snapshot_collect(event: Dictionary) -> void:
	if not _evaluating.is_empty():
		event["errors"].append("Нельзя сохранять во время пересчёта сета")
		return
	event["sections"]["sets"] = {"definitions": _definitions.duplicate(true), "active": _active.duplicate(true)}

func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["sets"]
	_definitions = data["definitions"].duplicate(true)
	_active = data["active"].duplicate(true)
