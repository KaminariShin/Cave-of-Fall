extends Node
## Общий контракт урона и зависимостей действий. Формулы оружия ещё не заданы.
var _dead: Dictionary = {}
var _watches: Dictionary = {} # actor -> {action, target}
var _minimum_damage := 0.0

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		_minimum_damage = float(rules["ruleset"].get("parameters", {}).get("combat", {}).get("damage_min", 0.0))
	EventBus.subscribe(&"CombatDamageRequested", _damage)
	EventBus.subscribe(&"CombatStartActionRequested", _start_action)
	EventBus.subscribe(&"CombatActionWatchRequested", _watch_action)
	EventBus.subscribe(&"CombatActionInvalidated", _invalidated)
	EventBus.subscribe(&"CombatEntityCanActRequested", _can_act)
	EventBus.subscribe(&"EntityDied", _on_entity_died)
	EventBus.subscribe(&"EntityRemoved", _on_entity_removed)
	EventBus.subscribe(&"ActionCompleted", _on_action_ended)
	EventBus.subscribe(&"ActionInterrupted", _on_action_ended)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)

## amount — входной урон до модификаторов, source может отсутствовать.
func _damage(event: Dictionary) -> void:
	event["accepted"] = false
	event.erase("stagger")
	var target: StringName = event.get("entity", &"")
	var source = event.get("source", null)
	var amount = event.get("amount", null)
	if target == &"" or _dead.has(target) or not _nonnegative(amount):
		return
	if source != null and not (source is String or source is StringName):
		return
	var allowed := {"entity": target, "allowed": true}
	EventBus.publish(&"CombatDamageAllowedRequested", allowed)
	if not allowed["allowed"]: return
	var hp := {"entity": target, "resource": &"HP", "found": false}
	EventBus.publish(&"ResourceGetRequested", hp)
	if not hp["found"]:
		return
	var old := float(hp["data"]["current"])
	if old <= 0.0:
		return
	var outgoing_value := float(amount)
	if not event.get("source_outgoing_precomputed", false):
		var outgoing := {"entity": StringName(str(source)) if source != null else &"", "target": "damage.outgoing", "base": outgoing_value, "accepted": false}
		EventBus.publish(&"PipelineEvaluateRequested", outgoing)
		if not outgoing["accepted"]:
			return
		outgoing_value = float(outgoing["value"])
	var damage: float = 0.0
	if event.get("resolved_periodic_damage", false) == true:
		# Периодический урон уже прошёл защиту и накопитель эффекта.
		if float(amount) != floorf(float(amount)) or float(amount) < 0.0: return
		damage = float(amount)
	else:
		var incoming := {"entity": target, "target": "damage.incoming", "base": maxf(_minimum_damage, outgoing_value), "accepted": false}
		EventBus.publish(&"PipelineEvaluateRequested", incoming)
		if not incoming["accepted"]:
			return
		damage = maxf(_minimum_damage, float(incoming["value"]))
		# Типизированный прямой физический урон использует актуальную броню.
		# Старые нетипизированные запросы остаются совместимыми; блок и
		# смешанное попадание ещё требуют отдельной боевой реализации.
		if event.get("damage_type", "") == "physical":
			var protection := {"entity":target, "damage_type":"physical", "percent":0.0}
			EventBus.publish(&"PeriodicProtectionGetRequested", protection)
			var percent = protection.get("percent", null)
			if not (percent is int or percent is float) or not is_finite(float(percent)):
				event["error"] = str(protection.get("protection_error", "Некорректная защита"))
				return
			damage = ceilf(maxf(0.0, damage * (1.0 - minf(75.0, float(protection["percent"])) / 100.0)))
		elif event.get("damage_type", "") == "magical":
			var protection := {"entity":target, "found":false}
			EventBus.publish(&"MagicalProtectionGetRequested",protection)
			if not protection.get("found",false) or not _nonnegative_or_negative_number(protection.get("percent",null)):
				event["error"] = str(protection.get("error", "Некорректная магическая защита"))
				return
			var units := roundi(float(protection["percent"]) * 100.0)
			var scaled := damage * float(10000 - units)
			var reduced := scaled / 10000.0 if is_finite(scaled) else damage * (float(10000 - units) / 10000.0)
			if not is_finite(reduced): event["error"] = "Переполнение магического урона"; return
			damage = ceilf(maxf(0.0, reduced))
	var change := {"entity": target, "resource": &"HP", "value": maxf(0.0, old - damage), "accepted": false}
	EventBus.publish(&"ResourceSetRequested", change)
	if not change["accepted"]:
		return
	var actual: float = old - float(change["value"])
	var lethal := old > 0.0 and float(change["value"]) <= 0.0
	if lethal:
		# До рассылки других уведомлений действие умершего больше не может стартовать.
		_dead[target] = true
	event["accepted"] = true
	event["applied"] = actual
	if actual > 0.0:
		EventBus.publish(&"EntityDamaged", {"entity": target, "source": source, "amount": actual})
	if lethal:
		EventBus.publish(&"EntityDied", {"entity": target, "killer": source})
	# Типизированное прямое и разрешённое периодическое попадание. Сумма
	# сравнивается до ограничения оставшимися HP, после защиты и округления.
	if event.get("resolved_periodic_damage",false) == true or event.get("damage_type","") in ["physical","magical"]:
		event["stagger"] = DirectDamageStaggerService.record(target,source,damage,hp["data"].get("max",null),lethal)

## Опциональная связка: после смерти цели действие отменяется как невозможное.
func _start_action(event: Dictionary) -> void:
	event["accepted"] = false
	var actor: StringName = event.get("entity", &"")
	var target: StringName = event.get("target", &"")
	var action: StringName = event.get("action", &"")
	if actor == &"" or target == &"" or _dead.has(actor) or _dead.has(target):
		return
	var target_query := {"entity": target, "found": false}
	EventBus.publish(&"EntityGetRequested", target_query)
	if not target_query["found"]:
		return
	# Специальная проверка готовности именно цели до запуска времени.
	var target_guard := {"entity":actor, "target":target, "action":action, "allowed":true, "reason":""}
	EventBus.publish(&"CombatTargetActionAllowedRequested", target_guard)
	if not target_guard.get("allowed", false):
		event["error"] = target_guard.get("reason", "Цель не готова к действию")
		return
	var request := {"entity": actor, "action": action, "duration": event.get("duration", -1.0), "accepted": false}
	EventBus.publish(&"ActionStartRequested", request)
	if not request["accepted"]:
		return
	var current := {"entity": actor, "found": false}
	EventBus.publish(&"ActionGetRequested", current)
	# Синхронные подписчики могли изменить состояние цели при старте.
	target_guard = {"entity":actor, "target":target, "action":action, "allowed":true, "reason":""}
	EventBus.publish(&"CombatTargetActionAllowedRequested", target_guard)
	if _dead.has(actor) or _dead.has(target) or not target_guard.get("allowed", false) or not current["found"] or current["data"]["id"] != action:
		if current["found"] and current["data"]["id"] == action:
			EventBus.publish(&"ActionCancelRequested", {"entity": actor, "reason": &"target_unavailable"})
		return
	_watches[actor] = {"target": target, "action": action}
	event["accepted"] = true

func _watch_action(event: Dictionary) -> void:
	event["accepted"] = false
	var actor: StringName = event.get("entity", &"")
	var target: StringName = event.get("target", &"")
	if actor == &"" or target == &"" or _dead.has(actor) or _dead.has(target):
		return
	var target_query := {"entity": target, "found": false}
	EventBus.publish(&"EntityGetRequested", target_query)
	var action := {"entity": actor, "found": false}
	EventBus.publish(&"ActionGetRequested", action)
	if not target_query["found"] or not action["found"]:
		return
	_watches[actor] = {"target": target, "action": action["data"]["id"]}
	event["accepted"] = true

func _invalidated(event: Dictionary) -> void:
	_cancel_watched(event.get("entity", &""), &"action_impossible")

# Read-only status used by the floor provenance cleanup.
func is_entity_dead(entity: StringName) -> bool:
	return _dead.has(entity)

func _can_act(event: Dictionary) -> void:
	event["allowed"] = not _dead.has(event.get("entity", &""))

func _on_entity_died(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if entity == &"":
		return
	_dead[entity] = true
	_cancel_dependents(entity)

func _on_entity_removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	_cancel_dependents(entity)
	_dead.erase(entity)
	_watches.erase(entity)

func _cancel_dependents(target: StringName) -> void:
	_watches.erase(target)
	for actor in _watches.keys():
		if _watches[actor]["target"] == target:
			_cancel_watched(actor, &"target_unavailable")

func _cancel_watched(actor: StringName, reason: StringName) -> void:
	if not _watches.has(actor):
		return
	var watched: Dictionary = _watches[actor]
	_watches.erase(actor)
	var action := {"entity": actor, "found": false}
	EventBus.publish(&"ActionGetRequested", action)
	if action["found"] and action["data"]["id"] == watched["action"]:
		EventBus.publish(&"ActionCancelRequested", {"entity": actor, "reason": reason})

func _on_action_ended(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if _watches.has(entity) and _watches[entity]["action"] == event.get("action", &""):
		_watches.erase(entity)

func _nonnegative(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0

func _snapshot_collect(event: Dictionary) -> void:
	event["sections"]["combat"] = {"dead": _dead.duplicate(true), "watches": _watches.duplicate(true)}
func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["combat"]
	_dead = data["dead"].duplicate(true)
	_watches = data["watches"].duplicate(true)

# Проставляем все смерти до первой публикации событий пакета.
func commit_simultaneous_deaths(ids: Array) -> void:
	if not SimultaneousDamageApplyService.authorizes_commit(): return
	for id in ids: _dead[id] = true

func _nonnegative_or_negative_number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v)) and float(v) <= 75.0 and absf(float(v)) <= 1000000000.0 and absf(float(v) * 100.0 - round(float(v) * 100.0)) <= 0.000001
