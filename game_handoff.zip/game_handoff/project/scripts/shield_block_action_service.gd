extends Node
## Состояние действия блока. Поглощение и геометрия сюда пока не подключены.
const ACTION := &"shield_block"
var _pending: Dictionary = {} # actor -> {item, slot, direction}
var _ending: Dictionary = {} # только внутри завершающего TimeDriver-шага
var _busy := false
var _launch: StringName = &""
var _launch_permit := false
func _ready() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION,"name":"Блок щитом","type":&"physical","base_duration":0.5,"interruptible":true}})
	EventBus.subscribe(&"ShieldBlockStartRequested", _start)
	EventBus.subscribe(&"ShieldBlockExtendRequested", _extend)
	EventBus.subscribe(&"ShieldBlockStatusRequested", _status)
	EventBus.subscribe(&"ActionStartAllowedRequested", _guard_start)
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested", _guard_ownership)
	EventBus.subscribe(&"ActionCompleted", _completed)
	EventBus.subscribe(&"ActionInterrupted", _interrupted)
	EventBus.subscribe(&"TimeStepSettled", _settled)
	EventBus.subscribe(&"EntityRemoved", _removed)
	EventBus.subscribe(&"EntityDied", _removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _restore)
	EventBus.subscribe(&"ShieldBlockSnapshotValidateRequested", _validate)
func _guard_start(e: Dictionary) -> void:
	if e.get("action",null) != ACTION: return
	if e.get("entity",null) != _launch or not _launch_permit: e["allowed"] = false
	else: _launch_permit = false
func _guard_ownership(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if actor is StringName and _pending.has(actor) and not CombatService.is_entity_dead(actor): e["allowed"] = false
func _valid_shield(actor: StringName, item: StringName, slot: String) -> bool:
	if CombatService.is_entity_dead(actor): return false
	var gear := {"entity":actor,"component":&"equipment","found":false}
	var q := {"item":item,"found":false}
	EventBus.publish(&"ComponentGetRequested",gear)
	EventBus.publish(&"ItemGetRequested",q)
	return gear.get("found",false) and gear.get("data",null) is Dictionary and gear["data"].get(slot,null) == item and q.get("found",false) and q.get("base",null) is Dictionary and q["base"].get("slot",null) == "shield"
func _start(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("error")
	var actor = e.get("entity",null)
	var slot = e.get("slot",null)
	var direction = e.get("direction",null)
	if _busy or not actor is StringName or actor == &"" or not slot is String or slot not in ["main","off"] or not ShieldBlockZoneService.valid_direction(direction) or _pending.has(actor):
		e["error"] = "Нужны свободный персонаж, рука щита и направление по стороне"; return
	_busy = true
	var gear := {"entity":actor,"component":&"equipment","found":false}
	EventBus.publish(&"ComponentGetRequested",gear)
	var item = gear.get("data",{}).get(slot,null)
	if not gear.get("found",false) or not item is StringName or item == &"" or not _valid_shield(actor,item,slot):
		_busy = false
		e["error"] = "В выбранной руке нет доступного щита"; return
	_pending[actor] = {"item":item,"slot":slot,"direction":direction}
	_launch = actor
	_launch_permit = true
	var start := {"entity":actor,"action":ACTION,"duration":0.5,"accepted":false}
	EventBus.publish(&"ActionStartRequested",start)
	_launch = &""
	_launch_permit = false
	var current := {"entity":actor,"found":false}
	EventBus.publish(&"ActionGetRequested",current)
	if not start.get("accepted",false) or not _pending.has(actor) or not current.get("found",false) or current["data"].get("id",null) != ACTION or not _valid_shield(actor,item,slot):
		if current.get("found",false) and current["data"].get("id",null) == ACTION: EventBus.publish(&"ActionCancelRequested", {"entity":actor,"reason":&"shield_unavailable"})
		_pending.erase(actor)
		_busy = false
		e["error"] = "Не удалось начать блок"; return
	_busy = false
	e["accepted"] = true
	EventBus.publish(&"ShieldBlockStarted", {"entity":actor,"item":item,"slot":slot,"direction":direction,"duration":0.5})
func _extend(e: Dictionary) -> void:
	e["accepted"] = false
	var actor = e.get("entity",null)
	if _busy or not actor is StringName or not _pending.has(actor) or _ending.has(actor): return
	var p: Dictionary = _pending[actor]
	if not _valid_shield(actor,p["item"],p["slot"]): return
	if not ActionRegistry.extend_shield_block(actor): return
	e["accepted"] = true
	EventBus.publish(&"ShieldBlockExtended", {"entity":actor,"duration":0.5})

func _status(e: Dictionary) -> void:
	e["active"] = false
	e.erase("item"); e.erase("slot"); e.erase("direction"); e.erase("ending")
	var actor = e.get("entity",null)
	if not actor is StringName or not _pending.has(actor): return
	var p: Dictionary = _pending[actor]
	if not _valid_shield(actor,p["item"],p["slot"]): return
	e["active"] = true
	e["item"] = p["item"]
	e["slot"] = p["slot"]
	e["direction"] = p["direction"]
	e["ending"] = _ending.has(actor)
func _completed(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null) != ACTION or not _pending.has(actor): return
	# Сохраняем доступность на завершающем шаге, в том числе после завершения NPC.
	if TimeDriver._stepping: _ending[actor] = true
	else: _finish_completed(actor)
func _settled(_e: Dictionary) -> void:
	for actor in _ending.keys(): _finish_completed(actor)
func _finish_completed(actor: StringName) -> void:
	if not _pending.has(actor): _ending.erase(actor); return
	var p: Dictionary = _pending[actor]
	_pending.erase(actor)
	_ending.erase(actor)
	EventBus.publish(&"ShieldBlockCompleted", {"entity":actor,"item":p["item"],"slot":p["slot"],"direction":p["direction"]})
# NPC завершает низкоуровневое действие до боевой фазы, но щит активен
# до конца шага. При нехватке ресурса завершаем именно как прерванный блок.
func interrupt_ending_from_batch(actor: StringName) -> bool:
	if not SimultaneousDamageApplyService.authorizes_phase_effects() or not _ending.has(actor) or not _pending.has(actor): return false
	var p: Dictionary = _pending[actor]
	_pending.erase(actor)
	_ending.erase(actor)
	EventBus.publish(&"ShieldBlockInterrupted", {"entity":actor,"item":p["item"],"slot":p["slot"],"direction":p["direction"],"reason":&"shield_exhausted"})
	return true
func _interrupted(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null) != ACTION or not _pending.has(actor): return
	var p: Dictionary = _pending[actor]
	_pending.erase(actor)
	_ending.erase(actor)
	EventBus.publish(&"ShieldBlockInterrupted", {"entity":actor,"item":p["item"],"slot":p["slot"],"direction":p["direction"],"reason":e.get("reason",&"cancelled")})
func _removed(e: Dictionary) -> void:
	_pending.erase(e.get("entity",null))
	_ending.erase(e.get("entity",null))
func _collect(e: Dictionary) -> void:
	if _busy or not _ending.is_empty(): e["errors"].append("Нельзя сохранять при изменении блока"); return
	e["sections"]["shield_block_actions"] = _pending.duplicate(true)
func _restore(e: Dictionary) -> void:
	_pending = e["sections"]["shield_block_actions"].duplicate(true)
	_ending.clear()
	_busy = false
	_launch = &""
	_launch_permit = false
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var s = e.get("sections",null)
	if not s is Dictionary or not s.get("shield_block_actions",null) is Dictionary or not s.get("entities",null) is Dictionary or not s.get("items",{}).get("instances",null) is Dictionary or not s.get("items",{}).get("bases",null) is Dictionary or not s.get("actions",{}).get("active",null) is Dictionary: return
	var pending: Dictionary = s["shield_block_actions"]
	var active: Dictionary = s["actions"]["active"]
	for actor in pending:
		var p = pending[actor]
		if not actor is StringName or actor == &"" or not s["entities"].has(actor) or not s["entities"][actor] is Dictionary or not p is Dictionary or p.size() != 3 or not ShieldBlockZoneService.valid_direction(p.get("direction",null)) or not p.get("item",null) is StringName or p["item"] == &"" or not p.get("slot",null) is String or p["slot"] not in ["main","off"]: return
		var slots = s["entities"][actor].get(&"equipment",null)
		if not slots is Dictionary or slots.get(p["slot"],null) != p["item"] or not s["items"]["instances"].has(p["item"]): return
		var item = s["items"]["instances"][p["item"]]
		if not item is Dictionary or not s["items"]["bases"].has(item.get("base_id",null)): return
		var base = s["items"]["bases"][item["base_id"]]
		if not base is Dictionary or base.get("slot",null) != "shield": return
		if not active.has(actor) or not active[actor] is Dictionary or active[actor].get("id",null) != ACTION or (not active[actor].get("steps",null) is int or active[actor]["steps"] < 50 or active[actor]["steps"] % 50 != 0) or s.get("combat",{}).get("dead",{}).has(actor): return
	for actor in active:
		if active[actor] is Dictionary and active[actor].get("id",null) == ACTION and not pending.has(actor): return
	e["valid"] = true
