extends Node
## Data-only weapon hierarchy; combat calculations belong to later fragments.
var _types: Dictionary = {}
var _tags: Dictionary = {}
var _variants: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"WeaponTypeRegisterRequested", _type_register)
	EventBus.subscribe(&"WeaponTagRegisterRequested", _tag_register)
	EventBus.subscribe(&"WeaponVariantRegisterRequested", _variant_register)
	EventBus.subscribe(&"WeaponVariantResolveRequested", _resolve)
	EventBus.subscribe(&"WeaponTypeGetRequested", _get_type)
	EventBus.subscribe(&"WeaponTagGetRequested", _get_tag)
	EventBus.subscribe(&"WeaponItemResolveRequested", _resolve_item)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"WeaponSnapshotValidateRequested", _validate_snapshot)
	var req := {"found":false}
	EventBus.publish(&"RulesetGetRequested", req)
	if req["found"]:
		var tables: Dictionary = req["ruleset"].get("tables", {})
		for item in tables.get("weapon_types", []): _type_register({"definition":item})
		for item in tables.get("weapon_tags", []): _tag_register({"definition":item})
		for item in tables.get("weapon_variants", []): _variant_register({"definition":item})

func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v))
func _valid_id(v: Variant) -> bool:
	return (v is String or v is StringName) and not str(v).is_empty()
func _valid_type(d: Variant) -> bool:
	return d is Dictionary and _valid_id(d.get("id", null)) and _number(d.get("base_attack_time", null)) and float(d["base_attack_time"]) > 0 and _number(d.get("min_percent", null)) and float(d["min_percent"]) >= 0
func _valid_tag(d: Variant) -> bool:
	if not d is Dictionary or not _valid_id(d.get("id", null)): return false
	for key in ["min_time_bonus", "stamina_cost_percent"]:
		if d.has(key) and not _number(d[key]): return false
	return true
func _valid_variant(d: Variant, types: Dictionary, tags: Dictionary) -> bool:
	if not d is Dictionary or not _valid_id(d.get("id", null)) or not _valid_id(d.get("type", null)) or not types.has(str(d["type"])) or not d.get("tags", null) is Array: return false
	var seen := {}
	for tag in d["tags"]:
		if not _valid_id(tag) or not tags.has(str(tag)) or seen.has(str(tag)): return false
		seen[str(tag)] = true
	if d.has("base_stamina_cost") and (not _number(d["base_stamina_cost"]) or float(d["base_stamina_cost"]) < 0): return false
	if d.has("base_attack_time") and (not _number(d["base_attack_time"]) or float(d["base_attack_time"]) <= 0): return false
	if d.has("min_percent") and (not _number(d["min_percent"]) or float(d["min_percent"]) < 0): return false
	return true
func _type_register(e: Dictionary) -> void:
	e["accepted"] = false
	var d = e.get("definition", null)
	if not _valid_type(d) or _types.has(str(d["id"])): return
	_types[str(d["id"])] = d.duplicate(true)
	e["accepted"] = true
func _tag_register(e: Dictionary) -> void:
	e["accepted"] = false
	var d = e.get("definition", null)
	if not _valid_tag(d) or _tags.has(str(d["id"])): return
	_tags[str(d["id"])] = d.duplicate(true)
	e["accepted"] = true
func _variant_register(e: Dictionary) -> void:
	e["accepted"] = false
	var d = e.get("definition", null)
	if not _valid_variant(d, _types, _tags) or _variants.has(str(d["id"])): return
	_variants[str(d["id"])] = d.duplicate(true)
	e["accepted"] = true
func _get_type(e: Dictionary) -> void:
	var id := str(e.get("id", ""))
	e["found"] = _types.has(id)
	if e["found"]: e["data"] = _types[id].duplicate(true)
func _get_tag(e: Dictionary) -> void:
	var id := str(e.get("id", ""))
	e["found"] = _tags.has(id)
	if e["found"]: e["data"] = _tags[id].duplicate(true)
func _resolve(e: Dictionary) -> void:
	e["found"] = false
	var id := str(e.get("variant", ""))
	if not _variants.has(id): return
	var d: Dictionary = _variants[id]
	var t: Dictionary = _types[str(d["type"])]
	var bonus := 0.0
	var stamina := 0.0
	var stamina_complete := true
	for tag in d["tags"]:
		if not _tags[str(tag)].has("stamina_cost_percent"): stamina_complete = false
		bonus += float(_tags[str(tag)].get("min_time_bonus", 0.0))
		stamina += float(_tags[str(tag)].get("stamina_cost_percent", 0.0))
	if not is_finite(bonus) or not is_finite(stamina): return
	e["data"] = {"id":id, "type":str(d["type"]), "tags":d["tags"].duplicate(), "base_attack_time":float(d.get("base_attack_time", t["base_attack_time"])), "min_percent":float(d.get("min_percent", t["min_percent"])), "min_time_bonus":bonus, "stamina_cost_percent":stamina, "stamina_cost_complete":stamina_complete}
	if d.has("base_stamina_cost"): e["data"]["base_stamina_cost"] = float(d["base_stamina_cost"])
	e["found"] = true
func _resolve_item(e: Dictionary) -> void:
	e["found"] = false
	var item := {"item":e.get("item", &""), "found":false}
	EventBus.publish(&"ItemGetRequested", item)
	if not item["found"]: return
	var resolve := {"variant":item["base"].get("weapon_variant", ""), "found":false}
	_resolve(resolve)
	if resolve["found"]:
		e["found"] = true
		e["data"] = resolve["data"]
func _collect(e: Dictionary) -> void:
	e["sections"]["weapons"] = {"types":_types.duplicate(true), "tags":_tags.duplicate(true), "variants":_variants.duplicate(true)}
func _apply(e: Dictionary) -> void:
	var d: Dictionary = e["sections"]["weapons"]
	_types = d["types"].duplicate(true)
	_tags = d["tags"].duplicate(true)
	_variants = d["variants"].duplicate(true)
func _validate_snapshot(e: Dictionary) -> void:
	e["valid"] = false
	var d = e.get("sections", {}).get("weapons", null)
	if not d is Dictionary or not d.get("types", null) is Dictionary or not d.get("tags", null) is Dictionary or not d.get("variants", null) is Dictionary: return
	for id in d["types"]:
		if not id is String or not _valid_type(d["types"][id]) or str(d["types"][id]["id"]) != id: return
	for id in d["tags"]:
		if not id is String or not _valid_tag(d["tags"][id]) or str(d["tags"][id]["id"]) != id: return
	for id in d["variants"]:
		if not id is String or not _valid_variant(d["variants"][id], d["types"], d["tags"]) or str(d["variants"][id]["id"]) != id: return
	e["valid"] = true
