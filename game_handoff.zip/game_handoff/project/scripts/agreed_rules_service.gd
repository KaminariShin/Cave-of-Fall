extends Node
## Чистые расчёты согласованных правил. Не запускают бой, эффекты или генерацию.

func _ready() -> void:
	EventBus.subscribe(&"DungeonDepthCalculateRequested", _depth)
	EventBus.subscribe(&"PeriodicDurationCalculateRequested", _periodic_duration)
	EventBus.subscribe(&"ArmourProtectionCalculateRequested", _armour)

func _numeric(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v))

func _depth(e: Dictionary) -> void:
	e["accepted"] = false
	var floor_no = e.get("floor", null)
	var distance = e.get("distance", null)
	if not floor_no is int or floor_no < 1 or floor_no > 4 or not distance is int or distance < 0:
		e["error"] = "Этаж должен быть от 1 до 4, удалённость — неотрицательным целым"
		return
	var depth: float = float(floor_no) + float(distance) / 5.0
	e["depth"] = depth
	e["enemy_level"] = 1 + floori(depth / 3.0)
	e["accepted"] = true

func _periodic_duration(e: Dictionary) -> void:
	e["accepted"] = false
	var base = e.get("base_duration", null)
	var con = e.get("CON", null)
	if not _numeric(base) or float(base) <= 0.0 or not _numeric(con):
		e["error"] = "Нужны положительная базовая длительность и конечный CON"
		return
	var denominator := 1.0 + (float(con) - 5.0) / 50.0
	if denominator <= 0.0 or not is_finite(denominator):
		e["error"] = "Недопустимый знаменатель формулы CON"
		return
	var raw: float = float(base) / denominator
	if not is_finite(raw) or raw > 10000000.0:
		e["error"] = "Недопустимая длительность"
		return
	var half_ticks := maxi(1, floori(raw / 0.5 + 0.5 + 0.000000001))
	e["duration"] = half_ticks * 0.5
	e["raw_duration"] = raw
	e["accepted"] = true

func _armour(e: Dictionary) -> void:
	e["accepted"] = false
	var armour = e.get("armour", null)
	var other = e.get("percent_sources", [])
	if not _numeric(armour) or float(armour) < 0.0 or not other is Array:
		e["error"] = "Требуются неотрицательная броня и массив процентных источников"
		return
	var a: float = float(armour)
	var value := _round_away(100.0 * (a / (a + 100.0)))
	for source in other:
		if not _numeric(source):
			e["error"] = "Некорректный процентный источник"
			return
		value += _round_away(float(source))
	if not is_finite(value): return
	e["percent"] = minf(75.0, snappedf(value, 0.01))
	e["accepted"] = true

func _round_away(value: float) -> float:
	if value == 0.0: return 0.0
	return signf(value) * ceil(absf(value) * 100.0 - 0.000000001) / 100.0
