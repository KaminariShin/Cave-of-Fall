extends Node
## При входе в выбранную комнату босса обращается к обычному SpawnService.
var _busy := false
var _restore_generation := 0

func _ready() -> void:
	EventBus.subscribe(&"PlayerRoomChanged", _room_changed)
	EventBus.subscribe(&"DungeonBossAutoSpawnRetryRequested", _retry)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotRestored", _restored)
	EventBus.subscribe(&"SpaceMapConfigured", _map_changed)

func _room_changed(e: Dictionary) -> void:
	if _busy: return
	var actor = e.get("entity", null)
	var room = e.get("room", null)
	if not actor is StringName or not room is StringName: return
	var tracking := {"found":false}
	EventBus.publish(&"DungeonFloorTrackingGetRequested", tracking)
	if not tracking.get("found", false) or tracking["data"].get("floor", 0) != 4 or tracking["data"].get("boss_candidate", null) != room: return
	_attempt(actor, room)

func _retry(e: Dictionary) -> void:
	e["accepted"] = false
	if _busy: return
	var current := {}
	EventBus.publish(&"RoomCurrentGetRequested", current)
	var actor = e.get("entity", null)
	if not actor is StringName or actor == &"" or current.get("entity", null) != actor or not current.get("room", null) is StringName or current["room"] == &"":
		e["error"] = "Игрок не находится в комнате босса"; return
	var result := _attempt(actor, current["room"])
	e.merge(result, true)

func _attempt(actor: StringName, room: StringName) -> Dictionary:
	if _busy: return {"accepted":false, "error":"Спавн уже выполняется"}
	_busy = true
	var result := _run(actor, room)
	if not result.get("accepted", false):
		EventBus.publish(&"DungeonBossAutoSpawnFailed", {"entity":actor, "room":room, "error":result.get("error", "Спавн не выполнен")})
	_busy = false
	return result

func _context(actor: StringName, room: StringName) -> Dictionary:
	var tracking := {"found":false}
	var current := {}
	var mode := {}
	var body := {"entity":actor, "found":false}
	var info := {"id":room, "found":false}
	EventBus.publish(&"DungeonFloorTrackingGetRequested", tracking)
	EventBus.publish(&"RoomCurrentGetRequested", current)
	EventBus.publish(&"GameModeGetRequested", mode)
	EventBus.publish(&"SpaceBodyGetRequested", body)
	EventBus.publish(&"RoomGetRequested", info)
	if not tracking.get("found", false) or tracking["data"].get("floor", 0) != 4 or tracking["data"].get("boss_candidate", null) != room or current.get("entity", null) != actor or current.get("room", null) != room or current.get("transitioning", true) or mode.get("entity", null) != actor or CombatService.is_entity_dead(actor) or not body.get("found", false) or not info.get("found", false): return {}
	var rect := Rect2i(info["data"]["origin_cell"] * 4, info["data"]["size_cells"] * 4)
	var body_rect := Rect2i(body["data"]["anchor"], Vector2i.ONE * body["data"]["size"])
	if not rect.encloses(body_rect): return {}
	return {"entry":body["data"]["anchor"]}

func _run(actor: StringName, room: StringName) -> Dictionary:
	var context := _context(actor, room)
	if context.is_empty(): return {"accepted":false, "error":"Игрок или выбранная комната изменились"}
	var status := {"room":room}
	EventBus.publish(&"RoomSpawnStatusRequested", status)
	if status.get("spawned", false):
		var boss := {"found":false}
		EventBus.publish(&"DungeonBossGetRequested", boss)
		if boss.get("found", false) and boss["data"].get("room", null) == room: return {"accepted":true, "already_spawned":true}
		return {"accepted":false, "error":"Спавн комнаты зафиксирован без подтверждённого босса"}
	var depth := {"room":room, "accepted":false}
	EventBus.publish(&"DungeonRoomDepthRequested", depth)
	if not depth.get("accepted", false): return {"accepted":false, "error":"Не удалось определить глубину комнаты босса"}
	var provider := {"room":room, "depth":depth["depth"], "accepted":false}
	EventBus.publish(&"DungeonBossSpawnPoolRequested", provider)
	var pool: Variant = null
	if provider.get("accepted", false):
		pool = provider.get("pool", null)
	else:
		if not SpawnService.boss_uses_full_random_budget(float(depth["depth"])): return {"accepted":false, "error":"Не задан пул обычных противников"}
		pool = []
	if not pool is Array: return {"accepted":false, "error":"Некорректный пул обычных противников"}
	var current := _context(actor, room)
	if current.is_empty() or current != context: return {"accepted":false, "error":"Положение игрока изменилось при подготовке"}
	var request := {"room":room, "player":actor, "entry_tile":context["entry"], "depth":depth["depth"], "pool":pool.duplicate(true), "accepted":false}
	if provider.has("queue_delay"): request["queue_delay"] = provider["queue_delay"]
	EventBus.publish(&"RoomSpawnRequested", request)
	if not request.get("accepted", false): return {"accepted":false, "error":request.get("error", "Спавн босса не выполнен")}
	return {"accepted":true, "already_spawned":false, "units":request["units"].duplicate(true)}

func _collect(e: Dictionary) -> void:
	if _busy: e["errors"].append("Нельзя сохранять во время автоматического спавна босса")

# Отложенный повтор после восстановления: не выполняется внутри применения снимка.
# Каждое восстановление и смена карты инвалидируют старую задачу.
func _map_changed(_e: Dictionary) -> void:
	_restore_generation += 1

func _restored(_e: Dictionary) -> void:
	if _busy: return # откат собственной транзакции не запускает цикл повторов
	_restore_generation += 1
	call_deferred("_retry_restored", _restore_generation)

func _retry_restored(generation: int) -> void:
	if generation != _restore_generation or _busy: return
	var current := {}
	EventBus.publish(&"RoomCurrentGetRequested", current)
	var actor = current.get("entity", null)
	var room = current.get("room", null)
	if not actor is StringName or actor == &"" or not room is StringName or room == &"": return
	if _context(actor, room).is_empty(): return
	var status := {"room":room}
	EventBus.publish(&"RoomSpawnStatusRequested", status)
	if status.get("spawned", false): return
	_attempt(actor, room)
