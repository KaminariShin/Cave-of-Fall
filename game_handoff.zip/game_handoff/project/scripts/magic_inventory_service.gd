extends Node
## Собирает бонусы только с надетых колец, амулетов и плащей.
var _active: Dictionary = {} # entity -> modifier_id -> volume_bonus
var _evaluating: Dictionary = {}
var _pending: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"EntityCreated", _entity_created)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"ComponentChanged", _component_changed)
	EventBus.subscribe(&"ComponentRemoved", _component_changed)
	EventBus.subscribe(&"ItemModAttached", _item_mod_attached)
	EventBus.subscribe(&"MagicInventoryGetRequested", _get_modifiers)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)

func _entity_created(event: Dictionary) -> void:
	_recalculate(event.get("entity", &""))

func _entity_removed(event: Dictionary) -> void:
	_active.erase(event.get("entity", &""))

func _component_changed(event: Dictionary) -> void:
	if event.get("component", &"") == &"equipment":
		_recalculate(event.get("entity", &""))

func _item_mod_attached(event: Dictionary) -> void:
	if str(event.get("mod", {}).get("kind", "")) != "magic_inventory":
		return
	var query := {"components": [&"equipment"], "entities": []}
	EventBus.publish(&"EntityQueryRequested", query)
	for entity in query["entities"]:
		_recalculate(entity)

func _get_modifiers(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	event["modifiers"] = _active.get(entity, {}).duplicate(true)

func _recalculate(entity: StringName) -> void:
	if _evaluating.has(entity):
		_pending[entity] = true
		return
	_evaluating[entity] = true
	_recalculate_once(entity)
	while _pending.has(entity):
		_pending.erase(entity)
		_recalculate_once(entity)
	_evaluating.erase(entity)

func _recalculate_once(entity: StringName) -> void:
	var desired := {}
	var equipment := {"entity": entity, "component": &"equipment", "found": false}
	EventBus.publish(&"ComponentGetRequested", equipment)
	var ids: Array[StringName] = []
	var error := ""
	if equipment["found"] and not _collect_ids(equipment["data"], ids, 0):
		error = "Некорректная структура экипировки"
	if error.is_empty():
		for item_id in ids:
			var query := {"item": item_id, "found": false}
			EventBus.publish(&"ItemGetRequested", query)
			if not query["found"]:
				error = "Неизвестный экипированный предмет: %s" % item_id
				break
			var slot := str(query["base"].get("slot", ""))
			if slot not in ["ring", "amulet", "cloak"]:
				continue
			var mods: Array = query["item_data"].get("mods", [])
			for index in range(mods.size()):
				var mod: Dictionary = mods[index]
				if str(mod.get("kind", "")) != "magic_inventory" or slot not in mod.get("allowed_slots", []):
					continue
				var volume = mod.get("volume_bonus", null)
				if not (volume is int or volume is float) or not is_finite(float(volume)) or float(volume) < 0.0:
					error = "Некорректный бонус объёма"
					break
				desired[_modifier_id(item_id, index)] = float(volume)
			if not error.is_empty():
				break
	if not error.is_empty():
		desired.clear()
		EventBus.publish(&"MagicInventoryEvaluationFailed", {"entity": entity, "error": error})
	var current: Dictionary = _active.get(entity, {})
	_active[entity] = current
	for id in current.keys():
		if not desired.has(id) or desired[id] != current[id]:
			current.erase(id)
			EventBus.publish(&"InventoryVolumeModifierRemoveRequested", {"entity": entity, "id": id})
	for id in desired:
		if current.has(id):
			continue
		var add := {"entity": entity, "modifier": {"id": id, "op": "add", "value": desired[id]}, "accepted": false}
		EventBus.publish(&"InventoryVolumeModifierAddRequested", add)
		if add["accepted"]:
			current[id] = desired[id]
		else:
			EventBus.publish(&"MagicInventoryModifierFailed", {"entity": entity, "modifier": id})
	if current.is_empty():
		_active.erase(entity)

func _collect_ids(value: Variant, ids: Array[StringName], depth: int) -> bool:
	if depth > 32:
		return false
	if value == null:
		return true
	if value is String or value is StringName:
		var id := StringName(str(value))
		if id == &"":
			return false
		if not ids.has(id):
			ids.append(id)
		return true
	if value is Dictionary:
		if value.has("id"):
			return _collect_ids(value["id"], ids, depth + 1)
		return _collect_ids(value.values(), ids, depth + 1)
	if value is Array:
		for child in value:
			if not _collect_ids(child, ids, depth + 1):
				return false
		return true
	return false

func _modifier_id(item_id: StringName, index: int) -> String:
	return "magic_inventory:%s:%d" % [str(item_id).uri_encode(), index]

func _snapshot_collect(event: Dictionary) -> void:
	if not _evaluating.is_empty():
		event["errors"].append("Нельзя сохранять во время пересчёта магического инвентаря")
		return
	event["sections"]["magic_inventory"] = {"active": _active.duplicate(true)}

func _snapshot_apply(event: Dictionary) -> void:
	_active = event["sections"]["magic_inventory"]["active"].duplicate(true)
