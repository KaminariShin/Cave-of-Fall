extends Node
## Ручное применение уже посчитанного попадания вне игрового шага.
## Не заменяет общую фазу одновременного боя.
var _busy := false
func _ready() -> void:
	EventBus.subscribe(&"StaggerApplyRequested",_apply)
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
func _collect(e: Dictionary) -> void:
	if _busy: e["errors"].append("Нельзя сохранять во время применения пошатывания")
func _apply(e: Dictionary) -> void:
	_apply_core(e,false,false,false)
func apply_from_simultaneous(e: Dictionary) -> void:
	_apply_core(e,true,false,false)
func apply_from_phase(e: Dictionary) -> void:
	_apply_core(e,false,true,false)
func apply_from_direct_phase(e: Dictionary) -> void:
	_apply_core(e,false,false,true)
func _apply_core(e: Dictionary, from_batch: bool, from_phase: bool, from_direct_phase: bool) -> void:
	e["accepted"] = false
	for key in ["error","data"]: e.erase(key)
	if _busy or TimeDriver._stepping or (TimeDriver._settling and not ((from_phase and PhaseStaggerService.authorized()) or (from_direct_phase and DirectDamageStaggerService.authorized()))) or (from_phase and not PhaseStaggerService.authorized()) or (from_direct_phase and not DirectDamageStaggerService.authorized()) or SaveService._transition_busy or (SimultaneousDamageApplyService._busy and not (from_batch and SimultaneousDamageApplyService.authorizes_stagger())) or (from_batch and not SimultaneousDamageApplyService.authorizes_stagger()):
		e["error"] = "Пошатывание недоступно в этой фазе"; return
	var target = e.get("target",null)
	var damage = e.get("damage",null)
	var expected = e.get("expected_max_hp",null)
	if not target is StringName or target == &"" or not damage is int or damage < 0 or damage > StaggerPlanService.MAX_VALUE or not expected is int or expected < 1 or expected > StaggerPlanService.MAX_VALUE:
		e["error"] = "Нужны цель, целый итоговый урон и ожидаемый максимум HP"; return
	if not EntityRegistry.has_entity(target) or CombatService.is_entity_dead(target) or not EntityRegistry.has_component(target,&"resources"):
		e["error"] = "Цель недоступна"; return
	var resources: Dictionary = EntityRegistry.get_component(target,&"resources")
	var hp = resources.get(&"HP",null)
	if not hp is Dictionary or not (hp.get("max",null) is int or hp.get("max",null) is float) or not is_finite(float(hp["max"])) or float(hp["max"]) != float(expected) or not (hp.get("current",null) is int or hp.get("current",null) is float) or not is_finite(float(hp["current"])) or float(hp["current"]) <= 0:
		e["error"] = "HP цели недоступны или максимум изменился"; return
	if damage * 4 < expected:
		e["accepted"] = true
		e["data"] = {"triggered":false,"applied":false,"reason":"below_threshold"}
		return
	var active := ActionRegistry.get_active_action(target)
	if not active.is_empty() and not active.get("interruptible",false):
		e["accepted"] = true
		e["data"] = {"triggered":true,"applied":false,"reason":"uninterruptible"}
		return
	_busy = true
	TimeDriver._allow_stagger_start = from_phase or from_direct_phase
	var applied: bool = ActionRegistry.start_action(target,&"stagger",0.2) if active.is_empty() else ActionRegistry.interrupt_with(target,&"stagger",0.2)
	TimeDriver._allow_stagger_start = false
	if not applied:
		_busy = false
		e["error"] = "Не удалось начать или обновить пошатывание"; return
	e["accepted"] = true
	e["data"] = {"triggered":true,"applied":true,"refreshed":active.get("id",null) == &"stagger","previous_action":active.get("id",null),"duration":0.2}
	EventBus.publish(&"StaggerApplied", {"target":target,"damage":damage,"max_hp":expected,"refreshed":e["data"]["refreshed"]})
	_busy = false
