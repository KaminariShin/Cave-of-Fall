extends Node
## Детерминированное восприятие по шагам игрового времени; фракции задаются явно.
var _seen: Dictionary = {}      # observer -> {target: reason}
var _hostile: Dictionary = {}   # симметричное отношение
var _noises: Dictionary = {}    # process id -> {source, position, radius, kind}
var _forced: Dictionary = {}    # observer -> {source: expiry_step}
var _radii: Dictionary = {}
var _controlled: StringName = &""
var _hotbar: Array = []
var _step := 0
var _sequence := 0
var _radius_unit := 1.0
var _force_hold_steps := 1
var _noise_rules: Dictionary = {}
var _refreshing := false
var _updating_hotbar := false
var _hotbar_dirty := false
var _noise_transition_busy := false
var _noise_transition_ids: Dictionary = {}
var _noise_callback_depth := 0

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var data: Dictionary = rules["ruleset"].get("parameters", {}).get("detection", {})
		_radius_unit = float(data.get("radius_unit_in_tiles", 1.0))
		_force_hold_steps = maxi(1, int(data.get("force_hold_steps", 1)))
		_noise_rules = data.get("noise", {}).duplicate(true)
	EventBus.subscribe(&"DetectionHostilitySetRequested", _hostility_set)
	EventBus.subscribe(&"DetectionPairGetRequested", _pair_get)
	EventBus.subscribe(&"DetectionStateGetRequested", _state_get)
	EventBus.subscribe(&"HotbarGetRequested", _hotbar_get)
	EventBus.subscribe(&"NoiseEmitRequested", _noise_requested)
	EventBus.subscribe(&"DetectionDirectedActionRequested", _directed_action)
	EventBus.subscribe(&"EntityCreated", _entity_created)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"EntityDied", _entity_died)
	EventBus.subscribe(&"SpaceBodyRemoved", _body_removed)
	EventBus.subscribe(&"StatChanged", _stat_changed)
	EventBus.subscribe(&"ControlledEntityRequested", _controlled_changed)
	EventBus.subscribe(&"PlayerRoomChanged", _room_changed)
	EventBus.subscribe(&"AIRegistered", _ai_registered)
	EventBus.subscribe(&"TimeStepStarted", _time_started)
	EventBus.subscribe(&"Tick", _tick)
	EventBus.subscribe(&"ProcessCompleted", _process_ended)
	EventBus.subscribe(&"ProcessInterrupted", _process_ended)
	EventBus.subscribe(&"CombatStartActionRequested", _combat_start)
	EventBus.subscribe(&"ProjectileLaunchRequested", _projectile_launch)
	EventBus.subscribe(&"ProjectileExplosion", _projectile_explosion)
	EventBus.subscribe(&"RatBiteResolved", _rat_bite)
	EventBus.subscribe(&"StrikeZoneDamageRequested", _strike)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"SnapshotRestored", _snapshot_restored)
	EventBus.subscribe(&"ProcessStartAllowedRequested", _noise_process_guard)
	EventBus.subscribe(&"SpawnMapReconfigureCheckRequested", _noise_map_guard)

func _entity_created(event: Dictionary) -> void:
	_update_radius(event.get("entity", &""))
func _stat_changed(event: Dictionary) -> void:
	if event.get("stat", &"") == &"PER":
		_update_radius(event.get("entity", &""))
func _update_radius(entity: StringName) -> void:
	if entity == &"":
		return
	var stat := {"entity": entity, "stat": &"PER", "found": false}
	EventBus.publish(&"StatGetRequested", stat)
	if not stat["found"] or not is_finite(float(stat["value"])) or not is_finite(_radius_unit) or _radius_unit < 0:
		return
	var radius := maxf(0.0, float(stat["value"]) * _radius_unit)
	if not is_finite(radius):
		return
	if not _radii.has(entity) or _radii[entity] != radius:
		_radii[entity] = radius
		EventBus.publish(&"DetectionRadiusChanged", {"entity": entity, "radius": radius})

func _controlled_changed(event: Dictionary) -> void:
	if event.get("accepted", false):
		var next_controlled: StringName = event.get("entity", &"")
		if next_controlled != _controlled:
			var previous := _controlled
			for other in _hotbar:
				EventBus.publish(&"MutualDetectionChanged", {"entity": previous, "other": other, "detected": false})
			if not _hotbar.is_empty():
				EventBus.publish(&"HotbarChanged", {"entity": previous, "hostiles": []})
				EventBus.publish(&"CombatDetectionChanged", {"entity": previous, "active": false, "hostiles": []})
			_hotbar = []
			_controlled = next_controlled
			_update_hotbar()
func _room_changed(_event: Dictionary) -> void:
	# Заново оцениваем при входе; выключенные наблюдатели теряют актуальное восприятие.
	_refresh()
	EventBus.publish(&"DetectionRoomRefreshFinished", {})
func _time_started(event: Dictionary) -> void:
	_step = int(round(float(event["game_time"]) / 0.01))
func _tick(_event: Dictionary) -> void:
	_cleanup_forced()
	_refresh()

func _hostility_set(event: Dictionary) -> void:
	event["accepted"] = false
	var a: StringName = event.get("a", &"")
	var b: StringName = event.get("b", &"")
	var hostile = event.get("hostile", null)
	if a == &"" or b == &"" or a == b or not hostile is bool or not _entity_exists(a) or not _entity_exists(b):
		return
	_set_relation(a, b, hostile)
	_set_relation(b, a, hostile)
	event["accepted"] = true
	_sync_ai(a, b, hostile and _is_seen(a, b))
	_sync_ai(b, a, hostile and _is_seen(b, a))
	_update_hotbar()
	EventBus.publish(&"HostilityChanged", {"a": a, "b": b, "hostile": hostile})
func _set_relation(a: StringName, b: StringName, value: bool) -> void:
	if value:
		if not _hostile.has(a): _hostile[a] = {}
		_hostile[a][b] = true
	elif _hostile.has(a):
		_hostile[a].erase(b)
		if _hostile[a].is_empty(): _hostile.erase(a)
func _is_hostile(a: StringName, b: StringName) -> bool:
	return _hostile.has(a) and _hostile[a].has(b)
func _is_seen(observer: StringName, target: StringName) -> bool:
	return _seen.has(observer) and _seen[observer].has(target)
func _pair_get(event: Dictionary) -> void:
	var observer: StringName = event.get("observer", &"")
	var target: StringName = event.get("target", &"")
	event["detected"] = _is_seen(observer, target)
	event["hostile"] = _is_hostile(observer, target)
	if event["detected"]:
		event["reason"] = _seen[observer][target]
func _state_get(event: Dictionary) -> void:
	var observer: StringName = event.get("observer", &"")
	event["detected"] = _seen.get(observer, {}).duplicate(true)
	event["radius_known"] = _radii.has(observer)
	if event["radius_known"]: event["radius"] = _radii[observer]
func _hotbar_get(event: Dictionary) -> void:
	event["entity"] = _controlled
	event["hostiles"] = _hotbar.duplicate()
	event["combat_detected"] = not _hotbar.is_empty()

func _refresh() -> void:
	if _refreshing:
		return
	_refreshing = true
	var bodies := _body_snapshot()
	var ids: Array = bodies.keys()
	ids.sort_custom(func(a, b): return str(a) < str(b))
	var next: Dictionary = {}
	for observer in ids:
		if not _alive(observer) or not _tick_allowed(observer):
			continue
		if not _radii.has(observer): _update_radius(observer)
		if not _radii.has(observer): continue
		for target in ids:
			if observer == target or not _alive(target):
				continue
			var reason := _reason(observer, target, bodies)
			if not reason.is_empty():
				if not next.has(observer): next[observer] = {}
				next[observer][target] = reason
	var old := _seen
	_seen = next
	for observer in old.keys():
		for target in old[observer].keys():
			if not _is_seen(observer, target):
				_emit_lost(observer, target)
	for observer in next.keys():
		if not next.has(observer): continue
		for target in next[observer].keys():
			if not old.has(observer) or not old[observer].has(target):
				if _is_seen(observer, target): _emit_detected(observer, target, next[observer][target])
	_refreshing = false
	_update_hotbar()

func _reason(observer: StringName, target: StringName, bodies: Dictionary) -> String:
	if _forced.has(observer) and int(_forced[observer].get(target, -1)) >= _step:
		return "forced"
	var observer_center: Vector2 = bodies[observer]["center"]
	for noise in _noises.values():
		if noise["source"] == target and observer_center.distance_to(noise["position"]) <= float(noise["radius"]):
			return "noise"
	var target_center: Vector2 = bodies[target]["center"]
	if observer_center.distance_to(target_center) > float(_radii[observer]) + 0.000001:
		return ""
	var los := {"from": _tile(observer_center), "to": _tile(target_center), "accepted": false}
	EventBus.publish(&"SpaceLineOfSightRequested", los)
	return "vision" if los["accepted"] and los["visible"] else ""

func _emit_detected(observer: StringName, target: StringName, reason: String) -> void:
	EventBus.publish(&"EntityDetected", {"observer": observer, "target": target, "reason": reason})
	if _is_hostile(observer, target): _sync_ai(observer, target, true)
func _emit_lost(observer: StringName, target: StringName) -> void:
	EventBus.publish(&"EntityLost", {"observer": observer, "target": target})
	if _is_hostile(observer, target): _sync_ai(observer, target, false)
func _sync_ai(observer: StringName, target: StringName, detected: bool) -> void:
	var query := {"entity": observer, "found": false}
	EventBus.publish(&"AIGetRequested", query)
	if query["found"] and query["data"]["target"] == target:
		EventBus.publish(&"AITargetSetRequested", {"entity": observer, "target": target, "detected": detected})
func _ai_registered(event: Dictionary) -> void:
	var observer: StringName = event.get("entity", &"")
	var query := {"entity": observer, "found": false}
	EventBus.publish(&"AIGetRequested", query)
	if query["found"]:
		var target: StringName = query["data"]["target"]
		if _is_hostile(observer, target): _sync_ai(observer, target, _is_seen(observer, target))

func _update_hotbar() -> void:
	if _updating_hotbar:
		_hotbar_dirty = true
		return
	_updating_hotbar = true
	for _attempt in range(16):
		_hotbar_dirty = false
		var next: Array = []
		var observer := _controlled
		for other in _hostile.get(observer, {}):
			if _is_seen(observer, other) and _is_seen(other, observer):
				next.append(other)
		next.sort_custom(func(a, b): return str(a) < str(b))
		if next != _hotbar:
			var previous := _hotbar.duplicate()
			_hotbar = next
			for other in previous:
				if not next.has(other): EventBus.publish(&"MutualDetectionChanged", {"entity": observer, "other": other, "detected": false})
			for other in next:
				if not previous.has(other): EventBus.publish(&"MutualDetectionChanged", {"entity": observer, "other": other, "detected": true})
			EventBus.publish(&"HotbarChanged", {"entity": observer, "hostiles": next.duplicate()})
			EventBus.publish(&"CombatDetectionChanged", {"entity": observer, "active": not next.is_empty(), "hostiles": next.duplicate()})
		if not _hotbar_dirty: break
	_updating_hotbar = false
	if _hotbar_dirty: call_deferred("_update_hotbar")

func _noise_requested(event: Dictionary) -> void:
	if _noise_transition_busy:
		event["accepted"] = false
		return
	_noise_callback_depth += 1
	_noise_requested_inner(event)
	_noise_callback_depth -= 1

func _noise_requested_inner(event: Dictionary) -> void:
	event["accepted"] = false
	var source: StringName = event.get("source", &"")
	var kind := str(event.get("kind", ""))
	var config = _noise_rules.get(kind, null)
	if source == &"" or not config is Dictionary:
		return
	var radius = config.get("radius", null)
	var duration = config.get("duration", null)
	if not _nonnegative(radius) or not _positive(duration):
		return
	var point = event.get("position", null)
	if point == null:
		var body := _body_center(source)
		if not body["found"]: return
		point = body["center"]
	if not point is Vector2 or not is_finite(point.x) or not is_finite(point.y):
		return
	_sequence += 1
	var id := StringName("noise:%d" % _sequence)
	_noises[id] = {"source": source, "position": point, "radius": float(radius), "kind": kind}
	var process := {"id": id, "duration": float(duration), "entity": source, "independent": true, "accepted": false}
	EventBus.publish(&"ProcessStartRequested", process)
	if not process["accepted"]:
		_noises.erase(id)
		return
	event["accepted"] = true
	event["id"] = id
	EventBus.publish(&"NoiseStarted", {"id": id, "source": source, "position": point, "radius": float(radius), "kind": kind, "duration": float(duration)})
	_refresh()
func _process_ended(event: Dictionary) -> void:
	var id: StringName = event.get("process", &"")
	if _noises.has(id):
		_noise_callback_depth += 1
		var noise: Dictionary = _noises[id]
		_noises.erase(id)
		EventBus.publish(&"NoiseEnded", {"id": id, "source": noise["source"], "kind": noise["kind"]})
		_refresh()
		_noise_callback_depth -= 1

func _directed_action(event: Dictionary) -> void:
	event["accepted"] = false
	var source: StringName = event.get("source", &"")
	var target: StringName = event.get("target", &"")
	var kind := str(event.get("kind", ""))
	if source == &"" or target == &"" or source == target or kind not in ["attack", "cast", "throw", "shot"] or not _alive(source) or not _alive(target) or not _tick_allowed(target) or not _body_center(source)["found"] or not _body_center(target)["found"]:
		return
	if not _forced.has(target): _forced[target] = {}
	_forced[target][source] = _step + _force_hold_steps
	event["accepted"] = true
	if not _is_seen(target, source):
		if not _seen.has(target): _seen[target] = {}
		_seen[target][source] = "forced"
		_emit_detected(target, source, "forced")
		_update_hotbar()
func _cleanup_forced() -> void:
	for observer in _forced.keys():
		for source in _forced[observer].keys():
			if int(_forced[observer][source]) < _step:
				_forced[observer].erase(source)
		if _forced[observer].is_empty(): _forced.erase(observer)

func _combat_start(event: Dictionary) -> void:
	if event.get("accepted", false) and event.get("action", &"") in [&"attack", &"rat_bite", &"ai_staff_attack"]:
		EventBus.publish(&"DetectionDirectedActionRequested", {"source": event.get("entity", &""), "target": event.get("target", &""), "kind": "attack"})
func _projectile_launch(event: Dictionary) -> void:
	if not event.get("accepted", false): return
	var source: StringName = event.get("entity", &"")
	EventBus.publish(&"NoiseEmitRequested", {"source": source, "kind": "shot"})
func _projectile_explosion(event: Dictionary) -> void:
	var center = event.get("center", null)
	if center is Vector2i:
		EventBus.publish(&"NoiseEmitRequested", {"source": event.get("owner", &""), "kind": "explosion", "position": Vector2(center) + Vector2.ONE * 0.5})
func _rat_bite(event: Dictionary) -> void:
	EventBus.publish(&"NoiseEmitRequested", {"source": event.get("entity", &""), "kind": "strike"})
func _strike(event: Dictionary) -> void:
	if event.get("accepted", false):
		EventBus.publish(&"NoiseEmitRequested", {"source": event.get("entity", &""), "kind": "strike"})

func _body_snapshot() -> Dictionary:
	var query := {}
	EventBus.publish(&"SpaceBodiesGetRequested", query)
	var result: Dictionary = {}
	for entity in query.get("bodies", {}):
		var body: Dictionary = query["bodies"][entity]
		var movement := {"entity": entity, "found": false}
		EventBus.publish(&"MovementPositionGetRequested", movement)
		var position: Vector2 = movement["position"] if movement["found"] else Vector2(body["anchor"])
		result[entity] = {"center": position + Vector2.ONE * float(body["size"]) / 2.0}
	return result
func _body_center(entity: StringName) -> Dictionary:
	var body := {"entity": entity, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	if not body["found"]: return {"found": false}
	var position := {"entity": entity, "found": false}
	EventBus.publish(&"MovementPositionGetRequested", position)
	var anchor: Vector2 = position["position"] if position["found"] else Vector2(body["data"]["anchor"])
	return {"found": true, "center": anchor + Vector2.ONE * float(body["data"]["size"]) / 2.0}
func _alive(entity: StringName) -> bool:
	var exists := {"entity": entity, "found": false}
	EventBus.publish(&"EntityGetRequested", exists)
	if not exists["found"]: return false
	var query := {"entity": entity, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", query)
	return query["allowed"]
func _entity_exists(entity: StringName) -> bool:
	var query := {"entity": entity, "found": false}
	EventBus.publish(&"EntityGetRequested", query)
	return query["found"]
func _tick_allowed(entity: StringName) -> bool:
	var query := {"entity": entity, "allowed": true}
	EventBus.publish(&"AIEntityTickAllowedRequested", query)
	if query["allowed"]:
		EventBus.publish(&"GameModeObserverAllowedRequested", query)
	return query["allowed"]
func _tile(point: Vector2) -> Vector2i:
	return Vector2i(floori(point.x), floori(point.y))
func _positive(value: Variant) -> bool:
	return _nonnegative(value) and float(value) > 0.0
func _nonnegative(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0

func _entity_died(event: Dictionary) -> void:
	_remove_seen(event.get("entity", &""))
func _body_removed(event: Dictionary) -> void:
	_remove_seen(event.get("entity", &""))
func _entity_removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	_remove_seen(entity)
	_radii.erase(entity)
	_forced.erase(entity)
	for observer in _forced.keys():
		_forced[observer].erase(entity)
		if _forced[observer].is_empty(): _forced.erase(observer)
	for other in _hostile.get(entity, {}).keys(): _set_relation(other, entity, false)
	_hostile.erase(entity)
	if entity == _controlled: _controlled = &""
	_update_hotbar()
func _remove_seen(entity: StringName) -> void:
	var removed: Array = []
	if _seen.has(entity):
		for target in _seen[entity].keys(): removed.append([entity, target])
		_seen.erase(entity)
	for observer in _seen.keys():
		if _seen[observer].has(entity):
			_seen[observer].erase(entity)
			removed.append([observer, entity])
			if _seen[observer].is_empty(): _seen.erase(observer)
	for pair in removed: _emit_lost(pair[0], pair[1])
	_update_hotbar()

func _snapshot_collect(event: Dictionary) -> void:
	if _refreshing or _updating_hotbar or _noise_transition_busy or _noise_callback_depth > 0:
		event["errors"].append("Нельзя сохранять во время пересчёта обнаружения или изменения шумов")
		return
	event["sections"]["detection"] = {"seen": _seen.duplicate(true), "hostile": _hostile.duplicate(true), "noises": _noises.duplicate(true), "forced": _forced.duplicate(true), "radii": _radii.duplicate(true), "controlled": _controlled, "step": _step, "sequence": _sequence}
func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["detection"]
	_seen = data["seen"].duplicate(true)
	_hostile = data["hostile"].duplicate(true)
	_noises = data["noises"].duplicate(true)
	_forced = data["forced"].duplicate(true)
	_radii = data["radii"].duplicate(true)
	_controlled = data["controlled"]
	_step = int(data["step"])
	_sequence = int(data["sequence"])
	_hotbar.clear()
	_refreshing = false
	_updating_hotbar = false
	_hotbar_dirty = false
func _snapshot_restored(_event: Dictionary) -> void:
	_update_hotbar()
	EventBus.publish(&"DetectionSnapshotRefreshFinished", {})

# Шумы — процессы текущей карты, в том числе от игрока и удалённых источников.
func discard_noises_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _noise_transition_busy or _noise_callback_depth > 0 or _refreshing or _updating_hotbar:
		return {"accepted":false, "error":"Обнаружение занято или нет операции перехода"}
	_noise_transition_busy = true
	var before: Dictionary = _noises.duplicate(true)
	var expected: Dictionary = before.duplicate(true)
	var ids: Array = before.keys()
	ids.sort_custom(func(a,b): return str(a) < str(b))
	var error := ""
	for id in ids: _noise_transition_ids[id] = true
	for id in ids:
		var process := ProcessRegistry.get_process_info(id)
		if process.is_empty() or not process.get("independent", false) or process.get("entity_id", null) != before[id].get("source", null):
			error = "Процесс шума отсутствует или не совпадает с источником"
			break
	if _noises != before or not SaveService.world_transition_operation_active(): error = "Состояние шумов изменилось"
	if error.is_empty():
		for id in ids:
			var process := ProcessRegistry.get_process_info(id)
			if process.is_empty() or not process.get("independent", false) or process.get("entity_id", null) != before[id].get("source", null):
				error = "Процесс шума изменился"
				break
			var stopped := ProcessRegistry.interrupt_process(id, &"floor_transition")
			expected.erase(id)
			if not stopped or ProcessRegistry.has_process(id) or _noises != expected or not SaveService.world_transition_operation_active():
				error = "Не удалось безопасно удалить шум"
				break
	_noise_transition_ids.clear()
	_noise_transition_busy = false
	if not error.is_empty():
		SaveService.fail_world_transition(error)
		return {"accepted":false, "error":error}
	return {"accepted":true, "noises":ids}

func _noise_process_guard(event: Dictionary) -> void:
	if _noise_transition_busy and _noise_transition_ids.has(event.get("id", &"")): event["allowed"] = false

func _noise_map_guard(event: Dictionary) -> void:
	if _noise_transition_busy or _noise_callback_depth > 0 or not _noises.is_empty(): event["allowed"] = false
