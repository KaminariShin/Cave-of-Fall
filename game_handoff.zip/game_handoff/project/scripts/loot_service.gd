extends Node
## Необязательный сервис: выпадают только реально имеющиеся предметы.
var _enabled := true
var _ground: Dictionary = {} # item -> {tile, source}
var _pending: Dictionary = {} # entity -> {item}
var _reserved: Dictionary = {} # item -> entity
var _processed: Dictionary = {}
var _death_centers: Dictionary = {}
var _queued_deaths: Dictionary = {}
var _draining := false
var _busy := false
var _transferring: StringName = &""
var _receiver: StringName = &""
var _discard_ids: Array = []
var _equip_drop_actor: StringName = &""
var _equip_drop_item: StringName = &""
var _equip_drop_slot := ""
var _drop_pending: Dictionary = {} # actor -> {item, tile}
var _drop_actor: StringName = &""
var _drop_item: StringName = &""
var _drop_launch: StringName = &""
var _drop_permit := false

func _ready() -> void:
	_register_drop_action()
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data": {"id": &"loot_pickup", "name": "Подбор предмета", "type": &"utility", "base_duration": 0.01, "interruptible": true}})
	EventBus.subscribe(&"LootModulePresentRequested", _present)
	EventBus.subscribe(&"LootEnableSetRequested", _set_enabled)
	EventBus.subscribe(&"LootGetRequested", _get_loot)
	EventBus.subscribe(&"LootDropTileCheckRequested", _drop_tile_check)
	EventBus.subscribe(&"LootDropTileResolveRequested", _drop_tile_resolve)
	EventBus.subscribe(&"LootPickupRequested", _pickup)
	EventBus.subscribe(&"LootPickupCandidatesRequested", _pickup_candidates)
	EventBus.subscribe(&"LootInventoryDropRequested", _inventory_drop_start)
	EventBus.subscribe(&"ActionStartAllowedRequested", _drop_start_guard)
	EventBus.subscribe(&"EntityInventoryChangeCheckRequested", _drop_inventory_guard)
	EventBus.subscribe(&"LootCollectCorpseRequested", _retry_corpse)
	EventBus.subscribe(&"LootInventoryAddCheckRequested", _inventory_check)
	EventBus.subscribe(&"LootEntityRemovalCheckRequested", _entity_removal_check)
	EventBus.subscribe(&"LootMapReconfigureCheckRequested", _map_check)
	EventBus.subscribe(&"LootTerrainChangeCheckRequested", _terrain_check)
	EventBus.subscribe(&"EntityDamaged", _damaged)
	EventBus.subscribe(&"EntityDied", _died)
	EventBus.subscribe(&"EntityRemoved", _removed)
	EventBus.subscribe(&"ActionCompleted", _action_completed)
	EventBus.subscribe(&"ActionInterrupted", _action_interrupted)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"SnapshotRestored", _restored)

func _present(event: Dictionary) -> void: event["present"] = true
func _set_enabled(event: Dictionary) -> void:
	event["accepted"] = false
	var value = event.get("enabled", null)
	if not value is bool or _busy: return
	_enabled = value
	if not _enabled:
		for actor in _pending.keys() + _drop_pending.keys():
			EventBus.publish(&"ActionCancelRequested", {"entity": actor, "reason": &"loot_disabled"})
	event["accepted"] = true
# Внутренний шаг будущей смены этажа. Использовать только внутри
# SaveService.run_world_transition_transaction; не событие для игрока.
# Подборы не отменяем: при занятости ничего не удаляем.
func discard_ground_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy or not _pending.is_empty() or not _drop_pending.is_empty() or not _reserved.is_empty() or not _death_centers.is_empty() or not _queued_deaths.is_empty():
		return {"accepted":false, "error":"Лут занят или нет операции перехода"}
	_busy = true
	var ids: Array = _ground.keys()
	ids.sort_custom(func(a, b): return str(a) < str(b))
	var error := ""
	for id in ids:
		if not id is StringName or _owned_elsewhere(id, &""):
			error = "Конфликт владельца наземного предмета: %s" % str(id)
			break
		var item := {"item":id, "found":false}
		EventBus.publish(&"ItemGetRequested", item)
		if not item.get("found", false):
			error = "Наземный предмет отсутствует: %s" % str(id)
			break
	if not _queued_deaths.is_empty() or not _death_centers.is_empty() or not SaveService.world_transition_operation_active():
		error = "Состояние изменилось во время проверки лута"
	if error.is_empty():
		_discard_ids = ids.duplicate()
		if not ItemService.retire_world_items_for_transition(ids):
			error = "Не удалось списать наземные предметы"
		else:
			# Между списанием экземпляров и удалением записей пола нет событий.
			for id in ids: _ground.erase(id)
		_discard_ids.clear()
	_busy = false
	_drain_deaths()
	if not error.is_empty(): return {"accepted":false, "error":error}
	return {"accepted":true, "items":ids}

# Для внутреннего протокола ItemService/BeltService, не права игрока.
func is_discarding_ground_items(ids: Array) -> bool:
	return _busy and SaveService.world_transition_operation_active() and ids == _discard_ids

func _get_loot(event: Dictionary) -> void:
	event["enabled"] = _enabled
	event["items"] = _ground.duplicate(true)
	if event.has("tile"):
		var filtered := {}
		for item in _ground:
			if _ground[item]["tile"] == event["tile"]: filtered[item] = _ground[item].duplicate(true)
		event["items"] = filtered
# Чистая проверка геометрии будущего сброса экипировки. Измеряем расстояние
# между центром тела и центром тайла; занятые телами/добычей клетки допускаются.
func _drop_center(actor: Variant) -> Dictionary:
	if not actor is StringName or actor == &"" or CombatService.is_entity_dead(actor): return {}
	var body := {"entity":actor,"found":false}
	EventBus.publish(&"SpaceBodyGetRequested",body)
	if not body.get("found",false) or not body.get("data",null) is Dictionary: return {}
	var b: Dictionary = body["data"]
	if not b.get("anchor",null) is Vector2i or not b.get("size",null) is int or b["size"] < 1: return {}
	var center := Vector2(b["anchor"]) + Vector2.ONE * float(b["size"]) * 0.5
	return {"center":center,"origin":Vector2i(floori(center.x),floori(center.y))}
func _drop_tile_valid(geometry: Dictionary, tile: Vector2i) -> bool:
	if geometry.is_empty(): return false
	var destination := Vector2(tile) + Vector2.ONE * 0.5
	if geometry["center"].distance_squared_to(destination) > 64.0 + 0.000000001: return false
	var cell := {"tile":tile}
	EventBus.publish(&"SpaceTileGetRequested",cell)
	if not cell.get("in_bounds",false) or cell.get("kind",0) != 1: return false
	var los := {"from":geometry["origin"],"to":tile}
	EventBus.publish(&"SpaceLineOfSightRequested",los)
	return los.get("accepted",false) and los.get("visible",false)
func _drop_tile_check(e: Dictionary) -> void:
	e["accepted"] = false; e["valid"] = false
	var tile = e.get("tile",null)
	if not tile is Vector2i: return
	var geometry := _drop_center(e.get("entity",null))
	if geometry.is_empty(): return
	e["accepted"] = true
	e["valid"] = _drop_tile_valid(geometry,tile)
func _drop_tile_resolve(e: Dictionary) -> void:
	e["accepted"] = false; e["found"] = false; e.erase("resolved_tile")
	var tile = e.get("tile",null)
	if not tile is Vector2i: return
	var geometry := _drop_center(e.get("entity",null))
	if geometry.is_empty(): return
	e["accepted"] = true
	if _drop_tile_valid(geometry,tile):
		e["found"] = true; e["resolved_tile"] = tile; return
	var center: Vector2 = geometry["center"]
	var origin := Vector2i(floori(center.x),floori(center.y))
	var best := Vector2i.ZERO
	var best_dist := INF
	var found := false
	# При равной дистанции используется порядок y, затем x; в ТЗ он не задан.
	for y in range(origin.y - 9, origin.y + 10):
		for x in range(origin.x - 9, origin.x + 10):
			var candidate := Vector2i(x,y)
			var distance := Vector2(candidate).distance_squared_to(Vector2(tile))
			if distance >= best_dist or not _drop_tile_valid(geometry,candidate): continue
			best = candidate; best_dist = distance; found = true
	if found: e["found"] = true; e["resolved_tile"] = best

# Только завершившееся действие снятия может вызвать этот тихий двойной
# коммит: сначала реестр снимает слот, сразу затем записывается пол, без событий.
func commit_equipment_drop(actor: StringName, item: StringName, slot: String, selected: Vector2i) -> Dictionary:
	if not EquipmentActionService.authorizes_ground_drop(actor,item,slot) or not _enabled or _busy or _ground.has(item) or _reserved.has(item): return {"accepted":false}
	_busy = true
	var where := {"entity":actor,"tile":selected}
	_drop_tile_resolve(where)
	var valid: bool = where.get("found",false) and not CombatService.is_entity_dead(actor) and not _owned_elsewhere(item,actor)
	var query := {"item":item}
	EventBus.publish(&"ItemGetRequested",query)
	valid = valid and query.get("found",false) and not _ground.has(item) and not _reserved.has(item)
	_equip_drop_actor = actor; _equip_drop_item = item; _equip_drop_slot = slot
	var released: bool = valid and EntityRegistry.release_equipment_to_ground(actor,item,slot)
	_equip_drop_actor = &""; _equip_drop_item = &""; _equip_drop_slot = ""
	if released: _ground[item] = {"tile":where["resolved_tile"],"source":actor}
	_busy = false
	_drain_deaths()
	if not released: return {"accepted":false}
	return {"accepted":true,"tile":where["resolved_tile"]}
func authorizes_equipment_drop(actor: StringName, item: StringName, slot: String) -> bool:
	return _busy and _equip_drop_actor == actor and _equip_drop_item == item and _equip_drop_slot == slot and actor != &"" and item != &""

func _inventory_check(event: Dictionary) -> void:
	var item: StringName = event.get("item", &"")
	if _ground.has(item):
		event["allowed"] = _busy and item == _transferring and event.get("entity", &"") == _receiver

func _entity_removal_check(event: Dictionary) -> void:
	if _busy: event["allowed"] = false
func _map_check(event: Dictionary) -> void:
	if not _ground.is_empty() or not _pending.is_empty() or not _drop_pending.is_empty(): event["allowed"] = false
func _terrain_check(event: Dictionary) -> void:
	if event.get("kind", 1) != 0: return
	var tiles: Array = event.get("tiles", [])
	for drop in _ground.values():
		if tiles.has(drop["tile"]):
			event["allowed"] = false
			return

# Фиксируем интерполированное положение до отмены движения по EntityDied.
func _damaged(event: Dictionary) -> void:
	if not _enabled: return
	var entity: StringName = event.get("entity", &"")
	var hp := {"entity": entity, "resource": &"HP", "found": false}
	EventBus.publish(&"ResourceGetRequested", hp)
	if hp["found"] and float(hp["data"]["current"]) <= 0.0:
		var position := _corpse_tile(entity)
		if position["found"]: _death_centers[entity] = position["tile"]
func _died(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if _enabled and _busy:
		if not _death_centers.has(entity):
			var body := _corpse_tile(entity)
			if body["found"]: _death_centers[entity] = body["tile"]
		_queued_deaths[entity] = true
		return
	if _enabled: _drop_corpse(entity)
	_death_centers.erase(entity)
	_drain_deaths()
func _drain_deaths() -> void:
	if _busy or _draining: return
	_draining = true
	while not _queued_deaths.is_empty():
		var ids: Array = _queued_deaths.keys()
		ids.sort_custom(func(a, b): return str(a) < str(b))
		var entity: StringName = ids[0]
		_queued_deaths.erase(entity)
		if _enabled: _drop_corpse(entity)
		_death_centers.erase(entity)
	_draining = false
func _retry_corpse(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var alive := {"entity": entity, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	if not _enabled or alive["allowed"] or _busy: return
	event["accepted"] = _drop_corpse(entity)
func _removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	_processed.erase(entity)
	_death_centers.erase(entity)
	_queued_deaths.erase(entity)
	if _pending.has(entity): _clear_pending(entity)
	_drop_pending.erase(entity)

func _drop_corpse(entity: StringName) -> bool:
	if entity == &"" or _busy or _processed.has(entity): return false
	var body := _corpse_tile(entity)
	if _death_centers.has(entity): body = {"found": true, "tile": _death_centers[entity]}
	if not body["found"]:
		EventBus.publish(&"LootDropFailed", {"entity": entity, "reason": "Нет корректной позиции тела"})
		return false
	var tile: Vector2i = body["tile"]
	var tile_query := {"tile": tile}
	EventBus.publish(&"SpaceTileGetRequested", tile_query)
	if not tile_query.get("in_bounds", false) or tile_query.get("kind", 0) != 1:
		EventBus.publish(&"LootDropFailed", {"entity": entity, "reason": "Тайл трупа не является полом"})
		return false
	var inv := {"entity": entity, "found": false}
	EventBus.publish(&"InventoryGetRequested", inv)
	var equip := {"entity": entity, "component": &"equipment", "found": false}
	EventBus.publish(&"ComponentGetRequested", equip)
	var inventory: Array = inv["data"].get("items", []).duplicate() if inv["found"] else []
	var equipment: Dictionary = equip.get("data", {}) if equip["found"] else {}
	var equipped: Array = []
	if not _collect_ids(equipment, equipped, 0):
		EventBus.publish(&"LootDropFailed", {"entity": entity, "reason": "Некорректная экипировка"})
		return false
	var equipped_slots := {}
	_collect_slots(equipment, equipped_slots, "", 0)
	var all: Array = inventory.duplicate()
	for id in equipped:
		if not all.has(id): all.append(id)
	all.sort_custom(func(a, b): return str(a) < str(b))
	_busy = true
	var drop_ids: Array = []
	for id_value in all:
		var id := StringName(str(id_value))
		var item := {"item": id, "found": false}
		EventBus.publish(&"ItemGetRequested", item)
		if id == &"" or not item["found"] or _ground.has(id) or (inventory.has(id) and equipped.has(id)) or _owned_elsewhere(id, entity):
			EventBus.publish(&"LootDropItemFailed", {"entity": entity, "item": id, "reason": "Предмет отсутствует или имеет конфликтующие записи владения"})
			continue
		drop_ids.append(id)
	# Убираем экипировку до инвентаря: бонусы вместимости могут исчезнуть, но
	# извлечение предметов не зависит от лимита объёма.
	if equip["found"] and not equipped.is_empty():
		var changed := {"entity": entity, "component": &"equipment", "data": _strip_equipment(equipment, drop_ids, 0), "accepted": false}
		EventBus.publish(&"ComponentSetRequested", changed)
		if not changed["accepted"]:
			_busy = false
			_drain_deaths()
			EventBus.publish(&"LootDropFailed", {"entity": entity, "reason": "Не удалось снять экипировку"})
			return false
	for id in drop_ids:
		if inventory.has(id):
			var remove := {"entity": entity, "item": id, "accepted": false}
			EventBus.publish(&"InventoryRemoveRequested", remove)
			if not remove["accepted"]:
				EventBus.publish(&"LootDropItemFailed", {"entity": entity, "item": id, "reason": "Не удалось извлечь из инвентаря"})
				continue
		_ground[id] = {"tile": tile, "source": entity}
		if equipped.has(id): EventBus.publish(&"ItemUnequipped", {"entity": entity, "item": id, "slot": equipped_slots.get(id, ""), "reason": &"death"})
		EventBus.publish(&"LootItemDropped", {"entity": entity, "item": id, "tile": tile, "position": Vector2(tile) + Vector2.ONE * 0.5})
	_processed[entity] = true
	_busy = false
	_drain_deaths()
	EventBus.publish(&"LootCorpseProcessed", {"entity": entity, "tile": tile})
	return true

func _register_drop_action() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":&"loot_inventory_drop","name":"Выбросить предмет","type":&"utility","base_duration":0.1,"interruptible":true}})

func _drop_start_guard(e: Dictionary) -> void:
	if e.get("action",null) != &"loot_inventory_drop": return
	if e.get("entity",null) != _drop_launch or not _drop_permit: e["allowed"] = false
	else: _drop_permit = false

func _drop_inventory_guard(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if not _drop_pending.has(actor) or actor == _drop_actor: return
	var id: StringName = _drop_pending[actor]["item"]
	if not e.get("after",{}).get("items",[]).has(id): e["allowed"] = false

func _pickup_candidates(e: Dictionary) -> void:
	e["items"] = []
	var actor = e.get("entity",null)
	if not _enabled or not actor is StringName: return
	var ids: Array = _ground.keys()
	ids.sort_custom(func(a,b): return str(a) < str(b))
	for id in ids:
		if not _reserved.has(id) and _covers(actor,_ground[id]["tile"]): e["items"].append(id)

# Выбрасывание из рюкзака — прерываемое действие, как и подбор.
# Предмет остаётся в инвентаре до завершения и проверяется повторно.
func _inventory_drop_start(e: Dictionary) -> void:
	e["accepted"] = false
	var actor = e.get("entity",null)
	var item = e.get("item",null)
	var tile = e.get("tile",null)
	var mode := {}
	EventBus.publish(&"GameModeGetRequested",mode)
	if not _enabled or _busy or not actor is StringName or actor != mode.get("entity",null) or not item is StringName or item == &"" or not tile is Vector2i or _drop_pending.has(actor) or _pending.has(actor) or _ground.has(item) or CombatService.is_entity_dead(actor): return
	var inv := {"entity":actor}
	EventBus.publish(&"InventoryGetRequested",inv)
	var query := {"item":item}
	EventBus.publish(&"ItemGetRequested",query)
	if not inv.get("found",false) or not inv["data"].get("items",[]).has(item) or not query.get("found",false) or not _drop_tile_valid(_drop_center(actor),tile): return
	_busy = true
	_drop_pending[actor] = {"item":item,"tile":tile}
	_drop_launch = actor; _drop_permit = true
	var start := {"entity":actor,"action":&"loot_inventory_drop","duration":0.1}
	EventBus.publish(&"ActionStartRequested",start)
	_drop_launch = &""; _drop_permit = false
	var active := {"entity":actor}
	EventBus.publish(&"ActionGetRequested",active)
	if not start.get("accepted",false) or not _drop_pending.has(actor) or active.get("data",{}).get("id",null) != &"loot_inventory_drop":
		_drop_pending.erase(actor); _busy = false; _drain_deaths(); return
	_busy = false
	e["accepted"] = true
	_drain_deaths()
	EventBus.publish(&"LootInventoryDropStarted",{"entity":actor,"item":item,"tile":tile,"duration":0.1})

func authorizes_inventory_drop(actor: StringName, item: StringName) -> bool:
	return _busy and actor == _drop_actor and item == _drop_item and actor != &"" and item != &""

# Последняя сверка непосредственно перед переносом, без событий и без
# возможности изменить геометрию между проверкой и атомарной записью.
func inventory_drop_commit_valid(actor: StringName, item: StringName) -> bool:
	if not authorizes_inventory_drop(actor,item) or not _enabled or not _drop_pending.has(actor) or _drop_pending[actor].get("item",null) != item or _ground.has(item) or _reserved.has(item) or CombatService.is_entity_dead(actor): return false
	var tile: Vector2i = _drop_pending[actor]["tile"]
	var body = SpaceService._bodies.get(actor,null)
	if not body is Dictionary or not body.get("anchor",null) is Vector2i or not body.get("size",null) is int or not SpaceService._floor.has(tile): return false
	var center := Vector2(body["anchor"]) + Vector2.ONE * float(body["size"]) * 0.5
	if center.distance_squared_to(Vector2(tile)+Vector2.ONE*0.5) > 64.0+0.000000001: return false
	var query := {"from":Vector2i(floori(center.x),floori(center.y)),"to":tile}
	SpaceService._line_of_sight(query)
	return query.get("accepted",false) and query.get("visible",false)

func _finish_inventory_drop(actor: StringName) -> void:
	if not _drop_pending.has(actor): return
	var p: Dictionary = _drop_pending[actor]
	var item: StringName = p["item"]
	var tile: Vector2i = p["tile"]
	_busy = true
	var q := {"item":item}
	EventBus.publish(&"ItemGetRequested",q)
	var ok: bool = _enabled and q.get("found",false) and not _ground.has(item) and not _reserved.has(item) and not CombatService.is_entity_dead(actor) and _drop_tile_valid(_drop_center(actor),tile)
	_drop_actor = actor; _drop_item = item
	if ok: ok = EntityRegistry.release_inventory_to_ground(actor,item)
	_drop_actor = &""; _drop_item = &""
	if ok: _ground[item] = {"tile":tile,"source":actor}
	_drop_pending.erase(actor)
	_busy = false
	_drain_deaths()
	if ok:
		EventBus.publish(&"ComponentChanged",{"entity":actor,"component":&"inventory","created":false})
		EventBus.publish(&"InventoryItemRemoved",{"entity":actor,"item":item})
		EventBus.publish(&"LootItemDropped",{"entity":actor,"item":item,"tile":tile,"position":Vector2(tile)+Vector2.ONE*0.5})
	else: EventBus.publish(&"LootInventoryDropFailed",{"entity":actor,"item":item,"reason":"Предмет или клетка недоступны"})

func _pickup(event: Dictionary) -> void:
	event["accepted"] = false
	var actor: StringName = event.get("entity", &"")
	var item: StringName = event.get("item", &"")
	var duration = event.get("duration", null)
	var control := {}
	EventBus.publish(&"GameModeGetRequested", control)
	if not _enabled or _busy or actor == &"" or actor != control.get("entity", &"") or not _ground.has(item) or _reserved.has(item) or _pending.has(actor) or not (duration is int or duration is float) or not is_finite(float(duration)) or float(duration) <= 0.0:
		return
	if not _covers(actor, _ground[item]["tile"]): return
	_busy = true
	_pending[actor] = {"item": item}
	_reserved[item] = actor
	var request := {"entity": actor, "action": &"loot_pickup", "duration": duration, "accepted": false}
	EventBus.publish(&"ActionStartRequested", request)
	var current := {"entity": actor, "found": false}
	EventBus.publish(&"ActionGetRequested", current)
	if not request["accepted"] or not _pending.has(actor) or not current["found"] or current["data"]["id"] != &"loot_pickup":
		_clear_pending(actor)
		_busy = false
		_drain_deaths()
		return
	event["accepted"] = true
	_busy = false
	_drain_deaths()
	EventBus.publish(&"LootPickupStarted", {"entity": actor, "item": item, "duration": float(duration)})
func _action_completed(event: Dictionary) -> void:
	var actor: StringName = event.get("entity", &"")
	if event.get("action", &"") == &"loot_inventory_drop":
		_finish_inventory_drop(actor)
		return
	if event.get("action", &"") != &"loot_pickup" or not _pending.has(actor): return
	var item: StringName = _pending[actor]["item"]
	_busy = true
	var ok := _enabled and _ground.has(item) and _covers(actor, _ground[item]["tile"])
	if ok:
		_transferring = item
		_receiver = actor
		var add := {"entity": actor, "item": item, "accepted": false}
		EventBus.publish(&"InventoryAddRequested", add)
		ok = add["accepted"]
		_transferring = &""
		_receiver = &""
		if ok: _ground.erase(item)
	_clear_pending(actor)
	_busy = false
	_drain_deaths()
	if ok: EventBus.publish(&"LootItemPickedUp", {"entity": actor, "item": item})
	else: EventBus.publish(&"LootPickupFailed", {"entity": actor, "item": item, "reason": "Предмет недоступен, не накрыт телом или не помещается"})
func _action_interrupted(event: Dictionary) -> void:
	var actor: StringName = event.get("entity", &"")
	if event.get("action", &"") == &"loot_inventory_drop" and _drop_pending.has(actor):
		var item: StringName = _drop_pending[actor]["item"]
		_drop_pending.erase(actor)
		EventBus.publish(&"LootInventoryDropInterrupted",{"entity":actor,"item":item})
	if event.get("action", &"") == &"loot_pickup" and _pending.has(actor):
		var item: StringName = _pending[actor]["item"]
		_clear_pending(actor)
		EventBus.publish(&"LootPickupInterrupted", {"entity": actor, "item": item, "reason": event.get("reason", &"cancelled")})
func _clear_pending(actor: StringName) -> void:
	if not _pending.has(actor): return
	_reserved.erase(_pending[actor]["item"])
	_pending.erase(actor)
func _covers(actor: StringName, tile: Vector2i) -> bool:
	var body := {"entity": actor, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	if not body["found"]: return false
	var pos := {"entity": actor, "found": false}
	EventBus.publish(&"MovementPositionGetRequested", pos)
	var anchor: Vector2 = pos["position"] if pos["found"] else Vector2(body["data"]["anchor"])
	var size := float(body["data"]["size"])
	return anchor.x <= tile.x and anchor.y <= tile.y and anchor.x + size >= tile.x + 1 and anchor.y + size >= tile.y + 1
func _corpse_tile(entity: StringName) -> Dictionary:
	var body := {"entity": entity, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	if not body["found"]: return {"found": false}
	var pos := {"entity": entity, "found": false}
	EventBus.publish(&"MovementPositionGetRequested", pos)
	var anchor: Vector2 = pos["position"] if pos["found"] else Vector2(body["data"]["anchor"])
	var center := anchor + Vector2.ONE * float(body["data"]["size"]) / 2.0
	return {"found": true, "tile": Vector2i(floori(center.x), floori(center.y))}

func _collect_ids(value: Variant, result: Array, depth: int) -> bool:
	if depth > 32: return false
	if value == null: return true
	if value is String or value is StringName:
		var id := StringName(str(value))
		if id == &"": return false
		if not result.has(id): result.append(id)
		return true
	if value is Dictionary:
		if value.has("id"): return _collect_ids(value["id"], result, depth + 1)
		for child in value.values():
			if not _collect_ids(child, result, depth + 1): return false
		return true
	if value is Array:
		for child in value:
			if not _collect_ids(child, result, depth + 1): return false
		return true
	return false
## Слоты до удаления; вложенный словарь/массив выражается путём через точку.
func _collect_slots(value: Variant, result: Dictionary, path: String, depth: int) -> void:
	if depth > 32 or value == null: return
	if value is String or value is StringName:
		var id := StringName(str(value))
		if id != &"" and not result.has(id): result[id] = path
		return
	if value is Dictionary:
		if value.has("id"):
			_collect_slots(value["id"], result, path, depth + 1)
			return
		for key in value:
			var next := str(key) if path.is_empty() else path + "." + str(key)
			_collect_slots(value[key], result, next, depth + 1)
	elif value is Array:
		for i in range(value.size()):
			var next := str(i) if path.is_empty() else path + "." + str(i)
			_collect_slots(value[i], result, next, depth + 1)

func _strip_equipment(value: Variant, ids: Array, depth: int) -> Variant:
	if depth > 32: return value
	if value is String or value is StringName:
		return null if ids.has(StringName(str(value))) else value
	if value is Dictionary:
		if value.has("id") and ids.has(StringName(str(value["id"]))): return null
		var result := {}
		for key in value: result[key] = _strip_equipment(value[key], ids, depth + 1)
		return result
	if value is Array:
		var result := []
		for child in value:
			var next = _strip_equipment(child, ids, depth + 1)
			if next != null: result.append(next)
		return result
	return value
func _owned_elsewhere(item: StringName, owner: StringName) -> bool:
	var query := {"components": [], "entities": []}
	EventBus.publish(&"EntityQueryRequested", query)
	for other in query["entities"]:
		if other == owner: continue
		var inventory := {"entity": other, "found": false}
		EventBus.publish(&"InventoryGetRequested", inventory)
		if inventory["found"] and inventory["data"].get("items", []).has(item): return true
		var equipment := {"entity": other, "component": &"equipment", "found": false}
		EventBus.publish(&"ComponentGetRequested", equipment)
		if equipment["found"]:
			var ids: Array = []
			if not _collect_ids(equipment["data"], ids, 0) or ids.has(item): return true
	return false

func _collect(event: Dictionary) -> void:
	if _busy or not _death_centers.is_empty():
		event["errors"].append("Нельзя сохранять во время обработки лута")
		return
	event["sections"]["loot"] = {"enabled": _enabled, "ground": _ground.duplicate(true), "pending": _pending.duplicate(true), "drop_pending":_drop_pending.duplicate(true), "processed": _processed.duplicate(true)}
func _apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"].get("loot", {"enabled": true, "ground": {}, "pending": {}, "processed": {}})
	_enabled = data["enabled"]
	_ground = data["ground"].duplicate(true)
	_pending = data["pending"].duplicate(true)
	_drop_pending = data.get("drop_pending",{}).duplicate(true)
	_drop_actor = &""; _drop_item = &""; _drop_launch = &""; _drop_permit = false
	_processed = data["processed"].duplicate(true)
	_reserved.clear()
	_discard_ids.clear()
	for actor in _pending: _reserved[_pending[actor]["item"]] = actor
	_busy = false
	_transferring = &""
	_receiver = &""
	_death_centers.clear()
	_queued_deaths.clear()
	_draining = false
func _restored(_event: Dictionary) -> void:
	_register_drop_action()
	EventBus.publish(&"LootRestored", {"items": _ground.duplicate(true)})
