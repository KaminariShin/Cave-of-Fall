extends Node
## Размещение портала и мгновенное завершение забега.
var _state: Dictionary = {}
var _busy := false
var _creating: StringName = &""

func _ready() -> void:
	EventBus.subscribe(&"DungeonMilestoneCandidateSelected", _selected)
	EventBus.subscribe(&"DungeonPortalGetRequested", _get_portal)
	EventBus.subscribe(&"DungeonPortalPlacementRetryRequested", _retry)
	EventBus.subscribe(&"DungeonPortalTrialRequested", _trial)
	EventBus.subscribe(&"DungeonPortalCreateCheckRequested", _create_check)
	EventBus.subscribe(&"DungeonPortalAvailabilityRequested", _availability)
	EventBus.subscribe(&"DungeonPortalInteractRequested", _interact)
	EventBus.subscribe(&"ObjectRemoved", _removed)
	EventBus.subscribe(&"SpaceMapConfigured", _reset)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"DungeonPortalSnapshotValidateRequested", _validate)

func _selected(e: Dictionary) -> void:
	if e.get("kind", "") != "portal" or _busy or not _state.is_empty(): return
	_state = {"room":e["room"], "status":"failed", "object":null}
	_place()

func _get_portal(e: Dictionary) -> void:
	e["found"] = not _state.is_empty()
	if e["found"]: e["data"] = _state.duplicate(true)

func _retry(e: Dictionary) -> void:
	e["accepted"] = false
	if _busy or _state.is_empty() or _state["status"] != "failed": return
	_place()
	e["accepted"] = _state["status"] == "placed"

# Проба ещё не подключённого тупика: те же условия тела 4×4 и пути,
# что у фактического размещения, но без создания объекта и расхода ГСЧ.
func _trial(e: Dictionary) -> void:
	e["accepted"] = false
	var room_id = e.get("room",null)
	if _busy or not _state.is_empty() or not room_id is StringName or room_id == &"" or _free_id() == &"": return
	_busy = true
	e["accepted"] = _probe_room(room_id)
	_busy = false

func _probe_room(room_id: StringName) -> bool:
	var room := {"id":room_id,"found":false}
	EventBus.publish(&"RoomGetRequested",room)
	if not room.get("found",false) or room["data"].get("type","") != "deadend": return false
	var data: Dictionary = room["data"]
	var entry: Dictionary = {}
	for ex in data["exits"]:
		if ex.get("id",null) == &"entry": entry=ex; break
	if entry.is_empty(): return false
	var origin: Vector2i = data["origin_cell"]*4
	var size: Vector2i = data["size_cells"]*4
	var bounds := {"origin":origin,"size":size}
	var seed := Vector2i(int(entry["x"]),int(entry["y"]))
	match str(entry["dirOut"]):
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
		_: return false
	if not DungeonStairsService._fits(seed,bounds): return false
	var parents := {seed:null}
	var queue: Array = [seed]
	var index := 0
	while index < queue.size():
		var anchor: Vector2i = queue[index]
		index += 1
		for tile in DungeonStairsService._adjacent_tiles(anchor):
			if DungeonStairsService._stair_tile_usable(anchor,tile,parents,Rect2i(origin,size)): return true
		for delta in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
			var next: Vector2i = anchor + delta
			if not parents.has(next) and DungeonStairsService._fits(next,bounds):
				parents[next]=anchor
				queue.append(next)
	return false

func _create_check(e: Dictionary) -> void:
	e["allowed"] = _busy and _creating != &"" and e.get("entity", null) == _creating and e.get("room", null) == _state.get("room", null)

func _place() -> void:
	_busy = true
	var room := {"id":_state["room"], "found":false}
	EventBus.publish(&"RoomGetRequested", room)
	if not room.get("found", false): return _failure("Комната не найдена")
	var data: Dictionary = room["data"]
	var entry: Dictionary = {}
	for ex in data["exits"]:
		if ex.get("id", null) == &"entry" and ex.get("connected", false): entry = ex; break
	if entry.is_empty(): return _failure("Нет связанного входа")
	var origin: Vector2i = data["origin_cell"] * 4
	var size: Vector2i = data["size_cells"] * 4
	var bounds := {"origin":origin, "size":size}
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match str(entry["dirOut"]):
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
		_: return _failure("Недопустимый вход")
	# Совместно с лестницей: путь тела 4×4 должен оставаться свободным от объекта.
	if not DungeonStairsService._fits(seed, bounds): return _failure("Телу 4×4 недоступен вход")
	var object_id := _free_id()
	if object_id == &"": return _failure("Нет свободного ID портала")
	var parents := {seed:null}
	var queue: Array = [seed]
	var index := 0
	while index < queue.size():
		var anchor: Vector2i = queue[index]
		index += 1
		for tile in DungeonStairsService._adjacent_tiles(anchor):
			if not DungeonStairsService._stair_tile_usable(anchor, tile, parents, Rect2i(origin, size)): continue
			_creating = object_id
			var create := {"entity":object_id, "type":"portal_exit", "room":_state["room"], "tile":tile, "accepted":false}
			EventBus.publish(&"ObjectCreateRequested", create)
			_creating = &""
			if create.get("accepted", false):
				_state["status"] = "placed"
				_state["object"] = object_id
				_busy = false
				EventBus.publish(&"DungeonPortalPlaced", {"room":_state["room"], "object":object_id, "tile":tile})
				return
			if create.has("incomplete"): return _failure("Создание объекта не удалось безопасно откатить")
		for delta in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = anchor + delta
			if not parents.has(next) and DungeonStairsService._fits(next, bounds):
				parents[next] = anchor
				queue.append(next)
	_failure("Нет доступного места для портала")

func _free_id() -> StringName:
	for i in range(10000):
		var id := StringName("portal_exit_%d" % i)
		var q := {"entity":id, "found":false}
		EventBus.publish(&"EntityGetRequested", q)
		if not q.get("found", false): return id
	return &""

func _failure(reason: String) -> void:
	_state["status"] = "failed"
	_state["object"] = null
	_creating = &""
	_busy = false
	EventBus.publish(&"DungeonPortalPlacementFailed", {"room":_state["room"], "error":reason})

func _removed(e: Dictionary) -> void:
	if not _state.is_empty() and e.get("object", null) == _state.get("object", null): _failure("Портал удалён")
func _reset(_e: Dictionary) -> void:
	_state.clear()
	_creating = &""

# Проверка известных условий, а не команда победы и не проверка боевого режима.
func _availability(e: Dictionary) -> void:
	e["accepted"] = false
	e["rule_allowed"] = false
	e["transition_available"] = false
	var actor = e.get("entity", null)
	if not actor is StringName or actor == &"": return
	e["accepted"] = true
	if _state.is_empty() or _state["status"] != "placed":
		e["reason"] = "Портал не размещён"; return
	var boss := {"found":false}
	EventBus.publish(&"DungeonBossGetRequested", boss)
	if not boss.get("found", false) or boss["data"].get("status", "") != "defeated":
		e["reason"] = "Босс не побеждён"; return
	var mode := {}
	EventBus.publish(&"GameModeGetRequested", mode)
	if mode.get("entity", null) != actor or CombatService.is_entity_dead(actor):
		e["reason"] = "Нужен живой управляемый персонаж"; return
	var action := {"entity":actor, "found":false}
	EventBus.publish(&"ActionGetRequested", action)
	if action.get("found", false):
		e["reason"] = "Выполняется другое действие"; return
	var object := {"object":_state["object"], "found":false}
	var body := {"entity":actor, "found":false}
	var room := {"id":_state["room"], "found":false}
	EventBus.publish(&"ObjectGetRequested", object)
	EventBus.publish(&"SpaceBodyGetRequested", body)
	EventBus.publish(&"RoomGetRequested", room)
	if not object.get("found", false) or not body.get("found", false) or not room.get("found", false):
		e["reason"] = "Объект, тело или комната отсутствуют"; return
	var a: Vector2i = body["data"]["anchor"]
	var n: int = body["data"]["size"]
	var tile: Vector2i = object["data"]["tile"]
	var bounds := Rect2i(room["data"]["origin_cell"] * 4, room["data"]["size_cells"] * 4)
	var adjacent := ((tile.x == a.x - 1 or tile.x == a.x + n) and tile.y >= a.y and tile.y < a.y + n) or ((tile.y == a.y - 1 or tile.y == a.y + n) and tile.x >= a.x and tile.x < a.x + n)
	if not bounds.encloses(Rect2i(a, Vector2i.ONE * n)) or not adjacent:
		e["reason"] = "Нужно находиться рядом с порталом"; return
	if mode.get("mode", "") != "exploration":
		e["reason"] = "Условия портала в бою не определены"; return
	var run := {"found":false}
	EventBus.publish(&"RunStatisticsGetRequested", run)
	if not run.get("found",false) or run["data"].get("entity",null) != actor or run["data"].get("floor",0) != 4 or run["data"].get("finished",false):
		e["reason"] = "Активный забег четвёртого этажа недоступен"; return
	e["rule_allowed"] = true
	e["transition_available"] = true
	e["reason"] = "Портал доступен"

func _interact(e: Dictionary) -> void:
	e["accepted"] = false
	if _busy or _state.is_empty() or e.get("object", null) != _state.get("object", null):
		e["error"] = "Портал недоступен"; return
	var q := {"entity":e.get("entity", null)}
	_availability(q)
	e["error"] = q.get("reason", "Портал недоступен")
	e["rule_allowed"] = q.get("rule_allowed", false)
	if not e["rule_allowed"]: return
	var finish := {"entity":e.get("entity",null), "accepted":false}
	EventBus.publish(&"RunStatisticsVictoryRequested", finish)
	e["accepted"] = finish.get("accepted",false)
	if e["accepted"]: e["error"] = ""
	else: e["error"] = "Не удалось завершить забег"

func _collect(e: Dictionary) -> void:
	if _busy:
		e["errors"].append("Нельзя сохранять во время размещения портала")
		return
	e["sections"]["dungeon_portal"] = _state.duplicate(true)
func _apply(e: Dictionary) -> void:
	_state = e["sections"]["dungeon_portal"].duplicate(true)
	_busy = false
	_creating = &""
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary or not sections.get("dungeon_portal", null) is Dictionary or not sections.get("dungeon_tracking", null) is Dictionary or not sections.get("objects", {}).get("objects", null) is Dictionary: return
	var state: Dictionary = sections["dungeon_portal"]
	var track: Dictionary = sections["dungeon_tracking"]
	var objects: Dictionary = sections["objects"]["objects"]
	var portals: Array = []
	for id in objects:
		if objects[id] is Dictionary and objects[id].get("type", "") == "portal_exit": portals.append(id)
	if state.is_empty():
		if track.get("portal_candidate", null) != null or not portals.is_empty(): return
		e["valid"] = true
		return
	if not state.get("room", null) is StringName or state["room"] != track.get("portal_candidate", null) or track.get("floor", 0) != 4 or state.get("status", "") not in ["failed", "placed"] or not state.has("object"): return
	if state["status"] == "failed":
		if state["object"] != null or not portals.is_empty(): return
	else:
		var id = state["object"]
		if not id is StringName or portals.size() != 1 or portals[0] != id or not objects.get(id, null) is Dictionary or objects[id].get("room", null) != state["room"]: return
	e["valid"] = true
