extends Node
## Описания действий и выполняемые действия юнитов. Время принадлежит TimeDriver.

signal action_started(entity_id: StringName, action_id: StringName)
signal action_finished(entity_id: StringName, action_id: StringName)
signal action_interrupted(entity_id: StringName, action_id: StringName, reason: StringName)

var _definitions: Dictionary = {}
var _active: Dictionary = {}
var _order: Array[StringName] = []
var _controlled_entity: StringName = &""
var _changing_controlled := false
var _game_time := 0.0
var _driver_active := false
# Только внутри текущего шага, сохранять промежуточное состояние нельзя.
var _phase_due: Array = []
var _phase_finishes: Array = []
# Временная очередь обычных запросов на шаге середины оружейного удара.
var _midpoint_processed: Dictionary = {}
var _midpoint_step := -1
var _midpoint_tick_complete := false
var _midpoint_deferred: Dictionary = {}
var _midpoint_resolving := false

func _ready() -> void:
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"TimeStepStarted", _on_time_step_started)
	EventBus.subscribe(&"Tick", _on_tick)
	EventBus.subscribe(&"DriverActionCompleted", _on_driver_completed_event)
	EventBus.subscribe(&"DriverActionInterrupted", _on_driver_interrupted_event)
	EventBus.subscribe(&"ControlledEntityRequested", _on_controlled_entity_requested)
	EventBus.subscribe(&"ActionDefinitionRegisterRequested", _on_definition_register_requested)
	EventBus.subscribe(&"ActionDefinitionGetRequested", _on_definition_get_requested)
	EventBus.subscribe(&"ActionGetRequested", _on_get_action_requested)
	EventBus.subscribe(&"ActionCancelRequested", _on_cancel_action_requested)
	EventBus.subscribe(&"EntityDied", _on_entity_died)
	EventBus.subscribe(&"ActionStartRequested", _on_action_start_requested)
	EventBus.subscribe(&"ActionInterruptRequested", _on_action_interrupt_requested)
	EventBus.subscribe(&"EntityRemoved", _on_entity_removed_event)
	register_definition({"id": &"wait", "name": "Ожидание", "type": &"utility", "base_duration": 0.01, "interruptible": true})
	register_definition({"id": &"attack", "name": "Удар", "type": &"physical", "base_duration": 0.7, "interruptible": true})
	register_definition({"id": &"stagger", "name": "Пошатывание", "type": &"utility", "base_duration": 0.2, "interruptible": true})

## Метаданные сохраняются без игровых формул. Неизвестные поля сохраняются.
func register_definition(data: Dictionary) -> bool:
	var id := StringName(str(data.get("id", "")))
	var kind := StringName(str(data.get("type", "")))
	var duration := float(data.get("base_duration", 0.0))
	if id == &"" or _definitions.has(id) or kind not in [&"physical", &"magical", &"utility"] or _duration_steps(duration) == 0:
		return false
	if str(data.get("name", "")).is_empty() or (data.has("phase_completion") and not data["phase_completion"] is bool):
		return false
	var trigger = data.get("phase_trigger","completion")
	if not trigger is String or trigger not in ["completion","midpoint"] or (trigger == "midpoint" and data.get("phase_completion",false) != true): return false
	var definition := data.duplicate(true)
	definition["phase_trigger"] = trigger
	definition["id"] = id
	definition["type"] = kind
	definition["interruptible"] = bool(data.get("interruptible", true))
	definition["phase_completion"] = data.get("phase_completion",false)
	definition["floor"] = data.get("floor", null)
	definition["stamina_cost"] = data.get("stamina_cost", null)
	definition["mp_cost"] = data.get("mp_cost", null)
	definition["speed_stat"] = data.get("speed_stat", null)
	definition["tags"] = data.get("tags", []).duplicate(true)
	definition["weapon_type"] = data.get("weapon_type", null)
	_definitions[id] = definition
	return true

func get_definition(action_id: StringName) -> Dictionary:
	return _definitions[action_id].duplicate(true) if _definitions.has(action_id) else {}

## Назначение меняется только когда нет активного контролируемого действия.
func set_controlled_entity(entity_id: StringName) -> bool:
	if entity_id == &"" or _driver_active or _active.has(entity_id) or (_controlled_entity != &"" and _active.has(_controlled_entity)):
		return false
	_controlled_entity = entity_id
	return true

## duration_override < 0 означает базовую длительность.
func start_action(entity_id: StringName, action_id: StringName, duration_override: float = -1.0) -> bool:
	if entity_id == &"" or _active.has(entity_id) or not _definitions.has(action_id) or _changing_controlled:
		return false
	var start_guard := {"entity":entity_id, "action":action_id, "allowed":true}
	EventBus.publish(&"ActionStartAllowedRequested", start_guard)
	if not start_guard.get("allowed", false): return false
	if not _mode_allows_action(entity_id, action_id):
		return false
	var alive := {"entity": entity_id, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	if not alive["allowed"]:
		return false
	var duration := _resolve_duration(action_id, duration_override)
	var steps := _duration_steps(duration)
	if steps == 0:
		return false
	var controlled := entity_id == _controlled_entity
	if controlled and _driver_active:
		return false
	_install(entity_id, action_id, steps)
	if controlled:
		_changing_controlled = true
		var request := {"action": action_id, "duration": duration, "accepted": false}
		EventBus.publish(&"TimeStartRequested", request)
		var started: bool = request["accepted"]
		_driver_active = started
		_changing_controlled = false
		if not started:
			_remove(entity_id)
			return false
	_emit_started(entity_id, action_id)
	return true

# Продление только существующего блока; единый таймер и реестр меняются атомарно.
func extend_shield_block(entity: StringName) -> bool:
	if TimeDriver._stepping or TimeDriver._settling or not _active.has(entity): return false
	var action: Dictionary = _active[entity]
	if action.get("id",null) != &"shield_block" or action["steps"] > 999999950: return false
	if entity == _controlled_entity:
		if not _driver_active or not TimeDriver._active or TimeDriver._action_id != &"shield_block" or TimeDriver._action_steps != action["steps"]: return false
		TimeDriver._action_steps += 50
	action["steps"] += 50
	return true

## Обычная замена учитывает interruptible; force — для исключительных эффектов.
func interrupt_with(entity_id: StringName, action_id: StringName, duration_override: float = -1.0, force: bool = false) -> bool:
	if not _active.has(entity_id) or not _definitions.has(action_id) or _changing_controlled:
		return false
	var start_guard := {"entity":entity_id, "action":action_id, "allowed":true}
	EventBus.publish(&"ActionStartAllowedRequested", start_guard)
	if not start_guard.get("allowed", false): return false
	if not _mode_allows_action(entity_id, action_id):
		return false
	var alive := {"entity": entity_id, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	if not alive["allowed"]:
		return false
	var old: Dictionary = _active[entity_id]
	if not force and not bool(_definitions[old["id"]]["interruptible"]):
		return false
	var duration := _resolve_duration(action_id, duration_override)
	var steps := _duration_steps(duration)
	if steps == 0:
		return false
	var old_id: StringName = old["id"]
	var controlled := entity_id == _controlled_entity
	if controlled and not _driver_active:
		return false
	_remove(entity_id)
	_install(entity_id, action_id, steps)
	if controlled:
		_changing_controlled = true
		var request := {"action": action_id, "duration": duration, "accepted": false}
		EventBus.publish(&"TimeInterruptRequested", request)
		var replaced: bool = request["accepted"]
		_changing_controlled = false
		if not replaced:
			_remove(entity_id)
			_active[entity_id] = old
			_order.append(entity_id)
			return false
	_emit_interrupted(entity_id, old_id, float(old["elapsed"]) * 0.01, &"replaced")
	_emit_started(entity_id, action_id)
	return true

func entity_removed(entity_id: StringName) -> void:
	cancel_action(entity_id, &"entity_removed")

func cancel_action(entity_id: StringName, reason: StringName = &"cancelled") -> bool:
	if not _active.has(entity_id) or _changing_controlled:
		return false
	var action_id: StringName = _active[entity_id]["id"]
	var elapsed: float = _active[entity_id]["elapsed"] * 0.01
	_remove(entity_id)
	if entity_id == _controlled_entity and _driver_active:
		_changing_controlled = true
		var request := {"accepted": false}
		EventBus.publish(&"TimeCancelRequested", request)
		_driver_active = false
		_changing_controlled = false
	_emit_interrupted(entity_id, action_id, elapsed, reason)
	return true

func get_active_action(entity_id: StringName) -> Dictionary:
	if not _active.has(entity_id):
		return {}
	var action: Dictionary = _active[entity_id]
	return {"id": action["id"], "duration": action["steps"] * 0.01, "elapsed": action["elapsed"] * 0.01, "interruptible": bool(_definitions[action["id"]]["interruptible"])}

func _on_tick(event: Dictionary) -> void:
	_phase_due.clear()
	_phase_finishes.clear()
	_game_time = float(event["game_time"])
	var snapshot: Array = []
	for entity_id in _order:
		snapshot.append([entity_id, _active[entity_id]])
	for entry in snapshot:
		var entity_id: StringName = entry[0]
		var action: Dictionary = entry[1]
		if not _active.has(entity_id) or not is_same(_active[entity_id], action):
			continue
		if entity_id != _controlled_entity:
			var allowed := {"entity": entity_id, "allowed": true}
			EventBus.publish(&"AIEntityTickAllowedRequested", allowed)
			if not allowed["allowed"]:
				continue
		if action["created_at"] == _game_time:
			continue
		action["elapsed"] += 1
		_midpoint_processed[entity_id] = true
		# Фазовый момент и завершение — независимые события. Середина при
		# нечётной длительности переносится на следующий целый шаг.
		var definition: Dictionary = _definitions[action["id"]]
		if definition.get("phase_completion",false) == true:
			var trigger: String = definition.get("phase_trigger","completion")
			var trigger_step: int = ceili(float(action["steps"]) / 2.0) if trigger == "midpoint" else action["steps"]
			if action["elapsed"] == trigger_step: _phase_due.append([entity_id,action])
			if action["elapsed"] >= action["steps"]: _phase_finishes.append([entity_id,action])
		elif entity_id != _controlled_entity and action["elapsed"] >= action["steps"]:
			var action_id: StringName = action["id"]
			_remove(entity_id)
			_emit_finished(entity_id, action_id)
	_midpoint_tick_complete = true

# Вызывается только TimeDriver между tick и завершением действий. Это список
# готовности, а не неизменяемый снимок всего мира или разрешение ударов.
func combat_phase_due() -> Array:
	var result: Array = []
	for entry in _phase_due:
		var entity: StringName = entry[0]
		var action: Dictionary = entry[1]
		if not _active.has(entity) or not is_same(_active[entity],action): continue
		result.append({"entity":entity,"action":action["id"],"elapsed_steps":action["elapsed"],"duration_steps":action["steps"]})
	result.sort_custom(func(a,b): return str(a["entity"]) < str(b["entity"]))
	return result

func finish_combat_phase() -> void:
	var due: Array = _phase_finishes.duplicate()
	_phase_due.clear()
	_phase_finishes.clear()
	for entry in due:
		var entity: StringName = entry[0]
		var action: Dictionary = entry[1]
		if entity == _controlled_entity or not _active.has(entity) or not is_same(_active[entity],action): continue
		var id: StringName = action["id"]
		_remove(entity)
		_emit_finished(entity,id)

func _on_driver_finished(action_id: StringName, _elapsed: float) -> void:
	_driver_active = false
	if _changing_controlled or not _active.has(_controlled_entity):
		return
	if _active[_controlled_entity]["id"] != action_id:
		return
	var entity_id := _controlled_entity
	_remove(entity_id)
	_emit_finished(entity_id, action_id)

func _on_driver_interrupted(action_id: StringName, _elapsed: float) -> void:
	if not _changing_controlled:
		_driver_active = false
	# Если TimeDriver был вызван напрямую, не оставляем старую запись в реестре.
	if _changing_controlled or not _active.has(_controlled_entity):
		return
	if _active[_controlled_entity]["id"] != action_id:
		return
	var entity_id := _controlled_entity
	_remove(entity_id)
	_emit_interrupted(entity_id, action_id, _elapsed, &"driver_interrupted")

# Вызывается только MovementService в ресурсной фазе, до Tick реестра.
func retime_move_after_tick(entity: StringName, remaining_steps: int) -> bool:
	if not TimeDriver._stepping or not _active.has(entity) or remaining_steps < 0: return false
	var action: Dictionary = _active[entity]
	if action["id"] != &"move" or action["created_at"] == _game_time: return false
	var target: int = int(action["elapsed"]) + 1 + remaining_steps
	if target > 1000000000: return false
	if entity == _controlled_entity:
		if not _driver_active or not TimeDriver.retime_move_after_tick(remaining_steps): return false
	action["steps"] = target
	return true

func _install(entity_id: StringName, action_id: StringName, steps: int) -> void:
	_active[entity_id] = {"id": action_id, "steps": steps, "elapsed": 0, "created_at": _game_time}
	_order.append(entity_id)

func _remove(entity_id: StringName) -> void:
	_active.erase(entity_id)
	_order.erase(entity_id)

func _mode_allows_action(entity_id: StringName, action_id: StringName) -> bool:
	if entity_id != _controlled_entity or not _definitions.has(action_id):
		return true
	var tags: Array = _definitions[action_id].get("tags", [])
	if action_id != &"rest" and not tags.has("rest") and not tags.has(&"rest"):
		return true
	var mode := {"rest_allowed": true}
	EventBus.publish(&"GameModeGetRequested", mode)
	return mode["rest_allowed"]

func _resolve_duration(action_id: StringName, duration_override: float) -> float:
	return float(_definitions[action_id]["base_duration"]) if duration_override < 0.0 else duration_override

func _duration_steps(duration: float) -> int:
	if not is_finite(duration) or duration <= 0.0 or duration / 0.01 > 1000000000.0:
		return 0
	var steps := int(round(duration / 0.01))
	if steps < 1 or absf(steps * 0.01 - duration) > 0.000001:
		return 0
	return steps

func _emit_started(entity_id: StringName, action_id: StringName) -> void:
	action_started.emit(entity_id, action_id)
	EventBus.publish(&"ActionStarted", {"entity": entity_id, "action": action_id})

func _emit_finished(entity_id: StringName, action_id: StringName) -> void:
	action_finished.emit(entity_id, action_id)
	EventBus.publish(&"ActionCompleted", {"entity": entity_id, "action": action_id})

func _emit_interrupted(entity_id: StringName, action_id: StringName, elapsed: float, reason: StringName) -> void:
	action_interrupted.emit(entity_id, action_id, reason)
	EventBus.publish(&"ActionInterrupted", {"entity": entity_id, "action": action_id, "elapsed": elapsed, "reason": reason})

func _on_driver_completed_event(event: Dictionary) -> void:
	_on_driver_finished(event["action"], event["elapsed"])

func _on_driver_interrupted_event(event: Dictionary) -> void:
	_on_driver_interrupted(event["action"], event["elapsed"])

func _on_action_start_requested(event: Dictionary) -> void:
	event["accepted"] = start_action(event.get("entity", &""), event.get("action", &""), event.get("duration", -1.0))

func _on_action_interrupt_requested(event: Dictionary) -> void:
	event.erase("deferred")
	var entity = event.get("entity", &"")
	if _should_defer_weapon_midpoint(entity):
		var replacement = event.get("action",null)
		var duration = event.get("duration",-1.0)
		var force = event.get("force",false)
		event["accepted"] = false
		if _midpoint_deferred.has(entity) or not replacement is StringName or not _definitions.has(replacement) or not (duration is int or duration is float) or not is_finite(float(duration)) or not force is bool: return
		if not force and not bool(_definitions[&"weapon_strike"].get("interruptible",false)): return
		if _duration_steps(_resolve_duration(replacement,float(duration))) == 0: return
		_midpoint_deferred[entity] = {"kind":"replace","original":_active[entity],"action":replacement,"duration":float(duration),"force":force}
		event["accepted"] = true; event["deferred"] = true
		return
	event["accepted"] = interrupt_with(event.get("entity", &""), event.get("action", &""), event.get("duration", -1.0), event.get("force", false))

func _on_entity_removed_event(event: Dictionary) -> void:
	entity_removed(event.get("entity", &""))

func _on_time_step_started(event: Dictionary) -> void:
	_game_time = float(event["game_time"])
	_midpoint_processed.clear()
	_midpoint_step = TimeDriver._total_steps
	_midpoint_tick_complete = false

func _on_controlled_entity_requested(event: Dictionary) -> void:
	event["accepted"] = set_controlled_entity(event.get("entity", &""))

func _snapshot_collect(event: Dictionary) -> void:
	if _changing_controlled or _midpoint_resolving or not _midpoint_deferred.is_empty():
		event["errors"].append("Нельзя сохранять во время изменения действия")
		return
	event["sections"]["actions"] = {"definitions": _definitions.duplicate(true), "active": _active.duplicate(true), "order": _order.duplicate(), "controlled": _controlled_entity, "game_time": _game_time, "driver_active": _driver_active}

func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["actions"]
	_definitions = data["definitions"].duplicate(true)
	_active = data["active"].duplicate(true)
	_order.clear()
	for entity in data["order"]:
		_order.append(entity)
	_controlled_entity = data["controlled"]
	_game_time = data["game_time"]
	_driver_active = data["driver_active"]
	_changing_controlled = false
	_phase_due.clear()
	_phase_finishes.clear()
	_midpoint_processed.clear()
	_midpoint_step = -1
	_midpoint_tick_complete = false
	_midpoint_deferred.clear()
	_midpoint_resolving = false

func _on_definition_register_requested(event: Dictionary) -> void:
	event["accepted"] = register_definition(event.get("data", {}))

func _on_definition_get_requested(event: Dictionary) -> void:
	var data := get_definition(event.get("action", &""))
	event["found"] = not data.is_empty()
	event["data"] = data

func _on_get_action_requested(event: Dictionary) -> void:
	var data := get_active_action(event.get("entity", &""))
	event["found"] = not data.is_empty()
	event["data"] = data

func _on_cancel_action_requested(event: Dictionary) -> void:
	event.erase("deferred")
	var entity: StringName = event.get("entity", &"")
	var reason: StringName = event.get("reason", &"cancelled")
	if _should_defer_weapon_midpoint(entity):
		event["accepted"] = false
		if _midpoint_deferred.has(entity): return
		_midpoint_deferred[entity] = {"kind":"cancel","original":_active[entity],"reason":reason}
		event["accepted"] = true; event["deferred"] = true
		return
	if _changing_controlled and _active.has(entity):
		var expected: StringName = _active[entity]["id"]
		call_deferred("_cancel_if_current", entity, expected, reason)
		event["accepted"] = true
		return
	event["accepted"] = cancel_action(entity, reason)

func _cancel_if_current(entity: StringName, expected: StringName, reason: StringName) -> void:
	if _active.has(entity) and _active[entity]["id"] == expected:
		cancel_action(entity, reason)

# Only ordinary public action requests are deferred; death/removal uses direct
# cancellation and remains immediate. Earlier and later steps are unchanged.
func _should_defer_weapon_midpoint(entity: Variant) -> bool:
	if _midpoint_resolving or not TimeDriver._stepping or not entity is StringName or not _active.has(entity) or _changing_controlled or CombatService.is_entity_dead(entity): return false
	if _midpoint_step != TimeDriver._total_steps:
		_midpoint_processed.clear()
		_midpoint_step = TimeDriver._total_steps
		_midpoint_tick_complete = false
	if _midpoint_tick_complete and not _midpoint_processed.has(entity): return false
	var a: Dictionary = _active[entity]
	if a.get("id",null) != &"weapon_strike" or a.get("created_at",null) == TimeDriver.game_time: return false
	var midpoint: int = ceili(float(a["steps"]) / 2.0)
	var elapsed: int = a["elapsed"]
	return elapsed == midpoint if _midpoint_processed.has(entity) else elapsed + 1 == midpoint

# Called after the phase packet is resolved, before phase completions.
func resolve_weapon_midpoint_interruptions() -> void:
	if not TimeDriver._stepping or TimeDriver._combat_phase or _midpoint_resolving: return
	_midpoint_resolving = true
	var ids: Array = _midpoint_deferred.keys()
	ids.sort_custom(func(a,b): return str(a) < str(b))
	for entity in ids:
		var request: Dictionary = _midpoint_deferred[entity]
		var applied := false
		var reason := "action_changed"
		if _active.has(entity) and is_same(_active[entity],request["original"]) and not CombatService.is_entity_dead(entity):
			if request["kind"] == "cancel": applied = cancel_action(entity,request["reason"])
			else: applied = interrupt_with(entity,request["action"],request["duration"],request["force"])
			reason = "applied" if applied else "revalidation_failed"
		_midpoint_deferred.erase(entity)
		EventBus.publish(&"WeaponStrikeDeferredInterruptionResolved", {"entity":entity,"kind":request["kind"],"applied":applied,"reason":reason})
	_midpoint_resolving = false

func _on_entity_died(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if _changing_controlled:
		call_deferred("cancel_action", entity, &"entity_died")
	else:
		cancel_action(entity, &"entity_died")
