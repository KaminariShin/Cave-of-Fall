extends Node
## Изучение экипировки управляемого персонажа от завершённых действий.
## Действие должно начаться, пока предмет надет; меню не учитываются.
var _pending: Dictionary = {} # actor -> {action, items}
var _finished_weapons: Dictionary = {} # лишь внутри публикации ActionCompleted
var _commit_weapon: StringName = &""
var _unequipped: Dictionary = {} # только синхронный интервал завершения
var _busy := false
var _commit_actor: StringName = &""
var _commit_ids: Array = []

func _ready() -> void:
	EventBus.subscribe(&"WeaponStrikeFinished", _weapon_finished)
	EventBus.subscribe(&"BowShotFinished", _bow_finished)
	EventBus.subscribe(&"ActionStarted", _started)
	EventBus.subscribe(&"ActionCompleted", _completed)
	EventBus.subscribe(&"ActionInterrupted", _interrupted)
	EventBus.subscribe(&"ItemUnequipped", _unequipped_event)
	EventBus.subscribe(&"EntityRemoved", _removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"ItemLearningProgressSnapshotValidateRequested", _validate)

func _controlled(actor: StringName) -> bool:
	var mode := {}
	EventBus.publish(&"GameModeGetRequested",mode)
	return mode.get("entity",null) == actor and not CombatService.is_entity_dead(actor)

func _eligible_equipped(actor: StringName) -> Array:
	var q := {"entity":actor,"component":&"equipment","found":false}
	EventBus.publish(&"ComponentGetRequested",q)
	var out: Array = []
	if not q.get("found",false) or not q.get("data",null) is Dictionary: return out
	for slot in ["main","off","head","body","hands","belt","legs","feet","ring1","ring2","amulet","cloak"]:
		var id = q["data"].get(slot,null)
		if not id is StringName or id == &"" or out.has(id): continue
		var item := {"item":id,"found":false}
		EventBus.publish(&"ItemGetRequested",item)
		if not item.get("found",false): continue
		var data: Dictionary = item["item_data"]
		if data.get("learning",{}).get("progress_kind",null) != "owner_actions" or data.get("learning_state",{}).get("identified",null) != false: continue
		var base_slot := str(item["base"].get("slot",""))
		if slot in ["main","off"] and base_slot != "shield": continue
		if slot not in ["main","off"] and base_slot != slot: continue
		out.append(id)
	return out

func _started(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	var action = e.get("action",null)
	if _busy or not actor is StringName or not action is StringName or action == &"menu_transition" or not _controlled(actor): return
	_busy = true
	var ids := _eligible_equipped(actor)
	if not ids.is_empty(): _pending[actor] = {"action":action,"items":ids}
	_busy = false

func _unequipped_event(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	var item = e.get("item",null)
	if not _pending.has(actor) or _pending[actor]["action"] != &"equipment_unequip" or not _pending[actor]["items"].has(item): return
	_unequipped[actor] = item

func _bow_finished(e: Dictionary) -> void:
	_weapon_finished_common(e,true)
func _weapon_finished(e: Dictionary) -> void:
	_weapon_finished_common(e,false)
func _weapon_finished_common(e: Dictionary, bow: bool) -> void:
	var actor = e.get("entity",null)
	var data = e.get("data",null)
	if _busy or not actor is StringName or not data is Dictionary or not data.get("item",null) is StringName: return
	var id: StringName = data["item"]
	if not (BowShotActionService.authorizes_finished(actor,id) if bow else WeaponStrikeActionService.authorizes_finished(actor,id)) or not _controlled(actor): return
	var gear := {"entity":actor,"component":&"equipment"}
	EventBus.publish(&"ComponentGetRequested",gear)
	if not gear.get("found",false) or (gear["data"].get("main",null) != id and gear["data"].get("off",null) != id): return
	var item := {"item":id}
	EventBus.publish(&"ItemGetRequested",item)
	if not item.get("found",false) or item["item_data"].get("learning",{}).get("progress_kind",null) != "weapon_strikes" or item["item_data"].get("learning_state",{}).get("identified",null) != false: return
	_finished_weapons[actor]=id

func _completed(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	var weapon = _finished_weapons.get(actor,null) if e.get("action",null) in [&"weapon_strike", &"bow_shot"] else null
	if (not _pending.has(actor) or _pending[actor]["action"] != e.get("action",null)) and weapon == null: return
	var pending: Dictionary = _pending.get(actor,{"items":[]})
	if _busy:
		_pending.erase(actor); _unequipped.erase(actor); _finished_weapons.erase(actor); return
	_busy = true
	var controlled := _controlled(actor)
	var current: Array = _eligible_equipped(actor) if controlled else []
	var completed_unequip = _unequipped.get(actor,null) if controlled else null
	var selected: Array = []
	for id in pending["items"]:
		if current.has(id) or completed_unequip == id:
			var item := {"item":id,"found":false}
			EventBus.publish(&"ItemGetRequested",item)
			if item.get("found",false) and item["item_data"].get("learning_state",{}).get("identified",null) == false: selected.append(id)
	if controlled and weapon is StringName and not selected.has(weapon): selected.append(weapon)
	var old_stats: Dictionary = StatsService.capture_equipment_stats(actor)
	_commit_actor = actor
	_commit_ids = selected.duplicate()
	_commit_weapon = weapon if weapon is StringName and selected.has(weapon) else &""
	var ok := selected.is_empty() or ItemService.advance_equipped_learning(actor,selected,_commit_weapon)
	_commit_actor = &""
	_commit_ids.clear()
	_commit_weapon = &""
	_pending.erase(actor)
	_unequipped.erase(actor)
	_finished_weapons.erase(actor)
	_busy = false
	if not ok:
		EventBus.publish(&"ItemLearningProgressFailed", {"entity":actor,"items":selected})
		return
	StatsService.notify_equipment_stats_change(actor,old_stats)
	# Все изменения уже сделаны, слушатели видят завершённый пакет.
	for id in selected:
		var item := {"item":id,"found":false}
		EventBus.publish(&"ItemGetRequested",item)
		if item.get("found",false): EventBus.publish(&"ItemLearningProgressChanged", {"entity":actor,"item":id,"state":item["item_data"]["learning_state"].duplicate(true)})

func authorizes_commit(actor: StringName, ids: Array, weapon: StringName) -> bool:
	return _busy and actor == _commit_actor and ids == _commit_ids and weapon == _commit_weapon

func _interrupted(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if _pending.has(actor) and _pending[actor]["action"] == e.get("action",null):
		_pending.erase(actor)
		_unequipped.erase(actor)
func _removed(e: Dictionary) -> void:
	_finished_weapons.erase(e.get("entity",null))
	_pending.erase(e.get("entity",null))
	_unequipped.erase(e.get("entity",null))
func _collect(e: Dictionary) -> void:
	if _busy or not _finished_weapons.is_empty(): e["errors"].append("Нельзя сохранять во время изменения изучения"); return
	e["sections"]["item_learning_progress"] = _pending.duplicate(true)
func _apply(e: Dictionary) -> void:
	_pending = e["sections"]["item_learning_progress"].duplicate(true)
	_unequipped.clear()
	_finished_weapons.clear()
	_commit_weapon = &""
	_busy = false
	_commit_actor = &""
	_commit_ids.clear()
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var s = e.get("sections",null)
	if not s is Dictionary or not s.get("item_learning_progress",null) is Dictionary or not s.get("actions",{}).get("active",null) is Dictionary or not s.get("items",{}).get("instances",null) is Dictionary or not s.get("entities",null) is Dictionary: return
	var pending: Dictionary = s["item_learning_progress"]
	for actor in pending:
		var p = pending[actor]
		if not actor is StringName or actor != s["actions"].get("controlled",null) or not s["entities"].has(actor) or not p is Dictionary or not p.get("action",null) is StringName or p["action"] == &"menu_transition" or not p.get("items",null) is Array or p["items"].is_empty() or p["items"].size() > 12: return
		var active = s["actions"]["active"].get(actor,null)
		if not active is Dictionary or active.get("id",null) != p["action"]: return
		var seen := {}
		for id in p["items"]:
			if not id is StringName or id == &"" or seen.has(id) or not s["items"]["instances"].has(id): return
			seen[id] = true
			var item = s["items"]["instances"][id]
			if not item is Dictionary or item.get("learning",{}).get("progress_kind",null) != "owner_actions": return
	# Защита от снимка в узком промежутке между запуском действия и
	# получением ActionStarted этим сервисом.
	var controlled = s["actions"].get("controlled",null)
	if controlled is StringName and s["actions"]["active"].has(controlled) and not pending.has(controlled) and s["entities"].has(controlled):
		var action = s["actions"]["active"][controlled]
		var gear = s["entities"][controlled].get(&"equipment",{}) if s["entities"][controlled] is Dictionary else {}
		if action is Dictionary and action.get("id",null) != &"menu_transition" and gear is Dictionary:
			for slot in ["main","off","head","body","hands","belt","legs","feet","ring1","ring2","amulet","cloak"]:
				var id = gear.get(slot,null)
				if not id is StringName or not s["items"]["instances"].has(id): continue
				var item = s["items"]["instances"][id]
				if not item is Dictionary or item.get("learning",{}).get("progress_kind",null) != "owner_actions" or item.get("learning_state",{}).get("identified",null) != false: continue
				var base = s["items"].get("bases",{}).get(item.get("base_id",null),{})
				if not base is Dictionary: continue
				var base_slot := str(base.get("slot",""))
				if (slot in ["main","off"] and base_slot == "shield") or (slot not in ["main","off"] and base_slot == slot): return
	e["valid"] = true
