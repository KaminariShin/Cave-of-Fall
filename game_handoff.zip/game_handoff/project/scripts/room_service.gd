extends Node
## Комнаты в логических клетках, границы и проёмы — в физических тайлах.
var _dimensions: Dictionary = {}
var _weights: Dictionary = {}
var _exit_counts: Dictionary = {}
var _scale := 4
var _rooms: Dictionary = {}
var _controlled: StringName = &""
var _current_room: StringName = &""
var _pending: Dictionary = {} # переход игрока через общий проём
var _deadend_budget := 0
var _sequence := 0
var _busy := false
var _incomplete: Dictionary = {}
var _just_finished_at: Variant = null
var _cave_enabled := false
var _cave_seed := 0
var _guard_width := 9
var _guard_depth := 6

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var parameters: Dictionary = rules["ruleset"].get("parameters", {})
		var room_data: Dictionary = parameters.get("rooms", {})
		_dimensions = room_data.get("dimensions", {}).duplicate(true)
		_weights = room_data.get("child_weights", {}).duplicate(true)
		_exit_counts = room_data.get("child_exits", {}).duplicate(true)
		_scale = int(parameters.get("space", {}).get("tiles_per_cell", 4))
		var cave: Dictionary = parameters.get("cave_generation", {})
		_guard_width = int(cave.get("guard_width", 9))
		_guard_depth = int(cave.get("guard_depth", 6))
	EventBus.subscribe(&"RoomCaveConfigureRequested", _cave_configure)
	EventBus.subscribe(&"RoomAllGetRequested", _all_rooms)
	EventBus.subscribe(&"RoomGenerationStatusGetRequested", _generation_status)
	EventBus.subscribe(&"RoomCreateRequested", _create_requested)
	EventBus.subscribe(&"RoomGetRequested", _get_requested)
	EventBus.subscribe(&"RoomCurrentGetRequested", _current_requested)
	EventBus.subscribe(&"RoomExitAddRequested", _add_exit_requested)
	EventBus.subscribe(&"RoomExitConnectRequested", _connect_requested)
	EventBus.subscribe(&"RoomChildTypeRollRequested", _child_roll_requested)
	EventBus.subscribe(&"RoomChildGenerateRequested", _child_generate_requested)
	EventBus.subscribe(&"RoomGenerationConfigureRequested", _generation_configure)
	EventBus.subscribe(&"RoomConnectivityRepairRequested", _repair_requested)
	EventBus.subscribe(&"RoomEnterRequested", _enter_requested)
	EventBus.subscribe(&"DiscoveredRoomsGetRequested", _discovered_requested)
	EventBus.subscribe(&"ControlledEntityRequested", _controlled_requested)
	EventBus.subscribe(&"SpacePassageEntered", _passage_entered)
	EventBus.subscribe(&"EntityMoved", _entity_moved)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"SpaceMapConfigured", _map_configured)
	EventBus.subscribe(&"SpaceTilesChanged", _terrain_changed)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)

func _map_configured(_event: Dictionary) -> void:
	_rooms.clear()
	_incomplete.clear()
	_current_room = &""
	_pending.clear()
	_sequence = 0
	_cave_enabled = false
	_cave_seed = 0

func _cave_configure(event: Dictionary) -> void:
	event["accepted"] = false
	if _busy or not _rooms.is_empty() or not event.get("enabled", null) is bool or not event.get("seed", null) is int: return
	_cave_enabled = event["enabled"]
	_cave_seed = event["seed"]
	event["accepted"] = true
func _all_rooms(event: Dictionary) -> void:
	event["rooms"] = _rooms.duplicate(true)

func _generation_status(event: Dictionary) -> void:
	event["incomplete"] = not _incomplete.is_empty()
	event["data"] = _incomplete.duplicate(true)

func _mark_incomplete(data: Dictionary) -> void:
	_incomplete = data.duplicate(true)
	EventBus.publish(&"RoomGenerationIncomplete", data.duplicate(true))

func _terrain_changed(event: Dictionary) -> void:
	if _busy or not _cave_enabled: return
	var tiles: Array = event.get("tiles", [])
	var affected: Array = []
	for id in _rooms:
		var room: Dictionary = _rooms[id]
		if not room.get("generated_cave", false): continue
		var bounds := Rect2i(room["origin_cell"] * _scale, room["size_cells"] * _scale)
		for tile in tiles:
			if tile is Vector2i and bounds.has_point(tile):
				affected.append(id)
				break
	if affected.is_empty(): return
	_busy = true
	for id in affected:
		if not _repair_generated(id): EventBus.publish(&"RoomGeometryRepairFailed", {"room": id})
	_busy = false

func _controlled_requested(event: Dictionary) -> void:
	if event.get("accepted", false):
		_controlled = event.get("entity", &"")
		_current_room = &""
		_pending.clear()

func _entity_removed(event: Dictionary) -> void:
	if event.get("entity", &"") == _controlled:
		_controlled = &""
		_current_room = &""
		_pending.clear()

func _generation_configure(event: Dictionary) -> void:
	event["accepted"] = false
	if _busy or not _incomplete.is_empty(): return
	var budget = event.get("deadend_budget", null)
	if not budget is int or budget < 0:
		return
	_deadend_budget = budget
	event["accepted"] = true

func _create_requested(event: Dictionary) -> void:
	event["accepted"] = false
	if _busy or not _incomplete.is_empty():
		return
	_busy = true
	var room_id := StringName(str(event.get("id", "")))
	var room_type := str(event.get("type", ""))
	var origin = event.get("origin_cell", null)
	var size = event.get("size_cells", null)
	if size == null:
		size = _roll_size(room_type, str(event.get("orientation", "vertical")))
	if room_id != &"" and origin is Vector2i and size is Vector2i and _create_room(room_id, room_type, origin, size):
		event["accepted"] = true
		event["size_cells"] = size
	_busy = false

func _create_room(id: StringName, type: String, origin: Vector2i, size: Vector2i, parent_id: StringName = &"", entry_dir: String = "", defer_notice: bool = false) -> bool:
	if _rooms.has(id) or not _valid_size(type, size) or not _room_fits(origin, size, type, parent_id):
		return false
	var origin_tile := origin * _scale
	var tile_size := size * _scale
	var perimeter: Array = []
	var interior: Array = []
	for x in range(tile_size.x):
		for y in range(tile_size.y):
			var tile := origin_tile + Vector2i(x, y)
			if x == 0 or y == 0 or x == tile_size.x - 1 or y == tile_size.y - 1:
				perimeter.append(tile)
			else:
				interior.append(tile)
	if _cave_enabled:
		var geometry := {"id": id, "type": type, "origin": origin, "size": size, "seed": _cave_seed, "entry_dir": entry_dir, "accepted": false}
		EventBus.publish(&"CaveGeometryBuildRequested", geometry)
		if not geometry["accepted"]: return false
		interior.clear()
		var logical_floor := {}
		for cell in geometry["cells"]: logical_floor[cell] = true
		for cell in geometry["cells"]:
			for dx in range(_scale):
				for dy in range(_scale): interior.append(origin_tile + cell * _scale + Vector2i(dx,dy))
		# Все внутренние логические клетки стены у пола получают карман.
		# Полные клетки пола и внешний периметр остаются нетронутыми.
		if _scale == 4:
			var detail_seed := int(_cave_seed) ^ int(("detail:%s:%s:%d:%d" % [id, type, origin.x, origin.y]).hash())
			for x in range(1,size.x-1):
				for y in range(1,size.y-1):
					var cell := Vector2i(x,y)
					if logical_floor.has(cell): continue
					var neighbors: Array = []
					for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
						if logical_floor.has(cell+d): neighbors.append(d)
					if neighbors.is_empty(): continue
					# В углу выбираем одну сторону, чтобы не пробивать стену насквозь.
					var toward: Vector2i = neighbors[0]
					var is_vertical: bool = toward.x != 0
					var first_side := Vector2i.UP if is_vertical else Vector2i.LEFT
					var last_side := Vector2i.DOWN if is_vertical else Vector2i.RIGHT
					var trim_first: bool = logical_floor.has(cell+first_side)
					var trim_last: bool = logical_floor.has(cell+last_side)
					var budget := 10
					for column in range(4):
						if (column == 0 and trim_first) or (column == 3 and trim_last): continue
						# Значение меняется группами по три физических клетки,
						# так что соседние столбцы не скачут на всю глубину стены.
						var along: int = (y if is_vertical else x) * 4 + column
						var boundary: int = x if is_vertical else y
						var band: int = floori(float(along) / 3.0)
						var hash_value: int = absi(int(("%d:%d:%d:%d:%d" % [detail_seed,toward.x,toward.y,boundary,band]).hash()))
						var depth: int = 1 + hash_value % 3
						if trim_first or trim_last or column == 0 or column == 3: depth = mini(depth,2)
						depth = mini(depth,budget)
						budget -= depth
						for step in range(depth):
							var local := Vector2i.ZERO
							if toward == Vector2i.LEFT: local = Vector2i(step,column)
							elif toward == Vector2i.RIGHT: local = Vector2i(3-step,column)
							elif toward == Vector2i.UP: local = Vector2i(column,step)
							else: local = Vector2i(column,3-step)
							interior.append(origin_tile + cell * _scale + local)
			# Округление выпуклых углов: стеновая клетка по диагонали от
			# полного пола получает небольшой связный треугольный карман.
			interior.append_array(_round_diagonal_corners(logical_floor, size, origin_tile, interior))
	# Предварительная проверка исключает повреждение существующего тела/проёма.
	for tile in perimeter:
		var query := {"tile": tile}
		EventBus.publish(&"SpaceTileGetRequested", query)
		if not query.get("in_bounds", false) or query.get("occupant", null) != null or query.get("passage", false):
			return false
	var walls := {"tiles": perimeter, "kind": 0, "accepted": false}
	EventBus.publish(&"SpaceTilesSetRequested", walls)
	if not walls["accepted"]:
		return false
	var floor := {"tiles": interior, "kind": 1, "accepted": false}
	EventBus.publish(&"SpaceTilesSetRequested", floor)
	if not floor["accepted"]:
		return false
	_rooms[id] = {"id": id, "type": type, "origin_cell": origin, "size_cells": size, "exits": [], "discovered": false, "floor_list": [], "generated_cave": _cave_enabled, "parent": parent_id, "guards": _corridor_guards(origin, size) if _cave_enabled and type == "corridor" else []}
	if _cave_enabled and not _repair_generated(id):
		_rooms.erase(id)
		if not interior.is_empty(): EventBus.publish(&"SpaceTilesSetRequested", {"tiles": interior, "kind": 0})
		return false
	if not defer_notice: EventBus.publish(&"RoomCreated", {"room": id, "type": type})
	return true

# Карманы в диагональных к полу стенах закрывают крупную ступень между
# двумя боковыми карманами, не затрагивая ни полный пол, ни периметр.
func _round_diagonal_corners(logical_floor: Dictionary, size: Vector2i, origin_tile: Vector2i, interior: Array) -> Array:
	var existing := {}
	for tile in interior: existing[tile] = true
	var additions: Array = []
	for x in range(1,size.x-1):
		for y in range(1,size.y-1):
			var cell := Vector2i(x,y)
			if logical_floor.has(cell): continue
			var side_floor := false
			for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
				if logical_floor.has(cell+d): side_floor = true
			if side_floor: continue
			var diagonals: Array = []
			for d in [Vector2i(-1,-1),Vector2i(1,-1),Vector2i(1,1),Vector2i(-1,1)]:
				if logical_floor.has(cell+d): diagonals.append(d)
			# Несколько разных диагональных полов: не создаём мост через стену.
			if diagonals.size()!=1: continue
			var direction: Vector2i = diagonals[0]
			var corner: Array = []
			for dx in range(3):
				for dy in range(3):
					if dx+dy>2: continue
					var q := Vector2i(dx if direction.x<0 else 3-dx, dy if direction.y<0 else 3-dy)
					corner.append(origin_tile+cell*4+q)
			var touches := false
			for tile in corner:
				for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
					if existing.has(tile+d): touches = true
			if not touches: continue
			for tile in corner: additions.append(tile)
	return additions

func _current_requested(event: Dictionary) -> void:
	event["entity"] = _controlled
	event["room"] = _current_room
	event["transitioning"] = not _pending.is_empty()

func _get_requested(event: Dictionary) -> void:
	var id := StringName(str(event.get("id", "")))
	event["found"] = _rooms.has(id)
	if event["found"]:
		event["data"] = _rooms[id].duplicate(true)

func _add_exit_requested(event: Dictionary) -> void:
	event["accepted"] = false
	if _busy or not _incomplete.is_empty():
		return
	_busy = true
	event["accepted"] = _add_exit(event.get("room", &""), event.get("id", &""), str(event.get("dir", "")), event.get("offset_cells", -1))
	_busy = false

func _add_exit(room_id: StringName, exit_id: StringName, direction: String, offset: Variant, quiet: bool = false) -> bool:
	if not _rooms.has(room_id) or exit_id == &"" or direction not in ["north", "south", "east", "west"] or not offset is int:
		return false
	var room: Dictionary = _rooms[room_id]
	if _find_exit(room, exit_id) != null:
		return false
	var size: Vector2i = room["size_cells"]
	var along: int = size.x if direction in ["north", "south"] else size.y
	if offset < 1 or offset > along - 2:
		return false
	var origin: Vector2i = room["origin_cell"] * _scale
	var bounds: Vector2i = size * _scale
	var start := origin
	match direction:
		"north": start += Vector2i(offset * _scale, 0)
		"south": start += Vector2i(offset * _scale, bounds.y - 1)
		"west": start += Vector2i(0, offset * _scale)
		"east": start += Vector2i(bounds.x - 1, offset * _scale)
	var step := Vector2i.RIGHT if direction in ["north", "south"] else Vector2i.DOWN
	var tiles: Array = []
	for i in range(_scale):
		var tile := start + step * i
		var query := {"tile": tile}
		EventBus.publish(&"SpaceTileGetRequested", query)
		if not query.get("in_bounds", false) or query.get("occupant", null) != null or query.get("passage", false):
			return false
		tiles.append(tile)
	# До изменения геометрии проверяем действующие сундуки. В пещере
	# допускаем только случай, когда ремонт не будет менять внутренний пол.
	var objects := {"room":room_id, "objects":{}}
	EventBus.publish(&"RoomObjectsGetRequested", objects)
	if not objects.get("objects", null) is Dictionary: return false
	for object_id in objects["objects"]:
		var obj = objects["objects"][object_id]
		if not obj is Dictionary: return false
		if obj.get("type", "") != "chest": continue
		if room.get("generated_cave", false) and not _cave_exit_needs_no_terrain_repair(room, tiles, direction): return false
		var safety := {"room":room_id, "tile":obj.get("tile", null), "existing_object":object_id, "additional_exit":{"x":start.x, "y":start.y, "dirOut":direction}, "accepted":false}
		EventBus.publish(&"DungeonChestPositionPreflightRequested", safety)
		if not safety.get("accepted", false): return false
	var paint := {"tiles": tiles, "kind": 1, "accepted": false}
	EventBus.publish(&"SpaceTilesSetRequested", paint)
	if not paint["accepted"]:
		return false
	var passage := {"tiles": tiles, "enabled": true, "accepted": false}
	EventBus.publish(&"SpacePassageSetRequested", passage)
	if not passage["accepted"]:
		EventBus.publish(&"SpaceTilesSetRequested", {"tiles": tiles, "kind": 0})
		return false
	room["exits"].append({"id": exit_id, "x": start.x, "y": start.y, "dirOut": direction, "offset_cells": offset, "connected": false, "sealed": false, "childId": null, "other_exit": null, "tiles": tiles})
	if not _repair(room_id):
		room["exits"].pop_back()
		EventBus.publish(&"SpacePassageSetRequested", {"tiles": tiles, "enabled": false})
		EventBus.publish(&"SpaceTilesSetRequested", {"tiles": tiles, "kind": 0})
		if not quiet: EventBus.publish(&"RoomExitFailed", {"room": room_id, "exit": exit_id})
		return false
	if not quiet: EventBus.publish(&"RoomExitCreated", {"room": room_id, "exit": exit_id})
	return true

# Строго достаточное условие для безопасного добавления прохода к пещере
# со стоящим сундуком. Если весь существующий пол и новый проём уже связаны
# с неизменным центром, _repair_generated не будет ни прокрашивать, ни
# удалять внутренние тайлы. Отказ не доказывает невозможность безопасного ремонта.
func _cave_exit_needs_no_terrain_repair(room: Dictionary, new_tiles: Array, direction: String) -> bool:
	var origin: Vector2i = room["origin_cell"] * _scale
	var size: Vector2i = room["size_cells"] * _scale
	var region := {"origin":origin, "size":size, "accepted":false}
	EventBus.publish(&"SpaceRegionGetRequested", region)
	if not region.get("accepted", false) or not region.get("floor", null) is Dictionary: return false
	var floor: Dictionary = region["floor"].duplicate()
	for tile in new_tiles: floor[tile] = true
	var center := origin + Vector2i(int(room["size_cells"].x / 2), int(room["size_cells"].y / 2)) * _scale + Vector2i.ONE
	if not floor.has(center): return false
	var reachable := _bfs(center, floor)
	if reachable.size() != floor.size(): return false
	for exit in room["exits"]:
		for tile in exit["tiles"]:
			if not reachable.has(tile): return false
	for tile in new_tiles:
		if not reachable.has(tile): return false
	var exits: Array = room["exits"].duplicate(true)
	exits.append({"tiles":new_tiles,"dirOut":direction})
	for ex in exits:
		for tile in _wide_exit_floor(room,ex):
			if not floor.has(tile): return false
	return true

# Детерминированный коридор допустимых якорей тела 4×4 между центром
# комнаты и внутренней стороной каждого прохода. Не проверяет динамические
# препятствия и не обещает, что последующие события не заблокируют путь.
func _wide_exit_floor(room: Dictionary, exit: Dictionary) -> Array:
	var origin: Vector2i = room["origin_cell"] * _scale
	var size: Vector2i = room["size_cells"] * _scale
	var center := origin + Vector2i(int(size.x / 2) - 2,int(size.y / 2) - 2)
	var target: Vector2i = exit["tiles"][0]
	match str(exit["dirOut"]):
		"north": target.y += 1
		"south": target.y -= 4
		"west": target.x += 1
		"east": target.x -= 4
		_: return []
	var result := {}
	for anchor in _l_path(center,target):
		for x in range(4):
			for y in range(4):
				var tile: Vector2i = anchor + Vector2i(x,y)
				if tile.x > origin.x and tile.y > origin.y and tile.x < origin.x+size.x-1 and tile.y < origin.y+size.y-1:
					result[tile]=true
	return result.keys()

func _connect_requested(event: Dictionary) -> void:
	event["accepted"] = false
	if _busy or not _incomplete.is_empty():
		return
	_busy = true
	event["accepted"] = _connect(event.get("room", &""), event.get("exit", &""), event.get("other_room", &""), event.get("other_exit", &""))
	_busy = false

func _connect(room_id: StringName, exit_id: StringName, other_id: StringName, other_exit_id: StringName, quiet: bool = false) -> bool:
	if not _rooms.has(room_id) or not _rooms.has(other_id) or room_id == other_id:
		return false
	var a = _find_exit(_rooms[room_id], exit_id)
	var b = _find_exit(_rooms[other_id], other_exit_id)
	if a == null or b == null or a["connected"] or b["connected"] or a["sealed"] or b["sealed"]:
		return false
	if _opposite(str(a["dirOut"])) != str(b["dirOut"]):
		return false
	var outward := _direction(str(a["dirOut"]))
	for tile in a["tiles"]:
		if not b["tiles"].has(tile + outward):
			return false
	a["connected"] = true
	a["childId"] = other_id
	a["other_exit"] = other_exit_id
	b["connected"] = true
	b["childId"] = room_id
	b["other_exit"] = exit_id
	if not quiet: EventBus.publish(&"RoomsConnected", {"room": room_id, "exit": exit_id, "other_room": other_id, "other_exit": other_exit_id})
	return true

func _child_roll_requested(event: Dictionary) -> void:
	event["accepted"] = false
	var parent := str(event.get("parent_type", ""))
	var budget = event.get("deadend_budget", _deadend_budget)
	if parent not in ["start", "passage", "fork", "crossroads", "corridor"] or not budget is int or budget < 0:
		return
	var result := _roll_child_type(parent, budget)
	if not result.is_empty():
		event["accepted"] = true
		event["type"] = result

func _roll_child_type(parent: String, budget: int) -> String:
	var choices: Array = []
	var total := 0.0
	for type in ["passage", "fork", "crossroads", "corridor", "deadend"]:
		if type == "corridor" and parent == "corridor":
			continue
		if type == "deadend" and (parent not in ["fork", "crossroads"] or budget <= 0):
			continue
		var weight := float(_weights.get(type, 0.0))
		if weight > 0.0 and is_finite(weight):
			choices.append({"type": type, "weight": weight})
			total += weight
	if choices.is_empty() or not is_finite(total):
		return ""
	var roll := {"accepted": false}
	EventBus.publish(&"RngFloatRequested", roll)
	if not roll["accepted"]:
		return ""
	var sample := float(roll["value"]) * total
	var cumulative := 0.0
	for choice in choices:
		cumulative += choice["weight"]
		if sample < cumulative:
			return choice["type"]
	return choices.back()["type"]

# Первый тип выбирается по весам; прочие идут в стабильном порядке только
# при отсутствии подходящей геометрии. Тупик и коридор ограничены как в броске.
func _fallback_types(parent: String, budget: int, selected: String) -> Array:
	var result: Array = [selected]
	for type in ["passage", "fork", "crossroads", "corridor", "deadend"]:
		if type == selected or not _dimensions.has(type): continue
		if type == "corridor" and parent == "corridor": continue
		if type == "deadend" and (parent not in ["fork", "crossroads"] or budget <= 0): continue
		var weight := float(_weights.get(type, 0.0))
		if weight > 0.0 and is_finite(weight): result.append(type)
	return result

func _possible_sizes(type: String, orientation: String) -> Array:
	var result: Array = []
	if not _dimensions.has(type): return result
	var p: Dictionary = _dimensions[type]
	if type == "corridor":
		for length in range(int(p["long_min"]), int(p["long_max"]) + 1):
			result.append(Vector2i(length, int(p["small"])) if orientation == "horizontal" else Vector2i(int(p["small"]), length))
	else:
		for width in range(int(p["min"]), int(p["max"]) + 1):
			for height in range(int(p["min"]), int(p["max"]) + 1): result.append(Vector2i(width, height))
	return result

func _child_generate_requested(event: Dictionary) -> void:
	event["accepted"] = false
	if not _incomplete.is_empty():
		event["error"] = "Генерация заблокирована после неудачного отката; требуется пересоздать карту"
		return
	if _busy:
		return
	_busy = true
	var result := _generate_child(event.get("room", &""), event.get("exit", &""))
	event.merge(result, true)
	_busy = false

func _generate_child(parent_id: StringName, exit_id: StringName) -> Dictionary:
	if not _incomplete.is_empty(): return {"accepted":false, "error":"Генерация заблокирована после неудачного отката"}
	if not _rooms.has(parent_id):
		return {"accepted": false, "error": "Комната не найдена"}
	var parent: Dictionary = _rooms[parent_id]
	var exit = _find_exit(parent, exit_id)
	if exit == null or exit["connected"] or exit["sealed"]:
		return {"accepted": false, "error": "Выход недоступен"}
	var budget_query := {"room":parent_id, "budget":_deadend_budget, "accepted":false}
	EventBus.publish(&"DungeonDeadendBudgetAvailableRequested", budget_query)
	if not budget_query["accepted"]:
		return {"accepted":false, "error":str(budget_query.get("error", "Не удалось проверить бюджет тупиков"))}
	var available_budget: int = budget_query["budget"]
	var portal_policy := {"room":parent_id, "accepted":false, "required":false}
	EventBus.publish(&"DungeonPortalBranchPolicyRequested", portal_policy)
	if not portal_policy.get("accepted", false): return {"accepted":false, "error":"Не удалось проверить выход за комнатой босса"}
	if portal_policy["required"] and available_budget < 1: return {"accepted":false, "error":"Нет бюджета для тупика за комнатой босса"}
	var child_type := "deadend" if portal_policy["required"] else _roll_child_type(parent["type"], available_budget)
	if child_type.is_empty():
		return {"accepted": false, "error": "Не удалось выбрать тип комнаты"}
	var direction: String = exit["dirOut"]
	var orientation := "horizontal" if direction in ["east", "west"] else "vertical"
	var size = _roll_size(child_type, orientation)
	if not size is Vector2i:
		return {"accepted": false, "error": "Не удалось выбрать размер"}
	var original_type := child_type
	var original_size: Vector2i = size
	var types := ["deadend"] if portal_policy["required"] else _fallback_types(str(parent["type"]), available_budget, original_type)
	var child_id: StringName = &""
	var tried := 0
	for alternative in types:
		var trial_needed := {"room":parent_id, "type":alternative, "accepted":false, "required":false}
		EventBus.publish(&"DungeonStairTrialRequiredRequested", trial_needed)
		if not trial_needed.get("accepted", false): return {"accepted":false, "error":"Не удалось проверить необходимость лестницы"}
		var sizes := _possible_sizes(alternative, orientation)
		if alternative == original_type:
			sizes.erase(original_size)
			sizes.push_front(original_size)
		for candidate_size in sizes:
			for placement in _find_child_origins(parent, exit, candidate_size, alternative):
				var origin: Vector2i = placement["origin"]
				# Не трогаем ничей ранее существовавший пол или проход. Поэтому
				# при неудачной пробе очистка не уничтожит чужую геометрию.
				var before := {"origin":origin * _scale, "size":candidate_size * _scale, "accepted":false}
				EventBus.publish(&"SpaceRegionGetRequested", before)
				if not before["accepted"] or not before["floor"].is_empty() or not before["passages"].is_empty(): continue
				tried += 1
				if child_id == &"":
					while true:
						_sequence += 1
						child_id = StringName("room_%d" % _sequence)
						if not _rooms.has(child_id): break
				if not _create_room(child_id, alternative, origin, candidate_size, parent_id, _opposite(direction), true):
					if not _clear_trial_region(origin, candidate_size):
						_mark_incomplete({"room":child_id, "origin":origin, "reason":"trial_cleanup_failed"})
						return {"accepted":false, "error":"Не удалось безопасно откатить создание комнаты"}
					continue
				if not _add_exit(child_id, &"entry", _opposite(direction), placement["offset"], true):
					if not _rollback_child(child_id, true):
						_mark_incomplete({"room":child_id, "reason":"room_rollback_failed"})
						return {"accepted":false, "error":"Откат занятой комнаты невозможен", "orphan_room":child_id}
					continue
				var count := _add_child_exits(child_id, _opposite(direction), true)
				var needed := int(_exit_counts.get(alternative, 0))
				var viable := count >= needed
				if viable and trial_needed.get("required", false):
					var trial := {"room":child_id, "floor":trial_needed["floor"], "accepted":false}
					EventBus.publish(&"DungeonStairTrialRequested", trial)
					viable = trial.get("accepted", false)
				if viable and portal_policy["required"]:
					var trial := {"room":child_id, "accepted":false}
					EventBus.publish(&"DungeonPortalTrialRequested", trial)
					viable = trial.get("accepted",false)
				if not viable or not _connect(parent_id, exit_id, child_id, &"entry", true):
					if not _rollback_child(child_id, true):
						_mark_incomplete({"room":child_id, "reason":"room_rollback_failed"})
						return {"accepted":false, "error":"Откат занятой комнаты невозможен", "orphan_room":child_id}
					continue
				if alternative == "deadend": _deadend_budget -= 1
				# Генераторы объектов видят только готовую связанную комнату.
				EventBus.publish(&"RoomCreated", {"room":child_id, "type":alternative})
				for child_exit in _rooms[child_id]["exits"]:
					EventBus.publish(&"RoomExitCreated", {"room":child_id, "exit":child_exit["id"]})
				EventBus.publish(&"RoomsConnected", {"room":parent_id, "exit":exit_id, "other_room":child_id, "other_exit":&"entry"})
				EventBus.publish(&"RoomChildGenerated", {"room":parent_id, "exit":exit_id, "child":child_id, "type":alternative})
				return {"accepted":true, "child":child_id, "type":alternative}
	var error := "Не удалось построить ни одно допустимое продолжение"
	EventBus.publish(&"RoomGenerationFailed", {"room":parent_id, "exit":exit_id, "error":error, "attempts":tried})
	return {"accepted":false, "error":error}

func _clear_trial_region(origin: Vector2i, size: Vector2i) -> bool:
	var region := {"origin":origin * _scale, "size":size * _scale, "accepted":false}
	EventBus.publish(&"SpaceRegionGetRequested", region)
	if not region["accepted"] or not region["passages"].is_empty(): return false
	var tiles: Array = region["floor"].keys()
	if tiles.is_empty(): return true
	var clear := {"tiles":tiles, "kind":0, "accepted":false}
	EventBus.publish(&"SpaceTilesSetRequested", clear)
	return clear["accepted"]

func _rollback_child(id: StringName, quiet: bool = false) -> bool:
	if not _rooms.has(id): return true
	var room: Dictionary = _rooms[id]
	var region := {"origin": room["origin_cell"] * _scale, "size": room["size_cells"] * _scale, "accepted": false}
	EventBus.publish(&"SpaceRegionGetRequested", region)
	if not region["accepted"]: return false
	var tiles: Array = region["floor"].keys()
	for tile in tiles:
		var query := {"tile": tile}
		EventBus.publish(&"SpaceTileGetRequested", query)
		if query.get("occupant", null) != null: return false
	var loot_check := {"tiles": tiles, "kind": 0, "allowed": true}
	EventBus.publish(&"LootTerrainChangeCheckRequested", loot_check)
	if not loot_check["allowed"]: return false
	for ex in room["exits"]:
		var passage := {"tiles": ex["tiles"], "enabled": false, "accepted": false}
		EventBus.publish(&"SpacePassageSetRequested", passage)
		if not passage["accepted"]: return false
	if not tiles.is_empty():
		var clear := {"tiles": tiles, "kind": 0, "accepted": false}
		EventBus.publish(&"SpaceTilesSetRequested", clear)
		if not clear["accepted"]: return false
	_rooms.erase(id)
	if not quiet: EventBus.publish(&"RoomRemoved", {"room": id})
	return true

func _find_child_origins(parent: Dictionary, exit: Dictionary, size: Vector2i, child_type: String) -> Array:
	var result: Array = []
	var origin: Vector2i = parent["origin_cell"]
	var parent_size: Vector2i = parent["size_cells"]
	var dir: String = exit["dirOut"]
	var exit_cell := Vector2i(int(exit["x"] / _scale), int(exit["y"] / _scale))
	var length: int = size.y if dir in ["east", "west"] else size.x
	for offset in range(1, length - 1):
		var candidate := Vector2i.ZERO
		match dir:
			"east": candidate = Vector2i(origin.x + parent_size.x, exit_cell.y - offset)
			"west": candidate = Vector2i(origin.x - size.x, exit_cell.y - offset)
			"south": candidate = Vector2i(exit_cell.x - offset, origin.y + parent_size.y)
			"north": candidate = Vector2i(exit_cell.x - offset, origin.y - size.y)
		if _room_fits(candidate, size, child_type, parent["id"]):
			result.append({"origin": candidate, "offset": offset})
	return result

func _add_child_exits(room_id: StringName, entry_dir: String, quiet: bool = false) -> int:
	var room: Dictionary = _rooms[room_id]
	var needed := int(_exit_counts.get(room["type"], 0))
	var directions := ["north", "east", "south", "west"]
	if room["type"] == "corridor":
		directions = [_opposite(entry_dir)]
	else:
		# Предпочитаем сторону с большим запасом места до границы карты.
		# Это эвристика, а не гарантия возможности построить продолжение.
		var map := {}
		EventBus.publish(&"SpaceMapGetRequested",map)
		if map.get("configured",false):
			var cells: Vector2i = map["size"] / _scale
			var pos: Vector2i = room["origin_cell"]
			var extent: Vector2i = room["size_cells"]
			var clearance := {"north":pos.y,"east":cells.x-pos.x-extent.x,"south":cells.y-pos.y-extent.y,"west":pos.x}
			var rank := {"north":0,"east":1,"south":2,"west":3}
			var options := {}
			for direction in directions:
				var along: int = extent.x if direction in ["north","south"] else extent.y
				var offset := clampi(int(along/2),1,along-2)
				var tile := pos*_scale
				match direction:
					"north": tile += Vector2i(offset*_scale,0)
					"south": tile += Vector2i(offset*_scale,extent.y*_scale-1)
					"west": tile += Vector2i(0,offset*_scale)
					"east": tile += Vector2i(extent.x*_scale-1,offset*_scale)
				var probe := {"x":tile.x,"y":tile.y,"dirOut":direction}
				options[direction] = _find_child_origins(room,probe,Vector2i(12,12),"passage").size()
			directions.sort_custom(func(a,b): return options[a] > options[b] or (options[a] == options[b] and (clearance[a] > clearance[b] or (clearance[a] == clearance[b] and rank[a] < rank[b]))))
	var created := 0
	for direction in directions:
		if created >= needed:
			break
		if direction == entry_dir:
			continue
		var size: Vector2i = room["size_cells"]
		var along: int = size.x if direction in ["north", "south"] else size.y
		var center := clampi(int(along / 2), 1, along - 2)
		var offsets: Array = [center]
		for candidate in range(1, along - 1):
			if candidate != center: offsets.append(candidate)
		for offset in offsets:
			if _add_exit(room_id, StringName("out_%d" % created), direction, offset, quiet):
				created += 1
				break
			# Не продолжать внутри повреждённой пробы: общий откат комнаты
			# проверит возможность безопасно удалить весь её пол и проходы.
			if not _failed_exit_is_clean(room, direction, offset): return -1
	return created

func _failed_exit_is_clean(room: Dictionary, direction: String, offset: int) -> bool:
	var origin: Vector2i = room["origin_cell"] * _scale
	var bounds: Vector2i = room["size_cells"] * _scale
	var start := origin
	match direction:
		"north": start += Vector2i(offset * _scale, 0)
		"south": start += Vector2i(offset * _scale, bounds.y - 1)
		"west": start += Vector2i(0, offset * _scale)
		"east": start += Vector2i(bounds.x - 1, offset * _scale)
	var step := Vector2i.RIGHT if direction in ["north", "south"] else Vector2i.DOWN
	for i in range(_scale):
		var q := {"tile":start + step * i}
		EventBus.publish(&"SpaceTileGetRequested", q)
		if not q.get("in_bounds", false) or q.get("kind", -1) != 0 or q.get("passage", false): return false
	return true

func _repair_requested(event: Dictionary) -> void:
	event["accepted"] = false
	if _busy:
		return
	_busy = true
	var room_id: StringName = event.get("room", &"")
	event["accepted"] = _repair(room_id)
	if event["accepted"]:
		event["floor_list"] = _rooms[room_id]["floor_list"].duplicate()
	_busy = false

## BFS по полу; L-прорезка проводится внутри периметра между проёмами.
func _repair(room_id: StringName) -> bool:
	if not _rooms.has(room_id):
		return false
	var room: Dictionary = _rooms[room_id]
	if room.get("generated_cave", false): return _repair_generated(room_id)
	var exits: Array = room["exits"]
	if exits.is_empty():
		room["floor_list"] = []
		return true
	var origin: Vector2i = room["origin_cell"] * _scale
	var size: Vector2i = room["size_cells"] * _scale
	var region := {"origin": origin, "size": size, "accepted": false}
	EventBus.publish(&"SpaceRegionGetRequested", region)
	if not region["accepted"]:
		return false
	var floor: Dictionary = region["floor"]
	var start: Vector2i = exits[0]["tiles"][0]
	if not floor.has(start):
		return false
	for exit in exits:
		var reachable := _bfs(start, floor)
		var target: Vector2i = exit["tiles"][0]
		if reachable.has(target):
			continue
		var from_inside: Vector2i = start - _direction(str(exits[0]["dirOut"]))
		var to_inside: Vector2i = target - _direction(str(exit["dirOut"]))
		var path := _l_path(from_inside, to_inside)
		var paint := {"tiles": path, "kind": 1, "accepted": false}
		EventBus.publish(&"SpaceTilesSetRequested", paint)
		if not paint["accepted"]:
			return false
		for tile in path:
			floor[tile] = true
	var reachable := _bfs(start, floor)
	for exit in exits:
		for tile in exit["tiles"]:
			if not reachable.has(tile):
				return false
	room["floor_list"] = reachable.keys()
	return true

## В пещерном режиме floor_list — глобальные логические клетки, floor_tiles — физические тайлы.
func _repair_generated(room_id: StringName) -> bool:
	var room: Dictionary = _rooms[room_id]
	var origin: Vector2i = room["origin_cell"] * _scale
	var size: Vector2i = room["size_cells"] * _scale
	var region := {"origin": origin, "size": size, "accepted": false}
	EventBus.publish(&"SpaceRegionGetRequested", region)
	if not region["accepted"]: return false
	var floor: Dictionary = region["floor"]
	var center := origin + Vector2i(int(room["size_cells"].x / 2), int(room["size_cells"].y / 2)) * _scale + Vector2i.ONE
	var paint: Dictionary = {}
	if not floor.has(center):
		# Низкоуровневое изменение карты может закрыть центральный тайл.
		# Берём ближайший внутренний пол с детерминированным tie-break.
		var available: Array = []
		for tile in floor:
			if tile.x > origin.x and tile.y > origin.y and tile.x < origin.x + size.x - 1 and tile.y < origin.y + size.y - 1:
				available.append(tile)
		available.sort_custom(func(a, b):
			var da: int = absi(a.x - center.x) + absi(a.y - center.y)
			var db: int = absi(b.x - center.x) + absi(b.y - center.y)
			return da < db or (da == db and (a.y < b.y or (a.y == b.y and a.x < b.x)))
		)
		if available.is_empty():
			paint[center] = true
			floor[center] = true
		else: center = available[0]
	for exit in room["exits"]:
		var target: Vector2i = exit["tiles"][0]
		var sideways := Vector2i.RIGHT if str(exit["dirOut"]) in ["north", "south"] else Vector2i.DOWN
		var inside: Vector2i = target - _direction(str(exit["dirOut"])) + sideways
		var reachable := _bfs(center, floor)
		if reachable.has(target): continue
		for point in _l_path(center, inside):
			for dx in range(-1, _scale - 1):
				for dy in range(-1, _scale - 1):
					var tile: Vector2i = point + Vector2i(dx, dy)
					if tile.x > origin.x and tile.y > origin.y and tile.x < origin.x + size.x - 1 and tile.y < origin.y + size.y - 1:
						paint[tile] = true
		for tile in paint: floor[tile] = true
	# Точечная связность пола недостаточна для тела игрока 4×4.
	# Открываем широкие пути ко всем имеющимся проходам, не меняя стену.
	for exit in room["exits"]:
		for tile in _wide_exit_floor(room,exit):
			if not floor.has(tile):
				paint[tile] = true
				floor[tile] = true
	if not paint.is_empty():
		var request := {"tiles": paint.keys(), "kind": 1, "accepted": false}
		EventBus.publish(&"SpaceTilesSetRequested", request)
		if not request["accepted"]: return false
	var connected := _bfs(center, floor)
	for exit in room["exits"]:
		for tile in exit["tiles"]:
			if not connected.has(tile): return false
	var unreachable: Array = []
	for tile in floor:
		if not connected.has(tile): unreachable.append(tile)
	if not unreachable.is_empty():
		var remove := {"tiles": unreachable, "kind": 0, "accepted": false}
		EventBus.publish(&"SpaceTilesSetRequested", remove)
		if not remove["accepted"]: return false
	var tiles: Array = connected.keys()
	tiles.sort_custom(func(a, b): return a.y < b.y or (a.y == b.y and a.x < b.x))
	var cells: Dictionary = {}
	for tile in tiles:
		cells[Vector2i(floori(float(tile.x) / _scale), floori(float(tile.y) / _scale))] = true
	var list: Array = cells.keys()
	list.sort_custom(func(a, b): return a.y < b.y or (a.y == b.y and a.x < b.x))
	room["floor_list"] = list
	room["floor_tiles"] = tiles
	return true

func _bfs(start: Vector2i, floor: Dictionary) -> Dictionary:
	var reached := {start: true}
	var queue: Array = [start]
	var head := 0
	while head < queue.size():
		var tile: Vector2i = queue[head]
		head += 1
		for offset in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = tile + offset
			if floor.has(next) and not reached.has(next):
				reached[next] = true
				queue.append(next)
	return reached

func _l_path(from: Vector2i, to: Vector2i) -> Array:
	var path: Array = [from]
	var point := from
	while point.x != to.x:
		point.x += 1 if point.x < to.x else -1
		path.append(point)
	while point.y != to.y:
		point.y += 1 if point.y < to.y else -1
		path.append(point)
	return path

func _enter_requested(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var room_id: StringName = event.get("room", &"")
	if entity != _controlled or not _rooms.has(room_id):
		return
	var room := _room_bounds(_rooms[room_id])
	var set_bounds := {"entity": entity, "room": room, "accepted": false}
	EventBus.publish(&"SpaceBodyRoomSetRequested", set_bounds)
	if not set_bounds["accepted"]:
		return
	_current_room = room_id
	_pending.clear()
	_discover(room_id)
	_publish_player_room(room_id)
	event["accepted"] = true

func _discovered_requested(event: Dictionary) -> void:
	var result: Array = []
	for id in _rooms:
		if _rooms[id]["discovered"]:
			result.append(id)
	event["rooms"] = result

func _discover(room_id: StringName) -> void:
	if not _rooms[room_id]["discovered"]:
		_rooms[room_id]["discovered"] = true
		EventBus.publish(&"RoomDiscovered", {"room": room_id})

func _publish_player_room(room_id: StringName) -> void:
	EventBus.publish(&"PlayerRoomChanged", {"entity": _controlled, "room": room_id, "room_type": _rooms[room_id]["type"]})

func _passage_entered(event: Dictionary) -> void:
	if event.get("entity", &"") == _controlled and _just_finished_at != null and event.get("anchor", null) == _just_finished_at:
		_just_finished_at = null
		return
	if event.get("entity", &"") != _controlled or _current_room == &"" or not _pending.is_empty() or _busy or not _rooms.has(_current_room):
		return
	var tiles: Array = event.get("tiles", [])
	var room: Dictionary = _rooms[_current_room]
	for exit in room["exits"]:
		var touched := false
		for tile in tiles:
			if exit["tiles"].has(tile):
				touched = true
				break
		if not touched or exit["sealed"]:
			continue
		if not exit["connected"]:
			_busy = true
			_generate_child(_current_room, exit["id"])
			_busy = false
		if exit["connected"] and _rooms.has(exit["childId"]):
			var clear := {"entity": _controlled, "room": null, "accepted": false}
			EventBus.publish(&"SpaceBodyRoomSetRequested", clear)
			if clear["accepted"]:
				_pending = {"from": _current_room, "to": exit["childId"]}
				_discover(exit["childId"])
		return

func _entity_moved(event: Dictionary) -> void:
	if event.get("entity", &"") != _controlled:
		return
	_just_finished_at = null
	if _pending.is_empty():
		return
	var body := {"entity": _controlled, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	if not body["found"]:
		return
	for key in ["to", "from"]:
		var room_id: StringName = _pending[key]
		if _body_inside(body["data"], _room_bounds(_rooms[room_id])):
			var set_bounds := {"entity": _controlled, "room": _room_bounds(_rooms[room_id]), "accepted": false}
			EventBus.publish(&"SpaceBodyRoomSetRequested", set_bounds)
			if set_bounds["accepted"]:
				var previous := _current_room
				_current_room = room_id
				_pending.clear()
				_just_finished_at = event.get("to", null)
				if room_id != previous:
					_publish_player_room(room_id)
			return

func _body_inside(body: Dictionary, bounds: Dictionary) -> bool:
	var a: Vector2i = body["anchor"]
	var s: int = body["size"]
	var p: Vector2i = bounds["origin"]
	var extent: Vector2i = bounds["size"]
	return a.x >= p.x and a.y >= p.y and a.x + s <= p.x + extent.x and a.y + s <= p.y + extent.y

func _room_bounds(room: Dictionary) -> Dictionary:
	return {"origin": room["origin_cell"] * _scale, "size": room["size_cells"] * _scale}

func _find_exit(room: Dictionary, id: StringName) -> Variant:
	for exit in room["exits"]:
		if exit["id"] == id:
			return exit
	return null

func _room_fits(origin: Vector2i, size: Vector2i, candidate_type: String = "", parent_id: StringName = &"") -> bool:
	if origin.x < 0 or origin.y < 0:
		return false
	var map := {}
	EventBus.publish(&"SpaceMapGetRequested", map)
	if not map.get("configured", false):
		return false
	var physical: Vector2i = (origin + size) * _scale
	if physical.x > map["size"].x or physical.y > map["size"].y:
		return false
	var candidate := Rect2i(origin, size)
	var candidate_guards := _corridor_guards(origin, size) if _cave_enabled and candidate_type == "corridor" else []
	for existing in _rooms.values():
		var other := Rect2i(existing["origin_cell"], existing["size_cells"])
		if candidate.intersects(other): return false
		if _cave_enabled and existing["id"] != parent_id:
			for guard in existing.get("guards", []):
				if candidate.intersects(Rect2i(guard["origin"], guard["size"])): return false
			for guard in candidate_guards:
				if other.intersects(Rect2i(guard["origin"], guard["size"])): return false
	return true

func _corridor_guards(origin: Vector2i, size: Vector2i) -> Array:
	if _guard_width < 1 or _guard_depth < 1: return []
	if size.x > size.y:
		var y := origin.y + floori(float(size.y - _guard_width) / 2.0)
		return [{"origin": Vector2i(origin.x - _guard_depth, y), "size": Vector2i(_guard_depth, _guard_width)}, {"origin": Vector2i(origin.x + size.x, y), "size": Vector2i(_guard_depth, _guard_width)}]
	var x := origin.x + floori(float(size.x - _guard_width) / 2.0)
	return [{"origin": Vector2i(x, origin.y - _guard_depth), "size": Vector2i(_guard_width, _guard_depth)}, {"origin": Vector2i(x, origin.y + size.y), "size": Vector2i(_guard_width, _guard_depth)}]

func _valid_size(type: String, size: Vector2i) -> bool:
	if not _dimensions.has(type):
		return false
	var params: Dictionary = _dimensions[type]
	if type == "corridor":
		var short := int(params["small"])
		var low := int(params["long_min"])
		var high := int(params["long_max"])
		return (size.x == short and size.y >= low and size.y <= high) or (size.y == short and size.x >= low and size.x <= high)
	return size.x >= int(params["min"]) and size.x <= int(params["max"]) and size.y >= int(params["min"]) and size.y <= int(params["max"])

func _roll_size(type: String, orientation: String) -> Variant:
	if not _dimensions.has(type):
		return null
	var params: Dictionary = _dimensions[type]
	if type == "corridor":
		var length := _rng_int(int(params["long_min"]), int(params["long_max"]))
		if length < 0:
			return null
		return Vector2i(length, int(params["small"])) if orientation == "horizontal" else Vector2i(int(params["small"]), length)
	var width := _rng_int(int(params["min"]), int(params["max"]))
	var height := _rng_int(int(params["min"]), int(params["max"]))
	return Vector2i(width, height) if width >= 0 and height >= 0 else null

func _rng_int(low: int, high: int) -> int:
	var event := {"min": low, "max": high, "accepted": false}
	EventBus.publish(&"RngIntRequested", event)
	return int(event["value"]) if event["accepted"] else -1

func _opposite(direction: String) -> String:
	return {"north": "south", "south": "north", "east": "west", "west": "east"}.get(direction, "")

func _direction(direction: String) -> Vector2i:
	return {"north": Vector2i.UP, "south": Vector2i.DOWN, "east": Vector2i.RIGHT, "west": Vector2i.LEFT}.get(direction, Vector2i.ZERO)

func _snapshot_collect(event: Dictionary) -> void:
	if not _incomplete.is_empty():
		event["errors"].append("Нельзя сохранять карту с незавершённым откатом генерации")
		return
	if _busy:
		event["errors"].append("Нельзя сохранять во время генерации комнаты")
		return
	event["sections"]["rooms"] = {"cave_enabled": _cave_enabled, "cave_seed": _cave_seed, "rooms": _rooms.duplicate(true), "controlled": _controlled, "current_room": _current_room, "pending": _pending.duplicate(true), "deadend_budget": _deadend_budget, "sequence": _sequence}

func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["rooms"]
	_rooms = data["rooms"].duplicate(true)
	_cave_enabled = data["cave_enabled"]
	_cave_seed = data["cave_seed"]
	_controlled = data["controlled"]
	_current_room = data["current_room"]
	_pending = data["pending"].duplicate(true)
	_deadend_budget = data["deadend_budget"]
	_sequence = data["sequence"]
	_incomplete.clear()
	_busy = false
