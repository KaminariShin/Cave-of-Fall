extends Control
var status: Label
var items_label: Label
var inventory_label: Label
func _ready() -> void:
	var background := ColorRect.new()
	background.color = Color("14202a")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)
	var box := VBoxContainer.new()
	box.position = Vector2(36, 24)
	box.size = Vector2(640, 310)
	box.add_theme_constant_override("separation", 10)
	add_child(box)
	var heading := Label.new()
	heading.text = "Лут: перенос вещей и подбор"
	heading.add_theme_font_size_override("font_size", 24)
	box.add_child(heading)
	status = Label.new()
	status.text = "Враг несёт два предмета."
	box.add_child(status)
	items_label = Label.new()
	box.add_child(items_label)
	inventory_label = Label.new()
	box.add_child(inventory_label)
	var buttons := HBoxContainer.new()
	box.add_child(buttons)
	var kill := Button.new()
	kill.text = "1. Победить врага"
	kill.pressed.connect(_kill)
	buttons.add_child(kill)
	var go := Button.new()
	go.text = "2. Встать на лут"
	go.pressed.connect(_approach)
	buttons.add_child(go)
	var pickup := Button.new()
	pickup.text = "3. Подобрать (1 с)"
	pickup.pressed.connect(_pickup)
	buttons.add_child(pickup)
	var hint := Label.new()
	hint.text = "Перенос в стенде мгновенный; игровой путь и экипировка здесь не показаны."
	box.add_child(hint)
	EventBus.subscribe(&"LootItemDropped", _changed)
	EventBus.subscribe(&"LootItemPickedUp", _picked)
	EventBus.subscribe(&"LootPickupFailed", _failed)
	_setup()
	_refresh()
func _setup() -> void:
	EventBus.publish(&"SpaceMapConfigureRequested", {"size": Vector2i(20,20)})
	var floors: Array = []
	for x in range(20):
		for y in range(20): floors.append(Vector2i(x,y))
	EventBus.publish(&"SpaceTilesSetRequested", {"tiles": floors, "kind": 1})
	EventBus.publish(&"MaterialRegisterRequested", {"material": {"id": "demo_mat", "name": "Материал", "weight_per_unit": 1, "volume_per_unit": 1, "level": 1}})
	EventBus.publish(&"ItemBaseRegisterRequested", {"base": {"id": "demo_base", "name": "Трофей", "slot": "main", "materials": [{"material_id": "demo_mat", "count": 1}]}})
	for id in [&"sword", &"supply"]:
		EventBus.publish(&"ItemCreateRequested", {"id": id, "base_id": &"demo_base", "item_level": 1})
	EntityRegistry.create_entity(&"hero")
	EntityRegistry.create_entity(&"enemy")
	EventBus.publish(&"SpaceBodyPlaceRequested", {"entity": &"hero", "anchor": Vector2i(2,2), "size": 2})
	EventBus.publish(&"SpaceBodyPlaceRequested", {"entity": &"enemy", "anchor": Vector2i(8,8), "size": 2})
	EventBus.publish(&"ControlledEntityRequested", {"entity": &"hero"})
	EventBus.publish(&"InventoryConfigureRequested", {"entity": &"hero", "volume": 2})
	EventBus.publish(&"InventoryConfigureRequested", {"entity": &"enemy", "volume": 2})
	EventBus.publish(&"InventoryAddRequested", {"entity": &"enemy", "item": &"supply"})
	EventBus.publish(&"ComponentSetRequested", {"entity": &"enemy", "component": &"equipment", "data": {"main": &"sword", "off": null, "armor": {}, "accessories": []}})
func _kill() -> void:
	var e := {"entity": &"enemy", "source": &"hero", "amount": 999}
	EventBus.publish(&"CombatDamageRequested", e)
	status.text = "Враг побеждён; вещи лежат на тайле (9, 9)." if e["accepted"] else "Враг уже побеждён."
	_refresh()
func _approach() -> void:
	var e := {"entity": &"hero", "anchor": Vector2i(8,8)}
	EventBus.publish(&"SpaceBodyMoveRequested", e)
	status.text = "Тело игрока накрывает тайл предметов." if e["accepted"] else "Сначала победите врага."
func _pickup() -> void:
	var ground := {}
	EventBus.publish(&"LootGetRequested", ground)
	var ids: Array = ground["items"].keys()
	ids.sort()
	if ids.is_empty():
		status.text = "Предметов на земле нет."
		return
	var e := {"entity": &"hero", "item": ids[0], "duration": 1.0}
	EventBus.publish(&"LootPickupRequested", e)
	status.text = "Подбор занимает 1 игровую секунду." if e["accepted"] else "Нужно накрывать тайл и не выполнять другое действие."
func _changed(_e: Dictionary) -> void: _refresh()
func _picked(_e: Dictionary) -> void:
	status.text = "Предмет перенесён в инвентарь."
	_refresh()
func _failed(_e: Dictionary) -> void:
	status.text = "Подбор не удался; предмет остался на земле."
	_refresh()
func _refresh() -> void:
	var ground := {}
	EventBus.publish(&"LootGetRequested", ground)
	var inv := {"entity": &"hero", "found": false}
	EventBus.publish(&"InventoryGetRequested", inv)
	items_label.text = "На земле: " + str(ground.get("items", {}).keys())
	inventory_label.text = "Инвентарь игрока: " + str(inv.get("data", {}).get("items", []))
