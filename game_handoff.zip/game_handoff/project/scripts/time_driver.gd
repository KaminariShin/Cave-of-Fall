extends Node
## Единственный владелец игрового времени. Время хранится целым числом шагов.
## Все длительности должны быть кратны STEP_SECONDS.

signal tick(dt: float)
signal action_started(action_id: StringName, duration: float)
signal action_interrupted(action_id: StringName, elapsed: float)
signal action_finished(action_id: StringName, elapsed: float)
signal turn_finished(duration: float)

const STEP_SECONDS: float = 0.01
const DURATION_EPSILON: float = 0.000001

var _total_steps: int = 0
var _active: bool = false
var _action_id: StringName = &""
var _action_steps: int = 0
var _action_elapsed_steps: int = 0
var _turn_steps: int = 0
var _real_time_accumulator: float = 0.0
var _generation: int = 0
var _stepping: bool = false
var _settling: bool = false
var _combat_phase: bool = false
var _combat_batch_used: bool = false
var _post_combat_phase: bool = false
var _allow_stagger_start: bool = false

var game_time: float:
	get:
		return _total_steps * STEP_SECONDS

var is_action_active: bool:
	get:
		return _active

var current_action_id: StringName:
	get:
		return _action_id if _active else &""

func _ready() -> void:
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"TimeStartRequested", _on_start_requested)
	EventBus.subscribe(&"TimeInterruptRequested", _on_interrupt_requested)
	EventBus.subscribe(&"TimeCancelRequested", _on_cancel_requested)
	action_finished.connect(func(id, elapsed): EventBus.publish(&"DriverActionCompleted", {"action": id, "elapsed": elapsed}))
	action_interrupted.connect(func(id, elapsed): EventBus.publish(&"DriverActionInterrupted", {"action": id, "elapsed": elapsed}))

func _on_start_requested(request: Dictionary) -> void:
	request["accepted"] = start_action(request["action"], request["duration"])

func _on_interrupt_requested(request: Dictionary) -> void:
	request["accepted"] = interrupt_with(request["action"], request["duration"])

func _on_cancel_requested(request: Dictionary) -> void:
	request["accepted"] = cancel_action()

func _process(delta: float) -> void:
	if WeaponStrikeActionService.launch_in_progress() or BowShotActionService.launch_in_progress(): return
	if not _active:
		_real_time_accumulator = 0.0
		return
	_real_time_accumulator += delta
	while _active and _real_time_accumulator + 1e-10 >= STEP_SECONDS:
		_real_time_accumulator -= STEP_SECONDS
		_step()
	if not _active:
		_real_time_accumulator = 0.0

## Начинает ход управляемого персонажа. Не заменяет уже активное действие.
func start_action(action_id: StringName, duration: float) -> bool:
	if _active or _stepping or (_settling and not (_post_combat_phase and _allow_stagger_start and action_id == &"stagger")) or action_id == &"":
		return false
	var steps := _duration_to_steps(duration)
	if steps <= 0:
		return false
	_turn_steps = 0
	_real_time_accumulator = 0.0
	_begin_action(action_id, steps)
	return true

## Ожидание — обычное действие без побочных эффектов.
func wait_for(duration: float) -> bool:
	return start_action(&"wait", duration)

## Немедленно заменяет активное действие; ход при этом продолжается.
## Вызывается на границе шага, в том числе из обработчика tick.
func interrupt_with(action_id: StringName, duration: float) -> bool:
	if not _active or action_id == &"":
		return false
	var steps := _duration_to_steps(duration)
	if steps <= 0:
		return false
	var old_id := _action_id
	var elapsed := _action_elapsed_steps * STEP_SECONDS
	# Сначала заменить действие: обработчики видят актуальное состояние.
	_generation += 1
	_action_id = action_id
	_action_steps = steps
	_action_elapsed_steps = 0
	var replacement_generation := _generation
	action_interrupted.emit(old_id, elapsed)
	# Обработчик прерывания сам мог заменить действие.
	if _active and _generation == replacement_generation:
		action_started.emit(action_id, steps * STEP_SECONDS)
	return true

## Прервать действие без замены и завершить текущий ход.
func cancel_action() -> bool:
	if not _active:
		return false
	var old_id := _action_id
	var elapsed := _action_elapsed_steps * STEP_SECONDS
	var turn_duration := _turn_steps * STEP_SECONDS
	_active = false
	_action_id = &""
	_generation += 1
	_real_time_accumulator = 0.0
	action_interrupted.emit(old_id, elapsed)
	turn_finished.emit(turn_duration)
	return true

## Для тестов/пошаговой симуляции. Нельзя вызывать из обработчика tick.
## Возвращает число действительно выполненных шагов.
func advance_steps(count: int) -> int:
	if count <= 0 or _stepping or _settling or WeaponStrikeActionService.launch_in_progress() or BowShotActionService.launch_in_progress():
		return 0
	var executed := 0
	while executed < count and _active:
		_step()
		executed += 1
	return executed

func _begin_action(action_id: StringName, steps: int) -> void:
	_active = true
	_action_id = action_id
	_action_steps = steps
	_action_elapsed_steps = 0
	_generation += 1
	action_started.emit(action_id, steps * STEP_SECONDS)

func _step() -> void:
	_stepping = true
	var step_generation := _generation
	_total_steps += 1
	_turn_steps += 1
	_action_elapsed_steps += 1
	# Здесь будущие Process Registry и Action Registry подписываются на tick.
	EventBus.publish(&"TimeStepStarted", {"game_time": game_time})
	EventBus.publish(&"TimeProcessesTick", {"dt": STEP_SECONDS, "game_time": game_time})
	EventBus.publish(&"TimeResourcesTick", {"dt": STEP_SECONDS, "game_time": game_time})
	EventBus.publish(&"Tick", {"dt": STEP_SECONDS, "game_time": game_time})
	tick.emit(STEP_SECONDS)
	# Отдельное окно сбора готовых фазовых действий до их завершения.
	# Один доверенный заранее подготовленный пакет может быть применён здесь.
	_combat_phase = true
	_combat_batch_used = false
	CombatPhaseBatchService.begin()
	EventBus.publish(&"TimeCombatPhase", {"game_time":game_time,"actions":ActionRegistry.combat_phase_due()})
	WeaponStrikePhaseSubmitService.submit_due_automatically()
	ProjectileService.submit_phase_contacts()
	var combat_committed: bool = CombatPhaseBatchService.finish()
	ProjectileService.finish_phase_contacts(combat_committed)
	_combat_phase = false
	ActionRegistry.resolve_weapon_midpoint_interruptions()
	ActionRegistry.finish_combat_phase()
	# Замена в обработчике tick означает, что новое действие ещё не тикало.
	if _active and _generation == step_generation and _action_elapsed_steps >= _action_steps:
		var finished_id := _action_id
		var elapsed := _action_elapsed_steps * STEP_SECONDS
		var turn_duration := _turn_steps * STEP_SECONDS
		_active = false
		_action_id = &""
		_generation += 1
		_real_time_accumulator = 0.0
		action_finished.emit(finished_id, elapsed)
		turn_finished.emit(turn_duration)
	_stepping = false
	# Действия и тики уже завершены, снимки снова доступны. Вложенное
	# продвижение времени и начало хода до окончания уведомления запрещены.
	_settling = true
	_post_combat_phase = true
	WeaponStrikePhaseSubmitService.emit_committed_strike_noises(combat_committed)
	DirectDamageStaggerService.resolve()
	PhaseStaggerService.resolve()
	_post_combat_phase = false
	EventBus.publish(&"TimeStepSettled", {"game_time":game_time})
	_settling = false

# Доверенный внутренний пересчёт конца текущего движения после одного
# игрового шага. Начатое действие и фактически прошедшее время не меняются.
func retime_move_after_tick(remaining_steps: int) -> bool:
	if not _stepping or not _active or _action_id != &"move" or remaining_steps < 0 or _action_elapsed_steps + remaining_steps > 1000000000: return false
	_action_steps = _action_elapsed_steps + remaining_steps
	return true

# Только один доверенный пакет на фазу, включая отклонённую попытку.
func claim_combat_batch() -> bool:
	if not _stepping or not _combat_phase or _combat_batch_used: return false
	_combat_batch_used = true
	return true

func _duration_to_steps(duration: float) -> int:
	if not is_finite(duration) or duration <= 0.0:
		return 0
	var steps_float := duration / STEP_SECONDS
	# Ограничение предотвращает переполнение при преобразовании в int.
	if steps_float > 1000000000.0:
		return 0
	var steps := int(round(steps_float))
	if steps < 1 or absf(steps * STEP_SECONDS - duration) > DURATION_EPSILON:
		return 0
	return steps

func _snapshot_collect(event: Dictionary) -> void:
	if _stepping:
		event["errors"].append("Нельзя сохранять во время шага времени")
		return
	event["sections"]["time"] = {"total_steps": _total_steps, "active": _active, "action_id": _action_id, "action_steps": _action_steps, "elapsed_steps": _action_elapsed_steps, "turn_steps": _turn_steps, "real_accumulator": _real_time_accumulator}

func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["time"]
	_total_steps = data["total_steps"]
	_active = data["active"]
	_action_id = data["action_id"]
	_action_steps = data["action_steps"]
	_action_elapsed_steps = data["elapsed_steps"]
	_turn_steps = data["turn_steps"]
	_real_time_accumulator = data["real_accumulator"]
	_generation += 1
