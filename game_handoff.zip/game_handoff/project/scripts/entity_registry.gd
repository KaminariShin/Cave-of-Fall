extends Node
## Реестр не знает классов игровых сущностей: только ID и компоненты-данные.

var _entities: Dictionary = {}
var _removing: Dictionary = {}
var _checking_removal: Dictionary = {}
var _ownership_busy := false
var _default_stat_value: float = 5.0
const STAT_NAMES := ["CON", "STR", "DEX", "INT", "WIS", "PER"]

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		_default_stat_value = float(rules["ruleset"].get("parameters", {}).get("stats", {}).get("base", 5))
	EventBus.subscribe(&"StatsCommitRequested", _on_stats_commit_requested)
	EventBus.subscribe(&"ResourcesCommitRequested", _on_resources_commit_requested)
	EventBus.subscribe(&"InventoryCommitRequested", _on_inventory_commit_requested)
	EventBus.subscribe(&"EquipmentTransferCommitRequested", _on_equipment_transfer_commit)
	EventBus.subscribe(&"SpatialCommitRequested", _on_spatial_commit_requested)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"EntityCreateRequested", _on_create_requested)
	EventBus.subscribe(&"EntityRemoveRequested", _on_remove_requested)
	EventBus.subscribe(&"ComponentSetRequested", _on_component_set_requested)
	EventBus.subscribe(&"ComponentRemoveRequested", _on_component_remove_requested)
	EventBus.subscribe(&"EntityGetRequested", _on_entity_get_requested)
	EventBus.subscribe(&"ComponentGetRequested", _on_component_get_requested)
	EventBus.subscribe(&"EntityQueryRequested", _on_entity_query_requested)

## Для характеристик задана база из ruleset; для ресурсов null означает «не задано»,
## а не ноль. Возвращается новый набор, не связанный с другими сущностями.
func make_common_components() -> Dictionary:
	return {
		&"stats": {"CON": _default_stat_value, "STR": _default_stat_value, "DEX": _default_stat_value, "INT": _default_stat_value, "WIS": _default_stat_value, "PER": _default_stat_value},
		&"resources": {"HP": _empty_resource(), "Stamina": _empty_resource(), "MP": _empty_resource()},
		&"equipment": {"main": null, "off": null, "armor": {}, "accessories": []},
		&"inventory": {"items": [], "volume": null},
		&"body_size": {"tiles": null},
		&"perception": {"PER": null, "detection_radius": null},
		&"detection": {"observers": [], "detected": []},
		&"position": {"anchor": null, "direction": null},
	}

func _empty_resource() -> Dictionary:
	return {"current": null, "remainder": null, "timer": null, "reserve": null, "reserve_filled": null}

## Начальные компоненты задаются явно. Данные глубоко копируются.
func create_entity(entity_id: StringName, components: Dictionary = {}) -> bool:
	if _ownership_busy or entity_id == &"" or _entities.has(entity_id) or _removing.has(entity_id):
		return false
	for component in components:
		if not _valid_component(component, components[component]):
			return false
	var data: Dictionary = {}
	for component in components:
		data[StringName(str(component))] = components[component].duplicate(true)
	if data.has(&"position") and data[&"position"].get("anchor", null) != null:
		# Размещать тело нужно только через пространственный сервис.
		return false
	if data.has(&"equipment") and not _ownership_change_valid(entity_id, {}, data[&"equipment"], false):
		return false
	if data.has(&"inventory"):
		var starting_items = data[&"inventory"].get("items", [])
		if not starting_items is Array or not starting_items.is_empty():
			return false
	var stats: Dictionary = data.get(&"stats", {})
	for stat in STAT_NAMES:
		var value = stats.get(stat, _default_stat_value)
		if not (value is int or value is float) or not is_finite(float(value)):
			return false
		stats[stat] = value
	# Внешние создания не могут напрямую внедрять модификаторы.
	stats["_modifiers"] = []
	data[&"stats"] = stats
	_entities[entity_id] = data
	EventBus.publish(&"EntityCreated", {"entity": entity_id})
	return true

## Сущность удаляется до уведомления; тот же ID нельзя создать внутри события.
func remove_entity(entity_id: StringName) -> bool:
	if _ownership_busy or not _entities.has(entity_id) or _removing.has(entity_id) or _checking_removal.has(entity_id):
		return false
	_checking_removal[entity_id] = true
	var loot_check := {"entity": entity_id, "allowed": true}
	EventBus.publish(&"LootEntityRemovalCheckRequested", loot_check)
	_checking_removal.erase(entity_id)
	if not loot_check["allowed"] or not _entities.has(entity_id) or _removing.has(entity_id): return false
	_removing[entity_id] = true
	_entities.erase(entity_id)
	EventBus.publish(&"EntityRemoved", {"entity": entity_id})
	_removing.erase(entity_id)
	return true

func has_entity(entity_id: StringName) -> bool:
	return _entities.has(entity_id)

func get_entity(entity_id: StringName) -> Dictionary:
	return _entities[entity_id].duplicate(true) if _entities.has(entity_id) else {}

func has_component(entity_id: StringName, component: StringName) -> bool:
	return _entities.has(entity_id) and _entities[entity_id].has(component)

func get_component(entity_id: StringName, component: StringName) -> Dictionary:
	if not has_component(entity_id, component):
		return {}
	return _entities[entity_id][component].duplicate(true)

## Запись целиком заменяет компонент. Игровые события уровня StatChanged и
## ResourceChanged публикуют соответствующие специализированные системы.
func set_component(entity_id: StringName, component: StringName, data: Dictionary) -> bool:
	if _ownership_busy or not _entities.has(entity_id) or component in [&"stats", &"resources", &"inventory", &"position", &"body_size"] or not _valid_component(component, data):
		return false
	if component == &"equipment" and not _ownership_change_valid(entity_id, _entities[entity_id].get(&"inventory", {}), data, false):
		return false
	var had_component: bool = _entities[entity_id].has(component)
	_entities[entity_id][component] = data.duplicate(true)
	EventBus.publish(&"ComponentChanged", {"entity": entity_id, "component": component, "created": not had_component})
	return true

func remove_component(entity_id: StringName, component: StringName) -> bool:
	if _ownership_busy or component in [&"stats", &"resources", &"inventory", &"position", &"body_size"] or not has_component(entity_id, component):
		return false
	_entities[entity_id].erase(component)
	EventBus.publish(&"ComponentRemoved", {"entity": entity_id, "component": component})
	return true

## Пустой список условий возвращает все ID. Порядок — порядок создания.
func query_entities(required_components: Array) -> Array:
	var result: Array = []
	for entity_id in _entities:
		var matches := true
		for component in required_components:
			if not _entities[entity_id].has(StringName(str(component))):
				matches = false
				break
		if matches:
			result.append(entity_id)
	return result

func _valid_component(component: Variant, data: Variant) -> bool:
	return (component is String or component is StringName) and not str(component).is_empty() and data is Dictionary

func _on_create_requested(request: Dictionary) -> void:
	request["accepted"] = create_entity(request.get("entity", &""), request.get("components", {}))

func _on_remove_requested(request: Dictionary) -> void:
	request["accepted"] = remove_entity(request.get("entity", &""))

func _on_component_set_requested(request: Dictionary) -> void:
	request["accepted"] = set_component(request.get("entity", &""), request.get("component", &""), request.get("data", {}))

func _on_component_remove_requested(request: Dictionary) -> void:
	request["accepted"] = remove_component(request.get("entity", &""), request.get("component", &""))

func _on_entity_get_requested(request: Dictionary) -> void:
	var entity_id: StringName = request.get("entity", &"")
	request["found"] = has_entity(entity_id)
	request["data"] = get_entity(entity_id)

func _on_component_get_requested(request: Dictionary) -> void:
	var entity_id: StringName = request.get("entity", &"")
	var component: StringName = request.get("component", &"")
	request["found"] = has_component(entity_id, component)
	request["data"] = get_component(entity_id, component)

func _on_entity_query_requested(request: Dictionary) -> void:
	request["entities"] = query_entities(request.get("components", []))

func _snapshot_collect(event: Dictionary) -> void:
	if not _removing.is_empty() or not _checking_removal.is_empty():
		event["errors"].append("Нельзя сохранять во время удаления сущности")
		return
	event["sections"]["entities"] = _entities.duplicate(true)

func _snapshot_apply(event: Dictionary) -> void:
	_entities = event["sections"]["entities"].duplicate(true)
	_removing.clear()
	_checking_removal.clear()

## Внутренний протокол конвейера характеристик. Игровые модули не отправляют
## этот запрос; они используют StatBaseSetRequested и StatModifier*Requested.
func _on_stats_commit_requested(request: Dictionary) -> void:
	var entity_id: StringName = request.get("entity", &"")
	var data = request.get("data", null)
	request["accepted"] = false
	if not _entities.has(entity_id) or not data is Dictionary:
		return
	for stat in STAT_NAMES:
		var value = data.get(stat, null)
		if not (value is int or value is float) or not is_finite(float(value)):
			return
	if not data.get("_modifiers", null) is Array:
		return
	_entities[entity_id][&"stats"] = data.duplicate(true)
	request["accepted"] = true
	EventBus.publish(&"ComponentChanged", {"entity": entity_id, "component": &"stats", "created": false})

func _on_resources_commit_requested(request: Dictionary) -> void:
	var entity_id: StringName = request.get("entity", &"")
	var data = request.get("data", null)
	request["accepted"] = false
	if not _entities.has(entity_id) or not data is Dictionary:
		return
	_entities[entity_id][&"resources"] = data.duplicate(true)
	request["accepted"] = true
	EventBus.publish(&"ComponentChanged", {"entity": entity_id, "component": &"resources", "created": false})

func _on_inventory_commit_requested(request: Dictionary) -> void:
	var entity_id: StringName = request.get("entity", &"")
	var data = request.get("data", null)
	request["accepted"] = false
	if not _entities.has(entity_id) or not data is Dictionary or not data.get("items", null) is Array:
		return
	if not _ownership_change_valid(entity_id, data, _entities[entity_id].get(&"equipment", {}), true): return
	_entities[entity_id][&"inventory"] = data.duplicate(true)
	request["accepted"] = true
	EventBus.publish(&"ComponentChanged", {"entity": entity_id, "component": &"inventory", "created": false})

## Атомарная смена владения между инвентарём и одним слотом экипировки.
## Вызов допускается только после проверок EquipmentActionService.
func _on_equipment_transfer_commit(request: Dictionary) -> void:
	request["accepted"] = false
	var entity = request.get("entity", null)
	var item = request.get("item", null)
	var slot = request.get("slot", null)
	var equip = request.get("equip", null)
	if not entity is StringName or not _entities.has(entity) or not item is StringName or item == &"" or not slot is String or slot.is_empty() or not equip is bool: return
	var inventory = _entities[entity].get(&"inventory", null)
	var equipment = _entities[entity].get(&"equipment", {})
	if not inventory is Dictionary or not inventory.get("items", null) is Array or not equipment is Dictionary: return
	var items: Array = inventory["items"].duplicate(true)
	var slots: Dictionary = equipment.duplicate(true)
	if equip:
		if not items.has(item) or slots.get(slot, null) != null: return
		items.erase(item)
		slots[slot] = item
	else:
		if slots.get(slot, null) != item or items.has(item): return
		slots[slot] = null
		items.append(item)
	var updated: Dictionary = inventory.duplicate(true)
	updated["items"] = items
	if not _ownership_change_valid(entity, updated, slots, false): return
	var created: bool = not _entities[entity].has(&"equipment")
	_entities[entity][&"inventory"] = updated
	_entities[entity][&"equipment"] = slots
	request["accepted"] = true
	EventBus.publish(&"ComponentChanged", {"entity":entity, "component":&"inventory", "created":false})
	EventBus.publish(&"ComponentChanged", {"entity":entity, "component":&"equipment", "created":created})
	EventBus.publish(&"InventoryItemRemoved" if equip else &"InventoryItemAdded", {"entity":entity, "item":item})

# Без уведомлений: LootService тут же фиксирует этот экземпляр на земле.
func release_equipment_to_ground(actor: StringName, item: StringName, slot: String) -> bool:
	if _ownership_busy or not LootService.authorizes_equipment_drop(actor,item,slot) or not _entities.has(actor) or CombatService.is_entity_dead(actor): return false
	var components: Dictionary = _entities[actor]
	var gear = components.get(&"equipment",null)
	var inv = components.get(&"inventory",null)
	if not gear is Dictionary or not inv is Dictionary or not inv.get("items",null) is Array or gear.get(slot,null) != item or inv["items"].has(item): return false
	for owner in _entities:
		var refs: Array = []
		var parts: Dictionary = _entities[owner]
		if not _ownership_ids(parts.get(&"inventory",{}).get("items",[]),refs,0) or not _ownership_ids(parts.get(&"equipment",{}),refs,0) or refs.count(item) != (1 if owner == actor else 0): return false
	var updated: Dictionary = gear.duplicate(true)
	updated[slot] = null
	_entities[actor][&"equipment"] = updated
	return true

# Удаление ссылки и добавление на землю выполняются LootService без
# промежуточных событий; все обычные охранные проверки владения сохраняются.
func release_inventory_to_ground(actor: StringName, item: StringName) -> bool:
	if _ownership_busy or not LootService.authorizes_inventory_drop(actor,item) or not _entities.has(actor) or CombatService.is_entity_dead(actor): return false
	var inventory = _entities[actor].get(&"inventory",null)
	var equipment = _entities[actor].get(&"equipment",{})
	if not inventory is Dictionary or not inventory.get("items",null) is Array or inventory["items"].count(item) != 1 or not equipment is Dictionary: return false
	var prior: Dictionary = inventory.duplicate(true)
	var updated: Dictionary = inventory.duplicate(true)
	updated["items"].erase(item)
	if not _ownership_change_valid(actor,updated,equipment,false): return false
	if not LootService.authorizes_inventory_drop(actor,item) or not _entities.has(actor) or _entities[actor].get(&"inventory",null) != prior or _entities[actor].get(&"equipment",{}) != equipment or CombatService.is_entity_dead(actor): return false
	for owner in _entities:
		var refs: Array = []
		var parts: Dictionary = _entities[owner]
		if not _ownership_ids(parts.get(&"inventory",{}).get("items",[]),refs,0) or not _ownership_ids(parts.get(&"equipment",{}),refs,0) or refs.count(item) != (1 if owner == actor else 0): return false
	if not LootService.inventory_drop_commit_valid(actor,item): return false
	_entities[actor][&"inventory"] = updated
	return true

# Закрытый атомарный коммит только для завершившегося действия ChestTransferService.
# Оба компонента записываются до любых уведомлений; вызов не является публичным API.
func transfer_chest_item(actor: StringName, chest: StringName, item: StringName) -> bool:
	if _ownership_busy or actor == chest or not ChestTransferService.authorizes_commit(actor, chest, item) or not _entities.has(actor) or not _entities.has(chest): return false
	_ownership_busy = true
	var permitted := true
	for entity in [actor, chest]:
		var guard := {"entity":entity, "allowed":true}
		EventBus.publish(&"EntityOwnershipMutationCheckRequested", guard)
		if not guard.get("allowed", false): permitted = false
	if not permitted or not ChestTransferService.commit_context_valid(actor, chest, item):
		_ownership_busy = false
		return false
	var source = _entities[chest].get(&"inventory", null)
	var target = _entities[actor].get(&"inventory", null)
	if not source is Dictionary or not target is Dictionary or not source.get("items", null) is Array or not target.get("items", null) is Array or source["items"].count(item) != 1 or target["items"].has(item):
		_ownership_busy = false
		return false
	# Проверяем отсутствие альтернативных владельцев, экипировки и наземного лута.
	var ground := {"items":{}}
	EventBus.publish(&"LootGetRequested", ground)
	if ground.get("items", {}).has(item):
		_ownership_busy = false
		return false
	for owner in _entities:
		var refs: Array = []
		var components: Dictionary = _entities[owner]
		if not _ownership_ids(components.get(&"inventory", {}).get("items", []), refs, 0) or not _ownership_ids(components.get(&"equipment", {}), refs, 0) or refs.count(item) != (1 if owner == chest else 0):
			_ownership_busy = false
			return false
	if not ChestTransferService.commit_context_valid(actor, chest, item):
		_ownership_busy = false
		return false
	var from: Dictionary = source.duplicate(true)
	var to: Dictionary = target.duplicate(true)
	from["items"].erase(item)
	to["items"].append(item)
	_entities[chest][&"inventory"] = from
	_entities[actor][&"inventory"] = to
	_ownership_busy = false
	return true

# Внутренний бесшумный шаг очистки контейнера в операции перехода.
# Объекты сами держат блокировку; внешних событий между снятием ссылок и
# списанием предметов не публикуется.
func empty_object_inventory_for_transition(entity: StringName, expected: Array) -> bool:
	if _ownership_busy or not ObjectGenerationService.is_emptying_object_inventory(entity, expected) or not _entities.has(entity): return false
	var inventory = _entities[entity].get(&"inventory", null)
	if not inventory is Dictionary or not inventory.get("items", null) is Array or inventory["items"] != expected: return false
	var updated: Dictionary = inventory.duplicate(true)
	updated["items"] = []
	_entities[entity][&"inventory"] = updated
	return true

# Снимает ссылки на вещи только выбранного зарегистрированного существа;
# списание экземпляров следует сразу, без публикации промежуточных событий.
func clear_spawned_ownership_for_transition(entity: StringName, expected_inventory: Array, expected_equipment: Dictionary) -> bool:
	if _ownership_busy or not FloorSpawnCleanup.is_clearing_ownership(entity, expected_inventory, expected_equipment) or not _entities.has(entity): return false
	var inventory = _entities[entity].get(&"inventory", null)
	var equipment = _entities[entity].get(&"equipment", {})
	if not inventory is Dictionary or not inventory.get("items", null) is Array or inventory["items"] != expected_inventory or equipment != expected_equipment: return false
	var updated: Dictionary = inventory.duplicate(true)
	updated["items"] = []
	_entities[entity][&"inventory"] = updated
	if _entities[entity].has(&"equipment"): _entities[entity][&"equipment"] = {}
	return true

# Проверка владения на границе реестра: включая прямые замены экипировки и
# внутренние коммиты. Существование экземпляра и совместимость слота остаются
# обязанностью предметных сервисов; здесь не разрушаем старые тестовые данные.
func _ownership_change_valid(entity: StringName, inventory: Dictionary, equipment: Dictionary, allow_ground_transfer: bool) -> bool:
	if _ownership_busy: return false
	_ownership_busy = true
	var guard := {"entity":entity, "allowed":true}
	EventBus.publish(&"EntityOwnershipMutationCheckRequested", guard)
	if not guard.get("allowed", false):
		_ownership_busy = false
		return false
	var previous: Dictionary = _entities.get(entity, {}).get(&"inventory", {})
	if previous != inventory:
		var change := {"entity":entity, "before":previous.duplicate(true), "after":inventory.duplicate(true), "allowed":true}
		EventBus.publish(&"EntityInventoryChangeCheckRequested", change)
		if not change.get("allowed", false):
			_ownership_busy = false
			return false
	var result := _ownership_change_valid_locked(entity, inventory, equipment, allow_ground_transfer)
	_ownership_busy = false
	return result

func _ownership_change_valid_locked(entity: StringName, inventory: Dictionary, equipment: Dictionary, allow_ground_transfer: bool) -> bool:
	var refs: Array = []
	if not _ownership_ids(inventory.get("items", []), refs, 0) or not _ownership_ids(equipment, refs, 0): return false
	var seen := {}
	for item in refs:
		if seen.has(item): return false
		seen[item] = true
	var ground := {"items":{}}
	EventBus.publish(&"LootGetRequested", ground)
	for item in seen:
		if ground.get("items", {}).has(item):
			if not allow_ground_transfer: return false
			var permission := {"entity":entity, "item":item, "allowed":true}
			EventBus.publish(&"LootInventoryAddCheckRequested", permission)
			if not permission["allowed"]: return false
	for owner in _entities:
		if owner == entity: continue
		var other: Array = []
		var components: Dictionary = _entities[owner]
		var other_inventory = components.get(&"inventory", {})
		var other_equipment = components.get(&"equipment", {})
		if not other_inventory is Dictionary or not other_equipment is Dictionary: return false
		if not _ownership_ids(other_inventory.get("items", []), other, 0) or not _ownership_ids(other_equipment, other, 0): return false
		for item in other:
			if seen.has(item): return false
	return true

func _ownership_ids(value: Variant, result: Array, depth: int) -> bool:
	if depth > 32: return false
	if value == null: return true
	if value is String or value is StringName:
		if str(value).is_empty(): return false
		result.append(StringName(str(value)))
		return true
	if value is Array:
		for child in value:
			if not _ownership_ids(child, result, depth + 1): return false
		return true
	if value is Dictionary:
		if value.has("id"): return _ownership_ids(value["id"], result, depth + 1)
		for child in value.values():
			if not _ownership_ids(child, result, depth + 1): return false
		return true
	return false

## Внутренний протокол SpaceService: единственная синхронная запись тела.
func _on_spatial_commit_requested(request: Dictionary) -> void:
	request["accepted"] = false
	var entity_id: StringName = request.get("entity", &"")
	var position = request.get("position", null)
	var body_size = request.get("body_size", null)
	if not _entities.has(entity_id) or not position is Dictionary or not body_size is Dictionary:
		return
	var anchor = position.get("anchor", null)
	if anchor != null and not anchor is Vector2i:
		return
	var size = body_size.get("tiles", null)
	if size != null and (not size is int or size <= 0):
		return
	_entities[entity_id][&"position"] = position.duplicate(true)
	_entities[entity_id][&"body_size"] = body_size.duplicate(true)
	request["accepted"] = true
	EventBus.publish(&"ComponentChanged", {"entity": entity_id, "component": &"position", "created": false})
	EventBus.publish(&"ComponentChanged", {"entity": entity_id, "component": &"body_size", "created": false})

# Синхронный внутренний коммит подготовленного пакета без событий между записями.
func commit_simultaneous_hp(expected: Dictionary, next: Dictionary) -> bool:
	if not SimultaneousDamageApplyService.authorizes_commit() or _ownership_busy or expected.size() != next.size(): return false
	for id in expected:
		if not next.has(id) or not _entities.has(id) or not _entities[id].has(&"resources") or _entities[id][&"resources"] != expected[id] or not next[id] is Dictionary: return false
	for id in expected: _entities[id][&"resources"] = next[id].duplicate(true)
	return true

# Перестановка двух рук только при завершении ShieldHandChangeService.
func swap_shield_hands(actor: StringName, shield: StringName, from: String, other: Variant) -> bool:
	if not ShieldHandChangeService.authorizes_commit(actor,shield,from,other) or _ownership_busy or not _entities.has(actor) or from not in ["main","off"]: return false
	var to := "off" if from == "main" else "main"
	var gear = _entities[actor].get(&"equipment",null)
	var inventory = _entities[actor].get(&"inventory",null)
	if not gear is Dictionary or not inventory is Dictionary or gear.get(from,null) != shield or gear.get(to,null) != other: return false
	var prior: Dictionary = gear.duplicate(true)
	var updated: Dictionary = gear.duplicate(true)
	updated[from] = other
	updated[to] = shield
	if not _ownership_change_valid(actor,inventory,updated,false): return false
	if not _entities.has(actor) or _entities[actor].get(&"equipment",null) != prior or _entities[actor].get(&"inventory",null) != inventory: return false
	_entities[actor][&"equipment"] = updated
	EventBus.publish(&"ComponentChanged", {"entity":actor,"component":&"equipment","created":false})
	return true
