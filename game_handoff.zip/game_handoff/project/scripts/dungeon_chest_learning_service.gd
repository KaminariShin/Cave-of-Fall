extends Node
## Схема и проекция изучения; узкий расчёт эффекта pre_armour для экипировки.
var _schema: Dictionary = {}
var _busy := false

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules.get("found",false):
		var source = rules["ruleset"].get("parameters",{}).get("chest_draft_learning",null)
		if _valid_config(source):
			_schema = source.duplicate(true)
			_schema["full_progress"] = int(_schema["full_progress"])
			for step in _schema["penalty_steps"]: step["progress"] = int(step["progress"])
			for i in range(_schema["mod_unlock_cycle"].size()): _schema["mod_unlock_cycle"][i] = int(_schema["mod_unlock_cycle"][i])
	EventBus.subscribe(&"DungeonChestLearningPreviewRequested", _preview)
	EventBus.subscribe(&"ItemLearningProjectionRequested", _item_projection)

func _integer(v: Variant) -> bool:
	return (v is float or v is int) and is_finite(float(v)) and floorf(float(v)) == float(v)

func _valid_config(d: Variant) -> bool:
	if not d is Dictionary or not _integer(d.get("full_progress",null)) or d["full_progress"] < 1 or d["full_progress"] > 1000000: return false
	var steps = d.get("penalty_steps",null)
	var cycle = d.get("mod_unlock_cycle",null)
	if not steps is Array or steps.is_empty() or not cycle is Array or cycle.is_empty(): return false
	var prior := -1
	var last_penalty := 1.0
	for step in steps:
		if not step is Dictionary or not _integer(step.get("progress",null)) or step["progress"] <= prior or step["progress"] > d["full_progress"]: return false
		var penalty = step.get("penalty",null)
		if not (penalty is int or penalty is float) or not is_finite(float(penalty)) or penalty < 0 or penalty > last_penalty: return false
		prior = int(step["progress"])
		last_penalty = float(penalty)
	if steps[0]["progress"] != 0 or prior != int(d["full_progress"]) or last_penalty != 0.0: return false
	for gate in cycle:
		if not _integer(gate) or gate <= 0 or gate > d["full_progress"]: return false
	return true

func schema_for(base: StringName, bases: Dictionary) -> Dictionary:
	if _schema.is_empty() or not bases.has(base) or not bases[base] is Dictionary: return {}
	var slot := str(bases[base].get("slot", ""))
	if slot not in ["weapon","shield","body"]: return {}
	var result := _schema.duplicate(true)
	result["progress_kind"] = "weapon_strikes" if slot == "weapon" else "owner_actions"
	return result

func gate_for(index: int) -> int:
	if _schema.is_empty() or index < 0: return -1
	return _schema["mod_unlock_cycle"][index % _schema["mod_unlock_cycle"].size()]

func _preview(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["base_penalty", "active_mods", "globally_identified", "error"]: e.erase(key)
	var object = e.get("object",null)
	var index = e.get("slot_index",null)
	var progress = e.get("progress",null)
	var identified = e.get("identified",null)
	var npc = e.get("npc",null)
	if _busy or _schema.is_empty() or not object is StringName or not index is int or index < 0 or not progress is int or progress < 0 or progress > _schema["full_progress"] or not identified is bool or not npc is bool:
		e["error"] = "Нужны сундук, индекс, прогресс и явные признаки опознания и NPC"; return
	_busy = true
	var snapshot: Dictionary = SaveService.collect_world_transition_snapshot()
	_busy = false
	if not snapshot.get("valid",false): e["error"] = "Снимок недоступен"; return
	var objects: Dictionary = snapshot["payload"]["sections"]["objects"]["objects"]
	if not objects.has(object) or not objects[object].has("content_draft") or index >= objects[object]["content_draft"]["slots"].size(): e["error"] = "План или позиция не найдены"; return
	var entry: Dictionary = objects[object]["content_draft"]["slots"][index]
	if entry["category"] != "equipment": e["error"] = "Позиция не является экипировкой"; return
	var projected := _evaluate(entry["learning"], {"progress":progress, "identified":identified}, entry["mods"], npc)
	if not projected.get("valid",false): e["error"] = "Схема изучения некорректна"; return
	e["accepted"] = true
	e["base_penalty"] = projected["base_penalty"]
	e["active_mods"] = projected["active_mods"]
	e["globally_identified"] = projected["globally_identified"]

# Чистая функция: не проверяет действие, INT или права, не применяет эффекты.
func _evaluate(schema: Dictionary, state: Dictionary, mods: Array, npc: bool) -> Dictionary:
	if not _valid_config(schema) or not state.get("identified",null) is bool or not state.get("progress",null) is int: return {"valid":false}
	var progress: int = state["progress"]
	var full: int = int(schema["full_progress"])
	if progress < 0 or progress > full: return {"valid":false}
	var known: bool = state["identified"] or progress == full
	var penalty := 0.0
	if not known and not npc:
		for step in schema["penalty_steps"]:
			if progress >= step["progress"]: penalty = float(step["penalty"])
	var active: Array = []
	var inactive: Array = []
	var seen := {}
	for mod in mods:
		if not mod is Dictionary or not (mod.get("id",null) is String or mod.get("id",null) is StringName) or str(mod["id"]).is_empty() or not mod.get("unlock_after",null) is int or mod["unlock_after"] < 1 or mod["unlock_after"] > full: return {"valid":false}
		var id := StringName(str(mod["id"]))
		if seen.has(id): return {"valid":false}
		seen[id] = true
		if known or npc or progress >= mod["unlock_after"]: active.append(id)
		else: inactive.append(id)
	return {"valid":true,"base_penalty":penalty,"base_multiplier":1.0-penalty,"active_mods":active,"inactive_mods":inactive,"globally_identified":known}

# Проекция именно фактического состояния существующего предмета и владельца.
func _item_projection(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["error","data"]: e.erase(key)
	var actor = e.get("entity",null)
	var id = e.get("item",null)
	if _busy or not actor is StringName or actor == &"" or not id is StringName or id == &"": e["error"] = "Нужны владелец и предмет"; return
	_busy = true
	var snapshot: Dictionary = SaveService.collect_world_transition_snapshot()
	_busy = false
	if not snapshot.get("valid",false): e["error"] = "Состояние недоступно"; return
	var sections: Dictionary = snapshot["payload"]["sections"]
	var controlled = sections["actions"].get("controlled",null)
	if not controlled is StringName or controlled == &"" or not sections["entities"].has(actor) or not sections["items"]["instances"].has(id): e["error"] = "Владелец, предмет или управление недоступны"; return
	var entity = sections["entities"][actor]
	var item = sections["items"]["instances"][id]
	if not entity is Dictionary or not item is Dictionary or not item.get("learning",null) is Dictionary or not item.get("learning_state",null) is Dictionary or not item.get("mods",null) is Array: e["error"] = "Нет состояния изучения"; return
	var inventory = entity.get(&"inventory",{})
	var equipment = entity.get(&"equipment",{})
	if not inventory is Dictionary or not equipment is Dictionary: e["error"] = "Некорректное владение"; return
	if not _contains(inventory.get("items",[]),id,0) and not _contains(equipment,id,0): e["error"] = "Предмет не принадлежит указанной сущности"; return
	var projection := _evaluate(item["learning"],item["learning_state"],item["mods"],actor != controlled)
	if not projection.get("valid",false): e["error"] = "Некорректные данные изучения или ступени модов"; return
	projection.erase("valid")
	projection["progress"] = item["learning_state"]["progress"]
	projection["full_progress"] = item["learning"]["full_progress"]
	projection["progress_kind"] = item["learning"]["progress_kind"]
	projection["npc"] = actor != controlled
	e["data"] = projection
	e["accepted"] = true

func _contains(value: Variant, id: StringName, depth: int) -> bool:
	if depth > 32: return false
	if value is String or value is StringName: return StringName(str(value)) == id
	if value is Array:
		for child in value:
			if _contains(child,id,depth+1): return true
	elif value is Dictionary:
		for child in value.values():
			if _contains(child,id,depth+1): return true
	return false

# Живой расчёт для уже проверенного надетого предмета; снимок не собирается,
# чтобы защита работала и внутри фаз действия/тика.
func equipped_base_multiplier(actor: StringName, item: Dictionary) -> Dictionary:
	if not item.has("learning"): return {"valid":true,"multiplier":1.0}
	var schema = item.get("learning",null)
	var state = item.get("learning_state",null)
	var requirement = item.get("int_req",null)
	if not schema is Dictionary or not state is Dictionary or not (requirement is float or requirement is int) or not is_finite(float(requirement)) or float(requirement) < 0: return {"valid":false}
	var result := _evaluate(schema, state, [], false)
	if not result.get("valid",false): return {"valid":false}
	var mode := {}
	EventBus.publish(&"GameModeGetRequested",mode)
	var controlled = mode.get("entity",null)
	if not controlled is StringName or controlled == &"": return {"valid":false}
	if actor != controlled or result["globally_identified"]: return {"valid":true,"multiplier":1.0}
	var intel := {"entity":actor,"stat":&"INT","found":false}
	EventBus.publish(&"StatGetRequested",intel)
	if not intel.get("found",false) or not (intel.get("value",null) is int or intel.get("value",null) is float) or not is_finite(float(intel["value"])): return {"valid":false}
	return {"valid":true,"multiplier":result["base_multiplier"] if float(intel["value"]) < float(requirement) else 1.0}

# Эффекты характеристик и брони используют общую проверку каталога и раскрытия.
func equipped_armour_mod_bonus(actor: StringName, item: Dictionary, base: Dictionary) -> Dictionary:
	return _equipped_catalog_bonus(actor,item,base,"pre_armour","armor")

# Бонус используется при подготовке урона лука и оружия ближнего боя.
func weapon_physical_damage_mod_bonus(actor: StringName, item: Dictionary, base: Dictionary) -> Dictionary:
	return _equipped_catalog_bonus(actor,item,base,"suf_physical_damage","physical_damage")

const EQUIPPED_STAT_MODS := {"CON":"pre_vital", "STR":"pre_strength", "DEX":"pre_agile", "INT":"pre_mind", "WIS":"suf_wisdom", "PER":"suf_perception"}

func equipped_stat_mod_bonus(actor: StringName, item: Dictionary, base: Dictionary, stat: String) -> Dictionary:
	if not EQUIPPED_STAT_MODS.has(stat): return {"valid":false}
	return _equipped_catalog_bonus(actor,item,base,EQUIPPED_STAT_MODS[stat],stat)

func equipped_stat_mods_valid(actor: StringName, item: Dictionary, base: Dictionary) -> bool:
	for stat in EQUIPPED_STAT_MODS:
		if not equipped_stat_mod_bonus(actor,item,base,stat).get("valid",false): return false
	return true

const EQUIPPED_RESOURCE_MODS := {"HP":["affix_hp","max_hp"], "Stamina":["affix_stamina","max_stamina"], "MP":["affix_mana","max_mp"]}

func equipped_resource_mod_bonus(actor: StringName, item: Dictionary, base: Dictionary, resource: StringName) -> Dictionary:
	var key := str(resource)
	if not EQUIPPED_RESOURCE_MODS.has(key): return {"valid":false}
	var info: Array = EQUIPPED_RESOURCE_MODS[key]
	return _equipped_catalog_bonus(actor,item,base,info[0],info[1])

func equipped_resource_mods_valid(actor: StringName, item: Dictionary, base: Dictionary) -> bool:
	for resource in [&"HP", &"Stamina", &"MP"]:
		if not equipped_resource_mod_bonus(actor,item,base,resource).get("valid",false): return false
	return true

func _equipped_catalog_bonus(actor: StringName, item: Dictionary, base: Dictionary, mod_id: String, stat: String) -> Dictionary:
	var mods = item.get("mods",null)
	if not mods is Array: return {"valid":false}
	var target: Dictionary = {}
	var target_index := -1
	for i in range(mods.size()):
		var mod = mods[i]
		if not mod is Dictionary: return {"valid":false}
		if str(mod.get("id","")) != mod_id: continue
		if not target.is_empty(): return {"valid":false}
		target = mod
		target_index = i
	if target.is_empty(): return {"valid":true,"bonus":0.0}
	if not item.has("learning") or target.get("unlock_after",null) != gate_for(target_index): return {"valid":false}
	var schema = item.get("learning",null)
	var state = item.get("learning_state",null)
	var level = item.get("item_level",null)
	if not schema is Dictionary or not state is Dictionary or not _integer(level) or float(level) < 1 or float(level) > 1000000 or StringName(str(item.get("rarity",""))) not in [&"magic",&"rare"] or not item.get("materials",null) is Array: return {"valid":false}
	var base_id = item.get("base_id",null)
	if not base_id is StringName or schema_for(base_id,{base_id:base}) != schema: return {"valid":false}
	var catalog := DungeonChestModCatalogService._catalog
	if not DungeonChestModCatalogService._catalog_valid(catalog): return {"valid":false}
	var definition: Dictionary = {}
	for row in catalog:
		if row["id"] == mod_id: definition = row; break
	if definition.is_empty() or target.get("category",null) != definition["category"] or target.get("stat",null) != definition["stat"] or definition["stat"] != stat or (not definition["slots"].has(str(base.get("slot",""))) and not definition["base_ids"].has(str(base_id))): return {"valid":false}
	var material = target.get("material_id",null)
	if not (material is StringName or material is String) or str(material).is_empty(): return {"valid":false}
	var family := ""
	for source in ["cloth_light","leather_thin","iron_common"]:
		var variants = DungeonChestMaterialsService._families.get(source,[])
		if variants is Array and variants.has(str(material)): family = {"cloth_light":"cloth","leather_thin":"leather","iron_common":"metal"}[source]
	if family.is_empty() or not definition["families"].has(family): return {"valid":false}
	var contained := false
	for stack in item.get("materials",[]):
		if stack is Dictionary and str(stack.get("material_id","")) == str(material) and _integer(stack.get("count",null)) and float(stack["count"]) > 0: contained = true
	if not contained: return {"valid":false}
	var mat := {"material":StringName(str(material)),"found":false}
	EventBus.publish(&"MaterialGetRequested",mat)
	if not mat.get("found",false) or not mat.get("data",null) is Dictionary or not (mat["data"].get("level",null) is int or mat["data"].get("level",null) is float) or not is_finite(float(mat["data"]["level"])): return {"valid":false}
	var matched := false
	for tier in definition["tiers"]:
		if target.get("tier",null) == tier["tier"] and target.get("level_req",null) == tier["level_req"] and target.get("value",null) == tier["value"] and float(tier["level_req"]) <= float(level) and float(tier["level_req"]) <= float(mat["data"]["level"]): matched = true
	if not matched: return {"valid":false}
	var mode := {}
	EventBus.publish(&"GameModeGetRequested",mode)
	var controlled = mode.get("entity",null)
	if not controlled is StringName or controlled == &"": return {"valid":false}
	var projected := _evaluate(schema,state,[target],actor != controlled)
	if not projected.get("valid",false): return {"valid":false}
	return {"valid":true,"bonus":float(target["value"]) if projected["active_mods"].has(StringName(mod_id)) else 0.0}
