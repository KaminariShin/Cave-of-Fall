extends Node
## Только подготовка контактов стрел внутри боевой фазы. Урон не применяется.
## Вход — снимки зарегистрированных снарядов, предоставленные будущим
## сборщиком столкновений, не публичный контракт запуска выстрела.
const LIMIT := 1000000000.0
const MAX_CONTACTS := 10000
const MAX_TILES := 300000
var _busy := false

func _ready() -> void:
	EventBus.subscribe(&"ProjectilePhasePlanRequested", _plan)

func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v))

func _fail(message: String) -> Dictionary:
	return {"accepted":false,"error":message}

func _plan(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("data"); e.erase("error")
	if _busy or not TimeDriver._combat_phase:
		e["error"] = "План доступен только в боевой фазе без вложенного вызова"; return
	var input = e.get("contacts",null)
	if not input is Array or input.size() > MAX_CONTACTS:
		e["error"] = "Нужен ограниченный список контактов"; return
	_busy = true
	var result := _build(input.duplicate(true))
	_busy = false
	if not result.get("accepted",false): e["error"] = result.get("error","Ошибка подготовки"); return
	e["accepted"] = true
	e["data"] = result["data"]

func _build(contacts: Array) -> Dictionary:
	var seen := {}
	var total_tiles := 0
	for contact in contacts:
		if not contact is Dictionary: return _fail("Некорректный контакт")
		var shot = contact.get("shot",null)
		var target = contact.get("target",null)
		var tiles = contact.get("attack_tiles",null)
		if not shot is Dictionary or shot.get("weapon_type",null) != "bow" or not shot.get("id",null) is StringName or shot["id"] == &"" or not shot.get("owner",null) is StringName or shot["owner"] == &"" or not target is StringName or target == &"" or not _number(shot.get("direct_damage",null)) or float(shot["direct_damage"]) < 0 or float(shot["direct_damage"]) > LIMIT or not tiles is Array: return _fail("Некорректный снимок стрелы или цели")
		if seen.has(shot["id"]): return _fail("Повторный контакт стрелы")
		seen[shot["id"]] = true
		total_tiles += tiles.size()
		if total_tiles > MAX_TILES: return _fail("Слишком много тайлов")
		for tile in tiles:
			if not tile is Vector2i: return _fail("Некорректный тайл")
	# Упорядочиваем независимо от порядка обработки процессов.
	contacts.sort_custom(func(a,b): return str(a["shot"]["id"]) < str(b["shot"]["id"]))
	var target_resources := {}
	var hits: Array = []
	for contact in contacts:
		var shot: Dictionary = contact["shot"]
		var target: StringName = contact["target"]
		if not EntityRegistry.has_entity(target) or CombatService.is_entity_dead(target) or not EntityRegistry.has_component(target,&"resources"): return _fail("Цель недоступна")
		var resources: Dictionary = EntityRegistry.get_component(target,&"resources")
		var hp = resources.get(&"HP",null)
		if not hp is Dictionary or not _number(hp.get("current",null)) or float(hp["current"]) < 1.0 or float(hp["current"]) > LIMIT or floorf(float(hp["current"])) != float(hp["current"]): return _fail("Некорректное HP цели")
		if target_resources.has(target) and target_resources[target] != resources: return _fail("Состояние цели изменилось")
		target_resources[target] = resources.duplicate(true)
		# Совпадает с обычным CombatDamageRequested для физического снаряда:
		# исходящий модификатор уже сохранён в стреле при выпуске.
		var incoming := {"entity":target,"target":"damage.incoming","base":maxf(CombatService._minimum_damage,float(shot["direct_damage"])),"accepted":false}
		EventBus.publish(&"PipelineEvaluateRequested",incoming)
		if not incoming.get("accepted",false) or not _number(incoming.get("value",null)): return _fail("Входящий урон недоступен")
		var p := {"entity":target,"damage_type":"physical","percent":0.0}
		EventBus.publish(&"PeriodicProtectionGetRequested",p)
		if not _number(p.get("percent",null)): return _fail("Физическая защита недоступна")
		var physical := ceilf(maxf(0.0,maxf(CombatService._minimum_damage,float(incoming["value"])) * (1.0-minf(75.0,float(p["percent"]))/100.0)))
		if not is_finite(physical) or physical > LIMIT: return _fail("Слишком большой урон")
		hits.append({"source":shot["owner"],"target":target,"hit_id":shot["id"],"damage":int(physical),"magical_damage":0,"hp_before":int(hp["current"]),"attack_tiles":contact["attack_tiles"].duplicate()})
	# Проверочные события могли поменять здоровье или другие ресурсы синхронно.
	for target in target_resources:
		if not EntityRegistry.has_entity(target) or CombatService.is_entity_dead(target) or EntityRegistry.get_component(target,&"resources") != target_resources[target]: return _fail("Ресурсы цели изменились при подготовке")
	if not TimeDriver._combat_phase: return _fail("Боевая фаза завершилась")
	return {"accepted":true,"data":{"hits":hits}}
