extends Node
## Данные предметов: никаких игровых эффектов модов, пока ТЗ не закончено.
var _materials: Dictionary = {}
var _bases: Dictionary = {}
var _instances: Dictionary = {}
var _consuming: Dictionary = {}
var _retired: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"MaterialRegisterRequested", _register_material)
	EventBus.subscribe(&"MaterialGetRequested", _get_material)
	EventBus.subscribe(&"ItemBaseRegisterRequested", _register_base)
	EventBus.subscribe(&"ItemBaseGetRequested", _get_base)
	EventBus.subscribe(&"ItemCreateRequested", _create_item)
	EventBus.subscribe(&"ItemGetRequested", _get_item)
	EventBus.subscribe(&"ItemConsumeFromInventoryRequested", _consume_from_inventory)
	EventBus.subscribe(&"ItemInventoryAddCheckRequested", _inventory_add_check)
	EventBus.subscribe(&"ItemGeometryModifiersSetRequested", _set_geometry_modifiers)
	EventBus.subscribe(&"ItemModAttachRequested", _attach_mod)
	EventBus.subscribe(&"ItemWeightRequested", _get_weight)
	EventBus.subscribe(&"ItemVolumeRequested", _get_volume)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	var request := {"found": false}
	EventBus.publish(&"RulesetGetRequested", request)
	if request["found"]:
		var tables: Dictionary = request["ruleset"].get("tables", {})
		for material in tables.get("materials", []):
			_register_material({"material": material})
		for item_base in tables.get("item_bases", []):
			_register_base({"base": item_base})

func _register_material(event: Dictionary) -> void:
	event["accepted"] = false
	var material = event.get("material", null)
	if not material is Dictionary:
		return
	var id := StringName(str(material.get("id", "")))
	if id == &"" or _materials.has(id) or str(material.get("name", "")).is_empty():
		return
	for key in ["weight_per_unit", "volume_per_unit", "level"]:
		if not _nonnegative(material.get(key, null)):
			return
	_materials[id] = material.duplicate(true)
	event["accepted"] = true

func _register_base(event: Dictionary) -> void:
	event["accepted"] = false
	var base = event.get("base", null)
	if not base is Dictionary:
		return
	var id := StringName(str(base.get("id", "")))
	if id == &"" or _bases.has(id) or str(base.get("name", "")).is_empty():
		return
	if not base.get("tags", []) is Array or not base.get("materials", []) is Array:
		return
	if not _valid_stacks(base.get("materials", [])):
		return
	var data: Dictionary = base.duplicate(true)
	data["slot"] = base.get("slot", null)
	data["tags"] = base.get("tags", []).duplicate(true)
	data["materials"] = base.get("materials", []).duplicate(true)
	for stack in data["materials"]: stack["count"] = int(stack["count"])
	data["base_int_req"] = base.get("base_int_req", null)
	data["set_id"] = base.get("set_id", null)
	_bases[id] = data
	event["accepted"] = true

func _create_item(event: Dictionary) -> void:
	event["accepted"] = false
	var id := StringName(str(event.get("id", "")))
	var base_id := StringName(str(event.get("base_id", "")))
	if id == &"" or _instances.has(id) or _retired.has(id) or not _bases.has(base_id):
		return
	var stacks = event.get("materials", _bases[base_id]["materials"])
	var weight_factor = event.get("weight_modifier", 1.0)
	var volume_factor = event.get("volume_modifier", 1.0)
	var item_level = event.get("item_level", null)
	if not _nonnegative(item_level):
		event["error"] = "Для создания предмета обязателен item_level"
		return
	if not _valid_stacks(stacks) or not _nonnegative(weight_factor) or not _nonnegative(volume_factor):
		return
	if event.has("learning"):
		var schema: Dictionary = DungeonChestLearningService.schema_for(base_id, _bases)
		if schema.is_empty() or event["learning"] != schema:
			event["error"] = "Некорректная схема изучения"; return
	var rarity := StringName(str(event.get("rarity", "normal")))
	var set_id = event.get("set_id", _bases[base_id].get("set_id", null))
	var rarity_check := {"rarity": rarity, "set_id": set_id, "accepted": false}
	EventBus.publish(&"ItemRarityPrepareRequested", rarity_check)
	if not rarity_check["accepted"]:
		event["error"] = rarity_check.get("error", "Сервис редкости недоступен")
		return
	var requirement := {"rank": rarity_check["rank"], "item_level": item_level, "accepted": false}
	EventBus.publish(&"ItemIdentificationRequirementCalculateRequested", requirement)
	if not requirement["accepted"]:
		event["error"] = "Не удалось вычислить требование идентификации"
		return
	var normalized_stacks: Array = stacks.duplicate(true)
	for stack in normalized_stacks: stack["count"] = int(stack["count"])
	_instances[id] = {"id": id, "base_id": base_id, "materials": normalized_stacks, "weight_modifier": float(weight_factor), "volume_modifier": float(volume_factor), "item_level": item_level, "int_req": requirement["value"], "mods": [], "rarity": rarity, "set_id": set_id, "rarity_extra_category": rarity_check.get("extra_category", null)}
	if event.has("learning"):
		_instances[id]["learning"] = event["learning"].duplicate(true)
		_instances[id]["learning_state"] = {"progress":0, "identified":false}
	event["accepted"] = true
	EventBus.publish(&"ItemCreated", {"item": id, "base_id": base_id})
	EventBus.publish(&"ItemWeightChanged", {"item": id})

# Внутренний протокол расходования инвентарного расходника: блокировка ID
# действует и во время синхронных уведомлений удаления из инвентаря.
func _consume_from_inventory(event: Dictionary) -> void:
	event["accepted"] = false
	var entity = event.get("entity", null)
	var id = event.get("item", null)
	if not entity is StringName or not id is StringName or id == &"" or _consuming.has(id) or not _instances.has(id): return
	var base: Dictionary = _bases[_instances[id]["base_id"]]
	if str(base.get("slot", "")) != "consumable": return
	var inventory := {"entity":entity, "found":false}
	EventBus.publish(&"InventoryGetRequested", inventory)
	if not inventory.get("found", false) or not inventory["data"].get("items", []).has(id): return
	_consuming[id] = true
	var remove := {"entity":entity, "item":id, "accepted":false}
	EventBus.publish(&"InventoryRemoveRequested", remove)
	if remove["accepted"]:
		_instances.erase(id)
		_retired[id] = true
		event["accepted"] = true
		EventBus.publish(&"ItemConsumed", {"entity":entity, "item":id})
	_consuming.erase(id)

# Списание без игровых уведомлений: LootService вызывает в защищённом
# синхронном участке операции перехода, а не через публичное событие.
func retire_world_items_for_transition(ids: Array) -> bool:
	if not LootService.is_discarding_ground_items(ids) and not ObjectGenerationService.is_discarding_object_items(ids) and not FloorSpawnCleanup.is_discarding_items(ids): return false
	var seen := {}
	for id in ids:
		if not id is StringName or id == &"" or seen.has(id) or not _instances.has(id) or _retired.has(id) or _consuming.has(id): return false
		seen[id] = true
	if not BeltService.discard_item_metadata_for_transition(ids): return false
	for id in ids:
		_instances.erase(id)
		_retired[id] = true
	return true

func _inventory_add_check(event: Dictionary) -> void:
	if _consuming.has(event.get("item", null)): event["allowed"] = false

func _get_item(event: Dictionary) -> void:
	var id := StringName(str(event.get("item", "")))
	event["found"] = _instances.has(id)
	if event["found"]:
		event["item_data"] = _instances[id].duplicate(true)
		if not event["item_data"].has("item_level"):
			event["item_data"]["item_level"] = null
		if not event["item_data"].has("mods"):
			event["item_data"]["mods"] = []
		event["base"] = _bases[_instances[id]["base_id"]].duplicate(true)

func _get_weight(event: Dictionary) -> void:
	_measure(event, "weight_per_unit", "weight_modifier", "weight_kg")

func _get_volume(event: Dictionary) -> void:
	_measure(event, "volume_per_unit", "volume_modifier", "volume")

func _measure(event: Dictionary, unit_field: String, modifier_field: String, output: String) -> void:
	var id := StringName(str(event.get("item", "")))
	event["found"] = false
	if not _instances.has(id):
		return
	var item: Dictionary = _instances[id]
	var total := 0.0
	for stack in item["materials"]:
		var material_id := StringName(str(stack["material_id"]))
		if not _materials.has(material_id):
			return
		total += float(_materials[material_id][unit_field]) * int(stack["count"])
	total *= float(item[modifier_field])
	if not is_finite(total):
		return
	event[output] = total
	event["found"] = true

func _valid_stacks(stacks: Variant) -> bool:
	if not stacks is Array:
		return false
	for stack in stacks:
		if not stack is Dictionary or not _materials.has(StringName(str(stack.get("material_id", "")))):
			return false
		var count = stack.get("count", null)
		if not _nonnegative(count) or float(count) != floorf(float(count)) or float(count) > 1000000000.0:
			return false
	return true

func _nonnegative(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0

func _snapshot_collect(event: Dictionary) -> void:
	if not _consuming.is_empty():
		event["errors"].append("Нельзя сохранять во время расходования предмета")
		return
	event["sections"]["items"] = {"materials": _materials.duplicate(true), "bases": _bases.duplicate(true), "instances": _instances.duplicate(true), "retired":_retired.duplicate(true)}

func _snapshot_apply(event: Dictionary) -> void:
	var section: Dictionary = event["sections"]["items"]
	_materials = section["materials"].duplicate(true)
	_bases = section["bases"].duplicate(true)
	_instances = section["instances"].duplicate(true)
	_retired = section["retired"].duplicate(true)
	_consuming.clear()

## Уровень материала доступен будущему генератору модов; проверка тиров
## будет реализована вместе с правилами выпадения, а не здесь.
func _get_material(event: Dictionary) -> void:
	var id := StringName(str(event.get("material", "")))
	event["found"] = _materials.has(id)
	if event["found"]:
		event["data"] = _materials[id].duplicate(true)

func _get_base(event: Dictionary) -> void:
	var id := StringName(str(event.get("base_id", "")))
	event["found"] = _bases.has(id)
	if event["found"]:
		event["data"] = _bases[id].duplicate(true)

## Принимает уже вычисленные итоговые коэффициенты. Моды и их стэкинг
## здесь не разбираются: их рассчитает будущий конвейер.
func _set_geometry_modifiers(event: Dictionary) -> void:
	event["accepted"] = false
	var id := StringName(str(event.get("item", "")))
	if not _instances.has(id) or (not event.has("weight_modifier") and not event.has("volume_modifier")):
		return
	var weight = event.get("weight_modifier", _instances[id]["weight_modifier"])
	var volume = event.get("volume_modifier", _instances[id]["volume_modifier"])
	if not _nonnegative(weight) or not _nonnegative(volume):
		return
	var item: Dictionary = _instances[id]
	var weight_changed := float(item["weight_modifier"]) != float(weight)
	var volume_changed := float(item["volume_modifier"]) != float(volume)
	item["weight_modifier"] = float(weight)
	item["volume_modifier"] = float(volume)
	event["accepted"] = true
	if weight_changed:
		EventBus.publish(&"ItemWeightChanged", {"item": id})
	if volume_changed:
		EventBus.publish(&"ItemVolumeChanged", {"item": id})

## Внутренний протокол ModService: публичная проверка тира и редкости — там.
func _attach_mod(event: Dictionary) -> void:
	event["accepted"] = false
	var id := StringName(str(event.get("item", "")))
	var mod = event.get("mod", null)
	if not _instances.has(id) or not mod is Dictionary:
		return
	var category := str(mod.get("category", ""))
	if category not in ["prefix", "suffix", "affix"]:
		return
	var item: Dictionary = _instances[id]
	# На надетой вещи запрещаем неподдержанные черновые моды и изменение
	# модификаторов характеристик и максимумов ресурсов в обход уведомления о смене характеристики.
	# Другие низкоуровневые операции не являются ACL.
	if item.has("learning") and (str(mod.get("id", "")) in ["suf_perception", "suf_wisdom", "pre_vital", "pre_strength", "pre_agile", "pre_mind", "affix_hp", "affix_stamina", "affix_mana", "suf_physical_damage"] or not DungeonChestModCatalogService.unsupported_live_effects({"learning":item["learning"], "mods":[mod]}).is_empty()):
		var owners := {"components":[&"equipment"], "entities":[]}
		EventBus.publish(&"EntityQueryRequested", owners)
		for owner in owners["entities"]:
			var gear := {"entity":owner, "component":&"equipment", "found":false}
			EventBus.publish(&"ComponentGetRequested",gear)
			if gear.get("found",false) and gear.get("data",{}).values().has(id): return
	if not item.has("mods"):
		item["mods"] = []
	var mod_id := str(mod.get("id", ""))
	if mod_id.is_empty():
		return
	for existing in item["mods"]:
		if existing is Dictionary and str(existing.get("id", "")) == mod_id:
			return
	var can_attach := {"item": id, "category": category, "candidate": mod, "allowed": false}
	EventBus.publish(&"ItemModCanAttachRequested", can_attach)
	if not can_attach["allowed"]:
		return
	item["mods"].append(mod.duplicate(true))
	event["accepted"] = true
	EventBus.publish(&"ItemModAttached", {"item": id, "mod": mod.duplicate(true)})

# Только для успешно завершённого защищённого действия опознания.
func identify_from_action(actor: StringName, item: StringName) -> bool:
	if not ItemIdentificationActionService.authorizes_commit(actor, item) or not _instances.has(item): return false
	var state = _instances[item].get("learning_state", null)
	if not state is Dictionary or state.get("identified", null) != false: return false
	state["identified"] = true
	return true

# Пакетный коммит без событий: все предметы обновляются до уведомлений.
func advance_equipped_learning(actor: StringName, ids: Array, weapon: StringName) -> bool:
	if not ItemLearningProgressService.authorizes_commit(actor, ids, weapon): return false
	var unique := {}
	for id in ids:
		if not id is StringName or id == &"" or unique.has(id) or not _instances.has(id): return false
		unique[id] = true
		var item: Dictionary = _instances[id]
		var schema = item.get("learning", null)
		var state = item.get("learning_state", null)
		if not schema is Dictionary or schema.get("progress_kind", null) != ("weapon_strikes" if id == weapon else "owner_actions") or not state is Dictionary or state.get("identified", null) != false or not state.get("progress", null) is int or state["progress"] < 0 or state["progress"] >= schema.get("full_progress", 0): return false
	for id in ids:
		var item: Dictionary = _instances[id]
		item["learning_state"]["progress"] += 1
		if item["learning_state"]["progress"] == item["learning"]["full_progress"]: item["learning_state"]["identified"] = true
	return true
