extends Node
## Однотайловые непроходимые объекты; позиции предоставляет внешний генератор.
var _objects: Dictionary = {} # entity -> record
var _pending: Dictionary = {} # actor -> object
var _reserved: Dictionary = {} # object -> actor
var _busy := false
var _materializing_object: StringName = &""
var _materializing_item: StringName = &""
var _rollback_entity: StringName = &""
var _obstacle_entity: StringName = &""
var _checking_removal: Dictionary = {}
var _transition_clearing := false
var _transition_inventories: Dictionary = {}
var _transition_discard_ids: Array = []
var _duration := 0.1
var _scale := 4

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var params: Dictionary = rules["ruleset"].get("parameters", {})
		_duration = float(params.get("objects", {}).get("interaction_duration", 0.1))
		_scale = int(params.get("space", {}).get("tiles_per_cell", 4))
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":&"object_interact", "name":"Взаимодействие с объектом", "type":&"utility", "base_duration":_duration, "interruptible":true}})
	EventBus.subscribe(&"RoomCreated", _room_created)
	EventBus.subscribe(&"RoomObjectsGenerateRequested", _generate_room)
	EventBus.subscribe(&"RoomObjectsGetRequested", _room_objects)
	EventBus.subscribe(&"ObjectVisualsGetRequested", _visual_objects)
	EventBus.subscribe(&"ObjectCreateRequested", _create)
	EventBus.subscribe(&"ChestConsumableDraftMaterializeRequested", _materialize_consumables)
	EventBus.subscribe(&"ChestPlainDraftMaterializeRequested", _materialize_plain)
	EventBus.subscribe(&"ChestDraftMaterializeRequested", _materialize_all)
	EventBus.subscribe(&"ChestDraftReadinessRequested", _draft_readiness)
	EventBus.subscribe(&"ObjectGetRequested", _get_object)
	EventBus.subscribe(&"ObjectContainerGetRequested", _container)
	EventBus.subscribe(&"ObjectInteractRequested", _interact)
	EventBus.subscribe(&"ObjectRemoveRequested", _remove)
	EventBus.subscribe(&"ActionCompleted", _completed)
	EventBus.subscribe(&"ActionInterrupted", _interrupted)
	EventBus.subscribe(&"EntityMoved", _moved)
	EventBus.subscribe(&"EntityRemoved", _removed)
	EventBus.subscribe(&"LootEntityRemovalCheckRequested", _removal_check)
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested", _ownership_mutation_check)
	EventBus.subscribe(&"EntityInventoryChangeCheckRequested", _inventory_change_check)
	EventBus.subscribe(&"ObjectObstacleMutationCheckRequested", _obstacle_check)
	EventBus.subscribe(&"CombatDamageAllowedRequested", _damage_check)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"ObjectSnapshotValidateRequested", _validate)

func _room_created(event: Dictionary) -> void:
	if _busy: return
	var points := {"room":event.get("room", &""), "room_type":event.get("type", ""), "points":[]}
	EventBus.publish(&"ObjectGenerationPointsRequested", points)
	if not points.get("points", null) is Array:
		EventBus.publish(&"RoomObjectsGenerationIncomplete", {"room":points["room"], "created":[], "failed_index":-1})
		return
	if points["points"].is_empty(): return
	var generation := {"room":points["room"], "objects":points["points"]}
	_generate_room(generation)
	if not generation.get("accepted", false):
		EventBus.publish(&"RoomObjectsGenerationIncomplete", {"room":points["room"], "created":generation.get("created", []), "failed_index":generation.get("failed_index", -1)})

func _generate_room(event: Dictionary) -> void:
	event["accepted"] = false
	var room = event.get("room", null)
	var specs = event.get("objects", null)
	if _busy or not room is StringName or room == &"" or not specs is Array or specs.size() > 256: return
	var created: Array = []
	for i in range(specs.size()):
		if not specs[i] is Dictionary:
			event["created"] = created
			event["failed_index"] = i
			return
		var request: Dictionary = specs[i].duplicate(true)
		request["room"] = room
		_create(request)
		if not request["accepted"]:
			event["created"] = created
			event["failed_index"] = i
			event["error"] = request.get("error", "Объект не создан")
			return
		created.append(request["entity"])
	event["accepted"] = true
	event["created"] = created
	EventBus.publish(&"RoomObjectsGenerated", {"room":room, "objects":created.duplicate()})

func _create(event: Dictionary) -> void:
	event["accepted"] = false
	var id = event.get("entity", null)
	var kind_value = event.get("type", null)
	var kind := str(kind_value)
	var room = event.get("room", null)
	var tile = event.get("tile", null)
	var visual = event.get("visual", {})
	var interaction = event.get("interaction", {})
	var capacity = event.get("inventory_capacity", null)
	if _busy or not id is StringName or id == &"" or not room is StringName or room == &"" or not (kind_value is String or kind_value is StringName) or kind not in ["chest", "altar", "stairs_down", "portal_exit"] or not tile is Vector2i or not visual is Dictionary or not interaction is Dictionary or not _safe(visual,0) or not _safe(interaction,0): return
	if kind == "portal_exit":
		var permit := {"entity":id, "room":room, "allowed":false}
		EventBus.publish(&"DungeonPortalCreateCheckRequested", permit)
		if not permit.get("allowed", false): return _fail(event, "Создание портала не разрешено")
	if kind == "chest":
		var portal := {"room":room, "accepted":false, "protected":false}
		EventBus.publish(&"DungeonPortalRoomCheckRequested", portal)
		if not portal.get("accepted", false) or portal.get("protected", false): return _fail(event, "Сундук в комнате портала запрещён")
	if capacity != null and (kind != "chest" or not _nonnegative(capacity)): return
	if _objects.has(id): return
	_busy = true
	_create_locked(event, id, kind, room, tile, visual, interaction, capacity)
	_busy = false

func _create_locked(event: Dictionary, id: StringName, kind: String, room: StringName, tile: Vector2i, visual: Dictionary, interaction: Dictionary, capacity: Variant) -> void:
	var room_query := {"id":room, "found":false}
	EventBus.publish(&"RoomGetRequested", room_query)
	if not room_query["found"]: return _fail(event, "Комната не найдена")
	var bounds := Rect2i(room_query["data"]["origin_cell"] * _scale, room_query["data"]["size_cells"] * _scale)
	if not bounds.has_point(tile): return _fail(event, "Тайл вне комнаты")
	var check := {"tile":tile}
	EventBus.publish(&"SpaceTileGetRequested", check)
	if not check.get("in_bounds", false) or check.get("kind", 0) != 1 or check.get("passage", false) or check.get("occupant", null) != null or check.get("obstacle", null) != null: return _fail(event, "Тайл непригоден или занят")
	var ground := {"tile":tile}
	EventBus.publish(&"LootGetRequested", ground)
	if not ground.get("items", {}).is_empty(): return _fail(event, "На тайле лежат предметы")
	var record := {"id":id, "type":kind, "room":room, "tile":tile, "opened":false, "visual":visual.duplicate(true), "interaction":interaction.duplicate(true)}
	var components := {&"world_object":{"type":kind, "room":room}, &"object_position":{"tile":tile}, &"object_interaction":interaction.duplicate(true), &"object_visual":visual.duplicate(true)}
	var create := {"entity":id, "components":components, "accepted":false}
	EventBus.publish(&"EntityCreateRequested", create)
	if not create["accepted"]: return _fail(event, "Сущность уже существует или не создана")
	var obstacle := {"entity":id, "tile":tile, "accepted":false}
	_obstacle_entity = id
	EventBus.publish(&"SpaceObstaclePlaceRequested", obstacle)
	_obstacle_entity = &""
	if not obstacle["accepted"]:
		_rollback_created(event, id, record)
		return _fail(event, "Не удалось зарезервировать тайл объекта")
	if kind == "chest" and capacity != null:
		var inv := {"entity":id, "volume":capacity, "accepted":false}
		EventBus.publish(&"InventoryConfigureRequested", inv)
		if not inv["accepted"]:
			_rollback_created(event, id, record)
			return _fail(event, "Не удалось настроить объём сундука")
	_objects[id] = record
	event["accepted"] = true
	EventBus.publish(&"ObjectCreated", {"object":id, "type":kind, "room":room, "tile":tile})

func _rollback_created(event: Dictionary, id: StringName, record: Dictionary) -> void:
	_rollback_entity = id
	var removal := {"entity":id, "accepted":false}
	EventBus.publish(&"EntityRemoveRequested", removal)
	_rollback_entity = &""
	if removal["accepted"]: return
	var entity := {"entity":id, "found":false}
	EventBus.publish(&"EntityGetRequested", entity)
	if not entity["found"]: return
	var obstacles := {}
	EventBus.publish(&"SpaceObstaclesGetRequested", obstacles)
	if obstacles.get("obstacles", {}).get(record["tile"], null) == id: _objects[id] = record
	event["incomplete"] = id
	EventBus.publish(&"ObjectGenerationIncomplete", {"object":id, "room":record["room"], "reason":"rollback_blocked"})

# Только внутренняя фиксация в транзакции. План не равен готовой добыче.
func can_attach_chest_draft(id: StringName) -> bool:
	if _busy or not _objects.has(id) or _objects[id]["type"] != "chest" or _objects[id]["opened"] or _objects[id].has("content_draft") or _pending.values().has(id): return false
	var inv := {"entity":id, "found":false}
	EventBus.publish(&"InventoryGetRequested", inv)
	return inv.get("found", false) and inv.get("data", {}).get("items", null) is Array and inv["data"]["items"].is_empty()

func attach_chest_draft_for_transition(id: StringName, draft: Dictionary) -> bool:
	if not SaveService.world_transition_operation_active() or not can_attach_chest_draft(id): return false
	_objects[id]["content_draft"] = draft.duplicate(true)
	return true

func _valid_content_draft(d: Variant, bases: Dictionary, materials: Dictionary) -> bool:
	if not d is Dictionary or d.get("complete", null) != false or d.get("kind", null) not in ["normal", "boss"]: return false
	var depth = d.get("depth", null)
	if not (depth is float or depth is int) or not is_finite(float(depth)) or float(depth) < 0 or float(depth) > 10000: return false
	var slots = d.get("slots", null)
	if not slots is Array or slots.size() < (4 if d["kind"] == "boss" else 2) or slots.size() > (8 if d["kind"] == "boss" else 5): return false
	var level := maxi(1, 1 + floori(float(depth) / 3.0))
	for entry in slots:
		if not entry is Dictionary or not entry.get("base_id", null) is StringName or not bases.has(entry["base_id"]) or not bases[entry["base_id"]] is Dictionary: return false
		var slot := str(bases[entry["base_id"]].get("slot", ""))
		if entry.get("category", null) == "equipment":
			if slot not in ["weapon", "shield", "body"] or not entry.get("item_level", null) is int or entry["item_level"] not in [level, level + 1] or entry.get("rarity", null) not in [&"normal", &"magic", &"rare"]: return false
			var expected: Array = DungeonChestMaterialsService._resolve(entry["base_id"], entry["item_level"], bases, materials)
			if expected.is_empty() or entry.get("materials", null) != expected: return false
			var learning: Dictionary = DungeonChestLearningService.schema_for(entry["base_id"], bases)
			if learning.is_empty() or entry.get("learning", null) != learning: return false
			if not DungeonChestModDraftService.validate_fixed_mods(entry, {"bases":bases, "materials":materials}): return false
		elif entry.get("category", null) == "consumable":
			if slot != "consumable" or not entry.get("item_level", null) is int or entry["item_level"] not in [level, level + 1] or entry.get("rarity", null) != &"normal" or entry.get("mods", null) != []: return false
			var expected: Array = DungeonChestMaterialsService.resolve_consumable(entry["base_id"], bases, materials)
			if expected.is_empty() or entry.get("materials", null) != expected: return false
		else: return false
	return true

# ID явно задаются вызывающим кодом и проверяются на уникальность до изменений.
func _materialize_consumables(event: Dictionary) -> void:
	_materialize_plain_draft(event, false)

# Диагностика сохранённого плана: не материализация и не проверка вместимости.
func _draft_readiness(event: Dictionary) -> void:
	event["accepted"] = false
	for key in ["slots", "plain_supported", "consumables_only", "unsupported_mod_ids", "error"]: event.erase(key)
	var id = event.get("object", null)
	if _busy or not id is StringName or id == &"":
		event["error"] = "Нужен доступный сундук"; return
	var snapshot: Dictionary = SaveService.collect_world_transition_snapshot()
	if not snapshot.get("valid",false):
		event["error"] = "Снимок недоступен"; return
	var objects: Dictionary = snapshot["payload"]["sections"]["objects"]["objects"]
	if not objects.has(id) or objects[id].get("type","") != "chest" or objects[id].get("opened",true) or not objects[id].has("content_draft"):
		event["error"] = "Нет закрытого сундука с планом"; return
	var draft: Dictionary = objects[id]["content_draft"]
	var results: Array = []
	var missing: Array = []
	var plain := true
	var consumables_only := true
	for i in range(draft["slots"].size()):
		var slot: Dictionary = draft["slots"][i]
		var equipment: bool = slot["category"] == "equipment"
		var eligible: bool = not equipment or (slot["rarity"] == &"normal" and slot["mods"].is_empty())
		if equipment: consumables_only = false
		if not eligible: plain = false
		var unimplemented: Array = []
		for mod in slot["mods"]:
			var mod_id: StringName = mod["id"]
			if mod_id not in [&"pre_armour", &"suf_perception", &"suf_wisdom", &"pre_vital", &"pre_strength", &"pre_agile", &"pre_mind", &"affix_hp", &"affix_stamina", &"affix_mana", &"suf_physical_damage"]:
				unimplemented.append(mod_id)
				if not missing.has(mod_id): missing.append(mod_id)
		results.append({"index":i, "category":slot["category"], "rarity":slot["rarity"], "plain_supported":eligible, "unsupported_mod_ids":unimplemented})
	event["slots"] = results
	event["plain_supported"] = plain
	event["consumables_only"] = consumables_only
	event["unsupported_mod_ids"] = missing
	event["accepted"] = true

func _materialize_plain(event: Dictionary) -> void:
	_materialize_plain_draft(event, true)

func _materialize_all(event: Dictionary) -> void:
	_materialize_plain_draft(event, true, true)

func _materialize_plain_draft(event: Dictionary, allow_equipment: bool, allow_magic: bool = false) -> void:
	event["accepted"] = false
	event["rolled_back"] = false
	for key in ["items", "error", "fatal"]: event.erase(key)
	var id = event.get("object", null)
	var ids = event.get("item_ids", null)
	if _busy or not id is StringName or id == &"" or not ids is Array or ids.is_empty() or ids.size() > 8:
		event["error"] = "Нужны сундук и список ID предметов"; return
	var unique := {}
	for item in ids:
		if not item is StringName or item == &"" or unique.has(item):
			event["error"] = "ID должны быть непустыми и различными"; return
		unique[item] = true
	var work := {"error":"", "expected":{}}
	var tx: Dictionary = SaveService.run_world_transition_transaction(func(): return _materialize_draft_transition(id,ids,allow_equipment,allow_magic,work))
	_materializing_object = &""
	_materializing_item = &""
	_busy = false
	event["accepted"] = tx.get("committed",false)
	event["rolled_back"] = tx.get("rolled_back",false)
	if tx.get("fatal",false): event["fatal"] = true
	if event["accepted"]: event["items"] = ids.duplicate()
	else: event["error"] = work["error"] if not work["error"].is_empty() else tx.get("error","Операция недоступна")

# Внутренний шаг общей транзакции; после ошибки внешний вызывающий обязан откатить её.
func materialize_boss_draft_for_transition(id: StringName, ids: Array) -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy or id == &"" or ids.size() < 4 or ids.size() > 8: return {"accepted":false,"error":"Операция недоступна"}
	var unique := {}
	for item in ids:
		if not item is StringName or item == &"" or unique.has(item): return {"accepted":false,"error":"Некорректные ID"}
		unique[item] = true
	var work := {"error":"", "expected":{}, "expected_kind":"boss"}
	var ok := _materialize_draft_transition(id,ids,true,true,work)
	_materializing_object = &""
	_materializing_item = &""
	_busy = false
	return {"accepted":ok,"error":work["error"]}

# Внутренний шаг для обычного сундука в его транзакции.
func materialize_normal_draft_for_transition(id: StringName, ids: Array) -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy or id == &"" or ids.size() < 2 or ids.size() > 5: return {"accepted":false,"error":"Операция недоступна"}
	var unique := {}
	for item in ids:
		if not item is StringName or item == &"" or unique.has(item): return {"accepted":false,"error":"Некорректные ID"}
		unique[item] = true
	var work := {"error":"", "expected":{}, "expected_kind":"normal"}
	var ok := _materialize_draft_transition(id,ids,true,true,work)
	_materializing_object = &""
	_materializing_item = &""
	_busy = false
	return {"accepted":ok,"error":work["error"]}

func _materialize_draft_transition(id: StringName, ids: Array, allow_equipment: bool, allow_magic: bool, work: Dictionary) -> bool:
	var before: Dictionary = SaveService._collect_transition_snapshot()
	if not before.get("valid",false): return _materialize_fail(work, "Снимок недоступен")
	var sections: Dictionary = before["payload"]["sections"]
	var objects: Dictionary = sections["objects"]["objects"]
	if not objects.has(id) or objects[id]["type"] != "chest" or objects[id]["opened"] or not objects[id].has("content_draft"): return _materialize_fail(work,"Нет закрытого сундука с планом")
	var draft: Dictionary = objects[id]["content_draft"]
	if work.has("expected_kind") and draft.get("kind",null) != work["expected_kind"]: return _materialize_fail(work,"Тип плана не соответствует операции")
	if draft["slots"].size() != ids.size(): return _materialize_fail(work,"Число ID не совпадает с планом")
	for slot in draft["slots"]:
		if slot["category"] == "consumable": continue
		if not allow_equipment or slot["category"] != "equipment" or (not allow_magic and (slot["rarity"] != &"normal" or not slot["mods"].is_empty())):
			return _materialize_fail(work,"Поддерживаются только расходники и обычная экипировка без модов" if allow_equipment else "Пока поддерживается только план из расходников")
	for item in ids:
		if sections["items"]["instances"].has(item) or sections["items"]["retired"].has(item): return _materialize_fail(work,"ID предмета уже использован")
	_busy = true
	_materializing_object = id
	var ok := _materialize_plain_locked(id, ids, draft, work)
	_materializing_object = &""
	_materializing_item = &""
	_busy = false
	if not ok: return false
	var after: Dictionary = SaveService._collect_transition_snapshot()
	if not after.get("valid",false): return _materialize_fail(work,"Итоговый снимок недоступен")
	# Допускаем только заявленные экземпляры, инвентарь и отметку сундука.
	var expected: Dictionary = sections.duplicate(true)
	expected["objects"]["objects"][id].erase("content_draft")
	expected["objects"]["objects"][id]["content_fixed"] = true
	expected["entities"][id][&"inventory"]["items"] = ids.duplicate()
	for item in ids: expected["items"]["instances"][item] = work["expected"][item]
	if expected != after["payload"]["sections"]: return _materialize_fail(work,"Во время создания изменилось постороннее состояние")
	return true

func _materialize_plain_locked(id: StringName, ids: Array, draft: Dictionary, work: Dictionary) -> bool:
	for i in range(ids.size()):
		var item: StringName = ids[i]
		var slot: Dictionary = draft["slots"][i]
		var rarity := {"rarity":slot["rarity"], "set_id":null, "accepted":false}
		EventBus.publish(&"ItemRarityPrepareRequested", rarity)
		if not rarity.get("accepted",false) or rarity.get("extra_category",null) != null: return _materialize_fail(work,"Редкость недоступна или требует случайного выбора")
		var req := {"rank":rarity["rank"], "item_level":slot["item_level"], "accepted":false}
		EventBus.publish(&"ItemIdentificationRequirementCalculateRequested", req)
		if not req.get("accepted",false): return _materialize_fail(work,"Не вычислено требование опознания")
		var create := {"id":item, "base_id":slot["base_id"], "item_level":slot["item_level"], "rarity":slot["rarity"], "materials":slot["materials"].duplicate(true), "accepted":false}
		if slot["category"] == "equipment": create["learning"] = slot["learning"].duplicate(true)
		EventBus.publish(&"ItemCreateRequested", create)
		if not create.get("accepted",false): return _materialize_fail(work,"Не удалось создать предмет")
		var expected := {"id":item, "base_id":slot["base_id"], "materials":slot["materials"].duplicate(true), "weight_modifier":1.0, "volume_modifier":1.0, "item_level":slot["item_level"], "int_req":req["value"], "mods":slot["mods"].duplicate(true), "rarity":slot["rarity"], "set_id":null, "rarity_extra_category":null}
		if slot["category"] == "equipment":
			expected["learning"] = slot["learning"].duplicate(true)
			expected["learning_state"] = {"progress":0, "identified":false}
		for mod in slot["mods"]:
			var attach := {"item":item, "mod":mod.duplicate(true), "accepted":false}
			EventBus.publish(&"ItemModAttachRequested", attach)
			if not attach.get("accepted",false): return _materialize_fail(work,"Не удалось закрепить мод из плана")
		var actual := {"item":item, "found":false}
		EventBus.publish(&"ItemGetRequested", actual)
		if not actual.get("found",false) or actual["item_data"] != expected: return _materialize_fail(work,"Созданная вещь отличается от плана")
		work["expected"][item] = expected
		_materializing_item = item
		var add := {"entity":id, "item":item, "accepted":false}
		EventBus.publish(&"InventoryAddRequested", add)
		_materializing_item = &""
		if not add.get("accepted",false): return _materialize_fail(work,"Не удалось поместить предмет в сундук: проверьте вместимость")
	if not _objects.has(id) or _objects[id].get("content_draft", null) != draft: return _materialize_fail(work,"План сундука изменился")
	_objects[id].erase("content_draft")
	_objects[id]["content_fixed"] = true
	return true

func _materialize_fail(work: Dictionary, text: String) -> bool:
	work["error"] = text
	return false

# Только видимые внешние признаки; содержимое сундука не возвращается.
func _visual_objects(event: Dictionary) -> void:
	event["objects"] = []
	for record in _objects.values():
		if record.get("type","") in ["chest","stairs_down","portal_exit"] and record.get("tile",null) is Vector2i:
			event["objects"].append({"tile":record["tile"],"type":record["type"],"opened":record.get("opened",false)})

func _room_objects(event: Dictionary) -> void:
	var room = event.get("room", null)
	event["objects"] = {}
	for id in _objects:
		if _objects[id]["room"] == room: event["objects"][id] = _objects[id].duplicate(true)

func _get_object(event: Dictionary) -> void:
	var id = event.get("object", null)
	event["found"] = _objects.has(id)
	if event["found"]: event["data"] = _objects[id].duplicate(true)

func _container(event: Dictionary) -> void:
	event["found"] = false
	var id = event.get("object", null)
	var actor = event.get("entity", null)
	if not _objects.has(id) or _objects[id]["type"] != "chest" or not _objects[id]["opened"] or not actor is StringName or not _adjacent(actor, _objects[id]): return
	var inv := {"entity":id, "found":false}
	EventBus.publish(&"InventoryGetRequested", inv)
	if inv["found"]:
		event["found"] = true
		event["inventory"] = inv.get("data", {}).duplicate(true)
		event["volume_known"] = inv.get("volume_known", false)

func _interact(event: Dictionary) -> void:
	event["accepted"] = false
	var actor = event.get("entity", null)
	var id = event.get("object", null)
	var duration = event.get("duration", _duration)
	if _busy or not actor is StringName or not id is StringName or not _objects.has(id) or _pending.has(actor) or _reserved.has(id): return
	if _objects[id].has("content_draft"):
		event["error"] = "Содержимое сундука ещё не сформировано"
		return
	if _objects[id]["type"] == "portal_exit":
		var portal := {"entity":actor, "object":id, "accepted":false}
		EventBus.publish(&"DungeonPortalInteractRequested", portal)
		event["accepted"] = portal.get("accepted", false)
		event["rule_allowed"] = portal.get("rule_allowed", false)
		event["error"] = portal.get("error", "Портал недоступен")
		return
	if not _valid_duration(duration): return
	if _objects[id]["type"] == "stairs_down":
		var descend := {"entity":actor, "object":id, "accepted":false}
		EventBus.publish(&"DungeonDescentAutoRequested", descend)
		event["accepted"] = descend.get("accepted", false)
		if event["accepted"]:
			event["duration"] = descend["duration"]
			event["floor"] = descend["floor"]
		else: event["error"] = descend.get("error", "Спуск недоступен")
		return
	_busy = true
	var control := {}
	EventBus.publish(&"GameModeGetRequested", control)
	if actor != control.get("entity", &"") or not _adjacent(actor, _objects[id]):
		_busy = false
		return
	_pending[actor] = id
	_reserved[id] = actor
	var start := {"entity":actor, "action":&"object_interact", "duration":float(duration), "accepted":false}
	EventBus.publish(&"ActionStartRequested", start)
	var action := {"entity":actor, "found":false}
	EventBus.publish(&"ActionGetRequested", action)
	if not start["accepted"] or not _pending.has(actor) or not action["found"] or action["data"]["id"] != &"object_interact" or not _objects.has(id) or not _adjacent(actor, _objects[id]):
		if action["found"] and action["data"]["id"] == &"object_interact": EventBus.publish(&"ActionCancelRequested", {"entity":actor, "reason":&"object_out_of_reach"})
		_clear(actor)
		_busy = false
		return
	event["accepted"] = true
	_busy = false
	EventBus.publish(&"ObjectInteractionStarted", {"entity":actor, "object":id, "duration":float(duration)})

func _completed(event: Dictionary) -> void:
	var actor: StringName = event.get("entity", &"")
	if event.get("action", &"") != &"object_interact" or not _pending.has(actor): return
	var id: StringName = _pending[actor]
	_busy = true
	var ok := _objects.has(id) and _adjacent(actor, _objects[id])
	var data: Dictionary = _objects[id].duplicate(true) if ok else {}
	if ok and data["type"] == "chest":
		_objects[id]["opened"] = true
		data["opened"] = true
	_clear(actor)
	_busy = false
	if not ok:
		EventBus.publish(&"ObjectInteractionFailed", {"entity":actor, "object":id, "reason":"недоступен или слишком далеко"})
		return
	if data["type"] == "chest": EventBus.publish(&"ChestOpened", {"entity":actor, "object":id})
	EventBus.publish(&"ObjectInteractionCompleted", {"entity":actor, "object":id, "type":data["type"], "interaction":data["interaction"].duplicate(true)})

func _interrupted(event: Dictionary) -> void:
	var actor: StringName = event.get("entity", &"")
	if event.get("action", &"") != &"object_interact" or not _pending.has(actor): return
	var id: StringName = _pending[actor]
	_clear(actor)
	EventBus.publish(&"ObjectInteractionInterrupted", {"entity":actor, "object":id, "reason":event.get("reason", &"cancelled")})

func _moved(event: Dictionary) -> void:
	var actor: StringName = event.get("entity", &"")
	if _pending.has(actor) and (not _objects.has(_pending[actor]) or not _adjacent(actor, _objects[_pending[actor]])):
		EventBus.publish(&"ActionCancelRequested", {"entity":actor, "reason":&"object_out_of_reach"})

# Внутренний шаг смены этажа. Удаляет только зарегистрированные мировые
# объекты и их инвентари, не трогает другие сущности. Вызывающий обязан
# выполнить его внутри run_world_transition_transaction.
func discard_objects_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy or not _pending.is_empty() or not _reserved.is_empty() or not _checking_removal.is_empty():
		return {"accepted":false, "error":"Объекты заняты или нет операции перехода"}
	_busy = true
	_transition_clearing = true
	_transition_inventories.clear()
	var objects: Array = _objects.keys()
	objects.sort_custom(func(a, b): return str(a) < str(b))
	var ids: Array = []
	var seen := {}
	var error := ""
	var control := {}
	EventBus.publish(&"GameModeGetRequested", control)
	for object in objects:
		if object == control.get("entity", &""):
			error = "Мировой объект является управляемой сущностью"
			break
		var entity := {"entity":object, "found":false}
		EventBus.publish(&"EntityGetRequested", entity)
		if not entity.get("found", false):
			error = "Сущность мирового объекта отсутствует"
			break
		var components: Dictionary = entity["data"]
		var inventory = components.get(&"inventory", null)
		if not inventory is Dictionary or not inventory.get("items", null) is Array or not _empty_equipment(components.get(&"equipment", {}), 0):
			error = "Некорректный инвентарь или экипировка объекта"
			break
		var contained: Array = inventory["items"].duplicate()
		for id in contained:
			if not id is StringName or id == &"" or seen.has(id):
				error = "Некорректный или повторный предмет объекта"
				break
			seen[id] = true
			var q := {"item":id, "found":false}
			EventBus.publish(&"ItemGetRequested", q)
			if not q.get("found", false):
				error = "Предмет объекта отсутствует"
				break
			ids.append(id)
		if not error.is_empty(): break
		_transition_inventories[object] = contained
	if not SaveService.world_transition_operation_active(): error = "Операция перехода прервана"
	ids.sort_custom(func(a, b): return str(a) < str(b))
	var changed := false
	if error.is_empty():
		_transition_discard_ids = ids.duplicate()
		# Без событий: нельзя наблюдать промежуточные ссылки без экземпляров.
		for object in objects:
			if not EntityRegistry.empty_object_inventory_for_transition(object, _transition_inventories[object]):
				error = "Не удалось очистить контейнер объекта"
				break
			changed = true
		if error.is_empty() and not ItemService.retire_world_items_for_transition(ids): error = "Не удалось списать содержимое объектов"
		_transition_discard_ids.clear()
	if error.is_empty():
		for object in objects:
			_rollback_entity = object
			var removal := {"entity":object, "accepted":false}
			EventBus.publish(&"EntityRemoveRequested", removal)
			_rollback_entity = &""
			if not removal.get("accepted", false):
				error = "Не удалось удалить мировой объект %s" % str(object)
				break
			changed = true
			if not SaveService.world_transition_operation_active():
				error = "Операция перехода прервана"
				break
	_transition_inventories.clear()
	_transition_discard_ids.clear()
	_transition_clearing = false
	_busy = false
	if not error.is_empty():
		if changed: SaveService.fail_world_transition(error)
		return {"accepted":false, "error":error}
	return {"accepted":true, "objects":objects, "items":ids}

func is_emptying_object_inventory(entity: StringName, ids: Array) -> bool:
	return _transition_clearing and _busy and SaveService.world_transition_operation_active() and _transition_inventories.has(entity) and _transition_inventories[entity] == ids

func is_discarding_object_items(ids: Array) -> bool:
	return _transition_clearing and _busy and SaveService.world_transition_operation_active() and ids == _transition_discard_ids

func _ownership_mutation_check(e: Dictionary) -> void:
	if _transition_clearing and _objects.has(e.get("entity", null)): e["allowed"] = false

# После открытия сундук не может пополняться; до открытия техническое
# заполнение пока остаётся доступно, генерация содержимого ещё не подключена.
func _inventory_change_check(e: Dictionary) -> void:
	var id = e.get("entity", null)
	if not _objects.has(id) or _objects[id]["type"] != "chest" or (not _objects[id]["opened"] and not _objects[id].has("content_draft") and not _objects[id].get("content_fixed", false)): return
	var before = e.get("before", null)
	var after = e.get("after", null)
	if not before is Dictionary or not after is Dictionary or not before.get("items", null) is Array or not after.get("items", null) is Array:
		e["allowed"] = false; return
	if _materializing_object == id and _materializing_item != &"" and SaveService.world_transition_operation_active():
		var expected: Dictionary = before.duplicate(true)
		expected["items"].append(_materializing_item)
		if after == expected: return
	for item in after["items"]:
		if not before["items"].has(item): e["allowed"] = false; return

func _empty_equipment(value: Variant, depth: int) -> bool:
	if depth > 32: return false
	if value == null: return true
	if value is Array:
		for child in value:
			if not _empty_equipment(child, depth + 1): return false
		return true
	if value is Dictionary:
		for child in value.values():
			if not _empty_equipment(child, depth + 1): return false
		return true
	return false

func _remove(event: Dictionary) -> void:
	event["accepted"] = false
	var id = event.get("object", null)
	if _busy or not id is StringName or not _objects.has(id): return
	var request := {"entity":id, "accepted":false}
	EventBus.publish(&"EntityRemoveRequested", request)
	event["accepted"] = request["accepted"]

func _removal_check(event: Dictionary) -> void:
	var id: StringName = event.get("entity", &"")
	if _busy and id != _rollback_entity:
		event["allowed"] = false
		return
	if _checking_removal.has(id):
		event["allowed"] = false
		return
	if _objects.has(id) and _objects[id]["type"] == "chest":
		# Пустой сундук не исчезает в рамках этажа. Только специальный
		# шаг перехода вправе удалить его после очистки содержимого.
		if not (_transition_clearing and _busy and _rollback_entity == id and SaveService.world_transition_operation_active()):
			event["allowed"] = false
			return
		_checking_removal[id] = true
		var inv := {"entity":id, "found":false}
		EventBus.publish(&"InventoryGetRequested", inv)
		_checking_removal.erase(id)
		if not inv["found"] or not inv["data"].get("items", []).is_empty(): event["allowed"] = false

func _obstacle_check(event: Dictionary) -> void:
	var id: StringName = event.get("entity", &"")
	if (_busy and id != _obstacle_entity) or (_objects.has(id) and id != _obstacle_entity): event["allowed"] = false

func _damage_check(event: Dictionary) -> void:
	if _objects.has(event.get("entity", null)) or _busy: event["allowed"] = false

func _removed(event: Dictionary) -> void:
	var id: StringName = event.get("entity", &"")
	if _objects.has(id):
		if _reserved.has(id): EventBus.publish(&"ActionCancelRequested", {"entity":_reserved[id], "reason":&"object_removed"})
		_objects.erase(id)
		EventBus.publish(&"ObjectRemoved", {"object":id})
	if _pending.has(id): _clear(id)

func _clear(actor: StringName) -> void:
	if _pending.has(actor):
		_reserved.erase(_pending[actor])
		_pending.erase(actor)

func _adjacent(actor: StringName, object: Dictionary) -> bool:
	var body := {"entity":actor, "found":false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	if not body["found"]: return false
	var a: Vector2i = body["data"]["anchor"]
	var n: int = body["data"]["size"]
	var p: Vector2i = object["tile"]
	var room := {"id":object["room"], "found":false}
	EventBus.publish(&"RoomGetRequested", room)
	if not room["found"]: return false
	var bounds := Rect2i(room["data"]["origin_cell"] * _scale, room["data"]["size_cells"] * _scale)
	if not bounds.encloses(Rect2i(a, Vector2i.ONE * n)): return false
	return ((p.x == a.x - 1 or p.x == a.x + n) and p.y >= a.y and p.y < a.y + n) or ((p.y == a.y - 1 or p.y == a.y + n) and p.x >= a.x and p.x < a.x + n)

func _safe(value: Variant, depth: int) -> bool:
	if depth > 64: return false
	match typeof(value):
		TYPE_NIL, TYPE_BOOL, TYPE_INT, TYPE_FLOAT, TYPE_STRING, TYPE_STRING_NAME, TYPE_VECTOR2, TYPE_VECTOR2I, TYPE_VECTOR3, TYPE_VECTOR3I, TYPE_COLOR: return true
		TYPE_ARRAY:
			for item in value:
				if not _safe(item, depth + 1): return false
			return true
		TYPE_DICTIONARY:
			for key in value:
				if not _safe(key, depth + 1) or not _safe(value[key], depth + 1): return false
			return true
	return false

func _nonnegative(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v)) and float(v) >= 0.0
func _valid_duration(v: Variant) -> bool:
	return _nonnegative(v) and float(v) >= 0.01 and float(v) <= 10000000.0 and absf(round(float(v) / 0.01) * 0.01 - float(v)) < 0.000001
func _fail(event: Dictionary, message: String) -> void:
	event["error"] = message

func _collect(event: Dictionary) -> void:
	if _busy:
		event["errors"].append("Нельзя сохранять во время изменения объектов")
		return
	event["sections"]["objects"] = {"objects":_objects.duplicate(true), "pending":_pending.duplicate()}
func _apply(event: Dictionary) -> void:
	_objects = event["sections"]["objects"]["objects"].duplicate(true)
	_pending = event["sections"]["objects"]["pending"].duplicate()
	_transition_clearing = false
	_transition_inventories.clear()
	_transition_discard_ids.clear()
	_materializing_object = &""
	_materializing_item = &""
	_reserved.clear()
	for actor in _pending: _reserved[_pending[actor]] = actor
	_busy = false

func _validate(event: Dictionary) -> void:
	event["valid"] = false
	var sections = event.get("sections", null)
	if not sections is Dictionary or not sections.get("objects", null) is Dictionary or not sections.get("space", null) is Dictionary or not sections.get("rooms", null) is Dictionary or not sections.get("entities", null) is Dictionary or not sections.get("actions", null) is Dictionary: return
	var snapshot: Dictionary = sections["objects"]
	var space: Dictionary = sections["space"]
	var rooms: Dictionary = sections["rooms"]
	var entities: Dictionary = sections["entities"]
	var actions: Dictionary = sections["actions"]
	if not snapshot.get("objects", null) is Dictionary or not snapshot.get("pending", null) is Dictionary or not space.get("obstacles", null) is Dictionary or not space.get("floor", null) is Dictionary or not space.get("passages", null) is Dictionary or not space.get("bodies", null) is Dictionary or not rooms.get("rooms", null) is Dictionary or not actions.get("active", null) is Dictionary or not actions.get("controlled", null) is StringName: return
	var records: Dictionary = snapshot["objects"]
	if records.size() != space["obstacles"].size(): return
	var occupied: Dictionary = {}
	for entity in space["bodies"]:
		var body = space["bodies"][entity]
		if not body is Dictionary or not body.get("anchor", null) is Vector2i or not body.get("size", null) is int or body["size"] <= 0 or body["size"] > 64: return
		for x in range(body["anchor"].x, body["anchor"].x + body["size"]):
			for y in range(body["anchor"].y, body["anchor"].y + body["size"]): occupied[Vector2i(x,y)] = true
	for id in records:
		var o = records[id]
		if not id is StringName or id == &"" or not o is Dictionary or o.get("id", null) != id or o.get("type", null) not in ["chest", "altar", "stairs_down", "portal_exit"] or not o.get("room", null) is StringName or not o.get("tile", null) is Vector2i or not o.get("opened", null) is bool or not o.get("visual", null) is Dictionary or not o.get("interaction", null) is Dictionary: return
		if o["type"] in ["altar", "stairs_down", "portal_exit"] and o["opened"]: return
		if o.has("content_fixed") and (o["type"] != "chest" or o["content_fixed"] != true or o.has("content_draft")): return
		if o.has("content_draft"):
			if o["type"] != "chest" or not sections.get("items", null) is Dictionary or not sections["items"].get("bases", null) is Dictionary or not _valid_content_draft(o["content_draft"], sections["items"]["bases"], sections["items"].get("materials", {})): return
		var tile: Vector2i = o["tile"]
		if space["obstacles"].get(tile, null) != id or not space["floor"].has(tile) or space["passages"].has(tile) or occupied.has(tile): return
		if not rooms["rooms"].has(o["room"]) or not entities.has(id) or not entities[id] is Dictionary: return
		var r = rooms["rooms"][o["room"]]
		if not r is Dictionary or not r.get("origin_cell", null) is Vector2i or not r.get("size_cells", null) is Vector2i or not Rect2i(r["origin_cell"] * _scale, r["size_cells"] * _scale).has_point(tile): return
		var e: Dictionary = entities[id]
		if not e.get(&"world_object", null) is Dictionary or e[&"world_object"].get("type", null) != o["type"] or e[&"world_object"].get("room", null) != o["room"] or not e.get(&"object_position", null) is Dictionary or e[&"object_position"].get("tile", null) != tile or e.get(&"object_visual", null) != o["visual"] or e.get(&"object_interaction", null) != o["interaction"]: return
		if o["type"] == "chest" and not e.get(&"inventory", null) is Dictionary: return
		if o.has("content_draft") and (o["opened"] or not e[&"inventory"].get("items", null) is Array or not e[&"inventory"]["items"].is_empty()): return
		if sections.has("loot"):
			if not sections["loot"] is Dictionary: return
			var ground = sections["loot"].get("ground", {})
			if not ground is Dictionary: return
			for item in ground:
				if ground[item] is Dictionary and ground[item].get("tile", null) == tile: return
	for entity in entities:
		if entities[entity] is Dictionary and entities[entity].has(&"world_object") and not records.has(entity): return
	var reserved: Dictionary = {}
	for actor in snapshot["pending"]:
		var id = snapshot["pending"][actor]
		if not actor is StringName or actor != actions["controlled"] or not id is StringName or not records.has(id) or reserved.has(id) or not space["bodies"].has(actor): return
		reserved[id] = true
		var action = actions["active"].get(actor, null)
		if not action is Dictionary or action.get("id", null) != &"object_interact": return
		var body: Dictionary = space["bodies"][actor]
		var a: Vector2i = body["anchor"]
		var n: int = body["size"]
		var p: Vector2i = records[id]["tile"]
		var room: Dictionary = rooms["rooms"][records[id]["room"]]
		if not Rect2i(room["origin_cell"] * _scale, room["size_cells"] * _scale).encloses(Rect2i(a,Vector2i.ONE*n)): return
		if not (((p.x == a.x-1 or p.x == a.x+n) and p.y >= a.y and p.y < a.y+n) or ((p.y == a.y-1 or p.y == a.y+n) and p.x >= a.x and p.x < a.x+n)): return
	# Нельзя восстанавливать действие без соответствующего ожидающего объекта.
	for actor in actions["active"]:
		var action = actions["active"][actor]
		if action is Dictionary and action.get("id", null) == &"object_interact" and not snapshot["pending"].has(actor): return
	event["valid"] = true
