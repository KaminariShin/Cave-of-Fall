extends RefCounted
## Чистый примитив: состояние хранит вызывающий код, не Accumulator.
## Все величины неотрицательны; целая часть ресурса выражена в int.

const MAX_EXACT_INTEGER: float = 9007199254740991.0

## Возвращает {ok, current, remainder, applied}, либо {ok: false, error}.
## Сумма amount может содержать более одной целой единицы.
static func accumulate(current: int, amount: float, maximum: int, remainder: float = 0.0) -> Dictionary:
	if current < 0 or maximum < 0 or current > maximum:
		return _error("current и maximum должны удовлетворять 0 <= current <= maximum")
	if float(maximum) > MAX_EXACT_INTEGER:
		return _error("maximum превышает точный диапазон целых чисел float")
	if not is_finite(amount) or amount < 0.0:
		return _error("amount должен быть конечным неотрицательным числом")
	if not is_finite(remainder) or remainder < 0.0 or remainder >= 1.0:
		return _error("remainder должен быть конечным числом от 0 включительно до 1 исключительно")
	# У полного ресурса остаток сбрасывается даже при нулевом пополнении.
	if current == maximum:
		return {"ok": true, "current": current, "remainder": 0.0, "applied": 0}
	var total := remainder + amount
	if not is_finite(total) or total > MAX_EXACT_INTEGER:
		return _error("сумма накопления слишком велика")
	var whole := int(floor(total))
	var applied: int = mini(whole, maximum - current)
	var new_current := current + applied
	var new_remainder: float = 0.0 if new_current >= maximum else total - float(whole)
	return {"ok": true, "current": new_current, "remainder": new_remainder, "applied": applied}

## Накопление без предела (например, счётчик шансов хода мира).
## Смысл выпавших целых единиц определяет вызывающая система.
static func accumulate_unbounded(remainder: float, amount: float) -> Dictionary:
	if not is_finite(remainder) or remainder < 0.0 or remainder >= 1.0:
		return _error("remainder должен быть конечным числом от 0 включительно до 1 исключительно")
	if not is_finite(amount) or amount < 0.0:
		return _error("amount должен быть конечным неотрицательным числом")
	var total := remainder + amount
	if not is_finite(total) or total > MAX_EXACT_INTEGER:
		return _error("сумма накопления слишком велика")
	var whole := int(floor(total))
	return {"ok": true, "whole": whole, "remainder": total - float(whole)}

static func _error(message: String) -> Dictionary:
	return {"ok": false, "error": message}
