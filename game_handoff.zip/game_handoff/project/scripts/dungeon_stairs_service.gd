extends Node
## Размещение лестницы-кандидата и предварительная проверка начала спуска.
var _state: Dictionary = {}
var _busy := false
var _combat_radius: Variant = null

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules.get("found", false): _combat_radius = rules["ruleset"].get("parameters", {}).get("dungeon", {}).get("stairs_combat_radius_tiles", null)
	EventBus.subscribe(&"DungeonMilestoneCandidateSelected", _selected)
	EventBus.subscribe(&"DungeonStairPlacementRetryRequested", _retry)
	EventBus.subscribe(&"DungeonStairGetRequested", _get_stair)
	EventBus.subscribe(&"DungeonStairAvailabilityRequested", _availability)
	EventBus.subscribe(&"DungeonStairTrialRequested", _trial_requested)
	EventBus.subscribe(&"ObjectRemoved", _object_removed)
	EventBus.subscribe(&"SpaceMapConfigured", _map_reset)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"DungeonStairSnapshotValidateRequested", _validate)

func _selected(e: Dictionary) -> void:
	if e.get("kind", "") != "stairs" or _busy or not _state.is_empty(): return
	_state = {"floor":e["floor"], "room":e["room"], "status":"failed", "object":null}
	_place()

func _retry(e: Dictionary) -> void:
	e["accepted"] = false
	if _busy or _state.is_empty() or _state["status"] != "failed": return
	_place()
	e["accepted"] = _state["status"] == "placed"

func _get_stair(e: Dictionary) -> void:
	e["found"] = not _state.is_empty()
	if e["found"]: e["data"] = _state.duplicate(true)

# Проверяет только начало спуска, не запускает действие и не меняет этаж.
func _availability(e: Dictionary) -> void:
	e["accepted"] = false
	e["rule_allowed"] = false
	e["transition_available"] = false
	var actor = e.get("entity", null)
	if not actor is StringName or actor == &"": return
	e["accepted"] = true
	if _state.is_empty() or _state["status"] != "placed":
		e["reason"] = "Лестница не размещена"
		return
	var mode := {}
	EventBus.publish(&"GameModeGetRequested", mode)
	if mode.get("entity", &"") != actor:
		e["reason"] = "Лестницей может воспользоваться только управляемый персонаж"
		return
	var alive := {"entity":actor, "allowed":true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	if not alive.get("allowed", false):
		e["reason"] = "Персонаж погиб"
		return
	var action := {"entity":actor, "found":false}
	EventBus.publish(&"ActionGetRequested", action)
	if action.get("found", false):
		e["reason"] = "Выполняется другое действие"
		return
	var object := {"object":_state["object"], "found":false}
	var body := {"entity":actor, "found":false}
	var room := {"id":_state["room"], "found":false}
	EventBus.publish(&"ObjectGetRequested", object)
	EventBus.publish(&"SpaceBodyGetRequested", body)
	EventBus.publish(&"RoomGetRequested", room)
	if not object.get("found", false) or not body.get("found", false) or not room.get("found", false):
		e["reason"] = "Нет лестницы, комнаты или тела персонажа"
		return
	var a: Vector2i = body["data"]["anchor"]
	var n: int = body["data"]["size"]
	var tile: Vector2i = object["data"]["tile"]
	var bounds := Rect2i(room["data"]["origin_cell"] * 4, room["data"]["size_cells"] * 4)
	var adjacent := ((tile.x == a.x - 1 or tile.x == a.x + n) and tile.y >= a.y and tile.y < a.y + n) or ((tile.y == a.y - 1 or tile.y == a.y + n) and tile.x >= a.x and tile.x < a.x + n)
	if not bounds.encloses(Rect2i(a, Vector2i.ONE * n)) or not adjacent:
		e["reason"] = "Нужно находиться рядом с лестницей"
		return
	var mode_name := str(mode.get("mode", ""))
	if mode_name not in ["combat", "exploration"]:
		e["reason"] = "Неизвестный игровой режим"
		return
	if mode_name == "combat":
		if not (_combat_radius is int or _combat_radius is float) or not is_finite(float(_combat_radius)) or float(_combat_radius) < 0:
			e["reason"] = "Не задан радиус проверки врагов"
			return
		var position := _position(actor, body["data"])
		var center := position + Vector2.ONE * float(n) / 2.0
		var bodies := {}
		EventBus.publish(&"SpaceBodiesGetRequested", bodies)
		var ids: Array = bodies.get("bodies", {}).keys()
		ids.sort_custom(func(x, y): return str(x) < str(y))
		for id in ids:
			if id == actor: continue
			var hostile := {"observer":actor, "target":id}
			EventBus.publish(&"DetectionPairGetRequested", hostile)
			if not hostile.get("hostile", false): continue
			var enemy_alive := {"entity":id, "allowed":true}
			EventBus.publish(&"CombatEntityCanActRequested", enemy_alive)
			if not enemy_alive.get("allowed", false): continue
			var enemy: Dictionary = bodies["bodies"][id]
			var enemy_pos := _position(id, enemy)
			var far := enemy_pos + Vector2.ONE * float(enemy["size"])
			var nearest := Vector2(clampf(center.x, enemy_pos.x, far.x), clampf(center.y, enemy_pos.y, far.y))
			var distance := center.distance_to(nearest)
			if distance <= float(_combat_radius):
				e["reason"] = "В бою враг находится слишком близко"
				e["blocking_enemy"] = id
				e["distance"] = distance
				return
	e["rule_allowed"] = true
	e["reason"] = "Условия начала соблюдены; полная готовность перехода не проверена"

func _position(id: StringName, body: Dictionary) -> Vector2:
	var q := {"entity":id, "found":false}
	EventBus.publish(&"MovementPositionGetRequested", q)
	return q["position"] if q.get("found", false) else Vector2(body["anchor"])

func _map_reset(_e: Dictionary) -> void:
	_state.clear()

func _object_removed(e: Dictionary) -> void:
	if not _state.is_empty() and e.get("object", null) == _state.get("object", null):
		_state["object"] = null
		_state["status"] = "failed"
		EventBus.publish(&"DungeonStairPlacementFailed", {"room":_state["room"], "error":"Лестница удалена"})

func _place() -> void:
	_busy = true
	var room := {"id":_state["room"], "found":false}
	EventBus.publish(&"RoomGetRequested", room)
	if not room.get("found", false):
		_finish_failure("Комната не найдена")
		return
	var data: Dictionary = room["data"]
	var entry: Dictionary = {}
	for ex in data["exits"]:
		if ex.get("id", null) == &"entry" and ex.get("connected", false):
			entry = ex
			break
	if entry.is_empty():
		_finish_failure("Нет связанного входа в тупик")
		return
	var origin: Vector2i = data["origin_cell"] * 4
	var size: Vector2i = data["size_cells"] * 4
	var bounds := {"origin":origin, "size":size}
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match str(entry["dirOut"]):
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
		_:
			_finish_failure("Недопустимое направление входа")
			return
	if not _fits(seed, bounds):
		_finish_failure("Телу 4×4 недоступен вход в тупик")
		return
	var parents := {seed:null}
	var queue: Array = [seed]
	var index := 0
	var obstacle_id := _free_id(int(_state["floor"]))
	if obstacle_id == &"":
		_finish_failure("Не удалось выбрать ID лестницы")
		return
	while index < queue.size():
		var anchor: Vector2i = queue[index]
		index += 1
		for tile in _adjacent_tiles(anchor):
			if not _stair_tile_usable(anchor, tile, parents, Rect2i(origin, size)): continue
			var create := {"entity":obstacle_id, "type":"stairs_down", "room":_state["room"], "tile":tile, "accepted":false}
			EventBus.publish(&"ObjectCreateRequested", create)
			if create["accepted"]:
				_state["status"] = "placed"
				_state["object"] = obstacle_id
				_busy = false
				EventBus.publish(&"DungeonStairPlaced", {"floor":_state["floor"], "room":_state["room"], "object":obstacle_id, "tile":tile})
				return
			if create.has("incomplete"):
				_finish_failure("Создание лестницы не удалось безопасно откатить")
				return
		for delta in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = anchor + delta
			if not parents.has(next) and _fits(next, bounds):
				parents[next] = anchor
				queue.append(next)
	_finish_failure("Нет доступного места для лестницы")

# Предварительная проверка на пробной, ещё не опубликованной комнате.
# Не создаёт объект и не объявляет комнату выбранной.
func _trial_requested(e: Dictionary) -> void:
	e["accepted"] = false
	if _busy or not _state.is_empty() or not e.get("room", null) is StringName or not e.get("floor", null) is int or e["floor"] < 1 or e["floor"] > 3: return
	_busy = true
	e["accepted"] = _probe_room(e["room"], e["floor"])
	_busy = false

func _probe_room(room_id: StringName, floor_no: int) -> bool:
	var room := {"id":room_id, "found":false}
	EventBus.publish(&"RoomGetRequested", room)
	if not room.get("found", false) or room["data"].get("type", "") != "deadend" or _free_id(floor_no) == &"": return false
	var data: Dictionary = room["data"]
	var entry: Dictionary = {}
	for ex in data["exits"]:
		if ex.get("id", null) == &"entry":
			entry = ex
			break
	if entry.is_empty(): return false
	var origin: Vector2i = data["origin_cell"] * 4
	var size: Vector2i = data["size_cells"] * 4
	var bounds := {"origin":origin, "size":size}
	var seed := Vector2i(int(entry["x"]), int(entry["y"]))
	match str(entry["dirOut"]):
		"west": seed.x += 1
		"east": seed.x -= 4
		"north": seed.y += 1
		"south": seed.y -= 4
		_: return false
	if not _fits(seed, bounds): return false
	var parents := {seed:null}
	var queue: Array = [seed]
	var index := 0
	while index < queue.size():
		var anchor: Vector2i = queue[index]
		index += 1
		for tile in _adjacent_tiles(anchor):
			if _stair_tile_usable(anchor, tile, parents, Rect2i(origin, size)): return true
		for delta in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = anchor + delta
			if not parents.has(next) and _fits(next, bounds):
				parents[next] = anchor
				queue.append(next)
	return false

func _stair_tile_usable(anchor: Vector2i, tile: Vector2i, parents: Dictionary, bounds: Rect2i) -> bool:
	if not bounds.has_point(tile) or not _path_clear_of_tile(anchor, tile, parents): return false
	var q := {"tile":tile}
	EventBus.publish(&"SpaceTileGetRequested", q)
	if not q.get("in_bounds", false) or q.get("kind", 0) != 1 or q.get("passage", false) or q.get("occupant", null) != null or q.get("obstacle", null) != null: return false
	var ground := {"tile":tile}
	EventBus.publish(&"LootGetRequested", ground)
	return ground.get("items", {}).is_empty()

func _free_id(floor_no: int) -> StringName:
	for i in range(10000):
		var id := StringName("stairs_%d_%d" % [floor_no, i])
		var q := {"entity":id, "found":false}
		EventBus.publish(&"EntityGetRequested", q)
		if not q.get("found", false): return id
	return &""

func _fits(anchor: Vector2i, bounds: Dictionary) -> bool:
	var q := {"anchor":anchor, "size":4, "room":bounds, "ignore_entity":&""}
	EventBus.publish(&"SpaceBodyFitsRequested", q)
	return q.get("fits", false)

func _adjacent_tiles(a: Vector2i) -> Array:
	var result: Array = []
	for i in range(4):
		result.append(a + Vector2i(i, -1))
		result.append(a + Vector2i(4, i))
		result.append(a + Vector2i(i, 4))
		result.append(a + Vector2i(-1, i))
	return result

func _path_clear_of_tile(anchor: Vector2i, tile: Vector2i, parents: Dictionary) -> bool:
	var point: Variant = anchor
	while point != null:
		if Rect2i(point, Vector2i(4,4)).has_point(tile): return false
		point = parents[point]
	return true

func _finish_failure(error: String) -> void:
	_state["status"] = "failed"
	_state["object"] = null
	_busy = false
	EventBus.publish(&"DungeonStairPlacementFailed", {"floor":_state["floor"], "room":_state["room"], "error":error})

func _collect(e: Dictionary) -> void:
	if _busy:
		e["errors"].append("Нельзя сохранять во время размещения лестницы")
		return
	e["sections"]["dungeon_stairs"] = _state.duplicate(true)
func _apply(e: Dictionary) -> void:
	_state = e["sections"]["dungeon_stairs"].duplicate(true)
	_busy = false
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary or not sections.get("dungeon_stairs", null) is Dictionary or not sections.get("dungeon_tracking", null) is Dictionary or not sections.get("objects", {}).get("objects", null) is Dictionary: return
	var state: Dictionary = sections["dungeon_stairs"]
	var track: Dictionary = sections["dungeon_tracking"]
	if state.is_empty():
		if track.get("stair_candidate", null) != null: return
		e["valid"] = true
		return
	if not state.get("floor", null) is int or state["floor"] < 1 or state["floor"] > 3 or state["floor"] != track.get("floor", null) or not state.get("room", null) is StringName or state["room"] != track.get("stair_candidate", null) or state.get("status", "") not in ["failed", "placed"] or not state.has("object"): return
	if state["status"] == "failed":
		if state["object"] != null: return
	else:
		var id = state["object"]
		var objects: Dictionary = sections["objects"]["objects"]
		if not id is StringName or not objects.has(id) or not objects[id] is Dictionary or objects[id].get("type", "") != "stairs_down" or objects[id].get("room", null) != state["room"]: return
	e["valid"] = true
