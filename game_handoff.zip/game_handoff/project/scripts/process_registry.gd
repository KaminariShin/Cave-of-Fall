extends Node
## Процессы обновляются только по сигналу игрового времени TimeDriver.

signal process_started(process_id: StringName)
signal process_finished(process_id: StringName)
signal process_interrupted(process_id: StringName, reason: StringName)

# Объекты процессов хранятся как словари и намеренно не отдаются наружу.
var _processes: Dictionary = {}
var _order: Array[StringName] = []
var _starting: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"ProcessStartRequested", _on_start_requested)
	EventBus.subscribe(&"ProcessGetRequested", _on_get_requested)
	EventBus.subscribe(&"ProcessInterruptRequested", _on_interrupt_requested)
	EventBus.subscribe(&"TimeProcessesTick", _on_tick)
	EventBus.subscribe(&"EntityRemoved", _on_entity_removed_event)

## id уникален среди активных процессов. Пустой entity_id означает отсутствие
## привязки. on_tick(id, dt), on_complete(id), on_interrupt(id, reason).
## Колбэки могут добавлять и удалять процессы, включая текущий.
func register_process(process_id: StringName, duration: float, entity_id: StringName = &"", independent: bool = false, on_tick: Callable = Callable(), on_complete: Callable = Callable(), on_interrupt: Callable = Callable()) -> bool:
	if process_id == &"" or _processes.has(process_id) or _starting.has(process_id):
		return false
	var steps := _duration_to_steps(duration)
	if steps <= 0:
		return false
	_starting[process_id] = true
	var gate := {"id":process_id, "entity":entity_id, "independent":independent, "allowed":true}
	EventBus.publish(&"ProcessStartAllowedRequested", gate)
	_starting.erase(process_id)
	if not gate.get("allowed", false) or _processes.has(process_id): return false
	_processes[process_id] = {
		"entity_id": entity_id,
		"independent": independent,
		"duration_steps": steps,
		"elapsed_steps": 0,
		"on_tick": on_tick,
		"on_complete": on_complete,
		"on_interrupt": on_interrupt,
	}
	_order.append(process_id)
	process_started.emit(process_id)
	EventBus.publish(&"ProcessStarted", {"process": process_id})
	return true

## Завершение по собственному условию процесса: столкновение, рассеивание и т.п.
func interrupt_process(process_id: StringName, reason: StringName = &"condition") -> bool:
	if not _processes.has(process_id):
		return false
	var process: Dictionary = _remove_process(process_id)
	var callback: Callable = process["on_interrupt"]
	if callback.is_valid():
		callback.call(process_id, reason)
	process_interrupted.emit(process_id, reason)
	EventBus.publish(&"ProcessInterrupted", {"process": process_id, "reason": reason})
	return true

## Явное уведомление от будущего Entity Registry при удалении сущности.
## Независимые процессы продолжают работать, остальные прерываются.
func entity_removed(entity_id: StringName) -> void:
	if entity_id == &"":
		return
	var snapshot := _order.duplicate()
	for process_id in snapshot:
		if not _processes.has(process_id):
			continue
		var process: Dictionary = _processes[process_id]
		if process["entity_id"] == entity_id and not process["independent"]:
			interrupt_process(process_id, &"entity_removed")

# Внутренняя проверка перед очисткой существ: независимые процессы не
# отменяются обычным EntityRemoved и требуют отдельного решения владельца.
func independent_processes_for_entities(entities: Array) -> Array:
	var result: Array = []
	for id in _order:
		var p: Dictionary = _processes[id]
		if p["independent"] and entities.has(p["entity_id"]): result.append(id)
	return result

func has_process(process_id: StringName) -> bool:
	return _processes.has(process_id)

## Возвращает снимок без колбэков, чтобы внешние системы не меняли реестр.
func get_process_info(process_id: StringName) -> Dictionary:
	if not _processes.has(process_id):
		return {}
	var process: Dictionary = _processes[process_id]
	return {
		"id": process_id,
		"entity_id": process["entity_id"],
		"independent": process["independent"],
		"duration": process["duration_steps"] * 0.01,
		"elapsed": process["elapsed_steps"] * 0.01,
	}

func _on_tick(event: Dictionary) -> void:
	var dt: float = event["dt"]
	# Снимок содержит не только id, но и ссылку на экземпляр: если колбэк
	# удалит процесс и создаст новый с тем же id, новый ждёт следующего шага.
	var snapshot: Array = []
	for process_id in _order:
		snapshot.append([process_id, _processes[process_id]])
	for entry in snapshot:
		var process_id: StringName = entry[0]
		var process: Dictionary = entry[1]
		if not _is_same_process(process_id, process):
			continue
		var room_gate := {"process": process_id, "allowed": true}
		EventBus.publish(&"SpawnProcessTickAllowedRequested", room_gate)
		if not room_gate["allowed"]: continue
		if not process["independent"] and process["entity_id"] != &"":
			var allowed := {"entity": process["entity_id"], "allowed": true}
			EventBus.publish(&"AIEntityTickAllowedRequested", allowed)
			if not allowed["allowed"]:
				continue
		process["elapsed_steps"] += 1
		var callback: Callable = process["on_tick"]
		if callback.is_valid():
			callback.call(process_id, dt)
		if not _is_same_process(process_id, process):
			continue
		# Событие без Callable можно безопасно восстановить из сохранения.
		EventBus.publish(&"ProcessStepped", {"process": process_id, "dt": dt, "elapsed": process["elapsed_steps"] * 0.01})
		if not _is_same_process(process_id, process):
			continue
		if process["elapsed_steps"] >= process["duration_steps"]:
			_remove_process(process_id)
			var complete: Callable = process["on_complete"]
			if complete.is_valid():
				complete.call(process_id)
			process_finished.emit(process_id)
			EventBus.publish(&"ProcessCompleted", {"process": process_id})

func _is_same_process(process_id: StringName, process: Dictionary) -> bool:
	return _processes.has(process_id) and is_same(_processes[process_id], process)

func _remove_process(process_id: StringName) -> Dictionary:
	var process: Dictionary = _processes[process_id]
	_processes.erase(process_id)
	_order.erase(process_id)
	return process

func _duration_to_steps(duration: float) -> int:
	if not is_finite(duration) or duration <= 0.0:
		return 0
	var steps_float: float = duration / 0.01
	if steps_float > 1000000000.0:
		return 0
	var steps := int(round(steps_float))
	if steps < 1 or absf(steps * 0.01 - duration) > 0.000001:
		return 0
	return steps

func _on_entity_removed_event(event: Dictionary) -> void:
	entity_removed(event.get("entity", &""))

func _snapshot_collect(event: Dictionary) -> void:
	if not _starting.is_empty():
		event["errors"].append("Нельзя сохранять во время начала процесса")
		return
	var saved: Array = []
	for process_id in _order:
		var process: Dictionary = _processes[process_id]
		for key in ["on_tick", "on_complete", "on_interrupt"]:
			var callback: Callable = process[key]
			if callback.is_valid():
				event["errors"].append("Процесс %s содержит Callable; его нельзя безопасно сохранить" % process_id)
				return
		saved.append({"id": process_id, "entity_id": process["entity_id"], "independent": process["independent"], "duration_steps": process["duration_steps"], "elapsed_steps": process["elapsed_steps"]})
	event["sections"]["processes"] = saved

func _snapshot_apply(event: Dictionary) -> void:
	_starting.clear()
	_processes.clear()
	_order.clear()
	for item in event["sections"]["processes"]:
		var process_id: StringName = item["id"]
		_processes[process_id] = {"entity_id": item["entity_id"], "independent": item["independent"], "duration_steps": item["duration_steps"], "elapsed_steps": item["elapsed_steps"], "on_tick": Callable(), "on_complete": Callable(), "on_interrupt": Callable()}
		_order.append(process_id)

func _on_start_requested(request: Dictionary) -> void:
	request["accepted"] = register_process(request.get("id", &""), request.get("duration", 0.0), request.get("entity", &""), request.get("independent", false))

func _on_interrupt_requested(request: Dictionary) -> void:
	request["accepted"] = interrupt_process(request.get("id", &""), request.get("reason", &"condition"))

func _on_get_requested(request: Dictionary) -> void:
	var process_id: StringName = request.get("id", &"")
	request["found"] = has_process(process_id)
	request["data"] = get_process_info(process_id)
