extends Node
## Инициализация уровня; остальное дерево создаёт RoomService по мере входа.
var _active := false
var _level_id: StringName = &""
var _seed := 0
var _size_cells := Vector2i.ZERO
var _scale := 4
var _default_size := Vector2i(96,96)
var _default_budget := 0
var _busy := false
func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var params: Dictionary = rules["ruleset"].get("parameters", {})
		_scale = int(params.get("space", {}).get("tiles_per_cell", 4))
		var cave: Dictionary = params.get("cave_generation", {})
		var size = cave.get("default_size_cells", [96,96])
		if size is Array and size.size() == 2: _default_size = Vector2i(int(size[0]), int(size[1]))
		_default_budget = int(cave.get("default_deadend_budget", 0))
	EventBus.subscribe(&"LevelGenerationRequested", _generate)
	EventBus.subscribe(&"LevelMapGetRequested", _get_level)
	EventBus.subscribe(&"SpaceMapConfigured", _map_changed)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
func _generate(event: Dictionary) -> void:
	event["accepted"] = false
	var id := StringName(str(event.get("level_id", "")))
	var seed = event.get("seed", int(str(id).hash()))
	var size = event.get("size_cells", _default_size)
	var budget = event.get("deadend_budget", _default_budget)
	var origin = event.get("start_origin", null)
	if _busy or id == &"" or not seed is int or not size is Vector2i or size.x < 24 or size.y < 24 or size.x > 512 or size.y > 512 or not budget is int or budget < 0:
		return
	if origin == null: origin = Vector2i(int((size.x - 11) / 2), int((size.y - 11) / 2))
	if not origin is Vector2i or origin.x < 0 or origin.y < 0 or origin.x + 12 >= size.x or origin.y + 12 >= size.y:
		return
	_busy = true
	var map := {"size": size * _scale, "accepted": false}
	EventBus.publish(&"SpaceMapConfigureRequested", map)
	if not map["accepted"]:
		_busy = false
		return
	var cave := {"enabled": true, "seed": seed, "accepted": false}
	EventBus.publish(&"RoomCaveConfigureRequested", cave)
	EventBus.publish(&"RngSeedRequested", {"seed": seed})
	EventBus.publish(&"RoomGenerationConfigureRequested", {"deadend_budget": budget})
	var start := {"id": &"start", "type": "start", "origin_cell": origin, "size_cells": Vector2i(11,11), "accepted": false}
	EventBus.publish(&"RoomCreateRequested", start)
	var exit := {"room": &"start", "id": &"east", "dir": "east", "offset_cells": 5, "accepted": false}
	if start["accepted"]: EventBus.publish(&"RoomExitAddRequested", exit)
	if not cave["accepted"] or not start["accepted"] or not exit["accepted"]:
		_busy = false
		event["error"] = "Начальная комната не создана; карта осталась частично настроенной"
		return
	_active = true
	_level_id = id
	_seed = seed
	_size_cells = size
	_busy = false
	var info := {}
	_get_level(info)
	event["accepted"] = true
	event["map_data"] = info["map_data"]
	EventBus.publish(&"LevelGenerated", {"level_id": id, "map_data": info["map_data"].duplicate(true)})
func _get_level(event: Dictionary) -> void:
	event["found"] = _active
	if not _active: return
	var rooms := {}
	EventBus.publish(&"RoomAllGetRequested", rooms)
	var result: Dictionary = rooms["rooms"].duplicate(true)
	for id in result:
		var room: Dictionary = result[id]
		room["rect"] = {"position": room["origin_cell"], "size": room["size_cells"]}
		room["floorList"] = room["floor_list"].duplicate()
		for exit in room["exits"]:
			exit["tile_x"] = exit["x"]
			exit["tile_y"] = exit["y"]
			exit["x"] = floori(float(exit["tile_x"]) / _scale)
			exit["y"] = floori(float(exit["tile_y"]) / _scale)
	event["map_data"] = {"level_id": _level_id, "seed": _seed, "size_cells": _size_cells, "tiles_per_cell": _scale, "start_room": &"start", "rooms": result}
func _map_changed(_event: Dictionary) -> void:
	_active = false
	_level_id = &""
	_seed = 0
	_size_cells = Vector2i.ZERO
func _collect(event: Dictionary) -> void:
	if _busy:
		event["errors"].append("Нельзя сохранять во время генерации уровня")
		return
	event["sections"]["level"] = {"active": _active, "level_id": _level_id, "seed": _seed, "size_cells": _size_cells}
func _apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["level"]
	_active = data["active"]
	_level_id = data["level_id"]
	_seed = data["seed"]
	_size_cells = data["size_cells"]
	_busy = false
