extends Node
## Однопроходная равновероятная выборка по консервативному поиску кандидатов.
## Задача временная и не сериализуется; сам сундук не создаётся.
var _job: Dictionary = {}
var _busy := false
var _generation := 0

func _ready() -> void:
	EventBus.subscribe(&"DungeonChestRandomPositionBeginRequested", _begin)
	EventBus.subscribe(&"DungeonChestRandomPositionStepRequested", _step)
	EventBus.subscribe(&"DungeonChestRandomPositionCancelRequested", _cancel)
	EventBus.subscribe(&"SnapshotRestored", _reset)
	EventBus.subscribe(&"SpaceMapConfigured", _reset)

func _reset(_e: Dictionary) -> void:
	_generation += 1
	_job.clear()

func _snapshot() -> Dictionary:
	var snapshot: Dictionary = SaveService.collect_world_transition_snapshot()
	if not snapshot.get("valid", false): return {"valid":false, "error":snapshot.get("error", "Снимок недоступен")}
	var sections: Dictionary = snapshot["payload"]["sections"]
	return {"valid":true, "signature":{"space":sections["space"].duplicate(true), "rooms":sections["rooms"].duplicate(true), "ground":sections.get("loot", {}).get("ground", {}).duplicate(true)}}

func _begin(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["error", "status", "cursor", "candidates_seen", "found", "tile", "interaction_anchor", "connected_exits_checked", "open_exits_checked"]: e.erase(key)
	var room = e.get("room", null)
	var random_order = e.get("random_order",false)
	if not random_order is bool: e["error"] = "Некорректный режим поиска"; return
	if _busy or not _job.is_empty() or not room is StringName or room == &"":
		e["error"] = "Поиск уже выполняется или не указана комната"; return
	_busy = true
	var generation := _generation
	var snap := _snapshot()
	if generation != _generation or not snap.get("valid", false):
		_busy = false
		e["error"] = str(snap.get("error", "Мир изменился")); return
	var rooms: Dictionary = snap["signature"]["rooms"]["rooms"]
	var data = rooms.get(room, null)
	if not data is Dictionary or not data.get("origin_cell", null) is Vector2i or not data.get("size_cells", null) is Vector2i:
		_busy = false
		e["error"] = "Комната не найдена"; return
	var size: Vector2i = data["size_cells"] * 4
	if size.x < 1 or size.y < 1 or size.x * size.y > 16384:
		_busy = false
		e["error"] = "Размер комнаты не поддерживается"; return
	_job = {"room":room, "origin":data["origin_cell"] * 4, "size":size, "cursor":0, "count":0, "selected":{}, "signature":snap["signature"], "random_order":random_order, "swaps":{}}
	_busy = false
	e["accepted"] = true
	e["status"] = "searching"

func _step(e: Dictionary) -> void:
	e["accepted"] = false
	e["world_changed"] = false
	for key in ["error", "status", "cursor", "candidates_seen", "found", "tile", "interaction_anchor", "connected_exits_checked", "open_exits_checked"]: e.erase(key)
	if _busy or _job.is_empty(): e["error"] = "Нет активного поиска"; return
	_busy = true
	var generation := _generation
	var snap := _snapshot()
	if generation != _generation or not snap.get("valid", false) or snap.get("signature", {}) != _job.get("signature", null):
		e["world_changed"] = generation == _generation and snap.get("valid", false) and snap.get("signature", {}) != _job.get("signature", null)
		return _abort(e, "Снимок недоступен или мир изменился; начните поиск заново")
	if _job.get("random_order",false):
		_random_order_step(e,generation)
		return
	var room: StringName = _job["room"]
	var cursor: int = _job["cursor"]
	var size: Vector2i = _job["size"]
	var total: int = size.x * size.y
	var search := {"room":room, "cursor":cursor, "accepted":false}
	EventBus.publish(&"DungeonChestPositionSearchRequested", search)
	var next = search.get("next_cursor", null)
	if generation != _generation or not search.get("accepted", false) or not next is int or next <= cursor or next > total or not search.get("complete", null) is bool or search["complete"] != (next == total) or not search.get("found", null) is bool:
		return _abort(e, "Ошибка страницы поиска")
	if search["found"]:
		var expected: Vector2i = _job["origin"] + Vector2i((next - 1) % size.x, int((next - 1) / size.x))
		if search.get("tile", null) != expected or not search.get("interaction_anchor", null) is Vector2i or not search.get("connected_exits_checked", null) is int or not search.get("open_exits_checked", null) is int or search["open_exits_checked"] < search["connected_exits_checked"]:
			return _abort(e, "Некорректный кандидат")
		_job["count"] += 1
		var take: bool = _job["count"] == 1
		if not take:
			var rng := {"min":1, "max":_job["count"], "accepted":false}
			EventBus.publish(&"RngIntRequested", rng)
			if generation != _generation or not rng.get("accepted", false) or not rng.get("value", null) is int or rng["value"] < 1 or rng["value"] > _job["count"]:
				return _abort(e, "Ошибка ГСЧ при выборе позиции")
			take = rng["value"] == 1
		if take:
			_job["selected"] = {"tile":search["tile"], "interaction_anchor":search["interaction_anchor"], "connected_exits_checked":search["connected_exits_checked"], "open_exits_checked":search["open_exits_checked"]}
	# События поиска/ГСЧ синхронны, но сторонние подписчики могут менять мир.
	var after := _snapshot()
	if generation != _generation or not after.get("valid", false) or after.get("signature", {}) != _job.get("signature", null):
		e["world_changed"] = generation == _generation and after.get("valid", false) and after.get("signature", {}) != _job.get("signature", null)
		return _abort(e, "Мир изменился во время поиска; начните заново")
	_job["cursor"] = next
	e["accepted"] = true
	e["cursor"] = next
	e["candidates_seen"] = _job["count"]
	if search["complete"]:
		e["status"] = "complete"
		e["found"] = _job["count"] > 0
		if e["found"]: e.merge(_job["selected"].duplicate(true), true)
		_job.clear()
	else: e["status"] = "searching"
	_busy = false

# Равновероятная случайная перестановка индексов без возврата, строится
# лениво (разреженный Fisher–Yates). Первый допустимый тайл равновероятен
# среди всех допустимых при неизменном снимке. Тяжёлый preflight вызываем
# только для клетки у стены и завершаем поиск сразу при успехе.
func _random_order_step(e: Dictionary, generation: int) -> void:
	var size: Vector2i = _job["size"]
	var total: int = size.x * size.y
	var selected: Dictionary = {}
	var checked := 0
	for _i in range(64):
		var remaining: int = total - int(_job["cursor"])
		if remaining <= 0: break
		var rng := {"min":0,"max":remaining-1,"accepted":false}
		EventBus.publish(&"RngIntRequested",rng)
		if generation != _generation or not rng.get("accepted",false) or not rng.get("value",null) is int or rng["value"] < 0 or rng["value"] >= remaining:
			return _abort(e,"Ошибка ГСЧ при случайном поиске")
		var swaps: Dictionary = _job["swaps"]
		var pick: int = rng["value"]
		var index: int = swaps.get(pick,pick)
		var last: int = remaining-1
		var tail: int = swaps.get(last,last)
		swaps.erase(last)
		if pick != last: swaps[pick] = tail
		_job["cursor"] += 1
		var tile: Vector2i = _job["origin"] + Vector2i(index % size.x, int(index / size.x))
		var near_wall: bool = DungeonChestSearchService._wall_floor(tile)
		if generation != _generation: return _abort(e,"Мир изменился во время поиска")
		if not near_wall: continue
		checked += 1
		var candidate := {"room":_job["room"],"tile":tile,"accepted":false}
		EventBus.publish(&"DungeonChestPositionPreflightRequested",candidate)
		if generation != _generation: return _abort(e,"Мир изменился во время поиска")
		if candidate.get("accepted",false):
			if candidate.get("tile",null) != tile or not candidate.get("interaction_anchor",null) is Vector2i or not candidate.get("connected_exits_checked",null) is int or not candidate.get("open_exits_checked",null) is int or candidate["connected_exits_checked"] < 1 or candidate["open_exits_checked"] < candidate["connected_exits_checked"]:
				return _abort(e,"Некорректный кандидат")
			selected = candidate
			break
		# Не более четырёх дорогих проверок за один кадр.
		if checked >= 4: break
	var after := _snapshot()
	if generation != _generation or not after.get("valid",false) or after.get("signature",{}) != _job.get("signature",null):
		e["world_changed"] = generation == _generation and after.get("valid",false) and after.get("signature",{}) != _job.get("signature",null)
		return _abort(e,"Мир изменился во время поиска; начните заново")
	e["accepted"] = true
	e["cursor"] = _job["cursor"]
	e["candidates_seen"] = int(_job.get("count",0)) + checked
	_job["count"] = e["candidates_seen"]
	if not selected.is_empty() or int(_job["cursor"]) == total:
		e["status"] = "complete"; e["found"] = not selected.is_empty()
		if e["found"]:
			for key in ["tile","interaction_anchor","connected_exits_checked","open_exits_checked"]: e[key] = selected[key]
		_job.clear()
	else: e["status"] = "searching"
	_busy = false

func _abort(e: Dictionary, message: String) -> void:
	_job.clear()
	_generation += 1
	_busy = false
	e["accepted"] = false
	e["error"] = message

func _cancel(e: Dictionary) -> void:
	e["accepted"] = not _busy and not _job.is_empty()
	if e["accepted"]:
		_generation += 1
		_job.clear()
