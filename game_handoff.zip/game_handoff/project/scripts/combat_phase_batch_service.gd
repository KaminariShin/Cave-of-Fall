extends Node
## Сбор доверенных подготовленных попаданий в один пакет текущего шага.
const MAX_HITS := 10000
const MAX_TILES := 300000
const MAX_NUMBER := 1000000000
var _collecting := false
var _finishing := false
var _failed := ""
var _hits: Array = []
var _blocks: Array = []
var _hp := {}
var _pairs := {}
var _blocked := {}
var _tile_count := 0
func _ready() -> void:
	EventBus.subscribe(&"CombatPhaseHitSubmitRequested",_submit_hit)
	EventBus.subscribe(&"CombatPhaseBlockSubmitRequested",_submit_block)
func begin() -> void:
	if not TimeDriver._combat_phase or _collecting or _finishing: return
	_collecting = true
	_failed = ""
	_hits.clear(); _blocks.clear(); _hp.clear(); _pairs.clear(); _blocked.clear()
	_tile_count = 0
func _reject(e: Dictionary,reason: String) -> void:
	e["error"] = reason
	if _collecting and _failed.is_empty(): _failed = reason
# Закрытый отказ всего текущего сбора при неполном оружейном пакете.
func reject_weapon_collection(reason: String) -> bool:
	if not WeaponStrikePhaseSubmitService.authorizes_collection_abort() or not _collecting or _finishing or not TimeDriver._combat_phase: return false
	_reject({},reason)
	return true
# Только снаряды, зарегистрированные владельцем контактов на этом шаге.
func reject_projectile_collection(reason: String) -> bool:
	if not ProjectileService._phase_submitting or not _collecting or _finishing or not TimeDriver._combat_phase: return false
	_reject({},reason)
	return true

func submit_projectile_hit(e: Dictionary) -> void:
	if not ProjectileService._phase_submitting or not ProjectileService.authorizes_phase_hit(e):
		e["accepted"] = false; e["error"] = "Недоверенный контакт снаряда"; return
	_submit_hit(e)
	if e.get("accepted",false): _hits.back()["independent_projectile"] = true

func _submit_hit(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("error")
	if not _collecting or _finishing or not TimeDriver._combat_phase: e["error"] = "Сбор попаданий закрыт"; return
	if not _failed.is_empty(): e["error"] = "Пакет уже отклонён"; return
	var source = e.get("source",null)
	var target = e.get("target",null)
	var p = e.get("damage",null)
	var m = e.get("magical_damage",0)
	var hp = e.get("hp_before",null)
	if _hits.size() >= MAX_HITS or not source is StringName or source == &"" or not target is StringName or target == &"" or not p is int or p < 0 or p > MAX_NUMBER or not m is int or m < 0 or m > MAX_NUMBER or p + m > MAX_NUMBER or not hp is int or hp < 1 or hp > MAX_NUMBER:
		_reject(e,"Некорректное подготовленное попадание"); return
	var hit_id = e.get("hit_id",source)
	if not hit_id is StringName or hit_id == &"": _reject(e,"Некорректный ID попадания"); return
	if (_hp.has(target) and _hp[target] != hp) or (_pairs.has(target) and _pairs[target].has(hit_id)):
		_reject(e,"Несовпадение HP или повторное попадание по цели"); return
	var row := {"source":source,"target":target,"damage":p,"magical_damage":m}
	if e.has("hit_id"): row["hit_id"] = hit_id
	if e.has("attack_tiles"):
		var tiles = e["attack_tiles"]
		if not tiles is Array or _tile_count + tiles.size() > MAX_TILES: _reject(e,"Некорректный или слишком большой список тайлов"); return
		for tile in tiles:
			if not tile is Vector2i: _reject(e,"Некорректный тайл атаки"); return
		_tile_count += tiles.size()
		row["attack_tiles"] = tiles.duplicate()
	if not _pairs.has(target): _pairs[target] = {}
	_pairs[target][hit_id] = true
	_hp[target] = hp
	_hits.append(row)
	e["accepted"] = true
func _submit_block(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("error")
	if not _collecting or _finishing or not TimeDriver._combat_phase: e["error"] = "Сбор блоков закрыт"; return
	if not _failed.is_empty(): e["error"] = "Пакет уже отклонён"; return
	var target = e.get("target",null)
	var direction = e.get("direction",null)
	var stamina = e.get("expected_stamina",null)
	if _blocks.size() >= MAX_HITS or not target is StringName or target == &"" or _blocked.has(target) or not ShieldBlockZoneService.valid_direction(direction) or not stamina is int or stamina < 0 or stamina > MAX_NUMBER:
		_reject(e,"Некорректный или повторный блок"); return
	_blocked[target] = true
	_blocks.append({"target":target,"direction":direction,"expected_stamina":stamina})
	e["accepted"] = true
func finish() -> bool:
	if not _collecting or _finishing or not TimeDriver._combat_phase: return false
	_collecting = false
	_finishing = true
	var count := _hits.size()
	var block_count := _blocks.size()
	var result := {"accepted":false}
	if not _failed.is_empty(): result["error"] = _failed
	elif count == 0 and block_count > 0: result["error"] = "Блок без попаданий"
	elif count > 0:
		var batch := {"hp_by_target":_hp.duplicate(true),"hits":_hits.duplicate(true),"blocks":_blocks.duplicate(true),"phase_commit":true,"apply_stagger":true}
		SimultaneousDamageApplyService._apply(batch)
		result["accepted"] = batch.get("accepted",false)
		if result["accepted"]: result["data"] = batch["data"].duplicate(true)
		else: result["error"] = batch.get("error","Не удалось применить пакет")
	if count > 0 or block_count > 0 or not _failed.is_empty():
		result["hit_count"] = count
		result["block_count"] = block_count
		EventBus.publish(&"CombatPhaseBatchResolved",result)
	_hits.clear(); _blocks.clear(); _hp.clear(); _pairs.clear(); _blocked.clear()
	var committed: bool = _failed.is_empty() and ((count == 0 and block_count == 0) or result.get("accepted",false))
	_failed = ""
	_finishing = false
	return committed
