extends Node
## Внутренний технический перенос из очищаемого мира в новый start.
## Не проверяет лестницу и не является игровым действием спуска.
var _busy := false

# Все параметры генерации задаются внутренним вызывающим кодом явно.
func rebuild_next_floor(actor: StringName, level_id: StringName, seed: int, size_cells: Vector2i, deadend_budget: int) -> Dictionary:
	if _busy or actor == &"" or level_id == &"" or size_cells.x < 24 or size_cells.y < 24 or size_cells.x > 512 or size_cells.y > 512 or deadend_budget < 0:
		return {"committed":false, "error":"Некорректные параметры или операция уже выполняется"}
	_busy = true
	var work := {"error":"", "steps":{}}
	var transaction: Dictionary = SaveService.run_world_transition_transaction(func(): return _execute(actor, level_id, seed, size_cells, deadend_budget, work))
	_busy = false
	transaction["steps"] = work["steps"].duplicate(true)
	if transaction.get("committed", false):
		transaction["floor"] = work["floor"]
		transaction["anchor"] = work["anchor"]
	if not work["error"].is_empty(): transaction["error"] = work["error"]
	return transaction

func _execute(actor: StringName, level_id: StringName, seed: int, size_cells: Vector2i, budget: int, work: Dictionary) -> bool:
	var initial: Dictionary = SaveService._collect_transition_snapshot()
	if not initial.get("valid", false): return _fail(work, "Исходный снимок недоступен")
	var before: Dictionary = initial["payload"]["sections"]
	var manifest_result: Dictionary = WorldTransitionManifest.build_manifest(before, actor)
	if not manifest_result.get("valid", false): return _fail(work, "Персонаж не управляется или погиб")
	var manifest: Dictionary = manifest_result["manifest"]
	if manifest["player_body"] == null or before["actions"]["active"].has(actor): return _fail(work, "У персонажа нет тела или выполняется действие")
	var stats: Dictionary = before["run_statistics"]
	var tracking: Dictionary = before["dungeon_tracking"]
	if stats.is_empty() or stats.get("finished", true) or stats.get("entity", &"") != actor or tracking.is_empty() or tracking.get("floor", 0) != stats.get("floor", -1) or tracking.get("root", &"") != stats.get("root", null) or not before["level"].get("active", false): return _fail(work, "Отслеживание этажа или статистика не готовы")
	var floor_no: int = stats["floor"] + 1
	if floor_no > 4 or (floor_no < 4 and budget < 1) or level_id == before["level"]["level_id"]: return _fail(work, "Недопустимый следующий этаж, бюджет или ID уровня")
	if not FloorTransitionCleanup.clean_known_floor_in_transaction(actor, work): return false
	var cleaned_snapshot: Dictionary = SaveService._collect_transition_snapshot()
	if not cleaned_snapshot.get("valid", false): return _fail(work, "Снимок после очистки недоступен")
	var cleaned: Dictionary = cleaned_snapshot["payload"]["sections"]
	var body: Dictionary = manifest["player_body"]
	var detach := {"entity":actor, "accepted":false}
	EventBus.publish(&"SpaceBodyRemoveRequested", detach)
	if not detach.get("accepted", false) or not SaveService.world_transition_operation_active(): return _fail(work, "Не удалось убрать тело со старой карты")
	var generated := {"level_id":level_id, "seed":seed, "size_cells":size_cells, "deadend_budget":budget, "accepted":false}
	EventBus.publish(&"LevelGenerationRequested", generated)
	if not generated.get("accepted", false) or not SaveService.world_transition_operation_active(): return _fail(work, "Не удалось создать новый уровень")
	var track := {"floor":floor_no, "start_room":&"start", "accepted":false}
	EventBus.publish(&"DungeonFloorTrackingBeginRequested", track)
	if not track.get("accepted", false): return _fail(work, "Не удалось включить отслеживание нового этажа")
	var advance := {"floor":floor_no, "start_room":&"start", "accepted":false}
	EventBus.publish(&"RunStatisticsFloorBeginRequested", advance)
	if not advance.get("accepted", false): return _fail(work, "Не удалось обновить статистику этажа")
	var room := {"id":&"start", "found":false}
	EventBus.publish(&"RoomGetRequested", room)
	if not room.get("found", false): return _fail(work, "Стартовая комната отсутствует")
	var scale: int = generated["map_data"]["tiles_per_cell"]
	var origin: Vector2i = room["data"]["origin_cell"] * scale
	var dimensions: Vector2i = room["data"]["size_cells"] * scale
	var bounds := {"origin":origin, "size":dimensions}
	var center := origin + dimensions / 2 - Vector2i.ONE * int(body["size"] / 2)
	var candidates: Array = []
	for y in range(origin.y, origin.y + dimensions.y - body["size"] + 1):
		for x in range(origin.x, origin.x + dimensions.x - body["size"] + 1): candidates.append(Vector2i(x,y))
	candidates.sort_custom(func(a,b):
		var da: int = (a-center).length_squared()
		var db: int = (b-center).length_squared()
		return a.y < b.y if da == db and a.x == b.x else (a.x < b.x if da == db else da < db))
	var placed := false
	for anchor in candidates:
		var fits := {"anchor":anchor, "size":body["size"], "room":bounds, "ignore_entity":&"", "fits":false}
		EventBus.publish(&"SpaceBodyFitsRequested", fits)
		if not fits.get("fits", false): continue
		var place := {"entity":actor, "anchor":anchor, "size":body["size"], "room":bounds, "accepted":false}
		EventBus.publish(&"SpaceBodyPlaceRequested", place)
		placed = place.get("accepted", false)
		break
	if not placed: return _fail(work, "Нет места для тела персонажа в стартовой комнате")
	var enter := {"entity":actor, "room":&"start", "accepted":false}
	EventBus.publish(&"RoomEnterRequested", enter)
	if not enter.get("accepted", false): return _fail(work, "Не удалось войти в стартовую комнату")
	var final: Dictionary = SaveService._collect_transition_snapshot()
	if not final.get("valid", false): return _fail(work, "Новый мир не прошёл проверку снимка")
	var after: Dictionary = final["payload"]["sections"]
	var new_report: Dictionary = WorldTransitionManifest.build_manifest(after, actor)
	if not new_report.get("valid", false): return _fail(work, "Персонаж потерян после переноса")
	var new_manifest: Dictionary = new_report["manifest"]
	if not new_manifest["other_entities"].is_empty() or not new_manifest["other_bodies"].is_empty() or not new_manifest["world_objects"].is_empty() or not new_manifest["ground_items"].is_empty() or not new_manifest["unassigned_items"].is_empty() or new_manifest["player_items"] != manifest["player_items"] or new_manifest["player_body"] == null or new_manifest["player_body"]["size"] != body["size"]: return _fail(work, "Состояние нового мира или вещи персонажа изменились")
	var old_entity: Dictionary = before["entities"][actor].duplicate(true)
	var new_entity: Dictionary = after["entities"][actor].duplicate(true)
	if old_entity.get(&"position", {}).get("direction", null) != new_entity.get(&"position", {}).get("direction", null): return _fail(work, "Изменилось направление персонажа")
	old_entity.erase(&"position"); new_entity.erase(&"position")
	if old_entity != new_entity: return _fail(work, "Изменилось состояние персонажа")
	for id in manifest["player_items"]:
		if after["items"]["instances"].get(id, null) != before["items"]["instances"].get(id, null) or after["belts"]["items"].get(id, null) != before["belts"]["items"].get(id, null): return _fail(work, "Изменились данные вещи персонажа")
	if before["time"] != after["time"] or before["periodic_effects"].get(actor, null) != after["periodic_effects"].get(actor, null) or before["resources"]["timers"].get(actor, null) != after["resources"]["timers"].get(actor, null) or after["actions"]["active"].has(actor): return _fail(work, "Изменились время, ресурсы или действие персонажа")
	for pair in [["pipeline", "modifiers"], ["sets", "active"], ["magic_inventory", "active"]]:
		if after[pair[0]][pair[1]].get(actor, null) != before[pair[0]][pair[1]].get(actor, null): return _fail(work, "Изменились модификаторы персонажа")
	for key in ["config", "moves", "paths"]:
		if after["movement"][key].get(actor, null) != cleaned["movement"][key].get(actor, null): return _fail(work, "Изменилось движение персонажа")
	if after["processes"] != cleaned["processes"] or not after["projectiles"]["active"].is_empty() or not after["detection"]["noises"].is_empty(): return _fail(work, "Изменились процессы или возникли снаряды и шумы")
	var expected_stats: Dictionary = stats.duplicate(true)
	expected_stats["floor"] = floor_no
	expected_stats["root"] = &"start"
	if not expected_stats["visited"].has(floor_no): expected_stats["visited"][floor_no] = {}
	expected_stats["visited"][floor_no][&"start"] = true
	expected_stats["max_depth"] = maxf(float(stats["max_depth"]), float(floor_no))
	expected_stats["depth_known"] = true
	if after["dungeon_tracking"].get("floor", 0) != floor_no or after["run_statistics"] != expected_stats or after["level"].get("level_id", &"") != level_id or after["level"].get("seed", null) != seed or after["level"].get("size_cells", null) != size_cells or after["rooms"].get("current_room", &"") != &"start" or after["rooms"]["rooms"].size() != 1: return _fail(work, "Неверное состояние следующего этажа")
	work["floor"] = floor_no
	work["anchor"] = new_manifest["player_body"]["anchor"]
	return true

func _fail(work: Dictionary, message: String) -> bool:
	work["error"] = message
	SaveService.fail_world_transition(message)
	return false
