extends Node
## Ограниченный журнал. Это диагностический след, а не полноценный реплей.
const MAX_ENTRIES := 2000
var enabled := true
var _entries: Array[String] = []

func _ready() -> void:
	EventBus.event_published.connect(_on_event)

func _on_event(event: StringName, payload: Dictionary) -> void:
	if not enabled:
		return
	# Запросы сериализации могут включать весь мир; в лог их содержимое не пишем.
	var text := str(event)
	if not str(event).begins_with("Snapshot") and event not in [&"RoomGetRequested", &"RoomConnectivityRepairRequested", &"FogStateGetRequested", &"SpaceRegionGetRequested", &"SpaceTilesSetRequested", &"SpaceTilesChanged", &"StrikeZoneGetRequested", &"SpaceBodiesGetRequested", &"ProcessStepped", &"ProjectileMoved"]:
		text += " " + str(payload).substr(0, 1000)
	_entries.append(text)
	if _entries.size() > MAX_ENTRIES:
		_entries.pop_front()

func get_entries() -> Array[String]:
	return _entries.duplicate()

func clear() -> void:
	_entries.clear()
