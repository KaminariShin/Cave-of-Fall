extends Node
## Безопасный отложенный вызов существующей snapshot-операции оснащения.
var _entity: StringName = &""
var _status := "none" # none, waiting, running, failed, installed
var _error := ""
var _generation := 0
var _trying := false

func _ready() -> void:
	EventBus.subscribe(&"RoomSpawned", _spawned)
	EventBus.subscribe(&"DungeonBossEquipmentInstalled", _installed)
	EventBus.subscribe(&"DungeonBossEquipmentAutoStatusRequested", _get_status)
	EventBus.subscribe(&"DungeonBossEquipmentAutoRetryRequested", _retry)
	EventBus.subscribe(&"TimeStepSettled", _settled)
	EventBus.subscribe(&"SnapshotRestored", _restored)
	EventBus.subscribe(&"SpaceMapConfigured", _reset)
	EventBus.subscribe(&"CombatDamageAllowedRequested", _damage_guard)
	EventBus.subscribe(&"CombatTargetActionAllowedRequested", _target_guard)
	EventBus.subscribe(&"ActionStartAllowedRequested", _action_guard)

func _boss_state() -> Dictionary:
	var q := {"found":false}
	EventBus.publish(&"DungeonBossGetRequested", q)
	return q.get("data", {}) if q.get("found", false) else {}

# Приостановка боевого взаимодействия — временная защитная мера, пока
# без экипировки нельзя корректно провести бой. Не правило неуязвимости босса.
func _needs_equipment(id: Variant) -> bool:
	if not id is StringName or id == &"": return false
	var boss := _boss_state()
	return boss.get("status", "") == "alive" and boss.get("entity", null) == id and boss.get("loadout", null) == null
func _damage_guard(e: Dictionary) -> void:
	if _needs_equipment(e.get("entity", null)):
		e["allowed"] = false
		e["reason"] = "Ожидается оснащение босса"
func _target_guard(e: Dictionary) -> void:
	if _needs_equipment(e.get("target", null)):
		e["allowed"] = false
		e["reason"] = "Ожидается оснащение босса"
func _action_guard(e: Dictionary) -> void:
	if _needs_equipment(e.get("entity", null)): e["allowed"] = false

func _spawned(e: Dictionary) -> void:
	for unit in e.get("units", []):
		if unit is Dictionary and unit.get("type_id", "") == "final_ogre" and unit.get("entity", null) is StringName:
			_schedule(unit["entity"])
			return

func _schedule(id: StringName) -> void:
	if not _needs_equipment(id): return
	_generation += 1
	_entity = id
	_status = "waiting"
	_error = ""
	call_deferred("_deferred_attempt", _generation)

func _deferred_attempt(generation: int) -> void:
	if generation == _generation and _status == "waiting": _attempt()

func _settled(_e: Dictionary) -> void:
	if _status == "waiting" and not _trying: _attempt()

func _installed(e: Dictionary) -> void:
	if e.get("entity", null) != _entity: return
	var boss := _boss_state()
	if boss.get("entity", null) != _entity or boss.get("loadout", null) == null: return
	_status = "installed"
	_error = ""
	_generation += 1

func _get_status(e: Dictionary) -> void:
	e["status"] = _status
	e["entity"] = _entity if _entity != &"" else null
	e["error"] = _error

func _retry(e: Dictionary) -> void:
	e["accepted"] = false
	if _trying or _entity == &"" or e.get("entity", null) != _entity or _status not in ["waiting", "failed"] or not _needs_equipment(_entity):
		e["error"] = "Повторное оснащение недоступно"; return
	var result := _attempt()
	e.merge(result, true)

func _attempt() -> Dictionary:
	if _trying or _entity == &"" or not _needs_equipment(_entity): return {"accepted":false, "error":"Оснащение недоступно"}
	_trying = true
	_status = "running"
	var id := _entity
	var request := {"entity":id, "accepted":false}
	EventBus.publish(&"DungeonBossEquipmentInstallRequested", request)
	if request.get("accepted", false):
		_status = "installed"
		_error = ""
		_generation += 1
	else:
		_status = "failed"
		_error = str(request.get("error", "Не удалось оснастить босса"))
		EventBus.publish(&"DungeonBossEquipmentAutoFailed", {"entity":id, "error":_error, "rolled_back":request.get("rolled_back", false)})
	_trying = false
	return {"accepted":request.get("accepted", false), "error":_error, "rolled_back":request.get("rolled_back", false)}

func _restored(_e: Dictionary) -> void:
	if _trying: return # внутренний rollback уже обрабатывается _attempt
	_generation += 1
	_entity = &""
	_status = "none"
	_error = ""
	var boss := _boss_state()
	if boss.get("status", "") != "alive" or not boss.get("entity", null) is StringName: return
	_entity = boss["entity"]
	if boss.get("loadout", null) == null: _schedule(_entity)
	else: _status = "installed"

func _reset(_e: Dictionary) -> void:
	_generation += 1
	_entity = &""
	_status = "none"
	_error = ""
