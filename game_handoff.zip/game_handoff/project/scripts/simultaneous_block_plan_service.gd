extends Node
## Расчёт уже пересёкших блок ударов после защиты/ослабления и округления.
## Ничья за остаточные единицы расходует игровой ГСЧ, но ресурсы не изменяет.
const MAX_HITS := 10000
const MAX_TOTAL := 1000000000
func _ready() -> void:
	EventBus.subscribe(&"SimultaneousBlockPlanRequested", _plan)
func _plan(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("data")
	e.erase("error")
	var stamina = e.get("available_stamina",null)
	var hits = e.get("hits",null)
	if not stamina is int or stamina < 0 or stamina > MAX_TOTAL or not hits is Array or hits.size() > MAX_HITS:
		e["error"] = "Нужны целый свободный запас и ограниченный список попаданий"; return
	var total := 0
	var seen := {}
	var entries: Array = []
	for hit in hits:
		if not hit is Dictionary: e["error"] = "Некорректное попадание"; return
		var id = hit.get("id",null)
		var damage = hit.get("damage",null)
		if not id is StringName or id == &"" or seen.has(id) or not damage is int or damage < 0 or damage > MAX_TOTAL:
			e["error"] = "Нужны уникальные ID и целый неотрицательный урон"; return
		seen[id] = true
		total += damage
		if total > MAX_TOTAL: e["error"] = "Сумма урона превышает лимит"; return
		entries.append({"id":id,"damage":damage,"blocked":0})
	# Продукт не больше 10^18: целочисленное деление без потери точности.
	var capacity: int = mini(total,stamina * 2)
	var allocated := 0
	if total > 0:
		for hit in entries:
			@warning_ignore("integer_division")
			var part: int = (int(hit["damage"]) * capacity) / total
			hit["blocked"] = part
			allocated += part
	var remainder: int = capacity - allocated
	entries.sort_custom(func(a,b): return a["damage"] < b["damage"] or (a["damage"] == b["damage"] and str(a["id"]) < str(b["id"])))
	var index := 0
	while remainder > 0 and index < entries.size():
		var end := index + 1
		while end < entries.size() and entries[end]["damage"] == entries[index]["damage"]: end += 1
		var eligible: Array = []
		for i in range(index,end):
			if entries[i]["blocked"] < entries[i]["damage"]: eligible.append(i)
		var take: int = mini(remainder,eligible.size())
		if take < eligible.size():
			# Частичный проход группы равных ударов: случайная выборка без замены.
			for i in range(take):
				var j: int = RngService._rng.randi_range(i,eligible.size()-1)
				var tmp = eligible[i]
				eligible[i] = eligible[j]
				eligible[j] = tmp
		for i in range(take): entries[eligible[i]]["blocked"] += 1
		remainder -= take
		index = end
	entries.sort_custom(func(a,b): return str(a["id"]) < str(b["id"]))
	for hit in entries: hit["passed"] = hit["damage"] - hit["blocked"]
	@warning_ignore("integer_division")
	var cost: int = (capacity + 1) / 2
	e["data"] = {"hits":entries,"total_damage":total,"absorbed":capacity,"stamina_cost":cost,"block_interrupted":capacity < total}
	e["accepted"] = true
