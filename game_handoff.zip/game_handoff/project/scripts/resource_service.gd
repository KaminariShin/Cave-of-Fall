extends Node
## HP, Stamina, MP. Формулы и период находятся в ruleset.
const ORDER := [&"MP", &"Stamina", &"HP"]
const Accumulator = preload("res://scripts/accumulator.gd")
var _period := 0.5
var _regen_params: Dictionary = {}
var _busy := false
var _coefficients: Dictionary = {}
var _timers: Dictionary = {} # id процесса -> {entity, resource}
var _due: Array = []

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var params: Dictionary = rules["ruleset"].get("parameters", {}).get("resources", {})
		_period = maxf(0.01, float(params.get("regen_period", 0.5)))
		_period = maxf(0.01, round(_period / 0.01) * 0.01)
		_regen_params = params.get("regeneration", {}).duplicate(true)
		_coefficients = {&"HP": params.get("hp", {}), &"Stamina": params.get("stamina", {}), &"MP": params.get("mp", {})}
	EventBus.subscribe(&"EntityCreated", _entity_created)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"EntityDied", _entity_died)
	EventBus.subscribe(&"StatChanged", _stat_changed)
	EventBus.subscribe(&"ItemEquipped", _equipment_effect_changed)
	EventBus.subscribe(&"ItemUnequipped", _equipment_effect_changed)
	EventBus.subscribe(&"ItemLearningProgressChanged", _equipment_effect_changed)
	EventBus.subscribe(&"ResourceGetRequested", _get_requested)
	EventBus.subscribe(&"ResourceSetRequested", _set_requested)
	EventBus.subscribe(&"ResourceSpendRequested", _spend_requested)
	EventBus.subscribe(&"MovementStaminaChargeRequested", _movement_charge_requested)
	EventBus.subscribe(&"ProcessCompleted", _process_completed)
	EventBus.subscribe(&"ProcessInterrupted", _process_interrupted)
	EventBus.subscribe(&"TimeResourcesTick", _tick)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"ResourceSnapshotValidateRequested", _snapshot_validate)

func _entity_created(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var resources := {}
	for resource in ORDER:
		var maximum := _calculate_max(entity, resource)
		if not is_finite(maximum):
			EventBus.publish(&"ResourceMaxCalculationFailed", {"entity":entity, "resource":resource})
			return
		resources[resource] = {"current": maximum, "max": maximum, "remainder": 0.0, "timer": 0.0, "reserve": 0.0, "reserve_filled": 0.0}
		if resource == &"HP": resources[resource]["cost_remainder"] = 0.0
		if resource == &"Stamina":
			resources[resource]["movement_remainder"] = 0.0
			resources[resource]["movement_debt"] = 0.0
	_commit(entity, resources)

func _entity_died(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	for process_id in _timers.keys():
		if _timers[process_id]["entity"] == entity:
			_timers.erase(process_id)
			EventBus.publish(&"ProcessInterruptRequested", {"id":process_id, "reason":&"entity_died"})
	for i in range(_due.size() - 1, -1, -1):
		if _due[i]["entity"] == entity: _due.remove_at(i)

func _entity_removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	for process_id in _timers.keys():
		if _timers[process_id]["entity"] == entity:
			_timers.erase(process_id)
	for i in range(_due.size() - 1, -1, -1):
		if _due[i]["entity"] == entity:
			_due.remove_at(i)

func _stat_changed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var data := _read(entity)
	if data.is_empty():
		return
	# Не заменяем максимум нулём при недоступной характеристике; весь пакет
	# оставляем нетронутым и сообщаем ошибку до изменения ресурсов.
	var maxima := {}
	for resource in ORDER:
		var maximum := _calculate_max(entity, resource)
		if not is_finite(maximum):
			EventBus.publish(&"ResourceMaxCalculationFailed", {"entity":entity, "resource":resource})
			return
		maxima[resource] = maximum
	var changed: Array = []
	for resource in ORDER:
		var entry: Dictionary = data[resource]
		var old: float = entry["current"]
		var old_max: float = entry["max"]
		entry["max"] = maxima[resource]
		if resource == &"HP" and old_max > 0.0 and old_max != float(entry["max"]):
			# Сохраняем долю здоровья; текущее HP округляется до ближайшего целого.
			# Живой персонаж при положительном новом максимуме не теряет последнюю единицу.
			var scaled: float = roundf(old / old_max * float(entry["max"]))
			if old > 0.0 and float(entry["max"]) >= 1.0: scaled = maxf(1.0,scaled)
			entry["current"] = clampf(scaled,0.0,float(entry["max"]))
		else:
			entry["current"] = minf(old, entry["max"])
		if entry["current"] >= entry["max"]:
			entry["remainder"] = 0.0
			entry["timer"] = 0.0
		if old != entry["current"]:
			changed.append({"resource": resource, "old": old, "new": entry["current"]})
	var before_release: float = data[&"Stamina"]["current"]
	if float(data[&"HP"]["current"]) >= float(data[&"HP"]["max"]): _release_reserve(data)
	if float(data[&"Stamina"]["current"]) != before_release: changed.append({"resource":&"Stamina", "old":before_release, "new":data[&"Stamina"]["current"]})
	_commit(entity, data)
	for resource in ORDER:
		_sync_timer(entity, resource)
	for item in changed:
		_emit_change(entity, item["resource"], item["old"], item["new"])

# Повторяем расчёт после коммита экипировки/обучения и смены управления.
func _equipment_effect_changed(event: Dictionary) -> void:
	refresh_equipment_maxima(event.get("entity", &""))

func refresh_equipment_maxima(entity: StringName) -> void:
	if entity != &"": _stat_changed({"entity":entity})

func _get_requested(request: Dictionary) -> void:
	var entity: StringName = request.get("entity", &"")
	var resource := StringName(str(request.get("resource", "")))
	var data := _read(entity)
	request["found"] = data.has(resource)
	if request["found"]:
		request["data"] = data[resource].duplicate(true)

func _set_requested(request: Dictionary) -> void:
	request["accepted"] = false
	var entity: StringName = request.get("entity", &"")
	var resource := StringName(str(request.get("resource", "")))
	var value = request.get("value", null)
	if not (value is int or value is float) or not is_finite(float(value)):
		return
	var data := _read(entity)
	if not data.has(resource):
		return
	var entry: Dictionary = data[resource]
	var old := float(entry["current"])
	entry["current"] = clampf(float(value), 0.0, float(entry["max"]))
	if entry["current"] >= entry["max"]:
		entry["remainder"] = 0.0
		entry["timer"] = 0.0
	var stamina_old: float = data[&"Stamina"]["current"]
	if resource == &"HP" and entry["current"] >= entry["max"]:
		_release_reserve(data)
	if not _commit(entity, data):
		return
	if stamina_old != float(data[&"Stamina"]["current"]):
		_emit_change(entity, &"Stamina", stamina_old, data[&"Stamina"]["current"])
		_sync_timer(entity, &"Stamina")
	_sync_timer(entity, resource)
	request["accepted"] = true
	request["value"] = entry["current"]
	_emit_change(entity, resource, old, entry["current"])

## Резерв уже вынесен из свободной Stamina, поэтому current — свободный остаток.
func _spend_requested(request: Dictionary) -> void:
	request["accepted"] = false
	var entity: StringName = request.get("entity", &"")
	var resource: StringName = request.get("resource", &"")
	var amount = request.get("amount", null)
	if resource != &"Stamina" or not (amount is int or amount is float) or not is_finite(float(amount)) or float(amount) < 0.0:
		return
	var data := _read(entity)
	if not data.has(&"Stamina") or not data.has(&"HP"):
		return
	var stamina: Dictionary = data[&"Stamina"]
	var available := maxf(0.0, float(stamina["current"]))
	request["available"] = available
	if float(amount) > available + 0.000000001:
		return
	var set := {"entity": entity, "resource": &"Stamina", "value": float(stamina["current"]) - float(amount), "accepted": false}
	_set_requested(set)
	request["accepted"] = set["accepted"]
	if set["accepted"]:
		request["value"] = set["value"]

## Технический контракт: начислить фактически пройденное расстояние после
## применения коэффициентов; сам MovementService пока его не вызывает.
func _movement_charge_requested(request: Dictionary) -> void:
	request["accepted"] = false
	var entity: StringName = request.get("entity", &"")
	var amount = request.get("amount", null)
	if not (amount is int or amount is float) or not is_finite(float(amount)) or float(amount) < 0.0: return
	var data := _read(entity)
	if not data.has(&"Stamina"): return
	var stamina: Dictionary = data[&"Stamina"]
	var accumulated := Accumulator.accumulate_unbounded(float(stamina.get("movement_remainder", NAN)), float(amount))
	if not accumulated["ok"]: return
	var old := float(stamina["current"])
	var debt := float(stamina.get("movement_debt", NAN))
	var whole := float(accumulated["whole"])
	# Суммирование долей одного сегмента может оставить 0.9999999999999999
	# вместо единицы. Устраняем лишь погрешность границы float.
	if float(accumulated["remainder"]) >= 1.0 - 0.000000000001:
		whole += 1.0
		accumulated["remainder"] = 0.0
	if not is_finite(debt) or debt < 0.0 or not is_finite(debt + whole) or debt + whole > Accumulator.MAX_EXACT_INTEGER: return
	var paid := minf(floorf(old), whole)
	stamina["current"] = old - paid
	stamina["movement_debt"] = debt + whole - paid
	stamina["movement_remainder"] = accumulated["remainder"]
	if not _commit(entity, data): return
	request["accepted"] = true
	request["charged"] = whole
	request["paid"] = paid
	request["debt"] = stamina["movement_debt"]
	request["remainder"] = stamina["movement_remainder"]
	_sync_timer(entity, &"Stamina")
	_emit_change(entity, &"Stamina", old, float(stamina["current"]))
	EventBus.publish(&"MovementStaminaCharged", {"entity":entity, "charged":whole, "paid":paid, "debt":stamina["movement_debt"], "remainder":stamina["movement_remainder"]})

func _emit_change(entity: StringName, resource: StringName, old: float, value: float) -> void:
	if old == value:
		return
	EventBus.publish(&"ResourceChanged", {"entity": entity, "resource": resource, "old": old, "new": value})
	if old > 0.0 and value <= 0.0:
		EventBus.publish(&"ResourceDepleted", {"entity": entity, "resource": resource})

func _calculate_max(entity: StringName, resource: StringName) -> float:
	var total := 0.0
	var coefficients: Dictionary = _coefficients.get(resource, {})
	for stat in coefficients:
		var request := {"entity": entity, "stat": StringName(str(stat)), "found": false}
		EventBus.publish(&"StatGetRequested", request)
		if not request.get("found",false) or not (request.get("value",null) is int or request.get("value",null) is float) or not is_finite(float(request["value"])):
			return NAN
		total += float(request["value"]) * float(coefficients[stat])
	var gear := {"entity":entity, "component":&"equipment", "found":false}
	EventBus.publish(&"ComponentGetRequested",gear)
	if gear.get("found",false):
		if not gear.get("data",null) is Dictionary: return NAN
		for slot in ["main","off","head","body","hands","belt","legs","feet","ring1","ring2","amulet","cloak"]:
			var id = gear["data"].get(slot,null)
			if id == null or not (id is StringName or id is String): continue
			var item := {"item":StringName(str(id)), "found":false}
			EventBus.publish(&"ItemGetRequested",item)
			if not item.get("found",false): continue
			var bonus: Dictionary = DungeonChestLearningService.equipped_resource_mod_bonus(entity,item["item_data"],item["base"],resource)
			if not bonus.get("valid",false): return NAN
			total += float(bonus["bonus"])
	# Сначала суммируются характеристики и все бонусы, затем неотрицательный
	# максимум округляется вниз. Текущие значения и регенерационный резерв
	# пока имеют отдельные старые дробные пути и не нормализуются здесь.
	return floorf(maxf(0.0, total)) if is_finite(total) else NAN

func _read(entity: StringName) -> Dictionary:
	var query := {"entity": entity, "component": &"resources", "found": false}
	EventBus.publish(&"ComponentGetRequested", query)
	return query.get("data", {}) if query["found"] else {}

func _commit(entity: StringName, data: Dictionary) -> bool:
	var request := {"entity": entity, "data": data, "accepted": false}
	EventBus.publish(&"ResourcesCommitRequested", request)
	return request["accepted"]

func _timer_id(entity: StringName, resource: StringName) -> StringName:
	return StringName("regen:%s:%s" % [str(entity).uri_encode(), str(resource)])

func _sync_timer(entity: StringName, resource: StringName) -> void:
	var data := _read(entity)
	if not data.has(resource):
		return
	var process_id := _timer_id(entity, resource)
	var alive := {"entity":entity, "allowed":true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	var waiting: bool = resource == &"HP" and float(data[&"HP"].get("reserve", 0.0)) > 0.0
	var below: bool = alive["allowed"] and (data[resource]["current"] < data[resource]["max"] or (resource == &"Stamina" and (float(data[&"HP"].get("reserve", 0.0)) > 0.0 or float(data[&"Stamina"].get("movement_debt", 0.0)) > 0.0))) and not waiting
	if not below and _timers.has(process_id):
		_timers.erase(process_id)
		EventBus.publish(&"ProcessInterruptRequested", {"id": process_id, "reason": &"resource_full"})
	elif below and not _timers.has(process_id):
		var start := {"id": process_id, "duration": _period, "entity": entity, "independent": false, "accepted": false}
		_timers[process_id] = {"entity": entity, "resource": resource}
		EventBus.publish(&"ProcessStartRequested", start)
		if not start["accepted"]:
			_timers.erase(process_id)
			EventBus.publish(&"RegenTimerStartFailed", {"entity": entity, "resource": resource})

func _process_completed(event: Dictionary) -> void:
	var process_id: StringName = event.get("process", &"")
	if _timers.has(process_id):
		_due.append(_timers[process_id].duplicate())
		_timers.erase(process_id)

func _process_interrupted(event: Dictionary) -> void:
	var process_id: StringName = event.get("process", &"")
	_timers.erase(process_id)

func _tick(_event: Dictionary) -> void:
	# Process Registry уже обновлён. По каждому юниту порядок MP, Stamina, HP.
	var due := _due.duplicate(true)
	_due.clear()
	for resource in ORDER:
		for item in due:
			if item["resource"] != resource:
				continue
			var entity: StringName = item["entity"]
			var data := _read(entity)
			if not data.has(resource):
				continue
			data[resource]["timer"] = 0.0
			_commit(entity, data)
			if data[resource]["current"] < data[resource]["max"] or (resource == &"Stamina" and (float(data[&"HP"].get("reserve", 0.0)) > 0.0 or float(data[&"Stamina"].get("movement_debt", 0.0)) > 0.0)):
				_regen_cycle(entity, resource)
				EventBus.publish(&"RegenCycleDue", {"entity": entity, "resource": resource})
			_sync_timer(entity, resource)
	# Сохраняем прошедшее время каждого действующего процесса в компоненте.
	for process_id in _timers.keys():
		var item: Dictionary = _timers[process_id]
		var allowed := {"entity": item["entity"], "allowed": true}
		EventBus.publish(&"AIEntityTickAllowedRequested", allowed)
		if not allowed["allowed"]:
			continue
		var get := {"id": process_id, "found": false}
		EventBus.publish(&"ProcessGetRequested", get)
		if not get["found"]:
			continue
		var data := _read(item["entity"])
		if data.has(item["resource"]):
			data[item["resource"]]["timer"] = get["data"]["elapsed"]
			_commit(item["entity"], data)

func _stat(entity: StringName, stat: StringName) -> float:
	var query := {"entity":entity, "stat":stat, "found":false}
	EventBus.publish(&"StatGetRequested", query)
	return float(query["value"]) if query["found"] else NAN

func _rate(entity: StringName, resource: StringName) -> float:
	var con := _stat(entity, &"CON")
	var strength := _stat(entity, &"STR")
	var dex := _stat(entity, &"DEX")
	var wisdom := _stat(entity, &"WIS")
	var intelligence := _stat(entity, &"INT")
	if not is_finite(con) or not is_finite(strength) or not is_finite(dex) or not is_finite(wisdom) or not is_finite(intelligence): return NAN
	if resource == &"HP":
		if con < float(_regen_params.get("hp_low_threshold", 5.0)): return 0.0
		if con < float(_regen_params.get("hp_high_threshold", 10.0)): return maxf(0.0, float(_regen_params.get("hp_low_factor", 0.02)) * (con - float(_regen_params.get("hp_low_baseline", 4.0))))
		return maxf(0.0, con / float(_regen_params.get("hp_high_divisor", 10.0)))
	if resource == &"Stamina": return maxf(0.0, float(_regen_params.get("stamina_base", 2.0)) + con / float(_regen_params.get("stamina_con_divisor", 5.0)) + strength / float(_regen_params.get("stamina_str_divisor", 10.0)) + dex / float(_regen_params.get("stamina_dex_divisor", 10.0)))
	return maxf(0.0, float(_regen_params.get("mp_base", 1.0)) + wisdom / float(_regen_params.get("mp_wis_divisor", 5.0)) + intelligence / float(_regen_params.get("mp_int_divisor", 10.0)))

func _release_reserve(data: Dictionary) -> void:
	var hp: Dictionary = data[&"HP"]
	var stamina: Dictionary = data[&"Stamina"]
	stamina["current"] = minf(float(stamina["max"]), float(stamina["current"]) + float(hp.get("reserve_filled", 0.0)))
	hp["reserve"] = 0.0
	hp["reserve_filled"] = 0.0
	hp.erase("reserve_heal")
	hp.erase("reserve_cost_remainder")

func _accumulate(entry: Dictionary, amount: float) -> float:
	var result := Accumulator.accumulate_unbounded(float(entry["remainder"]), amount)
	if not result["ok"]: return -1.0
	var old := float(entry["current"])
	entry["current"] = minf(float(entry["max"]), old + float(result["whole"]))
	entry["remainder"] = 0.0 if entry["current"] >= entry["max"] else result["remainder"]
	if entry["current"] >= entry["max"]: entry["timer"] = 0.0
	return float(entry["current"]) - old

func _regen_cycle(entity: StringName, resource: StringName) -> void:
	var data := _read(entity)
	if data.is_empty(): return
	var alive := {"entity":entity, "allowed":true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	if not alive["allowed"]: return
	var rate := _rate(entity, resource)
	if not is_finite(rate) or rate < 0.0: return
	var hp: Dictionary = data[&"HP"]
	var stamina: Dictionary = data[&"Stamina"]
	var old_hp := float(hp["current"])
	var old_stamina := float(stamina["current"])
	var old_resource := float(data[resource]["current"])
	var amount := rate * _period
	var reserved_now := false
	var released_hp := false
	if resource == &"HP":
		if float(hp["reserve"]) > 0: return
		var cost := amount * float(_regen_params.get("hp_stamina_multiplier", 2.5))
		var cost_result := Accumulator.accumulate_unbounded(float(hp.get("cost_remainder", 0.0)), cost)
		if not cost_result["ok"]: return
		var whole_cost := float(cost_result["whole"])
		# Старые сторонние пути пока могут дать дробный current. Не тратим
		# дробную часть: на этом этапе оплачиваются только целые единицы.
		var available := floorf(float(stamina["current"]))
		if available >= whole_cost:
			stamina["current"] = float(stamina["current"]) - whole_cost
			hp["cost_remainder"] = cost_result["remainder"]
			if _accumulate(hp, amount) < 0.0: return
		else:
			stamina["current"] = float(stamina["current"]) - available
			hp["reserve"] = whole_cost
			hp["reserve_filled"] = available
			hp["reserve_heal"] = amount
			# Остаток фиксируется лишь после оплаты; при отмене резервного
			# цикла предыдущее накопление стоимости сохраняется.
			hp["reserve_cost_remainder"] = cost_result["remainder"]
			reserved_now = true
	elif resource == &"Stamina":
		var accumulated := Accumulator.accumulate_unbounded(float(stamina["remainder"]), amount)
		if not accumulated["ok"]: return
		var whole := float(accumulated["whole"])
		stamina["remainder"] = accumulated["remainder"]
		var debt_paid := minf(whole, float(stamina["movement_debt"]))
		stamina["movement_debt"] = float(stamina["movement_debt"]) - debt_paid
		whole -= debt_paid
		if float(hp["reserve"]) > 0.0:
			var fill := minf(whole, maxf(0.0, float(hp["reserve"]) - float(hp["reserve_filled"])))
			hp["reserve_filled"] = float(hp["reserve_filled"]) + fill
			whole -= fill
			if float(hp["reserve_filled"]) >= float(hp["reserve"]):
				var heal := float(hp["reserve_heal"])
				hp["cost_remainder"] = hp["reserve_cost_remainder"]
				hp["reserve"] = 0.0
				hp["reserve_filled"] = 0.0
				hp.erase("reserve_heal")
				hp.erase("reserve_cost_remainder")
				if _accumulate(hp, heal) < 0.0: return
				released_hp = true
		stamina["current"] = minf(float(stamina["max"]), float(stamina["current"]) + whole)
		if float(stamina["current"]) >= float(stamina["max"]) and float(hp["reserve"]) == 0.0 and float(stamina["movement_debt"]) == 0.0:
			stamina["remainder"] = 0.0
			stamina["timer"] = 0.0
	else:
		_accumulate(data[resource], amount)
	if not _commit(entity, data): return
	_emit_change(entity, &"HP", old_hp, float(hp["current"]))
	_emit_change(entity, &"Stamina", old_stamina, float(stamina["current"]))
	if resource == &"MP": _emit_change(entity, resource, old_resource, float(data[resource]["current"]))
	if reserved_now: EventBus.publish(&"RegenReserved", {"entity":entity, "resource":&"HP", "amount":hp["reserve"], "filled":hp["reserve_filled"]})
	if not reserved_now:
		EventBus.publish(&"ResourceRegenerated", {"entity":entity, "resource":resource, "amount":float(data[resource]["current"]) - old_resource})
	if released_hp: EventBus.publish(&"ResourceRegenerated", {"entity":entity, "resource":&"HP", "amount":float(hp["current"]) - old_hp})
	_sync_timer(entity, &"Stamina")
	_sync_timer(entity, &"HP")

func _snapshot_collect(event: Dictionary) -> void:
	if not _due.is_empty():
		event["errors"].append("Нельзя сохранять во время обработки регенерации")
		return
	event["sections"]["resources"] = {"timers": _timers.duplicate(true)}

func _snapshot_validate(event: Dictionary) -> void:
	event["valid"] = false
	var sections = event.get("sections", {})
	var entities = sections.get("entities", null)
	var data = sections.get("resources", null)
	var processes = sections.get("processes", null)
	if not entities is Dictionary or not data is Dictionary or not data.get("timers", null) is Dictionary or not processes is Array: return
	var ids := {}
	for process in processes:
		if not process is Dictionary: return
		ids[process.get("id", &"")] = process
	for id in data["timers"]:
		var timer = data["timers"][id]
		if not id is StringName or not timer is Dictionary or not timer.get("entity", null) is StringName or timer.get("resource", &"") not in ORDER or not entities.has(timer["entity"]) or not ids.has(id): return
		if ids[id].get("entity_id", &"") != timer["entity"] or ids[id].get("independent", true) or id != _timer_id(timer["entity"], timer["resource"]): return
	for entity in entities:
		var component = entities[entity].get(&"resources", null) if entities[entity] is Dictionary else null
		if not component is Dictionary: continue
		for resource in ORDER:
			var entry = component.get(resource,null)
			if not entry is Dictionary: return
			var maximum = entry.get("max",null)
			if not (maximum is int or maximum is float) or not is_finite(float(maximum)) or float(maximum) < 0.0 or floorf(float(maximum)) != float(maximum): return
			# Текущие значения пока могут быть дробными, но повреждённый
			# снимок не должен внедрять NaN, отрицательные или лишние ресурсы.
			var current = entry.get("current",null)
			var remainder = entry.get("remainder",null)
			var timer = entry.get("timer",null)
			if not (current is int or current is float) or not is_finite(float(current)) or float(current) < 0.0 or float(current) > float(maximum): return
			if not (remainder is int or remainder is float) or not is_finite(float(remainder)) or float(remainder) < 0.0 or float(remainder) >= 1.0: return
			if not (timer is int or timer is float) or not is_finite(float(timer)) or float(timer) < 0.0: return
		var stamina: Dictionary = component[&"Stamina"]
		var debt = stamina.get("movement_debt",null)
		var move_remainder = stamina.get("movement_remainder",null)
		if not (debt is int or debt is float) or not is_finite(float(debt)) or float(debt) < 0.0 or float(debt) > Accumulator.MAX_EXACT_INTEGER or floorf(float(debt)) != float(debt): return
		if not (move_remainder is int or move_remainder is float) or not is_finite(float(move_remainder)) or float(move_remainder) < 0.0 or float(move_remainder) >= 1.0: return
		var hp = component.get(&"HP", null)
		if not hp is Dictionary: return
		var cost_remainder = hp.get("cost_remainder", null)
		if not (cost_remainder is int or cost_remainder is float) or not is_finite(float(cost_remainder)) or float(cost_remainder) < 0.0 or float(cost_remainder) >= 1.0: return
		var reserve = hp.get("reserve", null)
		var filled = hp.get("reserve_filled", null)
		if not (reserve is int or reserve is float) or not is_finite(float(reserve)) or float(reserve) < 0 or not (filled is int or filled is float) or not is_finite(float(filled)) or float(filled) < 0 or float(filled) > float(reserve) + 0.000000001: return
		if floorf(float(reserve)) != float(reserve) or floorf(float(filled)) != float(filled): return
		if float(reserve) > 0:
			var pending_cost = hp.get("reserve_cost_remainder",null)
			if not (pending_cost is int or pending_cost is float) or not is_finite(float(pending_cost)) or float(pending_cost) < 0.0 or float(pending_cost) >= 1.0: return
			if data["timers"].has(_timer_id(entity, &"HP")) or not (hp.get("reserve_heal", null) is int or hp.get("reserve_heal", null) is float) or not is_finite(float(hp["reserve_heal"])) or float(hp["reserve_heal"]) < 0: return
		elif float(filled) != 0 or hp.has("reserve_cost_remainder"): return
	event["valid"] = true

func _snapshot_apply(event: Dictionary) -> void:
	_timers = event["sections"]["resources"]["timers"].duplicate(true)
	_due.clear()
