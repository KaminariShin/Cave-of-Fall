extends Node
## Сохраняемый однократный бросок. Не выбирает позицию и не создаёт сундук.
var _rolls: Dictionary = {}
var _busy := false
var _generation := 0

func _ready() -> void:
	EventBus.subscribe(&"DungeonNormalChestRollRequested",_decide)
	EventBus.subscribe(&"DungeonNormalChestRollGetRequested",_get_roll)
	EventBus.subscribe(&"RoomRemoved",_removed)
	EventBus.subscribe(&"SpaceMapConfigured",_reset)
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
	EventBus.subscribe(&"SnapshotApplyRequested",_apply)
	EventBus.subscribe(&"NormalChestRollSnapshotValidateRequested",_validate)

func _reset(_e: Dictionary) -> void:
	_generation += 1
	_rolls.clear()
func _removed(e: Dictionary) -> void:
	var id=e.get("room",null)
	if _rolls.has(id):
		_rolls.erase(id)
		_generation+=1
func _get_roll(e: Dictionary) -> void:
	var room=e.get("room",null)
	e["found"]=_rolls.has(room)
	if e["found"]:
		e["roll"]=_rolls[room]
		e["selected"]=_rolls[room]==1
	else:
		e.erase("roll");e.erase("selected")

func _eligible(room: StringName) -> bool:
	var tracking: Dictionary={}
	EventBus.publish(&"DungeonFloorTrackingGetRequested",tracking)
	if not tracking.get("found",false):return false
	var t: Dictionary=tracking["data"]
	var query: Dictionary={"id":room}
	EventBus.publish(&"RoomGetRequested",query)
	if not query.get("found",false):return false
	var info: Dictionary=query["data"]
	if info.get("type","") not in ["passage","deadend","corridor"] or room==t.get("root",null) or room==t.get("boss_candidate",null) or room==t.get("portal_candidate",null):return false
	if t.get("boss_candidate",null)!=null and info.get("parent",null)==t["boss_candidate"] and info.get("type","")=="deadend":return false
	var depth: Dictionary={"room":room}
	EventBus.publish(&"DungeonRoomDepthRequested",depth)
	if not depth.get("accepted",false):return false
	if t.get("floor",0)==4 and t.get("boss_candidate",null)==null and info.get("type","")=="passage" and int(depth.get("distance",0))>15:return false
	return true

func _decide(e: Dictionary) -> void:
	e["accepted"]=false
	for key in ["roll","selected","existing","error"]:e.erase(key)
	var room=e.get("room",null)
	if _busy or not room is StringName or room==&"":
		e["error"]="Недоступен бросок комнаты";return
	_busy=true
	var generation:=_generation
	if not _eligible(room) or generation!=_generation:
		_busy=false;e["error"]="Комната недоступна или исключена";return
	if _rolls.has(room):
		e["accepted"]=true;e["existing"]=true;e["roll"]=_rolls[room];e["selected"]=_rolls[room]==1
		_busy=false;return
	var roll: Dictionary={"min":1,"max":4}
	EventBus.publish(&"RngIntRequested",roll)
	var value=roll.get("value",null)
	if generation!=_generation or not roll.get("accepted",false) or not value is int or value<1 or value>4 or not _eligible(room) or generation!=_generation:
		_busy=false;e["error"]="Ошибка ГСЧ или комната изменилась";return
	_rolls[room]=value
	e["accepted"]=true;e["existing"]=false;e["roll"]=value;e["selected"]=value==1
	_busy=false
	EventBus.publish(&"DungeonNormalChestRolled",{"room":room,"roll":value,"selected":value==1})

func _collect(e: Dictionary) -> void:
	if _busy:
		e["errors"].append("Нельзя сохранять во время броска сундука");return
	e["sections"]["normal_chest_rolls"]=_rolls.duplicate(true)
func _apply(e: Dictionary) -> void:
	_generation+=1
	_rolls=e["sections"]["normal_chest_rolls"].duplicate(true)
	_busy=false
func _validate(e: Dictionary) -> void:
	e["valid"]=false
	var sections=e.get("sections",null)
	if not sections is Dictionary or not sections.get("normal_chest_rolls",null) is Dictionary or not sections.get("rooms",{}).get("rooms",null) is Dictionary or not sections.get("dungeon_tracking",null) is Dictionary:return
	var rolls: Dictionary=sections["normal_chest_rolls"]
	var rooms: Dictionary=sections["rooms"]["rooms"]
	var t: Dictionary=sections["dungeon_tracking"]
	if not rolls.is_empty() and t.is_empty():return
	for id in rolls:
		var v=rolls[id]
		if not id is StringName or not v is int or v<1 or v>4 or not rooms.get(id,null) is Dictionary:return
		var info: Dictionary=rooms[id]
		if info.get("type","") not in ["passage","deadend","corridor"] or id==t.get("root",null) or id==t.get("boss_candidate",null) or id==t.get("portal_candidate",null):return
		if t.get("boss_candidate",null)!=null and info.get("parent",null)==t["boss_candidate"] and info.get("type","")=="deadend":return
		var distance: int=DungeonMilestoneService._distance(rooms,t.get("root",&""),id)
		if distance<0:return
		if t.get("floor",0)==4 and t.get("boss_candidate",null)==null and info.get("type","")=="passage" and distance>15:return
	e["valid"]=true
