extends Node
## Fragment 36: explicit, atomic room spawn; caller supplies depth, entry and pool.
const STATS := ["CON", "STR", "DEX", "INT", "WIS", "PER"]
const MAX_QUEUE := 256
const FINAL_BOSS_WEIGHT_PER_LEVEL := 12.0
# Черновой контент; фиксированный вес включает тег босса.
const FINAL_BOSS := {"id":"final_ogre", "type_weight":FINAL_BOSS_WEIGHT_PER_LEVEL, "species":{"id":"ogre", "species_weight":0.0}, "tags":[{"id":"boss", "tag_weight":0.0}], "base_stats":{"CON":10,"STR":10,"DEX":3,"INT":2,"WIS":3,"PER":12}, "growth_per_level":{"CON":2,"STR":2,"DEX":0,"INT":0,"WIS":0,"PER":0}, "body_size":6, "min_depth":0, "max_depth":null}
var _boss_state: Dictionary = {} # committed final boss, retained even if its entity is removed
var _spawned: Dictionary = {}
var _created_entities: Dictionary = {} # entity -> room, including dead until removed
var _rooms: Dictionary = {}
var _current_room: StringName = &""
var _sequence := 0
var _busy := false
var _transition_pending_ids: Dictionary = {}
var _scale := 4
var _body_sizes: Array = [2, 4, 6]
var _demo_pool: Array = []
var _demo_tag_options: Array = []
var _tag_rules: Dictionary = {}
var _rat_small_probability := 0.8
var _default_delay: Variant = null

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var params: Dictionary = rules["ruleset"].get("parameters", {})
		_scale = int(params.get("space", {}).get("tiles_per_cell", 4))
		_body_sizes.clear()
		for size in params.get("space", {}).get("body_sizes", [2,4,6]): _body_sizes.append(int(size))
		_default_delay = params.get("spawn", {}).get("queue_delay", null)
		_tag_rules = params.get("spawn", {}).get("tag_rules", {}).duplicate(true)
		_rat_small_probability = float(params.get("rat", {}).get("small_probability", 0.8))
		_demo_pool = params.get("spawn", {}).get("demo_pool", []).duplicate(true)
		_demo_tag_options = params.get("spawn", {}).get("demo_tag_options", []).duplicate(true)
		for demo in _demo_pool:
			demo["body_size"] = int(demo["body_size"])
			demo["min_depth"] = int(demo["min_depth"])
			if demo.get("max_depth", null) != null: demo["max_depth"] = int(demo["max_depth"])
	EventBus.subscribe(&"RoomSpawnRequested", _request)
	EventBus.subscribe(&"RoomSpawnStatusRequested", _status)
	EventBus.subscribe(&"DungeonBossGetRequested", _boss_get)
	EventBus.subscribe(&"EntityDamaged", _boss_damage)
	EventBus.subscribe(&"EntityDied", _boss_died)
	EventBus.subscribe(&"SpawnSummonerAIConfigureRequested", _configure_summoner)
	EventBus.subscribe(&"PlayerRoomChanged", _room_changed)
	EventBus.subscribe(&"CorpseBodyReleased", _released)
	EventBus.subscribe(&"SpaceBodyRemoved", _space_released)
	EventBus.subscribe(&"SpaceObstacleRemoved", _space_released)
	EventBus.subscribe(&"SpaceTilesChanged", _spawn_terrain_changed)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"EntityMoved", _moved)
	EventBus.subscribe(&"ProcessCompleted", _process_done)
	EventBus.subscribe(&"ProcessInterrupted", _process_interrupted)
	EventBus.subscribe(&"SpawnProcessTickAllowedRequested", _process_tick_allowed)
	EventBus.subscribe(&"ProcessStartAllowedRequested", _process_start_allowed)
	EventBus.subscribe(&"AIEntityTickAllowedRequested", _entity_tick_allowed)
	EventBus.subscribe(&"SpawnSnapshotValidateRequested", _validate_snapshot)
	EventBus.subscribe(&"SpaceMapConfigured", _reset)
	EventBus.subscribe(&"SpawnMapReconfigureCheckRequested", _map_check)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)

# Удаляет только ожидающие существа и таймеры очередей текущей карты.
# Уже созданные существа, снаряды и прочие процессы не затрагиваются.
# Доступно исключительно внутри синхронной операции перехода.
func cancel_queues_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy:
		return {"accepted":false, "error":"Спавн занят или нет операции перехода"}
	_busy = true
	var before: Dictionary = _rooms.duplicate(true)
	var expected: Dictionary = before.duplicate(true)
	var before_room := _current_room
	var room_ids: Array = _rooms.keys()
	room_ids.sort_custom(func(a, b): return str(a) < str(b))
	var pending_ids: Array = []
	var queued_count := 0
	var error := ""
	_transition_pending_ids.clear()
	for room in room_ids:
		var state: Dictionary = before[room]
		queued_count += state["queue"].size()
		var pid: StringName = state["pending"]
		if pid != &"":
			if _transition_pending_ids.has(pid):
				error = "Один таймер назначен нескольким очередям"
				break
			_transition_pending_ids[pid] = true
			pending_ids.append(pid)
	if error.is_empty():
		for pid in pending_ids:
			var process := {"id":pid, "found":false}
			EventBus.publish(&"ProcessGetRequested", process)
			if not process.get("found", false) or not process["data"].get("independent", false) or process["data"].get("entity_id", null) != &"":
				error = "Таймер очереди отсутствует или имеет неверного владельца"
				break
	if _rooms != before or _current_room != before_room or not SaveService.world_transition_operation_active(): error = "Состояние спавна изменилось во время проверки"
	if error.is_empty():
		for room in room_ids:
			var pid: StringName = before[room]["pending"]
			if pid == &"": continue
			var stop := {"id":pid, "reason":&"floor_transition", "accepted":false}
			EventBus.publish(&"ProcessInterruptRequested", stop)
			expected[room]["pending"] = &""
			var query := {"id":pid, "found":false}
			EventBus.publish(&"ProcessGetRequested", query)
			if not stop.get("accepted", false) or query.get("found", false) or _rooms != expected or _current_room != before_room or not SaveService.world_transition_operation_active():
				error = "Не удалось безопасно остановить таймер очереди"
				break
	if error.is_empty():
		for room in room_ids: _rooms[room]["queue"].clear()
	_transition_pending_ids.clear()
	_busy = false
	if not error.is_empty():
		SaveService.fail_world_transition(error)
		return {"accepted":false, "error":error}
	return {"accepted":true, "queue_count":queued_count, "cancelled_processes":pending_ids}

# Только уже размещённые существа, подтверждённые текущими записями спавна.
# Трупы, призванные существа и прочие сущности здесь не классифицируются.
func placed_actors_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy: return {"accepted":false, "error":"Спавн занят или нет операции перехода"}
	var result: Array = []
	for room in _rooms:
		var state: Dictionary = _rooms[room]
		if not state["queue"].is_empty() or state["pending"] != &"": return {"accepted":false, "error":"Сначала необходимо остановить очереди спавна"}
		for entity in state["placed"]:
			if result.has(entity): return {"accepted":false, "error":"Существо находится сразу в нескольких записях спавна"}
			result.append(entity)
	result.sort_custom(func(a, b): return str(a) < str(b))
	return {"accepted":true, "entities":result}

# Происхождение погибших существ подтверждается журналом создания спавна,
# а не только изменяемым компонентом. Призванные существа сюда не входят.
func dead_actors_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy: return {"accepted":false, "error":"Спавн занят или нет операции перехода"}
	for room in _rooms:
		if not _rooms[room]["queue"].is_empty() or _rooms[room]["pending"] != &"": return {"accepted":false, "error":"Сначала необходимо остановить очереди спавна"}
	var result: Array = []
	for entity in _created_entities:
		if CombatService.is_entity_dead(entity): result.append(entity)
	result.sort_custom(func(a, b): return str(a) < str(b))
	return {"accepted":true, "entities":result}

func _process_start_allowed(e: Dictionary) -> void:
	if _transition_pending_ids.has(e.get("id", null)): e["allowed"] = false

# Математическая граница нынешней формулы бюджета, а не таблица контента.
# Пустой обычный пул можно использовать только если остаток гарантированно нулевой.
func boss_uses_full_random_budget(depth: float) -> bool:
	if not is_finite(depth) or depth < 0.0 or depth > 1000.0: return false
	return FINAL_BOSS_WEIGHT_PER_LEVEL * (1 + floori(depth / 3.0)) >= 2.0 * depth

func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v))

func _valid_mob(mob: Variant) -> bool:
	if not mob is Dictionary or not (mob.get("id", null) is String or mob.get("id", null) is StringName) or str(mob["id"]).is_empty(): return false
	if not mob.get("species", null) is Dictionary or not (mob["species"].get("id", null) is String or mob["species"].get("id", null) is StringName) or str(mob["species"]["id"]).is_empty(): return false
	if not _number(mob.get("type_weight", null)) or float(mob["type_weight"]) < 0.0 or not _number(mob["species"].get("species_weight", null)) or float(mob["species"]["species_weight"]) < 0.0: return false
	if not mob.get("tags", null) is Array or not mob.get("base_stats", null) is Dictionary or not mob.get("growth_per_level", null) is Dictionary: return false
	if not mob.get("body_size", null) is int or mob["body_size"] not in _body_sizes: return false
	if not mob.get("min_depth", null) is int or mob["min_depth"] < 0: return false
	if mob.get("max_depth", null) != null and (not mob["max_depth"] is int or mob["max_depth"] < mob["min_depth"]): return false
	for key in STATS:
		if not _number(mob["base_stats"].get(key, null)) or not _number(mob["growth_per_level"].get(key, null)): return false
	var sum := float(mob["type_weight"]) + float(mob["species"]["species_weight"])
	var tag_ids: Dictionary = {}
	for tag in mob["tags"]:
		if not tag is Dictionary or not (tag.get("id", null) is String or tag.get("id", null) is StringName) or str(tag["id"]).is_empty() or not _number(tag.get("tag_weight", null)) : return false
		if tag_ids.has(str(tag["id"])): return false
		tag_ids[str(tag["id"])] = true
		sum += float(tag["tag_weight"])
	if tag_ids.has("large") and tag_ids.has("small"): return false
	var worst_sum := sum
	var options = mob.get("tag_options", [])
	if not options is Array or options.size() > 64: return false
	for option in options:
		if not option is Dictionary or not (option.get("id", null) is String or option.get("id", null) is StringName) or str(option["id"]).is_empty() or not _number(option.get("tag_weight", null)) or not _number(option.get("probability", null)) or float(option["probability"]) < 0 or float(option["probability"]) > 1: return false
		if float(option["probability"]) > 0.0: worst_sum += minf(0.0, float(option["tag_weight"]))
		var id := str(option["id"])
		if tag_ids.has(id): return false
		tag_ids[id] = true
	if tag_ids.has("large") and tag_ids.has("small"): return false
	var ai = mob.get("summoner_ai", null)
	if ai != null and (not ai is Dictionary or not _number(ai.get("wait_duration", null)) or float(ai["wait_duration"]) < 0.01 or float(ai["wait_duration"]) > 10000000.0 or absf(round(float(ai["wait_duration"]) / 0.01) * 0.01 - float(ai["wait_duration"])) > 0.000001): return false
	if str(mob["species"]["id"]) == "rat" and not mob.get("_tags_resolved", false) and not tag_ids.has("large") and not tag_ids.has("small"):
		if not _number(mob["species"].get("small_tag_weight", null)) : return false
		worst_sum += minf(0.0, float(mob["species"]["small_tag_weight"]))
	if str(mob["species"]["id"]) == "rat":
		for option in options:
			if str(option["id"]) == "large" and float(option["probability"]) > 0.0: return false
			if str(option["id"]) == "small" and not is_equal_approx(float(option["probability"]), _rat_small_probability): return false
	if mob.get("_tags_resolved", false):
		if not options.is_empty(): return false
		if tag_ids.has("large") and mob["body_size"] != int(_tag_rules.get("large", {}).get("body_size", 6)): return false
		if tag_ids.has("small") and mob["body_size"] != int(_tag_rules.get("small", {}).get("body_size", 2)): return false
	return is_finite(sum) and sum >= 0.01 and sum <= 1000000.0 and is_finite(worst_sum) and worst_sum >= 0.01

func _resolve_tags(source: Dictionary) -> Dictionary:
	var mob: Dictionary = source.duplicate(true)
	var fixed: Array = mob["tags"]
	var ids: Dictionary = {}
	for tag in fixed: ids[str(tag["id"])] = true
	var options: Array = mob.get("tag_options", []).duplicate(true)
	if str(mob["species"]["id"]) == "rat" and not ids.has("large") and not ids.has("small"):
		var explicit_small := false
		for option in options:
			if str(option["id"]) == "small": explicit_small = true
		if not explicit_small:
			options.append({"id":"small", "tag_weight":mob["species"]["small_tag_weight"], "probability":_rat_small_probability})
	for option in options:
		var roll := _rand_float()
		if roll < 0: return {}
		if roll < float(option["probability"]):
			var tag: Dictionary = option.duplicate(true)
			tag.erase("probability")
			fixed.append(tag)
			ids[str(tag["id"])] = true
	mob.erase("tag_options")
	mob["_tags_resolved"] = true
	if ids.has("large"): mob["body_size"] = int(_tag_rules.get("large", {}).get("body_size", 6))
	elif ids.has("small"): mob["body_size"] = int(_tag_rules.get("small", {}).get("body_size", 2))
	return mob

func _fail(event: Dictionary, message: String) -> void:
	event["accepted"] = false
	event["error"] = message

func _request(event: Dictionary) -> void:
	event["accepted"] = false
	for key in ["error", "units", "budget", "remaining_budget", "degraded", "level", "incomplete"]: event.erase(key)
	if _busy: return _fail(event, "Генерация спавна уже выполняется")
	var room_id = event.get("room", null)
	var player = event.get("player", null)
	var depth = event.get("depth", null)
	var entry = event.get("entry_tile", null)
	var offset = event.get("offset_cells", Vector2i.ZERO)
	var demo = event.get("demo_pool", false)
	var demo_tags = event.get("demo_tags", false)
	var demo_melee = event.get("demo_melee", false)
	if not demo_melee is bool or (demo_melee and (demo != true or demo_tags)): return _fail(event, "demo_melee требует demo_pool без demo_tags")
	if not demo_tags is bool or (demo_tags and demo != true): return _fail(event, "demo_tags доступен только с demo_pool")
	var delay = event.get("queue_delay", _default_delay)
	if delay != null and (not _number(delay) or float(delay) <= 0.0 or float(delay) > 10000000.0 or absf(round(float(delay) / 0.01) * 0.01 - float(delay)) > 0.000001): return _fail(event, "queue_delay должен быть положительным и кратным 0,01")
	if not room_id is StringName or room_id == &"" or not player is StringName or player == &"" or not _number(depth) or float(depth) < 0 or float(depth) > 1000 or not entry is Vector2i or not offset is Vector2i or not demo is bool:
		return _fail(event, "Нужны room, player, depth 0–1000, entry_tile и корректное смещение")
	if delay != null: event["queue_delay"] = float(delay)
	if absi(offset.x) > 512 or absi(offset.y) > 512: return _fail(event, "Смещение слишком велико")
	if _spawned.has(room_id): return _fail(event, "Спавн этой комнаты уже выполнен")
	var pool = _demo_pool.duplicate(true) if demo else event.get("pool", null)
	if demo and demo_tags:
		for example in pool: example["tag_options"] = _demo_tag_options.duplicate(true)
	if not pool is Array or pool.size() > 256: return _fail(event, "Нужен массив pool (или demo_pool=true)")
	var ids: Dictionary = {}
	for mob in pool:
		if not _valid_mob(mob) or str(mob.get("id", "")) == "final_ogre" or mob.get("_tags_resolved", false) or ids.has(str(mob["id"])): return _fail(event, "Некорректное или повторное определение моба")
		ids[str(mob["id"])] = true
	for mob in pool: mob.erase("_demo_melee")
	if demo_melee:
		for mob in pool: mob["_demo_melee"] = true
	_busy = true
	_prepare(event, room_id, player, float(depth), entry, offset, pool.duplicate(true))
	_busy = false

func _prepare(event: Dictionary, room_id: StringName, player: StringName, depth: float, entry: Vector2i, offset: Vector2i, pool: Array) -> void:
	var room := {"id": room_id, "found": false}
	EventBus.publish(&"RoomGetRequested", room)
	if not room["found"]: return _fail(event, "Комната не существует")
	var portal := {"room":room_id, "accepted":false, "protected":false}
	EventBus.publish(&"DungeonPortalRoomCheckRequested", portal)
	if not portal.get("accepted", false) or portal.get("protected", false): return _fail(event, "Спавн в комнате портала запрещён")
	var bounds := {"origin": room["data"]["origin_cell"] * _scale, "size": room["data"]["size_cells"] * _scale}
	if not Rect2i(bounds["origin"], bounds["size"]).has_point(entry): return _fail(event, "Тайл входа вне комнаты")
	var body := {"entity": player, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	if not body["found"] or not Rect2i(body["data"]["anchor"], Vector2i.ONE * body["data"]["size"]).has_point(entry):
		return _fail(event, "Тело игрока должно покрывать тайл входа")
	var tracking := {"found":false}
	EventBus.publish(&"DungeonFloorTrackingGetRequested", tracking)
	var mandatory := false
	if tracking.get("found", false) and tracking["data"].get("floor", 0) == 4:
		var selected = tracking["data"].get("boss_candidate", null)
		mandatory = selected == room_id
		if selected == null and room["data"].get("type", "") == "passage":
			var depth_query := {"room":room_id, "accepted":false}
			EventBus.publish(&"DungeonRoomDepthRequested", depth_query)
			if not depth_query.get("accepted", false): return _fail(event, "Не удалось проверить комнату босса")
			if depth_query["distance"] > 15: return _fail(event, "Дождитесь выбора комнаты босса")
		if mandatory:
			var depth_query := {"room":room_id, "accepted":false}
			EventBus.publish(&"DungeonRoomDepthRequested", depth_query)
			if not depth_query.get("accepted", false) or not is_equal_approx(depth, float(depth_query["depth"])): return _fail(event, "Глубина комнаты босса должна соответствовать отслеживанию этажа")
	_run(event, room_id, player, depth, entry, offset, pool, bounds, room["data"], mandatory)

func _rand_float() -> float:
	var q := {"accepted": false}
	EventBus.publish(&"RngFloatRequested", q)
	return float(q["value"]) if q["accepted"] else -1.0
func _rand_int(low: int, high: int) -> int:
	var q := {"min": low, "max": high, "accepted": false}
	EventBus.publish(&"RngIntRequested", q)
	return int(q["value"]) if q["accepted"] else -1

func _run(event: Dictionary, room_id: StringName, player: StringName, depth: float, entry: Vector2i, offset: Vector2i, pool: Array, bounds: Dictionary, room: Dictionary, mandatory_boss: bool = false) -> void:
	var draw := _rand_float()
	if draw < 0: return _fail(event, "RNG недоступен")
	var budget := float(depth) * (0.5 + 1.5 * draw)
	var remaining := budget
	var level := 1 + floori(depth / 3.0)
	var eligible: Array = []
	for mob in pool:
		if depth >= mob["min_depth"] and (mob.get("max_depth", null) == null or depth <= mob["max_depth"]): eligible.append(mob)
	var queue: Array = []
	if mandatory_boss:
		var boss: Dictionary = FINAL_BOSS.duplicate(true)
		boss["_tags_resolved"] = true
		var weight := FINAL_BOSS_WEIGHT_PER_LEVEL * level
		budget = maxf(budget, weight)
		remaining = budget - weight
		var stats := {}
		for key in STATS: stats[key] = float(boss["base_stats"][key]) + float(level - 1) * float(boss["growth_per_level"][key])
		queue.append({"definition":boss, "weight":weight, "stats":stats, "overload_requested":false})
	while remaining > 0.000000001:
		var affordable: Array = []
		for source in eligible:
			var mob := _resolve_tags(source)
			if mob.is_empty(): return _fail(event, "RNG недоступен при выборе тегов")
			if not _valid_mob(mob): return _fail(event, "Теги дали некорректный размер или вес")
			var weight: float = float(mob["type_weight"]) + float(mob["species"]["species_weight"])
			for tag in mob["tags"]: weight += float(tag["tag_weight"])
			weight *= level
			if weight > remaining + 0.000000001: continue
			var stats := {}
			for key in STATS:
				var n := float(mob["base_stats"][key]) + float(level - 1) * float(mob["growth_per_level"][key])
				if not is_finite(n): return _fail(event, "Переполнение характеристик")
				stats[key] = n
			affordable.append({"definition": mob, "weight": weight, "stats": stats})
		if affordable.is_empty(): break
		if queue.size() >= MAX_QUEUE: return _fail(event, "Превышен предел очереди (256); состав не создан")
		var selected := _rand_int(0, affordable.size() - 1)
		if selected < 0: return _fail(event, "RNG недоступен")
		var chosen: Dictionary = affordable[selected].duplicate(true)
		var overload_draw := _rand_float()
		if overload_draw < 0: return _fail(event, "RNG недоступен")
		chosen["overload_requested"] = overload_draw < 0.02
		queue.append(chosen)
		remaining = maxf(0.0, remaining - float(chosen["weight"]))

	# Use the same shuffled order for every attempt, so degradation tests are comparable.
	var anchors: Array = []
	var origin: Vector2i = bounds["origin"]
	var extent: Vector2i = bounds["size"]
	if not queue.is_empty():
		for y in range(origin.y, origin.y + extent.y):
			for x in range(origin.x, origin.x + extent.x): anchors.append(Vector2i(x,y) + offset * _scale)
	for i in range(anchors.size() - 1, 0, -1):
		var j := _rand_int(0, i)
		if j < 0: return _fail(event, "RNG недоступен")
		var swap = anchors[i]
		anchors[i] = anchors[j]
		anchors[j] = swap
	var protected_exits: Array = []
	if room.get("generated_cave",false):
		for room_exit in room.get("exits",[]):
			for tile in room_exit.get("tiles",[]):
				if tile is Vector2i and not protected_exits.has(tile): protected_exits.append(tile)
	var placements := _plan(queue, anchors, bounds, entry, true, true, [], [], protected_exits)
	var degraded: Array = []
	if placements.size() != queue.size():
		var no_radius := _plan(queue, anchors, bounds, entry, false, true, [], [], protected_exits)
		var no_gap := _plan(queue, anchors, bounds, entry, true, false, [], [], protected_exits)
		if no_radius.size() == queue.size():
			placements = no_radius
			degraded = ["entry_radius"]
		elif no_gap.size() == queue.size():
			placements = no_gap
			degraded = ["mob_gap"]
		else:
			placements = _plan(queue, anchors, bounds, entry, false, false, [], [], protected_exits)
			degraded = ["entry_radius", "mob_gap"]
	if mandatory_boss and placements.is_empty(): return _fail(event, "Не удалось разместить обязательного босса")
	var queued: Array = queue.slice(placements.size())
	var delay = event.get("queue_delay", null)
	if not queued.is_empty() and delay == null:
		return _fail(event, "Для непоместившихся мобов требуется явный queue_delay")

	var created: Array = []
	var units: Array = []
	for i in range(placements.size()):
		var member: Dictionary = queue[i]
		var def: Dictionary = member["definition"]
		var entity: StringName = _new_id(room_id)
		var tag_names: Array = []
		for tag in def["tags"]: tag_names.append(str(tag["id"]))
		var components := {&"stats": member["stats"], &"species": {"id": str(def["species"]["id"]), "tags": tag_names}, &"spawn": {"type_id": str(def["id"]), "level": level, "weight": member["weight"], "overload_requested": member["overload_requested"], "room": room_id, "required_weapon": "bow" if tag_names.has("archer") else null, "weapon_ready": false if tag_names.has("archer") else null, "summoner_ai_pending": tag_names.has("summoner") and not def.has("summoner_ai")}}
		if def.get("_demo_melee", false): components[&"spawn"]["demo_melee"] = true
		var create := {"entity": entity, "components": components, "accepted": false}
		EventBus.publish(&"EntityCreateRequested", create)
		if not create["accepted"]: return _rollback(event, room_id, created, "Не удалось создать моба")
		created.append(entity)
		if EntityRegistry.has_entity(entity): _created_entities[entity] = room_id
		var place := {"entity": entity, "anchor": placements[i], "size": def["body_size"], "room": bounds, "accepted": false}
		EventBus.publish(&"SpaceBodyPlaceRequested", place)
		if not place["accepted"]: return _rollback(event, room_id, created, "Не удалось разместить моба")
		var relation := {"a": player, "b": entity, "hostile": true, "accepted": false}
		EventBus.publish(&"DetectionHostilitySetRequested", relation)
		if not relation["accepted"] or not _apply_tags(entity, room_id, player, def) or not _live_at(entity, placements[i], def["body_size"]): return _rollback(event, room_id, created, "Не удалось применить теги или размещение изменилось")
		var effective := _effective_stats(entity)
		if effective.is_empty(): return _rollback(event, room_id, created, "Не удалось получить характеристики")
		units.append({"entity": entity, "type_id": str(def["id"]), "anchor": placements[i], "body_size": def["body_size"], "level": level, "weight": member["weight"], "stats": effective, "tags": tag_names.duplicate(), "overload_requested": member["overload_requested"]})
	# До фиксации повторно убеждаемся, что босс не погиб и не исчез в
	# синхронных обработчиках создания остальных существ и характеристик.
	if mandatory_boss and not _live_at(units[0]["entity"], units[0]["anchor"], 6): return _rollback(event, room_id, created, "Босс изменился до завершения спавна")
	_spawned[room_id] = true
	_rooms[room_id] = {"queue": queued.duplicate(true), "placed": created.duplicate(), "player": player, "entry": entry, "offset": offset, "bounds": bounds.duplicate(true), "degraded": degraded.duplicate(), "delay": float(delay) if delay != null else null, "level": level, "pending": &""}
	if mandatory_boss:
		_boss_state = {"room":room_id, "entity":units[0]["entity"], "status":"alive", "loadout":null}
	event["accepted"] = true
	event["budget"] = budget
	event["remaining_budget"] = remaining
	event["level"] = level
	event["units"] = units
	event["degraded"] = degraded
	event["queue_count"] = queued.size()
	EventBus.publish(&"RoomSpawned", {"room": room_id, "player": player, "depth": depth, "units": units.duplicate(true), "budget": budget, "remaining_budget": remaining, "degraded": degraded.duplicate(), "queue_count": queued.size()})

func _plan(queue: Array, anchors: Array, bounds: Dictionary, entry: Vector2i, use_radius: bool, use_gap: bool, occupied_rects: Array = [], ignored: Array = [], protected_exits: Array = []) -> Array:
	var result: Array = []
	var rects: Array = occupied_rects.duplicate()
	var exit_radius_squared := (3 * _scale) * (3 * _scale)
	for member in queue:
		var size: int = member["definition"]["body_size"]
		var found := false
		for anchor in anchors:
			var rect := Rect2i(anchor, Vector2i.ONE * size)
			if rect.has_point(entry): continue
			var near_exit := false
			for exit_tile in protected_exits:
				if rect.has_point(exit_tile):
					near_exit = true
					break
				var nearest_exit := Vector2i(clampi(exit_tile.x, rect.position.x, rect.end.x - 1), clampi(exit_tile.y, rect.position.y, rect.end.y - 1))
				if (nearest_exit - exit_tile).length_squared() <= exit_radius_squared:
					near_exit = true
					break
			if near_exit: continue
			var nearest := Vector2i(clampi(entry.x, rect.position.x, rect.end.x - 1), clampi(entry.y, rect.position.y, rect.end.y - 1))
			if use_radius and (nearest - entry).length_squared() <= exit_radius_squared: continue
			var blocked := false
			for other in rects:
				if rect.intersects(other):
					blocked = true
					break
				var dx: int = maxi(0, maxi(other.position.x - rect.end.x, rect.position.x - other.end.x))
				var dy: int = maxi(0, maxi(other.position.y - rect.end.y, rect.position.y - other.end.y))
				if use_gap and maxi(dx,dy) < _scale:
					blocked = true
					break
			if blocked: continue
			var fits := {"anchor": anchor, "size": size, "room": bounds, "ignore_entity": &"", "ignore_entities": ignored, "fits": false}
			EventBus.publish(&"SpaceBodyGroupFitsRequested" if not ignored.is_empty() else &"SpaceBodyFitsRequested", fits)
			if not fits["fits"]: continue
			result.append(anchor)
			rects.append(rect)
			found = true
			break
		if not found: return result
	return result

func _apply_tags(entity: StringName, room: StringName, player: StringName, definition: Dictionary) -> bool:
	var ids: Array = []
	for tag in definition["tags"]: ids.append(str(tag["id"]))
	for name in ["boss", "large"]:
		if not ids.has(name): continue
		var config: Dictionary = _tag_rules.get(name, {})
		for stat in STATS:
			var bonus: float = float(config.get("stat_add_all", 0)) + float(config.get("stat_add", {}).get(stat, 0))
			if bonus == 0: continue
			var mod := {"entity": entity, "modifier": {"id":"spawn_tag." + name + "." + stat, "target":"stat." + stat, "stage":"additive", "op":"add", "value":bonus}, "accepted":false}
			EventBus.publish(&"PipelineModifierRegisterRequested", mod)
			if not mod["accepted"]: return false
	# Заполняем только что созданные ресурсы после применения всех постоянных тегов.
	for resource in [&"HP", &"Stamina", &"MP"]:
		var get := {"entity":entity, "resource":resource, "found":false}
		EventBus.publish(&"ResourceGetRequested", get)
		if not get["found"]: return false
		var set := {"entity":entity, "resource":resource, "value":get["data"]["max"], "accepted":false}
		EventBus.publish(&"ResourceSetRequested", set)
		if not set["accepted"]: return false
	if ids.has("summoner") and definition.has("summoner_ai"):
		var config := {"entity":entity, "room":room, "target":player, "role":"summoner", "wait_duration":definition["summoner_ai"]["wait_duration"], "detected":false, "accepted":false}
		EventBus.publish(&"AIRegisterRequested", config)
		if not config["accepted"]: return false
	return true

func _effective_stats(entity: StringName) -> Dictionary:
	var stats := {}
	for stat in STATS:
		var query := {"entity":entity, "stat":StringName(stat), "found":false}
		EventBus.publish(&"StatGetRequested", query)
		if not query["found"] or not _number(query.get("value", null)): return {}
		stats[stat] = query["value"]
	return stats

func _live_at(entity: StringName, anchor: Vector2i, size: int) -> bool:
	var body := {"entity": entity, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	var allowed := {"entity": entity, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", allowed)
	return body["found"] and body["data"]["anchor"] == anchor and body["data"]["size"] == size and allowed["allowed"]

func _new_id(room: StringName) -> StringName:
	while true:
		_sequence += 1
		var id := StringName("spawn_%s_%d" % [str(room), _sequence])
		var q := {"entity": id, "found": false}
		EventBus.publish(&"EntityGetRequested", q)
		if not q["found"]: return id
	return &""

func _rollback(event: Dictionary, room: StringName, created: Array, reason: String) -> void:
	var remaining: Array = []
	for entity in created:
		var query := {"entity": entity, "found": false}
		EventBus.publish(&"EntityGetRequested", query)
		if not query["found"]: continue
		var remove := {"entity": entity, "accepted": false}
		EventBus.publish(&"EntityRemoveRequested", remove)
		if not remove["accepted"]: remaining.append(entity)
	if not remaining.is_empty():
		_spawned[room] = true
		event["incomplete"] = remaining
		EventBus.publish(&"RoomSpawnIncomplete", {"room": room, "entities": remaining.duplicate()})
	EventBus.publish(&"RoomSpawnFailed", {"room": room, "reason": reason})
	_fail(event, reason)

func _configure_summoner(event: Dictionary) -> void:
	event["accepted"] = false
	if _busy: return
	var entity = event.get("entity", null)
	var wait = event.get("wait_duration", null)
	if not entity is StringName or not _number(wait) or float(wait) < 0.01 or float(wait) > 10000000.0 or absf(round(float(wait) / 0.01) * 0.01 - float(wait)) > 0.000001: return
	_busy = true
	var comp := {"entity":entity, "component":&"spawn", "found":false}
	EventBus.publish(&"ComponentGetRequested", comp)
	if comp["found"] and comp["data"].get("summoner_ai_pending", false):
		var state_room: StringName = comp["data"].get("room", &"")
		if _rooms.has(state_room) and _rooms[state_room]["placed"].has(entity):
			var config := {"entity":entity, "room":state_room, "target":_rooms[state_room]["player"], "role":"summoner", "wait_duration":wait, "detected":false, "accepted":false}
			EventBus.publish(&"AIRegisterRequested", config)
			if config["accepted"]:
				comp["data"]["summoner_ai_pending"] = false
				var set := {"entity":entity, "component":&"spawn", "data":comp["data"], "accepted":false}
				EventBus.publish(&"ComponentSetRequested", set)
				if set["accepted"]: event["accepted"] = true
				else: EventBus.publish(&"AIUnregisterRequested", {"entity":entity})
	_busy = false

# Однократная фиксация экземпляров экипировки внутри snapshot-операции.
# При потере вещей повторное создание не разрешено.
func record_boss_loadout(entity: StringName, items: Dictionary) -> bool:
	if not SaveService.world_transition_operation_active() or not DungeonBossEquipmentService.authorizes_loadout_record(entity, items): return false
	if _boss_state.is_empty() or _boss_state.get("status", "") != "alive" or _boss_state.get("entity", null) != entity or _boss_state.get("loadout", null) != null: return false
	_boss_state["loadout"] = items.duplicate(true)
	return true

func _boss_get(event: Dictionary) -> void:
	event["found"] = not _boss_state.is_empty()
	if event["found"]: event["data"] = _boss_state.duplicate(true)

# CombatService помечает смерть до EntityDamaged и EntityDied. Регистрируем
# её уже на EntityDamaged, чтобы более позднее удаление трупа не стёрло факт.
func _boss_damage(event: Dictionary) -> void:
	_record_boss_death(event.get("entity", null))
func _boss_died(event: Dictionary) -> void:
	_record_boss_death(event.get("entity", null))
func _record_boss_death(entity: Variant) -> void:
	if _boss_state.is_empty() or _boss_state["status"] != "alive" or entity != _boss_state["entity"] or not CombatService.is_entity_dead(entity): return
	_boss_state["status"] = "defeated"
	EventBus.publish(&"DungeonBossDefeated", {"room":_boss_state["room"], "entity":entity})

func _status(event: Dictionary) -> void:
	var room = event.get("room", null)
	event["spawned"] = _spawned.has(room)
	if _rooms.has(room): event["data"] = _rooms[room].duplicate(true)
func _map_check(event: Dictionary) -> void:
	if _busy or not _created_entities.is_empty(): event["allowed"] = false
func _reset(_event: Dictionary) -> void:
	for room in _rooms:
		var pending: StringName = _rooms[room]["pending"]
		if pending != &"": EventBus.publish(&"ProcessInterruptRequested", {"id": pending, "reason": &"map_reset"})
	_boss_state.clear()
	_spawned.clear()
	_created_entities.clear()
	_rooms.clear()
	_current_room = &""
	_sequence = 0
func _collect(event: Dictionary) -> void:
	if _busy:
		event["errors"].append("Нельзя сохранять во время спавна")
		return
	event["sections"]["spawn"] = {"rooms": _spawned.duplicate(), "states": _rooms.duplicate(true), "created_entities":_created_entities.duplicate(), "boss":_boss_state.duplicate(true), "current_room": _current_room, "sequence": _sequence}
func _apply(event: Dictionary) -> void:
	_boss_state = event["sections"]["spawn"]["boss"].duplicate(true)
	_spawned = event["sections"]["spawn"]["rooms"].duplicate()
	_created_entities = event["sections"]["spawn"]["created_entities"].duplicate()
	_sequence = event["sections"]["spawn"]["sequence"]
	_rooms = event["sections"]["spawn"]["states"].duplicate(true)
	_current_room = event["sections"]["spawn"]["current_room"]
	_transition_pending_ids.clear()
	_busy = false

func _shuffle(bounds: Dictionary, offset: Vector2i) -> Array:
	var anchors: Array = []
	var origin: Vector2i = bounds["origin"]
	var extent: Vector2i = bounds["size"]
	for y in range(origin.y, origin.y + extent.y):
		for x in range(origin.x, origin.x + extent.x): anchors.append(Vector2i(x,y) + offset * _scale)
	for i in range(anchors.size() - 1, 0, -1):
		var j := _rand_int(0,i)
		if j < 0: return []
		var v = anchors[i]
		anchors[i] = anchors[j]
		anchors[j] = v
	return anchors

func _existing_rects(state: Dictionary, ignored: Array) -> Array:
	var q := {}
	EventBus.publish(&"SpaceBodiesGetRequested", q)
	var result: Array = []
	var bounds := Rect2i(state["bounds"]["origin"], state["bounds"]["size"])
	for id in q.get("bodies", {}):
		if id == state["player"] or ignored.has(id): continue
		var b: Dictionary = q["bodies"][id]
		var rect := Rect2i(b["anchor"], Vector2i.ONE * b["size"])
		if bounds.intersects(rect): result.append(rect)
	return result

func _queue_candidate(state: Dictionary) -> Variant:
	if state["queue"].is_empty(): return null
	var candidates := _shuffle(state["bounds"], state["offset"])
	var plan := _plan([state["queue"][0]], candidates, state["bounds"], state["entry"], not state["degraded"].has("entry_radius"), not state["degraded"].has("mob_gap"), _existing_rects(state, []))
	return plan[0] if not plan.is_empty() else null

func _attempt_schedule(room: StringName) -> void:
	if _busy or room != _current_room or not _rooms.has(room): return
	var state: Dictionary = _rooms[room]
	if state["queue"].is_empty() or state["pending"] != &"" or state["delay"] == null: return
	_busy = true
	if _queue_candidate(state) != null:
		_sequence += 1
		var process := StringName("spawn_delay:%s:%d" % [room, _sequence])
		state["pending"] = process
		var request := {"id": process, "duration": state["delay"], "entity": &"", "independent": true, "accepted": false}
		EventBus.publish(&"ProcessStartRequested", request)
		if not request["accepted"]:
			state["pending"] = &""
			EventBus.publish(&"SpawnQueueDelayFailed", {"room": room})
		else:
			EventBus.publish(&"SpawnQueueDelayStarted", {"room": room, "process": process, "duration": state["delay"]})
	_busy = false

func _process_tick_allowed(event: Dictionary) -> void:
	var id: StringName = event.get("process", &"")
	for room in _rooms:
		if _rooms[room]["pending"] == id and id != &"":
			event["allowed"] = bool(event.get("allowed", true)) and room == _current_room
			return

func _entity_tick_allowed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	for room in _rooms:
		if _rooms[room]["placed"].has(entity):
			event["allowed"] = bool(event.get("allowed", true)) and room == _current_room
			return

func _process_done(event: Dictionary) -> void:
	var id: StringName = event.get("process", &"")
	for room in _rooms:
		var state: Dictionary = _rooms[room]
		if state["pending"] != id or id == &"": continue
		state["pending"] = &""
		if _busy or room != _current_room or state["queue"].is_empty(): return
		_busy = true
		var anchor = _queue_candidate(state)
		if anchor == null:
			_busy = false
			EventBus.publish(&"SpawnQueueBlocked", {"room": room})
			return
		var member: Dictionary = state["queue"][0]
		var def: Dictionary = member["definition"]
		var entity := _new_id(room)
		var names: Array = []
		for tag in def["tags"]: names.append(str(tag["id"]))
		var components := {&"stats": member["stats"], &"species": {"id": str(def["species"]["id"]), "tags": names}, &"spawn": {"type_id": str(def["id"]), "level": state["level"], "weight": member["weight"], "overload_requested": member["overload_requested"], "room": room, "required_weapon": "bow" if names.has("archer") else null, "weapon_ready": false if names.has("archer") else null, "summoner_ai_pending": names.has("summoner") and not def.has("summoner_ai")}}
		if def.get("_demo_melee", false): components[&"spawn"]["demo_melee"] = true
		var create := {"entity": entity, "components": components, "accepted": false}
		EventBus.publish(&"EntityCreateRequested", create)
		if create["accepted"] and EntityRegistry.has_entity(entity): _created_entities[entity] = room
		var placed := {"entity": entity, "anchor": anchor, "size": def["body_size"], "room": state["bounds"], "accepted": false}
		if create["accepted"]: EventBus.publish(&"SpaceBodyPlaceRequested", placed)
		var relation := {"a": state["player"], "b": entity, "hostile": true, "accepted": false}
		if placed["accepted"]: EventBus.publish(&"DetectionHostilitySetRequested", relation)
		var tags_applied := false
		if relation["accepted"]: tags_applied = _apply_tags(entity, room, state["player"], def)
		if not create["accepted"] or not placed["accepted"] or not relation["accepted"] or not tags_applied or not _live_at(entity, anchor, def["body_size"]):
			if create["accepted"]:
				var remove := {"entity": entity, "accepted": false}
				EventBus.publish(&"EntityRemoveRequested", remove)
				var exists := {"entity": entity, "found": false}
				EventBus.publish(&"EntityGetRequested", exists)
				if not remove["accepted"] and exists["found"]:
					# Keep this very entity as placed and consume exactly one queue entry.
					state["queue"].pop_front()
					state["placed"].append(entity)
					EventBus.publish(&"RoomSpawnIncomplete", {"room": room, "entities": [entity]})
			_busy = false
			EventBus.publish(&"SpawnQueueBlocked", {"room": room})
			return
		state["queue"].pop_front()
		state["placed"].append(entity)
		EventBus.publish(&"SpawnQueueMobSpawned", {"room": room, "entity": entity, "anchor": anchor, "remaining": state["queue"].size(), "type_id": str(def["id"])})
		_busy = false
		_attempt_schedule(room)
		return

func _process_interrupted(event: Dictionary) -> void:
	var id: StringName = event.get("process", &"")
	for room in _rooms:
		if id != &"" and _rooms[room]["pending"] == id:
			_rooms[room]["pending"] = &""
			return

func _entity_removed(event: Dictionary) -> void:
	if not _boss_state.is_empty() and _boss_state["status"] == "alive" and event.get("entity", null) == _boss_state["entity"]:
		_boss_state["status"] = "lost"
		EventBus.publish(&"DungeonBossLost", _boss_state.duplicate(true))
	_created_entities.erase(event.get("entity", &""))
	_released(event)

func _released(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	for room in _rooms:
		_rooms[room]["placed"].erase(entity)
	if not _busy and _current_room != &"": _attempt_schedule(_current_room)

func _spawn_terrain_changed(event: Dictionary) -> void:
	if event.get("kind", 0) == 1 and not _busy and _current_room != &"": _attempt_schedule(_current_room)

func _space_released(_event: Dictionary) -> void:
	if not _busy and _current_room != &"": _attempt_schedule(_current_room)

func _moved(event: Dictionary) -> void:
	if not _busy and _current_room != &"": _attempt_schedule(_current_room)

func _room_changed(event: Dictionary) -> void:
	var next: StringName = event.get("room", &"")
	var previous := _current_room
	_current_room = next
	if _busy or next == previous or not _rooms.has(next): return
	var state: Dictionary = _rooms[next]
	if event.get("entity", &"") != state["player"]: return
	var player := {"entity": state["player"], "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", player)
	if not player["found"]: return
	state["entry"] = player["data"]["anchor"]
	_busy = true
	_reposition(next, state)
	_busy = false
	_attempt_schedule(next)

func _reposition(room: StringName, state: Dictionary) -> void:
	var members: Array = []
	var ids: Array = state["placed"].duplicate()
	for id in ids:
		var body := {"entity": id, "found": false}
		EventBus.publish(&"SpaceBodyGetRequested", body)
		if not body["found"]:
			EventBus.publish(&"RoomRepositionFailed", {"room": room, "reason": "missing_body"})
			return
		members.append({"definition": {"body_size": body["data"]["size"]}})
	if members.is_empty(): return
	var occupied := _existing_rects(state, ids)
	for attempt in range(4):
		var anchors := _shuffle(state["bounds"], state["offset"])
		var plan := _plan(members, anchors, state["bounds"], state["entry"], not state["degraded"].has("entry_radius"), not state["degraded"].has("mob_gap"), occupied, ids)
		if plan.size() != members.size(): continue
		var targets := {}
		for i in range(ids.size()): targets[ids[i]] = plan[i]
		var relocate := {"targets": targets, "accepted": false}
		EventBus.publish(&"SpaceBodiesRelocateRequested", relocate)
		if relocate["accepted"]:
			EventBus.publish(&"RoomRepositioned", {"room": room, "targets": targets})
			return
	EventBus.publish(&"RoomRepositionFailed", {"room": room, "reason": "no_placement", "positions_unchanged": true})

func _validate_snapshot(event: Dictionary) -> void:
	event["valid"] = false
	var sections = event.get("sections", null)
	if not sections is Dictionary or not sections.get("spawn", null) is Dictionary or not sections.get("rooms", null) is Dictionary or not sections.get("space", null) is Dictionary or not sections.get("entities", null) is Dictionary or not sections.get("processes", null) is Array: return
	var snap: Dictionary = sections["spawn"]
	if not snap.get("states", null) is Dictionary or not snap.get("rooms", null) is Dictionary or not snap.get("created_entities", null) is Dictionary or not snap.get("current_room", null) is StringName: return
	for entity in snap["created_entities"]:
		var room = snap["created_entities"][entity]
		if not entity is StringName or entity == &"" or not room is StringName or not snap["rooms"].has(room) or not sections["entities"].get(entity, null) is Dictionary: return
		var data: Dictionary = sections["entities"][entity]
		if not data.get(&"spawn", null) is Dictionary or data[&"spawn"].get("room", null) != room: return
	if not sections["rooms"].get("rooms", null) is Dictionary or not sections["space"].get("bodies", null) is Dictionary: return
	var boss = snap.get("boss", null)
	if not boss is Dictionary: return
	if boss.is_empty():
		var tracked = sections.get("dungeon_tracking", {})
		if tracked is Dictionary and tracked.get("floor", 0) == 4 and snap["states"].has(tracked.get("boss_candidate", null)): return
	if not boss.is_empty():
		var br = boss.get("room", null)
		var be = boss.get("entity", null)
		var status = boss.get("status", null)
		if not br is StringName or not be is StringName or be == &"" or status not in ["alive", "defeated", "lost"]: return
		if not boss.has("loadout"): return
		var loadout = boss["loadout"]
		if loadout != null:
			if not loadout is Dictionary or loadout.size() != 2 or not loadout.get("main", null) is StringName or loadout["main"] == &"" or not loadout.get("body", null) is StringName or loadout["body"] == &"" or loadout["main"] == loadout["body"]: return
			var item_instances = sections.get("items", {}).get("instances", {})
			for pair in [["main", &"hammer_simple"], ["body", &"armor_iron_body"]]:
				var item = item_instances.get(loadout[pair[0]], null)
				if item != null and (not item is Dictionary or item.get("base_id", null) != pair[1]): return
		if sections.get("dungeon_tracking", {}).get("floor", 0) != 4 or sections["dungeon_tracking"].get("boss_candidate", null) != br or not snap["states"].has(br) or not snap["rooms"].has(br): return
		var entity = sections["entities"].get(be, null)
		if status == "alive":
			if not entity is Dictionary or snap["created_entities"].get(be, null) != br or not snap["states"][br].get("placed", []).has(be) or sections.get("combat", {}).get("dead", {}).has(be): return
		if entity != null:
			if not entity is Dictionary or not entity.get(&"spawn", null) is Dictionary or entity[&"spawn"].get("type_id", "") != "final_ogre" or entity[&"spawn"].get("room", null) != br: return
			if status == "defeated" and not sections.get("combat", {}).get("dead", {}).has(be): return
		if status == "lost" and entity != null: return
	var current: StringName = snap["current_room"]
	var pending_seen: Dictionary = {}
	var all_placed: Dictionary = {}
	for room in snap["states"]:
		if not room is StringName or not snap["rooms"].has(room) or not sections["rooms"]["rooms"].has(room): return
		var st = snap["states"][room]
		if not st is Dictionary or not st.get("queue", null) is Array or st["queue"].size() > MAX_QUEUE or not st.get("placed", null) is Array or not st.get("player", null) is StringName or st["player"] == &"" or not st.get("entry", null) is Vector2i or not st.get("offset", null) is Vector2i or not st.get("bounds", null) is Dictionary or not st.get("degraded", null) is Array or not st.get("level", null) is int or st["level"] < 1 or not st.get("pending", null) is StringName: return
		var saved_room = sections["rooms"]["rooms"][room]
		if not saved_room is Dictionary or not saved_room.get("origin_cell", null) is Vector2i or not saved_room.get("size_cells", null) is Vector2i: return
		if st["bounds"].get("origin", null) != saved_room["origin_cell"] * _scale or st["bounds"].get("size", null) != saved_room["size_cells"] * _scale: return
		if not Rect2i(st["bounds"]["origin"], st["bounds"]["size"]).has_point(st["entry"]) or absi(st["offset"].x) > 512 or absi(st["offset"].y) > 512: return
		if st["degraded"].size() > 2: return
		for name in st["degraded"]:
			if name not in ["entry_radius", "mob_gap"] or st["degraded"].count(name) != 1: return
		var delay = st.get("delay", null)
		if delay != null and (not _number(delay) or float(delay) <= 0.0 or float(delay) > 10000000 or absf(round(float(delay) / 0.01) * 0.01 - float(delay)) > 0.000001): return
		if not st["queue"].is_empty() and delay == null: return
		for member in st["queue"]:
			if not member is Dictionary or not _valid_mob(member.get("definition", null)) or not _number(member.get("weight", null)) or member["weight"] <= 0 or not member.get("stats", null) is Dictionary or not member.get("overload_requested", null) is bool: return
			var definition: Dictionary = member["definition"]
			var expected_weight := float(definition["type_weight"]) + float(definition["species"]["species_weight"])
			for tag in definition["tags"]: expected_weight += float(tag["tag_weight"])
			expected_weight *= st["level"]
			if not is_equal_approx(expected_weight, float(member["weight"])): return
			for key in STATS:
				if not _number(member["stats"].get(key, null)): return
				var expected_stat := float(definition["base_stats"][key]) + float(st["level"] - 1) * float(definition["growth_per_level"][key])
				if not is_finite(expected_stat) or not is_equal_approx(expected_stat, float(member["stats"][key])): return
		var seen: Dictionary = {}
		for entity in st["placed"]:
			if not entity is StringName or seen.has(entity) or snap["created_entities"].get(entity, null) != room or not sections["entities"].has(entity) or not sections["space"]["bodies"].has(entity): return
			if all_placed.has(entity): return
			if sections.get("combat", {}).get("dead", {}).has(entity): return
			seen[entity] = true
			all_placed[entity] = true
			if not sections["entities"][entity] is Dictionary: return
			var component = sections["entities"][entity].get(&"spawn", null)
			if not component is Dictionary or component.get("room", null) != room: return
		var pending: StringName = st["pending"]
		if pending != &"":
			if st["queue"].is_empty() or pending_seen.has(pending): return
			pending_seen[pending] = true
			var found := false
			for process in sections["processes"]:
				if process is Dictionary and process.get("id", null) == pending:
					if not process.get("independent", false) or process.get("entity_id", null) != &"" or not process.get("duration_steps", null) is int or absf(float(process["duration_steps"]) * 0.01 - float(delay)) > 0.000001: return
					found = true
			if not found: return
	event["valid"] = true
