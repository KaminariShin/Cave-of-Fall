extends Node
## Проверка одной предложенной позиции, без создания объектов или расхода ГСЧ.
## Консервативно: каждый размеченный незапечатанный проход проверяется по одному положению 4×4.
const BODY := 4
const MAX_AREA := 16384

func _ready() -> void:
	EventBus.subscribe(&"DungeonChestPositionPreflightRequested", _preflight)

func _fail(e: Dictionary, error: String) -> void:
	e["error"] = error

func _tile(p: Vector2i) -> Dictionary:
	var q := {"tile":p}
	EventBus.publish(&"SpaceTileGetRequested", q)
	return q

func _seed(exit: Dictionary) -> Variant:
	if not exit.get("x", null) is int or not exit.get("y", null) is int: return null
	var p := Vector2i(exit["x"], exit["y"])
	match str(exit.get("dirOut", "")):
		"west": p.x += 1
		"east": p.x -= BODY
		"north": p.y += 1
		"south": p.y -= BODY
		_: return null
	return p

func _preflight(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["error", "interaction_anchor", "connected_exits_checked", "open_exits_checked"]: e.erase(key)
	var room_id = e.get("room", null)
	var chest = e.get("tile", null)
	if not room_id is StringName or room_id == &"" or not chest is Vector2i: return _fail(e, "Нужны ID комнаты и тайл")
	var rq := {"id":room_id, "found":false}
	EventBus.publish(&"RoomGetRequested", rq)
	if not rq.get("found", false): return _fail(e, "Комната не найдена")
	var room: Dictionary = rq["data"]
	var bounds := Rect2i(room["origin_cell"] * 4, room["size_cells"] * 4)
	if bounds.size.x * bounds.size.y > MAX_AREA: return _fail(e, "Комната превышает лимит проверки")
	if not bounds.has_point(chest): return _fail(e, "Тайл вне комнаты")
	var existing = e.get("existing_object", null)
	if existing != null:
		if not existing is StringName or existing == &"": return _fail(e, "Некорректный ID объекта")
		var object := {"object":existing, "found":false}
		EventBus.publish(&"ObjectGetRequested", object)
		if not object.get("found", false) or object["data"].get("type", "") != "chest" or object["data"].get("room", null) != room_id or object["data"].get("tile", null) != chest: return _fail(e, "Существующий сундук не совпадает с позицией")
	var q := _tile(chest)
	if not q.get("in_bounds", false) or q.get("kind", 0) != 1 or q.get("passage", false) or q.get("occupant", null) != null or q.get("obstacle", null) != existing: return _fail(e, "Тайл занят, не является полом или находится в проходе")
	var loot := {"tile":chest}
	EventBus.publish(&"LootGetRequested", loot)
	if not loot.get("items", {}).is_empty(): return _fail(e, "На тайле лежат предметы")
	# Предварительное, намеренно узкое определение «возле стены»: соседство
	# по стороне с непроходимым тайлом, а не диагональ или произвольный радиус.
	var wall := false
	for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
		var adjacent := _tile(chest + d)
		if not adjacent.get("in_bounds", false) or adjacent.get("kind", 0) == 0: wall = true
	if existing == null and not wall: return _fail(e, "Тайл не примыкает к стене")
	var connected: Array = []
	var pending: Array = []
	for ex in room.get("exits", []):
		if not ex is Dictionary or not ex.get("connected", null) is bool or not ex.get("sealed", null) is bool: return _fail(e, "Некорректные данные прохода")
		if ex["sealed"]: continue
		var seed = _seed(ex)
		if not seed is Vector2i: return _fail(e, "Некорректный размеченный проход")
		if ex["connected"]: connected.append(seed)
		else: pending.append(seed)
	# Требуется связанный проход: только будущий выход не доказывает доступ
	# игрока из уже существующей части подземелья.
	if connected.is_empty(): return _fail(e, "Нет связанного прохода для проверки доступности")
	var extra = e.get("additional_exit", null)
	if extra != null:
		if not extra is Dictionary: return _fail(e, "Некорректный дополнительный проход")
		var extra_seed = _seed(extra)
		if not extra_seed is Vector2i or not bounds.encloses(Rect2i(extra_seed, Vector2i.ONE * BODY)): return _fail(e, "Дополнительный проход вне комнаты")
		pending.append(extra_seed)
	var seeds: Array = connected + pending
	# Игрок сам является подвижным телом, а не постоянной стеной.
	# Исключаем только его при поиске пути, но затем проверяем, что его
	# реальная позиция принадлежит той же достижимой области. Прочие тела
	# и занятость клетки будущего сундука по-прежнему учитываются.
	var ignored: StringName = &""
	var player_anchor: Variant = null
	var mode := {}
	EventBus.publish(&"GameModeGetRequested", mode)
	var player = mode.get("entity", null)
	if player is StringName and player != &"":
		var body := {"entity":player,"found":false}
		EventBus.publish(&"SpaceBodyGetRequested", body)
		if body.get("found",false) and body.get("data",{}).get("size",null) == BODY:
			var p = body["data"].get("anchor",null)
			if p is Vector2i and bounds.encloses(Rect2i(p,Vector2i.ONE*BODY)):
				ignored = player
				player_anchor = p
	var body_bounds := {"origin":bounds.position, "size":bounds.size}
	var queue: Array = []
	var seen := {}
	var fit := {"anchor":seeds[0], "size":BODY, "room":body_bounds, "ignore_entity":ignored}
	EventBus.publish(&"SpaceBodyFitsRequested", fit)
	if not fit.get("fits", false) or Rect2i(seeds[0], Vector2i.ONE * BODY).has_point(chest): return _fail(e, "Первый проход недоступен телу 4×4")
	queue.append(seeds[0])
	seen[seeds[0]] = true
	var interaction: Variant = null
	var index := 0
	while index < queue.size():
		var anchor: Vector2i = queue[index]
		index += 1
		if interaction == null and _adjacent(anchor, chest): interaction = anchor
		for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
			var next: Vector2i = anchor + d
			if seen.has(next) or not bounds.encloses(Rect2i(next, Vector2i.ONE * BODY)) or Rect2i(next, Vector2i.ONE * BODY).has_point(chest): continue
			seen[next] = true
			var test := {"anchor":next, "size":BODY, "room":body_bounds, "ignore_entity":ignored}
			EventBus.publish(&"SpaceBodyFitsRequested", test)
			if test.get("fits", false): queue.append(next)
	if interaction == null: return _fail(e, "Нет достижимой позиции взаимодействия 4×4")
	# seen включает и неудачные запросы fits, поэтому использовать только queue.
	var reachable := {}
	for anchor in queue: reachable[anchor] = true
	for seed in seeds:
		if not reachable.has(seed): return _fail(e, "Не все размеченные проходы достижимы после размещения")
	if player_anchor != null and not reachable.has(player_anchor): return _fail(e, "Позиция игрока недоступна после размещения")
	e["accepted"] = true
	e["interaction_anchor"] = interaction
	e["connected_exits_checked"] = connected.size()
	e["open_exits_checked"] = seeds.size()

func _adjacent(a: Vector2i, p: Vector2i) -> bool:
	return ((p.x == a.x - 1 or p.x == a.x + BODY) and p.y >= a.y and p.y < a.y + BODY) or ((p.y == a.y - 1 or p.y == a.y + BODY) and p.x >= a.x and p.x < a.x + BODY)
