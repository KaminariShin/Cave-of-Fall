extends Control

var status: Label
var displayed_time := 0.0
var displayed_action := "нет"

func _ready() -> void:
	EventBus.publish(&"ControlledEntityRequested", {"entity": &"player"})
	EventBus.subscribe(&"Tick", _on_tick_event)
	EventBus.subscribe(&"ActionStarted", _on_started_event)
	EventBus.subscribe(&"ActionCompleted", _on_ended_event)
	EventBus.subscribe(&"ActionInterrupted", _on_ended_event)
	var column := VBoxContainer.new()
	column.position = Vector2(35, 30)
	column.add_theme_constant_override("separation", 15)
	add_child(column)
	var title := Label.new()
	title.text = "Time Driver: тестовая сцена"
	column.add_child(title)
	status = Label.new()
	column.add_child(status)
	var wait_button := Button.new()
	wait_button.text = "Ожидать 1 секунду"
	wait_button.pressed.connect(func(): EventBus.publish(&"ActionStartRequested", {"entity": &"player", "action": &"wait", "duration": 1.0}))
	column.add_child(wait_button)
	var attack_button := Button.new()
	attack_button.text = "Удар 0,7 секунды"
	attack_button.pressed.connect(func(): EventBus.publish(&"ActionStartRequested", {"entity": &"player", "action": &"attack"}))
	column.add_child(attack_button)
	var interrupt_button := Button.new()
	interrupt_button.text = "Прервать: пошатывание 0,2 секунды"
	interrupt_button.pressed.connect(func(): EventBus.publish(&"ActionInterruptRequested", {"entity": &"player", "action": &"stagger"}))
	column.add_child(interrupt_button)
	var hint := Label.new()
	hint.text = "Время идёт только во время действия."
	column.add_child(hint)

func _process(_delta: float) -> void:
	status.text = "Время: %.2f с   Действие: %s" % [displayed_time, displayed_action]

func _on_tick_event(event: Dictionary) -> void:
	displayed_time = event["game_time"]

func _on_started_event(event: Dictionary) -> void:
	if event["entity"] == &"player":
		displayed_action = str(event["action"])

func _on_ended_event(event: Dictionary) -> void:
	if event["entity"] == &"player":
		displayed_action = "нет"
