extends Control
## Playable integration demo. All balance here is demonstration-only.
const HERO := &"demo_hero"
const RAT := &"demo_rat"
const CHEST := &"demo_chest"
const ROOM := &"start"
const ATTACK := &"weapon_strike"
const BOW_SHOT := &"bow_shot"
const STRIKE := "demo_player_sword_thrust"
const DEMO_STRIKES := {"sword_simple_variant":"demo_player_sword_thrust", "hammer_simple_variant":"demo_player_hammer_slam"}
const STEP_PX := 20.0
const MAP_SIZE := Vector2i(640,640)
# Stable by default; change in the inspector or tests to reproduce generated runs.
@export var generation_seed: int = 42
# Real shield base used by the tutorial inventory. The demo defaults to small;
# deterministic gameplay harnesses can select a defensive build before _ready.
@export var starting_shield_base: StringName = &"shield_small"
@export var starting_armor_base: StringName = &""
const PICKUP_TIME := 0.35
# Исходный проект читает PNG напрямую; импортированные ресурсы — запасной
# путь для экспорта (экспорт пока не проверен).
var _ui_frame: Texture2D
var _ui_frame_image: Image
var _ui_parchment: Texture2D
var _ui_slot: Texture2D
var _inventory_art: Texture2D
var _equipment_base: Texture2D
var _inventory_highlight: Texture2D
var _item_icons: Dictionary = {}
var _ui_vials: Array[Texture2D] = []
var _journal_book: Texture2D
var _journal_turn_right: Array[Texture2D] = []
var _journal_turn_left: Array[Texture2D] = []
const JOURNAL_LIMIT := 300
const JOURNAL_LINES_PER_PAGE := 17
var journal_entries: Array = []
var journal_open := false
var journal_page := 0 # Номер разворота, от старых к новым.
var _journal_lines: Array = []
var _journal_dirty := true
var _journal_turn_time := 0.0
var _journal_turn_direction := 0
var _floor_atlas: Texture2D
var _wall_atlas: Texture2D
var _floor_memory_atlas: Texture2D
var _wall_memory_atlas: Texture2D
# Снимок только наблюдённых тайлов текущего этажа, не источник игровой логики.
var _map_memory: Dictionary = {}
const MEM_FLOOR := 1
const MEM_PASSAGE := 2
const MEM_CHEST := 4
const MEM_CHEST_OPEN := 8
const MEM_STAIRS := 16
const MEM_PORTAL := 32
const MEM_LOOT := 64
var _hero_sprite: Texture2D
var _enemy_sprite: Texture2D
var _ogre_sprite: Texture2D
var _rat_sprite: Texture2D
# Варианты глубины — цветовые обработки одного набора, не отдельные биомы.
const FLOOR_TINTS := [Color(1.0,1.0,1.0),Color(0.80,0.95,1.13),Color(0.82,1.09,0.82),Color(1.10,0.78,0.89)]
const EQUIPMENT_SLOTS := ["main", "off", "head", "body", "hands", "belt", "legs", "feet", "ring1", "ring2", "amulet", "cloak"]
const EQUIPMENT_LABELS := ["Основная рука", "Вторая рука", "Голова", "Тело", "Кисти", "Пояс", "Ноги", "Ступни", "Кольцо 1", "Кольцо 2", "Амулет", "Плащ"]
# Удар и щит направляются мышью с непрерывным углом.
var attack_direction := Vector2.RIGHT
# Выбор направления — временное состояние интерфейса, а не игровое действие.
var _direction_action := "" # attack / block / пусто
var facing := Vector2i.RIGHT:
	set(value):
		facing = value
		attack_direction = Vector2(value).normalized()
var message := "Найдите крысу. Время идёт только во время ваших действий.":
	set(value):
		message = value
		if not value.is_empty(): _journal_record(value)
var current_room: StringName = ROOM
var initialized := false
var inventory_open := false
var inventory_page := 0 # UI navigation only; restored snapshots return to page one.
var equipment_view := false
var identify_mode := false
var inspect_mode := false
var inspect_item: StringName = &""
var inspect_page := 0
const INSPECTION_PAGE_SIZE := 13
var equipment_page := 0
# Черновая прогрессия: простые заменяемые значения, не итоговый баланс.
const PROGRESSION_STATS := [&"CON", &"STR", &"DEX", &"INT", &"WIS", &"PER"]
const XP_PER_KILL := 25
const XP_PER_LEVEL_FACTOR := 100
const POINTS_PER_LEVEL := 2
const MAX_HERO_LEVEL := 1000
var hero_level := 1
var hero_xp := 0
var hero_points := 0
var stats_view := false
var _stat_allocation_busy := false
var _twohand_queue: Dictionary = {}
var _twohand_busy := false
var _drop_pick: Dictionary = {} # UI cursor; saved action keeps the selected tile.
var _drop_mode := false
var _pickup_open := false
var _pickup_chest: StringName = &""
var _pickup_page := 0
var _pickup_queue: Array = []
var _pickup_queue_running := false
var _pickup_inflight: StringName = &""
var _pickup_skipped := 0
var _pickup_starting := false
const PICKUP_PAGE_SIZE := 7
var is_dead := false
var is_won := false
var pending_attack := false
var attack_tiles: Array = []
# Короткий визуальный след уже наступившего момента удара, не окно блока.
var _strike_flashes: Dictionary = {}
const STRIKE_FLASH_MS := 150
# Удержание — только состояние ввода, в сохранение не записывается.
var _mouse_hold_down := false
var _mouse_hold_active := false
var _mouse_hold_elapsed := 0.0
var _mouse_hold_point := Vector2.ZERO
var _mouse_hold_attempted := false
const MOUSE_HOLD_DELAY := 0.22
var _held_keys: Array[int] = []
var _hold_blocked := false
var _accumulator := 0.0
var _spawn_errors: Dictionary = {}
var _spawn_generation := 0
var _spawning := false
var _restart_button: Button
var _fresh_available := false

func _load_art(path: String) -> Texture2D:
	# Исходный PNG не зависит от промежуточного .godot/imported, который может
	# отсутствовать после восстановления workspace или при изолированном тесте.
	if FileAccess.file_exists(path):
		var raw := FileAccess.get_file_as_bytes(path)
		var img := Image.new()
		if not raw.is_empty() and img.load_png_from_buffer(raw) == OK and not img.is_empty():
			return ImageTexture.create_from_image(img)
	if ResourceLoader.exists(path,"Texture2D"):
		var texture = ResourceLoader.load(path,"Texture2D")
		if texture is Texture2D: return texture
	push_error("Не удалось загрузить графику: " + path)
	return null

func _ready() -> void:
	_ui_frame = _load_art("res://assets/ui_fragments_frame.png")
	_ui_parchment = _load_art("res://assets/ui_parchment.png")
	_ui_slot = _load_art("res://assets/ui_slot.png")
	_inventory_art = _load_art("res://assets/inv_panel_full.png")
	_equipment_base = _load_art("res://assets/base.png")
	_inventory_highlight = _load_art("res://assets/inv_cell_highlight.png")
	for icon_id in ["sword_simple","hammer_simple","bow_simple","staff_simple","shield_small","shield_medium","shield_large","armor_cloth_body","armor_leather_body","armor_iron_body","potion_hp","potion_stamina","potion_mana","antidote","bandage","unknown"]:
		_item_icons[icon_id] = _load_art("res://assets/item_icons/"+icon_id+".png")
	_ui_vials = [_load_art("res://assets/ui_vial_hp.png"), _load_art("res://assets/ui_vial_stamina.png"), _load_art("res://assets/ui_vial_mana.png")]
	_journal_book = _load_art("res://assets/journal_book.png")
	for i in range(3):
		_journal_turn_right.append(_load_art("res://assets/journal_turn_r2l_%d.png" % i))
		_journal_turn_left.append(_load_art("res://assets/journal_turn_l2r_%d.png" % i))
	if journal_entries.is_empty(): _journal_record(message)
	if _ui_frame != null: _ui_frame_image = _ui_frame.get_image()
	_floor_atlas = _load_art("res://assets/floor_tiles.png")
	_wall_atlas = _load_art("res://assets/wall_tiles.png")
	_floor_memory_atlas = _load_art("res://assets/floor_memory.png")
	_wall_memory_atlas = _load_art("res://assets/wall_memory.png")
	_hero_sprite = _load_art("res://assets/hero_sprite.png")
	_enemy_sprite = _load_art("res://assets/enemy_sprite.png")
	_ogre_sprite = _load_art("res://assets/ogre_sprite.png")
	_rat_sprite = _load_art("res://assets/rat_sprite.png")
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	set_process_unhandled_key_input(true)
	for name in [&"FogVisibilityChanged", &"SpaceTilesChanged", &"SpacePassageChanged", &"ObjectCreated", &"ObjectRemoved", &"ChestOpened", &"LootItemDropped", &"LootItemPickedUp"]:
		EventBus.subscribe(name, _memory_changed)
	for pair in [[&"WeaponStrikeMidpoint", _strike_midpoint], [&"BowShotReleased", _bow_released], [&"ActionCompleted", _action_completed], [&"ActionInterrupted", _action_interrupted], [&"MovementStarted", _movement_started], [&"MovementCompleted", _movement_finished], [&"MovementInterrupted", _movement_finished], [&"MovementPathStopped", _movement_path_stopped], [&"MenuTransitionCompleted", _menu_completed], [&"EntityDied", _entity_died], [&"DemoProgressionGetRequested", _progression_get], [&"EntityDamaged", _damaged], [&"ChestOpened", _chest_opened], [&"ChestTakeCompleted", _chest_take_completed], [&"ChestTakeFailed", _chest_take_failed], [&"ChestTakeInterrupted", _chest_take_failed], [&"LootItemDropped", _loot_dropped], [&"LootInventoryDropFailed", _inventory_drop_failed], [&"LootInventoryDropInterrupted", _inventory_drop_failed], [&"LootItemPickedUp", _picked_up], [&"LootPickupFailed", _pickup_failed], [&"LootPickupInterrupted", _pickup_failed], [&"ConsumableUseCompleted", _consumable_completed], [&"ItemLearningIdentified", _identify_completed], [&"ItemLearningIdentifyFailed", _identify_failed], [&"ItemLearningIdentifyInterrupted", _identify_failed], [&"ItemUnequipped", _twohand_changed], [&"ItemEquipped", _twohand_changed], [&"EquipmentActionFailed", _twohand_failed], [&"PlayerRoomChanged", _room_changed], [&"SpaceMapConfigured", _spawn_map_reset], [&"DemoMeleeSetupFailed", _enemy_setup_failed], [&"RoomGenerationFailed", _room_generation_failed], [&"RoomGenerationIncomplete", _room_generation_incomplete], [&"DungeonStairPlacementFailed", _stair_failed], [&"DungeonPortalPlacementFailed", _portal_failed], [&"DungeonBossAutoSpawnFailed", _boss_spawn_failed], [&"RoomSpawned", _boss_spawned], [&"DungeonBossEquipmentAutoFailed", _boss_equipment_failed], [&"DungeonBossMeleeAIFailed", _boss_ai_failed], [&"DungeonNormalChestAutoFailed", _normal_chest_failed], [&"DungeonBossChestAutoFailed", _boss_chest_failed], [&"DungeonBossChestAutoCreated", _boss_chest_created], [&"DungeonDescended", _descended], [&"DungeonDescentFailed", _descent_failed], [&"RunStatisticsFinished", _run_finished], [&"SnapshotCollectRequested", _snapshot_collect], [&"SnapshotApplyRequested", _snapshot_apply], [&"GameDemoSnapshotValidateRequested", _snapshot_validate], [&"SessionDeleteOnDeathCheckRequested", _delete_guard]]:
		EventBus.subscribe(pair[0], pair[1])
	initialized = _setup()
	_restart_button = Button.new()
	_restart_button.text = "Новая игра"
	_restart_button.size = Vector2(190,36)
	_restart_button.visible = false
	_restart_button.pressed.connect(_new_game)
	add_child(_restart_button)
	if initialized:
		var baseline := SaveService.capture_demo_fresh_baseline()
		_fresh_available = baseline.get("accepted",false)
		if not _fresh_available: message = "Новый забег недоступен: " + str(baseline.get("error",""))
	else: message = "Ошибка настройки сцены. См. вывод Godot."
	queue_redraw()

func _exit_tree() -> void:
	_ask(&"DungeonNormalChestAutoEnableRequested", {"enabled":false})
	SaveService.clear_demo_fresh_baseline()
	for name in [&"FogVisibilityChanged", &"SpaceTilesChanged", &"SpacePassageChanged", &"ObjectCreated", &"ObjectRemoved", &"ChestOpened", &"LootItemDropped", &"LootItemPickedUp"]:
		EventBus.unsubscribe(name, _memory_changed)
	for pair in [[&"ActionCompleted", _action_completed], [&"ActionInterrupted", _action_interrupted], [&"MovementStarted", _movement_started], [&"MovementCompleted", _movement_finished], [&"MovementInterrupted", _movement_finished], [&"MovementPathStopped", _movement_path_stopped], [&"MenuTransitionCompleted", _menu_completed], [&"EntityDied", _entity_died], [&"DemoProgressionGetRequested", _progression_get], [&"EntityDamaged", _damaged], [&"ChestOpened", _chest_opened], [&"ChestTakeCompleted", _chest_take_completed], [&"ChestTakeFailed", _chest_take_failed], [&"ChestTakeInterrupted", _chest_take_failed], [&"LootItemDropped", _loot_dropped], [&"LootInventoryDropFailed", _inventory_drop_failed], [&"LootInventoryDropInterrupted", _inventory_drop_failed], [&"LootItemPickedUp", _picked_up], [&"LootPickupFailed", _pickup_failed], [&"LootPickupInterrupted", _pickup_failed], [&"ConsumableUseCompleted", _consumable_completed], [&"ItemLearningIdentified", _identify_completed], [&"ItemLearningIdentifyFailed", _identify_failed], [&"ItemLearningIdentifyInterrupted", _identify_failed], [&"ItemUnequipped", _twohand_changed], [&"ItemEquipped", _twohand_changed], [&"EquipmentActionFailed", _twohand_failed], [&"PlayerRoomChanged", _room_changed], [&"SpaceMapConfigured", _spawn_map_reset], [&"DemoMeleeSetupFailed", _enemy_setup_failed], [&"RoomGenerationFailed", _room_generation_failed], [&"RoomGenerationIncomplete", _room_generation_incomplete], [&"DungeonStairPlacementFailed", _stair_failed], [&"DungeonPortalPlacementFailed", _portal_failed], [&"DungeonBossAutoSpawnFailed", _boss_spawn_failed], [&"RoomSpawned", _boss_spawned], [&"DungeonBossEquipmentAutoFailed", _boss_equipment_failed], [&"DungeonBossMeleeAIFailed", _boss_ai_failed], [&"DungeonNormalChestAutoFailed", _normal_chest_failed], [&"DungeonBossChestAutoFailed", _boss_chest_failed], [&"DungeonBossChestAutoCreated", _boss_chest_created], [&"DungeonDescended", _descended], [&"DungeonDescentFailed", _descent_failed], [&"RunStatisticsFinished", _run_finished], [&"SnapshotCollectRequested", _snapshot_collect], [&"SnapshotApplyRequested", _snapshot_apply], [&"GameDemoSnapshotValidateRequested", _snapshot_validate], [&"SessionDeleteOnDeathCheckRequested", _delete_guard]]:
		EventBus.unsubscribe(pair[0], pair[1])

func _ask(id: StringName, event: Dictionary) -> Dictionary:
	EventBus.publish(id, event)
	return event
func _require(id: StringName, data: Dictionary) -> bool:
	var result := _ask(id, data)
	if not result.get("accepted", false):
		printerr("Demo setup failed: ", id, " ", result)
		return false
	return true
func _setup() -> bool:
	# Используем сгенерированную комнату, не заливая её неровности полом.
	if not _require(&"LevelGenerationRequested", {"level_id":&"demo_floor_1", "seed":generation_seed, "size_cells":MAP_SIZE / 4, "start_origin":Vector2i(12,12), "deadend_budget":1}): return false
	# Безопасная площадка учебных персонажей и сундука, а не вся комната.
	var tutorial_floor: Array = []
	for x in range(52,76):
		for y in range(58,76): tutorial_floor.append(Vector2i(x,y))
	if not _require(&"SpaceTilesSetRequested", {"tiles":tutorial_floor,"kind":1}): return false
	if not _require(&"EntityCreateRequested", {"entity":HERO, "components":{&"stats":{"PER":16}}}): return false
	if not _require(&"SpaceBodyPlaceRequested", {"entity":HERO, "anchor":Vector2i(54,60), "size":4}): return false
	if not _require(&"ControlledEntityRequested", {"entity":HERO}): return false
	if not _require(&"DungeonFloorTrackingBeginRequested", {"floor":1, "start_room":ROOM}): return false
	if not _require(&"RunStatisticsStartRequested", {"entity":HERO, "start_room":ROOM}): return false
	if not _require(&"RoomEnterRequested", {"entity":HERO, "room":ROOM}): return false
	if not _require(&"MovementConfigureRequested", {"entity":HERO, "actor_type":"player", "K_move":50.0}): return false
	if not _require(&"InventoryConfigureRequested", {"entity":HERO, "volume":8.0}): return false
	# Стартовый набор — только для демонстрации, не правило генерации добычи.
	for entry in [[&"demo_potion_hp", &"potion_hp"], [&"demo_antidote", &"antidote"], [&"demo_bandage", &"bandage"], [&"demo_potion_stamina", &"potion_stamina"], [&"demo_potion_mana", &"potion_mana"], [&"demo_sword", &"sword_simple"], [&"demo_shield", starting_shield_base]]:
		if not _require(&"ItemCreateRequested", {"id":entry[0], "base_id":entry[1], "item_level":1}): return false
		if not _require(&"InventoryAddRequested", {"entity":HERO, "item":entry[0]}): return false
	if starting_armor_base != &"":
		if not _require(&"ItemCreateRequested", {"id":&"demo_armor", "base_id":starting_armor_base, "item_level":1}): return false
		if not _require(&"InventoryAddRequested", {"entity":HERO, "item":&"demo_armor"}): return false
	# Демо начинается с мечом в руке, а не с бесплатной учебной атаки.
	if not _require(&"InventoryRemoveRequested", {"entity":HERO, "item":&"demo_sword"}): return false
	if not _require(&"ComponentSetRequested", {"entity":HERO, "component":&"equipment", "data":{"main":&"demo_sword"}}): return false
	if not _require(&"RatSpawnRequested", {"entity":RAT, "anchor":Vector2i(70,60)}): return false
	if not _require(&"ComponentSetRequested", {"entity":RAT, "component":&"demo_floor_actor", "data":{"type":"tutorial_rat"}}): return false
	if not _require(&"StatBaseSetRequested", {"entity":RAT, "stat":&"PER", "value":12}): return false
	# Учебная крыса использует тот же оружейный профиль, что и огр.
	# Меч и укол здесь — временная демонстрационная экипировка.
	if not _require(&"ItemCreateRequested", {"id":&"demo_rat_sword", "base_id":&"sword_simple", "item_level":1}): return false
	if not _require(&"ComponentSetRequested", {"entity":RAT, "component":&"equipment", "data":{"main":&"demo_rat_sword"}}): return false
	if not _require(&"AIRegisterRequested", {"entity":RAT, "room":ROOM, "role":"melee", "target":HERO, "detected":false, "wait_duration":0.20, "weapon":{"item":&"demo_rat_sword", "strike":"demo_rat_thrust"}, "movement":{"actor_type":"rat", "K_move":50.0}}): return false
	if not _require(&"DetectionHostilitySetRequested", {"a":HERO, "b":RAT, "hostile":true}): return false
	if not _require(&"ObjectCreateRequested", {"entity":CHEST, "type":"chest", "room":ROOM, "tile":Vector2i(59,72), "inventory_capacity":4.0}): return false
	if not _require(&"MaterialRegisterRequested", {"material":{"id":"demo_material", "name":"Ткань", "weight_per_unit":1.0, "volume_per_unit":1.0, "level":1}}): return false
	if not _require(&"ItemBaseRegisterRequested", {"base":{"id":"demo_trophy_base", "name":"Трофей", "materials":[{"material_id":"demo_material", "count":1}]}}): return false
	if not _require(&"ItemCreateRequested", {"id":&"demo_trophy", "base_id":&"demo_trophy_base", "item_level":1}): return false
	if not _require(&"InventoryConfigureRequested", {"entity":RAT, "volume":4.0}): return false
	if not _require(&"InventoryAddRequested", {"entity":RAT, "item":&"demo_trophy"}): return false
	if not _require(&"DungeonNormalChestAutoEnableRequested", {"enabled":true}): return false
	return true

func _normal_chest_failed(event: Dictionary) -> void:
	message = "Обычный сундук: " + str(event.get("error","ошибка")) + ". Повтор: R."
	queue_redraw()

func _room_generation_failed(event: Dictionary) -> void:
	message = "Ошибка генерации: " + str(event.get("error", "продолжение не построено"))
	queue_redraw()

func _room_generation_incomplete(_event: Dictionary) -> void:
	message = "Ошибка отката генерации: требуется перезапустить демо."
	queue_redraw()

func _descended(event: Dictionary) -> void:
	if event.get("entity",null) == HERO:
		message = "Вы спустились на этаж %d." % int(event.get("floor",0))
		queue_redraw()
func _descent_failed(event: Dictionary) -> void:
	if event.get("entity",null) == HERO:
		message = "Спуск не выполнен: " + str(event.get("error","неизвестно"))
		queue_redraw()
func _stair_failed(event: Dictionary) -> void:
	message = "Ошибка размещения лестницы: " + str(event.get("error", "неизвестно"))
	queue_redraw()
func _portal_failed(event: Dictionary) -> void:
	message = "Портал не размещён: " + str(event.get("error","ошибка")) + ". Повтор: R."
	queue_redraw()
func _boss_spawn_failed(event: Dictionary) -> void:
	if event.get("entity",null) != HERO or not event.get("room",null) is StringName: return
	var room: StringName = event["room"]
	_spawn_errors[room] = "Босс не появился: " + str(event.get("error","ошибка"))
	var actual := _ask(&"RoomCurrentGetRequested", {})
	if actual.get("entity",null) == HERO and actual.get("room",null) == room:
		message = _spawn_errors[room] + ". Повтор: R."
		queue_redraw()
func _boss_spawned(event: Dictionary) -> void:
	for unit in event.get("units",[]):
		if unit is Dictionary and unit.get("type_id","") == "final_ogre":
			_spawn_errors.erase(event.get("room",null))
			return
func _boss_equipment_failed(event: Dictionary) -> void:
	_boss_prepare_failed(event,"Не удалось оснастить босса")
func _boss_ai_failed(event: Dictionary) -> void:
	_boss_prepare_failed(event,"Не удалось подготовить ИИ босса")
func _boss_prepare_failed(event: Dictionary, label: String) -> void:
	var boss := _ask(&"DungeonBossGetRequested", {})
	if boss.get("found",false) and boss["data"].get("entity",null) == event.get("entity",null) and boss["data"].get("room",null) == current_room:
		message = label + ": " + str(event.get("error","ошибка")) + ". Повтор: R."
		queue_redraw()
func _boss_chest_failed(event: Dictionary) -> void:
	if event.get("room",null) == current_room:
		message = "Сундук босса не размещён: " + str(event.get("error","ошибка")) + ". Повтор: R."
		queue_redraw()
func _boss_chest_created(event: Dictionary) -> void:
	if event.get("room",null) == current_room:
		message = "Сундук босса размещён."
		queue_redraw()

func _run_finished(event: Dictionary) -> void:
	if event.get("entity",null) == HERO and event.get("outcome","") == "victory":
		is_won = true
		inventory_open = false
		message = "Подземелье пройдено."
		_restart_button.visible = true
		_restart_button.disabled = not _fresh_available
		queue_redraw()

func _snapshot_collect(event: Dictionary) -> void:
	if _twohand_busy or _stat_allocation_busy or _pickup_starting:
		event["errors"].append("Нельзя сохранять при запуске смены оружия")
		return
	if not initialized or is_dead or is_won:
		event["errors"].append("Демосцена ещё не готова или персонаж погиб")
		return
	event["sections"]["game_demo"] = {"facing":facing,"attack_direction":attack_direction,"room":current_room,"inventory_open":inventory_open,"pending_attack":pending_attack,"attack_tiles":attack_tiles.duplicate(),"spawn_errors":_spawn_errors.duplicate(true),"twohand_queue":_twohand_queue.duplicate(true),"progression":{"level":hero_level,"xp":hero_xp,"points":hero_points},"journal":journal_entries.duplicate(),"map_memory":_map_memory.duplicate(),"pickup_ui":{"open":_pickup_open,"chest":_pickup_chest,"page":_pickup_page,"queue":_pickup_queue.duplicate(),"running":_pickup_queue_running,"inflight":_pickup_inflight,"skipped":_pickup_skipped}}
func _snapshot_apply(event: Dictionary) -> void:
	_clear_held_input()
	_strike_flashes.clear()
	var d: Dictionary = event["sections"]["game_demo"]
	journal_entries = d.get("journal",[]).duplicate()
	_map_memory = d.get("map_memory",{}).duplicate()
	_journal_dirty = true
	journal_open = false
	_journal_turn_time = 0.0
	facing = d["facing"]
	attack_direction = d.get("attack_direction",Vector2(facing))
	current_room = d["room"]
	inventory_open = d["inventory_open"]
	hero_level = d["progression"]["level"]
	hero_xp = d["progression"]["xp"]
	hero_points = d["progression"]["points"]
	stats_view = false
	_direction_action = ""
	_stat_allocation_busy = false
	inventory_page = 0
	equipment_view = false
	equipment_page = 0
	identify_mode = false
	inspect_mode = false
	inspect_item = &""
	pending_attack = d["pending_attack"]
	attack_tiles = d["attack_tiles"].duplicate()
	# Сохранения до изменения дистанций хранят прежнюю подсветку. Для
	# продолжающейся атаки пересчитываем её по текущей боевой геометрии.
	if pending_attack:
		var weapon_action := _ask(&"WeaponStrikeActionStatusRequested", {"entity":HERO})
		if weapon_action.get("active",false):
			var a: Dictionary = weapon_action["data"]
			var zone := _ask(&"WeaponStrikePreviewRequested", {"entity":HERO,"item":a["item"],"strike":a["strike"],"kind":"physical","direction":a["direction"]})
			if zone.get("accepted",false): attack_tiles = zone["zone"]["tiles"].duplicate()
		else:
			var bow := _ask(&"BowShotStatusRequested", {"entity":HERO})
			if bow.get("active",false): attack_tiles = _bow_aim_tiles(bow["data"]["direction"])
	_spawn_errors = d["spawn_errors"].duplicate(true)
	_twohand_queue = d["twohand_queue"].duplicate(true)
	_twohand_busy = false
	_drop_pick.clear()
	var loot_ui: Dictionary = d.get("pickup_ui",{})
	_pickup_open = loot_ui.get("open",false)
	_pickup_chest = loot_ui.get("chest",&"")
	_pickup_page = loot_ui.get("page",0)
	_pickup_queue = loot_ui.get("queue",[]).duplicate()
	_pickup_queue_running = loot_ui.get("running",false)
	_pickup_inflight = loot_ui.get("inflight",&"")
	_pickup_skipped = loot_ui.get("skipped",0)
	_pickup_starting = false; _drop_mode = false
	if _pickup_open and _pickup_queue_running: call_deferred("_pickup_continue")
	_spawn_generation += 1
	call_deferred("_spawn_current",_spawn_generation,false)
	is_dead = false
	is_won = false
	if is_instance_valid(_restart_button): _restart_button.visible = false
	message = "Демосостояние восстановлено."
	queue_redraw()
func _snapshot_validate(event: Dictionary) -> void:
	event["valid"] = false
	var sections = event.get("sections",null)
	if not sections is Dictionary or not sections.get("game_demo",null) is Dictionary: return
	var d: Dictionary = sections["game_demo"]
	if d.size() != 8 + int(d.has("attack_direction")) + int(d.has("journal")) + int(d.has("map_memory")) + int(d.has("pickup_ui")) or not d.get("progression",null) is Dictionary or not d.get("twohand_queue",null) is Dictionary or not d.get("spawn_errors",null) is Dictionary or d.get("facing",null) not in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT] or not d.get("room",null) is StringName or not d.get("inventory_open",null) is bool or not d.get("pending_attack",null) is bool or not d.get("attack_tiles",null) is Array or d["attack_tiles"].size() > 5000: return
	if d.has("pickup_ui"):
		var ui = d["pickup_ui"]
		if not ui is Dictionary or ui.size()!=7 or not ui.get("open",null) is bool or not ui.get("chest",null) is StringName or not ui.get("page",null) is int or ui["page"]<0 or not ui.get("queue",null) is Array or ui["queue"].size()>10000 or not ui.get("running",null) is bool or not ui.get("inflight",null) is StringName or not ui.get("skipped",null) is int or ui["skipped"]<0: return
		if not ui["open"] and (ui["running"] or not ui["queue"].is_empty() or ui["inflight"]!=&""): return
		if not ui["running"] and not ui["queue"].is_empty(): return
		var seen := {}
		for id in ui["queue"]:
			if not id is StringName or id==&"" or seen.has(id): return
			seen[id]=true
		if ui["inflight"]!=&"":
			if seen.has(ui["inflight"]): return
			var active: Dictionary = sections.get("actions",{}).get("active",{}).get(HERO,{})
			if ui["chest"]==&"":
				if active.get("id",null)!=&"loot_pickup" or sections.get("loot",{}).get("pending",{}).get(HERO,{}).get("item",null)!=ui["inflight"]: return
			else:
				var cp: Dictionary = sections.get("chest_transfers",{}).get(HERO,{})
				if active.get("id",null)!=&"chest_take" or cp.get("item",null)!=ui["inflight"] or cp.get("object",null)!=ui["chest"]: return
	if d.has("map_memory"):
		if not d["map_memory"] is Dictionary or d["map_memory"].size() > MAP_SIZE.x*MAP_SIZE.y: return
		var map_size = sections.get("space",{}).get("size",null)
		if not map_size is Vector2i: return
		for tile in d["map_memory"]:
			var bits = d["map_memory"][tile]
			if not tile is Vector2i or tile.x < 0 or tile.y < 0 or tile.x >= map_size.x or tile.y >= map_size.y or not bits is int or bits < 0 or bits > 127: return
	if d.has("journal"):
		if not d["journal"] is Array or d["journal"].size() > JOURNAL_LIMIT: return
		for entry in d["journal"]:
			if not entry is String or entry.is_empty() or entry.length() > 1000: return
	if d.has("attack_direction"):
		var aim = d["attack_direction"]
		if not aim is Vector2 or not is_finite(aim.x) or not is_finite(aim.y) or absf(aim.length()-1.0) > 0.0001: return
	var progression: Dictionary = d["progression"]
	if progression.size() != 3 or not progression.get("level",null) is int or not progression.get("xp",null) is int or not progression.get("points",null) is int: return
	if progression["level"] < 1 or progression["level"] > MAX_HERO_LEVEL or progression["xp"] < 0 or progression["xp"] >= XP_PER_LEVEL_FACTOR * progression["level"] or progression["points"] < 0 or progression["points"] > POINTS_PER_LEVEL * (progression["level"]-1): return
	for tile in d["attack_tiles"]:
		if not tile is Vector2i: return
	if not sections.get("actions",null) is Dictionary or not sections["actions"].get("active",null) is Dictionary or sections["actions"].get("controlled",null) != HERO: return
	if not sections.get("rooms",null) is Dictionary or sections["rooms"].get("current_room",null) != d["room"] or not sections["rooms"].get("rooms",null) is Dictionary or not sections["rooms"]["rooms"].has(d["room"]): return
	for id in d["spawn_errors"]:
		if not id is StringName or not sections["rooms"]["rooms"].has(id) or not d["spawn_errors"][id] is String or d["spawn_errors"][id].is_empty() or d["spawn_errors"][id].length() > 1000: return
	if not sections.get("entities",null) is Dictionary or not sections["entities"].has(HERO) or not sections.get("combat",null) is Dictionary or not sections["combat"].get("dead",null) is Dictionary or sections["combat"]["dead"].has(HERO): return
	var active = sections["actions"]["active"].get(HERO,{})
	if not active is Dictionary or (active.get("id",null) in [ATTACK,BOW_SHOT]) != d["pending_attack"]: return
	if not d["pending_attack"] and not d["attack_tiles"].is_empty(): return
	var q: Dictionary = d["twohand_queue"]
	if not q.is_empty():
		if q.size() != 5 or not q.get("target",null) is StringName or q["target"] == &"" or q.get("stage",null) not in ["ready","running","choose"] or not q.get("item",null) is StringName or q.get("slot",null) not in ["","main","off"] or q.get("action",null) not in [&"",&"equipment_equip",&"equipment_unequip"]: return
		var instances = sections.get("items",{}).get("instances",{})
		var bases = sections.get("items",{}).get("bases",{})
		var hero = sections["entities"].get(HERO,{})
		if not instances is Dictionary or not bases is Dictionary or not hero is Dictionary or not hero.get(&"inventory",{}).get("items",[]) is Array or not instances.has(q["target"]) or not hero[&"inventory"]["items"].has(q["target"]): return
		var target = instances[q["target"]]
		var base = bases.get(target.get("base_id",null),{}) if target is Dictionary else {}
		if not base is Dictionary or base.get("slot","") != "weapon" or not base.get("tags",[]) is Array or not base["tags"].has("two_handed"): return
		if q["stage"] == "ready":
			if q["item"] != &"" or q["slot"] != "" or q["action"] != &"": return
		elif q["stage"] == "choose":
			var equipped = hero.get(&"equipment",{})
			if q["action"] != &"equipment_unequip" or q["item"] == &"" or q["item"] == q["target"] or q["slot"] not in ["main","off"] or not equipped is Dictionary or equipped.get(q["slot"],null) != q["item"] or not active.is_empty(): return
		else:
			var op = sections.get("equipment_actions",{}).get(HERO,{})
			if not op is Dictionary or op.get("item",null) != q["item"] or op.get("slot",null) != q["slot"] or op.get("action",null) != q["action"]: return
			if q["action"] == &"equipment_equip" and (q["slot"] != "main" or q["item"] != q["target"]): return
			if q["action"] == &"equipment_unequip" and (q["item"] == &"" or q["item"] == q["target"]): return
	event["valid"] = true
func _delete_guard(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO: event["allowed"] = false
func _new_game() -> void:
	if not is_dead and not is_won: return
	var result := SaveService.restart_demo_fresh()
	message = "Новый забег начат." if result.get("accepted",false) else "Не удалось начать новый забег: " + str(result.get("error",""))
	queue_redraw()
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		if _mouse_hold_down: _cancel_mouse_path()
		_clear_held_input()

func _clear_held_input() -> void:
	_stop_mouse_hold()
	_held_keys.clear()
	_hold_blocked = false

func _stop_mouse_hold() -> void:
	if _mouse_hold_active: _cancel_mouse_path()
	_mouse_hold_down = false
	_mouse_hold_active = false
	_mouse_hold_elapsed = 0.0
	_mouse_hold_attempted = false

func _repeat_mouse_hold(delta: float) -> void:
	if not _mouse_hold_down or not initialized or is_dead or is_won or inventory_open or journal_open or _pickup_open: return
	_mouse_hold_elapsed += delta
	if not _mouse_hold_active and _mouse_hold_elapsed >= MOUSE_HOLD_DELAY:
		_mouse_hold_active = true
		_mouse_hold_attempted = false
		_cancel_mouse_path()
	if not _mouse_hold_active or _mouse_hold_attempted or not _map_contains(_mouse_hold_point): return
	if TimeDriver.is_action_active or TimeDriver._stepping or TimeDriver._settling or _ask(&"ActionGetRequested", {"entity":HERO}).get("found",false): return
	_mouse_hold_attempted = true
	_mouse_move_to(_mouse_hold_point)

func _held_direction(code: int) -> Vector2i:
	match code:
		KEY_W, KEY_UP: return Vector2i.UP
		KEY_S, KEY_DOWN: return Vector2i.DOWN
		KEY_A, KEY_LEFT: return Vector2i.LEFT
		KEY_D, KEY_RIGHT: return Vector2i.RIGHT
	return Vector2i.ZERO

func _repeat_held_input() -> void:
	if _held_keys.is_empty() or _hold_blocked or not initialized or is_dead or is_won or inventory_open or journal_open or _pickup_open or not _drop_pick.is_empty() or not _twohand_queue.is_empty() or not _direction_action.is_empty(): return
	if TimeDriver.is_action_active or TimeDriver._stepping or TimeDriver._settling or _ask(&"ActionGetRequested", {"entity":HERO}).get("found",false): return
	var key: int = _held_keys.back()
	var direction := _held_direction(key)
	var accepted := _wait() if key == KEY_Q else _move(direction)
	if not accepted: _hold_blocked = true

func _process(delta: float) -> void:
	if _journal_turn_time > 0.0:
		_journal_turn_time = maxf(0.0,_journal_turn_time-delta)
		queue_redraw()
	_repeat_mouse_hold(delta)
	_repeat_held_input()
	if not _twohand_queue.is_empty() and _twohand_queue.get("stage","") == "ready": _twohand_continue()
	if _twohand_queue.get("stage","") == "choose" and _drop_pick.is_empty(): _begin_drop_pick(_twohand_queue["slot"],_twohand_queue["item"],true)
	if is_instance_valid(_restart_button):
		_restart_button.position = _map_rect().get_center() + Vector2(-95.0,64.0)
	var motion := _ask(&"MovementPositionGetRequested", {"entity":HERO}) if initialized else {}
	for actor in _strike_flashes.keys():
		if Time.get_ticks_msec() >= int(_strike_flashes[actor]["expires"]): _strike_flashes.erase(actor)
	if motion.get("moving",false) or not _direction_action.is_empty() or not _strike_flashes.is_empty(): queue_redraw()
	_accumulator += delta
	if _accumulator >= 0.08:
		_accumulator = 0.0
		queue_redraw()
# Mouse navigation uses the same operations and timing as keyboard input.
# Исходная рамка сохраняет пропорции; поля по бокам/сверху заполняются чёрным.
func _frame_scale() -> float:
	return minf(size.x/1365.0,size.y/768.0)
func _frame_rect() -> Rect2:
	var scaled := Vector2(1365,768)*_frame_scale()
	return Rect2((size-scaled)*0.5,scaled)
func _ui_point(p: Vector2) -> Vector2:
	return _frame_rect().position + p*_frame_scale()
func _ui_rect(r: Rect2) -> Rect2:
	return Rect2(_ui_point(r.position),r.size*_frame_scale())
func _map_rect() -> Rect2:
	return _ui_rect(Rect2(246,160,873,459))
# Углы декоративной рамки непрозрачны и не должны ловить клики карты.
func _map_contains(point: Vector2) -> bool:
	if not _map_rect().has_point(point) or _ui_frame_image == null: return false
	var local := (point-_frame_rect().position)/_frame_scale()
	var px := clampi(floori(local.x),0,1364)
	var py := clampi(floori(local.y),0,767)
	return _ui_frame_image.get_pixel(px,py).a < 0.5
func _inventory_rect() -> Rect2:
	return Rect2(_map_rect().get_center()-Vector2(260,235),Vector2(520,470))
func _inventory_button_rect() -> Rect2:
	return _ui_rect(Rect2(20,22,94,30))
func _stats_button_rect() -> Rect2:
	return _ui_rect(Rect2(122,22,95,30))
func _drop_cancel_rect() -> Rect2:
	return _ui_rect(Rect2(20,61,94,30))
func _drop_confirm_rect() -> Rect2:
	return _ui_rect(Rect2(122,61,95,30))
func _camera_center_world() -> Vector2:
	var body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
	if not body.get("found",false): return Vector2(56,62)
	var motion := _ask(&"MovementPositionGetRequested", {"entity":HERO})
	var anchor: Vector2 = motion.get("position",Vector2(body["data"]["anchor"]))
	return anchor + Vector2.ONE * float(body["data"]["size"]) * 0.5
func _map_origin() -> Vector2:
	return _map_rect().get_center()-_camera_center_world()*STEP_PX
func _cancel_mouse_path() -> void:
	_ask(&"MovementPathCancelRequested", {"entity":HERO})
func _movement_started(event: Dictionary) -> void:
	if event.get("entity",null) != HERO: return
	if initialized: _remember_visible()
	var delta: Vector2i = event.get("to",Vector2i.ZERO)-event.get("from",Vector2i.ZERO)
	if delta != Vector2i.ZERO:
		facing = Vector2i(signi(delta.x),0) if absi(delta.x)>=absi(delta.y) else Vector2i(0,signi(delta.y))
		attack_direction = Vector2(delta).normalized()
	queue_redraw()
func _movement_finished(event: Dictionary) -> void:
	if event.get("entity",null) == HERO:
		if initialized: _remember_visible()
		if _mouse_hold_active:
			_cancel_mouse_path()
			_mouse_hold_attempted = false
		queue_redraw()
func _movement_path_stopped(event: Dictionary) -> void:
	if event.get("entity",null) == HERO:
		message = "Путь прерван: проход занят или недоступен."
		queue_redraw()
func _mouse_aim(point: Vector2) -> bool:
	var body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
	if not body.get("found",false): return false
	var hero_screen := _map_origin() + _camera_center_world()*STEP_PX
	var delta := point-hero_screen
	if delta.length_squared() < 16.0:
		message = "Укажите направление чуть дальше от героя."
		queue_redraw()
		return false
	_cancel_mouse_path()
	facing = Vector2i(1 if delta.x > 0 else -1,0) if absf(delta.x)>=absf(delta.y) else Vector2i(0,1 if delta.y > 0 else -1)
	attack_direction = delta.normalized()
	queue_redraw()
	return true
# Предпросмотр запрашивает ту же геометрию, что используется в реальном
# ударе/блоке; ввод и ресурсы здесь не изменяются.
func _direction_preview(point: Vector2) -> Dictionary:
	if _direction_action not in ["attack","block"] or inventory_open or not _drop_pick.is_empty(): return {}
	if not _map_contains(point): return {}
	var center := _map_origin()+_camera_center_world()*STEP_PX
	var delta := point-center
	if delta.length_squared() < 16.0: return {}
	var gear: Dictionary = _ask(&"ComponentGetRequested", {"entity":HERO,"component":&"equipment"}).get("data",{})
	if _direction_action == "block":
		var direction := delta.normalized()
		for slot in ["off","main"]:
			var id = gear.get(slot,null)
			if not id is StringName: continue
			var item := _ask(&"ItemGetRequested", {"item":id})
			if item.get("found",false) and item.get("base",{}).get("slot","") == "shield":
				var zone := _ask(&"ShieldBlockPreviewRequested", {"entity":HERO,"slot":slot,"direction":direction})
				return {"kind":"block","tiles":zone["data"]["tiles"],"direction":direction} if zone.get("accepted",false) else {}
		return {}
	var id = gear.get("main",null)
	if not id is StringName: return {}
	var item := _ask(&"ItemGetRequested", {"item":id})
	if str(item.get("base",{}).get("weapon_variant","")) == "bow_simple_variant":
		return {"kind":"attack","tiles":_bow_aim_tiles(delta.normalized()),"direction":delta.normalized()}
	var strike := str(DEMO_STRIKES.get(str(item.get("base",{}).get("weapon_variant","")),""))
	if strike.is_empty(): return {}
	var result := _ask(&"WeaponStrikePreviewRequested", {"entity":HERO,"item":id,"strike":strike,"kind":"physical","direction":delta.normalized()})
	return {"kind":"attack","tiles":result["zone"]["tiles"],"direction":delta.normalized()} if result.get("accepted",false) else {}

# Белая линия — прогноз фактического пути технической стрелы, а не зона ближнего удара.
func _bow_aim_tiles(direction: Vector2, actor: StringName = HERO) -> Array:
	var muzzle := _ask(&"BowMuzzlePreviewRequested", {"entity":actor,"direction":direction})
	if not muzzle.get("accepted",false): return []
	var start: Vector2 = muzzle["position"]
	var service := get_node("/root/ProjectileService")
	var reach: float = float(service.effective_projectile_parameters("bow").get("range",0.0))
	var wall: Dictionary = service._wall_ray(start,direction,reach)
	var hit: Dictionary = service._first_body(start,direction,reach,service._body_snapshot(),actor)
	var end := reach
	if wall.get("hit",false): end = minf(end,float(wall["distance"]))
	if hit.get("hit",false): end = minf(end,float(hit["distance"]))
	var tiles: Array = []
	var seen := {}
	var steps := ceili(end / 0.2)
	for i in range(steps+1):
		var p: Vector2 = start + direction*minf(end,float(i)*0.2)
		var tile := Vector2i(floori(p.x),floori(p.y))
		if tile.x >= 0 and tile.y >= 0 and tile.x < MAP_SIZE.x and tile.y < MAP_SIZE.y and not seen.has(tile): seen[tile]=true; tiles.append(tile)
	return tiles

func _bow_released(event: Dictionary) -> void:
	var actor = event.get("entity",null)
	if not actor is StringName: return
	if actor != HERO:
		if not event.get("accepted",false): return
		var fog := _ask(&"FogStateGetRequested", {})
		var visible := {}
		for tile in fog.get("visible_tiles",[]): visible[tile] = true
		var body := _ask(&"SpaceBodyGetRequested", {"entity":actor})
		if not body.get("found",false): return
		var b: Dictionary = body["data"]
		var shown := false
		for y in range(b["anchor"].y,b["anchor"].y+int(b["size"])):
			for x in range(b["anchor"].x,b["anchor"].x+int(b["size"])):
				if visible.has(Vector2i(x,y)): shown = true; break
			if shown: break
		if not shown: return
		var status := _ask(&"BowShotStatusRequested", {"entity":actor})
		if not status.get("active",false): return
		var tiles: Array = []
		for tile in _bow_aim_tiles(Vector2(status["data"]["direction"]),actor):
			if visible.has(tile): tiles.append(tile)
		_strike_flashes[actor] = {"tiles":tiles,"expires":Time.get_ticks_msec()+STRIKE_FLASH_MS}
		queue_redraw()
		return
	if event.get("accepted",false):
		_strike_flashes[HERO] = {"tiles":attack_tiles.duplicate(),"expires":Time.get_ticks_msec()+STRIKE_FLASH_MS}
		message = "Стрела выпущена."
	else: message = "Выстрел не состоялся: " + str(event.get("error","препятствие"))
	queue_redraw()

func _arm_direction(action: String) -> void:
	_cancel_mouse_path()
	if action == "block" and _ask(&"ShieldBlockStatusRequested", {"entity":HERO}).get("active",false):
		var extended := _ask(&"ShieldBlockExtendRequested", {"entity":HERO})
		message = "Блок продлён на 0,5 с." if extended.get("accepted",false) else "Не удалось продлить блок."
		queue_redraw()
		return
	if _ask(&"ActionGetRequested", {"entity":HERO}).get("found",false):
		_direction_action = ""
		message = "Дождитесь завершения текущего действия."
	else:
		_direction_action = action
		message = ("УДАР" if action == "attack" else "БЛОК") + ": выберите направление ЛКМ или стрелкой. Esc — отмена."
	queue_redraw()
func _confirm_direction() -> void:
	var action := _direction_action
	_direction_action = ""
	if action == "attack": _start_attack()
	elif action == "block": _start_shield_block(attack_direction)
	queue_redraw()
func _mouse_move_to(point: Vector2) -> void:
	_cancel_mouse_path()
	if _ask(&"ActionGetRequested", {"entity":HERO}).get("found",false):
		message = "Маршрут отменён. Дождитесь конца шага и выберите цель."; queue_redraw(); return
	var world := (point-_map_origin())/STEP_PX
	var tile := Vector2i(floori(world.x),floori(world.y))
	var fog := _ask(&"FogStateGetRequested", {})
	if tile not in fog.get("visible_tiles",[]):
		message = "Можно выбрать только видимую клетку."; queue_redraw(); return
	var target := _ask(&"MovementAimAnchorRequested", {"entity":HERO,"point":world})
	if not target.get("found",false):
		message = "Рядом с целью нет места для героя."; queue_redraw(); return
	var path := _ask(&"MovementPathStartRequested", {"entity":HERO,"target":target["anchor"],"max_nodes":2048})
	message = "Идём к выбранной точке. Esc — остановить." if path.get("accepted",false) else "Путь к выбранной точке не найден."
	queue_redraw()

func _press_key(code: Key) -> void:
	var e := InputEventKey.new()
	e.pressed = true
	e.keycode = code
	_unhandled_key_input(e)
func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and _mouse_hold_down:
		_mouse_hold_point = get_global_transform_with_canvas().affine_inverse() * event.position
		_mouse_hold_attempted = false
		if _mouse_hold_active: _cancel_mouse_path()
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and not event.pressed:
		_stop_mouse_hold()
		return
	# Отпускание отслеживается даже когда другой интерфейс перехватил ввод.
	if event is InputEventKey and not event.pressed:
		if _held_keys.has(event.keycode):
			_held_keys.erase(event.keycode)
			_hold_blocked = false
		return
	if not initialized or is_dead or is_won or not event is InputEventMouseButton or not event.pressed: return
	if event.button_index not in [MOUSE_BUTTON_LEFT,MOUSE_BUTTON_RIGHT]: return
	_clear_held_input()
	var point: Vector2 = get_global_transform_with_canvas().affine_inverse() * event.position
	if journal_open:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if _journal_close_rect().has_point(point): _close_journal()
			elif _journal_prev_rect().has_point(point): _turn_journal(-1)
			elif _journal_next_rect().has_point(point): _turn_journal(1)
		get_viewport().set_input_as_handled()
		return
	if _pickup_open:
		_pickup_mouse_input(point,event.button_index)
		get_viewport().set_input_as_handled()
		return
	if event.button_index == MOUSE_BUTTON_LEFT and _journal_button_rect().has_point(point) and _drop_pick.is_empty() and _twohand_queue.is_empty():
		_open_journal()
		get_viewport().set_input_as_handled()
		return
	if not _drop_pick.is_empty():
		if event.button_index == MOUSE_BUTTON_LEFT:
			if _drop_cancel_rect().has_point(point): _press_key(KEY_ESCAPE)
			elif _drop_confirm_rect().has_point(point): _press_key(KEY_F)
			elif _map_contains(point):
				var body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
				if body.get("found",false):
					var coords := (point-_map_origin())/STEP_PX
					_drop_pick["tile"] = Vector2i(floori(coords.x),floori(coords.y))
					_drop_pick_message()
		get_viewport().set_input_as_handled()
		return
	if not _twohand_queue.is_empty():
		get_viewport().set_input_as_handled()
		return
	if event.button_index == MOUSE_BUTTON_LEFT and _stats_button_rect().has_point(point):
		_open_stats()
		get_viewport().set_input_as_handled()
		return
	if event.button_index == MOUSE_BUTTON_LEFT and _inventory_button_rect().has_point(point):
		_toggle_inventory()
		get_viewport().set_input_as_handled()
		return
	if not inventory_open:
		if _map_contains(point):
			if event.button_index == MOUSE_BUTTON_LEFT:
				if _direction_action.is_empty():
					message = "Сначала выберите действие: пробел — удар, B — блок."
					queue_redraw()
				elif _mouse_aim(point): _confirm_direction()
			else:
				_direction_action = ""
				_mouse_hold_down = true
				_mouse_hold_active = false
				_mouse_hold_elapsed = 0.0
				_mouse_hold_point = point
				_mouse_hold_attempted = false
				_mouse_move_to(point)
			get_viewport().set_input_as_handled()
		return
	if not stats_view and not (inspect_mode and inspect_item != &""):
		_inventory_art_input(point,event.button_index)
		get_viewport().set_input_as_handled()
		return
	var rect := _inventory_rect()
	if not rect.has_point(point): return
	var p := point-rect.position
	if stats_view:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if Rect2(472,12,34,30).has_point(p): _toggle_inventory()
			elif Rect2(18,58,136,32).has_point(p): stats_view = false; equipment_view = false; queue_redraw()
			elif Rect2(160,58,136,32).has_point(p): stats_view = false; equipment_view = true; queue_redraw()
			elif p.x >= 423 and p.x < 502 and p.y >= 160 and p.y < 160+6*40:
				_allocate_stat(int((p.y-160)/40))
		get_viewport().set_input_as_handled()
		return
	if event.button_index == MOUSE_BUTTON_LEFT:
		if Rect2(472,12,34,30).has_point(p):
			if inspect_mode and inspect_item != &"": _press_key(KEY_ESCAPE)
			else: _toggle_inventory()
		elif Rect2(18,58,136,32).has_point(p):
			equipment_view = false; identify_mode = false; inspect_mode = false; inspect_item = &""; queue_redraw()
		elif Rect2(160,58,136,32).has_point(p):
			equipment_view = true; identify_mode = false; inspect_mode = false; inspect_item = &""; queue_redraw()
		elif Rect2(302,58,93,32).has_point(p):
			_press_key(KEY_V)
		elif Rect2(401,58,105,32).has_point(p): _press_key(KEY_T)
		elif Rect2(18,374,65,30).has_point(p): _press_key(KEY_LEFT)
		elif Rect2(437,374,65,30).has_point(p): _press_key(KEY_RIGHT)
		elif inspect_mode and inspect_item != &"" and Rect2(18,415,120,32).has_point(p): _press_key(KEY_ESCAPE)
		elif p.x >= 18 and p.x < 502 and p.y >= 103 and p.y < 103+9*29:
			_press_key((KEY_1 + int((p.y-103)/29)) as Key)
	elif event.button_index == MOUSE_BUTTON_RIGHT and not (inspect_mode and inspect_item != &"") and p.x >= 18 and p.x < 502 and p.y >= 103 and p.y < 103+9*29:
		if not inspect_mode: _press_key(KEY_V)
		_press_key((KEY_1 + int((p.y-103)/29)) as Key)
	get_viewport().set_input_as_handled()

func _unhandled_key_input(event: InputEvent) -> void:
	if not initialized or not event is InputEventKey or not event.pressed: return
	if event.echo: return
	_stop_mouse_hold()
	if journal_open:
		if event.keycode in [KEY_J,KEY_ESCAPE]: _close_journal()
		elif event.keycode in [KEY_LEFT,KEY_PAGEUP]: _turn_journal(-1)
		elif event.keycode in [KEY_RIGHT,KEY_PAGEDOWN]: _turn_journal(1)
		get_viewport().set_input_as_handled()
		return
	if is_won: return
	if _pickup_open:
		_pickup_key_input(event)
		get_viewport().set_input_as_handled()
		return
	if event.keycode == KEY_J and not is_dead and _drop_pick.is_empty() and _twohand_queue.is_empty():
		_open_journal()
		get_viewport().set_input_as_handled()
		return
	if event.keycode not in [KEY_W,KEY_A,KEY_S,KEY_D,KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT,KEY_Q]:
		_clear_held_input()
	if event.keycode in [KEY_F5, KEY_F9]:
		var result := _ask(&"SessionSaveRequested" if event.keycode == KEY_F5 else &"SessionLoadRequested", {"slot":"demo"})
		message = ("Демо сохранено." if event.keycode == KEY_F5 else "Демо загружено.") if result.get("accepted",false) else "Ошибка сохранения/загрузки: " + str(result.get("error",""))
		queue_redraw()
		get_viewport().set_input_as_handled()
		return
	if not _drop_pick.is_empty():
		_drop_pick_input(event)
		get_viewport().set_input_as_handled()
		return
	if not _twohand_queue.is_empty():
		message = "Идёт смена двуручного оружия."
		queue_redraw()
		get_viewport().set_input_as_handled()
		return
	if not inventory_open and event.keycode == KEY_ESCAPE:
		_cancel_mouse_path()
		message = "Выбор направления отменён." if not _direction_action.is_empty() else "Маршрут остановлен; начатый шаг завершится."
		_direction_action = ""
		queue_redraw()
		get_viewport().set_input_as_handled()
		return
	if event.keycode in [KEY_SPACE, KEY_B, KEY_I, KEY_C, KEY_Q, KEY_E, KEY_F]: _cancel_mouse_path()
	if event.keycode in [KEY_I, KEY_C, KEY_Q, KEY_E, KEY_F, KEY_R]: _direction_action = ""
	if event.keycode == KEY_C:
		_open_stats()
		get_viewport().set_input_as_handled()
		return
	if event.keycode == KEY_I:
		_toggle_inventory()
		get_viewport().set_input_as_handled()
		return
	if is_dead: return
	if inventory_open:
		if stats_view:
			if event.keycode >= KEY_1 and event.keycode <= KEY_6: _allocate_stat(int(event.keycode-KEY_1))
			elif event.keycode == KEY_TAB: stats_view = false; equipment_view = false; queue_redraw()
			elif event.keycode == KEY_ESCAPE: _toggle_inventory()
			get_viewport().set_input_as_handled()
			return
		if event.keycode == KEY_V or (event.keycode == KEY_ESCAPE and inspect_mode):
			_drop_mode = false
			inspect_mode = not inspect_mode if event.keycode == KEY_V else false
			inspect_item = &""
			if inspect_mode: identify_mode = false
			message = "Выберите предмет для осмотра." if inspect_mode else "Осмотр закрыт."
			queue_redraw()
			get_viewport().set_input_as_handled()
			return
		if inspect_mode and inspect_item != &"":
			if event.keycode in [KEY_LEFT,KEY_RIGHT,KEY_PAGEUP,KEY_PAGEDOWN]:
				_change_inspect_page(-1 if event.keycode in [KEY_LEFT,KEY_PAGEUP] else 1)
				get_viewport().set_input_as_handled()
			return
		if event.keycode == KEY_G and not inspect_mode:
			_drop_mode = not _drop_mode
			if _drop_mode: identify_mode = false; equipment_view = false
			message = "Выбросить: выберите предмет в рюкзаке." if _drop_mode else "Режим выбрасывания выключен."
			queue_redraw()
			get_viewport().set_input_as_handled()
			return
		if event.keycode >= KEY_1 and event.keycode <= KEY_9:
			if _drop_mode and not equipment_view: _drop_inventory_item(int(event.keycode - KEY_1))
			elif inspect_mode: _inspect_select(int(event.keycode - KEY_1))
			elif equipment_view: _unequip_equipment_row(int(event.keycode - KEY_1))
			elif identify_mode: _identify_inventory_item(int(event.keycode - KEY_1))
			else: _use_inventory_item(int(event.keycode - KEY_1))
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_T:
			_drop_mode = false
			inspect_mode = false; inspect_item = &""
			if equipment_view: equipment_view = false; identify_mode = true
			else: identify_mode = not identify_mode
			message = "Выберите предмет для опознания." if identify_mode else "Режим использования предметов."
			queue_redraw()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_TAB:
			identify_mode = false
			equipment_view = not equipment_view
			queue_redraw()
			get_viewport().set_input_as_handled()
		elif event.keycode in [KEY_LEFT, KEY_RIGHT, KEY_PAGEUP, KEY_PAGEDOWN]:
			var delta := -1 if event.keycode in [KEY_LEFT, KEY_PAGEUP] else 1
			if equipment_view: equipment_page = clampi(equipment_page + delta, 0, 1); queue_redraw()
			else: _change_inventory_page(delta)
			get_viewport().set_input_as_handled()
		elif event.keycode in [KEY_Z, KEY_X]:
			_unequip_hand("main" if event.keycode == KEY_Z else "off")
			get_viewport().set_input_as_handled()
		return
	var direction := Vector2i.ZERO
	match event.keycode:
		KEY_W, KEY_UP: direction = Vector2i.UP
		KEY_S, KEY_DOWN: direction = Vector2i.DOWN
		KEY_A, KEY_LEFT: direction = Vector2i.LEFT
		KEY_D, KEY_RIGHT: direction = Vector2i.RIGHT
		KEY_SPACE: _arm_direction("attack")
		KEY_B: _arm_direction("block")
		KEY_Q:
			_held_keys.erase(KEY_Q)
			_held_keys.append(KEY_Q)
			_hold_blocked = false
			if not _wait() and not TimeDriver.is_action_active: _hold_blocked = true
		KEY_E: _pickup()
		KEY_F: _interact_chest()
		KEY_R: _retry_spawns()
		_: return
	if direction != Vector2i.ZERO:
		if not _direction_action.is_empty():
			facing = direction
			attack_direction = Vector2(direction)
			_confirm_direction()
		else:
			_held_keys.erase(event.keycode)
			_held_keys.append(event.keycode)
			_hold_blocked = false
			if not _move(direction) and not TimeDriver.is_action_active: _hold_blocked = true
	get_viewport().set_input_as_handled()

func _move(direction: Vector2i) -> bool:
	if not initialized or is_dead or inventory_open: return false
	facing = direction
	var event := _ask(&"MovementStepRequested", {"entity":HERO, "delta":direction})
	if not event.get("accepted", false): message = "Нельзя пройти: занято или действие ещё выполняется."
	else: message = "Движение выполняется во времени."
	queue_redraw()
	return event.get("accepted", false)
# Блок — отдельное штатное действие, не пассивный бонус от надетого щита.
func _start_shield_block(direction: Variant = null) -> bool:
	if not initialized or is_dead or is_won or inventory_open: return false
	var gear := _ask(&"ComponentGetRequested", {"entity":HERO,"component":&"equipment"})
	var slot := ""
	for hand in ["off","main"]:
		var id = gear.get("data",{}).get(hand,null)
		if id is StringName and id != &"":
			var item := _ask(&"ItemGetRequested", {"item":id})
			if item.get("found",false) and item.get("base",{}).get("slot","") == "shield":
				slot = hand
				break
	if slot.is_empty():
		message = "Для блока наденьте щит."
		queue_redraw()
		return false
	var result := _ask(&"ShieldBlockStartRequested", {"entity":HERO,"slot":slot,"direction":facing if direction == null else direction})
	message = "Блок щитом: 0,5 с. Повторное B продлевает блок." if result.get("accepted",false) else "Блок недоступен: " + str(result.get("error","занято"))
	queue_redraw()
	return result.get("accepted",false)

func _wait() -> bool:
	if is_dead or inventory_open: return false
	var event := _ask(&"ActionStartRequested", {"entity":HERO, "action":&"wait", "duration":0.5})
	message = "Ожидание: 0,5 с." if event.get("accepted", false) else "Другое действие ещё выполняется."
	return event.get("accepted", false)
func _start_attack() -> bool:
	if is_dead or inventory_open or pending_attack: return false
	var gear := _ask(&"ComponentGetRequested", {"entity":HERO,"component":&"equipment"})
	var item = gear.get("data",{}).get("main",null)
	if not item is StringName or item == &"":
		message = "Наденьте оружие в основной руке."
		return false
	var definition := _ask(&"ItemGetRequested", {"item":item})
	var variant := str(definition.get("base",{}).get("weapon_variant",""))
	if variant == "bow_simple_variant":
		var tiles := _bow_aim_tiles(attack_direction)
		var shot := _ask(&"BowShotStartRequested", {"entity":HERO,"item":item,"direction":attack_direction})
		if not shot.get("accepted",false):
			message = "Нельзя стрелять: " + str(shot.get("error","действие недоступно"))
			return false
		var status := _ask(&"BowShotStatusRequested", {"entity":HERO})
		if not status.get("active",false): message = "Выстрел прерван при начале."; return false
		pending_attack = true
		attack_tiles = tiles
		message = "Подготовка выстрела: направление показано белым."
		return true
	var strike := str(DEMO_STRIKES.get(variant,""))
	if strike.is_empty():
		message = "Для этого оружия атака в демо ещё не реализована."
		return false
	var preview := _ask(&"WeaponStrikePreviewRequested", {"entity":HERO,"item":item,"strike":strike,"kind":"physical","direction":attack_direction})
	if not preview.get("accepted", false):
		message = "Удар недоступен: " + str(preview.get("error", ""))
		return false
	var event := _ask(&"WeaponStrikeStartRequested", {"entity":HERO,"item":item,"strike":strike,"direction":attack_direction})
	if not event.get("accepted", false):
		message = "Нельзя атаковать: " + str(event.get("error", "нет выносливости или идёт действие"))
		return false
	var status := _ask(&"WeaponStrikeActionStatusRequested", {"entity":HERO})
	if not status.get("active",false):
		message = "Удар был прерван при начале."
		return false
	pending_attack = true
	attack_tiles = preview["zone"]["tiles"].duplicate()
	message = "Удар: зона показана белым."
	return true
func _action_completed(event: Dictionary) -> void:
	if event.get("entity", &"") != HERO or event.get("action", &"") not in [ATTACK,BOW_SHOT] or not pending_attack: return
	pending_attack = false
	attack_tiles.clear()
	message = "Удар завершён."
func _action_interrupted(event: Dictionary) -> void:
	if event.get("entity",null) == HERO and _twohand_queue.get("stage","") == "running" and event.get("action",null) == _twohand_queue.get("action",null):
		_twohand_queue.clear(); message = "Смена оружия прервана."; queue_redraw()
	if event.get("entity", &"") == HERO and event.get("action", &"") in [ATTACK,BOW_SHOT]:
		pending_attack = false
		attack_tiles.clear()
		message = "Удар прерван."
func _pickup_candidates() -> Array:
	if _pickup_chest != &"":
		var chest := _ask(&"ObjectContainerGetRequested",{"entity":HERO,"object":_pickup_chest})
		return chest.get("inventory",{}).get("items",[]).duplicate() if chest.get("found",false) else []
	var candidates: Array = _ask(&"LootPickupCandidatesRequested",{"entity":HERO}).get("items",[])
	var ground: Dictionary = _ask(&"LootGetRequested",{}).get("items",{})
	var visible: Array = _ask(&"FogStateGetRequested",{}).get("visible_tiles",[])
	var result: Array = []
	for id in candidates:
		if ground.has(id) and ground[id].get("tile",null) in visible: result.append(id)
	return result

func _pickup_can_fit(item: Variant) -> bool:
	if not item is StringName: return false
	var inv := _ask(&"InventoryGetRequested",{"entity":HERO})
	var volume := _ask(&"ItemVolumeRequested",{"item":item})
	return inv.get("found",false) and inv.get("volume_known",false) and volume.get("found",false) and float(inv["used_volume"])+float(volume["volume"]) <= float(inv["capacity"])+0.000000001

func _pickup_close() -> void:
	_pickup_open = false; _pickup_queue.clear(); _pickup_queue_running = false; _pickup_inflight = &""
	message = "Окно добычи закрыто."; queue_redraw()

# Список фиксируется в том же порядке, что показан игроку. Перед каждым
# действием заново проверяются наличие и свободный объём: не влезшие
# пропускаются без затрат времени, более мелкие всё равно рассматриваются.
func _pickup_all() -> void:
	if not _pickup_open or _pickup_queue_running or _pickup_inflight != &"": return
	_pickup_queue = _pickup_candidates().duplicate()
	_pickup_skipped = 0
	_pickup_queue_running = true
	_pickup_continue()

func _pickup_continue() -> void:
	if not _pickup_open or not _pickup_queue_running or is_dead or is_won: return
	if TimeDriver._stepping or TimeDriver._settling or TimeDriver.is_action_active or _pickup_inflight != &"": return
	while not _pickup_queue.is_empty():
		var id = _pickup_queue.pop_front()
		if not _pickup_candidates().has(id) or not _pickup_can_fit(id):
			_pickup_skipped += 1
			continue
		if _pickup_item(id): return
		_pickup_queue.clear(); _pickup_queue_running = false
		message = "Автоподбор остановлен: не удалось начать действие."
		queue_redraw(); return
	_pickup_queue_running = false
	var left := _pickup_candidates()
	if left.is_empty(): _pickup_open = false
	message = "Подбор завершён." if _pickup_skipped == 0 else "Подбор завершён: пропущено %d, нет места или предмет недоступен." % _pickup_skipped
	queue_redraw()

func _pickup_finished(item: Variant, success: bool) -> void:
	if not _pickup_open or item != _pickup_inflight: return
	_pickup_inflight = &""
	if not success:
		_pickup_queue.clear(); _pickup_queue_running = false
	elif _pickup_queue_running:
		call_deferred("_pickup_continue")
	elif _pickup_candidates().is_empty():
		_pickup_open = false
	queue_redraw()

func _pickup_item(item: Variant) -> bool:
	if not item is StringName or not _pickup_candidates().has(item):
		message = "Предмет уже недоступен."
		queue_redraw(); return false
	if not _pickup_can_fit(item):
		message = "Предмет не помещается в рюкзак."
		queue_redraw(); return false
	if _pickup_inflight != &"" or _ask(&"ActionGetRequested",{"entity":HERO}).get("found",false):
		message = "Дождитесь завершения подбора."
		return false
	_pickup_starting = true
	var request: Dictionary
	if _pickup_chest != &"":
		request = _ask(&"ChestTakeRequested", {"entity":HERO,"object":_pickup_chest,"item":item})
		message = "Берём %s: 0,1 с." % _item_name(item) if request.get("accepted",false) else "Не удалось взять предмет: " + str(request.get("error","действие недоступно"))
	else:
		request = _ask(&"LootPickupRequested", {"entity":HERO,"item":item,"duration":PICKUP_TIME})
		message = "Подбираем %s: 0,35 с." % _item_name(item) if request.get("accepted",false) else "Не удалось начать подбор."
	if request.get("accepted",false): _pickup_inflight = item
	_pickup_starting = false
	queue_redraw()
	return request.get("accepted",false)

func _pickup() -> bool:
	if is_dead or is_won or inventory_open or _ask(&"ActionGetRequested",{"entity":HERO}).get("found",false): return false
	_pickup_chest = &""
	var ids := _pickup_candidates()
	if ids.is_empty():
		message = "Встаньте телом на светящуюся добычу."
		queue_redraw(); return false
	_clear_held_input(); _cancel_mouse_path(); _direction_action = ""
	_pickup_open = true; _pickup_page = 0
	message = "Выберите предмет для подбора."
	queue_redraw()
	return true

func _pickup_rect() -> Rect2:
	var rect_size := Vector2(400,348)*_frame_scale()
	return Rect2(_map_rect().get_center()-rect_size*0.5,rect_size)
func _pickup_row_rect(row: int) -> Rect2:
	var r := _pickup_rect(); var f := _frame_scale()
	return Rect2(r.position+Vector2(12,46+row*35)*f,Vector2(376,32)*f)
func _pickup_control_rect(index: int) -> Rect2:
	var r := _pickup_rect(); var f := _frame_scale()
	return Rect2(r.position+Vector2([12,80,286,166][index],302)*f,Vector2([62,62,102,112][index],30)*f)
func _pickup_change_page(delta: int) -> void:
	var pages := maxi(1,ceili(float(_pickup_candidates().size())/PICKUP_PAGE_SIZE))
	_pickup_page = clampi(_pickup_page+delta,0,pages-1)
	queue_redraw()
func _pickup_key_input(event: InputEventKey) -> void:
	if event.keycode in [KEY_ESCAPE,KEY_E,KEY_F]:
		_pickup_close(); return
	if event.keycode in [KEY_F5,KEY_F9]:
		var result := _ask(&"SessionSaveRequested" if event.keycode==KEY_F5 else &"SessionLoadRequested",{"slot":"demo"})
		message = ("Демо сохранено." if event.keycode==KEY_F5 else "Демо загружено.") if result.get("accepted",false) else "Ошибка сохранения/загрузки: " + str(result.get("error",""))
		queue_redraw(); return
	if event.keycode == KEY_A:
		_pickup_all(); return
	if _pickup_queue_running or _pickup_inflight != &"": return
	if event.keycode in [KEY_LEFT,KEY_PAGEUP]: _pickup_change_page(-1); return
	if event.keycode in [KEY_RIGHT,KEY_PAGEDOWN]: _pickup_change_page(1); return
	if event.keycode >= KEY_1 and event.keycode < KEY_1+PICKUP_PAGE_SIZE:
		var ids := _pickup_candidates()
		var index := _pickup_page*PICKUP_PAGE_SIZE+int(event.keycode-KEY_1)
		if index < ids.size(): _pickup_item(ids[index])
func _pickup_mouse_input(point: Vector2, button: MouseButton) -> void:
	if button != MOUSE_BUTTON_LEFT: return
	if _pickup_control_rect(0).has_point(point): _pickup_change_page(-1); return
	if _pickup_control_rect(1).has_point(point): _pickup_change_page(1); return
	if _pickup_control_rect(2).has_point(point): _pickup_close(); return
	if _pickup_control_rect(3).has_point(point): _pickup_all(); return
	if _pickup_queue_running or _pickup_inflight != &"": return
	var ids := _pickup_candidates()
	for i in range(PICKUP_PAGE_SIZE):
		if _pickup_row_rect(i).has_point(point):
			var index := _pickup_page*PICKUP_PAGE_SIZE+i
			if index < ids.size(): _pickup_item(ids[index])
			return
func _draw_pickup_selector() -> void:
	var r := _pickup_rect(); var f := _frame_scale()
	_panel(r,Color("171b19f5"),Color("d8ba78"))
	_txt(("СУНДУК" if _pickup_chest != &"" else "ПОДОБРАТЬ") + "  ·  выберите предмет",r.position+Vector2(14,28)*f,maxi(10,roundi(15*f)),Color("f4e4be"),r.size.x-28*f)
	var ids := _pickup_candidates()
	var pages := maxi(1,ceili(float(ids.size())/PICKUP_PAGE_SIZE))
	_pickup_page = clampi(_pickup_page,0,pages-1)
	for i in range(PICKUP_PAGE_SIZE):
		var index := _pickup_page*PICKUP_PAGE_SIZE+i
		if index >= ids.size(): break
		var row := _pickup_row_rect(i)
		draw_rect(row,Color("78623c55") if row.has_point(get_local_mouse_position()) else Color("2b302bed"))
		draw_rect(row,Color("8a7955"),false,maxf(1.0,f))
		_draw_item_icon(ids[index],Rect2(row.position+Vector2(3,2)*f,Vector2.ONE*28*f))
		var fits := _pickup_can_fit(ids[index])
		var label := "%d. %s%s" % [i+1,_item_name(ids[index]),"" if fits else " · не помещается"]
		_txt(label,row.position+Vector2(38,21)*f,maxi(9,roundi(13*f)),Color("f0e4c9") if fits else Color("bda78f"),row.size.x-43*f)
	_mouse_button(_pickup_control_rect(0),"‹")
	_mouse_button(_pickup_control_rect(1),"›")
	_mouse_button(_pickup_control_rect(2),"Закрыть")
	_mouse_button(_pickup_control_rect(3),"Взять всё [A]",_pickup_queue_running)
	_txt("%d / %d" % [_pickup_page+1,pages],r.position+Vector2(145,295)*f,maxi(9,roundi(12*f)),Color("d6c8a9"))

func _interact_chest() -> bool:
	if is_dead or is_won or inventory_open: return false
	var portal := _ask(&"DungeonPortalGetRequested", {})
	if portal.get("found",false) and portal["data"].get("status","") == "placed":
		var portal_object := _ask(&"ObjectGetRequested", {"object":portal["data"]["object"]})
		var hero_body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
		if portal_object.get("found",false) and hero_body.get("found",false):
			var a: Vector2i = hero_body["data"]["anchor"]
			var n: int = hero_body["data"]["size"]
			var p: Vector2i = portal_object["data"]["tile"]
			if ((p.x == a.x-1 or p.x == a.x+n) and p.y >= a.y and p.y < a.y+n) or ((p.y == a.y-1 or p.y == a.y+n) and p.x >= a.x and p.x < a.x+n):
				var interaction := _ask(&"ObjectInteractRequested", {"entity":HERO,"object":portal["data"]["object"]})
				if not interaction.get("accepted",false): message = "Портал недоступен: " + str(interaction.get("error",""))
				queue_redraw()
				return interaction.get("accepted",false)
	var stair := _ask(&"DungeonStairGetRequested", {})
	if stair.get("found", false) and stair["data"].get("status", "") == "placed":
		var object := _ask(&"ObjectGetRequested", {"object":stair["data"]["object"]})
		var body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
		if object.get("found", false) and body.get("found", false):
			var a: Vector2i = body["data"]["anchor"]
			var n: int = body["data"]["size"]
			var p: Vector2i = object["data"]["tile"]
			if ((p.x == a.x - 1 or p.x == a.x + n) and p.y >= a.y and p.y < a.y + n) or ((p.y == a.y - 1 or p.y == a.y + n) and p.x >= a.x and p.x < a.x + n):
				var descent := _ask(&"ObjectInteractRequested", {"entity":HERO, "object":stair["data"]["object"]})
				message = "Спускаемся: 0,1 с." if descent.get("accepted", false) else "Спуск недоступен: " + str(descent.get("error", "демосцена не поддерживает переход"))
				queue_redraw()
				return descent.get("accepted", false)
	var body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
	var objects: Dictionary = _ask(&"RoomObjectsGetRequested", {"room":current_room}).get("objects",{})
	if not body.get("found",false): return false
	var a: Vector2i = body["data"]["anchor"]
	var n: int = body["data"]["size"]
	var ids: Array = objects.keys()
	ids.sort_custom(func(x,y): return str(x) < str(y))
	var empty_chest := false
	for id in ids:
		var data: Dictionary = objects[id]
		if data.get("type","") != "chest": continue
		var p: Vector2i = data["tile"]
		if not (((p.x == a.x-1 or p.x == a.x+n) and p.y >= a.y and p.y < a.y+n) or ((p.y == a.y-1 or p.y == a.y+n) and p.x >= a.x and p.x < a.x+n)): continue
		if not data.get("opened",false):
			var open := _ask(&"ObjectInteractRequested", {"entity":HERO,"object":id})
			message = "Открываем сундук: 0,1 с." if open.get("accepted",false) else "Не удалось открыть сундук: " + str(open.get("error","действие недоступно"))
			return open.get("accepted",false)
		var chest := _ask(&"ObjectContainerGetRequested", {"entity":HERO,"object":id})
		if not chest.get("found",false):
			message = "Сундук недоступен."; return false
		var items: Array = chest["inventory"].get("items",[])
		if items.is_empty():
			empty_chest = true
			continue
		_pickup_chest = id
		if _ask(&"ActionGetRequested",{"entity":HERO}).get("found",false): message="Дождитесь завершения действия."; return false
		_clear_held_input(); _cancel_mouse_path(); _direction_action = ""
		_pickup_open = true; _pickup_page = 0
		message = "Выберите предмет из сундука."
		queue_redraw()
		return true
	message = "Сундук пуст." if empty_chest else "Подойдите вплотную к сундуку с одной из сторон."
	return false
func _inventory_items() -> Array:
	return _ask(&"InventoryGetRequested", {"entity":HERO}).get("data", {}).get("items", [])
func _inventory_page_count(items: Array) -> int:
	return maxi(1, ceili(float(items.size()) / 9.0))
func _clamp_inventory_page(items: Array) -> void:
	inventory_page = clampi(inventory_page, 0, _inventory_page_count(items) - 1)
func _change_inventory_page(delta: int) -> void:
	if not initialized or is_dead or not inventory_open: return
	var items := _inventory_items()
	_clamp_inventory_page(items)
	inventory_page = clampi(inventory_page + delta, 0, _inventory_page_count(items) - 1)
	queue_redraw()
func _use_inventory_item(index: int) -> bool:
	if not initialized or is_dead or not inventory_open or index < 0 or index >= 9: return false
	var items := _inventory_items()
	_clamp_inventory_page(items)
	index += inventory_page * 9
	if index >= items.size():
		message = "В этой строке нет предмета."
		return false
	var item := _ask(&"ItemGetRequested", {"item":items[index]})
	if not item.get("found", false): return false
	var category := str(item["base"].get("slot", ""))
	var request: Dictionary
	if category == "consumable":
		request = _ask(&"ConsumableUseRequested", {"entity":HERO, "item":items[index]})
		message = "Применяем %s: 0,5 с." % item["base"].get("name", "предмет") if request.get("accepted", false) else "Нельзя применить предмет во время другого действия."
	else:
		if category == "weapon" and str(item["base"].get("weapon_variant","")) != "bow_simple_variant" and not DEMO_STRIKES.has(str(item["base"].get("weapon_variant",""))):
			message = "Для этого оружия атака в демо ещё не реализована."
			queue_redraw()
			return false
		var slot := "main" if category == "weapon" else ("off" if category == "shield" else category)
		if category == "ring":
			var gear := _ask(&"ComponentGetRequested", {"entity":HERO, "component":&"equipment"})
			slot = "ring1" if gear.get("data", {}).get("ring1", null) == null else "ring2"
		if slot not in ["main", "off", "head", "body", "hands", "belt", "legs", "feet", "ring1", "ring2", "amulet", "cloak"]:
			message = "Этот предмет нельзя экипировать."
			return false
		if category == "weapon" and item["base"].get("tags",[]).has("two_handed"):
			var hands: Dictionary = _ask(&"ComponentGetRequested", {"entity":HERO, "component":&"equipment"}).get("data",{})
			if hands.get("main",null) != null or hands.get("off",null) != null: return _start_twohand_sequence(items[index])
		request = _ask(&"EquipmentEquipRequested", {"entity":HERO, "item":items[index], "slot":slot})
		message = "Надеваем %s: 0,1 с." % item["base"].get("name", "предмет") if request.get("accepted", false) else "Нельзя надеть: " + str(request.get("error","слот занят или действие недоступно"))
	queue_redraw()
	return request.get("accepted", false)

# Смена двуручного оружия: каждый перенос — штатное отдельное действие.
func _start_twohand_sequence(target: StringName) -> bool:
	if not _twohand_queue.is_empty() or _twohand_busy or TimeDriver._stepping or TimeDriver._settling or _ask(&"ActionGetRequested", {"entity":HERO}).get("found",false):
		message = "Дождитесь завершения текущего действия."
		queue_redraw()
		return false
	var item := _ask(&"ItemGetRequested", {"item":target})
	if not item.get("found",false) or not _inventory_items().has(target):
		message = "Оружие больше недоступно."; queue_redraw(); return false
	if not DungeonChestModCatalogService.unsupported_live_effects(item["item_data"]).is_empty() or not DungeonChestLearningService.equipped_stat_mods_valid(HERO,item["item_data"],item["base"]) or not DungeonChestLearningService.equipped_resource_mods_valid(HERO,item["item_data"],item["base"]) or not DungeonChestLearningService.weapon_physical_damage_mod_bonus(HERO,item["item_data"],item["base"]).get("valid",false):
		message = "Смена оружия недоступна: эффекты предмета не поддерживаются."; queue_redraw(); return false
	_twohand_queue = {"target":target,"stage":"ready","item":&"","slot":"","action":&""}
	return _twohand_continue()
func _twohand_continue() -> bool:
	if _twohand_busy or _twohand_queue.is_empty() or _twohand_queue.get("stage","") != "ready" or TimeDriver._stepping or TimeDriver._settling: return false
	if is_dead or is_won: _twohand_queue.clear(); return false
	if _ask(&"ActionGetRequested", {"entity":HERO}).get("found",false): return false
	var target: StringName = _twohand_queue["target"]
	if not _inventory_items().has(target):
		_twohand_queue.clear(); message = "Смена оружия остановлена: предмет больше не в инвентаре."; queue_redraw(); return false
	var gear := _ask(&"ComponentGetRequested", {"entity":HERO,"component":&"equipment"})
	var slots: Dictionary = gear.get("data",{})
	var chosen := ""
	# Щит снимается первым независимо от руки.
	for slot in ["main","off"]:
		var id = slots.get(slot,null)
		if id is StringName and _ask(&"ItemGetRequested", {"item":id}).get("base",{}).get("slot","") == "shield": chosen=slot; break
	if chosen == "":
		for slot in ["off","main"]:
			if slots.get(slot,null) != null: chosen=slot; break
	var item: StringName = target if chosen == "" else slots[chosen]
	var action: StringName = &"equipment_equip" if chosen == "" else &"equipment_unequip"
	var slot := "main" if chosen == "" else chosen
	_twohand_queue.merge({"stage":"running","item":item,"slot":slot,"action":action},true)
	_twohand_busy = true
	var request := _ask(&"EquipmentEquipRequested" if chosen == "" else &"EquipmentUnequipRequested", {"entity":HERO,"item":item,"slot":slot})
	_twohand_busy = false
	if not request.get("accepted",false):
		if request.get("needs_drop_tile",false):
			_twohand_queue["stage"] = "choose"
			if _begin_drop_pick(slot,item,true): return true
		_twohand_queue.clear()
		message = "Смена оружия остановлена: " + str(request.get("error","действие недоступно"))
		queue_redraw()
		return false
	message = "Надеваем двуручное оружие: 0,1 с." if chosen == "" else "Снимаем предмет из руки: 0,1 с."
	queue_redraw()
	return true
# Временный экран выбора тайла: координаты фиксируются только с началом действия.
func _drop_inventory_item(index: int) -> bool:
	var items := _inventory_items()
	_clamp_inventory_page(items)
	var absolute := inventory_page*9+index
	if absolute < 0 or absolute >= items.size(): message = "В этой ячейке нет предмета."; return false
	if _ask(&"ActionGetRequested",{"entity":HERO}).get("found",false): message="Дождитесь завершения действия."; return false
	var item = items[absolute]
	if not item is StringName: return false
	return _begin_drop_pick("inventory",item,false)

func _begin_drop_pick(slot: String, item: StringName, queued: bool) -> bool:
	var body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
	if not body.get("found",false): return false
	var center: Vector2 = Vector2(body["data"]["anchor"]) + Vector2.ONE * float(body["data"]["size"]) * 0.5
	_drop_pick = {"slot":slot,"item":item,"tile":Vector2i(floori(center.x),floori(center.y)),"queued":queued}
	_drop_pick_message()
	return true
func _drop_pick_message() -> void:
	var check := _ask(&"LootDropTileCheckRequested", {"entity":HERO,"tile":_drop_pick["tile"]})
	message = "Выберите клетку мышью или стрелками, Положить/F, Отмена/Esc. " + ("Можно." if check.get("valid",false) else "Недоступно.")
	queue_redraw()
func _drop_pick_input(event: InputEventKey) -> void:
	var delta := Vector2i.ZERO
	match event.keycode:
		KEY_UP,KEY_W: delta=Vector2i.UP
		KEY_DOWN,KEY_S: delta=Vector2i.DOWN
		KEY_LEFT,KEY_A: delta=Vector2i.LEFT
		KEY_RIGHT,KEY_D: delta=Vector2i.RIGHT
		KEY_ESCAPE:
			if _drop_pick.get("queued",false): _twohand_queue.clear()
			_drop_pick.clear(); message = "Выбрасывание отменено."; queue_redraw(); return
		KEY_F:
			var slot: String = _drop_pick["slot"]
			var item: StringName = _drop_pick["item"]
			var tile: Vector2i = _drop_pick["tile"]
			var queued: bool = _drop_pick["queued"]
			if slot == "inventory":
				var drop := _ask(&"LootInventoryDropRequested",{"entity":HERO,"item":item,"tile":tile})
				if drop.get("accepted",false):
					_drop_pick.clear(); _drop_mode = false
					message = "Выбрасываем предмет: 0,1 с."
				else: message = "Нельзя выбросить: предмет или клетка недоступны."
				queue_redraw(); return
			if queued: _twohand_queue["stage"] = "running"
			_twohand_busy = true
			var request := _ask(&"EquipmentUnequipRequested", {"entity":HERO,"slot":slot,"drop_tile":tile})
			_twohand_busy = false
			if request.get("accepted",false):
				_drop_pick.clear(); message = "Снимаем предмет на землю: 0,1 с."
			else:
				if queued: _twohand_queue["stage"] = "choose"
				message = "Нельзя положить: " + str(request.get("error","клетка недоступна"))
			queue_redraw(); return
		_: return
	_drop_pick["tile"] += delta
	_drop_pick_message()

func _twohand_changed(event: Dictionary) -> void:
	if event.get("entity",null) != HERO or _twohand_queue.get("stage","") != "running" or event.get("item",null) != _twohand_queue.get("item",null) or event.get("slot",null) != _twohand_queue.get("slot",null): return
	if _twohand_queue["action"] == &"equipment_equip":
		_twohand_queue.clear(); message = "Двуручное оружие надето."
	else:
		_twohand_queue.merge({"stage":"ready","item":&"","slot":"","action":&""},true)
		message = "Продолжаем смену оружия."
	queue_redraw()
func _twohand_failed(event: Dictionary) -> void:
	if event.get("entity",null) == HERO and _twohand_queue.get("stage","") == "running" and event.get("item",null) == _twohand_queue.get("item",null):
		_twohand_queue.clear(); message = "Смена оружия остановлена: перенос не завершён."; queue_redraw()

func _inspect_select(index: int) -> bool:
	if not initialized or is_dead or is_won or not inventory_open or not inspect_mode or index < 0 or index >= 9: return false
	var id: Variant = null
	if equipment_view:
		var n := equipment_page * 9 + index
		if n < EQUIPMENT_SLOTS.size():
			var gear := _ask(&"ComponentGetRequested", {"entity":HERO,"component":&"equipment"})
			id = gear.get("data",{}).get(EQUIPMENT_SLOTS[n],null)
	else:
		var items := _inventory_items()
		_clamp_inventory_page(items)
		var n := inventory_page * 9 + index
		if n < items.size(): id = items[n]
	if not id is StringName or id == &"":
		message = "В этой строке нет предмета."
		queue_redraw()
		return false
	inspect_item = id
	inspect_page = 0
	queue_redraw()
	return true

func _change_inspect_page(delta: int) -> void:
	var count := _inspection_lines(inspect_item).size() if inspect_item != &"" else 0
	var max_page := maxi(0,ceili(float(count)/float(INSPECTION_PAGE_SIZE))-1)
	inspect_page = clampi(inspect_page+delta,0,max_page)
	queue_redraw()

# Текст содержит только уже раскрытые моды; нерегистрируемых подробностей
# и количества ещё скрытых модов интерфейс не показывает.
func _inspection_lines(id: StringName) -> Array:
	var items := _inventory_items()
	var gear := _ask(&"ComponentGetRequested", {"entity":HERO,"component":&"equipment"})
	var slots: Dictionary = gear.get("data",{})
	if not items.has(id) and not slots.values().has(id): return ["Предмет больше недоступен."]
	var item := _ask(&"ItemGetRequested", {"item":id})
	if not item.get("found",false): return ["Предмет больше недоступен."]
	var data: Dictionary = item.get("item_data",{})
	var lines: Array = [str(item.get("base",{}).get("name",id)), "Уровень предмета: %s" % str(data.get("item_level","—"))]
	var category := str(item.get("base",{}).get("slot",""))
	if category == "weapon":
		lines.append_array(_weapon_inspection_lines(id,item))
	elif category in ["shield","head","body","hands","belt","legs","feet"]:
		lines.append_array(_defence_inspection_lines(id,item,slots.values().has(id)))
	if not data.get("learning",null) is Dictionary or not data.get("learning_state",null) is Dictionary:
		lines.append("Без системы изучения.")
		return lines
	var schema: Dictionary = data["learning"]
	var state: Dictionary = data["learning_state"]
	var mods = data.get("mods",null)
	if not mods is Array: return ["Не удалось прочитать свойства предмета."]
	var projected: Dictionary = DungeonChestLearningService._evaluate(schema,state,mods,false)
	if not projected.get("valid",false): return ["Не удалось прочитать свойства предмета."]
	lines.append("Опознано" if projected["globally_identified"] else "Не опознано · требуется INT %s" % str(data.get("int_req","—")))
	lines.append("Изучение: %s / %s" % [str(state["progress"]),str(schema["full_progress"])])
	lines.append("Раскрытые моды:")
	var active: Array = projected["active_mods"]
	var shown := 0
	for mod in mods:
		if not mod is Dictionary or StringName(str(mod.get("id",""))) not in active: continue
		var suffix := "" if str(mod.get("id","")) in DungeonChestModCatalogService.LIVE_EFFECT_IDS else " (эффект не подключён)"
		var value := float(mod.get("value",0))
		var stat := str(mod.get("stat","?"))
		var label := str({"armor":"Броня", "max_hp":"Макс. HP", "max_stamina":"Макс. выносливость", "max_mp":"Макс. мана"}.get(stat,stat))
		lines.append("%s: %s%s%s" % [label, "+" if value > 0 else "", str(value),suffix])
		shown += 1
	if shown == 0: lines.append("Пока нет раскрытых модов.")
	return lines

# Вклад вещи рассчитывается теми же правилами, что броня экипировки.
# Прогноз вещи в рюкзаке использует текущие статы, без переодевания.
func _defence_inspection_lines(id: StringName, item: Dictionary, equipped: bool) -> Array:
	var base: Dictionary = item.get("base",{})
	var data: Dictionary = item.get("item_data",{})
	var category := str(base.get("slot",""))
	var result: Array = ["Тип: щит" if category == "shield" else "Тип: броня · %s" % str({"head":"голова","body":"тело","hands":"руки","belt":"пояс","legs":"ноги","feet":"ступни"}.get(category,category))]
	var armour := 0.0
	var valid := data.get("materials",null) is Array
	if valid:
		for stack in data["materials"]:
			if not stack is Dictionary: valid = false; break
			var material := _ask(&"MaterialGetRequested", {"material":StringName(str(stack.get("material_id","")))})
			if not material.get("found",false): valid = false; break
			armour += float(material["data"].get("armor_per_unit",0.0)) * int(stack.get("count",0))
	var factor: Dictionary = DungeonChestLearningService.equipped_base_multiplier(HERO,data)
	var bonus: Dictionary = DungeonChestLearningService.equipped_armour_mod_bonus(HERO,data,base)
	if valid and factor.get("valid",false) and bonus.get("valid",false):
		result.append("Броня материалов: %.2f" % armour)
		result.append("Вклад в броню: %.2f" % (armour * float(factor["multiplier"]) + float(bonus["bonus"])))
		if float(factor["multiplier"]) < 1.0: result.append("База после штрафа изучения: %.0f%%" % (100.0*float(factor["multiplier"])))
		if not equipped: result.append("Прогноз по текущим статам, без переодевания")
	else: result.append("Расчёт брони недоступен")
	var weight := _ask(&"ItemWeightRequested", {"item":id})
	var volume := _ask(&"ItemVolumeRequested", {"item":id})
	if weight.get("found",false): result.append("Вес: %.2f кг" % float(weight["weight_kg"]))
	if volume.get("found",false): result.append("Объём: %.2f" % float(volume["volume"]))
	if category == "shield":
		var width = base.get("shield_block_width",null)
		if (width is int or width is float) and is_finite(float(width)) and float(width) == floorf(float(width)) and int(width) in [1,2,4]: result.append("Ширина блока: %d физ. клеток" % int(width))
		result.append("Блок: 0,5 с · продление B")
		result.append("Поглощает физический урон за Stamina")
	return result

# Прогноз опирается на тот же удар и те же сервисы, что игровая атака;
# он не раскрывает скрытых модов и не предполагает будущую экипировку.
func _weapon_inspection_lines(id: StringName, item: Dictionary) -> Array:
	var result: Array = []
	var resolved := _ask(&"WeaponItemResolveRequested", {"item":id})
	var list := _ask(&"WeaponStrikesGetRequested", {"item":id})
	if not resolved.get("found",false) or not list.get("found",false): return ["Характеристики оружия недоступны."]
	var w: Dictionary = resolved["data"]
	var kind := str(w.get("type",""))
	var names := {"sword":"меч","hammer":"молот","bow":"лук"}
	var hands := "двуручное" if w.get("tags",[]).has("two_handed") else "одноручное"
	result.append("Тип: %s · %s" % [names.get(kind,kind),hands])
	var variant := str(w.get("id",""))
	var strike_id := "bow_simple_shot" if kind == "bow" and variant == "bow_simple_variant" else str(DEMO_STRIKES.get(variant,""))
	var strike: Dictionary = {}
	for row in list.get("strikes",[]):
		if str(row.get("id","")) == strike_id: strike = row; break
	if strike_id.is_empty() or strike.is_empty():
		result.append("Для этого оружия атака героя недоступна.")
		return result
	result.append("Атака: %s" % str(strike.get("name","—")))
	result.append("Базовый урон: %s" % str(strike.get("damage","—")))
	var damage := _ask(&"BowShotDamagePreviewRequested" if kind == "bow" else &"WeaponStrikeDamagePreviewRequested", {"entity":HERO,"item":id,"strike":strike_id})
	if damage.get("accepted",false):
		var d: Dictionary = damage["data"]
		result.append("Расчёт урона: %.2f · %s (без Stamina, защиты и крита)" % [float(d["nonnegative_damage"]),str(d["stat"])])
	else: result.append("Урон сейчас: недоступен")
	var zone: Dictionary = strike.get("zone",{})
	if kind == "bow":
		var reach = ProjectileService.effective_projectile_parameters("bow").get("range","—")
		result.append("Дальность стрелы: %s клеток от выпуска" % str(reach))
	else:
		var effective := {"weapon_type":kind,"range":strike.get("range",0)}
		WeaponStrikeService.adjust_attack_zone(effective,strike)
		var inner = effective.get("gap",0)
		var outer := float(inner)+float(effective.get("range",0))
		if zone.get("type","") == "arc": result.append("Зона: от %s до %s клеток · дуга %s°" % [str(inner),str(outer),str(zone.get("angle_degrees","—"))])
		elif zone.get("type","") == "line": result.append("Зона: от %s до %s · линия, ширина %s" % [str(inner),str(outer),str(zone.get("width","—"))])
		else: result.append("Зона: от %s до %s клеток" % [str(inner),str(outer)])
	var cost := _ask(&"WeaponStrikeStaminaPreviewRequested", {"entity":HERO,"item":id,"strike":strike_id})
	if cost.get("accepted",false):
		var c: Dictionary = cost["data"]
		result.append("Полная стоимость: %s Stamina" % str(c["full_cost"]))
		if c.get("can_start",false):
			result.append("Время сейчас: %.2f с · урон от Stamina: %.0f%%" % [float(c["duration"]),float(c["damage_multiplier"])*100.0])
		else: result.append("Недостаточно Stamina для атаки.")
	else: result.append("Стоимость и время: недоступны")
	if kind == "bow": result.append("Стрелы не расходуются.")
	if not bool(damage.get("data",{}).get("in_hand",false)):
		result.append("В инвентаре: расчёт по текущим статам и весу.")
	return result

func _identify_inventory_item(index: int) -> bool:
	if not initialized or is_dead or is_won or not inventory_open or equipment_view or not identify_mode or index < 0 or index >= 9: return false
	var items := _inventory_items()
	_clamp_inventory_page(items)
	index += inventory_page * 9
	if index >= items.size():
		message = "В этой строке нет предмета."
		queue_redraw()
		return false
	var item := _ask(&"ItemGetRequested", {"item":items[index]})
	if not item.get("found",false):
		message = "Предмет недоступен."
		queue_redraw()
		return false
	var request := _ask(&"ItemLearningIdentifyRequested", {"entity":HERO,"item":items[index]})
	message = "Опознаём %s: 1 с." % item["base"].get("name","предмет") if request.get("accepted",false) else "Нельзя опознать: " + str(request.get("error","другое действие выполняется"))
	queue_redraw()
	return request.get("accepted",false)
func _identify_completed(event: Dictionary) -> void:
	if event.get("entity",null) != HERO: return
	var item := _ask(&"ItemGetRequested", {"item":event.get("item",null)})
	message = "Опознан предмет: " + str(item.get("base",{}).get("name","предмет"))
	queue_redraw()
func _identify_failed(event: Dictionary) -> void:
	if event.get("entity",null) != HERO: return
	message = "Опознание не завершено: " + str(event.get("reason","ошибка"))
	queue_redraw()

func _unequip_equipment_row(index: int) -> bool:
	if not equipment_view or index < 0 or index >= 9: return false
	var slot_index := equipment_page * 9 + index
	if slot_index >= EQUIPMENT_SLOTS.size():
		message = "В этой строке нет слота."
		queue_redraw()
		return false
	return _unequip_slot(EQUIPMENT_SLOTS[slot_index])
func _unequip_hand(slot: String) -> bool:
	if slot not in ["main", "off"]: return false
	return _unequip_slot(slot)
func _unequip_slot(slot: String) -> bool:
	if not initialized or is_dead or not inventory_open or slot not in EQUIPMENT_SLOTS: return false
	var request := _ask(&"EquipmentUnequipRequested", {"entity":HERO, "slot":slot})
	if request.get("needs_drop_tile",false):
		var gear := _ask(&"ComponentGetRequested", {"entity":HERO,"component":&"equipment"})
		var item = gear.get("data",{}).get(slot,null)
		if item is StringName and _begin_drop_pick(slot,item,false): return true
	message = "Снимаем предмет: 0,1 с." if request.get("accepted", false) else "Нельзя снять: " + str(request.get("error","слот пуст или идёт действие"))
	queue_redraw()
	return request.get("accepted", false)

func _consumable_completed(event: Dictionary) -> void:
	if event.get("entity", &"") != HERO: return
	message = "Расходник применён." if event.get("success", false) else "Не удалось применить расходник."
	queue_redraw()

func _toggle_inventory() -> bool:
	_clear_held_input()
	if is_dead: return false
	_direction_action = ""
	_cancel_mouse_path()
	var request := _ask(&"MenuTransitionRequested", {"entity":HERO, "menu":"inventory", "operation":"close" if inventory_open else "open"})
	if not request.get("accepted", false): message = "Дождитесь завершения текущего действия."
	return request.get("accepted", false)
func _menu_completed(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO and event.get("menu", "") == "inventory":
		inventory_open = event.get("operation", "") == "open"
		if not inventory_open: inspect_mode = false; inspect_item = &""; stats_view = false; _drop_mode = false
		message = "Инвентарь открыт." if inventory_open else "Инвентарь закрыт."
func _progression_get(event: Dictionary) -> void:
	if not initialized or event.get("entity",null) != HERO: return
	event["found"] = true
	event["data"] = {"level":hero_level,"xp":hero_xp,"next_xp":hero_level*XP_PER_LEVEL_FACTOR,"points":hero_points}

func _open_stats() -> void:
	_direction_action = ""
	if not initialized or is_dead or is_won or not _drop_pick.is_empty() or not _twohand_queue.is_empty(): return
	if not inventory_open and not _toggle_inventory(): return
	stats_view = true
	inspect_mode = false; identify_mode = false; inspect_item = &""
	queue_redraw()

func _allocate_stat(index: int) -> bool:
	if not initialized or is_dead or is_won or not inventory_open or not stats_view or _stat_allocation_busy or not _twohand_queue.is_empty() or not _drop_pick.is_empty() or hero_points <= 0 or index < 0 or index >= PROGRESSION_STATS.size(): return false
	if _ask(&"ActionGetRequested", {"entity":HERO}).get("found",false):
		message = "Дождитесь завершения действия."; queue_redraw(); return false
	var stat: StringName = PROGRESSION_STATS[index]
	var before := _ask(&"StatGetRequested", {"entity":HERO,"stat":stat})
	if not before.get("found",false): return false
	_stat_allocation_busy = true
	# Резервируем очко до события StatChanged, чтобы повторный вход не потратил его дважды.
	hero_points -= 1
	var result := _ask(&"StatBaseSetRequested", {"entity":HERO,"stat":stat,"value":before["base"]+1})
	if not result.get("accepted",false): hero_points += 1
	_stat_allocation_busy = false
	message = "%s +1" % stat if result.get("accepted",false) else "Не удалось повысить характеристику."
	queue_redraw()
	return result.get("accepted",false)

func _entity_died(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO:
		_direction_action = ""
		_clear_held_input()
	if event.get("entity", &"") != HERO and event.get("killer",null) == HERO and not is_dead and not is_won and hero_level < MAX_HERO_LEVEL:
		hero_xp += XP_PER_KILL
		if hero_xp >= hero_level*XP_PER_LEVEL_FACTOR:
			hero_xp -= hero_level*XP_PER_LEVEL_FACTOR
			hero_level += 1
			hero_points += POINTS_PER_LEVEL
			message = "Уровень %d! Доступно очков: %d." % [hero_level,hero_points]
		else: message = "+%d опыта." % XP_PER_KILL
		if event.get("entity",null) == RAT: message += " Трофей: E."
		queue_redraw()
	if event.get("entity", &"") == HERO:
		_twohand_queue.clear()
		_drop_pick.clear()
		_pickup_open = false; _pickup_queue.clear(); _pickup_queue_running=false; _pickup_inflight=&""; _drop_mode = false
		is_dead = true
		_restart_button.visible = true
		_restart_button.disabled = not _fresh_available
		message = "Вы погибли."
		if FileAccess.file_exists(SaveService.DEMO_SESSION_PATH):
			var err := DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveService.DEMO_SESSION_PATH))
			if err != OK: message = "Вы погибли; не удалось удалить демо-сохранение."
	elif event.get("entity", &"") == RAT and event.get("killer",null) != HERO:
		message = "Крыса повержена. Подберите трофей клавишей E."
func _damaged(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO: message = "Вас ранили: −%.0f HP." % float(event.get("amount", 0.0))
func _chest_opened(event: Dictionary) -> void:
	if event.get("entity",null) != HERO: return
	var chest := _ask(&"ObjectContainerGetRequested", {"entity":HERO,"object":event.get("object",null)})
	var count: int = chest.get("inventory",{}).get("items",[]).size()
	message = "Сундук пуст." if count == 0 else "Сундук открыт: %d предметов. F — выбрать предмет." % count
func _chest_take_completed(event: Dictionary) -> void:
	if event.get("entity",null) == HERO:
		message = "Предмет в инвентаре."
		_pickup_finished(event.get("item",&""),true)
func _chest_take_failed(event: Dictionary) -> void:
	if event.get("entity",null) == HERO:
		message = "Перенос из сундука не завершён: " + str(event.get("reason","прерван"))
		_pickup_finished(event.get("item",&""),false)
func _loot_dropped(event: Dictionary) -> void:
	if event.get("entity",null) == HERO: message = "Предмет оставлен на земле."; queue_redraw()
func _inventory_drop_failed(event: Dictionary) -> void:
	if event.get("entity",null) == HERO: message = "Выбрасывание не завершено: " + str(event.get("reason","прервано")); queue_redraw()
func _picked_up(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO:
		message = "Трофей в инвентаре."
		_pickup_finished(event.get("item",&""),true)
func _pickup_failed(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO:
		message = "Не удалось поднять предмет."
		_pickup_finished(event.get("item",&""),false)
func _room_changed(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO:
		current_room = event.get("room", ROOM)
		if initialized:
			message = _spawn_errors[current_room] + ". Повтор: R." if _spawn_errors.has(current_room) else "Вы вошли в новую комнату."
			_spawn_generation += 1
			call_deferred("_spawn_current",_spawn_generation,false)
func _spawn_map_reset(_event: Dictionary) -> void:
	_map_memory.clear()
	_spawn_errors.clear()
	_spawn_generation += 1
func _enemy_setup_failed(event: Dictionary) -> void:
	var id = event.get("entity",null)
	var spawn := _ask(&"ComponentGetRequested", {"entity":id,"component":&"spawn"})
	if spawn.get("data",{}).get("room",null) == current_room:
		message = "Не удалось подготовить врага: " + str(event.get("error","")) + ". Повтор: R."
		queue_redraw()
func _spawn_current(generation: int, retry: bool) -> void:
	if generation != _spawn_generation or not is_inside_tree() or not initialized or is_dead or _spawning or current_room == ROOM: return
	var current := _ask(&"RoomCurrentGetRequested",{})
	if current.get("entity",null) != HERO or current.get("room",null) != current_room or current.get("transitioning",true): return
	var status := _ask(&"RoomSpawnStatusRequested", {"room":current_room})
	if status.get("spawned",false): return
	if _spawn_errors.has(current_room) and not retry: return
	var track := _ask(&"DungeonFloorTrackingGetRequested",{})
	if track.get("found",false) and track.get("data",{}).get("boss_candidate",null) == current_room: return
	var portal := _ask(&"DungeonPortalRoomCheckRequested", {"room":current_room})
	if not portal.get("accepted",false) or portal.get("protected",false): return
	var depth := _ask(&"DungeonRoomDepthRequested", {"room":current_room})
	var body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
	if not depth.get("accepted",false) or not body.get("found",false):
		_spawn_errors[current_room] = "Глубина комнаты или тело игрока недоступны"
		message = "Спавн не выполнен: " + _spawn_errors[current_room] + ". Повтор: R."
		return
	var room: StringName = current_room
	_spawning = true
	var request := _ask(&"RoomSpawnRequested", {"room":room,"player":HERO,"entry_tile":body["data"]["anchor"],"depth":depth["depth"],"demo_pool":true,"demo_melee":true,"queue_delay":0.1})
	_spawning = false
	if request.get("accepted",false):
		_spawn_errors.erase(room)
		message = "Комната заселена: %d, в очереди: %d." % [request.get("units",[]).size(),request.get("queue_count",0)]
	else:
		_spawn_errors[room] = str(request.get("error","неизвестная ошибка")).substr(0,1000)
		message = "Спавн не выполнен: " + _spawn_errors[room] + ". Повтор: R."
	queue_redraw()
func _retry_spawns() -> void:
	var normal_retry := _ask(&"DungeonNormalChestAutoRetryRequested", {})
	if normal_retry.get("accepted",false): message = "Повторяем создание обычного сундука."
	var tracking := _ask(&"DungeonFloorTrackingGetRequested", {})
	if tracking.get("found",false) and tracking["data"].get("boss_candidate",null) == current_room:
		var boss := _ask(&"DungeonBossGetRequested", {})
		if not boss.get("found",false):
			var spawn_retry := _ask(&"DungeonBossAutoSpawnRetryRequested", {"entity":HERO})
			if spawn_retry.get("accepted",false): _spawn_errors.erase(current_room)
			message = "Босс появился." if spawn_retry.get("accepted",false) else "Босс не появился: " + str(spawn_retry.get("error","ошибка")) + ". Повтор: R."
			queue_redraw()
			return
		var equipment := _ask(&"DungeonBossEquipmentAutoStatusRequested", {})
		if equipment.get("status","") == "failed":
			var equip_retry := _ask(&"DungeonBossEquipmentAutoRetryRequested", {"entity":equipment.get("entity",null)})
			message = "Босс оснащён." if equip_retry.get("accepted",false) else "Не удалось оснастить босса: " + str(equip_retry.get("error","ошибка")) + ". Повтор: R."
			queue_redraw()
			return
		var ai := _ask(&"DungeonBossMeleeAIStatusRequested", {})
		if ai.get("status","") == "failed":
			var ai_retry := _ask(&"DungeonBossMeleeAIRetryRequested", {})
			message = "ИИ босса подготовлен." if ai_retry.get("accepted",false) else "Не удалось подготовить ИИ босса: " + str(ai_retry.get("error","ошибка")) + ". Повтор: R."
			queue_redraw()
			return
	var portal := _ask(&"DungeonPortalGetRequested", {})
	if portal.get("found",false) and portal["data"].get("status","") == "failed" and tracking.get("found",false) and current_room in [tracking["data"].get("boss_candidate",null),portal["data"].get("room",null)]:
		var portal_retry := _ask(&"DungeonPortalPlacementRetryRequested", {})
		message = "Портал размещён." if portal_retry.get("accepted",false) else "Портал не размещён. Повтор: R."
		queue_redraw()
		return
	var chest := _ask(&"DungeonBossChestAutoStatusRequested", {})
	if chest.get("status","") == "failed" and chest.get("room",null) == current_room:
		var retry := _ask(&"DungeonBossChestAutoRetryRequested", {"room":current_room})
		message = "Ищем место для сундука босса." if retry.get("accepted",false) else "Повтор размещения сундука не выполнен: " + str(retry.get("error",""))
		queue_redraw()
		return
	if _spawn_errors.has(current_room):
		_spawn_current(_spawn_generation,true)
		return
	var state := _ask(&"RoomSpawnStatusRequested", {"room":current_room})
	var ids: Array = state.get("data",{}).get("placed",[])
	for id in ids:
		var status := _ask(&"DemoMeleeSetupStatusRequested", {"entity":id})
		if status.get("status","") == "failed":
			var retry := _ask(&"DemoMeleeSetupRetryRequested", {"entity":id})
			message = "Враг подготовлен." if retry.get("accepted",false) else "Повтор не выполнен: " + str(retry.get("error",""))
			queue_redraw()
			return
	if not normal_retry.get("accepted",false): message = "Нет спавна, ожидающего повтора."
	queue_redraw()

func _txt(text: String, at: Vector2, font_size: int, color: Color, width: float = -1) -> void:
	draw_string(ThemeDB.fallback_font, at, text, HORIZONTAL_ALIGNMENT_LEFT, width, font_size, color)
func _line(a: Vector2, b: Vector2, color: Color, w: float = 1.0) -> void:
	draw_line(a, b, color, w, true)
func _panel(rect: Rect2, fill: Color, stroke: Color) -> void:
	draw_rect(rect, fill)
	draw_rect(rect, stroke, false, 1.0)
# Подсказка только для видимого атакующего до середины удара; это прогноз,
# а не сохранённый боевой пакет: геометрия может измениться до попадания.
# Событие соответствует шагу удара, а короткий след нужен только для
# читаемости: он не означает, что удар всё ещё можно заблокировать.
func _strike_midpoint(event: Dictionary) -> void:
	var actor = event.get("entity",null)
	var data = event.get("data",null)
	if not actor is StringName or not data is Dictionary: return
	if actor != HERO:
		var fog := _ask(&"FogStateGetRequested", {})
		var visible := {}
		for tile in fog.get("visible_tiles",[]): visible[tile] = true
		var body := _ask(&"SpaceBodyGetRequested", {"entity":actor})
		if not body.get("found",false): return
		var bd: Dictionary = body["data"]
		var shown := false
		for y in range(bd["anchor"].y,bd["anchor"].y+int(bd["size"])):
			for x in range(bd["anchor"].x,bd["anchor"].x+int(bd["size"])):
				if visible.has(Vector2i(x,y)): shown = true; break
			if shown: break
		if not shown: return
	var zone := _ask(&"WeaponStrikePreviewRequested", {"entity":actor,"item":data.get("item",null),"strike":data.get("strike",null),"direction":data.get("direction",null),"kind":"physical"})
	if not zone.get("accepted",false): return
	_strike_flashes[actor] = {"tiles":zone["zone"]["tiles"].duplicate(),"expires":Time.get_ticks_msec()+STRIKE_FLASH_MS}
	queue_redraw()

func _strike_before_hit(actor: StringName) -> bool:
	var action := _ask(&"ActionGetRequested", {"entity":actor})
	var id = action.get("data",{}).get("id",null)
	if not action.get("found",false) or id not in [ATTACK,BOW_SHOT]: return false
	var status := _ask(&"BowShotStatusRequested" if id == BOW_SHOT else &"WeaponStrikeActionStatusRequested", {"entity":actor})
	if not status.get("active",false): return false
	var midpoint := float(ceili(float(status["data"]["duration_steps"])/2.0))*0.01
	return float(action["data"].get("elapsed",0)) + 0.0000001 < midpoint

func _enemy_windup_tiles(actor: StringName, visible: Dictionary) -> Array:
	if actor == HERO or actor == &"": return []
	var body := _ask(&"SpaceBodyGetRequested", {"entity":actor})
	if not body.get("found",false): return []
	var anchor: Vector2i = body["data"]["anchor"]
	var body_size: int = body["data"]["size"]
	var shown := false
	for y in range(anchor.y,anchor.y+body_size):
		for x in range(anchor.x,anchor.x+body_size):
			if visible.has(Vector2i(x,y)): shown = true; break
		if shown: break
	if not shown: return []
	var action := _ask(&"ActionGetRequested", {"entity":actor})
	var action_id = action.get("data",{}).get("id",null)
	if not action.get("found",false) or action_id not in [ATTACK,BOW_SHOT]: return []
	var status := _ask(&"BowShotStatusRequested" if action_id == BOW_SHOT else &"WeaponStrikeActionStatusRequested", {"entity":actor})
	if not status.get("active",false): return []
	var data: Dictionary = status["data"]
	var midpoint: float = float(ceili(float(data["duration_steps"])/2.0)) * 0.01
	if float(action["data"].get("elapsed",0)) + 0.0000001 >= midpoint: return []
	var tiles: Array = []
	if action_id == BOW_SHOT:
		tiles = _bow_aim_tiles(Vector2(data["direction"]),actor)
	else:
		var preview := _ask(&"WeaponStrikePreviewRequested", {"entity":actor,"item":data["item"],"strike":data["strike"],"direction":data["direction"],"kind":"physical"})
		if not preview.get("accepted",false): return []
		tiles = preview.get("zone",{}).get("tiles",[])
	var result: Array = []
	for tile in tiles:
		if tile is Vector2i and visible.has(tile): result.append(tile)
	return result

# Индекс фрагмента фиксирован по координатам физического тайла и этажу.
# Это только визуальный хеш, он не расходует игровой генератор случайностей.
# Полосы являются только проекцией DetectionDetailsService: обнаружение,
# враждебность и пороги PER проверяет этот сервис, зрение — отдельно здесь.
func _enemy_display_details(actor: StringName, visible: Dictionary) -> Dictionary:
	if actor == HERO or actor == &"": return {}
	var body := _ask(&"SpaceBodyGetRequested", {"entity":actor})
	if not body.get("found",false): return {}
	var data: Dictionary = body["data"]
	var is_visible := false
	for y in range(data["anchor"].y,data["anchor"].y+int(data["size"])):
		for x in range(data["anchor"].x,data["anchor"].x+int(data["size"])):
			if visible.has(Vector2i(x,y)):
				is_visible = true
				break
		if is_visible: break
	if not is_visible: return {}
	var details := _ask(&"DetectionDetailsGetRequested", {"observer":HERO,"target":actor})
	return details.get("data",{}) if details.get("found",false) else {}

func _draw_enemy_status(actor: StringName, visible: Dictionary, center: Vector2, body_size: int) -> void:
	var details := _enemy_display_details(actor,visible)
	if details.is_empty(): return
	var width := clampf(float(body_size)*STEP_PX*0.8,32,90)
	var pos := center - Vector2(width*0.5,float(body_size)*STEP_PX*0.5+12)
	if details.get("hp",null) is Dictionary:
		var hp: Dictionary = details["hp"]
		var maximum := float(hp.get("max",0))
		if maximum > 0.0 and is_finite(maximum):
			draw_rect(Rect2(pos,Vector2(width,5)),Color("0b1013e8"))
			draw_rect(Rect2(pos,Vector2(width*clampf(float(hp.get("current",0))/maximum,0,1),5)),Color("c97162"))
			pos.y -= 7
	var action = details.get("action",null)
	if action is Dictionary and action.get("active",false) and action.has("progress"):
		draw_rect(Rect2(pos,Vector2(width,3)),Color("0b1013e8"))
		draw_rect(Rect2(pos,Vector2(width*clampf(float(action["progress"]),0,1),3)),Color("e9b85a"))

func _art_tile_source(tile: Vector2i, floor_index: int, is_floor: bool) -> Rect2:
	var n: int = tile.x * 73856093 ^ tile.y * 19349663 ^ (floor_index + 1) * 83492791
	if is_floor: n ^= 0x1b873593
	n = (n ^ (n >> 13)) & 0x7fffffff
	n *= 1274126177
	n = n ^ (n >> 16)
	var index := posmod(n,256)
	return Rect2(Vector2((index % 16)*8, int(index / 16)*8),Vector2(8,8))

# Обновляем только наблюдаемые клетки. Динамические персонажи и снаряды
# намеренно не запоминаются: их положение после потери видимости неизвестно.
func _memory_changed(_event: Dictionary) -> void:
	if initialized: _remember_visible()

func _remember_visible(tiles: Array = []) -> void:
	if not initialized: return
	if tiles.is_empty(): tiles = _ask(&"FogStateGetRequested",{}).get("visible_tiles",[])
	if tiles.is_empty(): return
	var map := _ask(&"SpaceMapGetRequested",{})
	if not map.get("configured",false): return
	var map_size: Vector2i = map["size"]
	var valid := {}
	var lo := map_size
	var hi := Vector2i(-1,-1)
	for tile in tiles:
		if not tile is Vector2i or tile.x < 0 or tile.y < 0 or tile.x >= map_size.x or tile.y >= map_size.y: continue
		valid[tile] = true
		lo = Vector2i(mini(lo.x,tile.x),mini(lo.y,tile.y))
		hi = Vector2i(maxi(hi.x,tile.x),maxi(hi.y,tile.y))
	if valid.is_empty(): return
	var area := _ask(&"SpaceRegionGetRequested",{"origin":lo,"size":hi-lo+Vector2i.ONE})
	if not area.get("accepted",false): return
	var visible_objects := {}
	for object in _ask(&"ObjectVisualsGetRequested",{}).get("objects",[]):
		var tile: Vector2i = object["tile"]
		if not valid.has(tile): continue
		var flags := int(visible_objects.get(tile,0))
		match str(object["type"]):
			"chest": flags |= MEM_CHEST | (MEM_CHEST_OPEN if object.get("opened",false) else 0)
			"stairs_down": flags |= MEM_STAIRS
			"portal_exit": flags |= MEM_PORTAL
		visible_objects[tile] = flags
	for item in _ask(&"LootGetRequested",{}).get("items",{}).values():
		var tile = item.get("tile",null)
		if tile is Vector2i and valid.has(tile): visible_objects[tile] = int(visible_objects.get(tile,0)) | MEM_LOOT
	var floors: Dictionary = area["floor"]
	var passages: Dictionary = area["passages"]
	for tile in valid:
		_map_memory[tile] = (MEM_FLOOR if floors.has(tile) else 0) | (MEM_PASSAGE if passages.has(tile) else 0) | int(visible_objects.get(tile,0))

func _draw_memory_features(tile: Vector2i, flags: int, origin: Vector2) -> void:
	var p := origin + Vector2(tile)*STEP_PX
	if flags & MEM_PASSAGE: draw_rect(Rect2(p,Vector2.ONE*STEP_PX),Color("aaaaaa22"))
	if flags & MEM_CHEST:
		draw_rect(Rect2(p+Vector2(1,3),Vector2(18,14)),Color("747474"))
		draw_rect(Rect2(p+Vector2(1,3),Vector2(18,14)),Color("b0b0b0"),false,1.5)
		_line(p+Vector2(2,9),p+Vector2(18,9),Color("b0b0b0"),1)
		if flags & MEM_CHEST_OPEN: draw_circle(p+Vector2(10,10),2,Color("303030"))
	if flags & MEM_STAIRS:
		draw_rect(Rect2(p,Vector2.ONE*STEP_PX),Color("777777"))
		for row in range(3): _line(p+Vector2(3,5+row*5),p+Vector2(17,5+row*5),Color("c5c5c5"),1.5)
	if flags & MEM_PORTAL:
		draw_circle(p+Vector2.ONE*10,10,Color("777777"))
		draw_arc(p+Vector2.ONE*10,10,0,TAU,24,Color("b5b5b5"),2.0,true)
	if flags & MEM_LOOT:
		var c := p+Vector2.ONE*10
		draw_colored_polygon(PackedVector2Array([c+Vector2(0,-6),c+Vector2(6,0),c+Vector2(0,6),c+Vector2(-6,0)]),Color("b0b0b0"))

# Рисуем только видимые фрагменты тела, чтобы спрайт крупного противника
# не заходил в скрытые за стеной клетки.
func _draw_visible_sprite(texture: Texture2D, rect: Rect2, origin: Vector2, anchor: Vector2i, body_size: int, visible: Dictionary) -> void:
	if texture == null: return
	var source_size: Vector2 = texture.get_size()
	for y in range(anchor.y,anchor.y+body_size):
		for x in range(anchor.x,anchor.x+body_size):
			var tile := Vector2i(x,y)
			if not visible.has(tile): continue
			var part := rect.intersection(Rect2(origin+Vector2(tile)*STEP_PX,Vector2.ONE*STEP_PX))
			if not part.has_area(): continue
			var source := Rect2((part.position-rect.position)/rect.size*source_size,part.size/rect.size*source_size)
			draw_texture_rect_region(texture,part,source)

func _body_all_visible(anchor: Vector2i, body_size: int, visible: Dictionary) -> bool:
	for y in range(anchor.y,anchor.y+body_size):
		for x in range(anchor.x,anchor.x+body_size):
			if not visible.has(Vector2i(x,y)): return false
	return true

func _draw() -> void:
	var s := size
	if s.x < 700 or s.y < 500: return
	var bg := Color("0c1216")
	var pale := Color("e7e8dd")
	var muted := Color("879390")
	var gold := Color("e9b85a")
	draw_rect(Rect2(Vector2.ZERO, s), bg)
	var map_rect := _map_rect()
	var sidebar_x := map_rect.end.x
	var top := map_rect.position.y
	var bottom := map_rect.end.y
	# Камера, игровая область и мышь используют одну геометрию.
	var body := _ask(&"SpaceBodyGetRequested", {"entity":HERO})
	var center := map_rect.get_center()
	var origin := _map_origin()
	var min_tile := Vector2i(floori((map_rect.position.x-origin.x) / STEP_PX), floori((top-origin.y)/STEP_PX))
	var max_tile := Vector2i(ceili((map_rect.end.x-origin.x)/STEP_PX), ceili((bottom-origin.y)/STEP_PX))
	min_tile = Vector2i(clampi(min_tile.x,0,MAP_SIZE.x-1), clampi(min_tile.y,0,MAP_SIZE.y-1))
	max_tile = Vector2i(clampi(max_tile.x,0,MAP_SIZE.x), clampi(max_tile.y,0,MAP_SIZE.y))
	var region := _ask(&"SpaceRegionGetRequested", {"origin":min_tile, "size":max_tile-min_tile})
	var fog := _ask(&"FogStateGetRequested", {})
	var visible := {}
	for tile in fog.get("visible_tiles", []): visible[tile] = true
	_remember_visible(fog.get("visible_tiles",[]))
	var floors: Dictionary = region.get("floor", {})
	var floor_data := _ask(&"DungeonFloorTrackingGetRequested", {})
	var floor_index: int = clampi(int(floor_data.get("data",{}).get("floor",1))-1,0,3)
	var tint: Color = FLOOR_TINTS[floor_index]
	for y in range(min_tile.y,max_tile.y):
		for x in range(min_tile.x,max_tile.x):
			var tile := Vector2i(x,y)
			if visible.has(tile) or not _map_memory.has(tile): continue
			var flags: int = _map_memory[tile]
			var is_floor := bool(flags & MEM_FLOOR)
			var atlas: Texture2D = _floor_memory_atlas if is_floor else _wall_memory_atlas
			if atlas != null: draw_texture_rect_region(atlas,Rect2(origin+Vector2(tile)*STEP_PX,Vector2.ONE*STEP_PX),_art_tile_source(tile,floor_index,is_floor))
			_draw_memory_features(tile,flags,origin)
	for tile in visible:
		if tile.x < min_tile.x or tile.y < min_tile.y or tile.x >= max_tile.x or tile.y >= max_tile.y: continue
		var pos := origin + Vector2(tile)*STEP_PX
		var atlas: Texture2D = _floor_atlas if floors.has(tile) else _wall_atlas
		var src := _art_tile_source(tile,floor_index,floors.has(tile))
		draw_texture_rect_region(atlas,Rect2(pos,Vector2.ONE*STEP_PX),src,tint)
		if region.get("passages", {}).has(tile): draw_rect(Rect2(pos,Vector2.ONE*STEP_PX),Color("d2a96d25"))
	var bodies: Dictionary = _ask(&"SpaceBodiesGetRequested", {}).get("bodies",{})
	for actor in bodies:
		if not actor is StringName: continue
		for tile in _enemy_windup_tiles(actor,visible):
			draw_rect(Rect2(origin + Vector2(tile)*STEP_PX, Vector2.ONE*STEP_PX), Color("ffdf478c"))
		if actor != HERO:
			var guard := _ask(&"ShieldBlockZoneRequested", {"entity":actor})
			if guard.get("accepted",false):
				for tile in guard["data"]["tiles"]:
					if visible.has(tile): draw_rect(Rect2(origin+Vector2(tile)*STEP_PX,Vector2.ONE*STEP_PX),Color("79b9cfaa"))
	var pending_preview := _direction_preview(get_local_mouse_position())
	var preview_color := Color("79b9cf88") if pending_preview.get("kind","") == "block" else Color("ffffff8c")
	for tile in pending_preview.get("tiles",[]):
		if visible.has(tile):
			var cell := Rect2(origin + Vector2(tile)*STEP_PX, Vector2.ONE*STEP_PX)
			draw_rect(cell,preview_color)
			draw_rect(cell,preview_color.lightened(0.3),false,1.0)
	if _strike_before_hit(HERO):
		for tile in attack_tiles:
			if visible.has(tile): draw_rect(Rect2(origin + Vector2(tile)*STEP_PX, Vector2.ONE*STEP_PX), Color("ffffff8c"))
	for actor in _strike_flashes:
		var flash: Dictionary = _strike_flashes[actor]
		if Time.get_ticks_msec() >= int(flash["expires"]): continue
		var color := Color("39ed718c") if actor == HERO else Color("ff30308c")
		for tile in flash["tiles"]:
			if visible.has(tile): draw_rect(Rect2(origin + Vector2(tile)*STEP_PX, Vector2.ONE*STEP_PX), color)
	var block_zone := _ask(&"ShieldBlockZoneRequested", {"entity":HERO})
	if block_zone.get("accepted",false):
		for tile in block_zone["data"]["tiles"]:
			if visible.has(tile): draw_rect(Rect2(origin + Vector2(tile)*STEP_PX, Vector2.ONE*STEP_PX), Color("79b9cfaa"))
	var room_objects: Dictionary = _ask(&"RoomObjectsGetRequested", {"room":current_room}).get("objects",{})
	for id in room_objects:
		var data: Dictionary = room_objects[id]
		if data.get("type","") != "chest": continue
		var tile: Vector2i = data["tile"]
		if visible.has(tile):
			var p := origin + (Vector2(tile)+Vector2(0.5,0.5))*STEP_PX
			draw_rect(Rect2(p-Vector2(9,7),Vector2(18,14)), Color("9c693e"))
			draw_rect(Rect2(p-Vector2(9,7),Vector2(18,14)), gold, false, 1.5)
			_line(p+Vector2(-8,-1),p+Vector2(8,-1),Color("e9b85a"),1)
			if data.get("opened",false): draw_circle(p,2,Color("17231f"))
	var stair := _ask(&"DungeonStairGetRequested", {})
	if stair.get("found", false) and stair["data"].get("status", "") == "placed":
		var stair_object := _ask(&"ObjectGetRequested", {"object":stair["data"]["object"]})
		if stair_object.get("found", false):
			var stair_tile: Vector2i = stair_object["data"]["tile"]
			if visible.has(stair_tile):
				var p := origin + Vector2(stair_tile) * STEP_PX
				draw_rect(Rect2(p,Vector2.ONE*STEP_PX), Color("6a7380"))
				for row in range(3):
					_line(p + Vector2(3,5 + row * 5),p + Vector2(17,5 + row * 5),Color("e7e8dd"),1.5)
	var portal := _ask(&"DungeonPortalGetRequested", {})
	if portal.get("found",false) and portal["data"].get("status","") == "placed":
		var portal_object := _ask(&"ObjectGetRequested", {"object":portal["data"]["object"]})
		if portal_object.get("found",false) and visible.has(portal_object["data"]["tile"]):
			var p := origin + (Vector2(portal_object["data"]["tile"]) + Vector2.ONE*0.5) * STEP_PX
			draw_circle(p,10,Color("476cc4"))
			draw_arc(p,10,0,TAU,24,Color("b5d8ff"),2.0,true)
	var loot := _ask(&"LootGetRequested", {})
	for item in loot.get("items", {}):
		var tile: Vector2i = loot["items"][item]["tile"]
		if visible.has(tile):
			var p := origin+(Vector2(tile)+Vector2.ONE*0.5)*STEP_PX
			draw_circle(p,9,Color("e9b85a30"))
			draw_colored_polygon(PackedVector2Array([p+Vector2(0,-6),p+Vector2(6,0),p+Vector2(0,6),p+Vector2(-6,0)]),gold)
	# Спавненные тела показываем только в текущей видимой области.
	for id in bodies:
		if id == HERO or id == RAT: continue
		var spawn := _ask(&"ComponentGetRequested", {"entity":id,"component":&"spawn"})
		if not spawn.get("found",false): continue
		var sd: Dictionary = spawn["data"]
		if not sd.get("demo_melee",false) and sd.get("type_id","") != "final_ogre": continue
		var bd: Dictionary = bodies[id]
		var shown := false
		for x in range(bd["anchor"].x,bd["anchor"].x + int(bd["size"])):
			for y in range(bd["anchor"].y,bd["anchor"].y + int(bd["size"])):
				if visible.has(Vector2i(x,y)): shown = true
		if not shown: continue
		var p := origin + (Vector2(bd["anchor"]) + Vector2.ONE * float(bd["size"]) * 0.5) * STEP_PX
		var radius := maxf(12.0, float(bd["size"]) * STEP_PX * 0.4)
		var full := _body_all_visible(bd["anchor"],int(bd["size"]),visible)
		if full: draw_circle(p+Vector2(0,radius*0.25),radius*0.75,Color("00000070"))
		var enemy_tex: Texture2D = _ogre_sprite if sd.get("type_id","") == "final_ogre" else _enemy_sprite
		var sprite_size := Vector2.ONE * float(bd["size"]) * STEP_PX * 0.94
		_draw_visible_sprite(enemy_tex,Rect2(p-sprite_size*0.5,sprite_size),origin,bd["anchor"],int(bd["size"]),visible)
		if full:
			_draw_enemy_status(id,visible,p,int(bd["size"]))
			var action := _ask(&"ActionGetRequested", {"entity":id})
			if action.get("found",false) and action.get("data",{}).get("id",null) == &"weapon_strike": draw_arc(p,radius+6,0,TAU,36,Color("ef7961"),2.0,true)
	var rat := _ask(&"SpaceBodyGetRequested", {"entity":RAT})
	if rat.get("found",false):
		var rd: Dictionary = rat["data"]
		var seen := false
		for x in range(rd["anchor"].x, rd["anchor"].x + int(rd["size"])):
			for y in range(rd["anchor"].y, rd["anchor"].y + int(rd["size"])):
				if visible.has(Vector2i(x,y)): seen = true
		if seen:
			var p := origin+(Vector2(rd["anchor"])+Vector2.ONE*float(rd["size"])*0.5)*STEP_PX
			var full := _body_all_visible(rd["anchor"],int(rd["size"]),visible)
			if full: draw_circle(p+Vector2(0,4),14,Color("00000070"))
			var rat_size := Vector2.ONE * float(rd["size"]) * STEP_PX * 0.94
			_draw_visible_sprite(_rat_sprite,Rect2(p-rat_size*0.5,rat_size),origin,rd["anchor"],int(rd["size"]),visible)
			if full:
				_draw_enemy_status(RAT,visible,p,int(rd["size"]))
				var attack := _ask(&"ActionGetRequested", {"entity":RAT})
				if attack.get("found", false) and attack.get("data", {}).get("id", &"") == &"weapon_strike": draw_arc(p,26,0,TAU,32,Color("ef7961"),2.0,true)
	if body.get("found",false):
		var p := center
		draw_circle(p+Vector2(0,10),25,Color("00000080"))
		draw_arc(p,30,0,TAU,40,Color("d7bb7980"),1.5,true)
		var hero_size := Vector2.ONE * float(body["data"]["size"]) * STEP_PX * 0.94
		draw_texture_rect(_hero_sprite,Rect2(p-hero_size*0.5,hero_size),false)
		var face := attack_direction
		if not _direction_action.is_empty():
			var cursor_delta := get_local_mouse_position()-p
			if cursor_delta.length_squared() >= 16.0:
				if _direction_action == "attack": face = cursor_delta.normalized()
				else: face = Vector2(1 if cursor_delta.x > 0 else -1,0) if absf(cursor_delta.x)>=absf(cursor_delta.y) else Vector2(0,1 if cursor_delta.y > 0 else -1)
		draw_colored_polygon(PackedVector2Array([p+face*36,p+face*26+Vector2(-face.y,face.x)*5,p+face*26-Vector2(-face.y,face.x)*5]), gold)
	if not _drop_pick.is_empty():
		var tile: Vector2i = _drop_pick["tile"]
		var allowed: bool = _ask(&"LootDropTileCheckRequested", {"entity":HERO,"tile":tile}).get("valid",false)
		var cursor := Rect2(origin + Vector2(tile)*STEP_PX,Vector2.ONE*STEP_PX)
		draw_rect(cursor,Color("d9c36e88") if allowed else Color("ed615e88"))
		draw_rect(cursor,Color("fff0b5") if allowed else Color("ed7777"),false,2.0)
	# Снаряды видны только в открытой области карты.
	var projectiles: Dictionary = _ask(&"ProjectilesGetRequested",{}).get("projectiles",{})
	for projectile in projectiles.values():
		var world: Vector2 = projectile.get("position",Vector2.ZERO)
		var tile := Vector2i(floori(world.x),floori(world.y))
		if not visible.has(tile): continue
		var p := origin + world*STEP_PX
		var direction: Vector2 = projectile.get("direction",Vector2.RIGHT)
		if projectile.get("weapon_type","") == "bow":
			_line(p-direction*8.0,p+direction*7.0,Color("fff1c2"),2.0)
			draw_circle(p+direction*7.0,2.0,Color("e9b85a"))
		else: draw_circle(p,4.0,Color("ffb25f"))
	# Пользовательская рамка перекрывает мир, кроме прозрачного центрального окна.
	draw_texture_rect(_ui_frame,_frame_rect(),false)
	var fr := _frame_rect()
	if fr.position.y > 0:
		draw_rect(Rect2(0,0,s.x,fr.position.y),bg)
		draw_rect(Rect2(0,fr.end.y,s.x,s.y-fr.end.y),bg)
	if fr.position.x > 0:
		draw_rect(Rect2(0,0,fr.position.x,s.y),bg)
		draw_rect(Rect2(fr.end.x,0,s.x-fr.end.x,s.y),bg)
	_draw_frame_hud(visible,floors)
	if not _direction_action.is_empty() and not inventory_open and _drop_pick.is_empty():
		var prompt := Rect2(map_rect.position+Vector2(12,12),Vector2(minf(480.0,map_rect.size.x-24.0),34))
		_panel(prompt,Color("172420ed"),gold)
		_txt(("УДАР" if _direction_action == "attack" else "БЛОК") + "  ·  направление: ЛКМ / стрелки",prompt.position+Vector2(12,22),13,pale,prompt.size.x-20)
	if not is_dead and not is_won:
		if not _drop_pick.is_empty():
			_mouse_button(_drop_cancel_rect(),"Отмена")
			_mouse_button(_drop_confirm_rect(),"Положить")
		else:
			_mouse_button(_inventory_button_rect(),"Закрыть [I]" if inventory_open else "Вещи [I]")
			_mouse_button(_stats_button_rect(),"Статы [C]",stats_view and inventory_open)
	if inventory_open and _drop_pick.is_empty():
		if stats_view: _draw_stats()
		else: _draw_inventory(sidebar_x,top,bottom)
	if journal_open: _draw_journal()
	if _pickup_open: _draw_pickup_selector()
	if is_dead or is_won:
		_panel(Rect2(center-Vector2(225,125),Vector2(450,250)),Color("101a1cea"),Color("a47758"))
		_txt("ПОБЕДА" if is_won else "ЗАБЕГ ОКОНЧЕН",center+Vector2(-90,-76),20,Color("e6c2a2"))
		var summary := _ask(&"RunStatisticsGetRequested", {})
		if summary.get("found", false):
			var result: Dictionary = summary["data"]
			var depth_text := "—" if result["depth"] == null else "%.1f" % float(result["depth"])
			_txt("Убийства: %d    Комнаты: %d    Глубина: %s" % [result["kills"], result["rooms"], depth_text],center+Vector2(-195,-36),13,pale)
			var values: Dictionary = result["stats"]
			_txt("CON %s   STR %s   DEX %s" % [str(values.get("CON", "—")), str(values.get("STR", "—")), str(values.get("DEX", "—"))],center+Vector2(-195,-8),13,pale)
			_txt("INT %s   WIS %s   PER %s" % [str(values.get("INT", "—")), str(values.get("WIS", "—")), str(values.get("PER", "—"))],center+Vector2(-195,17),13,pale)
			_txt("Уровень персонажа: %d (черновой)" % hero_level,center+Vector2(-195,42),11,muted)
		if not _fresh_available: _txt("Новый забег недоступен; перезапустите проект.",center+Vector2(-195,88),12,pale)
# Подписи привязаны к пикселям исходной рамки и масштабируются вместе с ней.
func _ui_text(text: String, pos: Vector2, font_size: int, color: Color, width: float = -1) -> void:
	_txt(text,_ui_point(pos),maxi(8,roundi(float(font_size)*_frame_scale())),color,width*_frame_scale() if width >= 0 else -1)
# Заполнение рисуется поверх тёмной колбы, только в просвете стекла.
func _resource_vial_ratio(current: float, maximum: float) -> float:
	if maximum <= 0.0: return 0.0
	return clampf(current/maximum,0.0,1.0)
func _draw_resource_vials() -> void:
	var resources := [&"HP", &"Stamina", &"MP"]
	var captions := ["HP", "STA", "MP"]
	var colors := [Color("c93837"), Color("61a958"), Color("4783d1")]
	for i in range(resources.size()):
		var x: float = 14.0 + float(i)*64.0
		var resource := _ask(&"ResourceGetRequested", {"entity":HERO,"resource":resources[i]})
		var current: float = float(resource.get("data",{}).get("current",0.0))
		var maximum: float = float(resource.get("data",{}).get("max",0.0))
		var ratio := _resource_vial_ratio(current,maximum)
		if _ui_vials.size() > i and _ui_vials[i] != null:
			draw_texture_rect(_ui_vials[i],_ui_rect(Rect2(x,544,50,165)),false)
		var height := 98.0*ratio
		if height > 0.0:
			var liquid := _ui_rect(Rect2(x+16,675-height,18,height))
			var color: Color = colors[i]
			color.a = 0.73
			draw_rect(liquid,color)
			var glint := _ui_rect(Rect2(x+19,675-height,2,height))
			draw_rect(glint,Color(1,1,1,0.15))
			var meniscus := _ui_rect(Rect2(x+16,675-height,18,1.5))
			draw_rect(meniscus,Color(1,1,1,0.27))
		_ui_text(captions[i],Vector2(x+14,724),10,Color("f0e1bf"),40)
		_ui_text("%.0f / %.0f" % [current,maximum],Vector2(x+1,740),9,Color("f0e1bf"),62)

func _draw_frame_hud(visible: Dictionary, floors: Dictionary) -> void:
	var ink := Color("291a10")
	var dark := Color("1b120d")
	var light := Color("f0e1bf")
	var muted := Color("bdab89")
	var gold := Color("e9b85a")
	_ui_text("УПРАВЛЕНИЕ",Vector2(20,113),11,light,196)
	_ui_text("Space: удар   B: блок",Vector2(20,129),11,light,196)
	_ui_text("ПКМ: идти   Esc: отмена",Vector2(20,145),10,muted,196)
	_ui_text("ПУТНИК",Vector2(42,252),16,dark,125)
	var labels := ["CON", "STR", "DEX", "INT", "WIS", "PER"]
	for i in range(labels.size()):
		var stat := _ask(&"StatGetRequested", {"entity":HERO,"stat":StringName(labels[i])})
		_ui_text("%s  %s" % [labels[i],str(stat.get("value","—"))],Vector2(42,279+i*22),13,ink,125)
	_ui_text("E: поднять     F: открыть",Vector2(42,421),10,ink,130)
	_ui_text("Q: ожидать    I: вещи",Vector2(42,438),10,ink,130)
	_ui_text("F5 / F9: запись / загрузка",Vector2(42,455),9,ink,130)
	_draw_resource_vials()
	# Локальная миникарта показывает только уже видимые клетки; неизученное не раскрываем.
	var mini := _ui_rect(Rect2(1147,22,185,142))
	var hero := _camera_center_world()
	var center := mini.get_center()
	var scale := 2.1*_frame_scale()
	# Ограничиваем обход текущим окошком, а не размером всего этажа.
	var radius_x := ceili(mini.size.x/(2.0*scale))+2
	var radius_y := ceili(mini.size.y/(2.0*scale))+2
	var anchor := Vector2i(floori(hero.x),floori(hero.y))
	for y in range(anchor.y-radius_y,anchor.y+radius_y+1):
		for x in range(anchor.x-radius_x,anchor.x+radius_x+1):
			var tile := Vector2i(x,y)
			if visible.has(tile) or not _map_memory.has(tile): continue
			var p := center+(Vector2(tile)+Vector2.ONE*0.5-hero)*scale
			if mini.has_point(p):
				var floor_known := bool(int(_map_memory[tile]) & MEM_FLOOR)
				draw_rect(Rect2(p,Vector2.ONE*maxf(1.0,scale)),Color("585858") if floor_known else Color("909090"))
	for tile in visible:
		var delta: Vector2 = Vector2(tile)+Vector2.ONE*0.5-hero
		var p := center+delta*scale
		if mini.has_point(p):
			var is_floor: bool = floors.has(tile)
			if not is_floor:
				var terrain := _ask(&"SpaceTileGetRequested",{"tile":tile})
				is_floor = terrain.get("kind",0) == 1
			draw_rect(Rect2(p,Vector2.ONE*maxf(1.0,scale)),Color("49392c") if is_floor else Color("876e52"))
	draw_circle(center,maxf(2.0,3.0*_frame_scale()),Color("c64030"))
	_ui_text("МИНИКАРТА",Vector2(1160,38),10,light,160)
	var shown: Array = []
	var bar := _ask(&"HotbarDetailsGetRequested",{})
	for entry in bar.get("entries",[]):
		var id = entry.get("target",null)
		if id is StringName and not _enemy_display_details(id,visible).is_empty(): shown.append(entry)
	_ui_text("ВРАГ",Vector2(1202,246),15,dark,110)
	if shown.is_empty():
		_ui_text("Не обнаружен",Vector2(1202,271),11,ink,118)
	else:
		var target: Dictionary = shown[0]
		_ui_text("Цель %s" % str(target["target"]),Vector2(1202,271),10,ink,118)
		var hp = target.get("hp",null)
		if hp is Dictionary: _ui_text("HP  %.0f / %.0f" % [hp["current"],hp["max"]],Vector2(1202,297),12,ink,118)
		else: _ui_text("HP: неизвестно",Vector2(1202,297),11,ink,118)
		var action = target.get("action",null)
		if action is Dictionary and action.get("active",false):
			_ui_text(str(action.get("name","Действие")),Vector2(1202,323),11,ink,118)
			if action.has("progress"): _ui_text("Готовность: %d%%" % int(float(action["progress"])*100),Vector2(1202,344),10,ink,118)
		else: _ui_text("Действие: —",Vector2(1202,323),10,ink,118)
		_ui_text("Остальные данные",Vector2(1202,390),10,ink,118)
		_ui_text("неизвестны",Vector2(1202,406),10,ink,118)
	# Показаны текущие действия, а не несуществующая дискретная очередь ходов.
	_ui_text("ТЕКУЩИЕ ДЕЙСТВИЯ",Vector2(530,121),10,light,220)
	var actions: Array = []
	var own := _ask(&"ActionGetRequested",{"entity":HERO})
	if own.get("found",false): actions.append({"name":"ГЕРОЙ","progress":float(own["data"]["elapsed"])/maxf(0.01,float(own["data"]["duration"]))})
	for entry in shown:
		var action = entry.get("action",{})
		if action is Dictionary and action.get("active",false): actions.append({"name":"ВРАГ","progress":action.get("progress",null)})
	var positions := [304,363,422,481,540,599,658,717,776,835,894,953,1012]
	for i in range(mini(actions.size(),positions.size())):
		var x: int = positions[i]
		_ui_text(actions[i]["name"],Vector2(x+2,48),9,light,52)
		var progress = actions[i].get("progress",null)
		if progress is float or progress is int:
			var r := _ui_rect(Rect2(x+2,59,48,5))
			draw_rect(r,Color("191612"))
			draw_rect(Rect2(r.position,Vector2(r.size.x*clampf(float(progress),0,1),r.size.y)),gold)
	_ui_text("БЫСТРЫЕ ЯЧЕЙКИ: ПОКА НЕ НАЗНАЧЕНЫ",Vector2(455,669),10,muted,570)
	# Книга — кнопка открытия; снизу остаётся краткое последнее сообщение.
	if _journal_book != null: draw_texture_rect(_journal_book,_ui_rect(Rect2(1164,604,160,96)),false)
	_ui_text("ЖУРНАЛ [J]",Vector2(1190,715),11,light,150)
	var preview := _journal_wrap(message,170.0,10)
	for i in range(mini(preview.size(),2)): _ui_text(preview[i],Vector2(1160,731+i*14),10,light,170)

# Журнал хранит именно сообщения интерфейса, не скрытые данные симуляции.
func _journal_record(text: String) -> void:
	var clean := text.strip_edges().replace("\n"," ").left(1000)
	if clean.is_empty(): return
	journal_entries.append(clean)
	if journal_entries.size() > JOURNAL_LIMIT: journal_entries.pop_front()
	_journal_dirty = true
func _journal_wrap(text: String, max_width: float, font_size: int) -> Array:
	var lines: Array = []
	var line := ""
	var font := ThemeDB.fallback_font
	for word in text.split(" ",false):
		var remaining: String = word
		while not remaining.is_empty():
			var candidate := remaining if line.is_empty() else line+" "+remaining
			if font.get_string_size(candidate,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x <= max_width:
				line = candidate
				remaining = ""
			elif not line.is_empty():
				lines.append(line)
				line = ""
			else:
				var cut := 1
				while cut < remaining.length() and font.get_string_size(remaining.left(cut+1),HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x <= max_width: cut += 1
				lines.append(remaining.left(cut))
				remaining = remaining.substr(cut)
	if not line.is_empty(): lines.append(line)
	return lines
func _journal_prepare() -> void:
	if not _journal_dirty: return
	_journal_lines.clear()
	for entry in journal_entries:
		_journal_lines.append_array(_journal_wrap("• " + entry,270.0,14))
		_journal_lines.append("")
	_journal_dirty = false
func _journal_spreads() -> int:
	_journal_prepare()
	return maxi(1,ceili(float(_journal_lines.size()) / float(JOURNAL_LINES_PER_PAGE*2)))
func _journal_rect() -> Rect2:
	return Rect2(_map_rect().get_center()-Vector2(380,228),Vector2(760,456))
func _journal_button_rect() -> Rect2:
	return _ui_rect(Rect2(1152,600,190,156))
func _journal_prev_rect() -> Rect2:
	return Rect2(_journal_rect().position+Vector2(48,414),Vector2(95,30))
func _journal_next_rect() -> Rect2:
	return Rect2(_journal_rect().position+Vector2(617,414),Vector2(95,30))
func _journal_close_rect() -> Rect2:
	return Rect2(_journal_rect().position+Vector2(682,16),Vector2(50,30))
func _open_journal() -> void:
	_clear_held_input()
	_cancel_mouse_path()
	_direction_action = ""
	journal_page = _journal_spreads()-1
	_journal_turn_time = 0.0
	journal_open = true
	queue_redraw()
func _close_journal() -> void:
	journal_open = false
	_journal_turn_time = 0.0
	queue_redraw()
func _turn_journal(delta: int) -> void:
	var next := clampi(journal_page+delta,0,_journal_spreads()-1)
	if next == journal_page: return
	journal_page = next
	_journal_turn_direction = delta
	_journal_turn_time = 0.45
	queue_redraw()
func _draw_journal() -> void:
	var rect := _journal_rect()
	var texture := _journal_book
	if _journal_turn_time > 0.0:
		var frames: Array[Texture2D] = _journal_turn_right if _journal_turn_direction > 0 else _journal_turn_left
		var frame := clampi(floori((0.45-_journal_turn_time)/0.15),0,2)
		if frames.size() > frame and frames[frame] != null: texture = frames[frame]
	if texture != null: draw_texture_rect(texture,rect,false)
	if _journal_turn_time <= 0.0:
		_journal_prepare()
		journal_page = clampi(journal_page,0,_journal_spreads()-1)
		var ink := Color("23160f")
		_txt("ЖУРНАЛ",rect.position+Vector2(78,70),18,ink,270)
		for side in range(2):
			var first := journal_page*JOURNAL_LINES_PER_PAGE*2 + side*JOURNAL_LINES_PER_PAGE
			for row in range(JOURNAL_LINES_PER_PAGE):
				var index := first+row
				if index < _journal_lines.size(): _txt(_journal_lines[index],rect.position+Vector2(72+side*330,100+row*17),14,ink,270)
		_txt("%d / %d" % [journal_page+1,_journal_spreads()],rect.position+Vector2(617,400),12,ink,100)
	_mouse_button(_journal_close_rect(),"×")
	_mouse_button(_journal_prev_rect(),"‹ Назад")
	_mouse_button(_journal_next_rect(),"Вперёд ›")

func _resource_bar(resource: StringName, title: String, rect: Rect2, color: Color) -> void:
	var r := _ask(&"ResourceGetRequested", {"entity":HERO, "resource":resource})
	var current := 0.0
	var maximum := 0.0
	if r.get("found",false):
		current = float(r["data"].get("current",0.0))
		maximum = float(r["data"].get("max", 0.0))
	_txt(title,rect.position-Vector2(0,8),10,Color("a9b5a7"))
	_txt("%.0f" % current,rect.position+Vector2(rect.size.x-24,-8),11,Color("e7e8dd"))
	draw_rect(rect,Color("2c3b36"))
	if maximum <= 0.0: maximum = maxf(current,1.0)
	draw_rect(Rect2(rect.position,Vector2(rect.size.x*clampf(current/maximum,0,1),rect.size.y)),color)
# Девять частей сохраняют углы присланной рамки при любой ширине кнопки.
func _draw_nine_patch(texture: Texture2D, dest: Rect2, margin: float, modulation: Color = Color.WHITE) -> void:
	if texture == null or dest.size.x <= 0 or dest.size.y <= 0: return
	var source := texture.get_size()
	var mx := minf(margin,minf(source.x/2.0,dest.size.x/2.0))
	var my := minf(margin,minf(source.y/2.0,dest.size.y/2.0))
	var sx := [0.0,mx,source.x-mx,source.x]
	var sy := [0.0,my,source.y-my,source.y]
	var dx := [dest.position.x,dest.position.x+mx,dest.end.x-mx,dest.end.x]
	var dy := [dest.position.y,dest.position.y+my,dest.end.y-my,dest.end.y]
	for y in range(3):
		for x in range(3):
			var target := Rect2(dx[x],dy[y],dx[x+1]-dx[x],dy[y+1]-dy[y])
			var src := Rect2(sx[x],sy[y],sx[x+1]-sx[x],sy[y+1]-sy[y])
			if target.size.x > 0 and target.size.y > 0: draw_texture_rect_region(texture,target,src,modulation)
func _draw_inventory_panel(rect: Rect2) -> void:
	_draw_nine_patch(_ui_parchment,rect,12.0,Color("c5ad90"))
	# Затемнение под текстом: пергамент виден, но не снижает контраст.
	draw_rect(rect.grow(-9),Color("17130eed"))
	draw_rect(rect.grow(-9),Color("a58e5c"),false,1.0)
func _mouse_button(rect: Rect2, label: String, active: bool = false) -> void:
	var hover := rect.has_point(get_local_mouse_position())
	_draw_nine_patch(_ui_slot,rect,10.0)
	if active or hover:
		draw_rect(rect.grow(-4),Color("bc8b442c") if active else Color("e3c77e1f"))
		draw_rect(rect.grow(-3),Color("c7a86d"),false,1.0)
	_txt(label,rect.position+Vector2(10,rect.size.y*0.5+4),12,Color("f2e4c5"),rect.size.x-14)

func _draw_stats() -> void:
	var rect := _inventory_rect()
	var p := rect.position
	_draw_inventory_panel(rect)
	_txt("ХАРАКТЕРИСТИКИ",p+Vector2(18,34),18,Color("e7e8dd"))
	_mouse_button(Rect2(p+Vector2(472,12),Vector2(34,30)),"×")
	_mouse_button(Rect2(p+Vector2(18,58),Vector2(136,32)),"Инвентарь")
	_mouse_button(Rect2(p+Vector2(160,58),Vector2(136,32)),"Экипировка")
	_mouse_button(Rect2(p+Vector2(302,58),Vector2(204,32)),"Характеристики",true)
	_txt("Уровень: %d    Опыт: %d / %d" % [hero_level,hero_xp,hero_level*XP_PER_LEVEL_FACTOR],p+Vector2(22,120),15,Color("e9d5a8"))
	_txt("Свободные очки: %d" % hero_points,p+Vector2(22,146),14,Color("e9b85a"))
	var descriptions := ["Телосложение","Сила","Ловкость","Интеллект","Мудрость","Восприятие"]
	for i in range(PROGRESSION_STATS.size()):
		var stat: StringName = PROGRESSION_STATS[i]
		var q := _ask(&"StatGetRequested", {"entity":HERO,"stat":stat})
		var line := "%s · %s: %s (база %s)" % [stat,descriptions[i],str(q.get("value","—")),str(q.get("base","—"))]
		_txt(line,p+Vector2(22,180+i*40),13,Color("e9d5a8"),392)
		_mouse_button(Rect2(p+Vector2(423,160+i*40),Vector2(79,31)),"+1 [%d]" % (i+1),hero_points>0)
	_txt("Черновые правила: 25 опыта за убийство;",p+Vector2(22,422),11,Color("a9b5a7"))
	_txt("100 × текущий уровень, 2 очка за уровень.",p+Vector2(22,442),11,Color("a9b5a7"))
	_txt("C — характеристики; I — закрыть; Tab — вещи.",p+Vector2(22,460),11,Color("a9b5a7"))

# Координаты совпадают с присланным манифестом 676×444.
const EQUIPMENT_ART_RECTS := {
	"main":Rect2(24,88,76,160), "off":Rect2(212,88,76,160),
	"head":Rect2(134,20,44,58), "body":Rect2(105,84,102,130),
	"hands":Rect2(201,252,42,48), "belt":Rect2(115,214,82,14),
	"legs":Rect2(115,228,82,150), "feet":Rect2(122,378,68,44),
	"ring1":Rect2(82,252,21,24), "ring2":Rect2(82,280,21,24),
	"amulet":Rect2(64,50,36,36), "cloak":Rect2(212,28,44,58)
}
func _inventory_art_rect() -> Rect2:
	return _ui_rect(Rect2(340,150,676,444))
func _inventory_art_point(point: Vector2) -> Vector2:
	return (point-_inventory_art_rect().position)/_frame_scale()
func _inventory_cell_rect(index: int) -> Rect2:
	var local := Vector2(348+(index%7)*44,26+int(index/7)*44)
	return Rect2(_inventory_art_rect().position+local*_frame_scale(),Vector2.ONE*40*_frame_scale())
func _inventory_equipment_rect(slot: String) -> Rect2:
	var r: Rect2 = EQUIPMENT_ART_RECTS.get(slot,Rect2())
	return Rect2(_inventory_art_rect().position+r.position*_frame_scale(),r.size*_frame_scale())
func _inventory_toolbar_rect(index: int) -> Rect2:
	return _ui_rect([Rect2(691,597,42,22),Rect2(736,597,42,22),Rect2(781,597,75,22),Rect2(859,597,83,22),Rect2(945,597,70,22),Rect2(604,597,83,22)][index])
func _inventory_item_icon(item: Variant) -> Texture2D:
	if not item is StringName or item == &"": return null
	var q := _ask(&"ItemGetRequested",{"item":item})
	if not q.get("found",false): return null
	var id := str(q.get("item_data",{}).get("base_id",""))
	return _item_icons.get(id,_item_icons.get("unknown",null))
func _item_name(item: Variant) -> String:
	if not item is StringName or item == &"": return "пусто"
	return _inventory_item_label(_ask(&"ItemGetRequested",{"item":item}),item)
func _inventory_open_inspect(item: Variant) -> void:
	if not item is StringName or item == &"":
		message = "В этой ячейке нет предмета."
		return
	identify_mode = false
	inspect_mode = true
	inspect_item = item
	inspect_page = 0
	queue_redraw()
func _inventory_art_input(point: Vector2, button: MouseButton) -> void:
	if button == MOUSE_BUTTON_LEFT:
		for i in range(6):
			if _inventory_toolbar_rect(i).has_point(point):
				match i:
					0: _change_inventory_page(-7)
					1: _change_inventory_page(7)
					2: _press_key(KEY_V)
					3: _press_key(KEY_T)
					4: _toggle_inventory()
					5: _press_key(KEY_G)
				return
	var art := _inventory_art_rect()
	if not art.has_point(point): return
	var equipment: Dictionary = _ask(&"ComponentGetRequested",{"entity":HERO,"component":&"equipment"}).get("data",{})
	for slot in EQUIPMENT_SLOTS:
		if _inventory_equipment_rect(slot).has_point(point):
			equipment_view = true
			var id = equipment.get(slot,null)
			if button == MOUSE_BUTTON_RIGHT or inspect_mode: _inventory_open_inspect(id)
			elif _drop_mode: message = "Для выбрасывания выберите предмет в рюкзаке."
			elif not identify_mode: _unequip_slot(slot)
			else: message = "Опознать можно предмет в рюкзаке."
			queue_redraw()
			return
	var items := _inventory_items()
	_clamp_inventory_page(items)
	var base := int(inventory_page/7)*63
	for i in range(63):
		if _inventory_cell_rect(i).has_point(point):
			equipment_view = false
			var absolute := base+i
			if absolute >= items.size(): message = "В этой ячейке нет предмета."; queue_redraw(); return
			inventory_page = int(absolute/9)
			if button == MOUSE_BUTTON_RIGHT or inspect_mode: _inventory_open_inspect(items[absolute])
			elif _drop_mode: _drop_inventory_item(absolute%9)
			elif identify_mode: _identify_inventory_item(absolute%9)
			else: _use_inventory_item(absolute%9)
			queue_redraw()
			return
func _draw_item_icon(item: Variant, rect: Rect2) -> void:
	var texture := _inventory_item_icon(item)
	if texture == null: return
	var side := minf(rect.size.x,rect.size.y)*0.87
	var at := rect.get_center()-Vector2.ONE*side/2.0
	draw_texture_rect(texture,Rect2(at,Vector2.ONE*side),false)
func _inventory_toolbar_button(index: int, label: String, active: bool) -> void:
	var rect := _inventory_toolbar_rect(index)
	_draw_nine_patch(_ui_slot,rect,8.0*_frame_scale())
	if active or rect.has_point(get_local_mouse_position()):
		draw_rect(rect.grow(-2.0*_frame_scale()),Color("c9a15c33"))
		draw_rect(rect.grow(-1.0*_frame_scale()),Color("c7a86d"),false,maxf(1.0,_frame_scale()))
	_txt(label,rect.position+Vector2(5.0*_frame_scale(),rect.size.y*0.5+4.0*_frame_scale()),maxi(7,roundi(11.0*_frame_scale())),Color("f2e4c5"),rect.size.x-8.0*_frame_scale())
func _draw_inventory_art() -> void:
	var art := _inventory_art_rect()
	if _inventory_art != null: draw_texture_rect(_inventory_art,art,false)
	var gear: Dictionary = _ask(&"ComponentGetRequested",{"entity":HERO,"component":&"equipment"}).get("data",{})
	var mouse := get_local_mouse_position()
	var hover_label := ""
	for slot in EQUIPMENT_SLOTS:
		var rect := _inventory_equipment_rect(slot)
		var item = gear.get(slot,null)
		var twohand := false
		if slot == "off" and item == null and gear.get("main",null) is StringName:
			var main := _ask(&"ItemGetRequested",{"item":gear["main"]})
			twohand = main.get("base",{}).get("tags",[]).has("two_handed")
		if item is StringName or twohand:
			# Заменяем пиктограмму пустого слота на исходный фон без неё.
			if _equipment_base != null: draw_texture_rect_region(_equipment_base,rect,EQUIPMENT_ART_RECTS[slot])
			draw_rect(rect.grow(-2*_frame_scale()),Color("18130f99"))
			draw_rect(rect,Color("c7a86d"),false,maxf(1.0,_frame_scale()))
			if item is StringName: _draw_item_icon(item,rect)
			else: _txt("2H",rect.position+Vector2(8,20)*_frame_scale(),maxi(8,roundi(13*_frame_scale())),Color("e9d5a8"))
		if rect.has_point(mouse):
			draw_rect(rect,Color("e3c77e"),false,maxf(1.0,2*_frame_scale()))
			var n:int=EQUIPMENT_SLOTS.find(slot)
			hover_label = "%s: %s" % [EQUIPMENT_LABELS[n],("занята двуручным оружием" if twohand else _item_name(item))]
		if equipment_view:
			var n:int=EQUIPMENT_SLOTS.find(slot)-equipment_page*9
			if n>=0 and n<9: _txt(str(n+1),rect.position+Vector2(3,12)*_frame_scale(),maxi(8,roundi(10*_frame_scale())),Color("fff1ca"))
	var items := _inventory_items()
	_clamp_inventory_page(items)
	var base := int(inventory_page/7)*63
	for i in range(63):
		var cell := _inventory_cell_rect(i)
		var absolute := base+i
		if absolute < items.size(): _draw_item_icon(items[absolute],cell)
		if cell.has_point(mouse):
			if _inventory_highlight != null: draw_texture_rect(_inventory_highlight,cell.grow(4*_frame_scale()),false)
			hover_label = "Рюкзак: " + (_item_name(items[absolute]) if absolute < items.size() else "пусто")
		if not equipment_view and absolute >= inventory_page*9 and absolute < inventory_page*9+9 and absolute < items.size():
			_txt(str(absolute-inventory_page*9+1),cell.position+Vector2(3,12)*_frame_scale(),maxi(8,roundi(10*_frame_scale())),Color("fff1ca"))
	var footer := _ui_rect(Rect2(340,595,347,25))
	draw_rect(footer,Color("1c1713ed"))
	var pages := maxi(1,ceili(float(items.size())/63.0))
	var hint := hover_label if not hover_label.is_empty() else ("Выберите предмет" if _drop_mode else "Рюкзак %d/%d · ПКМ: осмотр" % [int(base/63)+1,pages])
	_ui_text(hint,Vector2(344,612),10,Color("f1e1bf"),253)
	for i in range(6):
		var names := ["‹", "›", "Осмотр", "Опознать", "Закрыть", "Выброс [G]"]
		_inventory_toolbar_button(i,names[i],(i==2 and inspect_mode) or (i==3 and identify_mode) or (i==5 and _drop_mode))

func _draw_inventory(sidebar_x: float, top: float, bottom: float) -> void:
	if not (inspect_mode and inspect_item != &""):
		_draw_inventory_art()
		return
	var rect := _inventory_rect()
	var pos := rect.position
	_draw_inventory_panel(rect)
	_txt("ОСМОТР ПРЕДМЕТА",pos+Vector2(18,34),18,Color("e7e8dd"))
	_mouse_button(Rect2(pos+Vector2(472,12),Vector2(34,30)),"×")
	if inspect_mode and inspect_item != &"":
		var lines := _inspection_lines(inspect_item)
		var pages := maxi(1,ceili(float(lines.size())/float(INSPECTION_PAGE_SIZE)))
		inspect_page = clampi(inspect_page,0,pages-1)
		var start := inspect_page * INSPECTION_PAGE_SIZE
		for i in range(mini(lines.size()-start,INSPECTION_PAGE_SIZE)):
			_txt(str(lines[start+i]),pos+Vector2(24,124+i*19),14 if start+i == 0 else 12,Color("e9d5a8"),472)
		if pages > 1:
			_mouse_button(Rect2(pos+Vector2(18,374),Vector2(65,30)),"<")
			_mouse_button(Rect2(pos+Vector2(437,374),Vector2(65,30)),">")
			_txt("Страница %d / %d" % [inspect_page+1,pages],pos+Vector2(205,394),11,Color("a9b5a7"))
		_mouse_button(Rect2(pos+Vector2(18,415),Vector2(120,32)),"Назад")

	_txt("Esc: назад · стрелки: страницы",pos+Vector2(18,456),11,Color("a9b5a7"))

func _inventory_item_label(item: Dictionary, fallback: Variant) -> String:
	var label := str(item.get("base",{}).get("name",fallback))
	var data = item.get("item_data",{})
	if data is Dictionary and data.get("learning",null) is Dictionary and data.get("learning_state",null) is Dictionary:
		if data["learning_state"].get("identified",false): label += " · опознано"
		else: label += " · не опознано (INT %s)" % str(data.get("int_req","—"))
	return label

func _equipped_name(id: Variant) -> String:
	if id == null: return "пусто"
	var item := _ask(&"ItemGetRequested", {"item":id})
	return str(item.get("base", {}).get("name", "?"))
