extends Node
## Описание модов и выбор тира; применение эффекта относится к конвейеру.
var _definitions: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"ModDefinitionRegisterRequested", _register)
	EventBus.subscribe(&"ModDefinitionGetRequested", _get_definition)
	EventBus.subscribe(&"ModRollApplyRequested", _roll_apply)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var tables: Dictionary = rules["ruleset"].get("tables", {})
		for definition in tables.get("mods", []):
			_register({"definition": definition})

func _register(event: Dictionary) -> void:
	event["accepted"] = false
	var definition = event.get("definition", null)
	if not definition is Dictionary:
		return
	var normalized: Dictionary = definition.duplicate(true)
	var id := StringName(str(normalized.get("id", "")))
	var category := str(normalized.get("category", ""))
	var magic := str(normalized.get("kind", "")) == "magic_inventory"
	if magic:
		if category != "affix" or not _valid_magic_penalty(normalized.get("slot_penalty", null)):
			return
		var allowed_slots = normalized.get("allowed_slots", ["ring", "amulet", "cloak"])
		if not allowed_slots is Array or allowed_slots.is_empty():
			return
		for slot in allowed_slots:
			if str(slot) not in ["ring", "amulet", "cloak"]:
				return
		normalized["allowed_slots"] = allowed_slots.duplicate()
		normalized["stat"] = "inventory_volume"
		var magic_tiers = normalized.get("tier_list", normalized.get("tiers", null))
		if not magic_tiers is Array:
			return
		var converted: Array = []
		for tier in magic_tiers:
			if not tier is Dictionary or not _nonnegative(tier.get("volume_bonus", null)):
				return
			var converted_tier: Dictionary = tier.duplicate(true)
			converted_tier["value"] = tier["volume_bonus"]
			converted.append(converted_tier)
		normalized["tiers"] = converted
	var stat := str(normalized.get("stat", ""))
	var tiers = normalized.get("tiers", null)
	if id == &"" or _definitions.has(id) or category not in ["prefix", "suffix", "affix"] or stat.is_empty() or not tiers is Array or tiers.is_empty():
		return
	var seen: Dictionary = {}
	var total_weight := 0.0
	for tier in tiers:
		if not tier is Dictionary or not tier.get("tier", null) is int or tier["tier"] < 1 or seen.has(tier["tier"]):
			return
		if not _number(tier.get("value", null)) or not _nonnegative(tier.get("level_req", null)) or not _nonnegative(tier.get("weight", null)):
			return
		seen[tier["tier"]] = true
		total_weight += float(tier["weight"])
	if not is_finite(total_weight) or total_weight <= 0.0:
		return
	_definitions[id] = normalized
	event["accepted"] = true

func _valid_magic_penalty(penalty: Variant) -> bool:
	if not penalty is Dictionary or not penalty.get("amount", null) is int:
		return false
	var category := str(penalty.get("category", ""))
	var amount: int = penalty["amount"]
	return (category == "suffix" and amount in [1, 2]) or (category == "prefix" and amount == 2)

func _get_definition(event: Dictionary) -> void:
	var id := StringName(str(event.get("id", "")))
	event["found"] = _definitions.has(id)
	if event["found"]:
		event["data"] = _definitions[id].duplicate(true)

func _roll_apply(event: Dictionary) -> void:
	event["accepted"] = false
	var item_id := StringName(str(event.get("item", "")))
	var mod_id := StringName(str(event.get("mod_id", "")))
	if item_id == &"" or not _definitions.has(mod_id):
		_fail(event, "Предмет или мод не найден")
		return
	var item_request := {"item": item_id, "found": false}
	EventBus.publish(&"ItemGetRequested", item_request)
	if not item_request["found"]:
		_fail(event, "Предмет не найден")
		return
	var item: Dictionary = item_request["item_data"]
	for existing in item.get("mods", []):
		if existing is Dictionary and str(existing.get("id", "")) == str(mod_id):
			_fail(event, "Мод с таким ID уже есть на предмете")
			return
	var item_level = item.get("item_level", null)
	if not _nonnegative(item_level):
		_fail(event, "Не задан item_level")
		return
	var definition: Dictionary = _definitions[mod_id]
	var category := str(definition["category"])
	var allowed := {"item": item_id, "category": category, "candidate": definition, "allowed": false}
	EventBus.publish(&"ItemModCanAttachRequested", allowed)
	if not allowed["allowed"]:
		_fail(event, allowed.get("error", "Редкость не допускает ещё один мод этой категории"))
		return
	var material_result := _get_material_level(item, event.get("material_id", null))
	if not material_result["ok"]:
		_fail(event, material_result["error"])
		return
	var material_level: float = material_result["level"]
	var candidates: Array = []
	var total_weight := 0.0
	for tier in definition["tiers"]:
		if float(tier["level_req"]) <= float(item_level) and float(tier["level_req"]) <= material_level and float(tier["weight"]) > 0.0:
			candidates.append(tier)
			total_weight += float(tier["weight"])
	if candidates.is_empty() or not is_finite(total_weight):
		_fail(event, "Нет доступных тиров с положительным весом")
		return
	var random := {"accepted": false}
	EventBus.publish(&"RngFloatRequested", random)
	if not random["accepted"]:
		_fail(event, "Генератор случайных чисел недоступен")
		return
	var sample := float(random["value"]) * total_weight
	var cumulative := 0.0
	var selected: Dictionary = candidates.back()
	for candidate in candidates:
		cumulative += float(candidate["weight"])
		if sample < cumulative:
			selected = candidate
			break
	var mod := {"id": mod_id, "category": category, "stat": definition["stat"], "tier": selected["tier"], "value": selected["value"], "level_req": selected["level_req"], "material_id": material_result["material_id"]}
	if str(definition.get("kind", "")) == "magic_inventory":
		mod["kind"] = "magic_inventory"
		mod["slot_penalty"] = definition["slot_penalty"].duplicate(true)
		mod["allowed_slots"] = definition["allowed_slots"].duplicate()
		mod["volume_bonus"] = selected["volume_bonus"]
	var attach := {"item": item_id, "mod": mod, "accepted": false}
	EventBus.publish(&"ItemModAttachRequested", attach)
	if not attach["accepted"]:
		_fail(event, "Не удалось записать мод")
		return
	event["accepted"] = true
	event["mod"] = mod.duplicate(true)

func _get_material_level(item: Dictionary, selected: Variant) -> Dictionary:
	var ids: Array[StringName] = []
	for stack in item.get("materials", []):
		if int(stack.get("count", 0)) <= 0:
			continue
		var id := StringName(str(stack.get("material_id", "")))
		if not ids.has(id):
			ids.append(id)
	if ids.is_empty():
		return {"ok": false, "error": "Нет материала, ограничивающего тир"}
	var chosen := StringName(str(selected)) if selected != null else &""
	if chosen == &"":
		if ids.size() != 1:
			return {"ok": false, "error": "Для смешанного предмета укажите material_id"}
		chosen = ids[0]
	if not ids.has(chosen):
		return {"ok": false, "error": "Материал не входит в предмет"}
	var query := {"material": chosen, "found": false}
	EventBus.publish(&"MaterialGetRequested", query)
	if not query["found"] or not _nonnegative(query["data"].get("level", null)):
		return {"ok": false, "error": "Уровень материала неизвестен"}
	return {"ok": true, "level": float(query["data"]["level"]), "material_id": chosen}

func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

func _nonnegative(value: Variant) -> bool:
	return _number(value) and float(value) >= 0.0

func _fail(event: Dictionary, reason: String) -> void:
	event["accepted"] = false
	event["error"] = reason

func _snapshot_collect(event: Dictionary) -> void:
	event["sections"]["mods"] = {"definitions": _definitions.duplicate(true)}

func _snapshot_apply(event: Dictionary) -> void:
	_definitions = event["sections"]["mods"]["definitions"].duplicate(true)
