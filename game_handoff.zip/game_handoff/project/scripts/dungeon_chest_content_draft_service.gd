extends Node
## Только черновой план: ни объектов, ни экземпляров вещей не создаётся.
var _busy := false
var _rolling := false
var _pools: Dictionary = {}

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules.get("found", false):
		var pools = rules["ruleset"].get("parameters", {}).get("chest_draft_pools", null)
		if pools is Dictionary: _pools = pools.duplicate(true)
	EventBus.subscribe(&"DungeonChestContentDraftRequested", _requested)
	EventBus.subscribe(&"DungeonChestDraftAttachRequested", _attach_requested)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect_guard)

func _collect_guard(e: Dictionary) -> void:
	if _rolling: e["errors"].append("Нельзя сохранять при составлении черновика сундука")

func _requested(e: Dictionary) -> void:
	e["accepted"] = false
	e["rolled_back"] = false
	for key in ["draft", "error", "fatal"]: e.erase(key)
	var kind = e.get("kind", null)
	var depth = e.get("depth", null)
	if _busy or kind not in ["normal", "boss"] or not (depth is float or depth is int) or not is_finite(float(depth)) or float(depth) < 0.0 or float(depth) > 10000.0:
		e["error"] = "Нужны тип сундука и корректная глубина"; return
	_busy = true
	var work := {"draft":{}, "error":""}
	var transaction: Dictionary = SaveService.run_world_transition_transaction(func(): return _execute(str(kind), float(depth), work))
	_rolling = false
	_busy = false
	e["accepted"] = transaction.get("committed", false)
	e["rolled_back"] = transaction.get("rolled_back", false)
	if transaction.get("fatal", false): e["fatal"] = true
	if not e["accepted"]:
		e["error"] = work["error"] if not work["error"].is_empty() else transaction.get("error", "Черновик недоступен")
		return
	e["draft"] = work["draft"].duplicate(true)

func _execute(kind: String, depth: float, work: Dictionary) -> bool:
	var before: Dictionary = SaveService._collect_transition_snapshot()
	if not before.get("valid", false): return _fail(work, "Невозможно проверить исходное состояние")
	var equipment := _validated_pool("equipment", before["payload"]["sections"]["items"]["bases"])
	var consumable := _validated_pool("consumable", before["payload"]["sections"]["items"]["bases"])
	if equipment.is_empty() or consumable.is_empty(): return _fail(work, "Черновой пул не готов или содержит неизвестную базу")
	_rolling = true
	var draft := _build(kind, depth, equipment, consumable, work)
	_rolling = false
	if draft.is_empty(): return false
	var after: Dictionary = SaveService._collect_transition_snapshot()
	if not after.get("valid", false): return _fail(work, "Состояние после бросков недоступно")
	var b: Dictionary = before["payload"]["sections"].duplicate(true)
	var a: Dictionary = after["payload"]["sections"].duplicate(true)
	# Сервис вправе продвинуть только игровой RNG; другие сериализуемые
	# изменения во время вызова делают операцию неуспешной.
	b.erase("rng")
	a.erase("rng")
	if b != a: return _fail(work, "Во время составления черновика изменился мир")
	work["draft"] = draft
	return true

func _validated_pool(category: String, bases: Dictionary) -> Array:
	var source = _pools.get(category, null)
	if not source is Array or source.is_empty(): return []
	var output: Array = []
	var seen := {}
	var total := 0
	for entry in source:
		if not entry is Dictionary or not entry.get("id", null) is String or str(entry["id"]).is_empty() or seen.has(entry["id"]): return []
		var w = entry.get("weight", null)
		if not (w is int or w is float) or not is_finite(float(w)) or float(w) != floorf(float(w)) or float(w) < 1 or float(w) > 1000000: return []
		var id := StringName(entry["id"])
		if not bases.has(id) or not bases[id] is Dictionary: return []
		var slot := str(bases[id].get("slot", ""))
		if category == "consumable" and slot != "consumable": return []
		if category == "equipment" and slot not in ["weapon", "shield", "body"]: return []
		seen[entry["id"]] = true
		total += int(w)
		if total > 1000000: return []
		output.append({"id":id, "weight":int(w)})
	return output

func _int_roll(low: int, high: int, work: Dictionary) -> int:
	var q := {"min":low, "max":high, "accepted":false}
	EventBus.publish(&"RngIntRequested", q)
	var value = q.get("value", null)
	if not q.get("accepted", false) or not value is int or value < low or value > high:
		work["error"] = "Ошибка случайного выбора"
		return -1
	return value

func _pick(pool: Array, work: Dictionary) -> StringName:
	var total := 0
	for row in pool: total += row["weight"]
	var roll := _int_roll(0, total - 1, work)
	if roll < 0: return &""
	var cumulative := 0
	for row in pool:
		cumulative += row["weight"]
		if roll < cumulative: return row["id"]
	return &""

func _build(kind: String, depth: float, equipment: Array, consumable: Array, work: Dictionary) -> Dictionary:
	var count := _int_roll(4 if kind == "boss" else 2, 8 if kind == "boss" else 5, work)
	if count < 0: return {}
	var min_level := maxi(1, 1 + floori(depth / 3.0))
	var slots: Array = []
	for i in range(count):
		var category := _int_roll(0, 99, work)
		if category < 0: return {}
		if category < 40:
			var base := _pick(equipment, work)
			if base == &"": return {}
			var level := _int_roll(min_level, min_level + 1, work)
			if level < 0: return {}
			# Полноценного реестра пригодных шаблонов пока нет.
			var rarity := {"unique_available":false, "artifact_available":false, "accepted":false}
			EventBus.publish(&"ItemRarityRollRequested", rarity)
			if not rarity.get("accepted", false) or rarity.get("rarity", null) not in [&"normal", &"magic", &"rare"]:
				return _fail_draft(work, "Выбор редкости не выполнен")
			slots.append({"category":"equipment", "base_id":base, "item_level":level, "rarity":rarity["rarity"]})
		else:
			var base := _pick(consumable, work)
			if base == &"": return {}
			slots.append({"category":"consumable", "base_id":base, "item_level":null, "rarity":null})
	return {"kind":kind, "depth":depth, "slots":slots, "complete":false}

func _fail(work: Dictionary, message: String) -> bool:
	work["error"] = message
	return false
func _fail_draft(work: Dictionary, message: String) -> Dictionary:
	work["error"] = message
	return {}

# Состав и привязка — одна транзакция: при отказе броски тоже отменяются.
func _attach_requested(e: Dictionary) -> void:
	e["accepted"] = false
	e["rolled_back"] = false
	for key in ["draft", "error", "fatal"]: e.erase(key)
	var id = e.get("object", null)
	var kind = e.get("kind", null)
	var depth = e.get("depth", null)
	if _busy or not id is StringName or id == &"" or kind not in ["normal", "boss"] or not (depth is float or depth is int) or not is_finite(float(depth)) or float(depth) < 0.0 or float(depth) > 10000.0:
		e["error"] = "Некорректные параметры"; return
	_busy = true
	var work := {"draft":{}, "error":""}
	var tx: Dictionary = SaveService.run_world_transition_transaction(func(): return _attach_draft_transition(id,str(kind),float(depth),work))
	_rolling = false
	_busy = false
	e["accepted"] = tx.get("committed", false)
	e["rolled_back"] = tx.get("rolled_back", false)
	if tx.get("fatal", false): e["fatal"] = true
	if e["accepted"]: e["draft"] = work["draft"].duplicate(true)
	else: e["error"] = work["error"] if not work["error"].is_empty() else tx.get("error", "Операция недоступна")


# Вызывается только внутри общей транзакции создания сундука.
func attach_boss_draft_for_transition(id: StringName, depth: float) -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy or id == &"" or not is_finite(depth) or depth < 0.0 or depth > 10000.0: return {"accepted":false,"error":"Операция недоступна"}
	_busy = true
	var work := {"draft":{}, "error":""}
	var ok := _attach_draft_transition(id,"boss",depth,work)
	_rolling = false
	_busy = false
	return {"accepted":ok,"draft":work["draft"].duplicate(true),"error":work["error"]}

# Обычный сундук материализуется внутри общей транзакции.
func attach_normal_draft_for_transition(id: StringName, depth: float) -> Dictionary:
	if not SaveService.world_transition_operation_active() or _busy or id == &"" or not is_finite(depth) or depth < 0.0 or depth > 10000.0: return {"accepted":false,"error":"Операция недоступна"}
	_busy = true
	var work := {"draft":{}, "error":""}
	var ok := _attach_draft_transition(id,"normal",depth,work)
	_rolling = false
	_busy = false
	return {"accepted":ok,"draft":work["draft"].duplicate(true),"error":work["error"]}

func _attach_draft_transition(id: StringName, kind: String, depth: float, work: Dictionary) -> bool:
	if not ObjectGenerationService.can_attach_chest_draft(id): return _fail(work, "Нужен пустой закрытый сундук без плана")
	if not _execute(str(kind), float(depth), work): return false
	# Разрешаем материалы до записи плана и в той же транзакции, что и броски.
	var snapshot: Dictionary = SaveService._collect_transition_snapshot()
	if not snapshot.get("valid", false): return _fail(work, "Реестр материалов недоступен")
	var items: Dictionary = snapshot["payload"]["sections"]["items"]
	for entry in work["draft"]["slots"]:
		if entry["category"] == "consumable":
			var consumable_stacks: Array = DungeonChestMaterialsService.resolve_consumable(entry["base_id"], items["bases"], items["materials"])
			if consumable_stacks.is_empty(): return _fail(work, "Не удалось определить упаковку расходника")
			var minimum := maxi(1, 1 + floori(float(depth) / 3.0))
			_rolling = true
			var item_level := _int_roll(minimum, minimum + 1, work)
			_rolling = false
			if item_level < 0: return false
			entry["item_level"] = item_level
			entry["rarity"] = &"normal"
			entry["materials"] = consumable_stacks
			entry["mods"] = []
			continue
		var stacks: Array = DungeonChestMaterialsService._resolve(entry["base_id"], entry["item_level"], items["bases"], items["materials"])
		if stacks.is_empty(): return _fail(work, "Не удалось определить материалы экипировки")
		entry["materials"] = stacks
		var mod_work := {"mods":[], "materials":[], "error":""}
		if not DungeonChestModDraftService.roll_for_transition(entry["base_id"], entry["item_level"], entry["rarity"], mod_work): return _fail(work, "Не удалось выбрать моды: " + str(mod_work["error"]))
		if mod_work["materials"] != stacks: return _fail(work, "Рецепт изменился во время выбора")
		entry["mods"] = mod_work["mods"].duplicate(true)
		entry["learning"] = DungeonChestLearningService.schema_for(entry["base_id"], items["bases"])
		if entry["learning"].is_empty(): return _fail(work, "Нет схемы изучения")
		for i in range(entry["mods"].size()):
			var gate: int = DungeonChestLearningService.gate_for(i)
			if gate < 1: return _fail(work, "Нет ступени раскрытия мода")
			entry["mods"][i]["unlock_after"] = gate
	var prepared: Dictionary = SaveService._collect_transition_snapshot()
	if not prepared.get("valid", false): return _fail(work, "Не удалось проверить состояние после подготовки")
	var before_sections: Dictionary = snapshot["payload"]["sections"].duplicate(true)
	var after_sections: Dictionary = prepared["payload"]["sections"].duplicate(true)
	before_sections.erase("rng"); after_sections.erase("rng")
	if before_sections != after_sections: return _fail(work, "Во время подготовки изменился мир")
	if not ObjectGenerationService.attach_chest_draft_for_transition(id, work["draft"]): return _fail(work, "Не удалось зафиксировать план")
	return true
