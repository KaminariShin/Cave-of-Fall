extends Node
## Преобразование доверенных исходных данных в попадания фазового сборщика.
## Не выбирает цели, не проверяет право атаки и не применяет урон.
const LIMIT := 1000000000.0
const MAX_HITS := 10000
const MAX_TILES := 300000
func _ready() -> void:
	EventBus.subscribe(&"PreparedDirectHitPlanRequested",_plan)
func _num(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v)) and absf(float(v)) <= LIMIT
func _plan(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("error"); e.erase("data")
	var source = e.get("source",null)
	var targets = e.get("targets",null)
	var physical = e.get("physical",null)
	var magical = e.get("magical",null)
	var weakening = e.get("weakening_multiplier",null)
	if not source is StringName or source == &"" or not targets is Array or targets.is_empty() or targets.size() > MAX_HITS or not _num(physical) or float(physical) < 0 or not _num(magical) or float(magical) < 0 or weakening not in [0.25,0.5,0.75,1.0]:
		e["error"] = "Некорректные источник, цели, части урона или ослабление"; return
	var crit := {"per":e.get("per",null),"chance_add_percent":e.get("chance_add_percent",0.0),"chance_factor":e.get("chance_factor",1.0),"multiplier_factor":e.get("multiplier_factor",1.0)}
	EventBus.publish(&"CriticalHitPreviewRequested",crit)
	if not crit.get("accepted",false): e["error"] = crit.get("error","Крит недоступен"); return
	var mult = crit.get("data",{}).get("critical_multiplier",null)
	if not _num(mult) or float(mult) < 1.0 or float(physical) * float(mult) > LIMIT or float(magical) * float(mult) > LIMIT:
		e["error"] = "Критический урон вне диапазона"; return
	var rows: Array = []
	var hits: Array = []
	var seen := {}
	var tile_count := 0
	for target in targets:
		if not target is Dictionary:
			e["error"] = "Некорректная цель"; return
		var id = target.get("target",null)
		var hp = target.get("hp_before",null)
		var tiles = target.get("attack_tiles",null)
		if not id is StringName or id == &"" or id == source or seen.has(id) or not hp is int or hp < 1 or hp > int(LIMIT) or not tiles is Array:
			e["error"] = "Нужны разные цели, целые HP и тайлы атаки"; return
		tile_count += tiles.size()
		if tile_count > MAX_TILES: e["error"] = "Слишком много тайлов"; return
		for tile in tiles:
			if not tile is Vector2i: e["error"] = "Некорректный тайл"; return
		var pp = target.get("physical_protection_percent",null)
		var mp = target.get("magical_protection_percent",null)
		# Проверяем наибольший возможный результат до расходования ГСЧ.
		var preflight := {"physical":float(physical)*float(mult),"magical":float(magical)*float(mult),"physical_protection_percent":pp,"magical_protection_percent":mp,"weakening_multiplier":weakening}
		EventBus.publish(&"DirectHitMitigationPreviewRequested",preflight)
		if not preflight.get("accepted",false): e["error"] = preflight.get("error","Защита недоступна"); return
		seen[id] = true
		rows.append({"target":id,"hp_before":hp,"physical_protection_percent":pp,"magical_protection_percent":mp,"attack_tiles":tiles.duplicate()})
		hits.append({"target":id,"physical":float(physical),"magical":float(magical)})
	rows.sort_custom(func(a,b): return str(a["target"]) < str(b["target"]))
	var rolled := {"per":e.get("per",null),"chance_add_percent":e.get("chance_add_percent",0.0),"chance_factor":e.get("chance_factor",1.0),"multiplier_factor":e.get("multiplier_factor",1.0),"kind":&"direct_mixed","hits":hits}
	EventBus.publish(&"CriticalHitPlanRequested",rolled)
	if not rolled.get("accepted",false): e["error"] = rolled.get("error","Не удалось бросить крит"); return
	var output: Array = []
	var rolls = rolled.get("data",{}).get("hits",[])
	if not rolls is Array or rolls.size() != rows.size(): e["error"] = "Некорректный результат крита"; return
	for i in range(rows.size()):
		var row: Dictionary = rows[i]
		var hit = rolls[i]
		if not hit is Dictionary or hit.get("target",null) != row["target"]: e["error"] = "Результат крита не совпал с целью"; return
		var mitigated := {"physical":hit.get("physical",null),"magical":hit.get("magical",null),"physical_protection_percent":row["physical_protection_percent"],"magical_protection_percent":row["magical_protection_percent"],"weakening_multiplier":weakening}
		EventBus.publish(&"DirectHitMitigationPreviewRequested",mitigated)
		if not mitigated.get("accepted",false): e["error"] = mitigated.get("error","Не удалось применить защиту"); return
		output.append({"source":source,"target":row["target"],"hp_before":row["hp_before"],"attack_tiles":row["attack_tiles"],"damage":mitigated["data"]["physical"],"magical_damage":mitigated["data"]["magical"],"critical":hit["critical"],"roll":hit["roll"]})
	e["accepted"] = true
	e["data"] = {"chance_percent":crit["data"]["chance_percent"],"critical_multiplier":mult,"hits":output}
