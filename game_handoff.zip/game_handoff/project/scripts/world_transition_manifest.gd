extends Node
## Только инвентаризация. Не является разрешением на удаление или переход.
func _ready() -> void:
	EventBus.subscribe(&"WorldTransitionManifestRequested", _requested)
	EventBus.subscribe(&"ItemOwnershipSnapshotValidateRequested", _validate_snapshot)

func _requested(e: Dictionary) -> void:
	e["accepted"] = false
	var actor = e.get("entity", null)
	if not actor is StringName or actor == &"":
		e["error"] = "Нужен ID управляемого персонажа"
		return
	var collected: Dictionary = SaveService.collect_world_transition_snapshot()
	if not collected.get("valid", false):
		e["error"] = collected.get("error", "Снимок недоступен")
		return
	var result := build_manifest(collected["payload"]["sections"], actor)
	if not result.get("valid", false):
		e["error"] = result.get("error", "Невозможно разобрать состояние мира")
		return
	e["accepted"] = true
	e["manifest"] = result["manifest"]

# Функция без изменения мира; вызывается только после общей проверки снимка.
func build_manifest(sections: Dictionary, actor: StringName) -> Dictionary:
	var entities: Dictionary = sections["entities"]
	var actions: Dictionary = sections["actions"]
	var space: Dictionary = sections["space"]
	var items: Dictionary = sections["items"]["instances"]
	if not entities.has(actor) or actions.get("controlled", &"") != actor:
		return _error("Персонаж не существует или не является управляемым")
	if sections["combat"]["dead"].has(actor): return _error("Персонаж погиб")
	var checked := validate_ownership(sections)
	if not checked.get("valid", false): return checked
	var owners: Dictionary = checked["owners"]
	var ground: Dictionary = sections.get("loot", {}).get("ground", {})
	var keep: Array = []
	var other: Array = []
	var free: Array = []
	for item in items:
		if not owners.has(item):
			free.append(item)
		elif owners[item].get("entity", null) == actor:
			keep.append(item)
		else:
			other.append(item)
	_sort(keep); _sort(other); _sort(free)
	var others: Array = entities.keys()
	others.erase(actor)
	_sort(others)
	var bodies: Array = space["bodies"].keys()
	bodies.erase(actor)
	_sort(bodies)
	var objects: Array = sections["objects"]["objects"].keys()
	_sort(objects)
	var processes: Array = sections["processes"].duplicate(true)
	return {"valid":true, "manifest":{
		"actor":actor, "player_body":space["bodies"].get(actor, null),
		"player_items":keep, "other_owned_or_ground_items":other, "unassigned_items":free,
		"item_locations":owners, "other_entities":others, "other_bodies":bodies,
		"world_objects":objects, "ground_items":_sorted_keys(ground),
		"active_actions":actions["active"].duplicate(true), "processes":processes,
		"pending_loot":sections.get("loot", {}).get("pending", {}).duplicate(true),
		"pending_object_interactions":sections["objects"]["pending"].duplicate(true),
		"spawn_states":sections["spawn"]["states"].duplicate(true),
		"executable":false
	}}

func _validate_snapshot(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary: return
	var result := validate_ownership(sections)
	e["valid"] = result.get("valid", false)
	if not e["valid"]: e["error"] = result.get("error", "Некорректное владение предметами")

# Применяется к любому снимку, в том числе без управляемого персонажа.
func validate_ownership(sections: Dictionary) -> Dictionary:
	if not sections.get("entities", null) is Dictionary or not sections.get("items", null) is Dictionary or not sections["items"].get("instances", null) is Dictionary: return _error("Нет данных предметов или сущностей")
	var entities: Dictionary = sections["entities"]
	var items: Dictionary = sections["items"]["instances"]
	var owners := {}
	for entity in entities:
		if not entity is StringName or not entities[entity] is Dictionary: return _error("Некорректная сущность")
		var data: Dictionary = entities[entity]
		var inventory = data.get(&"inventory", {})
		if not inventory is Dictionary or not inventory.get("items", []) is Array: return _error("Некорректный инвентарь")
		for item in inventory.get("items", []):
			if not _claim(item, {"kind":"inventory", "entity":entity}, items, owners): return _error("Неизвестный предмет или повторное владение: %s" % str(item))
		if not _equipment_claim(data.get(&"equipment", {}), entity, items, owners, 0): return _error("Некорректная экипировка или повторное владение у %s" % str(entity))
	var loot = sections.get("loot", {})
	if not loot is Dictionary or not loot.get("ground", {}) is Dictionary: return _error("Некорректный лут")
	var ground: Dictionary = loot.get("ground", {})
	for item in ground:
		if not ground[item] is Dictionary or not ground[item].get("tile", null) is Vector2i: return _error("Некорректное расположение предмета")
		if not _claim(item, {"kind":"ground", "tile":ground[item]["tile"]}, items, owners): return _error("Неизвестный предмет или повторное владение: %s" % str(item))
	return {"valid":true, "owners":owners}

func _claim(item: Variant, location: Dictionary, instances: Dictionary, owners: Dictionary) -> bool:
	if not (item is String or item is StringName) or str(item).is_empty(): return false
	var id := StringName(str(item))
	if not instances.has(id) or owners.has(id): return false
	owners[id] = location
	return true

func _equipment_claim(value: Variant, entity: StringName, instances: Dictionary, owners: Dictionary, depth: int) -> bool:
	if depth > 32: return false
	if value == null: return true
	if value is String or value is StringName:
		return _claim(value, {"kind":"equipment", "entity":entity}, instances, owners)
	if value is Array:
		for child in value:
			if not _equipment_claim(child, entity, instances, owners, depth + 1): return false
		return true
	if value is Dictionary:
		if value.has("id"): return _equipment_claim(value["id"], entity, instances, owners, depth + 1)
		for child in value.values():
			if not _equipment_claim(child, entity, instances, owners, depth + 1): return false
		return true
	return false

func _sort(a: Array) -> void:
	a.sort_custom(func(x, y): return str(x) < str(y))
func _sorted_keys(d: Dictionary) -> Array:
	var result := d.keys()
	_sort(result)
	return result
func _error(message: String) -> Dictionary:
	return {"valid":false, "error":message}
