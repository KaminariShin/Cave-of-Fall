extends Node
## Данные модификаторов не описывают источник; кто их создаёт — сервису всё равно.
const STAT_NAMES := ["CON", "STR", "DEX", "INT", "WIS", "PER"]
const STAGES := ["additive", "multiplicative", "threshold", "final"]
var _quant_interval: int = 5
var _quality_interval: int = 10

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var params: Dictionary = rules["ruleset"].get("parameters", {}).get("stats", {})
		_quant_interval = maxi(1, int(params.get("quantitative_interval", 5)))
		_quality_interval = maxi(1, int(params.get("qualitative_interval", 10)))
	EventBus.subscribe(&"StatGetRequested", _get_requested)
	EventBus.subscribe(&"StatBaseSetRequested", _set_base_requested)
	EventBus.subscribe(&"StatModifierAddRequested", _add_modifier_requested)
	EventBus.subscribe(&"StatModifierRemoveRequested", _remove_modifier_requested)

func _read(entity_id: StringName) -> Dictionary:
	var request := {"entity": entity_id, "component": &"stats", "found": false}
	EventBus.publish(&"ComponentGetRequested", request)
	return request.get("data", {}) if request["found"] else {}

func _get_requested(request: Dictionary) -> void:
	var stat := str(request.get("stat", ""))
	var data := _read(request.get("entity", &""))
	request["found"] = not data.is_empty() and stat in STAT_NAMES
	if not request["found"]:
		return
	var value := _effective(data, stat, request.get("entity", &""))
	if not is_finite(value): request["found"] = false; return
	request["base"] = data[stat]
	request["value"] = value
	# Значения пороговых бонусов не придуманы: только число достигнутых порогов.
	request["quantitative_thresholds"] = maxf(0.0, floor(value / _quant_interval))
	request["qualitative_thresholds"] = maxf(0.0, floor(value / _quality_interval))

func _set_base_requested(request: Dictionary) -> void:
	request["accepted"] = false
	var entity_id: StringName = request.get("entity", &"")
	var stat := str(request.get("stat", ""))
	var value = request.get("value", null)
	if stat not in STAT_NAMES or not _number(value):
		return
	var data := _read(entity_id)
	if data.is_empty():
		return
	var old := _effective(data, stat, entity_id)
	data[stat] = value
	_commit(entity_id, stat, data, old, request)

## modifier: id, stat, stage, op (add/multiply), value; threshold необязателен.
## IDs уникальны внутри сущности. В каждом этапе сохраняется порядок добавления.
func _add_modifier_requested(request: Dictionary) -> void:
	request["accepted"] = false
	var entity_id: StringName = request.get("entity", &"")
	var modifier = request.get("modifier", null)
	if not _valid_modifier(modifier):
		return
	var data := _read(entity_id)
	if data.is_empty():
		return
	for old_modifier in data["_modifiers"]:
		if str(old_modifier["id"]) == str(modifier["id"]):
			return
	var stat := str(modifier["stat"])
	var old := _effective(data, stat, entity_id)
	data["_modifiers"].append(modifier.duplicate(true))
	_commit(entity_id, stat, data, old, request)

func _remove_modifier_requested(request: Dictionary) -> void:
	request["accepted"] = false
	var entity_id: StringName = request.get("entity", &"")
	var id := str(request.get("id", ""))
	var data := _read(entity_id)
	if id.is_empty() or data.is_empty():
		return
	var modifiers: Array = data["_modifiers"]
	for index in range(modifiers.size()):
		if str(modifiers[index]["id"]) == id:
			var stat := str(modifiers[index]["stat"])
			var old := _effective(data, stat, entity_id)
			modifiers.remove_at(index)
			_commit(entity_id, stat, data, old, request)
			return

func _commit(entity_id: StringName, stat: String, data: Dictionary, old: float, request: Dictionary) -> void:
	var new_value := _effective(data, stat, entity_id)
	if not is_finite(new_value):
		return
	var write := {"entity": entity_id, "data": data, "accepted": false}
	EventBus.publish(&"StatsCommitRequested", write)
	request["accepted"] = write["accepted"]
	if write["accepted"] and old != new_value:
		EventBus.publish(&"StatChanged", {"entity": entity_id, "stat": StringName(stat), "old": old, "new": new_value})

func _effective(data: Dictionary, stat: String, entity_id: StringName) -> float:
	var modifiers: Array = []
	for modifier in data.get("_modifiers", []):
		if str(modifier.get("stat", "")) == stat:
			modifiers.append(modifier)
	if stat in STAT_NAMES:
		var gear := {"entity":entity_id, "component":&"equipment", "found":false}
		EventBus.publish(&"ComponentGetRequested",gear)
		if gear.get("found",false):
			if not gear.get("data",null) is Dictionary: return NAN
			for slot in ["main","off","head","body","hands","belt","legs","feet","ring1","ring2","amulet","cloak"]:
				var id = gear["data"].get(slot,null)
				if id == null: continue
				# Старые технические структуры экипировки могут содержать
				# вложенные веса вместо ID; моды экземпляров к ним не применяются.
				if not (id is StringName or id is String): continue
				var item := {"item":StringName(str(id)), "found":false}
				EventBus.publish(&"ItemGetRequested",item)
				if not item.get("found",false): continue
				var bonus: Dictionary = DungeonChestLearningService.equipped_stat_mod_bonus(entity_id,item["item_data"],item["base"],stat)
				if not bonus.get("valid",false): return NAN
				if bonus["bonus"] != 0.0: modifiers.append({"stage":"additive", "op":"add", "value":bonus["bonus"]})
	var request := {"entity": entity_id, "target": "stat." + stat, "base": data[stat], "modifiers": modifiers, "accepted": false}
	EventBus.publish(&"PipelineEvaluateRequested", request)
	return float(request["value"]) if request["accepted"] else NAN

# Снимок до изменения и уведомления после пакетного коммита.
func capture_equipment_stats(entity: StringName) -> Dictionary:
	var result := {}
	for stat in [&"CON", &"STR", &"DEX", &"INT", &"WIS", &"PER"]:
		var q := {"entity":entity, "stat":stat, "found":false}
		EventBus.publish(&"StatGetRequested",q)
		result[stat] = q
	return result

func notify_equipment_stats_change(entity: StringName, before: Dictionary) -> void:
	for stat in [&"CON", &"STR", &"DEX", &"INT", &"WIS", &"PER"]:
		var old = before.get(stat,{})
		if not old.get("found",false): continue
		var after := {"entity":entity, "stat":stat, "found":false}
		EventBus.publish(&"StatGetRequested",after)
		if after.get("found",false) and old["value"] != after["value"]:
			EventBus.publish(&"StatChanged", {"entity":entity, "stat":stat, "old":old["value"], "new":after["value"]})

func _valid_modifier(modifier: Variant) -> bool:
	if not modifier is Dictionary:
		return false
	var stage := str(modifier.get("stage", ""))
	var op := str(modifier.get("op", ""))
	if str(modifier.get("id", "")).is_empty() or str(modifier.get("stat", "")) not in STAT_NAMES or stage not in STAGES or not _number(modifier.get("value", null)):
		return false
	if op not in ["add", "multiply"] or (stage == "additive" and op != "add") or (stage == "multiplicative" and op != "multiply"):
		return false
	if modifier.has("threshold") and (stage != "threshold" or not _number(modifier["threshold"])):
		return false
	return true

func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))
