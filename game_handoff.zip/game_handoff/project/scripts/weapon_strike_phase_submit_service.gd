extends Node
## Автоматический или явный доверенный запуск: собирает удары и активные блоки.
## Применение происходит позже, в CombatPhaseBatchService.finish().
var _busy := false
var _attempted := false
var _noise_sources: Array = []
func _ready() -> void:
	EventBus.subscribe(&"TimeStepStarted",_new_step)
	EventBus.subscribe(&"WeaponStrikePhaseAutoSubmitRequested",_submit)
func _new_step(_e: Dictionary) -> void:
	_attempted = false
	_noise_sources.clear()
func authorizes_collection_abort() -> bool: return _busy
func _fail(message: String) -> Dictionary:
	CombatPhaseBatchService.reject_weapon_collection(message)
	return {"accepted":false,"error":message}
func _submit(e: Dictionary) -> void:
	e["accepted"] = false; e.erase("error"); e.erase("data")
	if _busy or _attempted or not TimeDriver._combat_phase or not CombatPhaseBatchService._collecting or CombatPhaseBatchService._finishing:
		e["error"] = "Окно недоступно или попытка уже выполнена"; return
	_attempted = true
	_busy = true
	var result := _build()
	_busy = false
	if not result.get("accepted",false): e["error"] = result.get("error","Пакет не подготовлен"); return
	_noise_sources = result.get("noise_sources",[])
	e["accepted"] = true; e["data"] = result["data"]

# Только после подтверждения всего боевого пакета и закрытия боевой фазы.
func emit_committed_strike_noises(committed: bool) -> void:
	var sources := _noise_sources.duplicate(true)
	_noise_sources.clear()
	if not committed: return
	for row in sources:
		var q := {"source":row["entity"],"kind":"strike","position":row["position"]}
		EventBus.publish(&"NoiseEmitRequested",q)
		if not q.get("accepted",false):
			EventBus.publish(&"WeaponStrikeNoiseFailed",{"entity":row["entity"]})
# Вызывается TimeDriver после публичного окна, до закрытия пакетного сбора.
# Явный запуск в окне имеет приоритет и не повторяется, даже если он отказал.
func submit_due_automatically() -> void:
	if _attempted: return
	var has_weapon := false
	for row in ActionRegistry.combat_phase_due():
		if row.get("action",null) == &"weapon_strike":
			has_weapon = true
			break
	if not has_weapon: return
	var result := {}
	_submit(result)
	if not result.get("accepted",false):
		EventBus.publish(&"WeaponStrikeAutoSubmissionFailed", {"error":result.get("error","Не удалось автоматически собрать удары")})

func _build() -> Dictionary:
	if TimeDriver._combat_batch_used or not CombatPhaseBatchService._failed.is_empty(): return _fail("Боевой пакет уже занят или отклонён")
	var plan := {}
	EventBus.publish(&"WeaponStrikePhaseAutoPlanRequested",plan)
	if not plan.get("accepted",false): return _fail(str(plan.get("error","Не удалось подготовить удары")))
	var data = plan.get("data",null)
	if not data is Dictionary or not data.get("hits",null) is Array or not data.get("attacks",null) is Array: return _fail("Некорректный план")
	var hits: Array = data["hits"].duplicate(true)
	var noise_sources: Array = []
	for attack in data["attacks"]:
		var actor = attack.get("entity",null)
		if not actor is StringName or actor == &"": return _fail("Некорректный источник удара")
		var body := {"entity":actor}
		EventBus.publish(&"SpaceBodyGetRequested",body)
		if not body.get("found",false): return _fail("Тело источника удара недоступно")
		var movement := {"entity":actor}
		EventBus.publish(&"MovementPositionGetRequested",movement)
		var origin: Vector2 = movement["position"] if movement.get("found",false) else Vector2(body["data"]["anchor"])
		noise_sources.append({"entity":actor,"position":origin + Vector2.ONE * float(body["data"]["size"]) / 2.0})
	var targets := {}
	for hit in hits:
		if not hit is Dictionary or not hit.get("target",null) is StringName: return _fail("Некорректное попадание")
		targets[hit["target"]] = true
	var ids: Array = targets.keys()
	ids.sort_custom(func(a,b): return str(a) < str(b))
	var blocks: Array = []
	for target in ids:
		var status := {"entity":target,"active":false}
		EventBus.publish(&"ShieldBlockStatusRequested",status)
		var pending = ShieldBlockActionService._pending.get(target,null)
		if not status.get("active",false):
			if pending != null: return _fail("Состояние активного блока недоступно")
			continue
		if not pending is Dictionary or status.get("item",null) != pending.get("item",null) or status.get("slot",null) != pending.get("slot",null) or status.get("direction",null) != pending.get("direction",null): return _fail("Состояние блока изменилось")
		var direction = status.get("direction",null)
		if not ShieldBlockZoneService.valid_direction(direction): return _fail("Некорректное направление блока")
		var resource := {"entity":target,"resource":&"Stamina","found":false}
		EventBus.publish(&"ResourceGetRequested",resource)
		var stamina = resource.get("data",{}).get("current",null)
		if not resource.get("found",false) or not (stamina is int or stamina is float) or not is_finite(float(stamina)) or float(stamina) < 0 or float(stamina) > 1000000000.0 or floorf(float(stamina)) != float(stamina):
			return _fail("Нужна целая доступная Stamina блокирующей цели")
		blocks.append({"target":target,"direction":direction,"expected_stamina":int(stamina)})
	# События чтения могли занять фазу или вызвать отказ другого участника.
	if not TimeDriver._combat_phase or TimeDriver._combat_batch_used or not CombatPhaseBatchService._collecting or not CombatPhaseBatchService._failed.is_empty(): return _fail("Фаза изменилась при подготовке")
	# Эти внутренние методы не публикуют событий. Любая ошибка отклоняет весь сбор,
	# включая заявки других участников; частичный пакет не будет применён.
	for block in blocks:
		var q: Dictionary = block.duplicate(true)
		CombatPhaseBatchService._submit_block(q)
		if not q.get("accepted",false): return _fail(str(q.get("error","Блок отклонён")))
	for hit in hits:
		var q: Dictionary = hit.duplicate(true)
		CombatPhaseBatchService._submit_hit(q)
		if not q.get("accepted",false): return _fail(str(q.get("error","Попадание отклонено")))
	return {"accepted":true,"data":{"attack_count":data["attacks"].size(),"hit_count":hits.size(),"block_count":blocks.size()},"noise_sources":noise_sources}
