extends Node
## Подготовка всех готовых оружейных ударов из тел карты без применения урона.
const MAX_ROWS := 10000
var _busy := false
func _ready() -> void:
	EventBus.subscribe(&"WeaponStrikePhaseAutoPlanRequested",_plan)
func _plan(e: Dictionary) -> void:
	e["accepted"] = false; e.erase("error"); e.erase("data")
	if _busy or not TimeDriver._combat_phase:
		e["error"] = "Запрос доступен только в боевой фазе без вложенного вызова"; return
	_busy = true
	var result := _build()
	_busy = false
	if not result.get("accepted",false): e["error"] = result.get("error","Не удалось выбрать кандидатов"); return
	e["accepted"] = true; e["data"] = result["data"]
func _fail(error: String) -> Dictionary: return {"accepted":false,"error":error}
func _build() -> Dictionary:
	var due: Array = []
	for row in ActionRegistry.combat_phase_due():
		if row.get("action",null) == &"weapon_strike": due.append(row["entity"])
	if due.size() > MAX_ROWS: return _fail("Слишком много готовых действий")
	due.sort_custom(func(a,b): return str(a) < str(b))
	if due.is_empty(): return {"accepted":true,"data":{"attacks":[],"hits":[],"candidate_count":0}}
	var query := {}
	EventBus.publish(&"SpaceBodiesGetRequested",query)
	var bodies = query.get("bodies",null)
	if not bodies is Dictionary or bodies.size() > MAX_ROWS + due.size(): return _fail("Некорректное или слишком большое множество тел")
	var living: Array = []
	for actor in bodies:
		if not actor is StringName or actor == &"" or not EntityRegistry.has_entity(actor) or not bodies[actor] is Dictionary: return _fail("Некорректная сущность в списке тел")
		if not CombatService.is_entity_dead(actor): living.append(actor)
	living.sort_custom(func(a,b): return str(a) < str(b))
	var requests: Array = []
	var count := 0
	for actor in due:
		var candidates: Array = []
		for target in living:
			if target != actor: candidates.append(target)
		count += candidates.size()
		if count > MAX_ROWS: return _fail("Слишком много кандидатов для фазы")
		requests.append({"entity":actor,"candidates":candidates})
	var plan := {"attacks":requests}
	EventBus.publish(&"WeaponStrikePhasePlanRequested",plan)
	if not plan.get("accepted",false): return _fail(str(plan.get("error","Не удалось подготовить фазу")))
	var data: Dictionary = plan["data"].duplicate(true)
	data["candidate_count"] = count
	return {"accepted":true,"data":data}
