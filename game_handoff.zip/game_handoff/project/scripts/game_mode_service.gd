extends Node
## Флаг режима и ограничения; источник состава боя — DetectionService.
var _mode := "exploration"
var _controlled: StringName = &""
var _room: StringName = &""
var _bounds: Dictionary = {}
var _scale := 4
var _transitioning := false

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		_scale = int(rules["ruleset"].get("parameters", {}).get("space", {}).get("tiles_per_cell", 4))
	EventBus.subscribe(&"GameModeGetRequested", _get_mode)
	EventBus.subscribe(&"GameModeObserverAllowedRequested", _observer_allowed)
	EventBus.subscribe(&"CombatDetectionChanged", _detection_changed)
	EventBus.subscribe(&"DetectionRoomRefreshFinished", _sync_from_hotbar)
	EventBus.subscribe(&"ControlledEntityRequested", _control_changed)
	EventBus.subscribe(&"PlayerRoomChanged", _room_changed)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"DetectionSnapshotRefreshFinished", _restored)

func _get_mode(event: Dictionary) -> void:
	event["mode"] = _mode
	event["entity"] = _controlled
	event["room"] = _room
	event["rest_allowed"] = _mode == "exploration"
	# В обоих режимах переход геймплейного меню занимает один шаг.
	event["menu_time_policy"] = {"gameplay_transition": 0.01, "ui_transition": 0.0, "operations": null}
	event["surprise_attacks_allowed"] = true
func _detection_changed(event: Dictionary) -> void:
	if not _transitioning and event.get("entity", &"") == _controlled:
		_set_mode("combat" if event.get("active", false) else "exploration")
func _sync_from_hotbar(_event: Dictionary) -> void:
	if _transitioning: return
	var bar := {}
	EventBus.publish(&"HotbarGetRequested", bar)
	if bar.get("entity", &"") == _controlled:
		_set_mode("combat" if bar.get("combat_detected", false) else "exploration")
func _set_mode(value: String) -> void:
	if value == _mode: return
	_mode = value
	EventBus.publish(&"GameModeChanged", {"mode": _mode, "entity": _controlled})
func _control_changed(event: Dictionary) -> void:
	if not event.get("accepted", false): return
	var entity: StringName = event.get("entity", &"")
	if entity == _controlled: return
	var previous: StringName = _controlled
	var old_previous: Dictionary = StatsService.capture_equipment_stats(previous) if previous != &"" else {}
	var old_next: Dictionary = StatsService.capture_equipment_stats(entity) if entity != &"" else {}
	_transitioning = true
	_set_mode("exploration")
	_controlled = entity
	_room = &""
	_bounds = {}
	_transitioning = false
	if previous != &"":
		StatsService.notify_equipment_stats_change(previous,old_previous)
		ResourceService.refresh_equipment_maxima(previous)
	if entity != &"":
		StatsService.notify_equipment_stats_change(entity,old_next)
		ResourceService.refresh_equipment_maxima(entity)
func _room_changed(event: Dictionary) -> void:
	if event.get("entity", &"") != _controlled: return
	var next_room: StringName = event.get("room", &"")
	if next_room == _room: return
	var old_room := _room
	var old_bounds := _bounds.duplicate(true)
	_transitioning = true
	_room = next_room
	_bounds = _room_bounds(next_room)
	if old_room != &"":
		_set_mode("exploration")
		_cancel_previous_room_actions(old_bounds)
	_transitioning = false

func _cancel_previous_room_actions(bounds: Dictionary) -> void:
	if bounds.is_empty(): return
	var bodies := {}
	EventBus.publish(&"SpaceBodiesGetRequested", bodies)
	var ids: Array = bodies.get("bodies", {}).keys()
	ids.sort_custom(func(a, b): return str(a) < str(b))
	for id in ids:
		if id == _controlled or not _inside(bodies["bodies"][id], bounds): continue
		var agent := {"entity": id, "found": false}
		EventBus.publish(&"AIGetRequested", agent)
		if agent["found"] and agent["data"].get("target", &"") == _controlled:
			EventBus.publish(&"AITargetSetRequested", {"entity": id, "target": _controlled, "detected": false})
		var action := {"entity": id, "found": false}
		EventBus.publish(&"ActionGetRequested", action)
		if action["found"]:
			EventBus.publish(&"ActionCancelRequested", {"entity": id, "reason": &"player_left_room"})

func _observer_allowed(event: Dictionary) -> void:
	if not event.get("allowed", true) or _room == &"": return
	var entity: StringName = event.get("entity", &"")
	if entity == _controlled: return
	var body := {"entity": entity, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	event["allowed"] = body["found"] and not _bounds.is_empty() and _inside(body["data"], _bounds)
func _room_bounds(id: StringName) -> Dictionary:
	if id == &"": return {}
	var query := {"id": id, "found": false}
	EventBus.publish(&"RoomGetRequested", query)
	if not query["found"]: return {}
	return {"origin": query["data"]["origin_cell"] * _scale, "size": query["data"]["size_cells"] * _scale}
func _inside(body: Dictionary, bounds: Dictionary) -> bool:
	var a: Vector2i = body["anchor"]
	var s := int(body["size"])
	var p: Vector2i = bounds["origin"]
	var size: Vector2i = bounds["size"]
	return a.x >= p.x and a.y >= p.y and a.x + s <= p.x + size.x and a.y + s <= p.y + size.y
func _collect(event: Dictionary) -> void:
	if _transitioning:
		event["errors"].append("Нельзя сохранять во время смены комнаты или режима")
		return
	event["sections"]["game_mode"] = {"mode": _mode, "controlled": _controlled, "room": _room}
func _apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["game_mode"]
	_mode = data["mode"]
	_controlled = data["controlled"]
	_room = data["room"]
	_bounds = _room_bounds(_room)
	_transitioning = false
func _restored(_event: Dictionary) -> void:
	EventBus.publish(&"GameModeRestored", {"mode": _mode, "entity": _controlled, "room": _room})
