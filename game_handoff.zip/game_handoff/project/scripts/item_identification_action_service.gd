extends Node
## Обычное опознание одной вещи из инвентаря за 1 секунду.
const ACTION := &"item_learning_identify"
var _pending: Dictionary = {}
var _busy := false
var _launch: StringName = &""
var _commit_actor: StringName = &""
var _commit_item: StringName = &""

func _ready() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION,"name":"Опознать предмет","type":&"utility","base_duration":1.0,"interruptible":false}})
	EventBus.subscribe(&"ItemLearningIdentifyRequested", _identify)
	EventBus.subscribe(&"ActionStartAllowedRequested", _action_guard)
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested", _ownership_guard)
	EventBus.subscribe(&"LootEntityRemovalCheckRequested", _removal_guard)
	EventBus.subscribe(&"ActionCompleted", _completed)
	EventBus.subscribe(&"ActionInterrupted", _interrupted)
	EventBus.subscribe(&"EntityRemoved", _removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"ItemIdentificationActionSnapshotValidateRequested", _validate)

func _action_guard(e: Dictionary) -> void:
	if e.get("action",null) == ACTION and e.get("entity",null) != _launch: e["allowed"] = false
	if e.get("action",null) == &"stagger" and _pending.has(e.get("entity",null)): e["allowed"] = false
func _ownership_guard(e: Dictionary) -> void:
	if _pending.has(e.get("entity",null)): e["allowed"] = false
func _removal_guard(e: Dictionary) -> void:
	if _pending.has(e.get("entity",null)): e["allowed"] = false

func _valid_context(actor: StringName, item: StringName, check_int: bool) -> bool:
	var mode := {}
	EventBus.publish(&"GameModeGetRequested", mode)
	if mode.get("entity",null) != actor or CombatService.is_entity_dead(actor): return false
	var inv := {"entity":actor,"found":false}
	EventBus.publish(&"InventoryGetRequested",inv)
	if not inv.get("found",false) or not inv.get("data",{}).get("items",[]).has(item): return false
	var q := {"item":item,"found":false}
	EventBus.publish(&"ItemGetRequested",q)
	if not q.get("found",false) or not q["item_data"].get("learning",null) is Dictionary or q["item_data"].get("learning_state",{}).get("identified",null) != false: return false
	if check_int:
		var stat := {"entity":actor,"stat":&"INT","found":false}
		EventBus.publish(&"StatGetRequested",stat)
		if not stat.get("found",false) or float(stat["value"]) < float(q["item_data"]["int_req"]): return false
	return true

func _identify(e: Dictionary) -> void:
	e["accepted"] = false
	var actor = e.get("entity",null)
	var item = e.get("item",null)
	if _busy or not actor is StringName or actor == &"" or not item is StringName or item == &"" or _pending.has(actor): return
	_busy = true
	if not _valid_context(actor,item,true):
		_busy = false
		e["error"] = "Предмет недоступен, уже опознан или не хватает INT"; return
	_pending[actor] = item
	_launch = actor
	var start := {"entity":actor,"action":ACTION,"duration":1.0,"accepted":false}
	EventBus.publish(&"ActionStartRequested",start)
	_launch = &""
	var active := {"entity":actor,"found":false}
	EventBus.publish(&"ActionGetRequested",active)
	if not start.get("accepted",false) or not _pending.has(actor) or not active.get("found",false) or active["data"].get("id",null) != ACTION or not _valid_context(actor,item,false):
		if active.get("found",false) and active["data"].get("id",null) == ACTION: EventBus.publish(&"ActionCancelRequested", {"entity":actor,"reason":&"identify_unavailable"})
		_pending.erase(actor)
		_busy = false
		e["error"] = "Не удалось начать опознание"; return
	_busy = false
	e["accepted"] = true
	EventBus.publish(&"ItemLearningIdentifyStarted", {"entity":actor,"item":item,"duration":1.0})

func authorizes_commit(actor: StringName, item: StringName) -> bool:
	return _busy and _commit_actor == actor and _commit_item == item and _pending.get(actor,null) == item

func _completed(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null) != ACTION or not _pending.has(actor): return
	var item: StringName = _pending[actor]
	if _busy:
		_pending.erase(actor)
		EventBus.publish(&"ItemLearningIdentifyFailed", {"entity":actor,"item":item,"reason":"Вложенное завершение"})
		return
	_busy = true
	var valid := _valid_context(actor,item,false)
	_commit_actor = actor
	_commit_item = item
	var ok := valid and ItemService.identify_from_action(actor,item)
	_commit_actor = &""
	_commit_item = &""
	_pending.erase(actor)
	_busy = false
	if ok: EventBus.publish(&"ItemLearningIdentified", {"entity":actor,"item":item})
	else: EventBus.publish(&"ItemLearningIdentifyFailed", {"entity":actor,"item":item,"reason":"Условия изменились"})

func _interrupted(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null) != ACTION or not _pending.has(actor): return
	var item: StringName = _pending[actor]
	_pending.erase(actor)
	EventBus.publish(&"ItemLearningIdentifyInterrupted", {"entity":actor,"item":item,"reason":e.get("reason",&"cancelled")})
func _removed(e: Dictionary) -> void:
	_pending.erase(e.get("entity",null))
func _collect(e: Dictionary) -> void:
	if _busy: e["errors"].append("Нельзя сохранять во время изменения опознания"); return
	e["sections"]["item_identification_actions"] = _pending.duplicate(true)
func _apply(e: Dictionary) -> void:
	_pending = e["sections"]["item_identification_actions"].duplicate(true)
	_busy = false
	_launch = &""
	_commit_actor = &""
	_commit_item = &""
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var s = e.get("sections",null)
	if not s is Dictionary or not s.get("item_identification_actions",null) is Dictionary or not s.get("entities",null) is Dictionary or not s.get("items",{}).get("instances",null) is Dictionary or not s.get("actions",{}).get("active",null) is Dictionary: return
	var pending: Dictionary = s["item_identification_actions"]
	var active: Dictionary = s["actions"]["active"]
	for actor in pending:
		var item = pending[actor]
		if not actor is StringName or actor == &"" or actor != s["actions"].get("controlled",null) or not item is StringName or item == &"" or not s["entities"].has(actor) or not s["entities"][actor] is Dictionary or not s["items"]["instances"].has(item): return
		var inv = s["entities"][actor].get(&"inventory",null)
		var data = s["items"]["instances"][item]
		if not inv is Dictionary or not inv.get("items",null) is Array or not inv["items"].has(item) or not data is Dictionary or not data.get("learning",null) is Dictionary or data.get("learning_state",{}).get("identified",null) != false: return
		if not active.has(actor) or not active[actor] is Dictionary or active[actor].get("id",null) != ACTION: return
	for actor in active:
		if active[actor] is Dictionary and active[actor].get("id",null) == ACTION and not pending.has(actor): return
	e["valid"] = true
