extends Node
## Явный атомарный шаг для уже выбранного тайла; сам поиск и автозапуск отдельно.
var _busy := false

func _ready() -> void:
	EventBus.subscribe(&"DungeonBossChestProvisionRequested", _requested)

func _requested(e: Dictionary) -> void:
	e["accepted"] = false
	e["rolled_back"] = false
	for key in ["object","items","tile","interaction_anchor","error","fatal"]: e.erase(key)
	var room = e.get("room",null)
	var tile = e.get("candidate",null)
	var object = e.get("chest_id",null)
	if _busy or not room is StringName or room == &"" or not object is StringName or object == &"" or not tile is Vector2i:
		e["error"] = "Нужны выбранная комната, ID сундука и кандидат"; return
	_busy = true
	var work := {"error":"", "items":[], "anchor":null}
	var tx: Dictionary = SaveService.run_world_transition_transaction(func(): return _execute(room,tile,object,work))
	_busy = false
	e["accepted"] = tx.get("committed",false)
	e["rolled_back"] = tx.get("rolled_back",false)
	if tx.get("fatal",false): e["fatal"] = true
	if not e["accepted"]:
		e["error"] = work["error"] if not work["error"].is_empty() else tx.get("error","Не удалось создать сундук")
		return
	e["object"] = object
	e["tile"] = tile
	e["items"] = work["items"].duplicate()
	e["interaction_anchor"] = work["anchor"]
	EventBus.publish(&"DungeonBossChestProvisioned", {"room":room,"object":object,"tile":tile,"items":work["items"].duplicate(),"interaction_anchor":work["anchor"]})

func _fail(work: Dictionary, message: String) -> bool:
	work["error"] = message
	return false

func _execute(room: StringName, tile: Vector2i, object: StringName, work: Dictionary) -> bool:
	var snap: Dictionary = SaveService._collect_transition_snapshot()
	if not snap.get("valid",false): return _fail(work,"Снимок мира недоступен")
	var sections: Dictionary = snap["payload"]["sections"]
	var tracking = sections.get("dungeon_tracking",null)
	if not tracking is Dictionary or tracking.get("floor",null) != 4 or tracking.get("boss_candidate",null) != room: return _fail(work,"Комната не является выбранной комнатой босса четвёртого этажа")
	if sections["entities"].has(object) or sections["objects"]["objects"].has(object): return _fail(work,"ID сундука уже занят")
	for existing in sections["objects"]["objects"].values():
		if existing is Dictionary and existing.get("room",null) == room and existing.get("type",null) == "chest" and existing.get("interaction",{}).get("boss_chest",false) == true:
			return _fail(work,"В комнате уже отмечен сундук босса")
	var depth := {"room":room,"accepted":false}
	EventBus.publish(&"DungeonRoomDepthRequested",depth)
	if not depth.get("accepted",false) or not (depth.get("depth",null) is int or depth.get("depth",null) is float) or not is_finite(float(depth["depth"])): return _fail(work,"Глубина комнаты недоступна")
	var check := {"room":room,"tile":tile,"accepted":false}
	EventBus.publish(&"DungeonChestPositionPreflightRequested",check)
	if not check.get("accepted",false): return _fail(work,"Позиция непригодна: " + str(check.get("error","ошибка проверки")))
	var create := {"entity":object,"type":"chest","room":room,"tile":tile,"interaction":{"boss_chest":true},"inventory_capacity":1000000.0,"accepted":false}
	EventBus.publish(&"ObjectCreateRequested",create)
	if not create.get("accepted",false): return _fail(work,"Сундук не создан: " + str(create.get("error","ошибка")))
	var after_create := {"room":room,"tile":tile,"existing_object":object,"accepted":false}
	EventBus.publish(&"DungeonChestPositionPreflightRequested",after_create)
	if not after_create.get("accepted",false): return _fail(work,"Проверка после размещения не прошла")
	var draft: Dictionary = DungeonChestContentDraftService.attach_boss_draft_for_transition(object,float(depth["depth"]))
	if not draft.get("accepted",false): return _fail(work,"Не удалось зафиксировать план: " + str(draft.get("error","")))
	var slots: Array = draft["draft"]["slots"]
	var current: Dictionary = SaveService._collect_transition_snapshot()
	if not current.get("valid",false): return _fail(work,"Не удалось проверить ID предметов")
	var items: Dictionary = current["payload"]["sections"]["items"]
	var ids: Array = []
	var prefix := "boss_chest:%s:" % str(object).uri_encode()
	for i in range(slots.size()):
		var id: StringName = &""
		for suffix in range(10000):
			var candidate := StringName(prefix + str(i) + ":" + str(suffix))
			if not items["instances"].has(candidate) and not items["retired"].has(candidate) and not ids.has(candidate): id = candidate; break
		if id == &"": return _fail(work,"Не удалось подобрать уникальные ID")
		ids.append(id)
	var materialized: Dictionary = ObjectGenerationService.materialize_boss_draft_for_transition(object,ids)
	if not materialized.get("accepted",false): return _fail(work,"Не удалось сформировать содержимое: " + str(materialized.get("error","")))
	var prepared: Dictionary = SaveService._collect_transition_snapshot()
	if not prepared.get("valid",false): return _fail(work,"Снимок заполненного сундука недоступен")
	var final_check := {"room":room,"tile":tile,"existing_object":object,"accepted":false}
	EventBus.publish(&"DungeonChestPositionPreflightRequested",final_check)
	if not final_check.get("accepted",false): return _fail(work,"Доступность сундука нарушена")
	var adjacent_wall := false
	for d in [Vector2i.UP,Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT]:
		var adjacent := {"tile":tile+d}
		EventBus.publish(&"SpaceTileGetRequested",adjacent)
		if not adjacent.get("in_bounds",false) or adjacent.get("kind",0) == 0: adjacent_wall = true
	if not adjacent_wall: return _fail(work,"Стена у сундука исчезла")
	var final_depth := {"room":room,"accepted":false}
	EventBus.publish(&"DungeonRoomDepthRequested",final_depth)
	if not final_depth.get("accepted",false) or final_depth.get("depth",null) != depth["depth"]: return _fail(work,"Глубина комнаты изменилась")
	var final_snapshot: Dictionary = SaveService._collect_transition_snapshot()
	if not final_snapshot.get("valid",false): return _fail(work,"Итоговый снимок недоступен")
	if final_snapshot["payload"]["sections"] != prepared["payload"]["sections"] or final_snapshot["payload"]["sections"]["rooms"] != sections["rooms"]: return _fail(work,"Мир изменился при итоговой проверке")
	var final_tracking = final_snapshot["payload"]["sections"].get("dungeon_tracking",{})
	if final_tracking.get("floor",null) != 4 or final_tracking.get("boss_candidate",null) != room: return _fail(work,"Выбранная комната изменилась")
	work["items"] = ids
	work["anchor"] = final_check["interaction_anchor"]
	return true
