extends Node
## Пассивный контейнер, не владеет действием подбора и не считает вес.
var _mutating: Dictionary = {}
var _adding_items: Dictionary = {}
func _ready() -> void:
	EventBus.subscribe(&"EntityCreated", _entity_created)
	EventBus.subscribe(&"InventoryConfigureRequested", _configure)
	EventBus.subscribe(&"InventoryGetRequested", _get_inventory)
	EventBus.subscribe(&"InventoryAddRequested", _add)
	EventBus.subscribe(&"InventoryRemoveRequested", _remove)
	EventBus.subscribe(&"InventoryVolumeModifierAddRequested", _add_modifier)
	EventBus.subscribe(&"InventoryVolumeModifierRemoveRequested", _remove_modifier)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_check)

func _entity_created(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var data := _read(entity)
	if data.is_empty():
		data = {"items": [], "volume": null}
	if not data.has("volume_modifiers"):
		data["volume_modifiers"] = []
	_commit(entity, data)

func _configure(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var volume = event.get("volume", null)
	if not _nonnegative(volume):
		return
	var data := _read(entity)
	if data.is_empty():
		return
	data["volume"] = float(volume)
	event["accepted"] = _commit(entity, data)

func _get_inventory(event: Dictionary) -> void:
	var data := _read(event.get("entity", &""))
	event["found"] = not data.is_empty()
	if not event["found"]:
		return
	var used := _used_volume(data["items"])
	var capacity := _capacity(data)
	event["data"] = data.duplicate(true)
	event["volume_known"] = used["ok"] and capacity["ok"]
	if event["volume_known"]:
		event["used_volume"] = used["value"]
		event["capacity"] = capacity["value"]
		event["over_capacity"] = used["value"] > capacity["value"]

func _add(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var item := StringName(str(event.get("item", "")))
	if entity == &"" or item == &"" or _mutating.has(entity) or _adding_items.has(item): return
	_mutating[entity] = true
	_adding_items[item] = true
	_add_locked(event, entity, item)
	_mutating.erase(entity)
	_adding_items.erase(item)

func _add_locked(event: Dictionary, entity: StringName, item: StringName) -> void:
	var data := _read(entity)
	if item == &"" or data.is_empty() or _is_in_any_inventory(item):
		return
	# Необязательный LootService может запретить прямое добавление вещи с земли.
	var ownership := {"entity": entity, "item": item, "allowed": true}
	EventBus.publish(&"LootInventoryAddCheckRequested", ownership)
	if not ownership["allowed"]:
		return
	var consume_check := {"entity":entity, "item":item, "allowed":true}
	EventBus.publish(&"ItemInventoryAddCheckRequested", consume_check)
	if not consume_check["allowed"]: return
	var equipment_check := {"entity":entity, "item":item, "allowed":true}
	EventBus.publish(&"EquipmentInventoryAddCheckRequested", equipment_check)
	if not equipment_check["allowed"]: return
	var used := _used_volume(data["items"])
	var capacity := _capacity(data)
	var item_volume := _item_volume(item)
	if not used["ok"] or not capacity["ok"] or not item_volume["ok"]:
		return
	if float(used["value"]) + float(item_volume["value"]) > float(capacity["value"]) + 0.000000001:
		return
	data["items"].append(item)
	if _commit(entity, data):
		event["accepted"] = true
		EventBus.publish(&"InventoryItemAdded", {"entity": entity, "item": item})

func _remove(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var item := StringName(str(event.get("item", "")))
	if entity == &"" or item == &"" or _mutating.has(entity) or _adding_items.has(item): return
	_mutating[entity] = true
	_remove_locked(event, entity, item)
	_mutating.erase(entity)

func _remove_locked(event: Dictionary, entity: StringName, item: StringName) -> void:
	var data := _read(entity)
	if data.is_empty() or not data["items"].has(item):
		return
	data["items"].erase(item)
	if _commit(entity, data):
		event["accepted"] = true
		EventBus.publish(&"InventoryItemRemoved", {"entity": entity, "item": item})

func _add_modifier(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var mod = event.get("modifier", null)
	if not mod is Dictionary or str(mod.get("id", "")).is_empty() or str(mod.get("op", "")) not in ["add", "multiply"]:
		return
	if not _nonnegative(mod.get("value", null)):
		return
	var data := _read(entity)
	if data.is_empty():
		return
	for existing in data["volume_modifiers"]:
		if str(existing["id"]) == str(mod["id"]):
			return
	data["volume_modifiers"].append(mod.duplicate(true))
	if data["volume"] != null and not _capacity(data)["ok"]:
		return
	event["accepted"] = _commit(entity, data)

func _remove_modifier(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var id := str(event.get("id", ""))
	var data := _read(entity)
	if data.is_empty():
		return
	for i in range(data["volume_modifiers"].size()):
		if str(data["volume_modifiers"][i]["id"]) == id:
			data["volume_modifiers"].remove_at(i)
			event["accepted"] = _commit(entity, data)
			return

func _read(entity: StringName) -> Dictionary:
	var query := {"entity": entity, "component": &"inventory", "found": false}
	EventBus.publish(&"ComponentGetRequested", query)
	return query.get("data", {}) if query["found"] else {}

func _commit(entity: StringName, data: Dictionary) -> bool:
	var query := {"entity": entity, "data": data, "accepted": false}
	EventBus.publish(&"InventoryCommitRequested", query)
	return query["accepted"]

func _capacity(data: Dictionary) -> Dictionary:
	if not _nonnegative(data.get("volume", null)):
		return {"ok": false}
	var result := float(data["volume"])
	for op in ["add", "multiply"]:
		for mod in data.get("volume_modifiers", []):
			if str(mod.get("op", "")) != op:
				continue
			if op == "add":
				result += float(mod["value"])
			else:
				result *= float(mod["value"])
	return {"ok": is_finite(result) and result >= 0.0, "value": result}

func _used_volume(items: Array) -> Dictionary:
	var total := 0.0
	for item in items:
		var volume := _item_volume(item)
		if not volume["ok"]:
			return {"ok": false}
		total += float(volume["value"])
	return {"ok": is_finite(total), "value": total}

func _item_volume(item: Variant) -> Dictionary:
	var request := {"item": item, "found": false}
	EventBus.publish(&"ItemVolumeRequested", request)
	if not request["found"] or not _nonnegative(request.get("volume", null)):
		return {"ok": false}
	return {"ok": true, "value": float(request["volume"])}

func _is_in_any_inventory(item: StringName) -> bool:
	var request := {"components": [&"inventory"], "entities": []}
	EventBus.publish(&"EntityQueryRequested", request)
	for entity in request["entities"]:
		var data := _read(entity)
		if data.get("items", []).has(item):
			return true
	return false

func _nonnegative(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0

func _snapshot_check(event: Dictionary) -> void:
	if not _mutating.is_empty():
		event["errors"].append("Нельзя сохранять во время изменения инвентаря")
