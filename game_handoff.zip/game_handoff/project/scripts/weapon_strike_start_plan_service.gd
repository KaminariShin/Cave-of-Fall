extends Node
## Read-only advisory preflight; not an authority or a reservation.
func _ready() -> void:
	EventBus.subscribe(&"WeaponStrikeStartPlanRequested", _plan)

func _plan(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("data"); e.erase("error")
	var actor = e.get("entity", null)
	var item = e.get("item", null)
	var direction = e.get("direction", null)
	var strike = e.get("strike", null)
	if not actor is StringName or actor == &"" or not item is StringName or item == &"" or not (strike is String or strike is StringName) or str(strike).is_empty() or not (direction is Vector2 or direction is Vector2i):
		e["error"] = "Нужны персонаж, оружие, удар и направление"; return
	var d := Vector2(direction)
	var length := d.length()
	if not is_finite(d.x) or not is_finite(d.y) or not is_finite(length) or length <= 0.000001:
		e["error"] = "Некорректное направление"; return
	d /= length
	var alive := {"entity":actor,"allowed":true}
	EventBus.publish(&"CombatEntityCanActRequested",alive)
	var active := {"entity":actor,"found":false}
	EventBus.publish(&"ActionGetRequested",active)
	if not alive.get("allowed",false) or active.get("found",false):
		e["error"] = "Персонаж погиб или занят"; return
	var gear := {"entity":actor,"component":&"equipment","found":false}
	EventBus.publish(&"ComponentGetRequested",gear)
	var slots = gear.get("data",null)
	if not gear.get("found",false) or not slots is Dictionary or (slots.get("main",null) != item and slots.get("off",null) != item):
		e["error"] = "Оружие должно быть в руке"; return
	var cost := {"entity":actor,"item":item,"strike":strike}
	EventBus.publish(&"WeaponStrikeStaminaPreviewRequested",cost)
	if not cost.get("accepted",false) or not cost.get("data",{}).get("can_start",false):
		e["error"] = cost.get("error","Недостаточно выносливости"); return
	var damage := {"entity":actor,"item":item,"strike":strike}
	EventBus.publish(&"WeaponStrikeDamagePreviewRequested",damage)
	if not damage.get("accepted",false) or not damage.get("data",{}).get("in_hand",false):
		e["error"] = damage.get("error","Урон не рассчитан"); return
	var zone := {"entity":actor,"item":item,"strike":strike,"kind":"physical","direction":d}
	EventBus.publish(&"WeaponStrikePreviewRequested",zone)
	if not zone.get("accepted",false): e["error"] = zone.get("error","Зона недоступна"); return
	var c: Dictionary = cost["data"]
	var steps := int(round(float(c["duration"]) / 0.01))
	if steps < 1: e["error"] = "Недопустимая длительность"; return
	e["data"] = {"entity":actor,"item":item,"strike":str(strike),"direction":d,"full_cost":c["full_cost"],"available":c["available"],"spend":c["spend"],"damage_multiplier":c["damage_multiplier"],"duration":c["duration"],"duration_steps":steps,"midpoint_step":ceili(float(steps)/2.0),"damage_preview":damage["data"].duplicate(true),"zone_preview":zone["zone"].duplicate(true)}
	e["accepted"] = true
