extends Control
## Изолированный стенд геометрии: мгновенный тест, не анимация удара.
const HERO := &"strike_demo_player"
const RAT := &"strike_demo_rat"
const MAP_SIZE := Vector2i(27, 16)
const TILE := 18.0
const ORIGIN := Vector2(20, 62)
var floors: Dictionary = {}
var zone: Dictionary = {}
var direction := Vector2.RIGHT
var shape_index := 0
var message := "1–3: форма   стрелки: направление   пробел: тест урона"
var hp := 45.0

func _ready() -> void:
	var map := {"size": MAP_SIZE, "accepted": false}
	EventBus.publish(&"SpaceMapConfigureRequested", map)
	var tiles: Array = []
	for x in range(MAP_SIZE.x):
		for y in range(MAP_SIZE.y):
			if x == 0 or y == 0 or x == MAP_SIZE.x - 1 or y == MAP_SIZE.y - 1 or (x == 9 and (y < 7 or y > 8)):
				continue
			var tile := Vector2i(x, y)
			tiles.append(tile)
			floors[tile] = true
	EventBus.publish(&"SpaceTilesSetRequested", {"tiles": tiles, "kind": 1})
	EventBus.publish(&"EntityCreateRequested", {"entity": HERO})
	EventBus.publish(&"EntityCreateRequested", {"entity": RAT})
	var hero := {"entity": HERO, "anchor": Vector2i(3, 7), "size": 2, "accepted": false}
	var rat := {"entity": RAT, "anchor": Vector2i(11, 7), "size": 2, "accepted": false}
	EventBus.publish(&"SpaceBodyPlaceRequested", hero)
	EventBus.publish(&"SpaceBodyPlaceRequested", rat)
	if not map["accepted"] or not hero["accepted"] or not rat["accepted"]:
		message = "Ошибка инициализации стенда"
	_update_zone()

func _shape() -> Dictionary:
	match shape_index:
		0: return {"type": "arc", "angle_degrees": 90, "radius": 10}
		1: return {"type": "line", "length": 10, "width": 2}
		_: return {"type": "cone", "angle_degrees": 60, "length": 10}

func _request() -> Dictionary:
	return {"entity": HERO, "weapon_type": "sword", "direction": direction, "shape": _shape()}

func _update_zone() -> void:
	var request := _request()
	EventBus.publish(&"StrikeZoneGetRequested", request)
	zone = request.get("tile_set", {}) if request["accepted"] else {}
	queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	match event.keycode:
		KEY_1: shape_index = 0
		KEY_2: shape_index = 1
		KEY_3: shape_index = 2
		KEY_LEFT: direction = Vector2.LEFT
		KEY_RIGHT: direction = Vector2.RIGHT
		KEY_UP: direction = Vector2.UP
		KEY_DOWN: direction = Vector2.DOWN
		KEY_SPACE:
			var attack := _request()
			attack["targets"] = [RAT]
			attack["amount"] = 5.0
			EventBus.publish(&"StrikeZoneDamageRequested", attack)
			if attack["accepted"] and not attack["hits"].is_empty() and attack["hits"][0]["accepted"]:
				message = "Попадание: урон 5.0. Время в стенде не идёт."
			else:
				message = "Промах или цель уже погибла."
			var resource := {"entity": RAT, "resource": &"HP", "found": false}
			EventBus.publish(&"ResourceGetRequested", resource)
			if resource["found"]: hp = float(resource["data"]["current"])
		_:
			return
	_update_zone()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("121b26"))
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(20, 25), "Зоны удара: меч, range 6 / gap 2", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_string(font, Vector2(20, 48), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("c9d4e5"))
	for y in range(MAP_SIZE.y):
		for x in range(MAP_SIZE.x):
			var tile := Vector2i(x, y)
			var color := Color("344654") if floors.has(tile) else Color("1a242f")
			if zone.has(tile): color = Color("b78942")
			draw_rect(Rect2(ORIGIN + Vector2(tile) * TILE, Vector2.ONE * (TILE - 1)), color)
	draw_rect(Rect2(ORIGIN + Vector2(3, 7) * TILE + Vector2.ONE * 2, Vector2.ONE * (2 * TILE - 4)), Color("5ed6c1"))
	draw_rect(Rect2(ORIGIN + Vector2(11, 7) * TILE + Vector2.ONE * 2, Vector2.ONE * (2 * TILE - 4)), Color("e36c68"))
	for y in range(7, 9):
		for x in range(11, 13):
			var tile := Vector2i(x, y)
			if zone.has(tile):
				draw_rect(Rect2(ORIGIN + Vector2(tile) * TILE + Vector2.ONE, Vector2.ONE * (TILE - 2)), Color("ffe08c"), false, 2.0)
	var names := ["Дуга", "Линия", "Конус"]
	draw_string(font, Vector2(525, 90), names[shape_index], HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_string(font, Vector2(525, 118), "HP цели: %.0f" % hp, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
	draw_string(font, Vector2(525, 148), "Цветные тайлы —", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("d7c6a8"))
	draw_string(font, Vector2(525, 166), "та же зона, что", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("d7c6a8"))
	draw_string(font, Vector2(525, 184), "использует урон.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("d7c6a8"))
	draw_string(font, Vector2(525, 218), "Размеры форм —", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(525, 236), "только для стенда.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
