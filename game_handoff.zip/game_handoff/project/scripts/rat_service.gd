extends Node
## Спавн вида и телеграфируемое действие укуса. ИИ — отдельный будущий модуль.
var _config: Dictionary = {}
var _bites: Dictionary = {} # rat -> фиксированная зона и параметры действия

func _ready() -> void:
	var request := {"found": false}
	EventBus.publish(&"RulesetGetRequested", request)
	if request["found"]:
		_config = request["ruleset"].get("parameters", {}).get("rat", {}).duplicate(true)
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data": {"id": &"rat_bite", "name": "Укус крысы", "type": &"physical", "base_duration": 0.01, "interruptible": true}})
	EventBus.subscribe(&"RatSpawnRequested", _spawn)
	EventBus.subscribe(&"RatBiteZoneRequested", _zone_requested)
	EventBus.subscribe(&"RatBiteStartRequested", _start_bite)
	EventBus.subscribe(&"RatBiteTelegraphGetRequested", _get_telegraph)
	EventBus.subscribe(&"ActionCompleted", _action_completed)
	EventBus.subscribe(&"ActionInterrupted", _action_interrupted)
	EventBus.subscribe(&"EntityMoved", _entity_moved)
	EventBus.subscribe(&"SpaceBodyRemoved", _body_removed)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"SnapshotRestored", _snapshot_restored)

func _spawn(event: Dictionary) -> void:
	event["accepted"] = false
	event.erase("error")
	var id: StringName = event.get("entity", &"")
	var anchor = event.get("anchor", null)
	if id == &"" or not anchor is Vector2i:
		return _fail(event, "Нужны entity и anchor")
	var exists := {"entity": id, "found": false}
	EventBus.publish(&"EntityGetRequested", exists)
	if exists["found"]:
		return _fail(event, "Сущность уже существует")
	var base := int(_config.get("base_body_size", 4))
	var small_size := int(_config.get("small_body_size", 2))
	var chance = _config.get("small_probability", null)
	if not _number(chance) or float(chance) < 0 or float(chance) > 1 or base != 4 or small_size != 2:
		return _fail(event, "Недопустимые правила размеров крысы")
	var roll := {"accepted": false}
	EventBus.publish(&"RngFloatRequested", roll)
	if not roll["accepted"]:
		return _fail(event, "RNG недоступен")
	var small: bool = float(roll["value"]) < float(chance)
	var body_size := small_size if small else base
	var room = event.get("room", null)
	var fits := {"anchor": anchor, "size": body_size, "room": room, "ignore_entity": &""}
	EventBus.publish(&"SpaceBodyFitsRequested", fits)
	if not fits.get("fits", false):
		event["small"] = small
		event["body_size"] = body_size
		return _fail(event, "Крыса выбранного размера не помещается")
	var tags: Array = ["small"] if small else []
	var poison_chance = _config.get("poisonous_probability", null)
	if not _number(poison_chance) or float(poison_chance) < 0.0 or float(poison_chance) > 1.0:
		return _fail(event, "Не задана вероятность ядовитой крысы")
	var poison_roll := {"accepted":false}
	EventBus.publish(&"RngFloatRequested", poison_roll)
	if not poison_roll["accepted"]: return _fail(event, "RNG недоступен")
	if float(poison_roll["value"]) < float(poison_chance): tags.append("poisonous")
	var create := {"entity": id, "components": {&"stats": _config.get("base_stats", {}), &"species": {"id": "rat", "tags": tags}}, "accepted": false}
	EventBus.publish(&"EntityCreateRequested", create)
	if not create["accepted"]:
		return _fail(event, "Не удалось создать сущность")
	var place := {"entity": id, "anchor": anchor, "size": body_size, "room": room, "accepted": false}
	EventBus.publish(&"SpaceBodyPlaceRequested", place)
	if not place["accepted"]:
		EventBus.publish(&"EntityRemoveRequested", {"entity": id})
		return _fail(event, "Не удалось разместить тело")
	event["accepted"] = true
	event["small"] = small
	event["body_size"] = body_size
	event["tags"] = tags.duplicate()
	EventBus.publish(&"RatSpawned", {"entity": id, "small": small, "body_size": body_size, "tags": tags.duplicate()})

func _zone_requested(event: Dictionary) -> void:
	for key in ["error", "anchor", "center", "direction", "tiles", "visible_tiles", "hit_tiles", "hit"]:
		event.erase(key)
	var zone := _make_zone(event.get("entity", &""), event.get("target", &""))
	event.merge(zone, true)

func _make_zone(rat: StringName, target: StringName) -> Dictionary:
	if rat == &"" or target == &"" or rat == target or not _is_rat(rat):
		return {"accepted": false, "error": "Нужны крыса и другая цель"}
	var rat_body := _body(rat)
	var target_body := _body(target)
	if rat_body.is_empty() or target_body.is_empty():
		return {"accepted": false, "error": "Нет тела крысы или цели"}
	var rat_size := int(rat_body["size"])
	var width := int(_config.get("bite_width", 2))
	var depth := int(_config.get("bite_depth", 2))
	if rat_size not in [2, 4] or width != 2 or depth != 2:
		return {"accepted": false, "error": "Неверный размер тела или укуса"}
	var anchor: Vector2i = rat_body["anchor"]
	var center := Vector2(anchor) + Vector2.ONE * float(rat_size) / 2.0
	var target_position := _position(target, target_body)
	var target_center: Vector2 = target_position + Vector2.ONE * float(target_body["size"]) / 2.0
	var delta := target_center - center
	if delta.length_squared() <= 0.0000001:
		return {"accepted": false, "error": "Направление цели не определено"}
	var facing: Vector2i
	if absf(delta.x) >= absf(delta.y):
		facing = Vector2i.RIGHT if delta.x >= 0.0 else Vector2i.LEFT
	else:
		facing = Vector2i.DOWN if delta.y >= 0.0 else Vector2i.UP
	var rect_origin: Vector2i
	if facing == Vector2i.RIGHT:
		rect_origin = anchor + Vector2i(rat_size, (rat_size - width) / 2)
	elif facing == Vector2i.LEFT:
		rect_origin = anchor + Vector2i(-depth, (rat_size - width) / 2)
	elif facing == Vector2i.DOWN:
		rect_origin = anchor + Vector2i((rat_size - width) / 2, rat_size)
	else:
		rect_origin = anchor + Vector2i((rat_size - width) / 2, -depth)
	var tiles: Array = []
	for y in range(2):
		for x in range(2):
			tiles.append(rect_origin + Vector2i(x, y))
	var visible := _visible_tiles(center, tiles)
	var hit_tiles := _intersect_body(target_position, int(target_body["size"]), visible)
	return {"accepted": true, "entity": rat, "target": target, "anchor": anchor, "center": center, "direction": facing, "tiles": tiles, "visible_tiles": visible, "hit_tiles": hit_tiles, "hit": not hit_tiles.is_empty()}

func _start_bite(event: Dictionary) -> void:
	event["accepted"] = false
	event.erase("error")
	var rat: StringName = event.get("entity", &"")
	var target: StringName = event.get("target", &"")
	var damage = event.get("damage", _config.get("bite_damage", null))
	var duration = event.get("duration", _config.get("bite_duration", null))
	if _bites.has(rat) or not _number(damage) or float(damage) < 0.0 or not _number(duration) or float(duration) <= 0.0:
		return _fail(event, "Нужны урон и длительность укуса")
	var zone := _make_zone(rat, target)
	if not zone["accepted"] or not zone.get("hit", false):
		return _fail(event, "Цель вне зоны укуса или закрыта скалой")
	var actor_alive := {"entity": rat, "allowed": true}
	var target_alive := {"entity": target, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", actor_alive)
	EventBus.publish(&"CombatEntityCanActRequested", target_alive)
	if not actor_alive["allowed"] or not target_alive["allowed"]:
		return _fail(event, "Носитель или цель погибли")
	var entry := {"target": target, "anchor": zone["anchor"], "center": zone["center"], "direction": zone["direction"], "tiles": zone["tiles"].duplicate(), "damage": float(damage), "duration": float(duration), "announced": false}
	_bites[rat] = entry
	var action := {"entity": rat, "target": target, "action": &"rat_bite", "duration": float(duration), "accepted": false}
	EventBus.publish(&"CombatStartActionRequested", action)
	if not action["accepted"] or not _bites.has(rat):
		_bites.erase(rat)
		return _fail(event, "Не удалось начать действие укуса")
	entry["announced"] = true
	event["accepted"] = true
	event["tiles"] = entry["tiles"].duplicate()
	EventBus.publish(&"RatBiteTelegraphStarted", {"entity": rat, "target": target, "tiles": entry["tiles"].duplicate(), "direction": entry["direction"], "duration": entry["duration"]})

func _get_telegraph(event: Dictionary) -> void:
	event.erase("data")
	var entity: StringName = event.get("entity", &"")
	event["found"] = _bites.has(entity)
	if event["found"]:
		event["data"] = _bites[entity].duplicate(true)

func _action_completed(event: Dictionary) -> void:
	var rat: StringName = event.get("entity", &"")
	if event.get("action", &"") != &"rat_bite" or not _bites.has(rat):
		return
	var bite: Dictionary = _bites[rat]
	_bites.erase(rat)
	if not bite.get("announced", false):
		return
	var rat_body := _body(rat)
	var target: StringName = bite["target"]
	var body := _body(target)
	var hit_tiles: Array = []
	var applied := 0.0
	var accepted := false
	if not rat_body.is_empty() and rat_body["anchor"] == bite["anchor"] and not body.is_empty():
		var visible := _visible_tiles(bite["center"], bite["tiles"])
		hit_tiles = _intersect_body(_position(target, body), int(body["size"]), visible)
		if not hit_tiles.is_empty():
			var damage := {"entity": target, "source": rat, "amount": bite["damage"], "damage_type":"physical", "accepted": false}
			EventBus.publish(&"CombatDamageRequested", damage)
			accepted = damage["accepted"]
			applied = float(damage.get("applied", 0.0))
			if accepted and applied > 0.0: _try_poison(rat, target)
	EventBus.publish(&"RatBiteTelegraphEnded", {"entity": rat, "target": target, "reason": &"completed"})
	EventBus.publish(&"RatBiteResolved", {"entity": rat, "target": target, "hit": not hit_tiles.is_empty(), "hit_tiles": hit_tiles, "damage_accepted": accepted, "applied": applied})

func _try_poison(rat: StringName, target: StringName) -> void:
	var species := {"entity":rat, "component":&"species", "found":false}
	EventBus.publish(&"ComponentGetRequested", species)
	if not species.get("found", false) or not species["data"].get("tags", []).has("poisonous"): return
	var chance = _config.get("poison_apply_probability", null)
	var amount = _config.get("poison_damage_per_tick", null)
	var duration = _config.get("poison_base_duration", null)
	if not _number(chance) or float(chance) < 0.0 or float(chance) > 1.0 or not _number(amount) or float(amount) < 0.0 or not _number(duration) or float(duration) <= 0.0: return
	var roll := {"accepted":false}
	EventBus.publish(&"RngFloatRequested", roll)
	if not roll["accepted"] or float(roll["value"]) >= float(chance): return
	EventBus.publish(&"PeriodicEffectApplyRequested", {"entity":target, "effect":&"poison", "source":rat, "damage_type":"physical", "damage_per_tick":amount, "base_duration":duration})

func _action_interrupted(event: Dictionary) -> void:
	var rat: StringName = event.get("entity", &"")
	if event.get("action", &"") == &"rat_bite" and _bites.has(rat):
		var bite: Dictionary = _bites[rat]
		_bites.erase(rat)
		if bite.get("announced", false):
			EventBus.publish(&"RatBiteTelegraphEnded", {"entity": rat, "target": bite["target"], "reason": event.get("reason", &"interrupted")})

func _entity_moved(event: Dictionary) -> void:
	var rat: StringName = event.get("entity", &"")
	if _bites.has(rat) and event.get("to", null) != _bites[rat]["anchor"]:
		EventBus.publish(&"ActionCancelRequested", {"entity": rat, "reason": &"attacker_moved"})
func _body_removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if _bites.has(entity):
		EventBus.publish(&"ActionCancelRequested", {"entity": entity, "reason": &"attacker_body_removed"})
	for rat in _bites.keys():
		if _bites[rat]["target"] == entity:
			EventBus.publish(&"ActionCancelRequested", {"entity": rat, "reason": &"target_body_removed"})
func _entity_removed(event: Dictionary) -> void:
	_bites.erase(event.get("entity", &""))

func _visible_tiles(center: Vector2, tiles: Array) -> Array:
	var result: Array = []
	var from := Vector2i(floori(center.x), floori(center.y))
	for tile in tiles:
		var query := {"from": from, "to": tile, "accepted": false}
		EventBus.publish(&"SpaceLineOfSightRequested", query)
		if query["accepted"] and query["visible"]:
			result.append(tile)
	return result
func _intersect_body(position: Vector2, size: int, tiles: Array) -> Array:
	var hits: Array = []
	var body := Rect2(position, Vector2.ONE * float(size))
	for tile in tiles:
		if body.intersects(Rect2(Vector2(tile), Vector2.ONE)):
			hits.append(tile)
	return hits
func _body(entity: StringName) -> Dictionary:
	var query := {"entity": entity, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", query)
	return query.get("data", {}) if query["found"] else {}
func _position(entity: StringName, body: Dictionary) -> Vector2:
	var query := {"entity": entity, "found": false}
	EventBus.publish(&"MovementPositionGetRequested", query)
	return query["position"] if query["found"] else Vector2(body["anchor"])
func _is_rat(entity: StringName) -> bool:
	var query := {"entity": entity, "component": &"species", "found": false}
	EventBus.publish(&"ComponentGetRequested", query)
	return query["found"] and query["data"].get("id", "") == "rat"
func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))
func _fail(event: Dictionary, text: String) -> void:
	event["error"] = text
func _snapshot_collect(event: Dictionary) -> void:
	event["sections"]["rats"] = {"bites": _bites.duplicate(true)}
func _snapshot_apply(event: Dictionary) -> void:
	_bites = event["sections"]["rats"]["bites"].duplicate(true)

func _snapshot_restored(_event: Dictionary) -> void:
	for rat in _bites:
		var bite: Dictionary = _bites[rat]
		EventBus.publish(&"RatBiteTelegraphStarted", {"entity": rat, "target": bite["target"], "tiles": bite["tiles"].duplicate(), "direction": bite["direction"], "duration": bite["duration"], "restored": true})
