extends Control
## Изолированный стенд телеграфа, урон/длительность укуса заданы только для примера.
const HERO := &"rat_demo_hero"
const RAT := &"rat_demo_rat"
const MAP_SIZE := Vector2i(27, 16)
const TILE := 18.0
const ORIGIN := Vector2(20, 62)
var floors: Dictionary = {}
var telegraph: Dictionary = {}
var hero_anchor := Vector2i(8, 5)
var hp := 45.0
var message := "Пробел: укус. Стрелки: уклонение (низкоуровневый перенос)."

func _ready() -> void:
	EventBus.subscribe(&"RatBiteResolved", _on_resolved)
	EventBus.subscribe(&"RatBiteTelegraphEnded", _on_ended)
	EventBus.subscribe(&"EntityDamaged", _on_damage)
	var map := {"size": MAP_SIZE, "accepted": false}
	EventBus.publish(&"SpaceMapConfigureRequested", map)
	var tiles: Array = []
	for x in range(1, MAP_SIZE.x - 1):
		for y in range(1, MAP_SIZE.y - 1):
			var tile := Vector2i(x, y)
			tiles.append(tile)
			floors[tile] = true
	EventBus.publish(&"SpaceTilesSetRequested", {"tiles": tiles, "kind": 1})
	EventBus.publish(&"EntityCreateRequested", {"entity": HERO})
	var hero := {"entity": HERO, "anchor": hero_anchor, "size": 4, "accepted": false}
	EventBus.publish(&"SpaceBodyPlaceRequested", hero)
	var control := {"entity": HERO, "accepted": false}
	EventBus.publish(&"ControlledEntityRequested", control)
	# В стенде намеренно нужен один маленький экземпляр; поиск seed использует общий RNG.
	var small_seed := -1
	for seed in range(100):
		EventBus.publish(&"RngSeedRequested", {"seed": seed})
		var roll := {}
		EventBus.publish(&"RngFloatRequested", roll)
		if float(roll["value"]) < 0.8:
			small_seed = seed
			break
	EventBus.publish(&"RngSeedRequested", {"seed": small_seed})
	var rat := {"entity": RAT, "anchor": Vector2i(6, 6), "accepted": false}
	EventBus.publish(&"RatSpawnRequested", rat)
	if not map["accepted"] or not hero["accepted"] or not control["accepted"] or not rat["accepted"] or not rat.get("small", false):
		message = "Ошибка инициализации стенда."

func _process(_delta: float) -> void:
	var query := {"entity": RAT, "found": false}
	EventBus.publish(&"RatBiteTelegraphGetRequested", query)
	telegraph.clear()
	if query["found"]:
		for tile in query["data"]["tiles"]:
			telegraph[tile] = true
	queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	var delta := Vector2i.ZERO
	match event.keycode:
		KEY_LEFT: delta = Vector2i.LEFT
		KEY_RIGHT: delta = Vector2i.RIGHT
		KEY_UP: delta = Vector2i.UP
		KEY_DOWN: delta = Vector2i.DOWN
		KEY_SPACE:
			if TimeDriver.is_action_active:
				message = "Дождитесь завершения ожидания."
				return
			var bite := {"entity": RAT, "target": HERO, "damage": 5.0, "duration": 0.8, "accepted": false}
			EventBus.publish(&"RatBiteStartRequested", bite)
			if bite["accepted"]:
				var wait := {"entity": HERO, "action": &"wait", "duration": 0.9, "accepted": false}
				EventBus.publish(&"ActionStartRequested", wait)
				message = "Укус готовится: красные тайлы — фиксированная зона."
			else:
				message = "Не удалось начать укус: " + str(bite.get("error", "ошибка"))
			return
		_: return
	var move := {"entity": HERO, "anchor": hero_anchor + delta, "accepted": false}
	EventBus.publish(&"SpaceBodyMoveRequested", move)
	if move["accepted"]:
		hero_anchor = move["anchor"]
	else:
		message = "Тело не помещается."
	queue_redraw()

func _on_resolved(event: Dictionary) -> void:
	message = "Попадание!" if event["hit"] else "Промах: цель ушла из телеграфа."
func _on_ended(event: Dictionary) -> void:
	if event.get("reason", &"") != &"completed":
		message = "Укус отменён: " + str(event.get("reason", &""))
func _on_damage(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO:
		var query := {"entity": HERO, "resource": &"HP", "found": false}
		EventBus.publish(&"ResourceGetRequested", query)
		if query["found"]: hp = float(query["data"]["current"])

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("121b26"))
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(20, 25), "Крыса 2×2: телеграф укуса", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_string(font, Vector2(20, 48), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("c9d4e5"))
	for y in range(MAP_SIZE.y):
		for x in range(MAP_SIZE.x):
			var tile := Vector2i(x, y)
			var color := Color("344654") if floors.has(tile) else Color("1a242f")
			if telegraph.has(tile): color = Color("ac493c")
			draw_rect(Rect2(ORIGIN + Vector2(tile) * TILE, Vector2.ONE * (TILE - 1)), color)
	draw_rect(Rect2(ORIGIN + Vector2(6, 6) * TILE + Vector2.ONE * 2, Vector2.ONE * (2 * TILE - 4)), Color("e36c68"))
	draw_rect(Rect2(ORIGIN + Vector2(hero_anchor) * TILE + Vector2.ONE * 2, Vector2.ONE * (4 * TILE - 4)), Color("5ed6c1"))
	for tile in telegraph:
		draw_rect(Rect2(ORIGIN + Vector2(tile) * TILE + Vector2.ONE, Vector2.ONE * (TILE - 2)), Color("ff9b77"), false, 2.0)
	draw_string(font, Vector2(525, 90), "HP игрока: %.0f" % hp, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
	draw_string(font, Vector2(525, 122), "Укус 0.8 с / 5 HP", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(525, 140), "только для стенда.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(525, 170), "Движение стрелками", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(525, 188), "мгновенное, тестовое.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
