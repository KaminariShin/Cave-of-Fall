extends Node
var _rules: Dictionary = {}
const RULESET_PATH := "res://config/ruleset.json"

func _ready() -> void:
	EventBus.subscribe(&"RulesetGetRequested", _on_get)
	reload_rules()

func reload_rules() -> bool:
	if not FileAccess.file_exists(RULESET_PATH):
		return false
	var file := FileAccess.open(RULESET_PATH, FileAccess.READ)
	if file == null:
		return false
	var parsed = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary or not parsed.get("version", null) is String or str(parsed["version"]).is_empty():
		return false
	_rules = parsed.duplicate(true)
	return true

func _on_get(event: Dictionary) -> void:
	event["found"] = not _rules.is_empty()
	event["ruleset"] = _rules.duplicate(true)
