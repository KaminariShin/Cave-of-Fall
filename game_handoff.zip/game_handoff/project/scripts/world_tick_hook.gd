extends Node
## Проводит только проверку событий, не создаёт существ и не меняет тайлы.
var _definitions: Array = []
var _room_id: StringName = &""
var _room_type: StringName = &""
var _active: Dictionary = {} # process_id -> {event, room}
var _sequence: int = 0
var _enabled := true

func _ready() -> void:
	EventBus.subscribe(&"Tick", _on_tick)
	EventBus.subscribe(&"PlayerRoomChanged", _on_room_changed)
	EventBus.subscribe(&"ProcessCompleted", _on_process_ended)
	EventBus.subscribe(&"ProcessInterrupted", _on_process_ended)
	EventBus.subscribe(&"SnapshotCollectRequested", _on_snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _on_snapshot_apply)
	_load_rules()

func _load_rules() -> void:
	var request := {"found": false}
	EventBus.publish(&"RulesetGetRequested", request)
	if not request["found"]:
		return
	var tables = request["ruleset"].get("tables", {})
	if tables is Dictionary and tables.get("world_events", null) is Array:
		_definitions = tables["world_events"].duplicate(true)

func _on_room_changed(event: Dictionary) -> void:
	_room_id = StringName(str(event.get("room", "")))
	_room_type = StringName(str(event.get("room_type", "")))

func _on_tick(event: Dictionary) -> void:
	if not _enabled or _room_id == &"" or _room_type == &"":
		return
	# Снимок комнаты не позволяет случайно проверить за один шаг две комнаты.
	var room := _room_id
	var room_type := _room_type
	for definition in _definitions:
		if not _valid_definition(definition, room_type):
			continue
		var event_id := StringName(str(definition["id"]))
		# Одно событие каждого типа на комнату. Повтор только после завершения.
		if _is_active(event_id, room):
			continue
		var base_chance := float(definition["chance_per_step"])
		var chance := base_chance + _cascade_bonus(event_id, room)
		# Будущие системы могут каждый шаг менять условия/шанс через шину.
		var query := {"event": event_id, "room": room, "room_type": room_type, "dt": event["dt"], "game_time": event["game_time"], "eligible": true, "chance": chance}
		EventBus.publish(&"WorldEventChanceEvaluating", query)
		if not bool(query.get("eligible", false)):
			continue
		var modified = query.get("chance", null)
		if not (modified is int or modified is float) or not is_finite(float(modified)):
			continue
		chance = clampf(float(modified), 0.0, 1.0)
		# Для каждой пригодной записи вызываем RNG, даже при вероятности 0 или 1.
		var roll := {"accepted": false}
		EventBus.publish(&"RngFloatRequested", roll)
		if not roll["accepted"] or chance <= 0.0 or (chance < 1.0 and float(roll["value"]) >= chance):
			continue
		_start_event(event_id, room, float(definition["duration"]))

func _start_event(event_id: StringName, room: StringName, duration: float) -> void:
	# ID уникален в рамках сохранённого забега. При коллизии с другим процессом
	# реестр отклоняет запрос; существующий процесс не заменяется.
	_sequence += 1
	var process_id := StringName("world:%s:%s:%d" % [room, event_id, _sequence])
	var request := {"id": process_id, "duration": duration, "entity": &"", "independent": true, "accepted": false}
	_active[process_id] = {"event": event_id, "room": room}
	EventBus.publish(&"ProcessStartRequested", request)
	if not request["accepted"]:
		_active.erase(process_id)
		EventBus.publish(&"WorldEventStartFailed", {"event": event_id, "room": room, "process": process_id})
		return
	if not _active.has(process_id):
		return
	EventBus.publish(&"WorldEventActivated", {"event": event_id, "room": room, "process": process_id, "duration": duration})

func _on_process_ended(event: Dictionary) -> void:
	var process_id: StringName = event.get("process", &"")
	if not _active.has(process_id):
		return
	var data: Dictionary = _active[process_id]
	_active.erase(process_id)
	EventBus.publish(&"WorldEventEnded", {"event": data["event"], "room": data["room"], "process": process_id, "reason": event.get("reason", &"completed")})

func _cascade_bonus(target: StringName, room: StringName) -> float:
	var bonus := 0.0
	for process_id in _active:
		var active: Dictionary = _active[process_id]
		if active["room"] != room:
			continue
		for definition in _definitions:
			if not definition is Dictionary or StringName(str(definition.get("id", ""))) != active["event"]:
				continue
			var boosts = definition.get("cascade", {})
			if boosts is Dictionary:
				var value = boosts.get(str(target), 0.0)
				if (value is int or value is float) and is_finite(float(value)):
					bonus += float(value)
	return bonus

func _is_active(event_id: StringName, room: StringName) -> bool:
	for data in _active.values():
		if data["event"] == event_id and data["room"] == room:
			return true
	return false

func _valid_definition(definition: Variant, room_type: StringName) -> bool:
	if not definition is Dictionary or str(definition.get("id", "")).is_empty():
		return false
	var rooms = definition.get("room_types", null)
	var chance = definition.get("chance_per_step", null)
	var duration = definition.get("duration", null)
	if not rooms is Array or not rooms.has(str(room_type)):
		return false
	if not (chance is int or chance is float) or not is_finite(float(chance)) or float(chance) < 0.0 or float(chance) > 1.0:
		return false
	if not (duration is int or duration is float) or not is_finite(float(duration)) or float(duration) <= 0.0 or float(duration) > 10000000.0:
		return false
	return absf(round(float(duration) / 0.01) * 0.01 - float(duration)) <= 0.000001

func _on_snapshot_collect(event: Dictionary) -> void:
	event["sections"]["world_hook"] = {"room": _room_id, "room_type": _room_type, "active": _active.duplicate(true), "sequence": _sequence, "enabled": _enabled}

func _on_snapshot_apply(event: Dictionary) -> void:
	var saved: Dictionary = event["sections"]["world_hook"]
	_room_id = saved["room"]
	_room_type = saved["room_type"]
	_active = saved["active"].duplicate(true)
	_sequence = saved["sequence"]
	_enabled = saved["enabled"]
