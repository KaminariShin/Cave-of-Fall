extends Node
## Техническое групповое планирование: без отправки заявок или урона.
const MAX_ROWS := 10000
const MAX_TILES := 300000
const LIMIT := 1000000000.0
var _busy := false
func _ready() -> void:
	EventBus.subscribe(&"WeaponStrikePhasePlanRequested",_plan)
func _plan(e: Dictionary) -> void:
	e["accepted"] = false; e.erase("error"); e.erase("data")
	if _busy or not TimeDriver._combat_phase:
		e["error"] = "План доступен только в боевой фазе без вложенного вызова"; return
	var requests = e.get("attacks",null)
	if not requests is Array or requests.is_empty() or requests.size() > MAX_ROWS:
		e["error"] = "Нужен ограниченный непустой список ударов"; return
	_busy = true
	var result := _build(requests.duplicate(true))
	_busy = false
	if not result.get("accepted",false): e["error"] = result.get("error","План не создан"); return
	e["accepted"] = true; e["data"] = result["data"]
func _fail(message: String) -> Dictionary: return {"accepted":false,"error":message}
func _build(requests: Array) -> Dictionary:
	var due := {}
	for row in ActionRegistry.combat_phase_due():
		if row.get("action",null) == &"weapon_strike": due[row["entity"]] = true
	var seen := {}
	var candidate_count := 0
	for request in requests:
		if not request is Dictionary: return _fail("Некорректный запрос удара")
		var actor = request.get("entity",null)
		var candidates = request.get("candidates",null)
		if not actor is StringName or actor == &"" or seen.has(actor) or not due.has(actor) or not candidates is Array: return _fail("Нужны разные удары, готовые в этой фазе")
		candidate_count += candidates.size()
		if candidate_count > MAX_ROWS: return _fail("Слишком много кандидатов")
		seen[actor] = true
	requests.sort_custom(func(a,b): return str(a["entity"]) < str(b["entity"]))
	var snapshots: Array = []
	var health_by_target := {}
	var protection_by_target := {}
	var total_hits := 0
	var total_tiles := 0
	# Получить все подготовленные входные данные до первого броска.
	for request in requests:
		var capture := {"entity":request["entity"],"candidates":request["candidates"]}
		EventBus.publish(&"WeaponStrikeHitSnapshotRequested",capture)
		if not capture.get("accepted",false): return _fail(str(capture.get("error","Ошибка чтения удара")))
		var data: Dictionary = capture["data"]
		var crit := {"per":data["per"]}
		EventBus.publish(&"CriticalHitPreviewRequested",crit)
		if not crit.get("accepted",false): return _fail(str(crit.get("error","Ошибка крита")))
		var max_physical: float = float(data["physical"]) * float(crit["data"]["critical_multiplier"])
		if not is_finite(max_physical) or max_physical > LIMIT: return _fail("Критический урон слишком велик")
		for target in data["targets"]:
			var id: StringName = target["target"]
			if (health_by_target.has(id) and health_by_target[id] != target["hp_before"]) or (protection_by_target.has(id) and protection_by_target[id] != target["physical_protection_percent"]): return _fail("Несогласованные HP или защита цели")
			health_by_target[id] = target["hp_before"]
			protection_by_target[id] = target["physical_protection_percent"]
			total_hits += 1; total_tiles += target["attack_tiles"].size()
			if total_hits > MAX_ROWS or total_tiles > MAX_TILES: return _fail("Превышен размер пакета")
			var validate := {"physical":max_physical,"magical":0.0,"physical_protection_percent":target["physical_protection_percent"],"magical_protection_percent":0.0,"weakening_multiplier":data["weakening_multiplier"]}
			EventBus.publish(&"DirectHitMitigationPreviewRequested",validate)
			if not validate.get("accepted",false): return _fail(str(validate.get("error","Ошибка защиты")))
		snapshots.append(data)
	var hits: Array = []
	var attacks: Array = []
	for data in snapshots:
		var rows: Array = data["targets"]
		if rows.is_empty():
			attacks.append({"entity":data["source"],"hit_count":0}); continue
		var plan: Dictionary = data.duplicate(true)
		EventBus.publish(&"PreparedDirectHitPlanRequested",plan)
		if not plan.get("accepted",false): return _fail(str(plan.get("error","Ошибка подготовки попаданий")))
		hits.append_array(plan["data"]["hits"])
		attacks.append({"entity":data["source"],"hit_count":rows.size()})
	return {"accepted":true,"data":{"attacks":attacks,"hits":hits}}
