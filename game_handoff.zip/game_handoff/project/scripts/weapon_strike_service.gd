extends Node
## Strike content and preview; no automatic attack execution without equipment.
var _strikes: Dictionary = {}
func _ready() -> void:
	EventBus.subscribe(&"WeaponStrikeRegisterRequested", _register)
	EventBus.subscribe(&"WeaponStrikesGetRequested", _list)
	EventBus.subscribe(&"WeaponStrikePreviewRequested", _preview)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"WeaponStrikeSnapshotValidateRequested", _validate_snapshot)
	var req := {"found":false}
	EventBus.publish(&"RulesetGetRequested", req)
	if req["found"]:
		for definition in req["ruleset"].get("tables", {}).get("weapon_strikes", []):
			_register({"definition":definition})
func _number(x: Variant) -> bool:
	return (x is int or x is float) and is_finite(float(x))
func _valid(d: Variant) -> bool:
	if not d is Dictionary or str(d.get("id", "")).is_empty() or str(d.get("name", "")).is_empty() or not d.get("variants", null) is Array or d["variants"].is_empty(): return false
	var seen := {}
	for variant in d["variants"]:
		if not (variant is String or variant is StringName) or str(variant).is_empty() or seen.has(str(variant)): return false
		seen[str(variant)] = true
	for name in ["speed_effectiveness", "damage", "range"]:
		if not _number(d.get(name, null)): return false
	if float(d["speed_effectiveness"]) <= 0 or float(d["damage"]) < 0 or float(d["range"]) < 0: return false
	var shape = d.get("zone", null)
	if not shape is Dictionary: return false
	if d.has("technique") and str(d["technique"]) not in ["piercing", "cutting", "chopping", "blunt"]: return false
	var kind := str(shape.get("type", ""))
	if shape.has("reach_bound") and not shape["reach_bound"] is bool: return false
	if shape.get("reach_bound", false):
		if shape.has("radius") or shape.has("diameter") or shape.has("length"): return false
		if kind == "line": return _number(shape.get("width", null)) and float(shape["width"]) > 0
		return kind == "arc" and _number(shape.get("angle_degrees", null)) and float(shape["angle_degrees"]) > 0 and float(shape["angle_degrees"]) <= 360
	if kind == "line":
		return _number(shape.get("length", null)) and float(shape["length"]) > 0 and _number(shape.get("width", null)) and float(shape["width"]) > 0
	if kind not in ["arc", "cone"] or not _number(shape.get("angle_degrees", null)) or float(shape["angle_degrees"]) <= 0 or float(shape["angle_degrees"]) > 360: return false
	if kind == "cone": return _number(shape.get("length", null)) and float(shape["length"]) > 0
	if shape.has("radius") == shape.has("diameter"): return false
	var size = shape.get("radius", shape.get("diameter", null))
	return _number(size) and float(size) > 0
func _register(e: Dictionary) -> void:
	e["accepted"] = false
	var d = e.get("definition", null)
	if not _valid(d) or _strikes.has(str(d["id"])): return
	for id in d["variants"]:
		var q := {"variant":id, "found":false}
		EventBus.publish(&"WeaponVariantResolveRequested", q)
		if not q["found"]: return
	_strikes[str(d["id"])] = d.duplicate(true)
	e["accepted"] = true
func _weapon(e: Dictionary) -> Dictionary:
	var q := {"found":false}
	if e.has("item") == e.has("variant"): return q
	if e.has("item"):
		q["item"] = e["item"]
		EventBus.publish(&"WeaponItemResolveRequested", q)
	else:
		q["variant"] = e["variant"]
		EventBus.publish(&"WeaponVariantResolveRequested", q)
	return q
func _list(e: Dictionary) -> void:
	e["found"] = false
	var weapon := _weapon(e)
	if not weapon["found"]: return
	var list: Array = []
	for id in _strikes:
		var strike: Dictionary = _strikes[id]
		for variant in strike["variants"]:
			if str(variant) == weapon["data"]["id"]:
				list.append(strike.duplicate(true))
				break
	e["found"] = true
	e["strikes"] = list
# Одинаковая поправка для всех оружейных атак ближнего боя.
# Старые сохранения хранят старые определения, поэтому адаптация выполняется
# при каждом расчёте, не изменяя исходных таблиц и сохранённых данных.
func adjust_attack_zone(zone: Dictionary, strike: Dictionary) -> void:
	var weapon_type := str(zone.get("weapon_type",""))
	if weapon_type in ["bow","crossbow"]: return
	var weapon: Dictionary = StrikeZoneService._weapons.get(weapon_type,{})
	var old_gap = zone.get("gap",weapon.get("gap",null))
	if not _number(old_gap) or not _number(zone.get("range",null)) or float(old_gap) < 0.0: return
	var shift := minf(2.0,float(old_gap))
	zone["gap"] = float(old_gap) - shift
	zone["range"] = maxf(0.0,float(zone["range"]) + shift - 1.0)

func _preview(e: Dictionary) -> void:
	e["accepted"] = false
	var list := {"found":false}
	for key in ["variant", "item"]:
		if e.has(key): list[key] = e[key]
	_list(list)
	if not list["found"]: return
	var strike: Dictionary = {}
	for entry in list["strikes"]:
		if str(entry["id"]) == str(e.get("strike", "")): strike = entry
	if strike.is_empty():
		e["error"] = "Удар недоступен выбранному виду оружия"
		return
	var timing := {"entity":e.get("entity", &""), "kind":e.get("kind", ""), "speed_effectiveness":strike["speed_effectiveness"]}
	for key in ["variant", "item"]:
		if e.has(key): timing[key] = e[key]
	EventBus.publish(&"WeaponAttackTimingRequested", timing)
	if not timing.get("accepted", false):
		e["error"] = timing.get("error", "Расчёт времени недоступен")
		return
	var w: Dictionary = timing["data"]["weapon"]
	var zone := {"entity":e.get("entity", &""), "direction":e.get("direction", null), "weapon_type":w["type"], "range":strike["range"], "shape":strike["zone"]}
	if e.has("gap"): zone["gap"] = e["gap"]
	adjust_attack_zone(zone,strike)
	EventBus.publish(&"StrikeZoneGetRequested", zone)
	if not zone.get("accepted", false):
		e["error"] = zone.get("error", "Не удалось рассчитать зону")
		return
	e["accepted"] = true
	e["strike_data"] = strike.duplicate(true)
	e["timing"] = timing["data"]
	e["zone"] = zone
func _collect(e: Dictionary) -> void:
	e["sections"]["weapon_strikes"] = {"definitions":_strikes.duplicate(true)}
func _apply(e: Dictionary) -> void:
	_strikes = e["sections"]["weapon_strikes"]["definitions"].duplicate(true)
func _validate_snapshot(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", {})
	var part = sections.get("weapon_strikes", null)
	var weapon = sections.get("weapons", null)
	if not part is Dictionary or not part.get("definitions", null) is Dictionary or not weapon is Dictionary or not weapon.get("variants", null) is Dictionary: return
	for id in part["definitions"]:
		var d = part["definitions"][id]
		if not id is String or not _valid(d) or str(d["id"]) != id: return
		for variant in d["variants"]:
			if not weapon["variants"].has(str(variant)): return
	e["valid"] = true
