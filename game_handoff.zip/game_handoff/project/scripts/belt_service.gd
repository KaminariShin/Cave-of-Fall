extends Node
## Каркас без каталога и игровых эффектов модулей: подробное ТЗ отложено.
var _slots_max := 6
var _types: Dictionary = {}
var _module_types: Dictionary = {}
var _belts: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"BeltTypeRegisterRequested", _register_belt_type)
	EventBus.subscribe(&"BeltModuleTypeRegisterRequested", _register_module_type)
	EventBus.subscribe(&"BeltInitializeRequested", _initialize_belt)
	EventBus.subscribe(&"BeltSlotsSetRequested", _set_slots)
	EventBus.subscribe(&"BeltModuleInstallRequested", _install_module)
	EventBus.subscribe(&"BeltModuleRemoveRequested", _remove_module)
	EventBus.subscribe(&"BeltGetRequested", _get_belt)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	var request := {"found": false}
	EventBus.publish(&"RulesetGetRequested", request)
	if request["found"]:
		var rules: Dictionary = request["ruleset"]
		_slots_max = int(rules.get("parameters", {}).get("belt", {}).get("slots_max", 6))
		var tables: Dictionary = rules.get("tables", {})
		for type in tables.get("belt_types", []):
			_register_belt_type({"definition": type})
		for module in tables.get("belt_modules", []):
			_register_module_type({"definition": module})

func _register_belt_type(event: Dictionary) -> void:
	event["accepted"] = false
	var data = event.get("definition", null)
	if not data is Dictionary:
		return
	var id := StringName(str(data.get("id", "")))
	var minimum = data.get("slots_min", null)
	if id == &"" or _types.has(id) or not minimum is int or minimum < 0 or minimum > _slots_max:
		return
	_types[id] = data.duplicate(true)
	event["accepted"] = true

func _register_module_type(event: Dictionary) -> void:
	event["accepted"] = false
	var data = event.get("definition", null)
	if not data is Dictionary:
		return
	var id := StringName(str(data.get("id", "")))
	var size = data.get("slots", null)
	if id == &"" or _module_types.has(id) or not size is int or size < 1 or size > _slots_max:
		return
	_module_types[id] = data.duplicate(true)
	event["accepted"] = true

## Экземпляр пояса — существующий предмет, чья база объявляет slot = belt.
## Можно указать количество слотов; по умолчанию — минимум конкретного типа.
func _initialize_belt(event: Dictionary) -> void:
	event["accepted"] = false
	var item_id := StringName(str(event.get("item", "")))
	var type_id := StringName(str(event.get("type_id", "")))
	if item_id == &"" or _belts.has(item_id) or not _types.has(type_id):
		return
	var item := {"item": item_id, "found": false}
	EventBus.publish(&"ItemGetRequested", item)
	if not item["found"] or str(item["base"].get("slot", "")) != "belt":
		return
	var slots = event.get("slots", _types[type_id]["slots_min"])
	if not _valid_slots(type_id, slots):
		return
	_belts[item_id] = {"type_id": type_id, "slots": slots, "modules": []}
	event["accepted"] = true
	EventBus.publish(&"BeltChanged", {"item": item_id})

func _set_slots(event: Dictionary) -> void:
	event["accepted"] = false
	var item_id := StringName(str(event.get("item", "")))
	var slots = event.get("slots", null)
	if not _belts.has(item_id):
		return
	var belt: Dictionary = _belts[item_id]
	if not _valid_slots(belt["type_id"], slots) or slots < _used(belt):
		return
	belt["slots"] = slots
	event["accepted"] = true
	EventBus.publish(&"BeltChanged", {"item": item_id})

## module — уникальный ID установленного экземпляра, type_id — его тип.
## Установка является операцией данных, не игровым действием или крафтом.
func _install_module(event: Dictionary) -> void:
	event["accepted"] = false
	var item_id := StringName(str(event.get("item", "")))
	var module_id := StringName(str(event.get("module", "")))
	var type_id := StringName(str(event.get("type_id", "")))
	if not _belts.has(item_id) or module_id == &"" or not _module_types.has(type_id) or _has_module(module_id):
		return
	var belt: Dictionary = _belts[item_id]
	var size: int = _module_types[type_id]["slots"]
	if _used(belt) + size > belt["slots"]:
		return
	belt["modules"].append({"id": module_id, "type_id": type_id, "slots": size})
	event["accepted"] = true
	EventBus.publish(&"BeltModuleInstalled", {"item": item_id, "module": module_id, "type_id": type_id})
	EventBus.publish(&"BeltChanged", {"item": item_id})

func _remove_module(event: Dictionary) -> void:
	event["accepted"] = false
	var item_id := StringName(str(event.get("item", "")))
	var module_id := StringName(str(event.get("module", "")))
	if not _belts.has(item_id):
		return
	var modules: Array = _belts[item_id]["modules"]
	for index in range(modules.size()):
		if modules[index]["id"] == module_id:
			modules.remove_at(index)
			event["accepted"] = true
			EventBus.publish(&"BeltModuleRemoved", {"item": item_id, "module": module_id})
			EventBus.publish(&"BeltChanged", {"item": item_id})
			return

func _get_belt(event: Dictionary) -> void:
	var item_id := StringName(str(event.get("item", "")))
	event["found"] = _belts.has(item_id)
	if not event["found"]:
		return
	var belt: Dictionary = _belts[item_id]
	event["data"] = belt.duplicate(true)
	event["data"]["slots_min"] = _types[belt["type_id"]]["slots_min"]
	event["data"]["slots_max"] = _slots_max
	event["data"]["used_slots"] = _used(belt)
	event["data"]["free_slots"] = belt["slots"] - event["data"]["used_slots"]

# Только для наземных экземпляров, списываемых при смене этажа.
# Модули в текущем каркасе — вложенные данные пояса, а не экземпляры вещей.
func discard_item_metadata_for_transition(ids: Array) -> bool:
	if not LootService.is_discarding_ground_items(ids) and not ObjectGenerationService.is_discarding_object_items(ids) and not FloorSpawnCleanup.is_discarding_items(ids): return false
	for id in ids: _belts.erase(id)
	return true

func _valid_slots(type_id: StringName, slots: Variant) -> bool:
	return slots is int and slots >= int(_types[type_id]["slots_min"]) and slots <= _slots_max

func _used(belt: Dictionary) -> int:
	var result := 0
	for module in belt["modules"]:
		result += int(module["slots"])
	return result

func _has_module(module_id: StringName) -> bool:
	for belt in _belts.values():
		for module in belt["modules"]:
			if module["id"] == module_id:
				return true
	return false

func _snapshot_collect(event: Dictionary) -> void:
	event["sections"]["belts"] = {"types": _types.duplicate(true), "module_types": _module_types.duplicate(true), "items": _belts.duplicate(true)}

func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["belts"]
	_types = data["types"].duplicate(true)
	_module_types = data["module_types"].duplicate(true)
	_belts = data["items"].duplicate(true)
