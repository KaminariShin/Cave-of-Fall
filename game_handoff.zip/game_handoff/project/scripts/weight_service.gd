extends Node
## Физический и бюджетный вес — разные величины, они не смешиваются.
var _base := 20.0
var _per_str := 5.0
var _tiers: Array = []
var _cache: Dictionary = {}

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var params: Dictionary = rules["ruleset"].get("parameters", {}).get("weight", {})
		_base = float(params.get("capacity_base_kg", 20.0))
		_per_str = float(params.get("capacity_per_str_kg", 5.0))
		_tiers = params.get("tiers", []).duplicate(true)
	EventBus.subscribe(&"EntityCreated", _on_entity_created)
	EventBus.subscribe(&"EntityRemoved", _on_entity_removed)
	EventBus.subscribe(&"ComponentChanged", _on_component_changed)
	EventBus.subscribe(&"ComponentRemoved", _on_component_changed)
	EventBus.subscribe(&"StatChanged", _on_stat_changed)
	EventBus.subscribe(&"WeightGetRequested", _on_get)
	EventBus.subscribe(&"WeightRefreshRequested", _on_refresh)
	EventBus.subscribe(&"ItemWeightChanged", _on_item_weight_changed)
	EventBus.subscribe(&"WeightModifiersRequested", _on_modifiers)
	EventBus.subscribe(&"BudgetWeightRequested", _on_budget)
	EventBus.subscribe(&"SnapshotRestored", _on_restored)

func _on_entity_created(event: Dictionary) -> void:
	_recalculate(event.get("entity", &""), false)

func _on_entity_removed(event: Dictionary) -> void:
	_cache.erase(event.get("entity", &""))

func _on_component_changed(event: Dictionary) -> void:
	if event.get("component", &"") in [&"inventory", &"equipment"]:
		_recalculate(event.get("entity", &""), true)

func _on_stat_changed(event: Dictionary) -> void:
	if str(event.get("stat", "")) == "STR":
		_recalculate(event.get("entity", &""), true)

func _on_get(request: Dictionary) -> void:
	var entity: StringName = request.get("entity", &"")
	request["found"] = _cache.has(entity)
	if request["found"]:
		request["data"] = _cache[entity].duplicate(true)

func _on_modifiers(request: Dictionary) -> void:
	var entity: StringName = request.get("entity", &"")
	request["found"] = _cache.has(entity) and _cache[entity].get("ok", false)
	if request["found"]:
		var data: Dictionary = _cache[entity]
		# Аддитивные доли, а не готовые множители. По ТЗ не меняют сам DEX/STR.
		request["modifiers"] = {"source": &"weight", "stamina_cost_add": data["stamina_add"], "action_duration_add": data["duration_add"]}

func _on_budget(request: Dictionary) -> void:
	request["accepted"] = false
	var type_value = request.get("type", null)
	var species = request.get("species", null)
	var level = request.get("level", null)
	var tags = request.get("tags", null)
	if not _number(type_value) or not _number(species) or not _number(level) or not tags is Array:
		return
	if float(type_value) < 0.0 or float(species) < 0.0 or float(level) < 0.0:
		return
	var sum := float(type_value) + float(species)
	for tag in tags:
		if not _number(tag) or float(tag) < 0.0:
			return
		sum += float(tag)
	var core := sum * float(level)
	if not is_finite(core):
		return
	request["core"] = core
	# Вклад предметов упомянут, но формула пока не задана.
	request["complete"] = false
	request["accepted"] = true

func _recalculate(entity: StringName, notify: bool) -> void:
	if entity == &"":
		return
	var stat := {"entity": entity, "stat": &"STR", "found": false}
	EventBus.publish(&"StatGetRequested", stat)
	if not stat["found"]:
		_cache.erase(entity)
		return
	var capacity := _base + float(stat["value"]) * _per_str
	var inventory := _get_component(entity, &"inventory")
	var equipment := _get_component(entity, &"equipment")
	var weight := {"ok": true, "kg": 0.0, "error": ""}
	if inventory.get("found", false):
		var items = inventory["data"].get("items", null)
		if not items is Array:
			weight = {"ok": false, "error": "inventory.items должен быть массивом"}
		else:
			weight = _measure(items, 0)
	if weight["ok"] and equipment.get("found", false):
		var equipment_weight := _measure(equipment["data"], 0)
		if not equipment_weight["ok"]:
			weight = equipment_weight
		else:
			weight["kg"] += equipment_weight["kg"]
	var old: Dictionary = _cache.get(entity, {})
	if not weight["ok"] or not is_finite(float(weight.get("kg", 0.0))) or not is_finite(capacity) or capacity <= 0.0:
		_cache[entity] = {"ok": false, "error": weight.get("error", "") if not weight["ok"] else "Грузоподъёмность должна быть положительной и вес конечным"}
		if notify:
			EventBus.publish(&"WeightCalculationFailed", {"entity": entity, "error": _cache[entity]["error"]})
		return
	var ratio := float(weight["kg"]) / capacity
	var tier := _choose_tier(ratio)
	if tier.is_empty():
		_cache[entity] = {"ok": false, "error": "Пороги веса отсутствуют или некорректны"}
		if notify:
			EventBus.publish(&"WeightCalculationFailed", {"entity": entity, "error": _cache[entity]["error"]})
		return
	var new_data := {"ok": true, "physical_kg": float(weight["kg"]), "capacity_kg": capacity, "ratio": ratio, "tier": StringName(tier["id"]), "stamina_add": float(tier["stamina_add"]), "duration_add": float(tier["duration_add"])}
	_cache[entity] = new_data
	if notify and (not old.get("ok", false) or old.get("tier", &"") != new_data["tier"]):
		EventBus.publish(&"WeightThresholdChanged", {"entity": entity, "old": old.get("tier", null) if old.get("ok", false) else null, "new": new_data["tier"]})

func _get_component(entity: StringName, component: StringName) -> Dictionary:
	var request := {"entity": entity, "component": component, "found": false}
	EventBus.publish(&"ComponentGetRequested", request)
	return request

## Слоты могут содержать null, ID предмета, словарь предмета или вложенную
## структуру слотов. Словарь предмета определяется наличием id или weight_kg.
func _measure(value: Variant, depth: int) -> Dictionary:
	if depth > 32:
		return {"ok": false, "error": "Слишком глубокая структура предметов"}
	if value == null:
		return {"ok": true, "kg": 0.0}
	if value is String or value is StringName:
		var lookup := {"item": value, "found": false}
		EventBus.publish(&"ItemWeightRequested", lookup)
		if not lookup["found"] or not _number(lookup.get("weight_kg", null)) or float(lookup["weight_kg"]) < 0.0:
			return {"ok": false, "error": "Неизвестен вес предмета %s" % str(value)}
		return {"ok": true, "kg": float(lookup["weight_kg"])}
	if value is Dictionary:
		if value.has("weight_kg") or value.has("id"):
			var kg = value.get("weight_kg", null)
			if kg == null and value.has("id"):
				var lookup := {"item": value["id"], "found": false}
				EventBus.publish(&"ItemWeightRequested", lookup)
				if lookup["found"]:
					kg = lookup.get("weight_kg", null)
			var count = value.get("quantity", 1)
			if not _number(kg) or float(kg) < 0.0 or not count is int or count < 0:
				return {"ok": false, "error": "У предмета неверный вес или количество"}
			return {"ok": true, "kg": float(kg) * count}
		return _measure(value.values(), depth + 1)
	if value is Array:
		var total := 0.0
		for child in value:
			var part := _measure(child, depth + 1)
			if not part["ok"]:
				return part
			total += part["kg"]
		return {"ok": true, "kg": total}
	return {"ok": false, "error": "Неподдерживаемые данные предмета или слота"}

func _choose_tier(ratio: float) -> Dictionary:
	for tier in _tiers:
		if tier.get("max_ratio", null) == null or ratio <= float(tier["max_ratio"]):
			return tier
	return {}

func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

func _on_restored(_event: Dictionary) -> void:
	_cache.clear()
	var request := {"components": [&"stats"], "entities": []}
	EventBus.publish(&"EntityQueryRequested", request)
	for entity in request["entities"]:
		_recalculate(entity, false)

func _on_refresh(request: Dictionary) -> void:
	var entity: StringName = request.get("entity", &"")
	_recalculate(entity, true)
	request["found"] = _cache.has(entity)

func _on_item_weight_changed(_event: Dictionary) -> void:
	# До реализации Item Registry безопасно пересчитываем всех носителей.
	for entity in _cache.keys():
		_recalculate(entity, true)
