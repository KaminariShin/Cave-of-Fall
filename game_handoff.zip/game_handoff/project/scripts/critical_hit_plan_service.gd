extends Node
## Ручной расчёт крита по заранее снятым данным: не наносит урон.
const MAX_HITS := 10000
const MAX_VALUE := 1000000000.0
func _ready() -> void:
	EventBus.subscribe(&"CriticalHitPreviewRequested", _preview)
	EventBus.subscribe(&"CriticalHitPlanRequested", _plan)
func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v)) and absf(float(v)) <= MAX_VALUE
func _parameters(e: Dictionary) -> Dictionary:
	var per = e.get("per",null)
	var add = e.get("chance_add_percent",0.0)
	var factor = e.get("chance_factor",1.0)
	var multiplier_factor = e.get("multiplier_factor",1.0)
	if not _number(per) or not _number(add) or not _number(factor) or float(factor) < 0 or not _number(multiplier_factor) or float(multiplier_factor) < 0:
		return {"valid":false,"error":"Некорректные характеристика или модификаторы"}
	var base := 5.0 + 0.5 * float(per)
	var modified := (base + float(add)) * float(factor)
	var multiplier := maxf(1.0,2.0 * float(multiplier_factor))
	if not is_finite(modified) or not is_finite(multiplier): return {"valid":false,"error":"Результат вне диапазона"}
	return {"valid":true,"base_chance_percent":base,"chance_percent":clampf(modified,0.0,100.0),"critical_multiplier":multiplier}
func _preview(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("data"); e.erase("error")
	var p := _parameters(e)
	if not p["valid"]: e["error"] = p["error"]; return
	p.erase("valid")
	e["data"] = p
	e["accepted"] = true
func _plan(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("data"); e.erase("error")
	var p := _parameters(e)
	var hits = e.get("hits",null)
	if not p["valid"]: e["error"] = p["error"]; return
	if e.get("kind",null) not in [&"direct_physical",&"direct_magical",&"direct_mixed"] or not hits is Array or hits.size() > MAX_HITS:
		e["error"] = "Нужен тип прямой атаки и ограниченный список попаданий"; return
	var rows: Array = []
	var seen := {}
	for hit in hits:
		if not hit is Dictionary: e["error"] = "Некорректное попадание"; return
		var id = hit.get("target",null)
		var physical = hit.get("physical",null)
		var magical = hit.get("magical",null)
		if not id is StringName or id == &"" or seen.has(id) or not _number(physical) or float(physical) < 0 or not _number(magical) or float(magical) < 0:
			e["error"] = "Нужны уникальные цели и неотрицательные части урона"; return
		if (e["kind"] == &"direct_physical" and float(magical) != 0.0) or (e["kind"] == &"direct_magical" and float(physical) != 0.0):
			e["error"] = "Тип атаки не соответствует частям урона"; return
		if not is_finite(float(physical) * p["critical_multiplier"]) or not is_finite(float(magical) * p["critical_multiplier"]):
			e["error"] = "Урон вне диапазона"; return
		seen[id] = true
		rows.append({"target":id,"physical_before":float(physical),"magical_before":float(magical)})
	rows.sort_custom(func(a,b): return str(a["target"]) < str(b["target"]))
	# Все проверки закончены до первого броска. Один бросок на цель, даже
	# при 0% и 100%, общий для физической и магической части.
	for row in rows:
		var roll: float = RngService._rng.randf()
		var critical: bool = p["chance_percent"] >= 100.0 or (p["chance_percent"] > 0.0 and roll * 100.0 < p["chance_percent"])
		var m: float = p["critical_multiplier"] if critical else 1.0
		row["roll"] = roll
		row["critical"] = critical
		row["physical"] = row["physical_before"] * m
		row["magical"] = row["magical_before"] * m
	p.erase("valid")
	p["hits"] = rows
	e["data"] = p
	e["accepted"] = true
