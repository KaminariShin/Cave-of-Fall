extends Control
## Демонстрация ленивых комнат. Низкоуровневые перемещения не являются действиями.
const HERO := &"room_demo_player"
const TILE_PX := 14.0
const MAP_SIZE := Vector2i(256, 256)
var anchor := Vector2i(118, 100)
var message := "Стрелки: двигайтесь вправо к проходу."
var current := &"start"
var known_rooms: Array = []

func _ready() -> void:
	EventBus.subscribe(&"RoomDiscovered", _on_discovered)
	EventBus.subscribe(&"PlayerRoomChanged", _on_room_changed)
	var map := {"size": MAP_SIZE, "accepted": false}
	EventBus.publish(&"SpaceMapConfigureRequested", map)
	EventBus.publish(&"RngSeedRequested", {"seed": 42})
	EventBus.publish(&"RoomGenerationConfigureRequested", {"deadend_budget": 1})
	var create := {"id": &"start", "type": "start", "origin_cell": Vector2i(20, 20), "size_cells": Vector2i(11, 11), "accepted": false}
	EventBus.publish(&"RoomCreateRequested", create)
	var exit := {"room": &"start", "id": &"east", "dir": "east", "offset_cells": 5, "accepted": false}
	EventBus.publish(&"RoomExitAddRequested", exit)
	var entity := {"entity": HERO, "accepted": false}
	EventBus.publish(&"EntityCreateRequested", entity)
	# Восемь тайлов — только демонстрационная настройка, не формула PER.
	EventBus.publish(&"FogDetectionRadiusSetRequested", {"entity": HERO, "radius": 8.0})
	var control := {"entity": HERO, "accepted": false}
	EventBus.publish(&"ControlledEntityRequested", control)
	var body := {"entity": HERO, "anchor": anchor, "size": 4, "accepted": false}
	EventBus.publish(&"SpaceBodyPlaceRequested", body)
	var enter := {"entity": HERO, "room": &"start", "accepted": false}
	EventBus.publish(&"RoomEnterRequested", enter)
	if not (map["accepted"] and create["accepted"] and exit["accepted"] and entity["accepted"] and control["accepted"] and body["accepted"] and enter["accepted"]):
		message = "Ошибка инициализации тестовой комнаты."
	_refresh_rooms()
	queue_redraw()

func _on_discovered(_event: Dictionary) -> void:
	_refresh_rooms()
	queue_redraw()

func _on_room_changed(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO:
		current = event["room"]
	queue_redraw()

func _refresh_rooms() -> void:
	known_rooms.clear()
	var discovered := {"rooms": []}
	EventBus.publish(&"DiscoveredRoomsGetRequested", discovered)
	for id in discovered["rooms"]:
		var room := {"id": id, "found": false}
		EventBus.publish(&"RoomGetRequested", room)
		if room["found"]:
			known_rooms.append(room["data"])

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed:
		return
	var delta := Vector2i.ZERO
	match event.keycode:
		KEY_LEFT: delta = Vector2i.LEFT
		KEY_RIGHT: delta = Vector2i.RIGHT
		KEY_UP: delta = Vector2i.UP
		KEY_DOWN: delta = Vector2i.DOWN
		_: return
	var move := {"entity": HERO, "anchor": anchor + delta, "accepted": false}
	EventBus.publish(&"SpaceBodyMoveRequested", move)
	if move["accepted"]:
		anchor = move["anchor"]
		message = "Стрелки: исследуйте открытые комнаты."
	else:
		message = "Путь перекрыт скалой или границей."
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("101720"))
	var camera := (Vector2(anchor) + Vector2(2, 2)) * TILE_PX - size / 2.0
	var first := Vector2i(maxi(0, floori(camera.x / TILE_PX)), maxi(0, floori(camera.y / TILE_PX)))
	var last := Vector2i(mini(MAP_SIZE.x, ceili((camera.x + size.x) / TILE_PX)), mini(MAP_SIZE.y, ceili((camera.y + size.y) / TILE_PX)))
	if last.x > first.x and last.y > first.y:
		var region := {"origin": first, "size": last - first, "accepted": false}
		EventBus.publish(&"SpaceRegionGetRequested", region)
		if region["accepted"]:
			var fog := {}
			EventBus.publish(&"FogStateGetRequested", fog)
			var visible := {}
			for tile in fog.get("visible_tiles", []):
				visible[tile] = true
			for x in range(first.x, last.x):
				for y in range(first.y, last.y):
					var tile := Vector2i(x, y)
					if not visible.has(tile):
						continue
					var color := Color("344654") if region["floor"].has(tile) else Color("1a242f")
					if region["passages"].has(tile):
						color = Color("b49a4b")
					draw_rect(Rect2(Vector2(tile) * TILE_PX - camera, Vector2.ONE * (TILE_PX - 1)), color)
	# Контур открытой комнаты известен даже там, где тайлы затемнены.
	for room in known_rooms:
		var origin: Vector2i = room["origin_cell"] * 4
		var extent: Vector2i = room["size_cells"] * 4
		draw_rect(Rect2(Vector2(origin) * TILE_PX - camera, Vector2(extent) * TILE_PX), Color("66879a"), false, 2.0)
	var hero_rect := Rect2(Vector2(anchor) * TILE_PX - camera + Vector2.ONE, Vector2.ONE * (TILE_PX * 4 - 2))
	draw_rect(hero_rect, Color("5ed6c1"))
	draw_rect(Rect2(0, 0, size.x, 52), Color("101720e8"))
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(15, 22), "Комната: %s · %s" % [current, message], HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color.WHITE)
	draw_string(font, Vector2(15, 43), "Время не идёт; радиус 8 тайлов задан только для стенда.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("bbcbdc"))

func _is_discovered(tile: Vector2i) -> bool:
	for room in known_rooms:
		var origin: Vector2i = room["origin_cell"] * 4
		var extent: Vector2i = room["size_cells"] * 4
		if tile.x >= origin.x and tile.y >= origin.y and tile.x < origin.x + extent.x and tile.y < origin.y + extent.y:
			return true
	return false
