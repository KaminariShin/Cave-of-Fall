extends Control
## Стенд opt-in ИИ; параметры и обнаружение здесь только демонстрационные.
const HERO := &"ai_demo_hero"
const RAT := &"ai_demo_rat"
const TILE := 18.0
const GRID := Vector2i(24, 14)
const VIEW_ORIGIN := Vector2i(6, 6)
const ORIGIN := Vector2(20, 62)
var hero_anchor := Vector2i(10, 10)
var rat_position := Vector2(19, 10)
var telegraph: Dictionary = {}
var hero_hp := 45.0
var message := "Пробел: ждать 0.5 с. Стрелки: тестовый перенос игрока."

func _ready() -> void:
	EventBus.subscribe(&"EntityDamaged", _on_damaged)
	EventBus.subscribe(&"AIDecision", _on_decision)
	var map := {"size": Vector2i(64, 64), "accepted": false}
	EventBus.publish(&"SpaceMapConfigureRequested", map)
	var room := {"id": &"demo_room", "type": "start", "origin_cell": Vector2i(1, 1), "size_cells": Vector2i(11, 11), "accepted": false}
	EventBus.publish(&"RoomCreateRequested", room)
	EventBus.publish(&"EntityCreateRequested", {"entity": HERO})
	var hero := {"entity": HERO, "anchor": hero_anchor, "size": 4, "accepted": false}
	EventBus.publish(&"SpaceBodyPlaceRequested", hero)
	var control := {"entity": HERO, "accepted": false}
	EventBus.publish(&"ControlledEntityRequested", control)
	var enter := {"entity": HERO, "room": &"demo_room", "accepted": false}
	EventBus.publish(&"RoomEnterRequested", enter)
	var small_seed := -1
	for seed in range(100):
		EventBus.publish(&"RngSeedRequested", {"seed": seed})
		var roll := {}
		EventBus.publish(&"RngFloatRequested", roll)
		if float(roll["value"]) < 0.8:
			small_seed = seed
			break
	EventBus.publish(&"RngSeedRequested", {"seed": small_seed})
	var rat := {"entity": RAT, "anchor": Vector2i(19, 10), "accepted": false}
	EventBus.publish(&"RatSpawnRequested", rat)
	var ai := {"entity": RAT, "room": &"demo_room", "role": "rat", "target": HERO, "detected": true, "wait_duration": 0.2, "retreat_hp_ratio": 0.25, "bite": {"damage": 3.0, "duration": 0.3, "stamina_cost": 0.0}, "movement": {"actor_type": "rat", "K_move": 10.0}, "accepted": false}
	EventBus.publish(&"AIRegisterRequested", ai)
	if not map["accepted"] or not room["accepted"] or not hero["accepted"] or not control["accepted"] or not enter["accepted"] or not rat["accepted"] or not ai["accepted"]:
		message = "Ошибка инициализации стенда ИИ."

func _process(_delta: float) -> void:
	var position := {"entity": RAT, "found": false}
	EventBus.publish(&"MovementPositionGetRequested", position)
	if position["found"]: rat_position = position["position"]
	var bite := {"entity": RAT, "found": false}
	EventBus.publish(&"RatBiteTelegraphGetRequested", bite)
	telegraph.clear()
	if bite["found"]:
		for tile in bite["data"]["tiles"]: telegraph[tile] = true
	queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	var delta := Vector2i.ZERO
	match event.keycode:
		KEY_LEFT: delta = Vector2i.LEFT
		KEY_RIGHT: delta = Vector2i.RIGHT
		KEY_UP: delta = Vector2i.UP
		KEY_DOWN: delta = Vector2i.DOWN
		KEY_SPACE:
			var wait := {"entity": HERO, "action": &"wait", "duration": 0.5, "accepted": false}
			EventBus.publish(&"ActionStartRequested", wait)
			if not wait["accepted"]: message = "Ожидание уже идёт или игрок погиб."
			return
		_: return
	var move := {"entity": HERO, "anchor": hero_anchor + delta, "accepted": false}
	EventBus.publish(&"SpaceBodyMoveRequested", move)
	if move["accepted"]: hero_anchor = move["anchor"]
	else: message = "Тело игрока не помещается."

func _on_decision(event: Dictionary) -> void:
	if event.get("entity", &"") == RAT:
		message = "ИИ: " + str(event["decision"]) + ". Пробел — продвинуть время."
func _on_damaged(event: Dictionary) -> void:
	if event.get("entity", &"") == HERO:
		var hp := {"entity": HERO, "resource": &"HP", "found": false}
		EventBus.publish(&"ResourceGetRequested", hp)
		if hp["found"]: hero_hp = float(hp["data"]["current"])

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("121b26"))
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(20, 25), "ИИ крысы: подход и телеграф укуса", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_string(font, Vector2(20, 48), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("c9d4e5"))
	for y in range(GRID.y):
		for x in range(GRID.x):
			var tile := VIEW_ORIGIN + Vector2i(x, y)
			var color := Color("ac493c") if telegraph.has(tile) else Color("344654")
			draw_rect(Rect2(ORIGIN + Vector2(x, y) * TILE, Vector2.ONE * (TILE - 1)), color)
	draw_rect(Rect2(ORIGIN + (Vector2(hero_anchor - VIEW_ORIGIN)) * TILE + Vector2.ONE * 2, Vector2.ONE * (4 * TILE - 4)), Color("5ed6c1"))
	draw_rect(Rect2(ORIGIN + (rat_position - Vector2(VIEW_ORIGIN)) * TILE + Vector2.ONE * 2, Vector2.ONE * (2 * TILE - 4)), Color("e36c68"))
	for tile in telegraph:
		draw_rect(Rect2(ORIGIN + Vector2(tile - VIEW_ORIGIN) * TILE + Vector2.ONE, Vector2.ONE * (TILE - 2)), Color("ff9b77"), false, 2.0)
	draw_string(font, Vector2(475, 90), "HP игрока: %.0f" % hero_hp, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
	draw_string(font, Vector2(475, 120), "Цель задана вручную;", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(475, 138), "обнаружение ещё впереди.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(475, 170), "K_move, урон, длительности", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(475, 188), "даны только для стенда.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(475, 220), "Стрелки: мгновенный", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(475, 238), "низкоуровневый перенос.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
