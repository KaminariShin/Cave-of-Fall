extends Node
## Сохраняемая подготовка удара. На середине публикует только уведомление, без урона.
const ACTION := &"weapon_strike"
var _pending: Dictionary = {}
var _busy := false
var _launch: StringName = &""
var _permit := false
var _finish_actor: StringName = &""
var _finish_item: StringName = &""
func _ready() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION,"name":"Удар оружием","type":&"physical","base_duration":1.0,"interruptible":true,"phase_completion":true,"phase_trigger":"midpoint"}})
	EventBus.subscribe(&"WeaponStrikeStartRequested",_start)
	EventBus.subscribe(&"WeaponStrikeActionStatusRequested",_status)
	EventBus.subscribe(&"ActionStartAllowedRequested",_guard_start)
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested",_guard_ownership)
	EventBus.subscribe(&"TimeCombatPhase",_phase)
	EventBus.subscribe(&"ActionCompleted",_finished)
	EventBus.subscribe(&"ActionInterrupted",_interrupted)
	EventBus.subscribe(&"EntityDied",_removed)
	EventBus.subscribe(&"EntityRemoved",_removed)
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
	EventBus.subscribe(&"SnapshotApplyRequested",_restore)
	EventBus.subscribe(&"WeaponStrikeActionSnapshotValidateRequested",_validate)
func launch_in_progress() -> bool: return _busy
func _guard_start(e: Dictionary) -> void:
	if e.get("action",null) != ACTION: return
	if e.get("entity",null) != _launch or not _permit: e["allowed"] = false
	else: _permit = false
func _guard_ownership(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if actor is StringName and _pending.has(actor) and not CombatService.is_entity_dead(actor): e["allowed"] = false
func _start(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("error"); e.erase("data")
	var ai_tick_start: bool = TimeDriver._stepping and not TimeDriver._combat_phase and AIService.authorizes_weapon_start(e.get("entity",null)) and e.get("entity",null) != ActionRegistry._controlled_entity
	if _busy or TimeDriver._settling or (TimeDriver._stepping and not ai_tick_start):
		e["error"] = "Запуск сейчас недоступен"; return
	_busy = true
	var plan := {"entity":e.get("entity",null),"item":e.get("item",null),"strike":e.get("strike",null),"direction":e.get("direction",null)}
	EventBus.publish(&"WeaponStrikeStartPlanRequested",plan)
	if not plan.get("accepted",false):
		_busy = false; e["error"] = plan.get("error","План недоступен"); return
	var d: Dictionary = plan["data"]
	var actor: StringName = d["entity"]
	var p := {"item":d["item"],"strike":d["strike"],"direction":d["direction"],"damage_multiplier":d["damage_multiplier"],"spend":d["spend"],"duration_steps":d["duration_steps"]}
	_pending[actor] = p
	_launch = actor; _permit = true
	var request := {"entity":actor,"action":ACTION,"duration":d["duration"]}
	EventBus.publish(&"ActionStartRequested",request)
	_launch = &""; _permit = false
	# Наблюдатели низкоуровневого начала уже могли отменить действие или
	# изменить ресурс. Не оплачиваем устаревший план.
	var active := {"entity":actor,"found":false}
	var resource := {"entity":actor,"resource":&"Stamina","found":false}
	var gear := {"entity":actor,"component":&"equipment","found":false}
	EventBus.publish(&"ActionGetRequested",active)
	EventBus.publish(&"ResourceGetRequested",resource)
	EventBus.publish(&"ComponentGetRequested",gear)
	var slots = gear.get("data",null)
	var current = resource.get("data",{}).get("current",null)
	var valid: bool = request.get("accepted",false) and _pending.has(actor) and active.get("found",false) and active.get("data",{}).get("id",null) == ACTION and resource.get("found",false) and (current is int or current is float) and is_finite(float(current)) and is_equal_approx(float(current),float(d["available"])) and gear.get("found",false) and slots is Dictionary and (slots.get("main",null) == p["item"] or slots.get("off",null) == p["item"]) and not CombatService.is_entity_dead(actor)
	if not valid:
		if active.get("found",false) and active.get("data",{}).get("id",null) == ACTION: EventBus.publish(&"ActionCancelRequested", {"entity":actor,"reason":&"strike_start_failed"})
		_pending.erase(actor); _busy = false; e["error"] = "Начало удара изменилось до оплаты"; return
	var payment := {"entity":actor,"resource":&"Stamina","amount":p["spend"],"accepted":false}
	EventBus.publish(&"ResourceSpendRequested",payment)
	if not payment.get("accepted",false):
		EventBus.publish(&"ActionCancelRequested", {"entity":actor,"reason":&"strike_payment_failed"})
		_pending.erase(actor); _busy = false; e["error"] = "Не удалось оплатить удар"; return
	_busy = false
	e["accepted"] = true
	e["data"] = p.duplicate(true)
	EventBus.publish(&"WeaponStrikeStarted", {"entity":actor,"data":p.duplicate(true),"still_active":_pending.has(actor)})
func _status(e: Dictionary) -> void:
	e["active"] = false; e.erase("data")
	var actor = e.get("entity",null)
	if actor is StringName and _pending.has(actor) and not _busy:
		e["active"] = true; e["data"] = _pending[actor].duplicate(true)
func _phase(e: Dictionary) -> void:
	for row in e.get("actions",[]):
		var actor = row.get("entity",null)
		if row.get("action",null) == ACTION and _pending.has(actor):
			EventBus.publish(&"WeaponStrikeMidpoint", {"entity":actor,"data":_pending[actor].duplicate(true),"game_time":e.get("game_time",0.0)})
func _finished(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null) == ACTION and _pending.has(actor):
		var p: Dictionary = _pending[actor]; _pending.erase(actor)
		_finish_actor=actor; _finish_item=p["item"]
		EventBus.publish(&"WeaponStrikeFinished", {"entity":actor,"data":p.duplicate(true)})
		_finish_actor=&""; _finish_item=&""
func authorizes_finished(actor: StringName, item: StringName) -> bool:
	return _finish_actor == actor and _finish_item == item and actor != &"" and item != &""
func _interrupted(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null) == ACTION and _pending.has(actor):
		var p: Dictionary = _pending[actor]; _pending.erase(actor)
		EventBus.publish(&"WeaponStrikeInterrupted", {"entity":actor,"data":p,"reason":e.get("reason",&"cancelled")})
func _removed(e: Dictionary) -> void: _pending.erase(e.get("entity",null))
func _collect(e: Dictionary) -> void:
	if _busy or _finish_actor != &"": e["errors"].append("Нельзя сохранять во время начала или завершения удара"); return
	e["sections"]["weapon_strike_actions"] = _pending.duplicate(true)
func _restore(e: Dictionary) -> void:
	_pending = e["sections"]["weapon_strike_actions"].duplicate(true)
	_busy = false; _launch = &""; _permit = false; _finish_actor = &""; _finish_item = &""
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var s = e.get("sections",null)
	if not s is Dictionary or not s.get("weapon_strike_actions",null) is Dictionary or not s.get("entities",null) is Dictionary or not s.get("items",{}).get("instances",null) is Dictionary or not s.get("items",{}).get("bases",null) is Dictionary or not s.get("actions",{}).get("active",null) is Dictionary or not s.get("actions",{}).get("definitions",null) is Dictionary or not s.get("weapon_strikes",{}).get("definitions",null) is Dictionary: return
	var definition = s["actions"]["definitions"].get(ACTION,null)
	if not definition is Dictionary or definition.get("phase_completion",false) != true or definition.get("phase_trigger","") != "midpoint" or definition.get("interruptible",false) != true: return
	var pending: Dictionary = s["weapon_strike_actions"]
	var active: Dictionary = s["actions"]["active"]
	for actor in pending:
		var p = pending[actor]
		if not actor is StringName or actor == &"" or not s["entities"].has(actor) or not s["entities"][actor] is Dictionary or not p is Dictionary or p.size() != 6 or not p.get("item",null) is StringName or p["item"] == &"" or not p.get("strike",null) is String or p["strike"].is_empty() or not p.get("direction",null) is Vector2: return
		var dir: Vector2 = p["direction"]
		if not is_finite(dir.x) or not is_finite(dir.y) or absf(dir.length()-1.0) > 0.0001 or p.get("damage_multiplier",null) not in [0.25,0.5,0.75,1.0] or not (p.get("spend",null) is int or p.get("spend",null) is float) or not is_finite(float(p["spend"])) or float(p["spend"]) < 1 or not p.get("duration_steps",null) is int or p["duration_steps"] < 1: return
		var gear = s["entities"][actor].get(&"equipment",null)
		if not gear is Dictionary or (gear.get("main",null) != p["item"] and gear.get("off",null) != p["item"]) or not active.has(actor) or not active[actor] is Dictionary or active[actor].get("id",null) != ACTION or active[actor].get("steps",null) != p["duration_steps"] or s.get("combat",{}).get("dead",{}).has(actor): return
		var instances: Dictionary = s["items"]["instances"]
		var bases: Dictionary = s["items"]["bases"]
		if not instances.has(p["item"]) or not instances[p["item"]] is Dictionary or not bases.has(instances[p["item"]].get("base_id",null)): return
		var base = bases[instances[p["item"]]["base_id"]]
		var strike = s["weapon_strikes"]["definitions"].get(p["strike"],null)
		if not base is Dictionary or base.get("slot",null) != "weapon" or not strike is Dictionary or not strike.get("variants",null) is Array or not strike["variants"].has(base.get("weapon_variant",null)): return
	for actor in active:
		if active[actor] is Dictionary and active[actor].get("id",null) == ACTION and not pending.has(actor): return
	e["valid"] = true
