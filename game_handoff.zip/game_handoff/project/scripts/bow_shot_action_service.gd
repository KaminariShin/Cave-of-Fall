extends Node
## Внутреннее действие выстрела. Защита щитом и игровой ввод пока не подключены.
const ACTION := &"bow_shot"
const STRIKE := "bow_simple_shot"
const SPEED := 10.0 # временное значение, не утверждено
var _pending: Dictionary = {}
var _busy := false
var _launch: StringName = &""
var _permit := false
var _finish_actor: StringName = &""
var _finish_item: StringName = &""
func _ready() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION,"name":"Выстрел из лука","type":&"physical","base_duration":1.2,"interruptible":true,"phase_completion":true,"phase_trigger":"midpoint"}})
	EventBus.subscribe(&"BowShotStartRequested",_start)
	EventBus.subscribe(&"BowShotStatusRequested",_status)
	EventBus.subscribe(&"ActionStartAllowedRequested",_guard_start)
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested",_guard_ownership)
	EventBus.subscribe(&"TimeCombatPhase",_phase)
	EventBus.subscribe(&"ActionCompleted",_completed)
	EventBus.subscribe(&"ActionInterrupted",_ended)
	EventBus.subscribe(&"EntityDied",_removed)
	EventBus.subscribe(&"EntityRemoved",_removed)
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
	EventBus.subscribe(&"SnapshotApplyRequested",_restore)
	EventBus.subscribe(&"BowShotSnapshotValidateRequested",_validate)
func launch_in_progress() -> bool: return _busy
func _guard_start(e: Dictionary) -> void:
	if e.get("action",null) != ACTION: return
	if e.get("entity",null) != _launch or not _permit: e["allowed"] = false
	else: _permit = false
func _guard_ownership(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if actor is StringName and _pending.has(actor) and not CombatService.is_entity_dead(actor): e["allowed"] = false
func _equipped(actor: StringName, item: StringName) -> bool:
	var gear := {"entity":actor,"component":&"equipment","found":false}
	var weapon := {"item":item,"found":false}
	EventBus.publish(&"ComponentGetRequested",gear)
	EventBus.publish(&"WeaponItemResolveRequested",weapon)
	var slots = gear.get("data",null)
	return gear.get("found",false) and slots is Dictionary and slots.get("main",null) == item and slots.get("off",null) == null and weapon.get("found",false) and weapon.get("data",{}).get("type","") == "bow" and weapon.get("data",{}).get("id","") == "bow_simple_variant"
func _start(e: Dictionary) -> void:
	e["accepted"] = false; e.erase("data"); e.erase("error")
	var actor = e.get("entity",null)
	var item = e.get("item",null)
	var direction = e.get("direction",null)
	var ai_tick_start: bool = TimeDriver._stepping and not TimeDriver._combat_phase and AIService.authorizes_weapon_start(actor) and actor != ActionRegistry._controlled_entity
	if _busy or (TimeDriver._stepping and not ai_tick_start) or TimeDriver._settling or not actor is StringName or actor == &"" or not item is StringName or item == &"" or not (direction is Vector2 or direction is Vector2i): e["error"] = "Некорректный выстрел или момент запуска"; return
	var d := Vector2(direction)
	if not is_finite(d.x) or not is_finite(d.y) or not is_finite(d.length()) or d.length() < 0.000001: e["error"] = "Некорректное направление"; return
	if CombatService.is_entity_dead(actor) or not _equipped(actor,item): e["error"] = "Нужен экипированный лук"; return
	_busy = true
	var muzzle := {"entity":actor,"direction":d}
	EventBus.publish(&"BowMuzzlePreviewRequested",muzzle)
	if not muzzle.get("accepted",false): _busy=false; e["error"]=muzzle.get("error","Точка выпуска недоступна"); return
	var cost := {"entity":actor,"item":item,"strike":STRIKE}
	EventBus.publish(&"WeaponStrikeStaminaPreviewRequested",cost)
	if not cost.get("accepted",false) or not cost.get("data",{}).get("can_start",false):
		_busy=false; e["error"] = cost.get("error","Недостаточно выносливости"); return
	var c: Dictionary = cost["data"]
	var p := {"item":item,"direction":d.normalized(),"damage_multiplier":c["damage_multiplier"],"spend":c["spend"],"duration_steps":int(round(float(c["duration"])/0.01))}
	_pending[actor] = p
	_launch = actor; _permit = true
	var action := {"entity":actor,"action":ACTION,"duration":c["duration"]}
	EventBus.publish(&"ActionStartRequested",action)
	_launch = &""; _permit = false
	var active := {"entity":actor,"found":false}
	var resource := {"entity":actor,"resource":&"Stamina","found":false}
	EventBus.publish(&"ActionGetRequested",active)
	EventBus.publish(&"ResourceGetRequested",resource)
	var current = resource.get("data",{}).get("current",null)
	var valid: bool = action.get("accepted",false) and _pending.has(actor) and active.get("found",false) and active.get("data",{}).get("id",null)==ACTION and resource.get("found",false) and (current is int or current is float) and is_finite(float(current)) and is_equal_approx(float(current),float(c["available"])) and _equipped(actor,item) and not CombatService.is_entity_dead(actor)
	if not valid:
		if active.get("found",false) and active.get("data",{}).get("id",null)==ACTION: EventBus.publish(&"ActionCancelRequested",{"entity":actor,"reason":&"bow_start_failed"})
		_pending.erase(actor); _busy=false; e["error"]="Начало выстрела изменилось до оплаты"; return
	var payment := {"entity":actor,"resource":&"Stamina","amount":p["spend"]}
	EventBus.publish(&"ResourceSpendRequested",payment)
	if not payment.get("accepted",false):
		EventBus.publish(&"ActionCancelRequested",{"entity":actor,"reason":&"bow_payment_failed"})
		_pending.erase(actor); _busy=false; e["error"]="Не удалось оплатить выстрел"; return
	_busy=false; e["accepted"]=true; e["data"]=p.duplicate(true)
	EventBus.publish(&"BowShotStarted",{"entity":actor,"data":p.duplicate(true),"still_active":_pending.has(actor)})
func _status(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	e["active"] = actor is StringName and _pending.has(actor) and not _busy
	e.erase("data")
	if e["active"]: e["data"] = _pending[actor].duplicate(true)
func _phase(e: Dictionary) -> void:
	for row in e.get("actions",[]):
		var actor = row.get("entity",null)
		if row.get("action",null)!=ACTION or not _pending.has(actor): continue
		var p: Dictionary = _pending[actor]
		if CombatService.is_entity_dead(actor) or not _equipped(actor,p["item"]): continue
		var damage := {"entity":actor,"item":p["item"],"strike":STRIKE}
		EventBus.publish(&"BowShotDamagePreviewRequested",damage)
		if not damage.get("accepted",false) or not damage.get("data",{}).get("in_hand",false):
			EventBus.publish(&"BowShotReleased",{"entity":actor,"accepted":false,"error":damage.get("error","Урон лука недоступен")})
			continue
		var shot := {"entity":actor,"weapon_type":"bow","direction":p["direction"],"speed":SPEED,"damage":float(damage["data"]["nonnegative_damage"])*float(p["damage_multiplier"])}
		EventBus.publish(&"ProjectileLaunchRequested",shot)
		EventBus.publish(&"BowShotReleased",{"entity":actor,"accepted":shot.get("accepted",false),"id":shot.get("id",null),"error":shot.get("error","")})
func _completed(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null)!=ACTION or not _pending.has(actor): return
	var p: Dictionary = _pending[actor]; _pending.erase(actor)
	_finish_actor=actor; _finish_item=p["item"]
	EventBus.publish(&"BowShotFinished",{"entity":actor,"data":p.duplicate(true)})
	_finish_actor=&""; _finish_item=&""
func authorizes_finished(actor: StringName, item: StringName) -> bool:
	return actor != &"" and item != &"" and actor == _finish_actor and item == _finish_item
func _ended(e: Dictionary) -> void:
	if e.get("action",null)==ACTION: _pending.erase(e.get("entity",null))
func _removed(e: Dictionary) -> void: _pending.erase(e.get("entity",null))
func _collect(e: Dictionary) -> void:
	if _busy or _finish_actor != &"": e["errors"].append("Нельзя сохранять во время начала или завершения выстрела"); return
	e["sections"]["bow_shot_actions"] = _pending.duplicate(true)
func _restore(e: Dictionary) -> void:
	_pending=e["sections"].get("bow_shot_actions",{}).duplicate(true)
	_busy=false; _launch=&""; _permit=false; _finish_actor=&""; _finish_item=&""
	if ActionRegistry.get_definition(ACTION).is_empty():
		EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION,"name":"Выстрел из лука","type":&"physical","base_duration":1.2,"interruptible":true,"phase_completion":true,"phase_trigger":"midpoint"}})
func _validate(e: Dictionary) -> void:
	e["valid"]=false
	var s=e.get("sections",null)
	if not s is Dictionary or not s.get("actions",{}).get("active",null) is Dictionary or not s.get("entities",null) is Dictionary or not s.get("items",{}).get("instances",null) is Dictionary: return
	var pending=s.get("bow_shot_actions",{})
	var active:Dictionary=s["actions"]["active"]
	if not pending is Dictionary:return
	if not pending.is_empty():
		var def=s["actions"].get("definitions",{}).get(ACTION,null)
		if not def is Dictionary or def.get("phase_completion",false)!=true or def.get("phase_trigger","")!="midpoint" or def.get("interruptible",false)!=true:return
	for actor in pending:
		var p=pending[actor]
		if not actor is StringName or actor==&"" or not p is Dictionary or p.size()!=5 or not p.get("item",null) is StringName or not p.get("direction",null) is Vector2 or p.get("damage_multiplier",null) not in [0.25,0.5,0.75,1.0] or not (p.get("spend",null) is int or p.get("spend",null) is float) or not is_finite(float(p["spend"])) or float(p["spend"])<1 or not p.get("duration_steps",null) is int or p["duration_steps"]<1:return
		var dir:Vector2=p["direction"]
		if not is_finite(dir.x) or not is_finite(dir.y) or absf(dir.length()-1.0)>0.0001:return
		var entity=s["entities"].get(actor,null)
		if not entity is Dictionary:return
		var gear=entity.get(&"equipment",null)
		var item=s["items"]["instances"].get(p["item"],null)
		if not gear is Dictionary or gear.get("main",null)!=p["item"] or gear.get("off",null)!=null or not item is Dictionary or item.get("base_id",null)!=&"bow_simple":return
		if not active.get(actor,null) is Dictionary or active[actor].get("id",null)!=ACTION or active[actor].get("steps",null)!=p["duration_steps"] or s.get("combat",{}).get("dead",{}).has(actor):return
	for actor in active:
		if active[actor] is Dictionary and active[actor].get("id",null)==ACTION and not pending.has(actor):return
	e["valid"]=true
