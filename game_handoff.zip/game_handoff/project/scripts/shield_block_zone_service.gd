extends Node
## Запрос геометрии: не проводит блок и не списывает выносливость.
const MAX_ATTACK_TILES := 300000
func _ready() -> void:
	EventBus.subscribe(&"ShieldBlockZoneRequested", _zone)
	EventBus.subscribe(&"ShieldBlockPreviewRequested", _preview)
func _zone(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["error","data"]: e.erase(key)
	var actor = e.get("entity",null)
	var direction = e.get("direction",null)
	if not actor is StringName or actor == &"":
		e["error"] = "Нужен персонаж"; return
	if e.has("attack_tiles"):
		var incoming = e["attack_tiles"]
		if not incoming is Array or incoming.size() > MAX_ATTACK_TILES: e["error"] = "Некорректный список тайлов атаки"; return
		for t in incoming:
			if not t is Vector2i: e["error"] = "Некорректный тайл атаки"; return
	var block := {"entity":actor,"active":false}
	var body := {"entity":actor,"found":false}
	EventBus.publish(&"ShieldBlockStatusRequested",block)
	EventBus.publish(&"SpaceBodyGetRequested",body)
	if not block.get("active",false) or not body.get("found",false) or not body.get("data",null) is Dictionary:
		e["error"] = "Нет активного блока или тела"; return
	if direction == null: direction = block.get("direction",null)
	if not valid_direction(direction) or direction != block.get("direction",null):
		e["error"] = "Направление не совпадает с начатым блоком"; return
	var result := _geometry(actor,block.get("item",null),block.get("slot",null),direction,body["data"],block.get("ending",false))
	if not result.get("accepted",false):
		e["error"] = result.get("error","Щит недоступен"); return
	var data: Dictionary = result["data"]
	var tiles: Array = data["tiles"]
	if e.has("attack_tiles"):
		var intersection: Array = []
		for tile in tiles:
			if e["attack_tiles"].has(tile): intersection.append(tile)
		data["intersection"] = intersection
		data["intersects"] = not intersection.is_empty()
	e["data"] = data
	e["accepted"] = true

# Предпросмотр не запускает блок и не расходует время или ресурсы.
func _preview(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["data","error"]: e.erase(key)
	var actor = e.get("entity",null)
	var slot = e.get("slot",null)
	var direction = e.get("direction",null)
	if not actor is StringName or actor == &"" or slot not in ["main","off"] or not valid_direction(direction):
		e["error"] = "Нужны персонаж, рука щита и направление"; return
	var gear := {"entity":actor,"component":&"equipment","found":false}
	var body := {"entity":actor,"found":false}
	EventBus.publish(&"ComponentGetRequested",gear)
	EventBus.publish(&"SpaceBodyGetRequested",body)
	if not gear.get("found",false) or not gear.get("data",null) is Dictionary or not body.get("found",false) or not body.get("data",null) is Dictionary:
		e["error"] = "Нет тела или экипировки"; return
	var result := _geometry(actor,gear["data"].get(slot,null),slot,direction,body["data"],false)
	e.merge(result,true)

func _geometry(_actor: StringName, item_id: Variant, slot: Variant, direction: Variant, body: Dictionary, ending: bool) -> Dictionary:
	var item := {"item":item_id,"found":false}
	EventBus.publish(&"ItemGetRequested",item)
	if not item.get("found",false) or not item.get("base",null) is Dictionary or item["base"].get("slot",null) != "shield": return {"accepted":false,"error":"Щит недоступен"}
	var width = item["base"].get("shield_block_width",null)
	var anchor = body.get("anchor",null)
	var size = body.get("size",null)
	if not (width is int or width is float) or not is_finite(float(width)) or floorf(float(width)) != float(width) or int(width) not in [1,2,4] or not anchor is Vector2i or not size is int or size < int(width) or slot not in ["main","off"]:
		return {"accepted":false,"error":"Ширина щита или тело не поддерживаются"}
	var tiles := _tiles(anchor,size,int(width),slot,direction)
	return {"accepted":true,"data":{"item":item_id,"slot":slot,"direction":direction,"body_anchor":anchor,"body_size":size,"width":int(width),"tiles":tiles,"ending":ending}}

# Непосредственная сверка результата проверочного события с реальными данными;
# события здесь не публикуются, чтобы между последней проверкой и commit не
# мог появиться новый побочный эффект подписчика.
func matches_committed_geometry(zone: Dictionary) -> bool:
	var id = zone.get("item",null)
	var slot = zone.get("slot",null)
	var direction = zone.get("direction",null)
	var anchor = zone.get("anchor",null)
	var size = zone.get("size",null)
	var width = zone.get("width",null)
	if not id is StringName or not ItemService._instances.has(id) or slot not in ["main","off"] or not valid_direction(direction) or not anchor is Vector2i or not size is int or not width is int or width not in [1,2,4] or size < width: return false
	var instance = ItemService._instances[id]
	if not instance is Dictionary or not ItemService._bases.has(instance.get("base_id",null)): return false
	var base = ItemService._bases[instance["base_id"]]
	if not base is Dictionary or base.get("slot",null) != "shield" or base.get("shield_block_width",null) != width: return false
	return zone.get("tiles",null) == _tiles(anchor,size,width,slot,direction)

# Старые сохранения и клавиатура используют Vector2i по четырём сторонам;
# мышь передаёт нормализованный Vector2 без привязки к фиксированным углам.
func valid_direction(direction: Variant) -> bool:
	if direction is Vector2i: return direction in [Vector2i.UP,Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT]
	if not direction is Vector2 or not is_finite(direction.x) or not is_finite(direction.y): return false
	return absf(direction.length_squared()-1.0) < 0.0001

# Клетки с внешней стороны тела, упорядоченные по периметру. Угол
# курсора определяет ближайшую клетку; у широкого щита соседние клетки
# идут по непрерывному периметру, в том числе через углы.
func _tiles(anchor: Vector2i, size: int, width: int, slot: String, direction: Variant) -> Array:
	var d := Vector2(direction)
	if absf(d.x) < 0.000001 or absf(d.y) < 0.000001:
		var cardinal := Vector2i(signi(int(round(d.x))),signi(int(round(d.y))))
		var right := Vector2i(-cardinal.y,cardinal.x)
		var hand := right if slot == "main" else -right
		var start := anchor
		if cardinal.x > 0: start.x += size
		elif cardinal.x < 0: start.x -= 1
		if cardinal.y > 0: start.y += size
		elif cardinal.y < 0: start.y -= 1
		if hand.x > 0: start.x += size - 1
		if hand.y > 0: start.y += size - 1
		if width == 1 and size > 1: start -= hand
		var result: Array = []
		for i in range(width): result.append(start - hand*i)
		return result
	var perimeter: Array[Vector2i] = []
	for x in range(size): perimeter.append(anchor+Vector2i(x,-1))
	for y in range(size): perimeter.append(anchor+Vector2i(size,y))
	for x in range(size-1,-1,-1): perimeter.append(anchor+Vector2i(x,size))
	for y in range(size-1,-1,-1): perimeter.append(anchor+Vector2i(-1,y))
	var center := Vector2(anchor)+Vector2.ONE*float(size)*0.5
	var best := 0
	var best_score := -INF
	for i in range(perimeter.size()):
		var v := (Vector2(perimeter[i])+Vector2.ONE*0.5-center).normalized()
		var score := d.dot(v)
		if score > best_score + 0.0000001:
			best_score = score
			best = i
	var start_index := best - (width / 2 if slot == "main" else (width-1) / 2)
	var tiles: Array = []
	for i in range(width): tiles.append(perimeter[posmod(start_index+i,perimeter.size())])
	return tiles
