extends Node
## Мёртвое тело перестаёт занимать тайлы, чтобы вещи можно было подобрать.
## Отдельно от необязательного LootService; изображение трупа пока не задано.
func _ready() -> void:
	EventBus.subscribe(&"EntityDied", _died)
func _died(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var remove := {"entity": entity, "accepted": false}
	EventBus.publish(&"SpaceBodyRemoveRequested", remove)
	if remove["accepted"]:
		EventBus.publish(&"CorpseBodyReleased", {"entity": entity})
