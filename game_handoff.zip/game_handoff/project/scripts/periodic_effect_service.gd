extends Node
## Периодический урон с отдельным остатком и таймером на цель и ID эффекта.
## Защиту поставляет PeriodicProtectionGetRequested; если поставщика нет — 0%.
const TICK_STEPS := 50
var _effects: Dictionary = {}
var _busy := false

func _ready() -> void:
	EventBus.subscribe(&"PeriodicEffectApplyRequested", _apply_effect)
	EventBus.subscribe(&"PeriodicEffectRemoveRequested", _remove_effect)
	EventBus.subscribe(&"PeriodicEffectGetRequested", _get_effect)
	EventBus.subscribe(&"TimeProcessesTick", _tick)
	EventBus.subscribe(&"EntityDied", _on_entity_gone)
	EventBus.subscribe(&"EntityRemoved", _on_entity_gone)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply_snapshot)
	EventBus.subscribe(&"PeriodicSnapshotValidateRequested", _validate_snapshot)

func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v))

func _apply_effect(e: Dictionary) -> void:
	e["accepted"] = false
	var entity = e.get("entity", null)
	var effect = e.get("effect", null)
	var source = e.get("source", null)
	var kind = e.get("damage_type", null)
	var damage = e.get("damage_per_tick", null)
	var base = e.get("base_duration", null)
	if not entity is StringName or entity == &"" or not effect is StringName or effect == &"" or (source != null and not (source is StringName or source is String)) or kind not in ["physical", "magical"] or not _number(damage) or float(damage) < 0.0 or not _number(base) or float(base) <= 0.0:
		e["error"] = "Некорректные параметры эффекта"
		return
	var hp := {"entity":entity, "resource":&"HP", "found":false}
	EventBus.publish(&"ResourceGetRequested", hp)
	if not hp["found"] or float(hp["data"]["current"]) <= 0.0: return
	# CON сокращает только физические дебаффы; для магического берём
	# нейтральное значение 5, сохраняя общую кратность тикам.
	var con_value := 5.0
	if kind == "physical":
		var stat := {"entity":entity, "stat":&"CON", "found":false}
		EventBus.publish(&"StatGetRequested", stat)
		if not stat["found"]: return
		con_value = float(stat["value"])
	var duration := {"base_duration":base, "CON":con_value, "accepted":false}
	EventBus.publish(&"PeriodicDurationCalculateRequested", duration)
	if not duration["accepted"]:
		e["error"] = duration.get("error", "Ошибка длительности")
		return
	var steps := roundi(float(duration["duration"]) * 100.0)
	if not _effects.has(entity): _effects[entity] = {}
	var effects: Dictionary = _effects[entity]
	if effects.has(effect):
		var current: Dictionary = effects[effect]
		if current["damage_type"] != kind:
			e["error"] = "Тип урона существующего эффекта не совпадает"
			return
		current["remaining_steps"] = steps
		if float(damage) > float(current["damage_per_tick"]):
			current["damage_per_tick"] = float(damage)
			current["source"] = StringName(str(source)) if source != null else null
	else:
		effects[effect] = {"damage_type":kind, "damage_per_tick":float(damage), "source":StringName(str(source)) if source != null else null, "remaining_steps":steps, "next_tick_steps":TICK_STEPS, "remainder":0.0}
	e["duration"] = duration["duration"]
	e["accepted"] = true
	EventBus.publish(&"PeriodicEffectApplied", {"entity":entity, "effect":effect, "duration":duration["duration"]})

func _remove_effect(e: Dictionary) -> void:
	e["accepted"] = false
	var entity = e.get("entity", null)
	var id = e.get("effect", null)
	if not _effects.has(entity) or not _effects[entity].has(id): return
	_effects[entity].erase(id)
	if _effects[entity].is_empty(): _effects.erase(entity)
	e["accepted"] = true
	EventBus.publish(&"PeriodicEffectRemoved", {"entity":entity, "effect":id})

func _get_effect(e: Dictionary) -> void:
	var entity = e.get("entity", null)
	var id = e.get("effect", null)
	e["found"] = _effects.has(entity) and _effects[entity].has(id)
	if e["found"]: e["data"] = _effects[entity][id].duplicate(true)

func _tick(_event: Dictionary) -> void:
	_busy = true
	var entities := _effects.keys()
	entities.sort_custom(func(a, b): return str(a) < str(b))
	for entity in entities:
		if not _effects.has(entity): continue
		var ids: Array = _effects[entity].keys()
		ids.sort_custom(func(a, b): return str(a) < str(b))
		for id in ids:
			if not _effects.has(entity) or not _effects[entity].has(id): continue
			var effect: Dictionary = _effects[entity][id]
			effect["remaining_steps"] -= 1
			effect["next_tick_steps"] -= 1
			if effect["next_tick_steps"] <= 0:
				effect["next_tick_steps"] = TICK_STEPS
				var protection := {"entity":entity, "damage_type":effect["damage_type"], "percent":0.0}
				if effect["damage_type"] == "magical":
					var magic := {"entity":entity,"found":false}
					EventBus.publish(&"MagicalProtectionGetRequested",magic)
					protection["percent"] = magic.get("percent",null) if magic.get("found",false) else null
				EventBus.publish(&"PeriodicProtectionGetRequested", protection)
				if not _number(protection.get("percent", null)):
					EventBus.publish(&"PeriodicEffectFailed", {"entity":entity, "effect":id, "error":"Некорректная защита"})
				else:
					var percent := minf(75.0, float(protection["percent"]))
					var accumulation: float = float(effect["remainder"]) + float(effect["damage_per_tick"]) * (1.0 - percent / 100.0)
					if not is_finite(accumulation) or accumulation > 1000000000.0:
						EventBus.publish(&"PeriodicEffectFailed", {"entity":entity, "effect":id, "error":"Переполнение урона"})
					else:
						var whole := floori(accumulation + 0.0000000001)
						effect["remainder"] = maxf(0.0, accumulation - whole)
						if whole > 0:
							var request := {"entity":entity, "source":effect["source"], "amount":whole, "source_outgoing_precomputed":true, "resolved_periodic_damage":true, "accepted":false}
							EventBus.publish(&"CombatDamageRequested", request)
							if not request["accepted"]: EventBus.publish(&"PeriodicEffectFailed", {"entity":entity, "effect":id, "error":"Урон не применён"})
						EventBus.publish(&"PeriodicEffectTicked", {"entity":entity, "effect":id, "damage":whole, "source":effect["source"]})
			if _effects.has(entity) and _effects[entity].has(id) and effect["remaining_steps"] <= 0:
				_remove_effect({"entity":entity, "effect":id})
	_busy = false

func _on_entity_gone(e: Dictionary) -> void:
	_effects.erase(e.get("entity", &""))

func _collect(e: Dictionary) -> void:
	if _busy:
		e["errors"].append("Нельзя сохранять во время обработки периодических эффектов")
		return
	e["sections"]["periodic_effects"] = _effects.duplicate(true)

func _apply_snapshot(e: Dictionary) -> void:
	_effects = e["sections"]["periodic_effects"].duplicate(true)

func _validate_snapshot(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary or not sections.get("periodic_effects", null) is Dictionary or not sections.get("entities", null) is Dictionary: return
	for entity in sections["periodic_effects"]:
		if not entity is StringName or not sections["entities"].has(entity): return
		var effects = sections["periodic_effects"][entity]
		if not effects is Dictionary or effects.is_empty(): return
		for id in effects:
			if not id is StringName or id == &"": return
			var d = effects[id]
			if not d is Dictionary or d.get("damage_type", null) not in ["physical", "magical"] or not _number(d.get("damage_per_tick", null)) or float(d["damage_per_tick"]) < 0.0: return
			if d.get("source", null) != null and not d["source"] is StringName: return
			if not d.get("remaining_steps", null) is int or d["remaining_steps"] < 1 or d["remaining_steps"] > 1000000000: return
			if not d.get("next_tick_steps", null) is int or d["next_tick_steps"] < 1 or d["next_tick_steps"] > TICK_STEPS: return
			if not _number(d.get("remainder", null)) or float(d["remainder"]) < 0.0 or float(d["remainder"]) >= 1.0: return
	e["valid"] = true
