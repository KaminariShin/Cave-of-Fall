extends Node
## Управляемый данными каркас ИИ; обнаружение, расходники и оружие появятся позже.
var _agents: Dictionary = {}
var _weapon_launch: StringName = &""
var _summons: Dictionary = {} # summoner -> [живые вызванные id]
var _tracked: Dictionary = {} # вызванные сущности -> комната, даже без ИИ
var _pending: Dictionary = {} # summoner -> данные текущего призыва
var _summon_completing := false
var _transition_cancel_busy := false
var _transition_cancel_targets: Dictionary = {}
var _room: StringName = &""
var _controlled: StringName = &""
var _sequence := 0
var _rules: Dictionary = {}
var _tile_scale := 4

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var params: Dictionary = rules["ruleset"].get("parameters", {})
		_rules = params.get("ai", {}).duplicate(true)
		_tile_scale = int(params.get("space", {}).get("tiles_per_cell", 4))
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data": {"id": &"ai_summon", "name": "Призыв крысы", "type": &"magical", "base_duration": 2.0, "interruptible": true}})
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data": {"id": &"ai_staff_attack", "name": "Удар посохом", "type": &"physical", "base_duration": 0.01, "interruptible": true}})
	EventBus.subscribe(&"AIRegisterRequested", _register)
	EventBus.subscribe(&"AIUnregisterRequested", _unregister)
	EventBus.subscribe(&"AIGetRequested", _get_agent)
	EventBus.subscribe(&"AITargetSetRequested", _set_target)
	EventBus.subscribe(&"AIWeaponTelegraphGetRequested", _get_weapon_telegraph)
	EventBus.subscribe(&"AIActionEffectScheduledRequested", _effect_scheduled)
	EventBus.subscribe(&"AIEntityTickAllowedRequested", _tick_allowed)
	EventBus.subscribe(&"ControlledEntityRequested", _controlled_changed)
	EventBus.subscribe(&"PlayerRoomChanged", _room_changed)
	EventBus.subscribe(&"EntityDamaged", _damaged)
	EventBus.subscribe(&"EntityMoved", _entity_moved)
	EventBus.subscribe(&"SpaceBodyRemoved", _body_removed)
	EventBus.subscribe(&"EntityDied", _entity_died)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"ActionCompleted", _action_completed)
	EventBus.subscribe(&"ActionInterrupted", _action_interrupted)
	EventBus.subscribe(&"Tick", _tick)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"SnapshotRestored", _snapshot_restored)
	EventBus.subscribe(&"SpawnMapReconfigureCheckRequested", _summons_map_check)
	EventBus.subscribe(&"ActionStartAllowedRequested", _transition_action_guard)

func _register(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var room: StringName = event.get("room", &"")
	var target: StringName = event.get("target", &"")
	var role := str(event.get("role", "rat"))
	var wait = event.get("wait_duration", _rules.get("wait_duration", null))
	var threshold = event.get("retreat_hp_ratio", _rules.get("retreat_hp_ratio", null))
	var attack = event.get("bite", null)
	var staff = event.get("staff_attack", null)
	var detected = event.get("detected", false)
	if entity == &"" or entity == _controlled or _agents.has(entity) or room == &"" or role not in ["rat", "summoner", "melee"] or not _valid_duration(wait) or not detected is bool:
		return _fail(event, "Нужны сущность, комната, тип и длительность ожидания")
	if threshold != null and (not _number(threshold) or float(threshold) < 0.0 or float(threshold) > 1.0):
		return _fail(event, "Некорректный порог отступления")
	if detected and (target == &"" or not _entity_exists(target)):
		return _fail(event, "Обнаруженная цель не существует")
	if not _entity_exists(entity):
		return _fail(event, "Сущность не найдена")
	if role == "rat":
		var species := {"entity": entity, "component": &"species", "found": false}
		EventBus.publish(&"ComponentGetRequested", species)
		if not species["found"] or species["data"].get("id", "") != "rat":
			return _fail(event, "Для role=rat нужна крыса")
		if not attack is Dictionary or not _number(attack.get("damage", null)) or float(attack["damage"]) < 0 or not _valid_duration(attack.get("duration", null)):
			return _fail(event, "Нужно явно задать укус")
		if not _number(attack.get("stamina_cost", null)) or float(attack["stamina_cost"]) < 0.0:
			return _fail(event, "Нужно явно задать стоимость укуса")
	if role == "melee":
		var weapon = event.get("weapon",null)
		if not weapon is Dictionary or not weapon.get("item",null) is StringName or weapon["item"] == &"" or not (weapon.get("strike",null) is String or weapon.get("strike",null) is StringName) or str(weapon["strike"]).is_empty():
			return _fail(event, "Нужны ID оружия и удара")
		var gear := {"entity":entity,"component":&"equipment","found":false}
		EventBus.publish(&"ComponentGetRequested",gear)
		if not gear.get("found",false) or not gear.get("data",null) is Dictionary or (gear["data"].get("main",null) != weapon["item"] and gear["data"].get("off",null) != weapon["item"]): return _fail(event, "Оружие должно быть надето")
		var strikes := {"item":weapon["item"],"found":false}
		EventBus.publish(&"WeaponStrikesGetRequested",strikes)
		if not strikes.get("found",false) or not strikes.get("strikes",[]) is Array: return _fail(event, "Оружие недоступно")
		var available := false
		for strike in strikes["strikes"]:
			if str(strike.get("id","")) == str(weapon["strike"]): available = true
		if not available: return _fail(event, "Удар недоступен оружию")
	if role == "summoner" and staff != null:
		if not staff is Dictionary or not _number(staff.get("damage", null)) or float(staff["damage"]) < 0.0 or not _valid_duration(staff.get("duration", null)) or not _number(staff.get("stamina_cost", null)) or float(staff["stamina_cost"]) < 0.0 or not _number(staff.get("range", null)) or float(staff["range"]) < 0.0 or not _number(staff.get("gap", null)) or float(staff["gap"]) < 0.0 or not staff.get("shape", null) is Dictionary:
			return _fail(event, "Для посоха нужны явные форма, дальность, урон, длительность и стоимость Stamina")
	var room_query := {"id": room, "found": false}
	EventBus.publish(&"RoomGetRequested", room_query)
	var body := _body(entity)
	if not room_query["found"] or body.is_empty():
		return _fail(event, "Нет комнаты или тела")
	var bounds := _room_bounds(room_query["data"])
	var fit := {"anchor": body["anchor"], "size": body["size"], "room": bounds, "ignore_entity": entity}
	EventBus.publish(&"SpaceBodyFitsRequested", fit)
	if not fit.get("fits", false):
		return _fail(event, "Тело не находится внутри комнаты")
	var movement = event.get("movement", null)
	if movement != null:
		if not movement is Dictionary:
			return _fail(event, "Неверная настройка движения")
		var configure: Dictionary = movement.duplicate(true)
		configure["entity"] = entity
		EventBus.publish(&"MovementConfigureRequested", configure)
		if not configure.get("accepted", false):
			return _fail(event, "Не удалось настроить перемещение")
	var set_room := {"entity": entity, "room": bounds, "accepted": false}
	EventBus.publish(&"SpaceBodyRoomSetRequested", set_room)
	if not set_room["accepted"]:
		return _fail(event, "Не удалось ограничить тело комнатой")
	_agents[entity] = {"room": room, "target": target, "role": role, "detected": detected, "wait_duration": float(wait), "retreat_hp_ratio": threshold, "bite": attack.duplicate(true) if attack is Dictionary else {}, "staff_attack": staff.duplicate(true) if staff is Dictionary else {}, "dirty": true, "reactive": false}
	if role == "melee": _agents[entity]["weapon"] = event["weapon"].duplicate(true)
	if not _summons.has(entity):
		_summons[entity] = []
	event["accepted"] = true
	EventBus.publish(&"AIRegistered", {"entity": entity, "room": room, "role": role})

func _unregister(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	event["accepted"] = _agents.has(entity)
	if event["accepted"]:
		# Не оставляем при удалении ИИ начатый им призыв.
		if _pending.has(entity):
			EventBus.publish(&"ActionCancelRequested", {"entity": entity, "reason": &"ai_unregistered"})
		_agents.erase(entity)

func _get_agent(event: Dictionary) -> void:
	var id: StringName = event.get("entity", &"")
	event["found"] = _agents.has(id)
	if event["found"]:
		event["data"] = _agents[id].duplicate(true)
		event["active_room"] = _active(id)
		event["summons"] = _summons.get(id, []).duplicate()

func _set_target(event: Dictionary) -> void:
	event["accepted"] = false
	var entity: StringName = event.get("entity", &"")
	var target: StringName = event.get("target", &"")
	var detected = event.get("detected", null)
	if not _agents.has(entity) or not detected is bool or (detected and (target == &"" or not _entity_exists(target))):
		return
	_agents[entity]["target"] = target
	_agents[entity]["detected"] = detected
	_agents[entity]["dirty"] = true
	_agents[entity]["reactive"] = true
	event["accepted"] = true

func _tick_allowed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if _agents.has(entity):
		event["allowed"] = _active(entity)
	elif _tracked.has(entity):
		event["allowed"] = entity == _controlled or (_room != &"" and _tracked[entity] == _room)
func _active(entity: StringName) -> bool:
	return _agents.has(entity) and entity != _controlled and _room != &"" and _agents[entity]["room"] == _room
func _controlled_changed(event: Dictionary) -> void:
	if event.get("accepted", false):
		_controlled = event.get("entity", &"")
		_room = &""
func _room_changed(event: Dictionary) -> void:
	_room = event.get("room", &"")
	for entity in _agents:
		if _active(entity):
			_agents[entity]["dirty"] = true
			_agents[entity]["reactive"] = true
			var body := _body(entity)
			if not body.is_empty():
				var fit := {"anchor": body["anchor"], "size": body["size"], "room": body["room"], "ignore_entity": entity}
				EventBus.publish(&"SpaceBodyFitsRequested", fit)
				EventBus.publish(&"AIPlacementRechecked", {"entity": entity, "room": _room, "valid": fit.get("fits", false)})

func _effect_scheduled(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	var action: StringName = event.get("action", &"")
	event["scheduled"] = false
	if not _pending.has(entity):
		return
	var pending: Dictionary = _pending[entity]
	if action == &"ai_summon" and pending.get("kind", "") == "summon":
		event["scheduled"] = true
	elif action == &"ai_staff_attack" and pending.get("kind", "") == "staff" and pending.get("announced", false):
		event["scheduled"] = true

func _get_weapon_telegraph(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	event["found"] = _pending.has(entity) and _pending[entity].get("kind", "") == "staff" and _pending[entity].get("announced", false)
	if event["found"]:
		event["data"] = _pending[entity].duplicate(true)

func _entity_moved(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if _pending.has(entity) and _pending[entity].get("kind", "") == "staff" and event.get("to", null) != _pending[entity]["anchor"]:
		EventBus.publish(&"ActionCancelRequested", {"entity": entity, "reason": &"attacker_moved"})

func _body_removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	for actor in _pending.keys():
		if actor == entity or (_pending[actor].get("kind", "") == "staff" and _pending[actor].get("target", &"") == entity):
			EventBus.publish(&"ActionCancelRequested", {"entity": actor, "reason": &"body_removed"})

func _damaged(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if _agents.has(entity):
		_agents[entity]["dirty"] = true
		_agents[entity]["reactive"] = true
func _entity_died(event: Dictionary) -> void:
	var id: StringName = event.get("entity", &"")
	_remove_summoned(id)
	for actor in _agents:
		if _agents[actor]["target"] == id:
			_agents[actor]["detected"] = false
			_agents[actor]["dirty"] = true
			_agents[actor]["reactive"] = true
	if _agents.has(id):
		_agents[id]["dirty"] = false
func _entity_removed(event: Dictionary) -> void:
	var id: StringName = event.get("entity", &"")
	_remove_summoned(id)
	_summons.erase(id)
	_tracked.erase(id)
	_agents.erase(id)
	_pending.erase(id)
	# Список вызванных детей остаётся жить независимо от владельца.
	for actor in _agents:
		if _agents[actor]["target"] == id:
			_agents[actor]["detected"] = false
			_agents[actor]["dirty"] = true
			_agents[actor]["reactive"] = true
func _remove_summoned(id: StringName) -> void:
	for parent in _summons:
		_summons[parent].erase(id)

func _action_completed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if event.get("action", &"") == &"ai_summon" and _pending.has(entity):
		_complete_summon(entity)
	elif event.get("action", &"") == &"ai_staff_attack" and _pending.has(entity):
		_complete_staff(entity)
	if _agents.has(entity):
		_agents[entity]["dirty"] = true
func _action_interrupted(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if event.get("action", &"") in [&"ai_summon", &"ai_staff_attack"] and _pending.has(entity):
		var old: Dictionary = _pending[entity]
		_pending.erase(entity)
		if old.get("kind", "") == "staff" and old.get("announced", false):
			EventBus.publish(&"AIWeaponTelegraphEnded", {"entity": entity, "target": old["target"], "reason": event.get("reason", &"interrupted")})
	if _agents.has(entity):
		_agents[entity]["dirty"] = true

func _tick(_event: Dictionary) -> void:
	for entity in _agents.keys():
		if not _active(entity): continue
		# Реакция на угрозу отслеживается даже когда решение уже принято.
		if _try_defend(entity): continue
		if not _agents[entity]["dirty"]: continue
		var alive := {"entity": entity, "allowed": true}
		EventBus.publish(&"CombatEntityCanActRequested", alive)
		if not alive["allowed"]:
			_agents[entity]["dirty"] = false
			continue
		var active := {"entity": entity, "found": false}
		EventBus.publish(&"ActionGetRequested", active)
		if active["found"]:
			if _agents[entity]["reactive"] and _should_interrupt(entity, active["data"]):
				EventBus.publish(&"ActionCancelRequested", {"entity": entity, "reason": &"ai_reconsidered"})
			else:
				_agents[entity]["reactive"] = false
				continue
		if not _agents.has(entity):
			continue
		_agents[entity]["dirty"] = false
		_agents[entity]["reactive"] = false
		_decide(entity)

# Общая реакция для обычных врагов и босса. Не прерываем уже начатые
# атаки, оглушение и другие важные действия; можно отменить только ожидание
# или движение. Состояние блока принадлежит штатному ShieldBlockActionService.
func _try_defend(entity: StringName) -> bool:
	var agent: Dictionary = _agents[entity]
	if agent.get("role","") != "melee" or not agent.get("detected",false): return false
	var target: StringName = agent.get("target",&"")
	if target == &"" or not _entity_exists(target) or CombatService.is_entity_dead(entity): return false
	var action := {"entity":entity}
	EventBus.publish(&"ActionGetRequested",action)
	if action.get("found",false) and action["data"].get("id",null) not in [&"wait",&"move"]: return false
	var gear := {"entity":entity,"component":&"equipment"}
	EventBus.publish(&"ComponentGetRequested",gear)
	var slot := ""
	for hand in ["off","main"]:
		var item = gear.get("data",{}).get(hand,null)
		if not item is StringName or item == &"": continue
		var q := {"item":item}
		EventBus.publish(&"ItemGetRequested",q)
		if q.get("found",false) and q.get("base",{}).get("slot","") == "shield": slot = hand; break
	if slot.is_empty(): return false
	var stamina := {"entity":entity,"resource":&"Stamina"}
	EventBus.publish(&"ResourceGetRequested",stamina)
	if not stamina.get("found",false) or float(stamina.get("data",{}).get("current",0)) < 1.0: return false
	var body := _body(entity)
	var enemy := _body(target)
	if body.is_empty() or enemy.is_empty(): return false
	# Обнаружение по звуку не даёт знания направления удара сквозь стену.
	var from := Vector2i(floori(body["center"].x),floori(body["center"].y))
	var to := Vector2i(floori(enemy["center"].x),floori(enemy["center"].y))
	var los := {"from":from,"to":to}
	EventBus.publish(&"SpaceLineOfSightRequested",los)
	if not los.get("visible",false): return false
	var direction := _shield_threat_direction(entity,target,slot,body,enemy)
	if direction == Vector2.ZERO: return false
	if action.get("found",false):
		var cancel := {"entity":entity,"reason":&"ai_shield_reaction"}
		EventBus.publish(&"ActionCancelRequested",cancel)
		if not cancel.get("accepted",false): return false
	var block := {"entity":entity,"slot":slot,"direction":direction}
	EventBus.publish(&"ShieldBlockStartRequested",block)
	if not block.get("accepted",false):
		if _agents.has(entity): _agents[entity]["dirty"] = true
		return false
	EventBus.publish(&"AIDecision", {"entity":entity,"decision":"shield_block","target":target,"direction":direction})
	return true

func _shield_threat_direction(entity: StringName, target: StringName, slot: String, body: Dictionary, enemy: Dictionary) -> Vector2:
	var directions: Array[Vector2] = []
	var anchor: Vector2i = body["anchor"]
	var size: int = body["size"]
	var center: Vector2 = body["center"]
	# Все позиции по периметру дают выбор реальной дискретной клетки щита.
	for x in range(-1,size+1):
		for y in range(-1,size+1):
			if (x in [-1,size]) == (y in [-1,size]): continue
			var d := (Vector2(anchor+Vector2i(x,y))+Vector2.ONE*0.5-center).normalized()
			if d != Vector2.ZERO: directions.append(d)
	var opponent_action := {"entity":target}
	EventBus.publish(&"ActionGetRequested",opponent_action)
	if opponent_action.get("found",false) and opponent_action["data"].get("id",null) == &"weapon_strike":
		var strike := {"entity":target}
		EventBus.publish(&"WeaponStrikeActionStatusRequested",strike)
		if strike.get("active",false):
			var p: Dictionary = strike["data"]
			var left := float(ceili(float(p["duration_steps"])/2.0))*0.01-float(opponent_action["data"]["elapsed"])
			if left > 0.0 and left <= 0.45:
				var zone := {"entity":target,"item":p["item"],"strike":p["strike"],"direction":p["direction"],"kind":"physical"}
				EventBus.publish(&"WeaponStrikePreviewRequested",zone)
				if zone.get("accepted",false):
					var attack_set: Dictionary = zone.get("zone",{}).get("tile_set",{})
					var best := Vector2.ZERO
					var count := 0
					for d in directions:
						var preview := {"entity":entity,"slot":slot,"direction":d}
						EventBus.publish(&"ShieldBlockPreviewRequested",preview)
						if not preview.get("accepted",false): continue
						var n := 0
						for tile in preview["data"]["tiles"]:
							if attack_set.has(tile): n += 1
						if n > count: best=d; count=n
					if count > 0: return best
	# Только собственные стрелы обнаруженной цели; проверяем свободную линию,
	# реальную геометрию щита и оставшееся время полёта.
	var shots := {}
	EventBus.publish(&"ProjectilesGetRequested",shots)
	for shot in shots.get("projectiles",{}).values():
		if shot.get("weapon_type","") != "bow" or shot.get("owner",null) != target: continue
		var position: Vector2 = shot["position"]
		var point_tile := Vector2i(floori(position.x),floori(position.y))
		var visible := {"from":Vector2i(floori(center.x),floori(center.y)),"to":point_tile}
		EventBus.publish(&"SpaceLineOfSightRequested",visible)
		if not visible.get("visible",false): continue
		var travel := minf(float(shot["speed"])*0.45,float(shot["range"])-float(shot["distance"]))
		if travel <= 0.0: continue
		var vector: Vector2 = shot["direction"]
		var wall: Dictionary = ProjectileService._wall_ray(position,vector,travel)
		var hit: Dictionary = ProjectileService._first_body(position,vector,travel,ProjectileService._body_snapshot(),target)
		for d in directions:
			var preview := {"entity":entity,"slot":slot,"direction":d}
			EventBus.publish(&"ShieldBlockPreviewRequested",preview)
			if not preview.get("accepted",false): continue
			for tile in preview["data"]["tiles"]:
				var distance: float = ProjectileService._ray_rectangle(position,vector,travel,Rect2(Vector2(tile),Vector2.ONE))
				if distance < 0.0: continue
				if wall.get("hit",false) and float(wall["distance"]) <= distance + 0.000001: continue
				if hit.get("hit",false) and float(hit["distance"]) < distance - 0.000001: continue
				return d
	return Vector2.ZERO

func _should_interrupt(entity: StringName, action: Dictionary) -> bool:
	if not action.get("interruptible", false):
		return false
	var agent: Dictionary = _agents[entity]
	if not agent["detected"] and action["id"] in [&"move", &"rat_bite", &"ai_summon", &"ai_staff_attack"]:
		return true
	if agent["detected"] and action["id"] == &"wait":
		return true
	return _low_hp(entity, agent) and action["id"] in [&"move", &"rat_bite"]

func _decide(entity: StringName) -> void:
	if not _agents.has(entity):
		return
	var agent: Dictionary = _agents[entity]
	var target: StringName = agent["target"]
	if not agent["detected"] or target == &"" or not _entity_exists(target) or _body(target).is_empty():
		_wait(entity, agent)
		return
	# Призыватель имеет заданный ТЗ приоритет; порог отступления — необязательная настройка.
	if agent["role"] == "summoner":
		if _start_summon(entity):
			return
		if _staff_attack(entity, target):
			return
	if agent["role"] == "melee":
		var attack_state := _bow_attack(entity, target, agent) if str(agent["weapon"]["strike"]) == "bow_simple_shot" else _melee_attack(entity, target, agent)
		if attack_state == 1: return
		# Достали цель, но не можем ударить (например, нет Stamina).
		if attack_state == 2:
			_wait(entity, agent)
			return
	if _low_hp(entity, agent) and _retreat(entity, target):
		return
	if agent["role"] == "rat":
		var zone := {"entity": entity, "target": target, "accepted": false}
		EventBus.publish(&"RatBiteZoneRequested", zone)
		if zone["accepted"] and zone["hit"] and _can_pay_stamina(entity, float(agent["bite"]["stamina_cost"])):
			var bite: Dictionary = agent["bite"]
			var start := {"entity": entity, "target": target, "damage": bite["damage"], "duration": bite["duration"], "accepted": false}
			EventBus.publish(&"RatBiteStartRequested", start)
			if start["accepted"] and _pay_started_action(entity, &"rat_bite", float(bite["stamina_cost"])):
				EventBus.publish(&"AIDecision", {"entity": entity, "decision": "bite", "target": target})
				return
	var body := _body(entity)
	var target_body := _body(target)
	if not body.is_empty() and not target_body.is_empty():
		var toward := {"entity": entity, "target": target if agent["role"] == "melee" else target_body["anchor"], "accepted": false}
		EventBus.publish(&"MovementMeleeApproachStepRequested" if agent["role"] == "melee" else &"MovementStepTowardRequested", toward)
		if toward["accepted"]:
			EventBus.publish(&"AIDecision", {"entity": entity, "decision": "approach", "target": target})
			return
	_wait(entity, agent)

# Возвращает 1 при начатой атаке, 2 если оружие/цель недоступны или цель
# в зоне, но удар не начался, 0 если цель вне зоны и нужно приблизиться.
func _melee_attack(entity: StringName, target: StringName, agent: Dictionary) -> int:
	var attacker := _body(entity)
	var victim := _body(target)
	if attacker.is_empty() or victim.is_empty(): return 2
	var target_position := {"entity":target,"found":false}
	EventBus.publish(&"MovementPositionGetRequested",target_position)
	if not target_position.get("found",false) or not target_position.get("position",null) is Vector2: return 2
	var position: Vector2 = target_position["position"]
	var direction := position + Vector2.ONE * float(victim["size"]) * 0.5 - Vector2(attacker["center"])
	if direction.length_squared() < 0.0000001: return 2
	var weapon: Dictionary = agent["weapon"]
	var preview := {"entity":entity,"item":weapon["item"],"strike":weapon["strike"],"kind":"physical","direction":direction}
	EventBus.publish(&"WeaponStrikePreviewRequested",preview)
	if not preview.get("accepted",false) or not preview.get("zone",{}).get("tile_set",null) is Dictionary: return 2
	var hit := false
	for tile in preview["zone"]["tile_set"]:
		if float(tile.x) < position.x + victim["size"] and float(tile.x + 1) > position.x and float(tile.y) < position.y + victim["size"] and float(tile.y + 1) > position.y:
			hit = true
			break
	if not hit: return 0
	var start := {"entity":entity,"item":weapon["item"],"strike":weapon["strike"],"direction":direction,"accepted":false}
	_weapon_launch = entity
	EventBus.publish(&"WeaponStrikeStartRequested",start)
	_weapon_launch = &""
	if not start.get("accepted",false): return 2
	EventBus.publish(&"AIDecision", {"entity":entity,"decision":"weapon_strike","target":target,"item":weapon["item"],"strike":weapon["strike"]})
	return 1

# Лучник использует общий ИИ и штатное действие выстрела. 0: нет линии /
# дистанции и надо искать позицию; 2: цель доступна, но сейчас нельзя стрелять.
func _bow_attack(entity: StringName, target: StringName, agent: Dictionary) -> int:
	var body := _body(entity)
	var victim := _body(target)
	if body.is_empty() or victim.is_empty(): return 2
	var own_pos := {"entity":entity,"found":false}
	var target_pos := {"entity":target,"found":false}
	EventBus.publish(&"MovementPositionGetRequested",own_pos)
	EventBus.publish(&"MovementPositionGetRequested",target_pos)
	if not own_pos.get("found",false) or not target_pos.get("found",false): return 2
	var start: Vector2 = own_pos["position"] + Vector2.ONE * float(body["size"]) * 0.5
	var center: Vector2 = target_pos["position"] + Vector2.ONE * float(victim["size"]) * 0.5
	var direction: Vector2 = center-start
	if direction.length_squared() < 0.000001: return 2
	direction = direction.normalized()
	var muzzle := {"entity":entity,"direction":direction}
	EventBus.publish(&"BowMuzzlePreviewRequested",muzzle)
	if not muzzle.get("accepted",false):
		# Слишком близкая цель требует отойти, а не идти сквозь неё.
		if _retreat(entity,target): return 1
		return 2
	var weapon_range = ProjectileService.effective_projectile_parameters("bow").get("range",null)
	if not _number(weapon_range) or float(weapon_range) <= 0: return 2
	var from: Vector2 = muzzle["position"]
	var bodies: Array = ProjectileService._body_snapshot()
	var hit: Dictionary = ProjectileService._first_body(from,direction,float(weapon_range),bodies,entity)
	var wall: Dictionary = ProjectileService._wall_ray(from,direction,float(weapon_range))
	if not hit.get("hit",false) or hit.get("entity",null) != target or (wall.get("hit",false) and float(wall["distance"]) <= float(hit["distance"]) + 0.000001): return 0
	var weapon: Dictionary = agent["weapon"]
	var request := {"entity":entity,"item":weapon["item"],"direction":direction}
	_weapon_launch = entity
	EventBus.publish(&"BowShotStartRequested",request)
	_weapon_launch = &""
	if not request.get("accepted",false): return 2
	EventBus.publish(&"AIDecision", {"entity":entity,"decision":"bow_shot","target":target,"item":weapon["item"]})
	return 1

func authorizes_weapon_start(entity: Variant) -> bool:
	return entity is StringName and entity != &"" and _weapon_launch == entity

func _low_hp(entity: StringName, agent: Dictionary) -> bool:
	if agent["retreat_hp_ratio"] == null:
		return false
	var hp := {"entity": entity, "resource": &"HP", "found": false}
	EventBus.publish(&"ResourceGetRequested", hp)
	return hp["found"] and float(hp["data"]["max"]) > 0.0 and float(hp["data"]["current"]) / float(hp["data"]["max"]) <= float(agent["retreat_hp_ratio"])

func _retreat(entity: StringName, target: StringName) -> bool:
	var body := _body(entity)
	var other := _body(target)
	if body.is_empty() or other.is_empty():
		return false
	var from: Vector2i = body["anchor"]
	var difference: Vector2i = from - other["anchor"]
	var xstep := Vector2i(signi(difference.x), 0)
	var ystep := Vector2i(0, signi(difference.y))
	var candidates := [xstep, ystep] if absi(difference.x) >= absi(difference.y) else [ystep, xstep]
	for delta in candidates:
		if delta == Vector2i.ZERO:
			continue
		var request := {"entity": entity, "delta": delta, "accepted": false}
		EventBus.publish(&"MovementStepRequested", request)
		if request["accepted"]:
			EventBus.publish(&"AIDecision", {"entity": entity, "decision": "retreat", "target": target})
			return true
	return false

func _wait(entity: StringName, agent: Dictionary) -> void:
	var request := {"entity": entity, "action": &"wait", "duration": agent["wait_duration"], "accepted": false}
	EventBus.publish(&"ActionStartRequested", request)
	if request["accepted"]:
		EventBus.publish(&"AIDecision", {"entity": entity, "decision": "wait"})
	else:
		# Следующий Tick позволяет повторить после временного конфликта.
		agent["dirty"] = true

func _staff_attack(entity: StringName, target: StringName) -> bool:
	var config: Dictionary = _agents[entity]["staff_attack"]
	if config.is_empty() or _pending.has(entity) or not _can_pay_stamina(entity, float(config["stamina_cost"])):
		return false
	var attacker := _body(entity)
	var victim := _body(target)
	if attacker.is_empty() or victim.is_empty():
		return false
	var direction: Vector2 = victim["center"] - attacker["center"]
	if direction.length_squared() <= 0.0000001:
		return false
	var query := {"entity": entity, "target": target, "weapon_type": "staff", "range": config["range"], "gap": config["gap"], "shape": config["shape"], "direction": direction, "accepted": false}
	EventBus.publish(&"StrikeZoneBodyTestRequested", query)
	if not query["accepted"] or not query["hit"]:
		return false
	var preview := {"entity": entity, "weapon_type": "staff", "range": config["range"], "gap": config["gap"], "shape": config["shape"], "direction": direction, "accepted": false}
	EventBus.publish(&"StrikeZoneGetRequested", preview)
	if not preview["accepted"]:
		return false
	_pending[entity] = {"kind": "staff", "target": target, "anchor": attacker["anchor"], "direction": direction, "config": config.duplicate(true), "tiles": preview["tiles"].duplicate(), "announced": false}
	var action := {"entity": entity, "target": target, "action": &"ai_staff_attack", "duration": config["duration"], "accepted": false}
	EventBus.publish(&"CombatStartActionRequested", action)
	if not action["accepted"] or not _pending.has(entity):
		_pending.erase(entity)
		return false
	if not _pay_started_action(entity, &"ai_staff_attack", float(config["stamina_cost"])):
		_pending.erase(entity)
		return false
	_pending[entity]["announced"] = true
	EventBus.publish(&"AIWeaponTelegraphStarted", {"entity": entity, "target": target, "tiles": preview["tiles"].duplicate(), "duration": config["duration"]})
	EventBus.publish(&"AIDecision", {"entity": entity, "decision": "staff", "target": target})
	return true

func _complete_staff(entity: StringName) -> void:
	var pending: Dictionary = _pending[entity]
	_pending.erase(entity)
	if not pending.get("announced", false):
		return
	var config: Dictionary = pending["config"]
	var query := {"entity": entity, "targets": [pending["target"]], "weapon_type": "staff", "range": config["range"], "gap": config["gap"], "shape": config["shape"], "direction": pending["direction"], "amount": config["damage"], "accepted": false}
	EventBus.publish(&"StrikeZoneDamageRequested", query)
	EventBus.publish(&"AIWeaponTelegraphEnded", {"entity": entity, "target": pending["target"], "reason": &"completed"})
	EventBus.publish(&"AIWeaponAttackResolved", {"entity": entity, "target": pending["target"], "hits": query.get("hits", []), "accepted": query["accepted"]})

func _can_pay_stamina(entity: StringName, amount: float) -> bool:
	var stamina := {"entity": entity, "resource": &"Stamina", "found": false}
	var hp := {"entity": entity, "resource": &"HP", "found": false}
	EventBus.publish(&"ResourceGetRequested", stamina)
	EventBus.publish(&"ResourceGetRequested", hp)
	if not stamina["found"] or not hp["found"]:
		return false
	var protected := maxf(float(hp["data"].get("reserve", 0.0)), float(hp["data"].get("reserve_filled", 0.0)))
	return maxf(0.0, float(stamina["data"]["current"]) - maxf(0.0, protected)) + 0.000000001 >= amount

func _pay_started_action(entity: StringName, action_id: StringName, amount: float) -> bool:
	var current := {"entity": entity, "found": false}
	EventBus.publish(&"ActionGetRequested", current)
	if not current["found"] or current["data"]["id"] != action_id:
		return false
	var spend := {"entity": entity, "resource": &"Stamina", "amount": amount, "accepted": false}
	EventBus.publish(&"ResourceSpendRequested", spend)
	if not spend["accepted"]:
		EventBus.publish(&"ActionCancelRequested", {"entity": entity, "reason": &"insufficient_stamina"})
		return false
	current = {"entity": entity, "found": false}
	EventBus.publish(&"ActionGetRequested", current)
	return current["found"] and current["data"]["id"] == action_id

func _start_summon(entity: StringName) -> bool:
	if _transition_cancel_busy: return false
	var cost := float(_rules.get("summon_mana", 10.0))
	var cap := int(_rules.get("summon_cap", 6))
	var mana := {"entity": entity, "resource": &"MP", "found": false}
	EventBus.publish(&"ResourceGetRequested", mana)
	if not mana["found"] or float(mana["data"]["current"]) < cost or _summons.get(entity, []).size() >= cap or _summon_anchor(entity).is_empty():
		return false
	_pending[entity] = {"kind": "summon", "room": _agents[entity]["room"]}
	var action := {"entity": entity, "action": &"ai_summon", "duration": float(_rules.get("summon_time", 2.0)), "accepted": false}
	EventBus.publish(&"ActionStartRequested", action)
	if not action["accepted"]:
		_pending.erase(entity)
		return false
	EventBus.publish(&"AIDecision", {"entity": entity, "decision": "summon"})
	return true

func _complete_summon(entity: StringName) -> void:
	if _summon_completing: return
	_summon_completing = true
	_complete_summon_inner(entity)
	_summon_completing = false

func _complete_summon_inner(entity: StringName) -> void:
	_pending.erase(entity)
	if not _agents.has(entity) or not _active(entity):
		return
	var cost := float(_rules.get("summon_mana", 10.0))
	var cap := int(_rules.get("summon_cap", 6))
	var room_id: StringName = _agents[entity]["room"]
	var mana := {"entity": entity, "resource": &"MP", "found": false}
	EventBus.publish(&"ResourceGetRequested", mana)
	var spot := _summon_anchor(entity)
	if not mana["found"] or float(mana["data"]["current"]) < cost or _summons.get(entity, []).size() >= cap or spot.is_empty():
		EventBus.publish(&"AISummonFailed", {"entity": entity})
		return
	_sequence += 1
	var child := StringName("summon:%s:%d" % [str(entity).uri_encode(), _sequence])
	var spawn := {"entity": child, "anchor": spot["anchor"], "room": spot["room"], "accepted": false}
	EventBus.publish(&"RatSpawnRequested", spawn)
	if not spawn["accepted"]:
		EventBus.publish(&"AISummonFailed", {"entity": entity})
		return
	# Обработчики спавна могут изменить ману или удалить участников.
	mana = {"entity": entity, "resource": &"MP", "found": false}
	EventBus.publish(&"ResourceGetRequested", mana)
	var child_alive := {"entity": child, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", child_alive)
	if not _agents.has(entity) or not _entity_exists(child) or not child_alive["allowed"] or not mana["found"] or float(mana["data"]["current"]) < cost:
		if _entity_exists(child):
			EventBus.publish(&"EntityRemoveRequested", {"entity": child})
		EventBus.publish(&"AISummonFailed", {"entity": entity})
		return
	var spend := {"entity": entity, "resource": &"MP", "value": float(mana["data"]["current"]) - cost, "accepted": false}
	EventBus.publish(&"ResourceSetRequested", spend)
	if not spend["accepted"]:
		EventBus.publish(&"EntityRemoveRequested", {"entity": child})
		EventBus.publish(&"AISummonFailed", {"entity": entity})
		return
	if not _entity_exists(child):
		EventBus.publish(&"AISummonFailed", {"entity": entity})
		return
	if _summons.has(entity):
		_summons[entity].append(child)
	_tracked[child] = room_id
	EventBus.publish(&"AISummoned", {"entity": entity, "summon": child, "room": room_id})

func _summon_anchor(entity: StringName) -> Dictionary:
	var body := _body(entity)
	if body.is_empty() or body["room"] == null:
		return {}
	var origin: Vector2i = body["anchor"]
	var radius := int(_rules.get("summon_search_radius", 8))
	for ring in range(1, mini(radius, 32) + 1):
		for y in range(-ring, ring + 1):
			for x in range(-ring, ring + 1):
				if maxi(absi(x), absi(y)) != ring:
					continue
				var anchor := origin + Vector2i(x, y)
				# Сначала место для 4x4, чтобы оба возможных размера поместились.
				var fits := {"anchor": anchor, "size": 4, "room": body["room"], "ignore_entity": &""}
				EventBus.publish(&"SpaceBodyFitsRequested", fits)
				if fits.get("fits", false):
					return {"anchor": anchor, "room": body["room"].duplicate(true)}
	return {}

func _body(entity: StringName) -> Dictionary:
	var query := {"entity": entity, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", query)
	return query.get("data", {}) if query["found"] else {}
func _entity_exists(entity: StringName) -> bool:
	var query := {"entity": entity, "found": false}
	EventBus.publish(&"EntityGetRequested", query)
	return query["found"]
func _room_bounds(room: Dictionary) -> Dictionary:
	return {"origin": room["origin_cell"] * _tile_scale, "size": room["size_cells"] * _tile_scale}
func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))
func _valid_duration(value: Variant) -> bool:
	return _number(value) and float(value) >= 0.01 and float(value) <= 10000000.0 and absf(roundf(float(value) / 0.01) * 0.01 - float(value)) < 0.000001
func _fail(event: Dictionary, error: String) -> void:
	event["error"] = error
func _snapshot_collect(event: Dictionary) -> void:
	if _summon_completing or _transition_cancel_busy: event["errors"].append("Нельзя сохранять во время изменения призыва")
	event["sections"]["ai"] = {"agents": _agents.duplicate(true), "summons": _summons.duplicate(true), "tracked": _tracked.duplicate(true), "pending": _pending.duplicate(true), "room": _room, "controlled": _controlled, "sequence": _sequence}
func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["ai"]
	_agents = data["agents"].duplicate(true)
	_summons = data["summons"].duplicate(true)
	_tracked = data["tracked"].duplicate(true)
	_pending = data["pending"].duplicate(true)
	_room = data["room"]
	_controlled = data["controlled"]
	_sequence = int(data["sequence"])

func _snapshot_restored(_event: Dictionary) -> void:
	for entity in _pending:
		var pending: Dictionary = _pending[entity]
		if pending.get("kind", "") == "staff" and pending.get("announced", false):
			EventBus.publish(&"AIWeaponTelegraphStarted", {"entity": entity, "target": pending["target"], "tiles": pending["tiles"].duplicate(), "duration": pending["config"]["duration"], "restored": true})

# Только завершённые призывы ИИ, не любые существа с похожим ID.
func summoned_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _summon_completing or _transition_cancel_busy: return {"accepted":false, "error":"Призыв занят или нет операции перехода"}
	for entry in _pending.values():
		if entry.get("kind", "") == "summon": return {"accepted":false, "error":"Сначала необходимо отменить начатые призывы"}
	var ids: Array = _tracked.keys()
	ids.sort_custom(func(a,b): return str(a) < str(b))
	return {"accepted":true, "entities":ids}

func _summons_map_check(event: Dictionary) -> void:
	if _summon_completing or not _tracked.is_empty(): event["allowed"] = false

# Снимает только начатые ИИ призывы, не трогает живых детей и другие действия.
func cancel_pending_summons_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _summon_completing or _transition_cancel_busy:
		return {"accepted":false, "error":"Призыв занят или нет операции перехода"}
	_transition_cancel_busy = true
	var before: Dictionary = _pending.duplicate(true)
	var tracked_before: Dictionary = _tracked.duplicate(true)
	var summons_before: Dictionary = _summons.duplicate(true)
	var targets: Array = []
	var expected: Dictionary = before.duplicate(true)
	var error := ""
	for actor in before:
		if before[actor].get("kind", "") == "summon":
			targets.append(actor)
			_transition_cancel_targets[actor] = true
	targets.sort_custom(func(a,b): return str(a) < str(b))
	for actor in targets:
		var active := ActionRegistry.get_active_action(actor)
		if actor == _controlled or not _agents.has(actor) or active.get("id", &"") != &"ai_summon":
			error = "Призыватель или его действие изменились"
			break
	if _pending != before or _tracked != tracked_before or _summons != summons_before or not SaveService.world_transition_operation_active(): error = "Состояние призывов изменилось"
	if error.is_empty():
		for actor in targets:
			if ActionRegistry.get_active_action(actor).get("id", &"") != &"ai_summon":
				error = "Действие призыва изменилось"
				break
			var cancelled := ActionRegistry.cancel_action(actor, &"floor_transition")
			expected.erase(actor)
			if not cancelled or not ActionRegistry.get_active_action(actor).is_empty() or _pending != expected or _tracked != tracked_before or _summons != summons_before or not SaveService.world_transition_operation_active():
				error = "Не удалось безопасно отменить призыв"
				break
	_transition_cancel_targets.clear()
	_transition_cancel_busy = false
	if not error.is_empty():
		SaveService.fail_world_transition(error)
		return {"accepted":false, "error":error}
	return {"accepted":true, "entities":targets}

func _transition_action_guard(event: Dictionary) -> void:
	if _transition_cancel_busy and (_transition_cancel_targets.has(event.get("entity", &"")) or event.get("action", &"") == &"ai_summon"):
		event["allowed"] = false
