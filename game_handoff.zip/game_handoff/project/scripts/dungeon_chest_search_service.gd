extends Node
## Пагинация детерминированного поиска; никаких объектов и резерваций.
const MAX_AREA := 16384
const MAX_SCAN := 256
const MAX_CHECK := 4

func _ready() -> void:
	EventBus.subscribe(&"DungeonChestPositionSearchRequested", _search)

func _search(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["found", "complete", "next_cursor", "scanned", "preflight_checked", "tile", "interaction_anchor", "connected_exits_checked", "open_exits_checked", "error"]: e.erase(key)
	var room = e.get("room", null)
	var cursor = e.get("cursor", 0)
	var scan_limit = e.get("scan_limit", MAX_SCAN)
	var check_limit = e.get("check_limit", MAX_CHECK)
	if not room is StringName or room == &"" or not cursor is int or not scan_limit is int or scan_limit < 1 or scan_limit > MAX_SCAN or not check_limit is int or check_limit < 1 or check_limit > MAX_CHECK:
		e["error"] = "Некорректные параметры поиска"; return
	var rq := {"id":room, "found":false}
	EventBus.publish(&"RoomGetRequested", rq)
	if not rq.get("found", false): e["error"] = "Комната не найдена"; return
	var data: Dictionary = rq["data"]
	var origin: Vector2i = data["origin_cell"] * 4
	var size: Vector2i = data["size_cells"] * 4
	var total: int = size.x * size.y
	if size.x < 1 or size.y < 1 or total > MAX_AREA or cursor < 0 or cursor > total:
		e["error"] = "Размер комнаты или курсор вне допустимого диапазона"; return
	var scanned := 0
	var checked := 0
	var next: int = cursor
	var chosen: Dictionary = {}
	while next < total and scanned < scan_limit and checked < check_limit:
		var tile := origin + Vector2i(next % size.x, int(next / size.x))
		next += 1
		scanned += 1
		if not _wall_floor(tile): continue
		checked += 1
		var candidate := {"room":room, "tile":tile, "accepted":false}
		EventBus.publish(&"DungeonChestPositionPreflightRequested", candidate)
		if candidate.get("accepted", false):
			chosen = candidate
			break
	e["accepted"] = true
	e["found"] = not chosen.is_empty()
	e["complete"] = next >= total
	e["next_cursor"] = next
	e["scanned"] = scanned
	e["preflight_checked"] = checked
	if not chosen.is_empty():
		e["tile"] = chosen["tile"]
		e["interaction_anchor"] = chosen["interaction_anchor"]
		e["connected_exits_checked"] = chosen["connected_exits_checked"]
		e["open_exits_checked"] = chosen["open_exits_checked"]

# Только дешёвый фильтр тех же условий preflight; проверка остальных условий
# остаётся в едином сервисе, чтобы поиск не заменял итоговую проверку.
func _wall_floor(tile: Vector2i) -> bool:
	var q := {"tile":tile}
	EventBus.publish(&"SpaceTileGetRequested", q)
	if not q.get("in_bounds", false) or q.get("kind", 0) != 1 or q.get("passage", false) or q.get("occupant", null) != null or q.get("obstacle", null) != null: return false
	for d in [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]:
		var neighbor := {"tile":tile + d}
		EventBus.publish(&"SpaceTileGetRequested", neighbor)
		if not neighbor.get("in_bounds", false) or neighbor.get("kind", 0) == 0: return true
	return false
