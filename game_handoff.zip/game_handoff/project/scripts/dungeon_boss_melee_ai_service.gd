extends Node
## Подключает штатного огра к тому же оружейному ИИ, что и обычных NPC.
## Никаких отдельных атакующих фаз босса здесь нет.
const STRIKE := "hammer_simple_slam"
const WAIT := 0.1
const MOVE_HUNDREDTHS := 20.0 # черновое значение; K_move берётся из ruleset
var _busy := false
var _generation := 0
var _status := "none"
var _error := ""
var _entity: StringName = &""

func _ready() -> void:
	EventBus.subscribe(&"DungeonBossEquipmentInstalled", _equipment_installed)
	EventBus.subscribe(&"PlayerRoomChanged", _room_changed)
	EventBus.subscribe(&"SnapshotRestored", _restored)
	EventBus.subscribe(&"TimeStepSettled", _settled)
	EventBus.subscribe(&"SpaceMapConfigured", _map_changed)
	EventBus.subscribe(&"DungeonBossMeleeAIStatusRequested", _status_requested)
	EventBus.subscribe(&"DungeonBossMeleeAIRetryRequested", _retry)

func _status_requested(e: Dictionary) -> void:
	e["status"] = _status
	e["entity"] = _entity if _entity != &"" else null
	e["error"] = _error

func _equipment_installed(_e: Dictionary) -> void:
	_attempt()

func _room_changed(_e: Dictionary) -> void:
	_attempt()

func _settled(_e: Dictionary) -> void:
	if _status == "waiting" and not _busy: _attempt()

func _map_changed(_e: Dictionary) -> void:
	_generation += 1
	_status = "none"
	_error = ""
	_entity = &""

func _restored(_e: Dictionary) -> void:
	_generation += 1
	_status = "none"
	_error = ""
	_entity = &""
	call_deferred("_restored_attempt", _generation)

func _restored_attempt(generation: int) -> void:
	if generation == _generation: _attempt()

func _retry(e: Dictionary) -> void:
	var result := _attempt()
	e.merge(result, true)

func _failure(message: String) -> Dictionary:
	_status = "failed"
	_error = message
	EventBus.publish(&"DungeonBossMeleeAIFailed", {"entity":_entity,"error":message})
	return {"accepted":false,"error":message}

func _attempt() -> Dictionary:
	if _busy or SaveService.world_transition_operation_active(): return {"accepted":false,"error":"Переход или регистрация ещё выполняется"}
	var boss := {"found":false}
	var current := {}
	EventBus.publish(&"DungeonBossGetRequested",boss)
	EventBus.publish(&"RoomCurrentGetRequested",current)
	if not boss.get("found",false) or boss.get("data",{}).get("status","") != "alive":
		_status = "none"; _entity = &""; _error = ""
		return {"accepted":false,"error":"Живой босс не найден"}
	var data: Dictionary = boss["data"]
	var id = data.get("entity",null)
	var room = data.get("room",null)
	var loadout = data.get("loadout",null)
	if not id is StringName or not room is StringName or not loadout is Dictionary or not loadout.get("main",null) is StringName:
		_status = "waiting"; _error = ""
		return {"accepted":false,"error":"Ожидается оснащение"}
	_entity = id
	var target = current.get("entity",null)
	if not target is StringName or target == &"" or current.get("room",null) != room or current.get("transitioning",true):
		_status = "waiting"; _error = ""
		return {"accepted":false,"error":"Игрок не находится в комнате босса"}
	_busy = true
	var ai := {"entity":id,"found":false}
	EventBus.publish(&"AIGetRequested",ai)
	if ai.get("found",false):
		var agent: Dictionary = ai.get("data",{})
		if agent.get("role",null) != "melee" or agent.get("room",null) != room or agent.get("weapon",{}).get("item",null) != loadout["main"] or str(agent.get("weapon",{}).get("strike","")) != STRIKE:
			_busy = false; return _failure("Босс уже зарегистрирован с другим ИИ")
		if agent.get("target",null) != target:
			var change := {"entity":id,"target":target,"detected":false,"accepted":false}
			EventBus.publish(&"AITargetSetRequested",change)
			if not change.get("accepted",false): _busy = false; return _failure("Не удалось обновить цель")
	else:
		var register := {"entity":id,"room":room,"role":"melee","target":target,"detected":false,"wait_duration":WAIT,"weapon":{"item":loadout["main"],"strike":STRIKE},"movement":{"base_hundredths":MOVE_HUNDREDTHS},"accepted":false}
		EventBus.publish(&"AIRegisterRequested",register)
		if not register.get("accepted",false): _busy = false; return _failure(str(register.get("error","Не удалось зарегистрировать ИИ")))
	var relation := {"a":id,"b":target,"hostile":true,"accepted":false}
	EventBus.publish(&"DetectionHostilitySetRequested",relation)
	if not relation.get("accepted",false): _busy = false; return _failure("Не удалось установить враждебность")
	_busy = false
	_status = "installed"; _error = ""
	EventBus.publish(&"DungeonBossMeleeAIInstalled", {"entity":id,"target":target,"room":room})
	return {"accepted":true}
