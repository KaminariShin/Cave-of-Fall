extends Node
## Независимые процессы, без Callable: сохраняются посреди полёта.
const EPS := 0.000001
const MAX_RAY_DISTANCE := 10000.0
const MAX_SUBSTEPS_PER_TICK := 50000
var _shots: Dictionary = {}
var _sequence := 0
var _weapons: Dictionary = {}
var _params: Dictionary = {}
var _transition_busy := false
var _transition_ids: Dictionary = {}
var _callback_depth := 0
# Контакты существуют только внутри одного шага, до закрытия боевой фазы.
var _phase_contacts: Dictionary = {}
var _phase_submitting := false

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		var combat: Dictionary = rules["ruleset"].get("parameters", {}).get("combat", {})
		_weapons = combat.get("weapons", {}).duplicate(true)
		_params = combat.get("projectiles", {}).duplicate(true)
	EventBus.subscribe(&"ProjectileLaunchRequested", _launch)
	EventBus.subscribe(&"BowMuzzlePreviewRequested", _bow_muzzle_preview)
	EventBus.subscribe(&"ProjectileGetRequested", _get_shot)
	EventBus.subscribe(&"ProjectilesGetRequested", _get_all)
	EventBus.subscribe(&"ProcessStepped", _process_step)
	EventBus.subscribe(&"ProcessCompleted", _process_completed)
	EventBus.subscribe(&"ProcessInterrupted", _process_interrupted)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)
	EventBus.subscribe(&"ProcessStartAllowedRequested", _transition_process_guard)
	EventBus.subscribe(&"SpawnMapReconfigureCheckRequested", _transition_map_guard)

# Отступ сокращён на два, а внешний предел от центра стрелка — на один.
# Длина полёта от новой точки запуска потому может увеличиться на один.
func effective_projectile_parameters(weapon: String) -> Dictionary:
	var original: Dictionary = _weapons.get(weapon,{})
	var gap = original.get("gap",null)
	var reach = original.get("range",null)
	if not _nonnegative(gap) or not _positive(reach): return {}
	var shift := minf(2.0,float(gap))
	return {"gap":float(gap)-shift,"range":maxf(0.01,float(reach)+shift-1.0)}

# Проверка безопасного старта; реальный выпуск повторяет проверку после подготовки.
# Это не перехват щитом: пока препятствие лишь не даёт стрелять сквозь него.
func _bow_muzzle_preview(event: Dictionary) -> void:
	event["accepted"] = false
	event.erase("error")
	var owner = event.get("entity",null)
	var d = event.get("direction",null)
	if not owner is StringName or owner == &"" or not (d is Vector2 or d is Vector2i): event["error"]="Некорректные данные выстрела"; return
	var direction := Vector2(d)
	if not is_finite(direction.x) or not is_finite(direction.y) or not is_finite(direction.length()) or direction.length() <= EPS: event["error"]="Некорректное направление"; return
	direction = direction.normalized()
	var body := {"entity":owner,"found":false}
	EventBus.publish(&"SpaceBodyGetRequested",body)
	if not body.get("found",false): event["error"]="Тело стрелка недоступно"; return
	var offset_base = _params.get("muzzle_base_offset",null)
	var gap = effective_projectile_parameters("bow").get("gap",null)
	var clearance = _params.get("min_wall_clearance",null)
	if not _nonnegative(offset_base) or not _nonnegative(gap) or not _nonnegative(clearance) or float(offset_base)+float(gap)>MAX_RAY_DISTANCE: event["error"]="Параметры выстрела недоступны"; return
	var movement := {"entity":owner,"found":false}
	EventBus.publish(&"MovementPositionGetRequested",movement)
	var anchor: Vector2 = movement["position"] if movement.get("found",false) else Vector2(body["data"]["anchor"])
	var center: Vector2 = anchor + Vector2.ONE * float(body["data"]["size"]) / 2.0
	var offset: float = float(offset_base)+float(gap)
	var obstacle := _bow_start_obstacle(center,direction,offset,owner)
	if obstacle.get("hit",false): event["error"]="Препятствие перед точкой запуска стрелы"; return
	var muzzle := center+direction*offset
	var wall := _wall_ray(muzzle,direction,float(clearance))
	if wall.get("hit",false) and float(wall["distance"]) < float(clearance)-EPS: event["error"]="До стены меньше 0.4 тайла"; return
	event["accepted"] = true
	event["position"] = muzzle

func _bow_start_obstacle(center: Vector2, direction: Vector2, offset: float, owner: StringName) -> Dictionary:
	return _trace_arrow_contact(center,direction,offset,_body_snapshot(),owner)

func _launch(event: Dictionary) -> void:
	if _transition_busy:
		event["accepted"] = false
		return _error(event, "Очистка снарядов выполняется")
	_callback_depth += 1
	_launch_inner(event)
	_callback_depth -= 1

func _launch_inner(event: Dictionary) -> void:
	event["accepted"] = false
	var owner: StringName = event.get("entity", &"")
	var weapon := str(event.get("weapon_type", ""))
	if owner == &"" or weapon not in ["bow", "fireball"] or not _weapons.has(weapon):
		return _error(event, "Нужен носитель и тип bow или fireball")
	var alive := {"entity": owner, "allowed": true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	var body := {"entity": owner, "found": false}
	EventBus.publish(&"SpaceBodyGetRequested", body)
	if not alive["allowed"] or not body["found"]:
		return _error(event, "Носитель погиб или не имеет тела")
	var d = event.get("direction", null)
	if not (d is Vector2 or d is Vector2i):
		return _error(event, "Нужно направление")
	var direction := Vector2(d)
	var magnitude := direction.length()
	if not is_finite(direction.x) or not is_finite(direction.y) or not is_finite(magnitude) or magnitude <= EPS:
		return _error(event, "Нужно конечное ненулевое направление")
	direction /= magnitude
	var weapon_params: Dictionary = _weapons[weapon]
	var speed = event.get("speed", _params.get("default_speed", null))
	var adjusted := effective_projectile_parameters(weapon)
	var reach = event.get("range", adjusted.get("range",null))
	var gap = event.get("gap", adjusted.get("gap",null))
	var fireball: Dictionary = _params.get("fireball", {})
	var direct = event.get("damage", fireball.get("direct_damage", null) if weapon == "fireball" else null)
	var blast = fireball.get("explosion_damage", null) if weapon == "fireball" else 0.0
	if weapon == "fireball":
		var radius = fireball.get("explosion_radius_tiles", null)
		if not _nonnegative(radius) or float(radius) > 32.0 or floorf(float(radius)) != float(radius) or not fireball.get("explosion_los", null) is bool:
			return _error(event, "Недопустимые параметры взрыва")
	var ray_step = _params.get("ray_step_tiles", null)
	var offset_base = _params.get("muzzle_base_offset", null)
	var clearance = _params.get("min_wall_clearance", null)
	if not _positive(speed) or not _positive(reach) or float(reach) > MAX_RAY_DISTANCE or not _nonnegative(gap) or not _nonnegative(direct) or not _nonnegative(blast) or not _positive(ray_step) or not _nonnegative(offset_base) or not _nonnegative(clearance):
		return _error(event, "Нужны скорость, дальность и урон; проверьте параметры ruleset")
	if ceil(float(speed) * 0.01 / float(ray_step)) > MAX_SUBSTEPS_PER_TICK:
		return _error(event, "Слишком высокая скорость")
	var total_steps_float: float = ceil(float(reach) / float(speed) / 0.01)
	if not is_finite(total_steps_float) or total_steps_float > 1000000000.0:
		return _error(event, "Длительность полёта слишком велика")
	var total_steps := maxi(1, int(total_steps_float))
	var movement := {"entity": owner, "found": false}
	EventBus.publish(&"MovementPositionGetRequested", movement)
	var anchor: Vector2 = movement["position"] if movement["found"] else Vector2(body["data"]["anchor"])
	var center := anchor + Vector2.ONE * float(body["data"]["size"]) / 2.0
	var offset: float = float(offset_base) + float(gap)
	if not is_finite(offset) or offset > MAX_RAY_DISTANCE:
		return _error(event, "Слишком большой отступ")
	var muzzle := center + direction * offset
	if weapon == "bow":
		var obstacle := _bow_start_obstacle(center, direction, offset, owner)
		if obstacle.get("hit",false): return _error(event, "Препятствие перед точкой запуска стрелы")
	# Между телом и точкой старта нельзя проскочить сквозь скалу.
	if _wall_ray(center, direction, offset).get("hit", false):
		return _error(event, "Стена перед точкой запуска")
	var near := _wall_ray(muzzle, direction, float(clearance))
	if near.get("hit", false) and float(near["distance"]) < float(clearance) - EPS:
		return _error(event, "До стены меньше 0.4 тайла")
	var direct_snapshot := _source_damage(owner, float(direct))
	var blast_snapshot := _source_damage(owner, float(blast)) if weapon == "fireball" else {"accepted": true, "value": 0.0}
	if not direct_snapshot["accepted"] or not blast_snapshot["accepted"]:
		return _error(event, "Ошибка конвейера урона")
	_sequence += 1
	var id := StringName("projectile:%d" % _sequence)
	var shot := {"id": id, "owner": owner, "weapon_type": weapon, "origin": muzzle, "position": muzzle, "direction": direction, "speed": float(speed), "range": float(reach), "distance": 0.0, "direct_damage": float(direct_snapshot["value"]), "blast_damage": float(blast_snapshot["value"]), "impact_target": &"", "last_free": muzzle, "last_free_tile": _tile(muzzle)}
	_shots[id] = shot
	var process := {"id": id, "duration": total_steps * 0.01, "entity": owner, "independent": true, "accepted": false}
	EventBus.publish(&"ProcessStartRequested", process)
	if not process["accepted"]:
		_shots.erase(id)
		return _error(event, "Не удалось создать процесс снаряда")
	event["accepted"] = true
	event["id"] = id
	event["position"] = muzzle
	EventBus.publish(&"ProjectileLaunched", {"id": id, "entity": owner, "position": muzzle, "direction": direction})
	# Попадание в точке старта не ждёт первого игрового шага.
	if _shots.has(id):
		var bodies := _body_snapshot()
		var initial := _first_body(muzzle, direction, 0.0, bodies, owner)
		if initial["hit"]:
			shot["impact_target"] = initial["entity"]
			EventBus.publish(&"ProcessInterruptRequested", {"id": id, "reason": &"entity"})

func _process_step(event: Dictionary) -> void:
	_callback_depth += 1
	_process_step_inner(event)
	_callback_depth -= 1

func _process_step_inner(event: Dictionary) -> void:
	var id: StringName = event.get("process", &"")
	if not _shots.has(id):
		return
	var shot: Dictionary = _shots[id]
	var start: float = float(shot["distance"])
	var end: float = minf(float(shot["range"]), float(shot["speed"]) * float(event["elapsed"]))
	var step := float(_params.get("ray_step_tiles", 0.2))
	var bodies := _body_snapshot()
	while start < end and _shots.has(id):
		var next_distance := minf(start + step, end)
		if next_distance <= start:
			break
		var segment := next_distance - start
		var point: Vector2 = shot["origin"] + shot["direction"] * start
		var wall := _wall_ray(point, shot["direction"], segment)
		var hit := _first_body(point, shot["direction"], segment, bodies, shot["owner"])
		var shield := _first_shield(point, shot["direction"], segment, bodies, shot["owner"]) if shot["weapon_type"] == "bow" else {"hit":false}
		if wall.get("hit", false) and (not hit["hit"] or float(wall["distance"]) <= float(hit["distance"]) + EPS) and (not shield["hit"] or float(wall["distance"]) <= float(shield["distance"]) + EPS):
			var distance: float = start + float(wall["distance"])
			shot["distance"] = distance
			shot["last_free"] = shot["origin"] + shot["direction"] * maxf(0.0, distance - 0.0001)
			if float(wall["distance"]) > EPS:
				shot["last_free_tile"] = wall["last_tile"]
			# Учитываем точность Vector2: точка остаётся внутри поражённого тайла.
			var contact: Vector2 = shot["origin"] + shot["direction"] * distance
			var wall_tile: Vector2i = wall["tile"]
			shot["position"] = Vector2(clampf(contact.x, wall_tile.x + 0.002, wall_tile.x + 0.998), clampf(contact.y, wall_tile.y + 0.002, wall_tile.y + 0.998))
			EventBus.publish(&"ProcessInterruptRequested", {"id": id, "reason": &"wall"})
			return
		if shield["hit"] and (not hit["hit"] or float(shield["distance"]) <= float(hit["distance"]) + EPS):
			shot["distance"] = start + float(shield["distance"])
			shot["position"] = point + shot["direction"] * float(shield["distance"])
			shot["impact_target"] = shield["entity"]
			shot["impact_shield_tile"] = shield["tile"]
			EventBus.publish(&"ProcessInterruptRequested", {"id":id,"reason":&"shield"})
			return
		if hit["hit"]:
			shot["distance"] = start + float(hit["distance"])
			var contact: Vector2 = shot["origin"] + shot["direction"] * float(shot["distance"])
			var target_pos: Vector2 = hit["position"]
			var target_size: float = hit["size"]
			shot["position"] = Vector2(clampf(contact.x, target_pos.x + 0.002, target_pos.x + target_size - 0.002), clampf(contact.y, target_pos.y + 0.002, target_pos.y + target_size - 0.002))
			shot["last_free"] = shot["position"]
			shot["impact_target"] = hit["entity"]
			EventBus.publish(&"ProcessInterruptRequested", {"id": id, "reason": &"entity"})
			return
		start = next_distance
	shot["distance"] = end
	shot["position"] = shot["origin"] + shot["direction"] * end
	shot["last_free"] = shot["position"]
	shot["last_free_tile"] = _tile(shot["position"])
	EventBus.publish(&"ProjectileMoved", {"id": id, "position": shot["position"]})
	if end >= float(shot["range"]):
		EventBus.publish(&"ProcessInterruptRequested", {"id": id, "reason": &"range"})

func _process_completed(event: Dictionary) -> void:
	var id: StringName = event.get("process", &"")
	if _shots.has(id):
		_finish(id, &"range")
func _process_interrupted(event: Dictionary) -> void:
	var id: StringName = event.get("process", &"")
	if _shots.has(id):
		_finish(id, event.get("reason", &"cancelled"))

func _finish(id: StringName, reason: StringName) -> void:
	_callback_depth += 1
	_finish_inner(id, reason)
	_callback_depth -= 1

func _finish_inner(id: StringName, reason: StringName) -> void:
	if not _shots.has(id):
		return
	var shot: Dictionary = _shots[id]
	_shots.erase(id) # Защита от повторного срабатывания вложенными событиями.
	var impact: Vector2 = shot["position"]
	var target: StringName = shot["impact_target"]
	if shot["weapon_type"] == "bow" and reason in [&"entity", &"shield"] and target != &"" and TimeDriver._stepping and not TimeDriver._combat_phase:
		_phase_contacts[id] = {"shot":shot.duplicate(true),"target":target,"attack_tiles":[shot["impact_shield_tile"]] if reason == &"shield" else [],"reason":reason}
		return
	var direct := {}
	if reason == &"entity" and target != &"":
		direct = _apply_damage(target, shot["owner"], shot["direct_damage"], "physical" if shot["weapon_type"] == "bow" else "")
	var explosion := {}
	if shot["weapon_type"] == "fireball" and reason in [&"entity", &"wall", &"range"]:
		explosion = _explode(shot, reason)
	EventBus.publish(&"ProjectileExpired", {"id": id, "owner": shot["owner"], "reason": reason, "position": impact, "target": target, "direct": direct, "explosion": explosion})

# Доверенная проверка привязки подготовленного попадания к контакту текущего шага.
func authorizes_phase_hit(hit: Dictionary) -> bool:
	var id = hit.get("hit_id",null)
	if not id is StringName or not _phase_contacts.has(id): return false
	var contact: Dictionary = _phase_contacts[id]
	return contact["shot"]["owner"] == hit.get("source",null) and contact["target"] == hit.get("target",null)

func submit_phase_contacts() -> void:
	if _phase_contacts.is_empty(): return
	_phase_submitting = true
	var contacts: Array = _phase_contacts.values().duplicate(true)
	var plan := {"contacts":contacts}
	ProjectilePhasePlanService._plan(plan)
	if not plan.get("accepted",false):
		CombatPhaseBatchService.reject_projectile_collection(str(plan.get("error","Ошибка подготовки стрел")))
	else:
		for hit in plan["data"]["hits"]:
			var target: StringName = hit["target"]
			if not CombatPhaseBatchService._blocked.has(target):
				var status := {"entity":target}
				EventBus.publish(&"ShieldBlockStatusRequested",status)
				if status.get("active",false):
					var resource := {"entity":target,"resource":&"Stamina"}
					EventBus.publish(&"ResourceGetRequested",resource)
					var stamina = resource.get("data",{}).get("current",null)
					if not resource.get("found",false) or not (stamina is int or stamina is float) or not is_finite(float(stamina)) or stamina < 0 or floorf(float(stamina)) != float(stamina):
						CombatPhaseBatchService.reject_projectile_collection("Недоступна Stamina блока стрелы")
						break
					var block := {"target":target,"direction":status["direction"],"expected_stamina":int(stamina)}
					CombatPhaseBatchService._submit_block(block)
					if not block.get("accepted",false):
						CombatPhaseBatchService.reject_projectile_collection("Не удалось подготовить блок стрелы")
						break
			var request: Dictionary = hit.duplicate(true)
			CombatPhaseBatchService.submit_projectile_hit(request)
			if not request.get("accepted",false):
				CombatPhaseBatchService.reject_projectile_collection(str(request.get("error","Попадание стрелы отклонено")))
				break
	_phase_submitting = false

func finish_phase_contacts(committed: bool) -> void:
	var contacts := _phase_contacts.duplicate(true)
	_phase_contacts.clear()
	for id in contacts:
		var contact: Dictionary = contacts[id]
		var shot: Dictionary = contact["shot"]
		var direct := {"accepted":committed,"simultaneous":true}
		if not committed: direct["error"] = "Боевой пакет отклонён"
		EventBus.publish(&"ProjectileExpired", {"id":id,"owner":shot["owner"],"reason":contact.get("reason",&"entity"),"position":shot["position"],"target":contact["target"],"direct":direct,"explosion":{}})

func _explode(shot: Dictionary, reason: StringName) -> Dictionary:
	var config: Dictionary = _params.get("fireball", {})
	var radius := int(config.get("explosion_radius_tiles", 1))
	var use_los := bool(config.get("explosion_los", true))
	var center := _tile(shot["position"])
	# При ударе в скалу источник LOS — последний свободный тайл перед стеной.
	var los_start: Vector2i = shot["last_free_tile"] if reason == &"wall" else center
	var zone: Dictionary = {}
	for y in range(center.y - radius, center.y + radius + 1):
		for x in range(center.x - radius, center.x + radius + 1):
			var tile := Vector2i(x, y)
			if _is_floor(tile) and (not use_los or _los(los_start, tile)):
				zone[tile] = true
	var hits: Array = []
	var bodies := _body_snapshot()
	for body in bodies:
		var rect := Rect2(body["position"], Vector2.ONE * float(body["size"]))
		var hit_tiles: Array = []
		for tile in zone:
			if rect.intersects(Rect2(Vector2(tile), Vector2.ONE)):
				hit_tiles.append(tile)
		if not hit_tiles.is_empty():
			hits.append({"entity": body["entity"], "tiles": hit_tiles})
	for hit in hits:
		var result := _apply_damage(hit["entity"], shot["owner"], shot["blast_damage"])
		hit["accepted"] = result.get("accepted", false)
		hit["applied"] = result.get("applied", 0.0)
	var out := {"center": center, "tiles": zone.keys(), "hits": hits}
	EventBus.publish(&"ProjectileExplosion", {"id": shot["id"], "owner": shot["owner"], "center": center, "tiles": out["tiles"], "hits": hits})
	return out

func _source_damage(owner: StringName, base: float) -> Dictionary:
	var request := {"entity": owner, "target": "damage.outgoing", "base": base, "accepted": false}
	EventBus.publish(&"PipelineEvaluateRequested", request)
	return request
func _apply_damage(target: StringName, owner: StringName, amount: float, damage_type: String = "") -> Dictionary:
	var request := {"entity": target, "source": owner, "amount": maxf(0.0, amount), "source_outgoing_precomputed": true, "accepted": false}
	if not damage_type.is_empty(): request["damage_type"] = damage_type
	EventBus.publish(&"CombatDamageRequested", request)
	return request

func _body_snapshot() -> Array:
	var query := {}
	EventBus.publish(&"SpaceBodiesGetRequested", query)
	var bodies: Dictionary = query.get("bodies", {})
	var ids: Array = bodies.keys()
	ids.sort_custom(func(a, b): return str(a) < str(b))
	var out: Array = []
	for id in ids:
		var body: Dictionary = bodies[id]
		var position := {"entity": id, "found": false}
		EventBus.publish(&"MovementPositionGetRequested", position)
		out.append({"entity": id, "position": position["position"] if position["found"] else Vector2(body["anchor"]), "size": body["size"]})
	return out

# Ближайший активный щит на отрезке; контакт разрешается общей боевой фазой.
func _first_shield(point: Vector2, direction: Vector2, length: float, bodies: Array, owner: StringName) -> Dictionary:
	var closest := length + 1.0
	var result := {"hit":false}
	for body in bodies:
		var actor = body.get("entity",null)
		if not actor is StringName or actor == owner: continue
		var zone := {"entity":actor}
		EventBus.publish(&"ShieldBlockZoneRequested",zone)
		if not zone.get("accepted",false): continue
		for tile in zone.get("data",{}).get("tiles",[]):
			if not tile is Vector2i: continue
			var t := _ray_rectangle(point,direction,length,Rect2(Vector2(tile),Vector2.ONE))
			if t >= 0.0 and t < closest - EPS:
				closest = t
				result = {"hit":true,"distance":t,"entity":actor,"tile":tile}
	return result

## Черновой геометрический прогноз, пока не участвует в разрешении полёта.
## При совпадении расстояний: стена, затем щит, затем тело; это допущение.
func _trace_arrow_contact(point: Vector2, direction: Vector2, length: float, bodies: Array, owner: StringName) -> Dictionary:
	var wall := _wall_ray(point, direction, length)
	var shield := _first_shield(point, direction, length, bodies, owner)
	var body := _first_body(point, direction, length, bodies, owner)
	var best := {"hit":false}
	for row in [["wall",wall],["shield",shield],["body",body]]:
		var candidate: Dictionary = row[1]
		if candidate.get("hit",false) and (not best["hit"] or float(candidate["distance"]) < float(best["distance"]) - EPS):
			best = candidate.duplicate(true)
			best["kind"] = row[0]
	return best

## Непрерывное пересечение луча с текущими прямоугольниками тел, в пределах сегмента.
func _first_body(point: Vector2, direction: Vector2, length: float, bodies: Array, owner: StringName) -> Dictionary:
	var closest := length + 1.0
	var result := {"hit": false}
	for body in bodies:
		if body["entity"] == owner:
			continue
		var t := _ray_rectangle(point, direction, length, Rect2(body["position"], Vector2.ONE * float(body["size"])))
		if t >= 0.0 and t < closest:
			closest = t
			result = {"hit": true, "distance": t, "entity": body["entity"], "position": body["position"], "size": body["size"]}
	return result

func _ray_rectangle(point: Vector2, direction: Vector2, length: float, rect: Rect2) -> float:
	var enter := 0.0
	var leave := length
	for axis in range(2):
		var p: float = point[axis]
		var v: float = direction[axis]
		var lo: float = rect.position[axis]
		var hi: float = lo + rect.size[axis]
		if absf(v) <= EPS:
			if p < lo or p >= hi:
				return -1.0
			continue
		var a := (lo - p) / v
		var b := (hi - p) / v
		enter = maxf(enter, minf(a, b))
		leave = minf(leave, maxf(a, b))
		if enter > leave + EPS:
			return -1.0
	if leave <= 0.0 and not rect.has_point(point):
		return -1.0
	return maxf(0.0, enter) if enter <= length + EPS and leave >= 0.0 else -1.0

## DDA дополнительно проверяет границы тайлов внутри каждого подшага 0.2.
func _wall_ray(origin: Vector2, direction: Vector2, length: float) -> Dictionary:
	var cell := _tile(origin)
	if not _is_floor(cell):
		return {"hit": true, "distance": 0.0, "tile": cell}
	var sx := signi(int(signf(direction.x)))
	var sy := signi(int(signf(direction.y)))
	var tx := INF
	var ty := INF
	var dx := INF
	var dy := INF
	if sx != 0:
		tx = (float(cell.x + 1) - origin.x) / direction.x if sx > 0 else (float(cell.x) - origin.x) / direction.x
		dx = 1.0 / absf(direction.x)
	if sy != 0:
		ty = (float(cell.y + 1) - origin.y) / direction.y if sy > 0 else (float(cell.y) - origin.y) / direction.y
		dy = 1.0 / absf(direction.y)
	while minf(tx, ty) <= length + EPS:
		var t := minf(tx, ty)
		var previous := cell
		if absf(tx - t) <= EPS:
			cell.x += sx
			tx += dx
		if absf(ty - t) <= EPS:
			cell.y += sy
			ty += dy
		if not _is_floor(cell):
			return {"hit": true, "distance": maxf(0.0, t), "tile": cell, "last_tile": previous}
	return {"hit": false}

func _los(from: Vector2i, to: Vector2i) -> bool:
	var x := from.x
	var y := from.y
	var dx := absi(to.x - x)
	var dy := -absi(to.y - y)
	var sx := 1 if x < to.x else -1
	var sy := 1 if y < to.y else -1
	var error := dx + dy
	while true:
		if not _is_floor(Vector2i(x, y)):
			return false
		if x == to.x and y == to.y:
			return true
		var e2 := error * 2
		if e2 >= dy:
			error += dy
			x += sx
		if e2 <= dx:
			error += dx
			y += sy
	return false
func _is_floor(tile: Vector2i) -> bool:
	var query := {"tile": tile, "in_bounds": false}
	EventBus.publish(&"SpaceTileGetRequested", query)
	return query["in_bounds"] and query.get("kind", 0) == 1
func _tile(point: Vector2) -> Vector2i:
	return Vector2i(floori(point.x), floori(point.y))
func _positive(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) > 0.0
func _nonnegative(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0
func _error(event: Dictionary, text: String) -> void:
	event["error"] = text
func _get_shot(event: Dictionary) -> void:
	var id: StringName = event.get("id", &"")
	event["found"] = _shots.has(id)
	if event["found"]:
		event["data"] = _shots[id].duplicate(true)
func _get_all(event: Dictionary) -> void:
	event["projectiles"] = _shots.duplicate(true)
func _snapshot_collect(event: Dictionary) -> void:
	if _transition_busy or _callback_depth > 0 or not _phase_contacts.is_empty(): event["errors"].append("Нельзя сохранять во время изменения снарядов")
	event["sections"]["projectiles"] = {"active": _shots.duplicate(true), "sequence": _sequence}
func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["projectiles"]
	_shots = data["active"].duplicate(true)
	_sequence = int(data["sequence"])

# Все зарегистрированные снаряды принадлежат текущей общей карте, включая
# выстрелы игрока и снаряды после удаления владельца. Взрыв не вызывается.
func discard_projectiles_for_transition() -> Dictionary:
	if not SaveService.world_transition_operation_active() or _transition_busy or _callback_depth > 0 or not _phase_contacts.is_empty():
		return {"accepted":false, "error":"Снаряды заняты или нет операции перехода"}
	_transition_busy = true
	var before: Dictionary = _shots.duplicate(true)
	var expected: Dictionary = before.duplicate(true)
	var ids: Array = before.keys()
	ids.sort_custom(func(a,b): return str(a) < str(b))
	var error := ""
	for id in ids: _transition_ids[id] = true
	for id in ids:
		var process := ProcessRegistry.get_process_info(id)
		if process.is_empty() or not process.get("independent", false) or process.get("entity_id", null) != before[id].get("owner", null):
			error = "Процесс снаряда отсутствует или не совпадает с владельцем"
			break
	if _shots != before or not SaveService.world_transition_operation_active(): error = "Состояние снарядов изменилось"
	if error.is_empty():
		for id in ids:
			var process := ProcessRegistry.get_process_info(id)
			if process.is_empty() or not process.get("independent", false) or process.get("entity_id", null) != before[id].get("owner", null):
				error = "Процесс снаряда изменился"
				break
			var stopped := ProcessRegistry.interrupt_process(id, &"floor_transition")
			expected.erase(id)
			if not stopped or ProcessRegistry.has_process(id) or _shots != expected or not SaveService.world_transition_operation_active():
				error = "Не удалось безопасно удалить снаряд"
				break
	_transition_ids.clear()
	_transition_busy = false
	if not error.is_empty():
		SaveService.fail_world_transition(error)
		return {"accepted":false, "error":error}
	return {"accepted":true, "projectiles":ids}

func _transition_process_guard(event: Dictionary) -> void:
	if _transition_busy and _transition_ids.has(event.get("id", &"")): event["allowed"] = false

func _transition_map_guard(event: Dictionary) -> void:
	if _transition_busy or _callback_depth > 0 or not _phase_contacts.is_empty() or not _shots.is_empty(): event["allowed"] = false
