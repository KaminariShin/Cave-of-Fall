extends Node
## Минимальный безопасный перенос одного предмета: без очереди автозамены и дропа.
const EQUIP := &"equipment_equip"
const UNEQUIP := &"equipment_unequip"
const SLOTS := ["main", "off", "head", "body", "hands", "belt", "legs", "feet", "ring1", "ring2", "amulet", "cloak"]
var _pending: Dictionary = {}
var _busy := false
var _drop_actor: StringName = &""
var _drop_item: StringName = &""
var _drop_slot := ""

func _ready() -> void:
	for entry in [[EQUIP, "Надеть"], [UNEQUIP, "Снять"]]:
		EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":entry[0], "name":entry[1], "type":&"utility", "base_duration":0.1, "interruptible":false}})
	EventBus.subscribe(&"EquipmentEquipRequested", _equip)
	EventBus.subscribe(&"EquipmentUnequipRequested", _unequip)
	EventBus.subscribe(&"EquipmentArmourGetRequested", _armour_get)
	EventBus.subscribe(&"PeriodicProtectionGetRequested", _periodic_protection)
	EventBus.subscribe(&"EquipmentInventoryAddCheckRequested", _inventory_add_check)
	EventBus.subscribe(&"ActionCompleted", _action_completed)
	EventBus.subscribe(&"ActionInterrupted", _action_interrupted)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"EntityDied", _entity_removed)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _restore)
	EventBus.subscribe(&"EquipmentSnapshotValidateRequested", _validate_snapshot)

func _query_component(entity: StringName, component: StringName) -> Dictionary:
	var q := {"entity":entity, "component":component, "found":false}
	EventBus.publish(&"ComponentGetRequested", q)
	return q

func _item(id: StringName) -> Dictionary:
	var q := {"item":id, "found":false}
	EventBus.publish(&"ItemGetRequested", q)
	return q

func _slot_ok(slot: String, base: Dictionary) -> bool:
	var category := str(base.get("slot", ""))
	if slot in ["main", "off"]: return category in ["weapon", "shield"]
	if slot in ["ring1", "ring2"]: return category == "ring"
	return category == slot and slot in SLOTS

func _two_handed(item: StringName) -> bool:
	if item == &"": return false
	var q := _item(item)
	return q.get("found", false) and q["base"].get("tags", []).has("two_handed")

func _armour_get(e: Dictionary) -> void:
	e["found"] = false
	var entity = e.get("entity", null)
	if not entity is StringName: return
	var owner := {"entity":entity, "found":false}
	EventBus.publish(&"EntityGetRequested", owner)
	if not owner["found"]: return
	var gear := _query_component(entity, &"equipment")
	var slots: Dictionary = gear["data"] if gear["found"] else {}
	var total := 0.0
	for slot in ["main", "off", "head", "body", "hands", "belt", "legs", "feet"]:
		var id = slots.get(slot, null)
		if id == null: continue
		if not (id is StringName or id is String): return
		var item := _item(StringName(str(id)))
		if not item["found"]: return
		var category := str(item["base"].get("slot", ""))
		if slot in ["main", "off"] and category != "shield": continue
		if slot not in ["main", "off"] and category != slot: continue
		var factor: Dictionary = DungeonChestLearningService.equipped_base_multiplier(entity, item["item_data"])
		if not factor.get("valid",false): return
		var base_armour := 0.0
		for stack in item["item_data"].get("materials", []):
			var material := {"material":StringName(str(stack.get("material_id", ""))), "found":false}
			EventBus.publish(&"MaterialGetRequested", material)
			if not material["found"]: return
			var value = material["data"].get("armor_per_unit", 0.0)
			if not (value is int or value is float) or not is_finite(float(value)) or float(value) < 0: return
			base_armour += float(value) * int(stack.get("count", 0))
		var mod_bonus: Dictionary = DungeonChestLearningService.equipped_armour_mod_bonus(entity, item["item_data"], item["base"])
		if not mod_bonus.get("valid",false): return
		total += base_armour * factor["multiplier"] + mod_bonus["bonus"]
	if not is_finite(total): return
	e["armour"] = total
	e["found"] = true

func _periodic_protection(e: Dictionary) -> void:
	if e.get("damage_type", "") != "physical": return
	# Провайдер присутствует: ошибка расчёта не должна выглядеть как 0%.
	e["percent"] = null
	e["protection_error"] = "Не удалось рассчитать физическую защиту"
	var armour := {"entity":e.get("entity", &""), "found":false}
	_armour_get(armour)
	if not armour["found"]: return
	var other := {"entity":e.get("entity",&""), "found":false}
	EventBus.publish(&"PhysicalProtectionSourcesGetRequested",other)
	if not other.get("found",false) or not other.get("sources",null) is Array: return
	var percentages: Array = []
	for source in other["sources"]:
		if not source is Dictionary or not (source.get("percent",null) is int or source.get("percent",null) is float) or not is_finite(float(source["percent"])): return
		percentages.append(source["percent"])
	var result := {"armour":armour["armour"], "percent_sources":percentages, "accepted":false}
	EventBus.publish(&"ArmourProtectionCalculateRequested", result)
	var percent = result.get("percent", null)
	if result.get("accepted", false) and (percent is int or percent is float) and is_finite(float(percent)):
		e["percent"] = percent
		e.erase("protection_error")

func _inventory_add_check(e: Dictionary) -> void:
	var item := StringName(str(e.get("item", "")))
	var query := {"components":[&"equipment"], "entities":[]}
	EventBus.publish(&"EntityQueryRequested", query)
	for owner in query["entities"]:
		var gear := _query_component(owner, &"equipment")
		if gear["found"] and _contains_item(gear["data"], item, 0):
			e["allowed"] = false
			return

func _contains_item(value: Variant, id: StringName, depth: int) -> bool:
	if depth > 32 or id == &"": return false
	if value is String or value is StringName: return StringName(str(value)) == id
	if value is Array:
		for v in value:
			if _contains_item(v, id, depth + 1): return true
	if value is Dictionary:
		for v in value.values():
			if _contains_item(v, id, depth + 1): return true
	return false

func _equip(e: Dictionary) -> void:
	e["accepted"] = false
	var entity = e.get("entity", null)
	var id = e.get("item", null)
	var slot := str(e.get("slot", ""))
	if _busy or not entity is StringName or entity == &"" or not id is StringName or id == &"" or slot not in SLOTS or _pending.has(entity): return
	var inv := _query_component(entity, &"inventory")
	var gear := _query_component(entity, &"equipment")
	var item := _item(id)
	if not inv["found"] or not item["found"] or not inv["data"].get("items", []).has(id): return
	var slots: Dictionary = gear["data"] if gear["found"] else {}
	if slots.get(slot, null) != null or not _slot_ok(slot, item["base"]): return
	var missing: Array = DungeonChestModCatalogService.unsupported_live_effects(item["item_data"])
	if not missing.is_empty():
		e["error"] = "Эффекты модов ещё не реализованы: " + str(missing)
		return
	if not DungeonChestLearningService.equipped_stat_mods_valid(entity,item["item_data"],item["base"]) or not DungeonChestLearningService.equipped_resource_mods_valid(entity,item["item_data"],item["base"]) or not DungeonChestLearningService.weapon_physical_damage_mod_bonus(entity,item["item_data"],item["base"]).get("valid",false):
		e["error"] = "Некорректный мод характеристики"; return
	if _two_handed(id) and (slot != "main" or slots.get("off", null) != null): return
	if slot == "off" and _two_handed(StringName(str(slots.get("main", "")))): return
	_start(e, entity, id, slot, EQUIP)

func _unequip(e: Dictionary) -> void:
	e["accepted"] = false
	var entity = e.get("entity", null)
	var slot := str(e.get("slot", ""))
	if _busy or not entity is StringName or entity == &"" or slot not in SLOTS or _pending.has(entity): return
	var gear := _query_component(entity, &"equipment")
	if not gear["found"]: return
	var id = gear["data"].get(slot, null)
	if not id is StringName or id == &"": return
	if not _can_fit(entity, id):
		var tile = e.get("drop_tile",null)
		if not tile is Vector2i:
			e["needs_drop_tile"] = true
			e["error"] = "Недостаточно места: выберите клетку для предмета"
			return
		var check := {"entity":entity,"tile":tile}
		EventBus.publish(&"LootDropTileCheckRequested",check)
		if not check.get("accepted",false) or not check.get("valid",false):
			e["error"] = "Выбранная клетка недоступна или слишком далеко"
			return
		_start(e, entity, id, slot, UNEQUIP, tile)
		return
	_start(e, entity, id, slot, UNEQUIP)

func _can_fit(entity: StringName, id: StringName) -> bool:
	var inventory := {"entity":entity, "found":false}
	EventBus.publish(&"InventoryGetRequested", inventory)
	var item := {"item":id, "found":false}
	EventBus.publish(&"ItemVolumeRequested", item)
	return inventory.get("found", false) and inventory.get("volume_known", false) and item.get("found", false) and float(inventory["used_volume"]) + float(item["volume"]) <= float(inventory["capacity"]) + 0.000000001

func _start(e: Dictionary, entity: StringName, item: StringName, slot: String, action: StringName, drop_tile: Variant = null) -> void:
	_pending[entity] = {"item":item, "slot":slot, "action":action}
	if drop_tile is Vector2i: _pending[entity]["drop_tile"] = drop_tile
	var request := {"entity":entity, "action":action, "duration":0.1, "accepted":false}
	EventBus.publish(&"ActionStartRequested", request)
	if not request["accepted"]:
		_pending.erase(entity)
		return
	e["accepted"] = true

func _action_completed(e: Dictionary) -> void:
	var entity: StringName = e.get("entity", &"")
	if not _pending.has(entity) or _pending[entity]["action"] != e.get("action", &""): return
	var operation: Dictionary = _pending[entity]
	_pending.erase(entity)
	var inv := _query_component(entity, &"inventory")
	var gear := _query_component(entity, &"equipment")
	var item: StringName = operation["item"]
	var slot: String = operation["slot"]
	var action: StringName = operation["action"]
	if not inv["found"]:
		_fail(entity, item, slot)
		return
	var inventory: Dictionary = inv["data"]
	var slots: Dictionary = gear["data"] if gear["found"] else {}
	var q := _item(item)
	if not q["found"]:
		_fail(entity, item, slot)
		return
	if action == EQUIP:
		if not DungeonChestLearningService.equipped_stat_mods_valid(entity,q["item_data"],q["base"]) or not DungeonChestLearningService.equipped_resource_mods_valid(entity,q["item_data"],q["base"]) or not DungeonChestLearningService.weapon_physical_damage_mod_bonus(entity,q["item_data"],q["base"]).get("valid",false) or not DungeonChestModCatalogService.unsupported_live_effects(q["item_data"]).is_empty() or not inventory.get("items", []).has(item) or slots.get(slot, null) != null or not _slot_ok(slot, q["base"]) or (_two_handed(item) and (slot != "main" or slots.get("off", null) != null)) or (slot == "off" and _two_handed(StringName(str(slots.get("main", ""))))):
			_fail(entity, item, slot)
			return
	else:
		if slots.get(slot, null) != item or (not operation.has("drop_tile") and not _can_fit(entity, item)):
			_fail(entity, item, slot)
			return
	var old_stats: Dictionary = StatsService.capture_equipment_stats(entity)
	if action == UNEQUIP and operation.has("drop_tile"):
		_busy = true
		_drop_actor = entity; _drop_item = item; _drop_slot = slot
		var dropped: Dictionary = LootService.commit_equipment_drop(entity,item,slot,operation["drop_tile"])
		_drop_actor = &""; _drop_item = &""; _drop_slot = ""
		_busy = false
		if not dropped.get("accepted",false): _fail(entity,item,slot); return
		EventBus.publish(&"ComponentChanged", {"entity":entity,"component":&"equipment","created":false})
		StatsService.notify_equipment_stats_change(entity,old_stats)
		EventBus.publish(&"ItemUnequipped", {"entity":entity,"item":item,"slot":slot,"reason":&"ground_drop"})
		var tile: Vector2i = dropped["tile"]
		EventBus.publish(&"LootItemDropped", {"entity":entity,"item":item,"tile":tile,"position":Vector2(tile)+Vector2.ONE*0.5})
		return
	# Единственный коммит обоих компонентов в реестр исключает промежуточное
	# владение предметом в двух контейнерах или потерю при ошибке.
	_busy = true
	var commit := {"entity":entity, "item":item, "slot":slot, "equip":action == EQUIP, "accepted":false}
	EventBus.publish(&"EquipmentTransferCommitRequested", commit)
	_busy = false
	if not commit["accepted"]:
		_fail(entity, item, slot)
		return
	StatsService.notify_equipment_stats_change(entity,old_stats)
	EventBus.publish(&"ItemEquipped" if action == EQUIP else &"ItemUnequipped", {"entity":entity, "item":item, "slot":slot})

func authorizes_ground_drop(entity: StringName, item: StringName, slot: String) -> bool:
	return _busy and entity == _drop_actor and item == _drop_item and slot == _drop_slot and entity != &"" and item != &""
func _fail(entity: StringName, item: StringName, slot: String) -> void:
	EventBus.publish(&"EquipmentActionFailed", {"entity":entity, "item":item, "slot":slot})

func _action_interrupted(e: Dictionary) -> void:
	var entity: StringName = e.get("entity", &"")
	if _pending.has(entity) and _pending[entity]["action"] == e.get("action", &""):
		_pending.erase(entity)

func _entity_removed(e: Dictionary) -> void:
	_pending.erase(e.get("entity", &""))

func _collect(e: Dictionary) -> void:
	if _busy:
		e["errors"].append("Нельзя сохранять во время переноса экипировки")
		return
	e["sections"]["equipment_actions"] = _pending.duplicate(true)

func _restore(e: Dictionary) -> void:
	_pending = e["sections"]["equipment_actions"].duplicate(true)
	_drop_actor = &""; _drop_item = &""; _drop_slot = ""

func _validate_snapshot(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary or not sections.get("equipment_actions", null) is Dictionary or not sections.get("actions", null) is Dictionary or not sections.get("entities", null) is Dictionary: return
	for entity in sections["equipment_actions"]:
		if not entity is StringName or not sections["entities"].has(entity): return
		var op = sections["equipment_actions"][entity]
		if not op is Dictionary or op.size() not in [3,4] or (op.size() == 4 and (not op.has("drop_tile") or not op["drop_tile"] is Vector2i or op.get("action",null) != UNEQUIP)) or not op.get("item", null) is StringName or op["item"] == &"" or str(op.get("slot", "")) not in SLOTS or op.get("action", null) not in [EQUIP, UNEQUIP]: return
		var actions: Dictionary = sections["actions"].get("active", {})
		if not actions.has(entity) or not actions[entity] is Dictionary or actions[entity].get("id", null) != op["action"]: return
		var instances = sections.get("items", {}).get("instances", null)
		if not instances is Dictionary or not instances.has(op["item"]): return
		var components = sections["entities"][entity]
		if not components is Dictionary: return
		var inventory = components.get(&"inventory", null)
		var slots = components.get(&"equipment", {})
		if not inventory is Dictionary or not inventory.get("items", null) is Array or not slots is Dictionary: return
		var held: Array = inventory["items"]
		if op["action"] == EQUIP:
			if held.count(op["item"]) != 1 or slots.get(op["slot"], null) != null: return
		else:
			if held.has(op["item"]) or slots.get(op["slot"], null) != op["item"]: return
	for entity in sections["actions"].get("active", {}):
		var action = sections["actions"]["active"][entity]
		if action is Dictionary and action.get("id", null) in [EQUIP, UNEQUIP] and not sections["equipment_actions"].has(entity): return
	e["valid"] = true
