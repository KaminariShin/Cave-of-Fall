extends Node
## Снимок по явно перечисленным кандидатам, без бросков или применения урона.
const MAX_TARGETS := 10000
const MAX_TILES := 300000
const LIMIT := 1000000000.0
func _ready() -> void:
	EventBus.subscribe(&"WeaponStrikeHitSnapshotRequested",_capture)
func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v)) and absf(float(v)) <= LIMIT
func _capture(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("data"); e.erase("error")
	var actor = e.get("entity",null)
	var candidates = e.get("candidates",null)
	if not actor is StringName or actor == &"" or not candidates is Array or candidates.size() > MAX_TARGETS:
		e["error"] = "Нужны атакующий и ограниченный список кандидатов"; return
	var seen := {}
	for id in candidates:
		if not id is StringName or id == &"" or id == actor or seen.has(id):
			e["error"] = "Кандидаты должны быть различными сущностями, кроме атакующего"; return
		seen[id] = true
	var status := {"entity":actor,"active":false}
	EventBus.publish(&"WeaponStrikeActionStatusRequested",status)
	if not status.get("active",false) or not status.get("data",null) is Dictionary or CombatService.is_entity_dead(actor):
		e["error"] = "Нет активного оружейного действия"; return
	var p: Dictionary = status["data"]
	var damage := {"entity":actor,"item":p["item"],"strike":p["strike"]}
	EventBus.publish(&"WeaponStrikeDamagePreviewRequested",damage)
	if not damage.get("accepted",false) or not damage.get("data",{}).get("in_hand",false): e["error"] = damage.get("error","Оружие недоступно"); return
	var raw = damage["data"].get("nonnegative_damage",null)
	var stat := {"entity":actor,"stat":&"PER","found":false}
	EventBus.publish(&"StatGetRequested",stat)
	if not _number(raw) or float(raw) < 0 or not stat.get("found",false) or not _number(stat.get("value",null)):
		e["error"] = "Урон или PER недоступны"; return
	var weapon := {"item":p["item"],"found":false}
	var strikes := {"item":p["item"],"found":false}
	EventBus.publish(&"WeaponItemResolveRequested",weapon)
	EventBus.publish(&"WeaponStrikesGetRequested",strikes)
	if not weapon.get("found",false) or not strikes.get("found",false): e["error"] = "Оружие недоступно"; return
	var strike: Dictionary = {}
	for row in strikes["strikes"]:
		if str(row.get("id","")) == p["strike"]: strike = row; break
	if strike.is_empty(): e["error"] = "Удар недоступен"; return
	var zone := {"entity":actor,"direction":p["direction"],"weapon_type":weapon["data"].get("type",null),"range":strike.get("range",null),"shape":strike.get("zone",null)}
	WeaponStrikeService.adjust_attack_zone(zone,strike)
	EventBus.publish(&"StrikeZoneGetRequested",zone)
	if not zone.get("accepted",false) or not zone.get("tiles",null) is Array or not zone.get("tile_set",null) is Dictionary:
		e["error"] = zone.get("error","Зона недоступна"); return
	var ordered: Array = candidates.duplicate()
	ordered.sort_custom(func(a,b): return str(a) < str(b))
	var targets: Array = []
	var tile_count := 0
	for target in ordered:
		if not EntityRegistry.has_entity(target): e["error"] = "Кандидат не существует"; return
		if CombatService.is_entity_dead(target): continue
		var body: Dictionary = StrikeZoneService._body(target)
		if body.is_empty(): e["error"] = "У кандидата нет тела"; return
		var overlap: Dictionary = StrikeZoneService._body_tiles_in_zone(target,body,zone["tile_set"])
		if not overlap.get("accepted",false): e["error"] = overlap.get("error","Положение цели недоступно"); return
		if overlap["tiles"].is_empty(): continue
		var health := {"entity":target,"resource":&"HP","found":false}
		var protection := {"entity":target,"damage_type":"physical","percent":null}
		EventBus.publish(&"ResourceGetRequested",health)
		EventBus.publish(&"PeriodicProtectionGetRequested",protection)
		var hp = health.get("data",{}).get("current",null)
		var pp = protection.get("percent",null)
		if not health.get("found",false) or not _number(hp) or float(hp) < 1 or floorf(float(hp)) != float(hp) or not _number(pp) or float(pp) > 75:
			e["error"] = "HP или физическая защита цели недоступны"; return
		tile_count += zone["tiles"].size()
		if tile_count > MAX_TILES: e["error"] = "Слишком много тайлов для пакета"; return
		targets.append({"target":target,"hp_before":int(hp),"physical_protection_percent":pp,"magical_protection_percent":0.0,"attack_tiles":zone["tiles"].duplicate()})
	# Это не атомарный общий снимок: запросы и подписчики могут менять мир.
	e["data"] = {"source":actor,"physical":float(raw),"magical":0.0,"per":stat["value"],"weakening_multiplier":p["damage_multiplier"],"targets":targets,"direction":p["direction"],"item":p["item"],"strike":p["strike"]}
	e["accepted"] = true
