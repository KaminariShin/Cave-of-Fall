extends Node
## Таблица только задаёт разрешённые слоты; генерацию модов выполняет ModService.
var _rarities: Dictionary = {}

func _ready() -> void:
	var rules := {"found": false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules["found"]:
		for rarity in rules["ruleset"].get("tables", {}).get("rarities", []):
			if rarity is Dictionary and not str(rarity.get("id", "")).is_empty():
				_rarities[StringName(str(rarity["id"]))] = rarity.duplicate(true)
	EventBus.subscribe(&"ItemRarityPrepareRequested", _prepare)
	EventBus.subscribe(&"ItemRarityGetRequested", _get_rarity)
	EventBus.subscribe(&"RarityValidateRequested", _validate)
	EventBus.subscribe(&"ItemModCanAttachRequested", _can_attach)
	EventBus.subscribe(&"AffixEligibilityRequested", _affix_eligible)

func _prepare(event: Dictionary) -> void:
	event["accepted"] = false
	var rarity := StringName(str(event.get("rarity", "")))
	if not _rarities.has(rarity):
		event["error"] = "Неизвестная редкость"
		return
	var set_id = event.get("set_id", null)
	if set_id != null and (not (set_id is String or set_id is StringName) or str(set_id).is_empty()):
		event["error"] = "Некорректный set_id"
		return
	var rule: Dictionary = _rarities[rarity]
	if rule["set_policy"] == "none" and set_id != null:
		event["error"] = "Обычный предмет не может принадлежать сету"
		return
	if rule["set_policy"] == "required" and set_id == null:
		event["error"] = "Артефакт должен быть ключевым предметом сета"
		return
	event["rank"] = int(rule["rank"])
	event["extra_category"] = null
	if rule.get("extras", "none") == "random_one":
		var roll := {"min": 0, "max": 1, "accepted": false}
		EventBus.publish(&"RngIntRequested", roll)
		if not roll["accepted"]:
			event["error"] = "Генератор случайных чисел недоступен"
			return
		event["extra_category"] = "prefix" if roll["value"] == 0 else "suffix"
	event["accepted"] = true

func _get_rarity(event: Dictionary) -> void:
	var info := _item_info(event.get("item", &""))
	event["found"] = info["ok"]
	if info["ok"]:
		event["data"] = info["data"]

func _can_attach(event: Dictionary) -> void:
	event["allowed"] = false
	var category := str(event.get("category", ""))
	var info := _item_info(event.get("item", &""))
	if not info["ok"] or category not in ["prefix", "suffix", "affix"]:
		event["error"] = "Неизвестный предмет, редкость или категория"
		return
	var data: Dictionary = info["data"]
	if int(data["counts"][category]) >= int(data["limits"][category]):
		event["error"] = "Достигнут лимит категории для редкости"
		return
	var candidate = event.get("candidate", {})
	if candidate is Dictionary and str(candidate.get("kind", "")) == "magic_inventory":
		var slot := str(info["base"].get("slot", ""))
		if slot not in ["ring", "amulet", "cloak"] or slot not in candidate.get("allowed_slots", []):
			event["error"] = "Магический инвентарь несовместим со слотом предмета"
			return
		var penalty = candidate.get("slot_penalty", null)
		if not penalty is Dictionary or not penalty.get("amount", null) is int:
			event["error"] = "Не указан штраф к лимиту"
			return
		var penalty_category := str(penalty.get("category", ""))
		var amount: int = penalty["amount"]
		if not ((penalty_category == "suffix" and amount in [1, 2]) or (penalty_category == "prefix" and amount == 2)):
			event["error"] = "Неизвестный штраф к лимиту"
			return
		if int(data["counts"][penalty_category]) > maxi(0, int(data["limits"][penalty_category]) - amount):
			event["error"] = "Штраф уменьшит лимит ниже числа существующих модов"
			return
	event["allowed"] = true

func _affix_eligible(event: Dictionary) -> void:
	var info := _item_info(event.get("item", &""))
	event["eligible"] = info["ok"] and int(info["data"]["rank"]) >= 1

func _validate(event: Dictionary) -> void:
	var info := _item_info(event.get("item", &""))
	event["found"] = info["ok"]
	if not info["ok"]:
		return
	var data: Dictionary = info["data"]
	var errors: Array = []
	for category in ["prefix", "suffix", "affix"]:
		if data["counts"][category] > data["limits"][category]:
			errors.append("Превышен лимит %s" % category)
	# Количества редкости — максимумы: нехватка подходящих модов допустима.
	event["errors"] = errors
	event["complete"] = errors.is_empty()

func _item_info(item_id: StringName) -> Dictionary:
	var query := {"item": item_id, "found": false}
	EventBus.publish(&"ItemGetRequested", query)
	if not query["found"]:
		return {"ok": false}
	var item: Dictionary = query["item_data"]
	var rarity := StringName(str(item.get("rarity", "")))
	if not _rarities.has(rarity):
		return {"ok": false}
	var rule: Dictionary = _rarities[rarity]
	var limits := {"prefix": int(rule["prefix_max"]), "suffix": int(rule["suffix_max"]), "affix": int(rule["affix_max"])}
	if rule.get("extras", "none") == "both":
		limits["prefix"] += 1
		limits["suffix"] += 1
	elif rule.get("extras", "none") == "random_one":
		var category := str(item.get("rarity_extra_category", ""))
		if category not in ["prefix", "suffix"]:
			return {"ok": false}
		limits[category] += 1
	var counts := {"prefix": 0, "suffix": 0, "affix": 0}
	for mod in item.get("mods", []):
		var category := str(mod.get("category", ""))
		if counts.has(category):
			counts[category] += 1
		if str(mod.get("kind", "")) == "magic_inventory":
			var penalty: Dictionary = mod.get("slot_penalty", {})
			var penalty_category := str(penalty.get("category", ""))
			if penalty_category in ["prefix", "suffix"]:
				limits[penalty_category] = maxi(0, int(limits[penalty_category]) - int(penalty.get("amount", 0)))
	return {"ok": true, "item": item, "base": query["base"], "data": {"rarity": rarity, "rank": int(rule["rank"]), "limits": limits, "counts": counts, "affix_min": int(rule["affix_min"]), "set_id": item.get("set_id", null), "set_policy": rule["set_policy"], "key_set_item": rarity == &"artifact" and item.get("set_id", null) != null, "extra_category": item.get("rarity_extra_category", null)}}
