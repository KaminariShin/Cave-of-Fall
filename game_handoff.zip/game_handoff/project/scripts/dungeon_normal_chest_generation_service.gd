extends Node
## Явная синхронная сборка: один бросок, случайное место, заполненный сундук.
## Автоматическое подключение к генератору комнат пока отсутствует.
var _states: Dictionary = {}
var _busy := false

func _ready() -> void:
	EventBus.subscribe(&"DungeonNormalChestGenerateRequested",_generate)
	EventBus.subscribe(&"DungeonNormalChestGenerationGetRequested",_get_state)
	EventBus.subscribe(&"SpaceMapConfigured",_reset)
	EventBus.subscribe(&"RoomRemoved",_room_removed)
	EventBus.subscribe(&"ObjectRemoved",_object_removed)
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
	EventBus.subscribe(&"SnapshotApplyRequested",_apply)
	EventBus.subscribe(&"NormalChestGenerationSnapshotValidateRequested",_validate)

func _reset(_e: Dictionary) -> void: _states.clear()
func _room_removed(e: Dictionary) -> void: _states.erase(e.get("room",null))
func _object_removed(e: Dictionary) -> void:
	var id=e.get("object",e.get("entity",null))
	for room in _states.keys():
		if _states[room].get("object",null)==id:_states.erase(room)
func _get_state(e: Dictionary) -> void:
	var room=e.get("room",null)
	e["found"]=_states.has(room)
	if e["found"]:e["data"]=_states[room].duplicate(true)
	else:e.erase("data")
func _generate(e: Dictionary) -> void:
	e["accepted"]=false;e["rolled_back"]=false
	for key in ["status","object","tile","items","interaction_anchor","error","existing","fatal"]:e.erase(key)
	var room=e.get("room",null)
	if _busy or not room is StringName or room==&"":
		e["error"]="Нужна доступная комната";return
	if _states.has(room):
		e["accepted"]=true;e["existing"]=true;e.merge(_states[room].duplicate(true),true);return
	_busy=true
	var work: Dictionary={"error":"","result":{}}
	var tx: Dictionary=SaveService.run_world_transition_transaction(func():return _execute(room,work))
	_busy=false
	e["accepted"]=tx.get("committed",false)
	e["rolled_back"]=tx.get("rolled_back",false)
	if tx.get("fatal",false):e["fatal"]=true
	if not e["accepted"]:
		e["error"]=work["error"] if not work["error"].is_empty() else tx.get("error","Не удалось сгенерировать сундук")
		return
	e["existing"]=false;e.merge(work["result"].duplicate(true),true)
	EventBus.publish(&"DungeonNormalChestGenerated",{"room":room,"data":work["result"].duplicate(true)})

func _fail(work: Dictionary,message: String) -> bool:
	work["error"]=message;return false
func _execute(room: StringName,work: Dictionary) -> bool:
	var roll: Dictionary={"room":room}
	EventBus.publish(&"DungeonNormalChestRollRequested",roll)
	if not roll.get("accepted",false):return _fail(work,str(roll.get("error","Ошибка выбора")))
	if not roll["selected"]:
		_states[room]={"status":"not_selected"}
		work["result"]=_states[room].duplicate(true);return true
	var rq: Dictionary={"id":room}
	EventBus.publish(&"RoomGetRequested",rq)
	if not rq.get("found",false):return _fail(work,"Комната не найдена")
	var origin: Vector2i=rq["data"]["origin_cell"]*4
	var size: Vector2i=rq["data"]["size_cells"]*4
	if size.x<1 or size.y<1 or size.x*size.y>16384:return _fail(work,"Размер комнаты не поддерживается")
	var candidates: Array=[]
	for y in range(size.y):
		for x in range(size.x):
			var tile:=origin+Vector2i(x,y)
			if DungeonChestSearchService._wall_floor(tile):candidates.append(tile)
	# Случайная перестановка без возврата; первый допустимый кандидат
	# равновероятен среди всех допустимых при неизменной геометрии.
	while not candidates.is_empty():
		var pick: Dictionary={"min":0,"max":candidates.size()-1}
		EventBus.publish(&"RngIntRequested",pick)
		var index=pick.get("value",null)
		if not pick.get("accepted",false) or not index is int or index<0 or index>=candidates.size():return _fail(work,"Ошибка выбора позиции")
		var tile: Vector2i=candidates[index]
		candidates[index]=candidates.back();candidates.pop_back()
		var check: Dictionary={"room":room,"tile":tile}
		EventBus.publish(&"DungeonChestPositionPreflightRequested",check)
		if not check.get("accepted",false):continue
		var object:=_free_id(room)
		if object==&"":return _fail(work,"Не удалось подобрать ID сундука")
		var made: Dictionary=DungeonNormalChestProvisionService.provision_for_transition(room,tile,object)
		if not made.get("accepted",false):return _fail(work,str(made.get("error","Ошибка создания")))
		_states[room]={"status":"created","object":object,"tile":tile}
		work["result"]=_states[room].duplicate(true)
		work["result"]["items"]=made["items"].duplicate()
		work["result"]["interaction_anchor"]=made["interaction_anchor"]
		return true
	_states[room]={"status":"no_position"}
	work["result"]=_states[room].duplicate(true);return true
func _free_id(room: StringName) -> StringName:
	for i in range(10000):
		var id:=StringName("normal_chest:%s:%d" % [str(room).uri_encode(),i])
		var q: Dictionary={"entity":id}
		EventBus.publish(&"EntityGetRequested",q)
		if not q.get("found",false):return id
	return &""
func _collect(e: Dictionary) -> void:e["sections"]["normal_chest_generation"]=_states.duplicate(true)
func _apply(e: Dictionary) -> void:_states=e["sections"]["normal_chest_generation"].duplicate(true)
func _validate(e: Dictionary) -> void:
	e["valid"]=false
	var s=e.get("sections",null)
	if not s is Dictionary or not s.get("normal_chest_generation",null) is Dictionary or not s.get("normal_chest_rolls",null) is Dictionary or not s.get("objects",{}).get("objects",null) is Dictionary:return
	var rolls: Dictionary=s["normal_chest_rolls"]
	var objects: Dictionary=s["objects"]["objects"]
	for room in s["normal_chest_generation"]:
		var row=s["normal_chest_generation"][room]
		if not room is StringName or not row is Dictionary or not rolls.has(room):return
		match row.get("status",null):
			"not_selected":
				if row.size()!=1 or rolls[room]==1:return
			"no_position":
				if row.size()!=1 or rolls[room]!=1:return
			"created":
				var id=row.get("object",null)
				if row.size()!=3 or rolls[room]!=1 or not id is StringName or not row.get("tile",null) is Vector2i or not objects.get(id,null) is Dictionary:return
				var obj: Dictionary=objects[id]
				if obj.get("room",null)!=room or obj.get("type","")!="chest" or obj.get("tile",null)!=row["tile"] or not obj.get("interaction",{}).get("normal_chest",false) or not obj.get("content_fixed",false):return
			_:return
	e["valid"]=true
