extends Node
## Просмотр конкретных материалов экипировки из черновой таблицы сундуков.
## Не создаёт предмет и не меняет сохранённый план.
var _families: Dictionary = {}
var _busy := false

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules.get("found", false):
		var families = rules["ruleset"].get("parameters", {}).get("chest_draft_material_families", null)
		if families is Dictionary: _families = families.duplicate(true)
	EventBus.subscribe(&"DungeonChestEquipmentMaterialsPreviewRequested", _preview)

func _preview(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["materials", "material_level", "error"]: e.erase(key)
	var base = e.get("base_id", null)
	var level = e.get("item_level", null)
	if _busy or not base is StringName or base == &"" or not level is int or level < 1 or level > 1000000:
		e["error"] = "Нужны ID базы и целый item_level"; return
	_busy = true
	var snapshot: Dictionary = SaveService.collect_world_transition_snapshot()
	if not snapshot.get("valid", false):
		_busy = false
		e["error"] = "Невозможно проверить состояние"; return
	var items: Dictionary = snapshot["payload"]["sections"]["items"]
	var bases: Dictionary = items["bases"]
	var materials: Dictionary = items["materials"]
	var result := _resolve(base, level, bases, materials)
	_busy = false
	if result.is_empty():
		e["error"] = "Нет подходящего чернового рецепта или материала"; return
	e["accepted"] = true
	e["materials"] = result
	e["material_level"] = 1 if level <= 2 else (3 if level <= 4 else 5)

func _resolve(base: StringName, level: int, bases: Dictionary, materials: Dictionary) -> Array:
	if not bases.has(base) or not bases[base] is Dictionary or str(bases[base].get("slot", "")) not in ["weapon", "shield", "body"]: return []
	var recipe = bases[base].get("materials", null)
	if not recipe is Array or recipe.is_empty(): return []
	var tier_index := 0 if level <= 2 else (1 if level <= 4 else 2)
	var material_level: int = [1,3,5][tier_index]
	var out: Array = []
	var seen := {}
	for stack in recipe:
		if not stack is Dictionary: return []
		var source := str(stack.get("material_id", ""))
		var count = stack.get("count", null)
		if source.is_empty() or seen.has(source) or not count is int or count <= 0 or count > 1000000: return []
		seen[source] = true
		var variants = _families.get(source, null)
		if not variants is Array or variants.size() != 3: return []
		var id = variants[tier_index]
		if not id is String or id.is_empty(): return []
		var key := StringName(id)
		if not materials.has(key) or not materials[key] is Dictionary or materials[key].get("level", null) != material_level: return []
		out.append({"material_id":id, "count":count})
	return out

# У расходников упаковка определяется базовым рецептом, а не семействами брони.
func resolve_consumable(base: StringName, bases: Dictionary, materials: Dictionary) -> Array:
	if not bases.has(base) or not bases[base] is Dictionary or str(bases[base].get("slot", "")) != "consumable": return []
	var recipe = bases[base].get("materials", null)
	if not recipe is Array or recipe.is_empty(): return []
	var seen := {}
	var result: Array = []
	for stack in recipe:
		if not stack is Dictionary: return []
		var raw = stack.get("material_id", null)
		var count = stack.get("count", null)
		if not (raw is String or raw is StringName) or str(raw).is_empty() or not count is int or count <= 0 or count > 1000000: return []
		var id := StringName(str(raw))
		if seen.has(id) or not materials.has(id) or not materials[id] is Dictionary: return []
		seen[id] = true
		result.append({"material_id":str(id), "count":count})
	return result
