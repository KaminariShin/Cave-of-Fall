extends Control

var service: Node
var list: ItemList
var output: TextEdit
var status: Label
var all_button: Button
var selected_button: Button
var stop_button: Button
var refresh_button: Button
var progress: ProgressBar
var open_button: Button
var last_dir := ""
var names: Array[String] = []
var results := {}

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	service = preload("res://scripts/test_runner_service.gd").new()
	add_child(service)
	service.run_started.connect(_run_started)
	service.test_started.connect(_test_started)
	service.test_finished.connect(_test_finished)
	service.run_finished.connect(_run_finished)
	_build_ui()
	_refresh()

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = Color("101827")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]: margin.add_theme_constant_override(side, 16)
	add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 9)
	margin.add_child(column)
	var title := Label.new()
	title.text = "Тесты проекта"
	title.add_theme_font_size_override("font_size", 23)
	column.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "Полный прогон или один выбранный тест • отдельный процесс и изолированные сохранения"
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(subtitle)
	var controls := HBoxContainer.new()
	controls.add_theme_constant_override("separation", 8)
	column.add_child(controls)
	all_button = _button(controls, "Запустить все", _run_all)
	selected_button = _button(controls, "Запустить выбранный", _run_selected)
	stop_button = _button(controls, "Остановить", _stop)
	refresh_button = _button(controls, "Обновить список", _refresh)
	stop_button.disabled = true
	status = Label.new()
	status.text = "Готово"
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(status)
	progress = ProgressBar.new()
	progress.show_percentage = true
	progress.min_value = 0
	progress.max_value = 1
	progress.value = 0
	column.add_child(progress)
	var body := HSplitContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.split_offset = 275
	column.add_child(body)
	list = ItemList.new()
	list.custom_minimum_size = Vector2(230, 160)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.item_selected.connect(_selected)
	body.add_child(list)
	output = TextEdit.new()
	output.editable = false
	output.selecting_enabled = true
	output.custom_minimum_size = Vector2(250,160)
	output.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	output.placeholder_text = "Выберите тест, чтобы просмотреть результат и журнал."
	body.add_child(output)
	var footer := HBoxContainer.new()
	column.add_child(footer)
	var help := Label.new()
	help.text = "Инструкция: TESTING.md • Таймаут: 120 с"
	help.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(help)
	open_button = _button(footer, "Открыть отчёт", _open_report)
	open_button.disabled = true

func _button(parent: Node, text: String, callback: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.pressed.connect(callback)
	parent.add_child(button)
	return button
func _refresh() -> void:
	if service.is_running(): return
	names = service.discover_tests()
	results.clear()
	list.clear()
	for name in names: list.add_item(name.trim_suffix(".gd"))
	if not names.is_empty(): list.select(0)
	status.text = "Найдено тестов: %d" % names.size()
	output.text = "Выберите тест и нажмите «Запустить выбранный» или запустите все тесты по очереди."
func _run_all() -> void:
	_start_result(service.start_all())
func _run_selected() -> void:
	var selection := list.get_selected_items()
	if selection.is_empty():
		status.text = "Сначала выберите тест."
		return
	_start_result(service.start_one(names[selection[0]]))
func _start_result(result: Dictionary) -> void:
	if not result.get("accepted", false): status.text = "Не удалось начать: " + str(result.get("error", ""))
func _stop() -> void:
	status.text = "Остановка…"
	service.cancel()
func _open_report() -> void:
	if not last_dir.is_empty():
		var err := OS.shell_open(last_dir)
		if err != OK: status.text = "Не удалось открыть каталог: " + last_dir
func _run_started(total: int, _dir: String) -> void:
	results.clear()
	for i in range(names.size()): list.set_item_text(i, names[i].trim_suffix(".gd"))
	all_button.disabled = true
	selected_button.disabled = true
	refresh_button.disabled = true
	stop_button.disabled = false
	progress.max_value = total
	progress.value = 0
	output.text = "Подготовка изолированного прогона…"
func _test_started(index: int, total: int, name: String) -> void:
	status.text = "Выполняется %d / %d: %s" % [index, total, name]
func _test_finished(result: Dictionary) -> void:
	results[result["name"]] = result
	var i := names.find(result["name"])
	if i >= 0: list.set_item_text(i, "%s  ·  %s" % [result["name"].trim_suffix(".gd"), result["status"]])
	progress.value += 1
	output.text = _format_result(result)
func _run_finished(summary: Dictionary) -> void:
	all_button.disabled = false
	selected_button.disabled = false
	refresh_button.disabled = false
	stop_button.disabled = true
	last_dir = summary["run_dir"]
	open_button.disabled = false
	status.text = "%s: %d/%d успешно, ошибок: %d. Отчёт: %s" % ["Остановлено" if summary["cancelled"] else "Завершено", summary["passed"], summary["total"], summary["failed"], summary["run_dir"]]
func _selected(index: int) -> void:
	if index < 0 or index >= names.size(): return
	output.text = _format_result(results[names[index]]) if results.has(names[index]) else "Результата для этого теста пока нет."
func _format_result(result: Dictionary) -> String:
	return "%s — %s\n%s\nВремя: %.2f с; код: %d\nЛог: %s\n\n%s" % [result["name"], result["status"], result["reason"], result["elapsed_ms"] / 1000.0, result["exit_code"], result["log_path"], result["log"]]
