extends Node
## Низкоуровневая пространственная модель, без продвижения игрового времени.
var _batch_busy := false
var _obstacle_busy := false
var _cell_size := 4
var _pixels_per_tile := 14
var _allowed_sizes: Array = [2, 4, 6]
var _size := Vector2i.ZERO
var _floor: Dictionary = {}      # Vector2i -> true; вне этого словаря скала
var _obstacles: Dictionary = {} # tile -> object entity
var _passages: Dictionary = {}   # Vector2i -> true
var _bodies: Dictionary = {}     # entity -> {anchor, size, room}
var _occupants: Dictionary = {}  # Vector2i -> entity

func _ready() -> void:
	var config := {"found": false}
	EventBus.publish(&"RulesetGetRequested", config)
	if config["found"]:
		var params: Dictionary = config["ruleset"].get("parameters", {}).get("space", {})
		_cell_size = int(params.get("tiles_per_cell", 4))
		_pixels_per_tile = int(params.get("pixels_per_tile", 14))
		_allowed_sizes.clear()
		for body_size in params.get("body_sizes", [2, 4, 6]):
			_allowed_sizes.append(int(body_size))
	EventBus.subscribe(&"SpaceMapConfigureRequested", _configure)
	EventBus.subscribe(&"SpaceMapGetRequested", _get_map)
	EventBus.subscribe(&"SpaceRegionGetRequested", _get_region)
	EventBus.subscribe(&"SpaceTilesSetRequested", _set_tiles)
	EventBus.subscribe(&"SpaceTileGetRequested", _get_tile)
	EventBus.subscribe(&"SpaceLineOfSightRequested", _line_of_sight)
	EventBus.subscribe(&"SpacePassageSetRequested", _set_passage)
	EventBus.subscribe(&"SpaceObstaclePlaceRequested", _obstacle_place)
	EventBus.subscribe(&"SpaceObstacleRemoveRequested", _obstacle_remove)
	EventBus.subscribe(&"SpaceObstaclesGetRequested", _obstacles_get)
	EventBus.subscribe(&"SpaceCellToTileRequested", _cell_to_tile)
	EventBus.subscribe(&"SpaceTileToCellRequested", _tile_to_cell)
	EventBus.subscribe(&"SpaceTileToCanvasRequested", _tile_to_canvas)
	EventBus.subscribe(&"SpaceCanvasToTileRequested", _canvas_to_tile)
	EventBus.subscribe(&"SpaceBodyFitsRequested", _body_fits_requested)
	EventBus.subscribe(&"SpaceBodyGroupFitsRequested", _group_fits_requested)
	EventBus.subscribe(&"SpaceBodiesRelocateRequested", _relocate_group)
	EventBus.subscribe(&"SpaceBodyPlaceRequested", _place)
	EventBus.subscribe(&"SpaceBodyMoveRequested", _move)
	EventBus.subscribe(&"SpaceBodyRemoveRequested", _remove)
	EventBus.subscribe(&"SpaceBodyGetRequested", _get_body)
	EventBus.subscribe(&"SpaceBodiesGetRequested", _get_bodies)
	EventBus.subscribe(&"SpaceBodyRoomSetRequested", _set_room)
	EventBus.subscribe(&"EntityRemoved", _entity_removed)
	EventBus.subscribe(&"LootEntityRemovalCheckRequested", _batch_removal_check)
	EventBus.subscribe(&"CombatDamageAllowedRequested", _batch_removal_check)
	EventBus.subscribe(&"SnapshotCollectRequested", _snapshot_collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _snapshot_apply)

## Новую карту нельзя создать поверх размещённых тел.
func _configure(event: Dictionary) -> void:
	event["accepted"] = false
	if _batch_busy or _obstacle_busy: return
	var size = event.get("size", null)
	if not size is Vector2i or size.x <= 0 or size.y <= 0 or not _bodies.is_empty() or not _obstacles.is_empty():
		return
	var loot_check := {"allowed": true}
	EventBus.publish(&"LootMapReconfigureCheckRequested", loot_check)
	if not loot_check["allowed"]: return
	var spawn_check := {"allowed": true}
	EventBus.publish(&"SpawnMapReconfigureCheckRequested", spawn_check)
	if not spawn_check["allowed"]: return
	_size = size
	_floor.clear()
	_passages.clear()
	_occupants.clear()
	event["accepted"] = true
	EventBus.publish(&"SpaceMapConfigured", {"size": size})

func _get_map(event: Dictionary) -> void:
	event["configured"] = _size.x > 0 and _size.y > 0
	event["size"] = _size
	event["tiles_per_cell"] = _cell_size
	event["pixels_per_tile"] = _pixels_per_tile

## Все тайлы проверяются до записи. Замена пола под телом запрещена.
func _set_tiles(event: Dictionary) -> void:
	event["accepted"] = false
	if _batch_busy or _obstacle_busy: return
	var tiles = event.get("tiles", null)
	var kind = event.get("kind", null)
	if not tiles is Array or tiles.is_empty() or not kind is int or kind not in [0, 1]:
		return
	for tile in tiles:
		if not tile is Vector2i or not _in_bounds(tile) or (kind == 0 and (_occupants.has(tile) or _passages.has(tile) or _obstacles.has(tile))):
			return
	var loot_check := {"tiles": tiles, "kind": kind, "allowed": true}
	EventBus.publish(&"LootTerrainChangeCheckRequested", loot_check)
	if not loot_check["allowed"]: return
	for tile in tiles:
		if kind == 1:
			_floor[tile] = true
		else:
			_floor.erase(tile)
			_passages.erase(tile)
	event["accepted"] = true
	EventBus.publish(&"SpaceTilesChanged", {"tiles": tiles.duplicate(), "kind": kind})

func _get_tile(event: Dictionary) -> void:
	var tile = event.get("tile", null)
	event["in_bounds"] = tile is Vector2i and _in_bounds(tile)
	if event["in_bounds"]:
		event["kind"] = 1 if _floor.has(tile) else 0
		event["passage"] = _passages.has(tile)
		event["occupant"] = _occupants.get(tile, null)
		event["obstacle"] = _obstacles.get(tile, null)

## Проём — ровно четыре соседних коллинеарных напольных тайла.
## Геометрию и принадлежность комнат проверит будущий сервис комнат.
func _set_passage(event: Dictionary) -> void:
	event["accepted"] = false
	if _batch_busy or _obstacle_busy: return
	var tiles = event.get("tiles", null)
	var enabled = event.get("enabled", true)
	if not tiles is Array or tiles.size() != _cell_size or not enabled is bool:
		return
	var unique: Dictionary = {}
	for tile in tiles:
		if not tile is Vector2i or not _in_bounds(tile) or not _floor.has(tile) or unique.has(tile) or (enabled and _obstacles.has(tile)):
			return
		unique[tile] = true
	var first: Vector2i = tiles[0]
	var horizontal := true
	var vertical := true
	var min_x := first.x
	var max_x := first.x
	var min_y := first.y
	var max_y := first.y
	for tile in tiles:
		horizontal = horizontal and tile.y == first.y
		vertical = vertical and tile.x == first.x
		min_x = mini(min_x, tile.x)
		max_x = maxi(max_x, tile.x)
		min_y = mini(min_y, tile.y)
		max_y = maxi(max_y, tile.y)
	if not ((horizontal and max_x - min_x == _cell_size - 1) or (vertical and max_y - min_y == _cell_size - 1)):
		return
	for tile in tiles:
		if enabled:
			_passages[tile] = true
		else:
			_passages.erase(tile)
	event["accepted"] = true
	EventBus.publish(&"SpacePassageChanged", {"tiles": tiles.duplicate(), "enabled": enabled})

func _obstacle_place(event: Dictionary) -> void:
	event["accepted"] = false
	var entity = event.get("entity", null)
	var tile = event.get("tile", null)
	if _batch_busy or _obstacle_busy or not entity is StringName or entity == &"" or not tile is Vector2i or not _floor.has(tile) or _passages.has(tile) or _occupants.has(tile) or _obstacles.has(tile): return
	_obstacle_busy = true
	var permit := {"entity":entity, "allowed":true}
	EventBus.publish(&"ObjectObstacleMutationCheckRequested", permit)
	var owner := {"entity":entity, "found":false}
	EventBus.publish(&"EntityGetRequested", owner)
	var valid: bool = permit["allowed"] and owner["found"] and _floor.has(tile) and not _passages.has(tile) and not _occupants.has(tile) and not _obstacles.has(tile)
	for existing in _obstacles.values():
		if existing == entity: valid = false
	if not valid:
		_obstacle_busy = false
		return
	_obstacles[tile] = entity
	event["accepted"] = true
	EventBus.publish(&"SpaceObstaclePlaced", {"entity":entity, "tile":tile})
	_obstacle_busy = false

func _obstacle_remove(event: Dictionary) -> void:
	event["accepted"] = false
	if _batch_busy or _obstacle_busy: return
	var entity: StringName = event.get("entity", &"")
	var permit := {"entity":entity, "allowed":true}
	EventBus.publish(&"ObjectObstacleMutationCheckRequested", permit)
	if not permit["allowed"]: return
	for tile in _obstacles.keys():
		if _obstacles[tile] == entity:
			_obstacle_busy = true
			_obstacles.erase(tile)
			event["accepted"] = true
			EventBus.publish(&"SpaceObstacleRemoved", {"entity":entity, "tile":tile})
			_obstacle_busy = false
			return

func _obstacles_get(event: Dictionary) -> void:
	event["obstacles"] = _obstacles.duplicate()

func _cell_to_tile(event: Dictionary) -> void:
	var cell = event.get("cell", null)
	event["accepted"] = cell is Vector2i
	if event["accepted"]:
		event["tile"] = cell * _cell_size

func _tile_to_cell(event: Dictionary) -> void:
	var tile = event.get("tile", null)
	event["accepted"] = tile is Vector2i
	if event["accepted"]:
		event["cell"] = Vector2i(floori(float(tile.x) / _cell_size), floori(float(tile.y) / _cell_size))

func _tile_to_canvas(event: Dictionary) -> void:
	var tile = event.get("tile", null)
	event["accepted"] = tile is Vector2i
	if event["accepted"]:
		event["canvas"] = Vector2(tile) * _pixels_per_tile

func _canvas_to_tile(event: Dictionary) -> void:
	var point = event.get("canvas", null)
	event["accepted"] = point is Vector2 and is_finite(point.x) and is_finite(point.y)
	if event["accepted"]:
		event["tile"] = Vector2i(floori(point.x / _pixels_per_tile), floori(point.y / _pixels_per_tile))

func _body_fits_requested(event: Dictionary) -> void:
	var anchor = event.get("anchor", null)
	var size = event.get("size", null)
	var room = event.get("room", null)
	event["fits"] = anchor is Vector2i and size is int and size in _allowed_sizes and _valid_room(room) and _body_fits(anchor, size, event.get("ignore_entity", &""), room)

func _group_fits_requested(event: Dictionary) -> void:
	var anchor = event.get("anchor", null)
	var size = event.get("size", null)
	var room = event.get("room", null)
	var ignored = event.get("ignore_entities", null)
	event["fits"] = anchor is Vector2i and size is int and size in _allowed_sizes and _valid_room(room) and ignored is Array and _group_fits(anchor, size, room, ignored)

func _group_fits(anchor: Vector2i, size: int, room: Variant, ignored: Array) -> bool:
	if not _inside_room(anchor, size, room): return false
	for x in range(anchor.x, anchor.x + size):
		for y in range(anchor.y, anchor.y + size):
			var tile := Vector2i(x,y)
			if not _in_bounds(tile) or not _floor.has(tile) or _obstacles.has(tile): return false
			if _occupants.has(tile) and not ignored.has(_occupants[tile]): return false
	return true

## Все позиции проверяются до изменения занятости; обмен телами разрешён.
func _relocate_group(event: Dictionary) -> void:
	event["accepted"] = false
	var targets = event.get("targets", null)
	if _batch_busy or _obstacle_busy or not targets is Dictionary: return
	var ids: Array = targets.keys()
	var rects: Array = []
	var old: Dictionary = {}
	for id in ids:
		if not id is StringName or not _bodies.has(id) or not targets[id] is Vector2i: return
		var body: Dictionary = _bodies[id]
		var anchor: Vector2i = targets[id]
		if not _group_fits(anchor, body["size"], body["room"], ids): return
		var rect := Rect2i(anchor, Vector2i.ONE * body["size"])
		for other in rects:
			if rect.intersects(other): return
		rects.append(rect)
		old[id] = body["anchor"]
	_batch_busy = true
	for id in ids: _erase_occupancy(id, _bodies[id]["anchor"], _bodies[id]["size"])
	for id in ids:
		_bodies[id]["anchor"] = targets[id]
		_fill_occupancy(id, targets[id], _bodies[id]["size"])
	var ok := true
	for id in ids:
		if not _commit(id, targets[id], _bodies[id]["size"]):
			ok = false
			break
	if not ok:
		for id in ids: _erase_occupancy(id, targets[id], _bodies[id]["size"])
		for id in ids:
			_bodies[id]["anchor"] = old[id]
			_fill_occupancy(id, old[id], _bodies[id]["size"])
			_commit(id, old[id], _bodies[id]["size"])
	_batch_busy = false
	if not ok: return
	event["accepted"] = true
	for id in ids:
		if old[id] != targets[id]: EventBus.publish(&"EntityMoved", {"entity": id, "from": old[id], "to": targets[id], "reason": &"room_reposition"})

func _place(event: Dictionary) -> void:
	event["accepted"] = false
	if _batch_busy or _obstacle_busy: return
	var entity: StringName = event.get("entity", &"")
	var anchor = event.get("anchor", null)
	var size = event.get("size", null)
	var room = event.get("room", null)
	if entity == &"" or _bodies.has(entity) or not anchor is Vector2i or not size is int or size not in _allowed_sizes or not _valid_room(room):
		return
	var owner := {"entity": entity, "found": false}
	EventBus.publish(&"EntityGetRequested", owner)
	if not owner["found"] or not _body_fits(anchor, size, &"", room):
		return
	var body := {"anchor": anchor, "size": size, "room": room.duplicate(true) if room is Dictionary else null}
	_bodies[entity] = body
	_fill_occupancy(entity, anchor, size)
	if not _commit(entity, anchor, size):
		_erase_occupancy(entity, anchor, size)
		_bodies.erase(entity)
		return
	event["accepted"] = true
	EventBus.publish(&"SpaceBodyPlaced", {"entity": entity, "anchor": anchor, "size": size})

## Низкоуровневый перенос. Длительность/путь/покадровое перемещение — позже.
func _move(event: Dictionary) -> void:
	event["accepted"] = false
	if _batch_busy or _obstacle_busy: return
	var entity: StringName = event.get("entity", &"")
	var requested = event.get("anchor", null)
	if not _bodies.has(entity) or not requested is Vector2i:
		return
	var body: Dictionary = _bodies[entity]
	var old: Vector2i = body["anchor"]
	var size: int = body["size"]
	var target := _clamp_anchor(requested, size, body["room"])
	if not _body_fits(target, size, entity, body["room"]):
		return
	if target == old:
		event["accepted"] = true
		event["anchor"] = target
		return
	var old_passages := _covered_passages(old, size)
	_erase_occupancy(entity, old, size)
	_fill_occupancy(entity, target, size)
	body["anchor"] = target
	if not _commit(entity, target, size):
		_erase_occupancy(entity, target, size)
		_fill_occupancy(entity, old, size)
		body["anchor"] = old
		return
	event["accepted"] = true
	event["anchor"] = target
	EventBus.publish(&"EntityMoved", {"entity": entity, "from": old, "to": target})
	var entered: Array = []
	for tile in _covered_passages(target, size):
		if not old_passages.has(tile):
			entered.append(tile)
	if not entered.is_empty():
		EventBus.publish(&"SpacePassageEntered", {"entity": entity, "tiles": entered, "anchor": target})

func _remove(event: Dictionary) -> void:
	event["accepted"] = false
	if _batch_busy or _obstacle_busy: return
	var entity: StringName = event.get("entity", &"")
	if not _bodies.has(entity):
		return
	var body: Dictionary = _bodies[entity]
	_erase_occupancy(entity, body["anchor"], body["size"])
	_bodies.erase(entity)
	if not _commit(entity, null, body["size"]):
		_bodies[entity] = body
		_fill_occupancy(entity, body["anchor"], body["size"])
		return
	event["accepted"] = true
	EventBus.publish(&"SpaceBodyRemoved", {"entity": entity})

func _get_body(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	event["found"] = _bodies.has(entity)
	if event["found"]:
		var body: Dictionary = _bodies[entity]
		event["data"] = body.duplicate(true)
		event["data"]["center"] = Vector2(body["anchor"]) + Vector2.ONE * float(body["size"]) / 2.0

func _set_room(event: Dictionary) -> void:
	event["accepted"] = false
	if _batch_busy or _obstacle_busy: return
	var entity: StringName = event.get("entity", &"")
	var room = event.get("room", null)
	if not _bodies.has(entity) or not _valid_room(room):
		return
	var body: Dictionary = _bodies[entity]
	if not _inside_room(body["anchor"], body["size"], room):
		return
	body["room"] = room.duplicate(true) if room is Dictionary else null
	event["accepted"] = true

func _batch_removal_check(event: Dictionary) -> void:
	if _batch_busy: event["allowed"] = false

func _entity_removed(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	for tile in _obstacles.keys():
		if _obstacles[tile] == entity:
			_obstacles.erase(tile)
			EventBus.publish(&"SpaceObstacleRemoved", {"entity":entity, "tile":tile})
	if _bodies.has(entity):
		var body: Dictionary = _bodies[entity]
		_erase_occupancy(entity, body["anchor"], body["size"])
		_bodies.erase(entity)

func _commit(entity: StringName, anchor: Variant, size: int) -> bool:
	var existing := {"entity": entity, "component": &"position", "found": false}
	EventBus.publish(&"ComponentGetRequested", existing)
	var position: Dictionary = existing.get("data", {}) if existing["found"] else {}
	position["anchor"] = anchor
	if not position.has("direction"):
		position["direction"] = null
	var request := {"entity": entity, "position": position, "body_size": {"tiles": size}, "accepted": false}
	EventBus.publish(&"SpatialCommitRequested", request)
	return request["accepted"]

func _body_fits(anchor: Vector2i, size: int, ignore_entity: StringName, room: Variant) -> bool:
	if not _inside_room(anchor, size, room):
		return false
	for x in range(anchor.x, anchor.x + size):
		for y in range(anchor.y, anchor.y + size):
			var tile := Vector2i(x, y)
			if not _in_bounds(tile) or not _floor.has(tile) or _obstacles.has(tile):
				return false
			if _occupants.has(tile) and _occupants[tile] != ignore_entity:
				return false
	return true

func _valid_room(room: Variant) -> bool:
	if room == null:
		return true
	if not room is Dictionary or not room.get("origin", null) is Vector2i or not room.get("size", null) is Vector2i:
		return false
	var origin: Vector2i = room["origin"]
	var size: Vector2i = room["size"]
	return origin.x >= 0 and origin.y >= 0 and size.x > 0 and size.y > 0 and origin.x + size.x <= _size.x and origin.y + size.y <= _size.y

func _inside_room(anchor: Vector2i, size: int, room: Variant) -> bool:
	if room == null:
		return true
	var origin: Vector2i = room["origin"]
	var bounds: Vector2i = room["size"]
	return anchor.x >= origin.x and anchor.y >= origin.y and anchor.x + size <= origin.x + bounds.x and anchor.y + size <= origin.y + bounds.y

func _clamp_anchor(anchor: Vector2i, size: int, room: Variant) -> Vector2i:
	var origin := Vector2i.ZERO
	var bounds := _size
	if room is Dictionary:
		origin = room["origin"]
		bounds = room["size"]
	return Vector2i(clampi(anchor.x, origin.x, origin.x + bounds.x - size), clampi(anchor.y, origin.y, origin.y + bounds.y - size))

func _in_bounds(tile: Vector2i) -> bool:
	return tile.x >= 0 and tile.y >= 0 and tile.x < _size.x and tile.y < _size.y

func _fill_occupancy(entity: StringName, anchor: Vector2i, size: int) -> void:
	for x in range(anchor.x, anchor.x + size):
		for y in range(anchor.y, anchor.y + size):
			_occupants[Vector2i(x, y)] = entity

func _erase_occupancy(entity: StringName, anchor: Vector2i, size: int) -> void:
	for x in range(anchor.x, anchor.x + size):
		for y in range(anchor.y, anchor.y + size):
			var tile := Vector2i(x, y)
			if _occupants.get(tile, null) == entity:
				_occupants.erase(tile)

func _covered_passages(anchor: Vector2i, size: int) -> Array:
	var result: Array = []
	for x in range(anchor.x, anchor.x + size):
		for y in range(anchor.y, anchor.y + size):
			var tile := Vector2i(x, y)
			if _passages.has(tile):
				result.append(tile)
	return result

func _snapshot_collect(event: Dictionary) -> void:
	if _batch_busy or _obstacle_busy:
		event["errors"].append("Нельзя сохранять во время изменения пространства")
		return
	event["sections"]["space"] = {"size": _size, "floor": _floor.duplicate(), "passages": _passages.duplicate(), "bodies": _bodies.duplicate(true), "obstacles": _obstacles.duplicate()}

func _snapshot_apply(event: Dictionary) -> void:
	var data: Dictionary = event["sections"]["space"]
	_size = data["size"]
	_floor = data["floor"].duplicate()
	_passages = data["passages"].duplicate()
	_obstacles = data["obstacles"].duplicate()
	_bodies = data["bodies"].duplicate(true)
	_occupants.clear()
	for entity in _bodies:
		var body: Dictionary = _bodies[entity]
		_fill_occupancy(entity, body["anchor"], body["size"])

## Снимок прямоугольной области для BFS и будущих систем карты.
func _get_region(event: Dictionary) -> void:
	event["accepted"] = false
	var origin = event.get("origin", null)
	var size = event.get("size", null)
	if not origin is Vector2i or not size is Vector2i or origin.x < 0 or origin.y < 0 or size.x <= 0 or size.y <= 0 or origin.x + size.x > _size.x or origin.y + size.y > _size.y:
		return
	var floors: Dictionary = {}
	var passages: Dictionary = {}
	for x in range(origin.x, origin.x + size.x):
		for y in range(origin.y, origin.y + size.y):
			var tile := Vector2i(x, y)
			if _floor.has(tile):
				floors[tile] = true
			if _passages.has(tile):
				passages[tile] = true
	event["floor"] = floors
	event["passages"] = passages
	event["accepted"] = true

## Снимок размещённых тел для систем столкновения, без прямого доступа к владельцу.
func _get_bodies(event: Dictionary) -> void:
	event["bodies"] = _bodies.duplicate(true)

## Целочисленный Bresenham: оба конца и все выбранные тайлы должны быть полом.
func _line_of_sight(event: Dictionary) -> void:
	event["accepted"] = false
	event["visible"] = false
	var from = event.get("from", null)
	var to = event.get("to", null)
	if not from is Vector2i or not to is Vector2i or not _in_bounds(from) or not _in_bounds(to):
		return
	event["accepted"] = true
	var x: int = from.x
	var y: int = from.y
	var dx := absi(to.x - x)
	var dy := -absi(to.y - y)
	var sx := 1 if x < to.x else -1
	var sy := 1 if y < to.y else -1
	var error := dx + dy
	while true:
		if not _floor.has(Vector2i(x, y)):
			return
		if x == to.x and y == to.y:
			event["visible"] = true
			return
		var e2 := error * 2
		if e2 >= dy:
			error += dy
			x += sx
		if e2 <= dx:
			error += dx
			y += sy
