extends Node
## Отложенный покадровый поиск; работа поиска не сериализуется.
var _status := "none" # none, waiting, searching, failed, created
var _room: StringName = &""
var _object: StringName = &""
var _error := ""
var _cursor := 0
var _seen := 0
var _generation := 0
var _own_job := false
var _busy := false
# Повторяем только подтверждённую смену геометрии, ограниченно.
const WORLD_CHANGE_RETRIES := 3
var _world_change_retries := 0
var _quick_search := true

func _ready() -> void:
	set_process(false)
	EventBus.subscribe(&"RoomSpawned", _spawned)
	EventBus.subscribe(&"PlayerRoomChanged", _room_changed)
	EventBus.subscribe(&"DungeonBossChestProvisioned", _provisioned)
	EventBus.subscribe(&"DungeonBossChestAutoStatusRequested", _status_requested)
	EventBus.subscribe(&"DungeonBossChestAutoRetryRequested", _retry)
	EventBus.subscribe(&"SnapshotRestored", _restored)
	EventBus.subscribe(&"SpaceMapConfigured", _reset)

func _eligible_room(room: StringName) -> bool:
	var tracking := {"found":false}
	var boss := {"found":false}
	EventBus.publish(&"DungeonFloorTrackingGetRequested",tracking)
	EventBus.publish(&"DungeonBossGetRequested",boss)
	return room != &"" and tracking.get("found",false) and tracking["data"].get("floor",null) == 4 and tracking["data"].get("boss_candidate",null) == room and boss.get("found",false) and boss["data"].get("room",null) == room and boss["data"].get("status","") in ["alive","defeated"]

func _context(room: StringName) -> bool:
	var current := {}
	var mode := {}
	EventBus.publish(&"RoomCurrentGetRequested",current)
	EventBus.publish(&"GameModeGetRequested",mode)
	return _eligible_room(room) and current.get("room",null) == room and not current.get("transitioning",true) and current.get("entity",null) == mode.get("entity",null) and mode.get("entity",&"") != &"" and not CombatService.is_entity_dead(mode["entity"])

func _find_existing(room: StringName) -> Dictionary:
	var q := {"room":room, "objects":{}}
	EventBus.publish(&"RoomObjectsGetRequested",q)
	if not q.get("objects",null) is Dictionary: return {"error":"Реестр объектов недоступен"}
	var found: Array = []
	for id in q["objects"]:
		var obj = q["objects"][id]
		if obj is Dictionary and obj.get("type","") == "chest" and obj.get("interaction",{}).get("boss_chest",false) == true: found.append(id)
	if found.size() > 1: return {"error":"Найдено несколько сундуков босса"}
	if found.is_empty(): return {"found":false}
	var obj: Dictionary = q["objects"][found[0]]
	if not obj.get("content_fixed",false) or obj.has("content_draft"): return {"error":"Сундук босса не заполнен"}
	return {"found":true, "object":found[0]}

func _spawned(e: Dictionary) -> void:
	for unit in e.get("units",[]):
		if unit is Dictionary and unit.get("type_id","") == "final_ogre" and e.get("room",null) is StringName:
			_schedule(e["room"])
			return

func _room_changed(e: Dictionary) -> void:
	var room = e.get("room",null)
	if _status == "searching" and room != _room:
		_fail("Игрок покинул комнату во время поиска")
	if room is StringName and room != &"" and _status in ["none","failed"] and _eligible_room(room): _schedule(room)

func _schedule(room: StringName) -> void:
	if _busy or _status in ["waiting","searching"]: return
	_generation += 1
	_world_change_retries = 0
	_room = room
	_status = "waiting"
	_error = ""
	_cursor = 0
	_seen = 0
	call_deferred("_begin",_generation)

func _begin(generation: int) -> void:
	if generation != _generation or _status != "waiting" or _busy: return
	if not _context(_room):
		_fail("Игрок или комната босса недоступны")
		return
	var existing := _find_existing(_room)
	if existing.has("error"):
		_fail(str(existing["error"])); return
	if existing.get("found",false):
		_status = "created"
		_object = existing["object"]
		return
	_busy = true
	var q := {"room":_room,"accepted":false,"random_order":_quick_search}
	EventBus.publish(&"DungeonChestRandomPositionBeginRequested",q)
	_busy = false
	if generation != _generation: return
	if not q.get("accepted",false):
		_fail("Не удалось начать поиск: " + str(q.get("error","ошибка"))); return
	_own_job = true
	_status = "searching"
	set_process(true)

func _process(_delta: float) -> void:
	if _status != "searching" or _busy: return
	if not _context(_room):
		_fail("Игрок или комната босса изменились"); return
	_busy = true
	var generation := _generation
	var step := {"accepted":false}
	EventBus.publish(&"DungeonChestRandomPositionStepRequested",step)
	_busy = false
	if generation != _generation: return
	if not step.get("accepted",false):
		_own_job = false
		if step.get("world_changed",false) and _world_change_retries < WORLD_CHANGE_RETRIES and _context(_room):
			_world_change_retries += 1
			_status = "waiting"
			_cursor = 0; _seen = 0
			set_process(false)
			call_deferred("_begin",generation)
			return
		_fail("Поиск прерван: " + str(step.get("error","ошибка"))); return
	_cursor = int(step.get("cursor",0))
	_seen = int(step.get("candidates_seen",0))
	if step.get("status","") != "complete": return
	_own_job = false
	set_process(false)
	if not step.get("found",false):
		_fail("Безопасная позиция сундука не найдена"); return
	var chest_id := _free_object_id(_room)
	if chest_id == &"":
		_fail("Не удалось подобрать свободный ID сундука"); return
	_busy = true
	var create := {"room":_room,"candidate":step.get("tile",null),"chest_id":chest_id,"accepted":false}
	EventBus.publish(&"DungeonBossChestProvisionRequested",create)
	_busy = false
	if generation != _generation: return
	if not create.get("accepted",false):
		_fail("Создание сундука не выполнено: " + str(create.get("error","ошибка"))); return
	_status = "created"
	_object = chest_id
	_error = ""
	EventBus.publish(&"DungeonBossChestAutoCreated", {"room":_room,"object":_object,"tile":create["tile"],"items":create["items"].duplicate()})

func _free_object_id(room: StringName) -> StringName:
	var prefix := "boss_chest:" + str(room).uri_encode() + ":"
	for i in range(10000):
		var id := StringName(prefix + str(i))
		var entity := {"entity":id,"found":false}
		EventBus.publish(&"EntityGetRequested",entity)
		if not entity.get("found",false): return id
	return &""

func _fail(message: String) -> void:
	if _own_job:
		EventBus.publish(&"DungeonChestRandomPositionCancelRequested",{})
		_own_job = false
	set_process(false)
	_generation += 1
	_status = "failed"
	_error = message
	EventBus.publish(&"DungeonBossChestAutoFailed", {"room":_room,"error":message})

func _provisioned(e: Dictionary) -> void:
	if _busy or e.get("room",null) != _room: return
	if _own_job: EventBus.publish(&"DungeonChestRandomPositionCancelRequested",{})
	_own_job = false
	set_process(false)
	_generation += 1
	_status = "created"
	_object = e.get("object",&"")
	_error = ""

func _status_requested(e: Dictionary) -> void:
	e["status"] = _status
	e["room"] = _room if _room != &"" else null
	e["object"] = _object if _object != &"" else null
	e["error"] = _error
	e["cursor"] = _cursor
	e["candidates_seen"] = _seen

func _retry(e: Dictionary) -> void:
	e["accepted"] = false
	var room = e.get("room",null)
	if _busy or not room is StringName or room == &"" or _status in ["waiting","searching"] or not _context(room):
		e["error"] = "Повторный поиск недоступен"; return
	_schedule(room)
	e["accepted"] = _status == "waiting"

func _restored(_e: Dictionary) -> void:
	if _busy: return
	_reset({})
	var current := {}
	EventBus.publish(&"RoomCurrentGetRequested",current)
	var room = current.get("room",null)
	if room is StringName and room != &"" and _context(room): _schedule(room)

func _reset(_e: Dictionary) -> void:
	if _busy: return
	if _own_job: EventBus.publish(&"DungeonChestRandomPositionCancelRequested",{})
	_own_job = false
	_world_change_retries = 0
	_generation += 1
	_status = "none"
	_room = &""
	_object = &""
	_error = ""
	_cursor = 0
	_seen = 0
	set_process(false)
