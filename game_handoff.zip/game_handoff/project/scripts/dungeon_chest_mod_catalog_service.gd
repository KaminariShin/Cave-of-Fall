extends Node
## Чистый просмотр черновых кандидатов. Не регистрирует и не накладывает моды.
const LIVE_EFFECT_IDS := ["pre_armour","suf_perception","suf_wisdom","pre_vital","pre_strength","pre_agile","pre_mind","affix_hp","affix_stamina","affix_mana","suf_physical_damage"]
var _catalog: Array = []
var _busy := false

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules.get("found",false):
		var rows = rules["ruleset"].get("parameters",{}).get("chest_draft_mod_catalog",null)
		if _catalog_valid(rows):
			_catalog = rows.duplicate(true)
			for row in _catalog:
				row["weight"] = int(row["weight"])
				for tier in row["tiers"]:
					for key in ["tier", "level_req", "weight"]: tier[key] = int(tier[key])
	EventBus.subscribe(&"DungeonChestModCandidatesPreviewRequested", _preview)

func _catalog_valid(rows: Variant) -> bool:
	if not rows is Array or rows.is_empty(): return false
	var seen := {}
	for row in rows:
		if not row is Dictionary or not row.get("id",null) is String or row["id"].is_empty() or seen.has(row["id"]) or row.get("category",null) not in ["prefix","suffix","affix"] or not row.get("stat",null) is String or row["stat"].is_empty(): return false
		seen[row["id"]] = true
		if not _positive_int(row.get("weight",null)): return false
		for key in ["slots","base_ids","families"]:
			if not row.get(key,null) is Array: return false
		if row["slots"].is_empty() and row["base_ids"].is_empty(): return false
		if row["families"].is_empty(): return false
		for slot in row["slots"]:
			if slot not in ["body","shield","weapon","belt"]: return false
		for id in row["base_ids"]:
			if not id is String or id.is_empty(): return false
		for family in row["families"]:
			if family not in ["cloth","leather","metal"]: return false
		var tiers = row.get("tiers",null)
		if not tiers is Array or tiers.is_empty(): return false
		var tier_seen := {}
		for tier in tiers:
			if not tier is Dictionary or not _positive_int(tier.get("tier",null)) or tier_seen.has(tier["tier"]) or not _positive_int(tier.get("level_req",null)) or not _positive_int(tier.get("weight",null)) or not _number(tier.get("value",null)): return false
			tier_seen[tier["tier"]] = true
	return true

func _preview(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["candidates","error"]: e.erase(key)
	var base = e.get("base_id",null)
	var level = e.get("item_level",null)
	var material = e.get("material_id",null)
	var used = e.get("used_mod_ids",[])
	var category = e.get("category",null)
	if _busy or _catalog.is_empty() or not base is StringName or base == &"" or not level is int or level < 1 or level > 1000000 or not material is StringName or material == &"" or not used is Array or category not in ["prefix","suffix","affix"]:
		e["error"] = "Некорректные параметры или каталог"; return
	var excluded := {}
	for id in used:
		if not id is StringName or id == &"" or excluded.has(id):
			e["error"] = "Некорректные использованные ID"; return
		excluded[id] = true
	_busy = true
	var snapshot: Dictionary = SaveService.collect_world_transition_snapshot()
	if not snapshot.get("valid",false):
		_busy = false
		e["error"] = "Состояние недоступно"; return
	var items: Dictionary = snapshot["payload"]["sections"]["items"]
	var result := candidates_for_snapshot(base, level, material, category, excluded, items)
	_busy = false
	if not result.get("accepted", false):
		e["error"] = result.get("error", "Нет рецепта"); return
	e["accepted"] = true
	e["candidates"] = result["candidates"]

# Внутренний чистый расчёт по уже полученному снимку, без событий и ГСЧ.
func candidates_for_snapshot(base: StringName, level: int, material: StringName, category: String, excluded: Dictionary, items: Dictionary, playable_only: bool = false) -> Dictionary:
	if _catalog.is_empty(): return {"accepted":false, "error":"Каталог недоступен"}
	var recipe: Array = DungeonChestMaterialsService._resolve(base, level, items["bases"], items["materials"])
	var family := ""
	for stack in recipe:
		if StringName(stack["material_id"]) == material:
			for original in items["bases"][base]["materials"]:
				var variants = DungeonChestMaterialsService._families.get(str(original["material_id"]), [])
				if variants is Array and variants.has(str(material)):
					family = {"cloth_light":"cloth", "leather_thin":"leather", "iron_common":"metal"}.get(str(original["material_id"]), "")
	if family.is_empty():
		return {"accepted":false, "error":"Материал не входит в черновой рецепт"}
	var material_level: int = int(items["materials"][material]["level"])
	var slot := str(items["bases"][base]["slot"])
	var candidates: Array = []
	for row in _catalog:
		if playable_only and row["id"] not in LIVE_EFFECT_IDS: continue
		if row["category"] != category or excluded.has(StringName(row["id"])) or not row["families"].has(family) or (not row["slots"].has(slot) and not row["base_ids"].has(str(base))): continue
		var tiers: Array = []
		for tier in row["tiers"]:
			if tier["level_req"] <= level and tier["level_req"] <= material_level: tiers.append(tier.duplicate(true))
		if not tiers.is_empty(): candidates.append({"id":StringName(row["id"]), "category":row["category"], "stat":row["stat"], "weight":row["weight"], "tiers":tiers})
	return {"accepted":true, "candidates":candidates}

func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v))

func _positive_int(v: Variant) -> bool:
	return _number(v) and float(v) >= 1 and float(v) <= 1000000 and floorf(float(v)) == float(v)

# Только черновые ID: чужие механизмы модов не объявляются поддержанными.
func unsupported_live_effects(item: Dictionary) -> Array:
	var missing: Array = []
	if not item.has("learning") or not item.get("mods",null) is Array: return missing
	for mod in item["mods"]:
		if not mod is Dictionary: continue
		var id := str(mod.get("id",""))
		var draft_shape: bool = mod.has("material_id") and mod.has("tier") and mod.has("unlock_after")
		var known := false
		for row in _catalog:
			if row["id"] == id: known = true; break
		if not id.is_empty() and id not in LIVE_EFFECT_IDS and (known or draft_shape) and not missing.has(StringName(id)): missing.append(StringName(id))
	return missing
