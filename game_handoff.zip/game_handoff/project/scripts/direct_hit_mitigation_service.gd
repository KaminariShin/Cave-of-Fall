extends Node
## Чистый расчёт уже подготовленного прямого попадания до блока и HP.
const LIMIT := 1000000000.0
func _ready() -> void:
	EventBus.subscribe(&"DirectHitMitigationPreviewRequested", _preview)
func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v)) and absf(float(v)) <= LIMIT
func _preview(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("error"); e.erase("data")
	var physical = e.get("physical",null)
	var magical = e.get("magical",null)
	var physical_protection = e.get("physical_protection_percent",null)
	var magical_protection = e.get("magical_protection_percent",null)
	var weakening = e.get("weakening_multiplier",null)
	if not _number(physical) or float(physical) < 0 or not _number(magical) or float(magical) < 0 or not _number(physical_protection) or float(physical_protection) > 75.0 or not _number(magical_protection) or float(magical_protection) > 75.0 or not _number(weakening) or float(weakening) not in [0.25,0.5,0.75,1.0]:
		e["error"] = "Нужны части прямого урона, итоговые защиты не выше 75% и допустимая ступень ослабления"; return
	# Итоговая защита имеет точность 0,01 п.п.; используем целые сотые
	# процента, чтобы не создавать ложное ceil из вычисления (1 - 0.43).
	var p_units := roundi(float(physical_protection) * 100.0)
	var m_units := roundi(float(magical_protection) * 100.0)
	if absf(float(physical_protection) * 100.0 - p_units) > 0.000001 or absf(float(magical_protection) * 100.0 - m_units) > 0.000001:
		e["error"] = "Итоговая защита должна быть округлена до 0,01 процентного пункта"; return
	var p_after := float(physical) * float(10000 - p_units) / 10000.0
	var m_after := float(magical) * float(10000 - m_units) / 10000.0
	var p_weakened := p_after * float(weakening)
	var m_weakened := m_after * float(weakening)
	if not is_finite(p_weakened) or not is_finite(m_weakened) or p_weakened > LIMIT or m_weakened > LIMIT:
		e["error"] = "Урон превышает предел"; return
	var p_result := int(ceil(p_weakened))
	var m_result := int(ceil(m_weakened))
	if p_result + m_result > int(LIMIT): e["error"] = "Сумма урона превышает предел"; return
	e["data"] = {"physical_after_protection":p_after,"magical_after_protection":m_after,"physical_before_rounding":p_weakened,"magical_before_rounding":m_weakened,"physical":p_result,"magical":m_result,"total":p_result + m_result}
	e["accepted"] = true
