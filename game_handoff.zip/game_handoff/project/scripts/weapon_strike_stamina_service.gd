extends Node
## Только прогноз: не проверяет экипировку, не списывает ресурс и не начинает действие.
var _techniques: Dictionary = {}
func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested",rules)
	if rules.get("found",false):
		var values = rules["ruleset"].get("parameters",{}).get("weapon_strike_stamina",{}).get("techniques",null)
		if values is Dictionary: _techniques = values.duplicate(true)
	EventBus.subscribe(&"WeaponStrikeStaminaPreviewRequested",_preview)

func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v))

func _preview(e: Dictionary) -> void:
	e["accepted"] = false
	for k in ["data","error"]: e.erase(k)
	var actor = e.get("entity",null)
	var item = e.get("item",null)
	var strike_id = e.get("strike",null)
	if not actor is StringName or actor == &"" or not item is StringName or item == &"" or not (strike_id is StringName or strike_id is String) or str(strike_id).is_empty():
		e["error"] = "Нужны персонаж, экземпляр оружия и удар"; return
	var weapon := {"item":item,"found":false}
	var list := {"item":item,"found":false}
	EventBus.publish(&"WeaponItemResolveRequested",weapon)
	EventBus.publish(&"WeaponStrikesGetRequested",list)
	if not weapon.get("found",false) or not list.get("found",false): e["error"] = "Оружие недоступно"; return
	var w: Dictionary = weapon["data"]
	var base = w.get("base_stamina_cost",null)
	var tag = w.get("stamina_cost_percent",null)
	if not _number(base) or float(base) <= 0 or not w.get("stamina_cost_complete",false) or not _number(tag) or 1.0 + float(tag) <= 0:
		e["error"] = "Не заданы все параметры стоимости оружия"; return
	var strike: Dictionary = {}
	for row in list["strikes"]:
		if str(row.get("id","")) == str(strike_id): strike = row; break
	if strike.is_empty(): e["error"] = "Удар недоступен оружию"; return
	var technique := str(strike.get("technique",""))
	var factor = _techniques.get(technique,null)
	if not _number(factor) or float(factor) <= 0: e["error"] = "Не задана техника или её коэффициент"; return
	var weight := {"entity":actor,"found":false}
	EventBus.publish(&"WeightModifiersRequested",weight)
	var add = weight.get("modifiers",{}).get("stamina_cost_add",null)
	if not weight.get("found",false) or not _number(add) or 1.0 + float(add) <= 0: e["error"] = "Множитель веса недоступен"; return
	var raw: float = float(base) * float(factor) * (1.0 + float(tag)) * (1.0 + float(add))
	if not is_finite(raw) or raw <= 0 or raw > 1000000000: e["error"] = "Некорректная стоимость"; return
	var cost := int(ceil(raw))
	if cost < 1: e["error"] = "Некорректная округлённая стоимость"; return
	var stamina := {"entity":actor,"resource":&"Stamina","found":false}
	EventBus.publish(&"ResourceGetRequested",stamina)
	var current = stamina.get("data",{}).get("current",null)
	if not stamina.get("found",false) or not _number(current) or float(current) < 0: e["error"] = "Выносливость недоступна"; return
	var timing := {"entity":actor,"item":item,"kind":"physical","speed_effectiveness":strike.get("speed_effectiveness",null),"accepted":false}
	EventBus.publish(&"WeaponAttackTimingRequested",timing)
	if not timing.get("accepted",false): e["error"] = "Расчёт времени недоступен"; return
	var available := float(current)
	var can_start := available >= 1.0
	var ratio := available / float(cost)
	var damage_factor := 1.0
	var duration_factor := 1.0
	if ratio < 0.25: damage_factor = 0.25; duration_factor = 2.0
	elif ratio < 0.75: damage_factor = 0.5; duration_factor = 1.5
	elif ratio < 1.0: damage_factor = 0.75; duration_factor = 1.25
	var unrounded: float = float(timing["data"]["unrounded_duration"]) * duration_factor
	if not is_finite(unrounded) or unrounded <= 0 or unrounded > 10000000: e["error"] = "Некорректное время"; return
	e["data"] = {"full_cost":cost,"raw_cost":raw,"available":available,"can_start":can_start,"spend":minf(available,float(cost)) if can_start else 0.0,"damage_multiplier":damage_factor,"duration_multiplier":duration_factor,"duration":maxf(0.01,ceil(unrounded / 0.01 - 0.000000001) * 0.01),"technique":technique}
	e["accepted"] = true
