extends Node
## Чистое определение порога по отдельным итоговым попаданиям.
## Не запускает действие пошатывания и не читает мир.
const MAX_COUNT := 10000
const MAX_VALUE := 1000000000
func _ready() -> void:
	EventBus.subscribe(&"StaggerPlanRequested",_plan)
func _plan(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("error"); e.erase("data")
	var maxima = e.get("max_hp_by_target",null)
	var hits = e.get("hits",null)
	if not maxima is Dictionary or maxima.size() > MAX_COUNT or not hits is Array or hits.size() > MAX_COUNT:
		e["error"] = "Нужны максимумы HP и ограниченный список попаданий"; return
	for id in maxima:
		if not id is StringName or id == &"" or not maxima[id] is int or maxima[id] < 1 or maxima[id] > MAX_VALUE:
			e["error"] = "Некорректный максимум HP"; return
	var pairs := {}
	var groups := {}
	for hit in hits:
		if not hit is Dictionary: e["error"] = "Некорректное попадание"; return
		var source = hit.get("source",null)
		var target = hit.get("target",null)
		var damage = hit.get("damage",null)
		if not source is StringName or source == &"" or not target is StringName or target == &"" or not maxima.has(target) or not damage is int or damage < 0 or damage > MAX_VALUE:
			e["error"] = "Нужны источник, цель и целый итоговый урон"; return
		var hit_id = hit.get("hit_id",source)
		if not hit_id is StringName or hit_id == &"": e["error"] = "Некорректный ID попадания"; return
		if not pairs.has(target): pairs[target] = {}
		if pairs[target].has(hit_id): e["error"] = "Повторный ID попадания по цели"; return
		pairs[target][hit_id] = true
		if not groups.has(target): groups[target] = []
		if damage * 4 >= maxima[target] and not groups[target].has(source): groups[target].append(source)
	var targets: Array = groups.keys()
	targets.sort_custom(func(a,b): return str(a) < str(b))
	var rows: Array = []
	for target in targets:
		var qualifying: Array = groups[target]
		qualifying.sort_custom(func(a,b): return str(a) < str(b))
		rows.append({"target":target,"max_hp":maxima[target],"triggered":not qualifying.is_empty(),"sources":qualifying})
	e["data"] = {"targets":rows,"duration":0.2}
	e["accepted"] = true
