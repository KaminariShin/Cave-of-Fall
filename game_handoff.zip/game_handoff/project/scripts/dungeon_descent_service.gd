extends Node
## Параметризованный внутренний игровой протокол спуска; демо к нему не подключено.
const ACTION := &"stairs_descend"
var _pending: Dictionary = {}
var _starting := false
var _start_gate_used := false
var _finishing := false
var _next_deadend_budget: Variant = null

func _ready() -> void:
	var rules := {"found":false}
	EventBus.publish(&"RulesetGetRequested", rules)
	if rules.get("found", false):
		var budget = rules["ruleset"].get("parameters", {}).get("dungeon", {}).get("next_floor_deadend_budget", null)
		if (budget is int or budget is float) and is_finite(float(budget)) and float(budget) >= 1 and float(budget) <= 1000000 and floorf(float(budget)) == float(budget): _next_deadend_budget = int(budget)
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION, "name":"Спуск по лестнице", "type":&"utility", "base_duration":0.1, "interruptible":false}})
	EventBus.subscribe(&"DungeonDescendRequested", _start)
	EventBus.subscribe(&"DungeonDescentPlanRequested", _plan)
	EventBus.subscribe(&"DungeonDescentAutoRequested", _auto)
	EventBus.subscribe(&"ActionStartAllowedRequested", _action_guard)
	EventBus.subscribe(&"ActionCompleted", _completed)
	EventBus.subscribe(&"ActionInterrupted", _interrupted)
	EventBus.subscribe(&"ObjectRemoved", _object_removed)
	EventBus.subscribe(&"SpaceBodyRemoved", _body_removed)
	EventBus.subscribe(&"EntityMoved", _entity_moved)
	EventBus.subscribe(&"TimeStepSettled", _settled)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"DungeonDescentSnapshotValidateRequested", _validate)

# Детерминированный черновой выбор без расходования глобального RNG.
# Он не обещает, что генератор действительно породит подходящую лестницу.
func _plan(e: Dictionary) -> void:
	e["accepted"] = false
	var actor = e.get("entity", null)
	if _starting or _finishing or not _pending.is_empty() or not actor is StringName or actor == &"" or not _next_deadend_budget is int or _next_deadend_budget < 1: return _error(e, "План спуска недоступен")
	var snap: Dictionary = SaveService.collect_world_transition_snapshot()
	if not snap.get("valid", false): return _error(e, "Нельзя подготовить снимок мира")
	var sections: Dictionary = snap["payload"]["sections"]
	var stats: Dictionary = sections["run_statistics"]
	var level: Dictionary = sections["level"]
	var tracking: Dictionary = sections["dungeon_tracking"]
	if stats.is_empty() or stats.get("finished", true) or stats.get("entity", null) != actor or sections["actions"].get("controlled", null) != actor or not level.get("active", false) or not stats.get("floor", null) is int or stats["floor"] < 1 or stats["floor"] >= 4 or tracking.get("floor", null) != stats["floor"] or tracking.get("root", null) != stats.get("root", null): return _error(e, "Мир не готов к планированию спуска")
	var next_floor: int = stats["floor"] + 1
	var next_seed: int = int(("next_floor:%s:%d:%d" % [str(level["level_id"]), level["seed"], next_floor]).hash())
	var next_id := StringName("floor_%d_%08x" % [next_floor, next_seed])
	if next_id == level["level_id"]: next_id = StringName(str(next_id) + "_next")
	e["accepted"] = true
	e["floor"] = next_floor
	e["parameters"] = {"entity":actor, "level_id":next_id, "seed":next_seed, "size_cells":level["size_cells"], "deadend_budget":_next_deadend_budget}

func _auto(e: Dictionary) -> void:
	e["accepted"] = false
	var stair_id = e.get("object", null)
	var stair := {"found":false}
	EventBus.publish(&"DungeonStairGetRequested", stair)
	if not stair_id is StringName or not stair.get("found", false) or stair["data"].get("status", "") != "placed" or stair["data"].get("object", null) != stair_id: return _error(e, "Объект не является выбранной лестницей")
	var plan := {"entity":e.get("entity", null), "accepted":false}
	_plan(plan)
	if not plan.get("accepted", false): return _error(e, str(plan.get("error", "План недоступен")))
	var request: Dictionary = plan["parameters"].duplicate(true)
	request["required_stair"] = stair_id
	_start(request)
	if not request.get("accepted", false): return _error(e, str(request.get("error", "Не удалось начать спуск")))
	e["accepted"] = true
	e["floor"] = plan["floor"]
	e["duration"] = 0.1

func _start(e: Dictionary) -> void:
	e["accepted"] = false
	if _starting or _finishing or not _pending.is_empty(): return _error(e, "Спуск уже выполняется")
	var actor = e.get("entity", null)
	var level_id = e.get("level_id", null)
	var seed = e.get("seed", null)
	var size = e.get("size_cells", null)
	var budget = e.get("deadend_budget", null)
	if not actor is StringName or actor == &"" or not level_id is StringName or level_id == &"" or not seed is int or not size is Vector2i or size.x < 24 or size.y < 24 or size.x > 512 or size.y > 512 or not budget is int or budget < 0: return _error(e, "Нужны явные параметры следующего уровня")
	var snap: Dictionary = SaveService.collect_world_transition_snapshot()
	if not snap.get("valid", false): return _error(e, "Нельзя подготовить снимок мира")
	var sections: Dictionary = snap["payload"]["sections"]
	var stats: Dictionary = sections["run_statistics"]
	var track: Dictionary = sections["dungeon_tracking"]
	var stairs: Dictionary = sections["dungeon_stairs"]
	if stats.is_empty() or stats.get("finished", true) or stats.get("entity", &"") != actor or track.get("floor", null) != stats.get("floor", null) or track.get("root", null) != stats.get("root", null) or not sections["level"].get("active", false) or level_id == sections["level"]["level_id"] or stairs.get("status", "") != "placed": return _error(e, "Мир не готов к спуску")
	var floor_no: int = int(stats["floor"])
	if floor_no < 1 or floor_no >= 4 or (floor_no + 1 < 4 and budget < 1): return _error(e, "Недопустимый этаж или бюджет")
	if e.has("required_stair") and e["required_stair"] != stairs.get("object", null): return _error(e, "Выбранная лестница изменилась")
	var availability := {"entity":actor}
	EventBus.publish(&"DungeonStairAvailabilityRequested", availability)
	if not availability.get("rule_allowed", false): return _error(e, str(availability.get("reason", "Спуск запрещён")))
	var current_stair := {"found":false}
	EventBus.publish(&"DungeonStairGetRequested", current_stair)
	if not current_stair.get("found", false) or current_stair.get("data", {}) != stairs: return _error(e, "Лестница изменилась во время проверки")
	_pending = {"actor":actor, "stair":stairs["object"], "floor":floor_no, "level_id":level_id, "seed":seed, "size_cells":size, "deadend_budget":budget, "phase":"running"}
	_starting = true
	_start_gate_used = false
	var start := {"entity":actor, "action":ACTION, "duration":0.1, "accepted":false}
	EventBus.publish(&"ActionStartRequested", start)
	_starting = false
	_start_gate_used = false
	if not start.get("accepted", false) or _pending.get("phase", "") != "running" or ActionRegistry.get_active_action(actor).get("id", &"") != ACTION:
		_pending.clear()
		return _error(e, "Не удалось начать спуск")
	e["accepted"] = true
	EventBus.publish(&"DungeonDescentStarted", {"entity":actor, "stair":stairs["object"], "floor":floor_no, "duration":0.1})

func _action_guard(e: Dictionary) -> void:
	if e.get("action", &"") != ACTION: return
	if not _starting or _start_gate_used or e.get("entity", &"") != _pending.get("actor", null): e["allowed"] = false
	else: _start_gate_used = true

func _completed(e: Dictionary) -> void:
	if e.get("action", &"") == ACTION and e.get("entity", null) == _pending.get("actor", null) and _pending.get("phase", "") == "running": _pending["phase"] = "ready"
func _interrupted(e: Dictionary) -> void:
	if e.get("action", &"") == ACTION and e.get("entity", null) == _pending.get("actor", null):
		var actor: StringName = _pending["actor"]
		_pending.clear()
		EventBus.publish(&"DungeonDescentInterrupted", {"entity":actor, "reason":e.get("reason", &"interrupted")})
func _object_removed(e: Dictionary) -> void:
	if not _pending.is_empty() and e.get("object", null) == _pending.get("stair", null): _cancel(&"stair_removed")
func _body_removed(e: Dictionary) -> void:
	if not _pending.is_empty() and e.get("entity", null) == _pending.get("actor", null): _cancel(&"body_removed")
func _entity_moved(e: Dictionary) -> void:
	if not _pending.is_empty() and e.get("entity", null) == _pending.get("actor", null): _cancel(&"actor_moved")
func _cancel(reason: StringName) -> void:
	if _pending.is_empty(): return
	var actor: StringName = _pending["actor"]
	if _pending.get("phase", "") == "running":
		var cancel := {"entity":actor, "reason":reason, "accepted":false}
		EventBus.publish(&"ActionCancelRequested", cancel)
		if cancel.get("accepted", false): return
	# Действие могло уже выйти из реестра при вложенном событии завершения.
	if not _pending.is_empty():
		_pending.clear()
		EventBus.publish(&"DungeonDescentInterrupted", {"entity":actor, "reason":reason})

func _settled(_e: Dictionary) -> void:
	if _finishing or _pending.get("phase", "") != "ready": return
	_finishing = true
	var request := _pending.duplicate(true)
	_pending.clear() # Транзакция должна сделать валидный снимок после завершения действия.
	var result: Dictionary = FloorRebuildService.rebuild_next_floor(request["actor"], request["level_id"], request["seed"], request["size_cells"], request["deadend_budget"])
	_finishing = false
	if result.get("committed", false):
		EventBus.publish(&"DungeonDescended", {"entity":request["actor"], "from_floor":request["floor"], "floor":result["floor"], "anchor":result["anchor"]})
	else:
		EventBus.publish(&"DungeonDescentFailed", {"entity":request["actor"], "error":result.get("error", "Не удалось перейти"), "rolled_back":result.get("rolled_back", false), "fatal":result.get("fatal", false)})

func _collect(e: Dictionary) -> void:
	if _starting or _pending.get("phase", "") == "ready": e["errors"].append("Нельзя сохранять между окончанием спуска и переходом")
	e["sections"]["dungeon_descent"] = _pending.duplicate(true)
func _apply(e: Dictionary) -> void:
	_pending = e["sections"]["dungeon_descent"].duplicate(true)
	_starting = false
	_start_gate_used = false
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary or not sections.get("dungeon_descent", null) is Dictionary or not sections.get("actions", {}).get("active", null) is Dictionary: return
	var d: Dictionary = sections["dungeon_descent"]
	var active: Dictionary = sections["actions"]["active"]
	if d.is_empty():
		for action in active.values():
			if not action is Dictionary or action.get("id", &"") == ACTION: return
		e["valid"] = true
		return
	if d.get("phase", "") != "running" or not d.get("actor", null) is StringName or d["actor"] != sections["actions"].get("controlled", null) or not d.get("stair", null) is StringName or not d.get("floor", null) is int or d["floor"] < 1 or d["floor"] > 3 or not d.get("level_id", null) is StringName or d["level_id"] == &"" or not d.get("seed", null) is int or not d.get("size_cells", null) is Vector2i or d["size_cells"].x < 24 or d["size_cells"].y < 24 or d["size_cells"].x > 512 or d["size_cells"].y > 512 or not d.get("deadend_budget", null) is int or d["deadend_budget"] < 0 or (d["floor"] < 3 and d["deadend_budget"] < 1): return
	if not active.get(d["actor"], null) is Dictionary or active[d["actor"]].get("id", &"") != ACTION or active[d["actor"]].get("steps", -1) != 10 or sections.get("combat", {}).get("dead", {}).has(d["actor"]): return
	if not sections.get("dungeon_stairs", null) is Dictionary or not sections.get("run_statistics", null) is Dictionary or not sections.get("dungeon_tracking", null) is Dictionary or not sections.get("objects", {}).get("objects", null) is Dictionary or not sections.get("space", {}).get("bodies", null) is Dictionary: return
	var stair: Dictionary = sections["dungeon_stairs"]
	var stats: Dictionary = sections["run_statistics"]
	var tracking: Dictionary = sections["dungeon_tracking"]
	var object = sections["objects"]["objects"].get(d["stair"], null)
	var body = sections["space"]["bodies"].get(d["actor"], null)
	if stair.get("object", null) != d["stair"] or stair.get("floor", null) != d["floor"] or stair.get("status", "") != "placed" or stats.get("floor", null) != d["floor"] or stats.get("entity", null) != d["actor"] or tracking.get("floor", null) != d["floor"] or not sections["level"].get("active", false) or d["level_id"] == sections["level"].get("level_id", null): return
	if not object is Dictionary or object.get("type", "") != "stairs_down" or not object.get("tile", null) is Vector2i or not body is Dictionary or not body.get("anchor", null) is Vector2i or not body.get("size", null) is int or not sections["entities"].has(d["actor"]): return
	var tile: Vector2i = object["tile"]
	var a: Vector2i = body["anchor"]
	var n: int = body["size"]
	if n <= 0 or not (((tile.x == a.x - 1 or tile.x == a.x + n) and tile.y >= a.y and tile.y < a.y + n) or ((tile.y == a.y - 1 or tile.y == a.y + n) and tile.x >= a.x and tile.x < a.x + n)): return
	for actor in active:
		if not active[actor] is Dictionary or (actor != d["actor"] and active[actor].get("id", &"") == ACTION): return
	e["valid"] = true
func _error(e: Dictionary, text: String) -> void: e["error"] = text
