extends Node
## Низкоуровневый ручной контракт для заранее рассчитанных попаданий.
## Не заменяет фазу сбора ударов и не является системой прав.
var _busy := false
var _committing := false
var _stagger_committing := false
var _phase_effects := false
func _ready() -> void:
	EventBus.subscribe(&"SimultaneousDamageApplyRequested",_apply)
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
func authorizes_commit() -> bool:
	return _busy and _committing
func authorizes_stagger() -> bool:
	return _busy and _stagger_committing
func authorizes_phase_effects() -> bool:
	return _busy and _phase_effects and TimeDriver._combat_phase
func _collect(e: Dictionary) -> void:
	if _busy: e["errors"].append("Нельзя сохранять во время применения пакета урона")
func _finish(e: Dictionary, message: String) -> void:
	_committing = false
	_stagger_committing = false
	_phase_effects = false
	_busy = false
	e["error"] = message
func _apply(e: Dictionary) -> void:
	e["accepted"] = false
	for key in ["error","data"]: e.erase(key)
	var phase_commit = e.get("phase_commit",false)
	if not phase_commit is bool: e["error"] = "phase_commit должен быть логическим"; return
	if _busy or SaveService._transition_busy:
		e["error"] = "Применение пакета недоступно в текущей фазе"; return
	if phase_commit:
		if not TimeDriver.claim_combat_batch(): e["error"] = "Боевой пакет этой фазы недоступен"; return
	elif TimeDriver._stepping:
		e["error"] = "Применение пакета недоступно в текущей фазе"; return
	# Ни проверочные события, ни владелец исходного запроса не должны менять
	# подготовленный пакет после его первоначальной проверки.
	var apply_stagger = e.get("apply_stagger",false)
	if not apply_stagger is bool: e["error"] = "apply_stagger должен быть логическим"; return
	if apply_stagger and TimeDriver._settling: e["error"] = "Пошатывание недоступно при завершении шага"; return
	var input_hp = e.get("hp_by_target",null)
	var input_hits = e.get("hits",null)
	var hp = input_hp.duplicate(true) if input_hp is Dictionary else input_hp
	var hits = input_hits.duplicate(true) if input_hits is Array else input_hits
	# damage — подготовленная физическая часть, magical_damage — магическая;
	# сначала обе валидируются, затем агрегатор видит сумму для каждой пары.
	# Отдельная физическая часть сохраняется для расчёта щита.
	if not hits is Array or hits.size() > SimultaneousDamagePlanService.MAX_HITS:
		e["error"] = "Некорректный список попаданий"; return
	var total_hits: Array = []
	for hit in hits:
		if not hit is Dictionary or not hit.get("damage",null) is int or hit["damage"] < 0 or hit["damage"] > SimultaneousDamagePlanService.MAX_NUMBER:
			e["error"] = "Некорректная физическая часть"; return
		var magical = hit.get("magical_damage",0)
		if not magical is int or magical < 0 or magical > SimultaneousDamagePlanService.MAX_NUMBER or hit["damage"] + magical > SimultaneousDamagePlanService.MAX_NUMBER:
			e["error"] = "Некорректная магическая часть или сумма"; return
		var total: Dictionary = hit.duplicate(true)
		total["damage"] = hit["damage"] + magical
		total_hits.append(total)
	var query := {"hp_by_target":hp,"hits":total_hits,"accepted":false}
	SimultaneousDamagePlanService._plan(query)
	if not query.get("accepted",false): e["error"] = query.get("error","Пакет некорректен"); return
	_busy = true
	var rows: Array = query["data"]["targets"]
	var single_input = e.get("block",null)
	var multiple_input = e.get("blocks",null)
	var single = single_input.duplicate(true) if single_input is Dictionary else single_input
	var multiple = multiple_input.duplicate(true) if multiple_input is Array else multiple_input
	if e.has("block") and e.has("blocks"): _finish(e,"Укажите block или blocks, но не оба"); return
	if e.has("blocks") and not multiple is Array: _finish(e,"Нужен массив блоков"); return
	var blocks: Array = []
	if single != null: blocks = [single]
	elif multiple is Array: blocks = multiple.duplicate(true)
	if blocks.size() > 10000: _finish(e,"Слишком много блоков"); return
	var seen_blocks := {}
	for b in blocks:
		if not b is Dictionary or not b.get("target",null) is StringName or b["target"] == &"" or seen_blocks.has(b["target"]) or not ShieldBlockZoneService.valid_direction(b.get("direction",null)) or not b.get("expected_stamina",null) is int or b["expected_stamina"] < 0 or b["expected_stamina"] > 1000000000:
			_finish(e,"Некорректные или повторные параметры блока"); return
		seen_blocks[b["target"]] = true
	blocks.sort_custom(func(a,b): return str(a["target"]) < str(b["target"]))
	var targets := {}
	var sources := {}
	var hits_by_target := {}
	for row in rows: targets[row["target"]] = true
	for hit in hits:
		var independent = hit.get("independent_projectile",false)
		if independent:
			if independent != true or not phase_commit or not CombatPhaseBatchService._finishing or not ProjectileService.authorizes_phase_hit(hit):
				_finish(e,"Недоверенное независимое попадание"); return
		else: sources[hit["source"]] = true
		if not hits_by_target.has(hit["target"]): hits_by_target[hit["target"]] = []
		hits_by_target[hit["target"]].append(hit)
	var states := {}
	for id in targets.keys() + sources.keys():
		if states.has(id): continue
		if not EntityRegistry.has_entity(id) or CombatService.is_entity_dead(id) or not EntityRegistry.has_component(id,&"resources"):
			_finish(e,"Источник или цель недоступны"); return
		var resources: Dictionary = EntityRegistry.get_component(id,&"resources")
		var h = resources.get(&"HP",null)
		if not h is Dictionary or not (h.get("current",null) is int or h.get("current",null) is float) or not is_finite(float(h["current"])) or float(h["current"]) <= 0:
			_finish(e,"Некорректные HP источника или цели"); return
		states[id] = resources
	for row in rows:
		if float(states[row["target"]][&"HP"]["current"]) != float(row["hp_before"]):
			_finish(e,"HP изменились после снимка"); return
	var stagger_maxima := {}
	if apply_stagger:
		for id in targets:
			var maximum = states[id][&"HP"].get("max",null)
			if not (maximum is int or maximum is float) or not is_finite(float(maximum)) or float(maximum) < 1 or float(maximum) > StaggerPlanService.MAX_VALUE or floor(float(maximum)) != float(maximum):
				_finish(e,"Некорректный максимум HP для пошатывания"); return
			stagger_maxima[id] = int(maximum)
	for id in targets:
		var allowed := {"entity":id,"allowed":true}
		EventBus.publish(&"CombatDamageAllowedRequested",allowed)
		if not allowed.get("allowed",false): _finish(e,"Цель защищена от урона"); return
	var block_hits := {}
	var block_zones := {}
	for block in blocks:
		var target: StringName = block["target"]
		if not targets.has(target): _finish(e,"Цель блока отсутствует в пакете"); return
		var stamina = states[target].get(&"Stamina",null)
		if not stamina is Dictionary or not (stamina.get("current",null) is int or stamina.get("current",null) is float) or not is_finite(float(stamina["current"])) or float(stamina["current"]) != float(block["expected_stamina"]):
			_finish(e,"Свободная выносливость изменилась или не целая"); return
		var relevant: Array = []
		var zone: Dictionary = {}
		for hit in hits_by_target[target]:
			if not hit.get("attack_tiles",null) is Array: _finish(e,"Нужны тайлы каждого удара по блокирующему"); return
			var z := {"entity":target,"direction":block["direction"],"attack_tiles":hit["attack_tiles"],"accepted":false}
			ShieldBlockZoneService._zone(z)
			if not z.get("accepted",false): _finish(e,"Зона блока недоступна"); return
			var data: Dictionary = z["data"]
			var invariant := {"item":data["item"],"slot":data["slot"],"anchor":data["body_anchor"],"size":data["body_size"],"width":data["width"],"direction":data["direction"],"tiles":data["tiles"]}
			if zone.is_empty(): zone = invariant
			elif zone != invariant: _finish(e,"Зона блока изменилась"); return
			if data["intersects"]: relevant.append({"id":hit.get("hit_id",hit["source"]),"damage":hit["damage"]})
		block_hits[target] = relevant
		block_zones[target] = zone
	# Все проверки зон завершены: позже проверенный защитник не должен
	# незаметно изменить блок или положение другого защитника.
	for block in blocks:
		var target: StringName = block["target"]
		var zone: Dictionary = block_zones[target]
		var pending = ShieldBlockActionService._pending.get(target,null)
		var gear := EntityRegistry.get_component(target,&"equipment")
		var body = SpaceService._bodies.get(target,null)
		var action := ActionRegistry.get_active_action(target)
		var valid_action: bool = action.get("id",null) == &"shield_block" or (phase_commit and ShieldBlockActionService._ending.has(target) and action.is_empty())
		if not pending is Dictionary or pending.get("item",null) != zone.get("item",null) or pending.get("slot",null) != zone.get("slot",null) or pending.get("direction",null) != zone.get("direction",null) or gear.get(zone.get("slot",""),null) != zone.get("item",null) or not body is Dictionary or body.get("anchor",null) != zone.get("anchor",null) or body.get("size",null) != zone.get("size",null) or not valid_action or not ShieldBlockZoneService.matches_committed_geometry(zone):
			_finish(e,"Блок или положение изменились"); return
	# Подписчики проверок могли синхронно изменить мир; повторно сверяем все ресурсы.
	for id in states:
		if not EntityRegistry.has_entity(id) or CombatService.is_entity_dead(id) or EntityRegistry.get_component(id,&"resources") != states[id]:
			_finish(e,"Состояние изменилось при проверке"); return
	# После этого места внешних событий до коммита нет; откатим собственные броски при отказе.
	var rng_state: int = RngService._rng.state
	var block_results := {}
	var passed_by_target := {}
	if not blocks.is_empty():
		var adjusted: Array = total_hits.duplicate(true)
		for block in blocks:
			var target: StringName = block["target"]
			var bq := {"available_stamina":block["expected_stamina"],"hits":block_hits[target],"accepted":false}
			SimultaneousBlockPlanService._plan(bq)
			if not bq.get("accepted",false):
				RngService._rng.state = rng_state
				_finish(e,"Не удалось рассчитать блок"); return
			block_results[target] = bq["data"]
			var passed := {}
			for entry in bq["data"]["hits"]: passed[entry["id"]] = entry["passed"]
			passed_by_target[target] = passed
		for hit in adjusted:
			var passed: Dictionary = passed_by_target.get(hit["target"],{})
			var hit_id: StringName = hit.get("hit_id",hit["source"])
			if passed.has(hit_id): hit["damage"] = passed[hit_id] + hit.get("magical_damage",0)
		query = {"hp_by_target":hp,"hits":adjusted,"accepted":false}
		SimultaneousDamagePlanService._plan(query)
		if not query.get("accepted",false):
			RngService._rng.state = rng_state
			_finish(e,"Не удалось рассчитать остаточный урон"); return
		rows = query["data"]["targets"]
	# Сохраняем урон каждого источника до ограничения оставшимися HP —
	# агрегат HP сам по себе не подходит для порога пошатывания.
	var resolved_hits: Array = []
	for hit in hits:
		var passed: Dictionary = passed_by_target.get(hit["target"],{})
		var physical: int = passed.get(hit.get("hit_id",hit["source"]),hit["damage"])
		var magical: int = hit.get("magical_damage",0)
		var resolved := {"source":hit["source"],"target":hit["target"],"physical":physical,"magical":magical,"damage":physical + magical}
		if hit.has("hit_id"): resolved["hit_id"] = hit["hit_id"]
		resolved_hits.append(resolved)
	resolved_hits.sort_custom(func(a,b): return str(a["target"]) < str(b["target"]) or (a["target"] == b["target"] and str(a["source"]) < str(b["source"])))
	query["data"]["resolved_hits"] = resolved_hits
	var stagger_plan := {}
	var stagger_max_damage := {}
	if apply_stagger:
		for hit in resolved_hits: stagger_max_damage[hit["target"]] = maxi(stagger_max_damage.get(hit["target"],0),hit["damage"])
		var sq := {"max_hp_by_target":stagger_maxima,"hits":resolved_hits,"accepted":false}
		StaggerPlanService._plan(sq)
		if not sq.get("accepted",false):
			RngService._rng.state = rng_state
			_finish(e,"Не удалось рассчитать пошатывание"); return
		stagger_plan = sq["data"]
	var changes := {}
	var original := {}
	var deaths: Array = []
	var death_set := {}
	for row in rows:
		var id: StringName = row["target"]
		original[id] = states[id]
		changes[id] = states[id].duplicate(true)
		changes[id][&"HP"]["current"] = float(row["hp_after"])
		if row["lethal"]: deaths.append(id); death_set[id] = true
	for block in blocks:
		changes[block["target"]][&"Stamina"]["current"] = float(block["expected_stamina"] - block_results[block["target"]]["stamina_cost"])
	for row in rows:
		var candidates: Array = row["killer_candidates"]
		if candidates.size() == 1: row["killer"] = candidates[0]
		elif candidates.size() > 1: row["killer"] = candidates[RngService._rng.randi_range(0,candidates.size()-1)]
		else: row["killer"] = null
	_committing = true
	var committed: bool = EntityRegistry.commit_simultaneous_hp(original,changes)
	if not committed:
		RngService._rng.state = rng_state
		_finish(e,"Не удалось зафиксировать пакет"); return
	CombatService.commit_simultaneous_deaths(deaths)
	_committing = false
	# Все HP, Stamina и отметки смерти уже установлены.
	for block in blocks:
		if block_results[block["target"]]["block_interrupted"] and not death_set.has(block["target"]):
			if phase_commit and ShieldBlockActionService._ending.has(block["target"]):
				_phase_effects = true
				ShieldBlockActionService.interrupt_ending_from_batch(block["target"])
				_phase_effects = false
			else: ActionRegistry.cancel_action(block["target"], &"shield_exhausted")
	if apply_stagger:
		var outcomes: Array = []
		var deferred: Array = []
		# Не прерываем готовое действие на том же шаге до его завершения.
		for entry in stagger_plan["targets"]:
			var target: StringName = entry["target"]
			var outcome := {"target":target,"sources":entry["sources"].duplicate(),"triggered":entry["triggered"],"applied":false}
			if not entry["triggered"]: outcome["reason"] = "below_threshold"
			elif death_set.has(target): outcome["reason"] = "lethal"
			elif phase_commit: outcome["reason"] = "queued"
			else:
				var st := {"target":target,"damage":stagger_max_damage[target],"expected_max_hp":stagger_maxima[target],"accepted":false}
				_stagger_committing = true
				StaggerApplyService.apply_from_simultaneous(st)
				_stagger_committing = false
				if st.get("accepted",false): outcome.merge(st["data"],true)
				else: outcome["reason"] = "apply_failed"; outcome["error"] = st.get("error","Не удалось применить")
			outcomes.append(outcome)
			if phase_commit: deferred.append({"target":target,"sources":entry["sources"].duplicate(),"triggered":entry["triggered"],"lethal":death_set.has(target),"damage":stagger_max_damage[target],"max_hp":stagger_maxima[target]})
		if phase_commit:
			_phase_effects = true
			PhaseStaggerService.stage(deferred)
			_phase_effects = false
		query["data"]["stagger"] = outcomes
	for row in rows:
		var id: StringName = row["target"]
		EventBus.publish(&"ComponentChanged", {"entity":id,"component":&"resources","created":false})
		if block_results.has(id) and block_results[id]["stamina_cost"] > 0:
			ResourceService._emit_change(id,&"Stamina",float(states[id][&"Stamina"]["current"]),float(changes[id][&"Stamina"]["current"]))
		if row["hp_lost"] > 0:
			EventBus.publish(&"ResourceChanged", {"entity":id,"resource":&"HP","old":float(row["hp_before"]),"new":float(row["hp_after"])})
			if row["lethal"]: EventBus.publish(&"ResourceDepleted", {"entity":id,"resource":&"HP"})
			EventBus.publish(&"EntityDamaged", {"entity":id,"source":null,"amount":float(row["hp_lost"]),"simultaneous":true})
	for row in rows:
		if row["lethal"]: EventBus.publish(&"EntityDied", {"entity":row["target"],"killer":row["killer"],"simultaneous":true})
	for row in rows:
		if not row["lethal"] and EntityRegistry.has_entity(row["target"]):
			ResourceService._sync_timer(row["target"],&"HP")
			if block_results.has(row["target"]): ResourceService._sync_timer(row["target"],&"Stamina")
	if not blocks.is_empty(): query["data"]["blocks"] = block_results.duplicate(true)
	if single != null: query["data"]["block"] = block_results[single["target"]].duplicate(true)
	_busy = false
	e["accepted"] = true
	e["data"] = query["data"]
	EventBus.publish(&"SimultaneousDamageApplied", {"data":query["data"].duplicate(true)})
