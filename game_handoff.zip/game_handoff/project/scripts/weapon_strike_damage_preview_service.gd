extends Node
## Частичная проекция до крита, ослабления, защиты и блока; без нанесения урона.
func _ready() -> void:
	EventBus.subscribe(&"WeaponStrikeDamagePreviewRequested", _preview)
	EventBus.subscribe(&"BowShotDamagePreviewRequested", _preview_bow)
func _number(v: Variant) -> bool:
	return (v is int or v is float) and is_finite(float(v))
func _preview(e: Dictionary) -> void:
	_calculate(e, false)
func _preview_bow(e: Dictionary) -> void:
	_calculate(e, true)
func _calculate(e: Dictionary, bow: bool) -> void:
	e["accepted"] = false
	for key in ["error","data"]: e.erase(key)
	var actor = e.get("entity",null)
	var id = e.get("item",null)
	var strike_id = e.get("strike",null)
	if not actor is StringName or actor == &"" or not id is StringName or id == &"" or not (strike_id is String or strike_id is StringName) or str(strike_id).is_empty():
		e["error"] = "Нужны владелец, оружие и удар"; return
	var item := {"item":id,"found":false}
	var gear := {"entity":actor,"component":&"equipment","found":false}
	var inventory := {"entity":actor,"found":false}
	var entity := {"entity":actor,"found":false}
	EventBus.publish(&"EntityGetRequested",entity)
	EventBus.publish(&"ItemGetRequested",item)
	EventBus.publish(&"ComponentGetRequested",gear)
	EventBus.publish(&"InventoryGetRequested",inventory)
	if not entity.get("found",false) or not item.get("found",false) or not item.get("base",null) is Dictionary or not item.get("item_data",null) is Dictionary or str(item["base"].get("slot","")) != "weapon":
		e["error"] = "Персонаж или оружие не найдены"; return
	var slots = gear.get("data",{})
	var in_hand: bool = gear.get("found",false) and slots is Dictionary and (slots.get("main",null) == id or slots.get("off",null) == id)
	var inv = inventory.get("data",{})
	var owned: bool = inventory.get("found",false) and inv is Dictionary and inv.get("items",[]) is Array and inv["items"].has(id)
	if not in_hand and not owned: e["error"] = "Предмет не принадлежит персонажу"; return
	var weapon := {"item":id,"found":false}
	var list := {"item":id,"found":false}
	EventBus.publish(&"WeaponItemResolveRequested",weapon)
	EventBus.publish(&"WeaponStrikesGetRequested",list)
	if not weapon.get("found",false) or not list.get("found",false): e["error"] = "Вид или удары оружия недоступны"; return
	var row: Dictionary = {}
	for candidate in list["strikes"]:
		if str(candidate.get("id","")) == str(strike_id): row = candidate; break
	if row.is_empty() or not _number(row.get("damage",null)) or float(row["damage"]) < 0: e["error"] = "Удар недоступен"; return
	var w: Dictionary = weapon["data"]
	var tags = w.get("tags",null)
	if not tags is Array: e["error"] = "Теги оружия недоступны"; return
	if bow:
		if str(w.get("type","")) != "bow" or str(strike_id) != "bow_simple_shot": e["error"] = "Нужен выстрел из лука"; return
	elif tags.has("throwing") or str(w.get("type","")) in ["bow","crossbow"]:
		e["error"] = "Метательное и дальнобойное оружие здесь не рассчитывается"; return
	# DEX для лука — временное предположение до уточнения ТЗ.
	var stat: StringName = &"DEX" if bow or tags.has("light") or tags.has("fencing") else &"STR"
	var stat_q := {"entity":actor,"stat":stat,"found":false}
	EventBus.publish(&"StatGetRequested",stat_q)
	if not stat_q.get("found",false) or not _number(stat_q.get("value",null)): e["error"] = "Характеристика недоступна"; return
	var base_factor: Dictionary = DungeonChestLearningService.equipped_base_multiplier(actor,item["item_data"])
	var bonus: Dictionary = DungeonChestLearningService.weapon_physical_damage_mod_bonus(actor,item["item_data"],item["base"])
	if not base_factor.get("valid",false) or not bonus.get("valid",false): e["error"] = "Некорректные данные изучения или мода"; return
	var characteristic: float = 1.0 + (float(stat_q["value"]) - 5.0) / 20.0
	var base: float = float(row["damage"]) * float(base_factor["multiplier"])
	var raw: float = (base + float(bonus["bonus"])) * characteristic
	if not is_finite(raw): e["error"] = "Некорректный результат"; return
	e["data"] = {"base_damage":float(row["damage"]),"learning_multiplier":base_factor["multiplier"],"physical_mod_bonus":bonus["bonus"],"stat":stat,"stat_value":float(stat_q["value"]),"stat_multiplier":characteristic,"raw_damage":raw,"nonnegative_damage":maxf(0.0,raw),"in_hand":in_hand}
	e["accepted"] = true
