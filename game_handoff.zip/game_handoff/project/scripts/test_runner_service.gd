extends Node
## Each test runs in a separate Godot process with isolated user:// data.
signal run_started(total: int, run_dir: String)
signal test_started(index: int, total: int, name: String)
signal test_finished(result: Dictionary)
signal run_finished(summary: Dictionary)

const TEST_DIR := "res://tests"
const TIMEOUT_MS := 240000
const MAX_LOG_BYTES := 16 * 1024 * 1024
var _tests: Array[String] = []
var _results: Array = []
var _index := 0
var _pid := -1
var _started_ms := 0
var _log_path := ""
var _run_dir := ""
var _project_dir := ""
var _run_token := ""
var _cancelled := false
var _running := false
var _generation := 0

func discover_tests() -> Array[String]:
	var found: Array[String] = []
	var dir := DirAccess.open(TEST_DIR)
	if dir == null: return found
	dir.list_dir_begin()
	var file := dir.get_next()
	while not file.is_empty():
		if not dir.current_is_dir() and file.begins_with("test_") and file.ends_with(".gd"):
			found.append(file)
		file = dir.get_next()
	dir.list_dir_end()
	found.sort()
	return found

func is_running() -> bool: return _running
func get_results() -> Array: return _results.duplicate(true)
func start_all() -> Dictionary: return start_tests(discover_tests())
func start_one(name: String) -> Dictionary: return start_tests([name])

func start_tests(names: Array) -> Dictionary:
	if _running: return {"accepted":false, "error":"Прогон уже выполняется"}
	if names.is_empty(): return {"accepted":false, "error":"Нет выбранных тестов"}
	var available := discover_tests()
	var seen := {}
	var selected: Array[String] = []
	for name in names:
		if not name is String or not available.has(name) or seen.has(name):
			return {"accepted":false, "error":"Неизвестный или повторный тест: %s" % str(name)}
		selected.append(name)
		seen[name] = true
	var source := ProjectSettings.globalize_path("res://")
	if not FileAccess.file_exists(source.path_join("project.godot")):
		return {"accepted":false, "error":"Нужен исходный проект Godot, не экспортированная игра"}
	_run_token = "%d_%d_%d" % [int(Time.get_unix_time_from_system()), OS.get_process_id(), Time.get_ticks_usec()]
	_run_dir = ProjectSettings.globalize_path("user://test_runner/runs/" + _run_token)
	_project_dir = _run_dir.path_join("project")
	if DirAccess.make_dir_recursive_absolute(_project_dir) != OK:
		return {"accepted":false, "error":"Не удалось создать каталог тестов"}
	var copied := _copy_tree(source, _project_dir)
	if copied != OK:
		return {"accepted":false, "error":"Не удалось скопировать проект: %s" % error_string(copied)}
	_tests = selected
	_results.clear()
	_index = 0
	_cancelled = false
	_running = true
	_generation += 1
	_pid = -1
	run_started.emit(_tests.size(), _run_dir)
	call_deferred("_start_next", _generation)
	return {"accepted":true, "run_dir":_run_dir}

func cancel() -> void:
	if not _running: return
	_cancelled = true
	if _pid > 0:
		# OS.kill reaps the child on some platforms; don't poll it afterwards.
		if OS.kill(_pid) == OK:
			_complete_active(-1, false, true)
	else:
		_finish_run()

func _start_next(generation: int) -> void:
	if not _running or generation != _generation or _pid > 0: return
	if _cancelled or _index >= _tests.size():
		_finish_run()
		return
	# Every process uses a unique user://, so game and other test saves are never touched.
	var config := ConfigFile.new()
	var project_file := _project_dir.path_join("project.godot")
	if config.load(project_file) != OK:
		_fail_to_start("Не удалось открыть копию project.godot")
		return
	var isolated := "TimeDriver_test_runner/%s/%03d" % [_run_token, _index]
	config.set_value("application", "config/use_custom_user_dir", true)
	config.set_value("application", "config/custom_user_dir_name", isolated)
	if config.save(project_file) != OK:
		_fail_to_start("Не удалось настроить изолированный user://")
		return
	_log_path = _run_dir.path_join("%03d_%s.log" % [_index + 1, _tests[_index].get_basename()])
	var args := PackedStringArray(["--headless", "--path", _project_dir, "--log-file", _log_path, "--script", "res://tests/" + _tests[_index]])
	_started_ms = Time.get_ticks_msec()
	_pid = OS.create_process(OS.get_executable_path(), args, false)
	if _pid <= 0:
		_fail_to_start("Не удалось запустить процесс Godot")
		return
	test_started.emit(_index + 1, _tests.size(), _tests[_index])

func _process(_delta: float) -> void:
	if not _running or _pid <= 0: return
	var timeout := Time.get_ticks_msec() - _started_ms > TIMEOUT_MS
	if timeout:
		if OS.kill(_pid) == OK:
			_complete_active(-1, true, false)
			return
	if OS.is_process_running(_pid): return
	var exit_code := OS.get_process_exit_code(_pid)
	_complete_active(exit_code, timeout, _cancelled)

func _complete_active(exit_code: int, timeout: bool, cancelled: bool) -> void:
	_pid = -1
	var log := _read_log(_log_path)
	var info := classify_result(exit_code, log, timeout, cancelled)
	var result := {"name":_tests[_index], "status":info["status"], "reason":info["reason"], "exit_code":exit_code, "elapsed_ms":Time.get_ticks_msec() - _started_ms, "log_path":_log_path, "log":log}
	_results.append(result)
	test_finished.emit(result.duplicate(true))
	_index += 1
	_start_next(_generation)

func classify_result(exit_code: int, log: String, timeout: bool = false, cancelled: bool = false) -> Dictionary:
	if cancelled: return {"status":"CANCELLED", "reason":"Остановлено пользователем"}
	if timeout: return {"status":"TIMEOUT", "reason":"Превышено 240 секунд"}
	if exit_code != 0: return {"status":"FAIL", "reason":"Код завершения: %d" % exit_code}
	for marker in ["SCRIPT ERROR", "ERROR:", "Parse Error", "FAIL:"]:
		if log.contains(marker): return {"status":"FAIL", "reason":"В журнале обнаружено: " + marker}
	if not log.contains("PASS"): return {"status":"FAIL", "reason":"Нет отметки PASS в журнале"}
	return {"status":"PASS", "reason":""}

func _fail_to_start(reason: String) -> void:
	var result := {"name":_tests[_index], "status":"FAIL", "reason":reason, "exit_code":-1, "elapsed_ms":0, "log_path":"", "log":""}
	_results.append(result)
	test_finished.emit(result.duplicate(true))
	_index += 1
	call_deferred("_start_next", _generation)

func _finish_run() -> void:
	if not _running: return
	_running = false
	var passed := 0
	var failed := 0
	var cancelled_count := 0
	for result in _results:
		if result["status"] == "PASS": passed += 1
		elif result["status"] == "CANCELLED": cancelled_count += 1
		else: failed += 1
	var summary := {"total":_tests.size(), "completed":_results.size(), "passed":passed, "failed":failed, "cancelled_count":cancelled_count, "skipped":_tests.size() - _results.size(), "cancelled":_cancelled, "run_dir":_run_dir, "results":_results.duplicate(true)}
	var file := FileAccess.open(_run_dir.path_join("report.json"), FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(summary, "  "))
	run_finished.emit(summary)

func _read_log(path: String) -> String:
	if not FileAccess.file_exists(path): return ""
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null: return ""
	if f.get_length() > MAX_LOG_BYTES: return "ERROR: Журнал превышает 16 МБ"
	return f.get_as_text()

func _copy_tree(source: String, target: String) -> Error:
	var dir := DirAccess.open(source)
	if dir == null: return ERR_CANT_OPEN
	dir.list_dir_begin()
	var name := dir.get_next()
	while not name.is_empty():
		if name != ".godot" and not name.begins_with("."):
			var src := source.path_join(name)
			var dst := target.path_join(name)
			var err := OK
			if dir.current_is_dir():
				err = DirAccess.make_dir_recursive_absolute(dst)
				if err == OK: err = _copy_tree(src, dst)
			else:
				err = DirAccess.copy_absolute(src, dst)
			if err != OK:
				dir.list_dir_end()
				return err
		name = dir.get_next()
	dir.list_dir_end()
	return OK

func _exit_tree() -> void:
	if _pid > 0 and OS.is_process_running(_pid): OS.kill(_pid)
