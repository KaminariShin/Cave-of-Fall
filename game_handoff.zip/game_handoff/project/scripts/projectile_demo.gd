extends Control
## Изолированный тест снаряда; скорость и урон стрелы здесь демонстрационные.
const HERO := &"projectile_demo_player"
const RAT := &"projectile_demo_rat"
const OTHER := &"projectile_demo_other"
const MAP_SIZE := Vector2i(27, 16)
const TILE := 18.0
const ORIGIN := Vector2(20, 62)
var floors: Dictionary = {}
var shots: Dictionary = {}
var blast: Dictionary = {}
var direction := Vector2.RIGHT
var kind := "fireball"
var rat_hp := 45.0
var other_hp := 45.0
var status := "1: фаербол  2: стрела  стрелки: направление  пробел: запуск"

func _ready() -> void:
	EventBus.subscribe(&"ProjectileExplosion", _on_explosion)
	EventBus.subscribe(&"ProjectileExpired", _on_expired)
	EventBus.subscribe(&"EntityDamaged", _on_damaged)
	var map := {"size": MAP_SIZE, "accepted": false}
	EventBus.publish(&"SpaceMapConfigureRequested", map)
	var tiles: Array = []
	for x in range(MAP_SIZE.x):
		for y in range(MAP_SIZE.y):
			if x == 0 or y == 0 or x == MAP_SIZE.x - 1 or y == MAP_SIZE.y - 1 or (x == 18 and y > 1 and y < 14):
				continue
			var tile := Vector2i(x, y)
			tiles.append(tile)
			floors[tile] = true
	EventBus.publish(&"SpaceTilesSetRequested", {"tiles": tiles, "kind": 1})
	for id in [HERO, RAT, OTHER]:
		EventBus.publish(&"EntityCreateRequested", {"entity": id})
	var hero := {"entity": HERO, "anchor": Vector2i(2, 6), "size": 2, "accepted": false}
	var rat := {"entity": RAT, "anchor": Vector2i(12, 6), "size": 2, "accepted": false}
	var other := {"entity": OTHER, "anchor": Vector2i(12, 8), "size": 2, "accepted": false}
	for request in [hero, rat, other]:
		EventBus.publish(&"SpaceBodyPlaceRequested", request)
	if not map["accepted"] or not hero["accepted"] or not rat["accepted"] or not other["accepted"]:
		status = "Ошибка инициализации стенда"

func _process(_delta: float) -> void:
	var query := {}
	EventBus.publish(&"ProjectilesGetRequested", query)
	shots = query.get("projectiles", {})
	queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	match event.keycode:
		KEY_1: kind = "fireball"
		KEY_2: kind = "bow"
		KEY_LEFT: direction = Vector2.LEFT
		KEY_RIGHT: direction = Vector2.RIGHT
		KEY_UP: direction = Vector2.UP
		KEY_DOWN: direction = Vector2.DOWN
		KEY_SPACE:
			if TimeDriver.is_action_active:
				status = "Дождитесь конца демонстрационного ожидания."
				return
			blast.clear()
			var launch := {"entity": HERO, "weapon_type": kind, "direction": direction, "speed": 10.0, "accepted": false}
			if kind == "bow": launch["damage"] = 4.0
			EventBus.publish(&"ProjectileLaunchRequested", launch)
			if launch["accepted"]:
				TimeDriver.wait_for(2.0)
				status = "Снаряд летит; ожидание продвигает игровое время."
			else:
				status = "Выстрел отклонён: " + str(launch.get("error", "ошибка"))
		_:
			return
	queue_redraw()

func _on_explosion(event: Dictionary) -> void:
	blast.clear()
	for tile in event["tiles"]:
		blast[tile] = true

func _on_expired(event: Dictionary) -> void:
	status = "Снаряд исчез: " + str(event["reason"]) + "."

func _on_damaged(event: Dictionary) -> void:
	var entity: StringName = event.get("entity", &"")
	if entity in [RAT, OTHER]:
		var request := {"entity": entity, "resource": &"HP", "found": false}
		EventBus.publish(&"ResourceGetRequested", request)
		if request["found"]:
			if entity == RAT: rat_hp = float(request["data"]["current"])
			else: other_hp = float(request["data"]["current"])

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("121b26"))
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(20, 25), "Снаряды и черновой взрыв фаербола", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_string(font, Vector2(20, 48), status, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("c9d4e5"))
	for y in range(MAP_SIZE.y):
		for x in range(MAP_SIZE.x):
			var tile := Vector2i(x, y)
			var color := Color("344654") if floors.has(tile) else Color("1a242f")
			if blast.has(tile): color = Color("a66331")
			draw_rect(Rect2(ORIGIN + Vector2(tile) * TILE, Vector2.ONE * (TILE - 1)), color)
	draw_rect(Rect2(ORIGIN + Vector2(2, 6) * TILE + Vector2.ONE * 2, Vector2.ONE * (2 * TILE - 4)), Color("5ed6c1"))
	draw_rect(Rect2(ORIGIN + Vector2(12, 6) * TILE + Vector2.ONE * 2, Vector2.ONE * (2 * TILE - 4)), Color("e36c68"))
	draw_rect(Rect2(ORIGIN + Vector2(12, 8) * TILE + Vector2.ONE * 2, Vector2.ONE * (2 * TILE - 4)), Color("caa6e9"))
	for shot in shots.values():
		draw_circle(ORIGIN + shot["position"] * TILE, 5.0, Color("ffd166"))
	draw_string(font, Vector2(525, 90), "Фаербол" if kind == "fireball" else "Стрела", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_string(font, Vector2(525, 120), "HP цели: %.0f" % rat_hp, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
	draw_string(font, Vector2(525, 143), "HP рядом: %.0f" % other_hp, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
	draw_string(font, Vector2(525, 179), "Скорость 10 —", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(525, 197), "только для стенда.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(525, 225), "После гибели цели", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
	draw_string(font, Vector2(525, 243), "перезапустите сцену.", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("9babb7"))
