extends Node
## Счётчики текущего забега. Не является профилем или хранилищем результатов.
const STATS := [&"CON", &"STR", &"DEX", &"INT", &"WIS", &"PER"]
var _data: Dictionary = {}

func _ready() -> void:
	EventBus.subscribe(&"RunStatisticsStartRequested", _start)
	EventBus.subscribe(&"RunStatisticsFloorBeginRequested", _floor_begin)
	EventBus.subscribe(&"RunStatisticsGetRequested", _get_stats)
	EventBus.subscribe(&"RunStatisticsVictoryRequested", _victory)
	EventBus.subscribe(&"PlayerRoomChanged", _room_changed)
	EventBus.subscribe(&"EntityDied", _died)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"RunStatisticsSnapshotValidateRequested", _validate)

func _start(e: Dictionary) -> void:
	e["accepted"] = false
	var entity = e.get("entity", null)
	var room = e.get("start_room", null)
	if not entity is StringName or entity == &"" or not room is StringName or room == &"": return
	var owner := {"entity":entity, "found":false}
	EventBus.publish(&"EntityGetRequested", owner)
	var alive := {"entity":entity, "allowed":true}
	EventBus.publish(&"CombatEntityCanActRequested", alive)
	var start_room := {"id":room, "found":false}
	EventBus.publish(&"RoomGetRequested", start_room)
	var control := {}
	EventBus.publish(&"GameModeGetRequested", control)
	if not owner.get("found", false) or not alive.get("allowed", true) or not start_room.get("found", false) or control.get("entity", &"") != entity: return
	if not _data.is_empty() and not _data.get("finished", false): return
	_data = {"entity":entity, "floor":1, "root":room, "visited":{}, "kills":0, "max_depth":0.0, "depth_known":false, "finished":false, "outcome":"", "final_stats":{}}
	e["accepted"] = true

func _floor_begin(e: Dictionary) -> void:
	e["accepted"] = false
	if _data.is_empty() or _data["finished"]: return
	var floor_no = e.get("floor", null)
	var room = e.get("start_room", null)
	if not floor_no is int or floor_no != _data["floor"] + 1 or floor_no > 4 or not room is StringName or room == &"": return
	var query := {"id":room, "found":false}
	EventBus.publish(&"RoomGetRequested", query)
	if not query["found"]: return
	_data["floor"] = floor_no
	_data["root"] = room
	e["accepted"] = true

func _room_changed(e: Dictionary) -> void:
	if _data.is_empty() or _data["finished"] or e.get("entity", null) != _data["entity"]: return
	var room = e.get("room", null)
	if not room is StringName or room == &"": return
	var query := {"rooms":{}}
	EventBus.publish(&"RoomAllGetRequested", query)
	if not query["rooms"].has(room): return
	var floor_no: int = _data["floor"]
	if not _data["visited"].has(floor_no): _data["visited"][floor_no] = {}
	_data["visited"][floor_no][room] = true
	var distance := _distance(query["rooms"], _data["root"], room)
	if distance < 0:
		EventBus.publish(&"RunStatisticsDepthUnavailable", {"floor":floor_no, "room":room})
		return
	var calc := {"floor":floor_no, "distance":distance, "accepted":false}
	EventBus.publish(&"DungeonDepthCalculateRequested", calc)
	if calc["accepted"]:
		_data["max_depth"] = maxf(float(_data["max_depth"]), float(calc["depth"]))
		_data["depth_known"] = true

func _distance(rooms: Dictionary, root: StringName, target: StringName) -> int:
	if not rooms.has(root) or not rooms.has(target): return -1
	var queue: Array = [root]
	var distances := {root:0}
	var index := 0
	while index < queue.size():
		var id: StringName = queue[index]
		index += 1
		if id == target: return int(distances[id])
		for exit in rooms[id].get("exits", []):
			var next = exit.get("childId", null)
			if exit.get("connected", false) and next is StringName and rooms.has(next) and not distances.has(next):
				distances[next] = int(distances[id]) + 1
				queue.append(next)
	return -1

func _died(e: Dictionary) -> void:
	if _data.is_empty() or _data["finished"]: return
	var dead = e.get("entity", null)
	if dead == _data["entity"]:
		_data["final_stats"] = _read_stats(_data["entity"])
		_data["finished"] = true
		_data["outcome"] = "death"
		EventBus.publish(&"RunStatisticsFinished", {"entity":dead, "outcome":"death"})
	elif e.get("killer", null) == _data["entity"]:
		_data["kills"] += 1

func _victory(e: Dictionary) -> void:
	e["accepted"] = false
	if _data.is_empty() or _data["finished"] or _data["floor"] != 4 or e.get("entity",null) != _data["entity"]: return
	var portal := {"entity":_data["entity"]}
	EventBus.publish(&"DungeonPortalAvailabilityRequested", portal)
	if not portal.get("rule_allowed",false): return
	_data["final_stats"] = _read_stats(_data["entity"])
	_data["finished"] = true
	_data["outcome"] = "victory"
	e["accepted"] = true
	EventBus.publish(&"RunStatisticsFinished", {"entity":_data["entity"], "outcome":"victory"})

func _read_stats(entity: StringName) -> Dictionary:
	var result := {}
	for stat in STATS:
		var q := {"entity":entity, "stat":stat, "found":false}
		EventBus.publish(&"StatGetRequested", q)
		if q.get("found", false): result[str(stat)] = q["value"]
	return result

func _get_stats(e: Dictionary) -> void:
	e["found"] = not _data.is_empty()
	if not e["found"]: return
	var count := 0
	for rooms in _data["visited"].values(): count += rooms.size()
	var progress := {"entity":_data["entity"],"found":false}
	EventBus.publish(&"DemoProgressionGetRequested",progress)
	var level = progress.get("data",{}).get("level",null) if progress.get("found",false) else null
	e["data"] = {"entity":_data["entity"], "kills":_data["kills"], "rooms":count, "depth":_data["max_depth"] if _data["depth_known"] else null, "floor":_data["floor"], "level":level, "stats":_data["final_stats"].duplicate(true) if _data["finished"] else _read_stats(_data["entity"]), "finished":_data["finished"], "outcome":_data["outcome"]}

func _collect(e: Dictionary) -> void:
	e["sections"]["run_statistics"] = _data.duplicate(true)
func _apply(e: Dictionary) -> void:
	_data = e["sections"]["run_statistics"].duplicate(true)
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var sections = e.get("sections", null)
	if not sections is Dictionary or not sections.get("run_statistics", null) is Dictionary: return
	var d: Dictionary = sections["run_statistics"]
	if d.is_empty():
		e["valid"] = true
		return
	if not d.get("entity", null) is StringName or d["entity"] == &"" or not d.get("floor", null) is int or d["floor"] < 1 or d["floor"] > 4 or not d.get("root", null) is StringName or d["root"] == &"": return
	if not d.get("visited", null) is Dictionary or not d.get("kills", null) is int or d["kills"] < 0 or not d.get("depth_known", null) is bool or not d.get("finished", null) is bool or not d.get("final_stats", null) is Dictionary: return
	var depth = d.get("max_depth", null)
	if not (depth is float or depth is int) or not is_finite(float(depth)) or float(depth) < 0: return
	if (not d["finished"] and d.get("outcome", null) != "") or (d["finished"] and d.get("outcome", null) not in ["death", "victory"]): return
	if (not d["finished"] or d["outcome"] == "victory") and not sections.get("entities", {}).has(d["entity"]): return
	if d["outcome"] == "victory":
		if d["floor"] != 4 or sections.get("spawn",{}).get("boss",{}).get("status","") != "defeated" or sections.get("dungeon_portal",{}).get("status","") != "placed": return
	for floor_no in d["visited"]:
		if not floor_no is int or floor_no < 1 or floor_no > d["floor"] or not d["visited"][floor_no] is Dictionary: return
		for room in d["visited"][floor_no]:
			if not room is StringName or room == &"" or d["visited"][floor_no][room] != true: return
	e["valid"] = true
