extends Node
## Щит переходит в другую руку за 1 с, меняясь с одноручным оружием.
const ACTION := &"shield_change_hand"
var _pending: Dictionary = {}
var _busy := false
var _committing: StringName = &""
var _launch: StringName = &""
var _launch_permit := false
func _ready() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION,"name":"Сменить руку щита","type":&"utility","base_duration":1.0,"interruptible":true}})
	EventBus.subscribe(&"ShieldHandChangeRequested",_start)
	EventBus.subscribe(&"ActionStartAllowedRequested",_guard_start)
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested",_guard_ownership)
	EventBus.subscribe(&"LootEntityRemovalCheckRequested",_guard_removal)
	EventBus.subscribe(&"ActionCompleted",_completed)
	EventBus.subscribe(&"ActionInterrupted",_interrupted)
	EventBus.subscribe(&"EntityRemoved",_removed)
	EventBus.subscribe(&"EntityDied",_removed)
	EventBus.subscribe(&"SnapshotCollectRequested",_collect)
	EventBus.subscribe(&"SnapshotApplyRequested",_restore)
	EventBus.subscribe(&"ShieldHandSnapshotValidateRequested",_validate)
func _guard_start(e: Dictionary) -> void:
	if e.get("action",null) != ACTION: return
	if e.get("entity",null) != _launch or not _launch_permit: e["allowed"] = false
	else: _launch_permit = false
func _guard_ownership(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if actor is StringName and _pending.has(actor) and _committing != actor and not CombatService.is_entity_dead(actor): e["allowed"] = false
func _guard_removal(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if actor is StringName and _pending.has(actor) and not CombatService.is_entity_dead(actor): e["allowed"] = false
func _item(id: StringName) -> Dictionary:
	var q := {"item":id,"found":false}
	EventBus.publish(&"ItemGetRequested",q)
	return q
func _valid(actor: StringName, p: Dictionary) -> bool:
	if CombatService.is_entity_dead(actor): return false
	var gear := {"entity":actor,"component":&"equipment","found":false}
	EventBus.publish(&"ComponentGetRequested",gear)
	if not gear.get("found",false) or not gear.get("data",null) is Dictionary: return false
	var from: String = p["from"]
	var to := "off" if from == "main" else "main"
	if gear["data"].get(from,null) != p["shield"] or gear["data"].get(to,null) != p["other"]: return false
	var shield := _item(p["shield"])
	if not shield.get("found",false) or not shield.get("base",null) is Dictionary or shield["base"].get("slot",null) != "shield": return false
	if p["other"] != null:
		var weapon := _item(p["other"])
		if not weapon.get("found",false) or not weapon.get("base",null) is Dictionary or weapon["base"].get("slot",null) != "weapon" or not weapon["base"].get("tags",null) is Array or weapon["base"]["tags"].has("two_handed"): return false
	return true
func _start(e: Dictionary) -> void:
	e["accepted"] = false
	e.erase("error")
	var actor = e.get("entity",null)
	var from = e.get("slot",null)
	if _busy or not actor is StringName or actor == &"" or not from is String or from not in ["main","off"] or _pending.has(actor): e["error"] = "Нужны персонаж и рука со щитом"; return
	_busy = true
	var gear := {"entity":actor,"component":&"equipment","found":false}
	EventBus.publish(&"ComponentGetRequested",gear)
	if not gear.get("found",false) or not gear.get("data",null) is Dictionary:
		_busy = false; e["error"] = "Экипировка недоступна"; return
	var to := "off" if from == "main" else "main"
	var shield = gear["data"].get(from,null)
	var other = gear["data"].get(to,null)
	if not shield is StringName or shield == &"" or (other != null and (not other is StringName or other == &"")):
		_busy = false; e["error"] = "Некорректные руки"; return
	var p := {"shield":shield,"from":from,"other":other}
	if not _valid(actor,p):
		_busy = false; e["error"] = "Нужен щит и пустая рука или одноручное оружие"; return
	_pending[actor] = p
	_launch = actor
	_launch_permit = true
	var start := {"entity":actor,"action":ACTION,"duration":1.0,"accepted":false}
	EventBus.publish(&"ActionStartRequested",start)
	_launch = &""
	_launch_permit = false
	var current := {"entity":actor,"found":false}
	EventBus.publish(&"ActionGetRequested",current)
	if not start.get("accepted",false) or not _pending.has(actor) or not current.get("found",false) or current["data"].get("id",null) != ACTION or not _valid(actor,p):
		if current.get("found",false) and current["data"].get("id",null) == ACTION: EventBus.publish(&"ActionCancelRequested", {"entity":actor,"reason":&"shield_unavailable"})
		_pending.erase(actor)
		_busy = false; e["error"] = "Не удалось начать смену руки"; return
	_busy = false
	e["accepted"] = true
	EventBus.publish(&"ShieldHandChangeStarted", {"entity":actor,"shield":shield,"from":from,"to":to,"other":other,"duration":1.0})
func authorizes_commit(actor: StringName, shield: StringName, from: String, other: Variant) -> bool:
	return _busy and _committing == actor and _pending.get(actor,{}) == {"shield":shield,"from":from,"other":other}
func _completed(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null) != ACTION or not _pending.has(actor): return
	var p: Dictionary = _pending[actor]
	if _busy:
		_pending.erase(actor)
		EventBus.publish(&"ShieldHandChangeFailed", {"entity":actor,"reason":"Вложенное завершение"}); return
	_busy = true
	var valid := _valid(actor,p)
	_committing = actor
	var ok: bool = valid and EntityRegistry.swap_shield_hands(actor,p["shield"],p["from"],p["other"])
	_committing = &""
	_pending.erase(actor)
	_busy = false
	var to := "off" if p["from"] == "main" else "main"
	if ok: EventBus.publish(&"ShieldHandChanged", {"entity":actor,"shield":p["shield"],"from":p["from"],"to":to,"other":p["other"]})
	else: EventBus.publish(&"ShieldHandChangeFailed", {"entity":actor,"reason":"Руки изменились или перестановка запрещена"})
func _interrupted(e: Dictionary) -> void:
	var actor = e.get("entity",null)
	if e.get("action",null) != ACTION or not _pending.has(actor): return
	_pending.erase(actor)
	EventBus.publish(&"ShieldHandChangeInterrupted", {"entity":actor,"reason":e.get("reason",&"cancelled")})
func _removed(e: Dictionary) -> void: _pending.erase(e.get("entity",null))
func _collect(e: Dictionary) -> void:
	if _busy: e["errors"].append("Нельзя сохранять при смене руки щита"); return
	e["sections"]["shield_hand_actions"] = _pending.duplicate(true)
func _restore(e: Dictionary) -> void:
	_pending = e["sections"]["shield_hand_actions"].duplicate(true)
	_busy = false
	_committing = &""
	_launch = &""
	_launch_permit = false
func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var s = e.get("sections",null)
	if not s is Dictionary or not s.get("shield_hand_actions",null) is Dictionary or not s.get("entities",null) is Dictionary or not s.get("items",{}).get("instances",null) is Dictionary or not s.get("items",{}).get("bases",null) is Dictionary or not s.get("actions",{}).get("active",null) is Dictionary: return
	var pending: Dictionary = s["shield_hand_actions"]
	var active: Dictionary = s["actions"]["active"]
	for actor in pending:
		var p = pending[actor]
		if not actor is StringName or actor == &"" or not s["entities"].has(actor) or not s["entities"][actor] is Dictionary or not p is Dictionary or p.size() != 3 or not p.get("shield",null) is StringName or p["shield"] == &"" or not p.get("from",null) is String or p["from"] not in ["main","off"] or not p.has("other"): return
		if p["other"] != null and (not p["other"] is StringName or p["other"] == &""): return
		var to := "off" if p["from"] == "main" else "main"
		var gear = s["entities"][actor].get(&"equipment",null)
		if not gear is Dictionary or gear.get(p["from"],null) != p["shield"] or gear.get(to,null) != p["other"]: return
		if not active.has(actor) or not active[actor] is Dictionary or active[actor].get("id",null) != ACTION or active[actor].get("steps",null) != 100 or s.get("combat",{}).get("dead",{}).has(actor): return
		var instances: Dictionary = s["items"]["instances"]
		var bases: Dictionary = s["items"]["bases"]
		if not instances.has(p["shield"]) or not instances[p["shield"]] is Dictionary or not bases.has(instances[p["shield"]].get("base_id",null)): return
		var shield = bases[instances[p["shield"]]["base_id"]]
		if not shield is Dictionary or shield.get("slot",null) != "shield": return
		if p["other"] != null:
			if not instances.has(p["other"]) or not instances[p["other"]] is Dictionary or not bases.has(instances[p["other"]].get("base_id",null)): return
			var other = bases[instances[p["other"]]["base_id"]]
			if not other is Dictionary or other.get("slot",null) != "weapon" or not other.get("tags",null) is Array or other["tags"].has("two_handed"): return
	for actor in active:
		if active[actor] is Dictionary and active[actor].get("id",null) == ACTION and not pending.has(actor): return
	e["valid"] = true
