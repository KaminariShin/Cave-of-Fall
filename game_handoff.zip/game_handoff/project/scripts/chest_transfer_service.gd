extends Node
## Извлечение одной вещи из открытого сундука за 0,1 с.
const ACTION := &"chest_take"
var _pending: Dictionary = {} # actor -> {object, item}
var _busy := false
var _launch: StringName = &""
var _committing := false
var _commit_actor: StringName = &""
var _commit_object: StringName = &""
var _commit_item: StringName = &""

func _ready() -> void:
	EventBus.publish(&"ActionDefinitionRegisterRequested", {"data":{"id":ACTION, "name":"Взять предмет из сундука", "type":&"utility", "base_duration":0.1, "interruptible":true}})
	EventBus.subscribe(&"ChestTakeRequested", _take)
	EventBus.subscribe(&"ActionStartAllowedRequested", _action_guard)
	EventBus.subscribe(&"EntityOwnershipMutationCheckRequested", _ownership_guard)
	EventBus.subscribe(&"LootEntityRemovalCheckRequested", _removal_guard)
	EventBus.subscribe(&"ActionCompleted", _completed)
	EventBus.subscribe(&"ActionInterrupted", _interrupted)
	EventBus.subscribe(&"EntityMoved", _moved)
	EventBus.subscribe(&"SnapshotCollectRequested", _collect)
	EventBus.subscribe(&"SnapshotApplyRequested", _apply)
	EventBus.subscribe(&"ChestTransferSnapshotValidateRequested", _validate)

func _action_guard(e: Dictionary) -> void:
	if e.get("action", null) == &"stagger" and _pending.has(e.get("entity", null)): e["allowed"] = false
	if e.get("action", null) == ACTION and (_launch == &"" or e.get("entity", null) != _launch): e["allowed"] = false

func _ownership_guard(e: Dictionary) -> void:
	var entity = e.get("entity", null)
	if _committing and entity in [_commit_actor, _commit_object]: return
	for actor in _pending:
		if entity == actor or entity == _pending[actor]["object"]: e["allowed"] = false; return

func _removal_guard(e: Dictionary) -> void:
	var entity = e.get("entity", null)
	for actor in _pending:
		if entity == actor or entity == _pending[actor]["object"]: e["allowed"] = false; return

func _valid_context(actor: StringName, object: StringName, item: StringName) -> bool:
	var mode := {}
	EventBus.publish(&"GameModeGetRequested", mode)
	if mode.get("entity", null) != actor or CombatService.is_entity_dead(actor): return false
	var chest := {"entity":actor, "object":object, "found":false}
	EventBus.publish(&"ObjectContainerGetRequested", chest)
	if not chest.get("found", false) or not chest.get("inventory", {}).get("items", []).has(item): return false
	var inv := {"entity":actor, "found":false}
	var volume := {"item":item, "found":false}
	EventBus.publish(&"InventoryGetRequested", inv)
	EventBus.publish(&"ItemVolumeRequested", volume)
	return inv.get("found", false) and inv.get("volume_known", false) and volume.get("found", false) and float(inv["used_volume"]) + float(volume["volume"]) <= float(inv["capacity"]) + 0.000000001

func _take(e: Dictionary) -> void:
	e["accepted"] = false
	var actor = e.get("entity", null)
	var object = e.get("object", null)
	var item = e.get("item", null)
	if _busy or not actor is StringName or actor == &"" or not object is StringName or object == &"" or not item is StringName or item == &"" or _pending.has(actor): return
	for pending in _pending.values():
		if pending["object"] == object: e["error"] = "Сундук уже занят"; return
	_busy = true
	if not _valid_context(actor, object, item):
		_busy = false
		e["error"] = "Сундук или предмет недоступен, либо не хватает места"; return
	_pending[actor] = {"object":object, "item":item}
	_launch = actor
	var request := {"entity":actor, "action":ACTION, "duration":0.1, "accepted":false}
	EventBus.publish(&"ActionStartRequested", request)
	_launch = &""
	var active := {"entity":actor, "found":false}
	EventBus.publish(&"ActionGetRequested", active)
	if not request.get("accepted", false) or not _pending.has(actor) or not active.get("found", false) or active["data"].get("id", null) != ACTION or not _valid_context(actor, object, item):
		if active.get("found", false) and active["data"].get("id", null) == ACTION: EventBus.publish(&"ActionCancelRequested", {"entity":actor, "reason":&"chest_unavailable"})
		_pending.erase(actor)
		_busy = false
		e["error"] = "Перенос не удалось начать"; return
	_busy = false
	e["accepted"] = true
	EventBus.publish(&"ChestTakeStarted", {"entity":actor, "object":object, "item":item, "duration":0.1})

func authorizes_commit(actor: StringName, object: StringName, item: StringName) -> bool:
	return _busy and _committing and _commit_actor == actor and _commit_object == object and _commit_item == item and _pending.get(actor, {}) == {"object":object, "item":item}

func commit_context_valid(actor: StringName, object: StringName, item: StringName) -> bool:
	return authorizes_commit(actor, object, item) and _valid_context(actor, object, item)

func _completed(e: Dictionary) -> void:
	var actor = e.get("entity", null)
	if e.get("action", null) != ACTION or not _pending.has(actor): return
	var op: Dictionary = _pending[actor]
	if _busy:
		_pending.erase(actor)
		EventBus.publish(&"ChestTakeFailed", {"entity":actor, "object":op["object"], "item":op["item"], "reason":"Вложенное завершение"})
		return
	_busy = true
	_commit_actor = actor
	_commit_object = op["object"]
	_commit_item = op["item"]
	_committing = true
	var ok: bool = EntityRegistry.transfer_chest_item(actor, op["object"], op["item"])
	_committing = false
	_commit_actor = &""
	_commit_object = &""
	_commit_item = &""
	if ok:
		EventBus.publish(&"ComponentChanged", {"entity":op["object"], "component":&"inventory", "created":false})
		EventBus.publish(&"ComponentChanged", {"entity":actor, "component":&"inventory", "created":false})
	_pending.erase(actor)
	_busy = false
	if ok:
		EventBus.publish(&"InventoryItemRemoved", {"entity":op["object"], "item":op["item"]})
		EventBus.publish(&"InventoryItemAdded", {"entity":actor, "item":op["item"]})
		EventBus.publish(&"ChestTakeCompleted", {"entity":actor, "object":op["object"], "item":op["item"]})
	else:
		EventBus.publish(&"ChestTakeFailed", {"entity":actor, "object":op["object"], "item":op["item"], "reason":"Условия переноса изменились"})

func _interrupted(e: Dictionary) -> void:
	var actor = e.get("entity", null)
	if e.get("action", null) != ACTION or not _pending.has(actor): return
	var op: Dictionary = _pending[actor]
	_pending.erase(actor)
	EventBus.publish(&"ChestTakeInterrupted", {"entity":actor, "object":op["object"], "item":op["item"], "reason":e.get("reason", &"cancelled")})

func _moved(e: Dictionary) -> void:
	var actor = e.get("entity", null)
	if not _pending.has(actor): return
	var op: Dictionary = _pending[actor]
	var chest := {"entity":actor, "object":op["object"], "found":false}
	EventBus.publish(&"ObjectContainerGetRequested", chest)
	if not chest.get("found", false): EventBus.publish(&"ActionCancelRequested", {"entity":actor, "reason":&"chest_out_of_reach"})

func _collect(e: Dictionary) -> void:
	if _busy: e["errors"].append("Нельзя сохранять во время изменения переноса из сундука"); return
	e["sections"]["chest_transfers"] = _pending.duplicate(true)
func _apply(e: Dictionary) -> void:
	_pending = e["sections"]["chest_transfers"].duplicate(true)
	_busy = false
	_launch = &""
	_committing = false

func _validate(e: Dictionary) -> void:
	e["valid"] = false
	var s = e.get("sections", null)
	if not s is Dictionary or not s.get("chest_transfers", null) is Dictionary or not s.get("actions", {}).get("active", null) is Dictionary or not s.get("entities", null) is Dictionary or not s.get("objects", {}).get("objects", null) is Dictionary or not s.get("items", {}).get("instances", null) is Dictionary: return
	var used := {}
	for actor in s["chest_transfers"]:
		var op = s["chest_transfers"][actor]
		if not actor is StringName or not op is Dictionary or not op.get("object", null) is StringName or not op.get("item", null) is StringName or used.has(op["object"]) or not s["entities"].has(actor) or not s["entities"].has(op["object"]) or not s["items"]["instances"].has(op["item"]): return
		used[op["object"]] = true
		var obj = s["objects"]["objects"].get(op["object"], null)
		if actor == &"" or op["object"] == &"" or op["item"] == &"" or actor == op["object"] or not s["entities"][op["object"]] is Dictionary or not s["entities"][actor] is Dictionary: return
		var inventory = s["entities"][op["object"]].get(&"inventory", {})
		if not inventory is Dictionary or not inventory.get("items", null) is Array: return
		var action = s["actions"]["active"].get(actor, null)
		if not obj is Dictionary or obj.get("type", "") != "chest" or not obj.get("opened", false) or not inventory.get("items", []).has(op["item"]) or not action is Dictionary or action.get("id", null) != ACTION or actor != s["actions"].get("controlled", null): return
		var space = s.get("space", {})
		var room_data = s.get("rooms", {}).get("rooms", {}).get(obj.get("room", null), null)
		var body = space.get("bodies", {}).get(actor, null)
		if not body is Dictionary or not body.get("anchor", null) is Vector2i or not body.get("size", null) is int or body["size"] < 1 or not obj.get("tile", null) is Vector2i or not room_data is Dictionary or not room_data.get("origin_cell", null) is Vector2i or not room_data.get("size_cells", null) is Vector2i: return
		var a: Vector2i = body["anchor"]
		var p: Vector2i = obj["tile"]
		var n: int = body["size"]
		if not Rect2i(room_data["origin_cell"] * 4, room_data["size_cells"] * 4).encloses(Rect2i(a, Vector2i.ONE * n)): return
		if not (((p.x == a.x - 1 or p.x == a.x + n) and p.y >= a.y and p.y < a.y + n) or ((p.y == a.y - 1 or p.y == a.y + n) and p.x >= a.x and p.x < a.x + n)): return
	for actor in s["actions"]["active"]:
		var action = s["actions"]["active"][actor]
		if action is Dictionary and action.get("id", null) == ACTION and not s["chest_transfers"].has(actor): return
	e["valid"] = true
